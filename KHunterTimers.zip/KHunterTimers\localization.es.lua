if( GetLocale() == "esES" ) then
	
	--Disparos
	KHT_CONC_SHOT = "Disparo de conmoci\195\179n";
	KHT_IMP_CONC = "Disparo de conmoci\195\179n mejorado";
	KHT_IMP_CONC_SHORT = "Disparo de conmoci\195\179n mej.";
	KHT_SCATTER = "Disparo disperso";
	KHT_AUTO_SHOT = "Disparo autom\195\161tico";
	KHT_SILENCE_SHOT = "Disparo silenciador";

	--Buffs
	KHT_HUNTERS_MARK = "Marca del cazador";
	KHT_RAPID_FIRE = "Fuego r\195\161pido";
	KHT_MISDIRECTION = "Redirecci\195\179n";

	--Racials
	KHT_BERSERKING = "Enrabiar";
	KHT_BLOOD_FURY = "Furia de sangre";
	KHT_STONEFORM = "Forma p\195\169trea";
	KHT_WAR_STOMP = "Pisot\195\179n de guerra";
	KHT_ARCANE = "Torrente arcano";

	--Set/Item Procs
	KHT_EXPOSE_WEAKNESS = "Exponer debilidad";
	KHT_PRIMAL_BLESSING = "Bendici\195\179n primigenia";
	KHT_SANTOS = "Bendici\195\179n de Santos";			-- Don Santos' Famous Hunting Rifle
	KHT_HEROIC = "Resoluci\195\179n heroica";			-- Desolation 4-piece bonus
	KHT_SKYFIRE = "Presteza de fuego celeste";			-- Thundering Skyfire Diamond
	KHT_BEASTLORD = "Debilidad aprovechada";			-- Beast Lord 4-piece bonus
	KHT_CHAMPION = "Sortija del campe\195\179n eterno";	-- Band of the Eternal Champion

	--Talent Procs
	KHT_QUICK_SHOTS = "Disparos presurosos";
	KHT_FEROCIOUS = "Inspiraci\195\179n";
	KHT_RAPID_KILLING = "Matanza r\195\161pida";
	KHT_TACTICIAN = "Maestro T\195\161ctico";
	KHT_CONC_BARRAGE = "Tromba de conmoci\195\179n";
	KHT_AIMED_SHOT = "Disparo de punter\195\173a";

	--Trinkets
	KHT_DEVILSAUR = "Furia de demosaurio";
	KHT_ZHM = "Fuerza agitada";
	KHT_EARTHSTRIKE = "Golpe de tierra";
	KHT_SWARMGUARD = "Distintivo del Guardaenjambre";
	KHT_JOM_GABBAR = "Jom Gabbar";
	KHT_KISS_SPIDER = "Beso de la ara\195\177a";
	KHT_FEROCITY = "Ferocidad";				-- Bladefist's Breath and Ancient Draenei War Talisman
	KHT_BURNING_HATRED = "Odio ardiente";		-- Uniting Charm and Ogre Mauler's Badge
	KHT_ANCIENT_POWER = "Poder ancestral";		-- Core of Ar'kelos
	KHT_NIGHTSEYE = "Pantera de ojo de noche";	-- Nightseye Panther
	KHT_UNRAVELLER = "Ira del Desenredador";	-- Hourglass of the Unraveller
	KHT_LUST = "Deseo de batalla";			-- Bloodlust Brooch
	KHT_HASTE = "Celeridad";					-- Abacus of the Violent Odds
	KHT_HEROISM = "Hero\195\173smo";			-- Terrokar Tablet of Precision
	KHT_TSUNAMI = "Furia de las olas batientes";	-- Tsunami Talisman
	KHT_ASHTONGUE = "Objetivo mortal";			-- Ashtongue Talisman of Swiftness
	KHT_WRATH = "Aura de C\195\179lera";		-- Darkmoon Card: Wrath
	KHT_DELUSIONAL = "Ilusorio";				-- Darkmoon Card: Madness
	KHT_KLEPTOMANIA = "Cleptoman\195\173a";		-- Darkmoon Card: Madness
	KHT_MANIC = "Man\195\173aco";				-- Darkmoon Card: Madness
	KHT_MARTYR = "Complejo de m\195\161rtir";	-- Darkmoon Card: Madness
	KHT_NARCISSISM = "Narcisismo";			-- Darkmoon Card: Madness
	KHT_PARANOIA = "Paranoia";				-- Darkmoon Card: Madness
	KHT_TALON = "Poder de disparo";			-- Talon of Al'ar
	KHT_SKYGUARD = "Valor de combate";			-- Skyguard Silver Cross
	KHT_MADNESS = "Golpe en\195\169rgico";		-- Madness of the Betrayer
	KHT_BERSERKER = "Llamada del rabioso";		-- Berserker's Call

	--Pet Abilities
	KHT_PET_INTIM = "Pet Intimidaci\195\179n";
	KHT_INTIM = "Intimidaci\195\179n";
	KHT_BW = "C\195\179lera de las bestias";
	KHT_FEED_PET = "Alimentar mascota";
	KHT_MEND_PET = "Aliviar mascota";
	KHT_PET_FRENZY = "Efecto de frenes\195\173";
	KHT_KILL_COMMAND = "Matar";
	KHT_SCREECH = "Chirrido";

	--Traps
	KHT_TRAP = "Trampa";
	KHT_FROST_TRAP = "Trampa de Escarcha";
	KHT_EXPL_TRAP = "Trampa explosiva";
	KHT_IMMO_TRAP = "Trampa de inmolaci\195\179n";
	KHT_FREEZING_TRAP = "Trampa congelante";
	KHT_SNAKE_TRAP = "Trampa con culebras";
	KHT_VENOMOUS = "Culebra venenosa";
	KHT_ENTRAPMENT = "Atrapamiento";
	KHT_AURA = "Aura";
	KHT_PRIMED = "colocada";

	--Melee Abilities
	KHT_WING_CLIP = "Cortar alas";
	KHT_IMP_WC = "Cortar alas mejorado";
	KHT_IMP_WC_SHORT = "Cortar alas mejorado";
	KHT_COUNTER = "Contraataque";
	KHT_DETERRENCE = "Disuasi\195\179n";

	--Stings
	KHT_STING = "Picadura";
	KHT_WYVERN = "Picadura de Dracole\195\179n";
	KHT_WYVERN_TEXT = "Picadura de Dracole\195\179n (Dormir)";
	KHT_SERPENT = "Picadura de serpiente";
	KHT_VIPER = "Picadura de v\195\173bora";
	KHT_SCORPID = "Picadura de esc\195\179rpido";

	--Other
	KHT_FLARE = "Bengala";
	KHT_FEAR_BEAST = "Asustar bestia";
	KHT_DONE = "Fin!"
	KHT_FEIGN_DEATH = "Fingir muerte";

	--Enemies
	KHT_FRENZY = "Frenes\195\173";
--	KHT_FRENZY_EMOTE = "goes into a killing frenzy!";
--	KHT_FRENZY_FLAMEGOR = "goes into a frenzy!";
	KHT_CHROMAGGUS = "Chromaggus";
	KHT_FLAMEGOR = "Flamagor";
	KHT_MAGMADAR = "Magmadar";
	KHT_HUHURAN = "Princesa Huhuran";
	KHT_GLUTH = "Gluth";

	--Status Text---------------------------------------

	KHT_OPTIONS_COLOR_CHANGE = "Cambiar Color";
	KHT_OPTIONS_MILI = "ms";
	KHT_OPTIONS_LOCK = "Bloquear";
	KHT_OPTIONS_BAR_DIST = "Distancia entre Barras";
	KHT_OPTIONS_SCALE = "Escalar";
	KHT_OPTIONS_FLASH = "Flash Time";
	KHT_OPTIONS_STEP = "Flash Step";
	KHT_OPTIONS_BARSTART = "Color comienzo de barra";
	KHT_OPTIONS_BAREND = "Color fin de barra";
	KHT_OPTIONS_BACKDROP = "Color de fondo";
	KHT_OPTIONS_TIMERS_TEXT = "Temporizadores";
	KHT_OPTIONS_BARS_TEXT = "Barras";
	KHT_OPTIONS_DECIMALS = "Decimales";
	KHT_OPTIONS_SHOT_DELAY = "Retraso Disparo";
	KHT_OPTIONS_SHOW_TEX = "Mostrar Texturas";
	KHT_OPTIONS_LARGE_TEX = "Texturas Grandes";
	KHT_OPTIONS_APPEND = "A\195\177adir Objetivo";
	KHT_OPTIONS_BORDER = "Color Borde";
	KHT_OPTIONS_TEXT_COLOR = "Color Texto";
	KHT_OPTIONS_TIME_COLOR = "Color Tiempo";
	KHT_OPTIONS_TARGET_COLOR = "Color Texto Objetivo";
	KHT_OPTIONS_OVERALL_OPACITY = "Opacidad";
	KHT_OPTIONS_HIDE_TEXT = "Esconder Texto";
	KHT_OPTIONS_HIDE_TIME = "Esconder Tiempo";
	KHT_OPTIONS_HIDE_GAP = "Esconder Gap";
	KHT_OPTIONS_BAR_THICKNESS = "Grosor Barra";
	KHT_OPTIONS_HIDE_PADDING = "Hide Padding";
	KHT_OPTIONS_STICKY = "Sticky Auto Shot";
	KHT_OPTIONS_DOWN = "Barras en cascada descendente";

end
	
