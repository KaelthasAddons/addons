KHT_VERSION = "v2.3.2";

--Abilities-----------------------------------------
--Shots
KHT_CONC_SHOT = "Concussive Shot";
KHT_IMP_CONC = "Improved Concussive Shot";
KHT_IMP_CONC_SHORT = "Imp. Concussive Shot";
KHT_SCATTER = "Scatter Shot";
KHT_AUTO_SHOT = "Auto Shot";
KHT_SILENCE_SHOT = "Silencing Shot";

--Buffs
KHT_HUNTERS_MARK = "Hunter's Mark";
KHT_RAPID_FIRE = "Rapid Fire";
KHT_MISDIRECTION = "Misdirection";

--Racials
KHT_BERSERKING = "Berserking";
KHT_BLOOD_FURY = "Blood Fury";
KHT_STONEFORM = "Stoneform";
KHT_WAR_STOMP = "War Stomp";
KHT_ARCANE = "Arcane Torrent";

--Set/Item Procs
KHT_EXPOSE_WEAKNESS = "Expose Weakness";	-- Dragonstalker 8-piece bonus or Survival talent
KHT_PRIMAL_BLESSING = "Primal Blessing";	-- ZG fist weapons
KHT_SANTOS = "Santos' Blessing";			-- Don Santos' Famous Hunting Rifle
KHT_HEROIC = "Heroic Resolution";			-- Desolation 4-piece bonus
KHT_SKYFIRE = "Skyfire Swiftness";			-- Thundering Skyfire Diamond
KHT_BEASTLORD = "Exploited Weakness";		-- Beast Lord 4-piece bonus
KHT_CHAMPION = "Eternal Champion";			-- Band of the Eternal Champion

--Talent Procs
KHT_QUICK_SHOTS = "Quick Shots";			-- Improved Aspect of the Hawk
KHT_FEROCIOUS = "Ferocious Inspiration";
KHT_RAPID_KILLING = "Rapid Killing";
KHT_TACTICIAN = "Master Tactician";
KHT_CONC_BARRAGE = "Concussive Barrage";
KHT_AIMED_SHOT = "Aimed Shot";

--Trinkets
KHT_DEVILSAUR = "Devilsaur Fury";			-- Devilsaur Eye
KHT_ZHM = "Restless Strength";			-- Zandalarian Hero Medallion
KHT_EARTHSTRIKE = "Earthstrike";			-- Earthstrike
KHT_SWARMGUARD = "Badge of the Swarmguard";	-- Badge of the Swarmguard
KHT_JOM_GABBAR = "Jom Gabbar";			-- Jom Gabbar
KHT_KISS_SPIDER = "Kiss of the Spider";		-- Kiss of the Spider
KHT_FEROCITY = "Ferocity";				-- Bladefist's Breath and Ancient Draenei War Talisman
KHT_BURNING_HATRED = "Burning Hatred";		-- Uniting Charm and Ogre Mauler's Badge
KHT_ANCIENT_POWER = "Ancient Power";		-- Core of Ar'kelos
KHT_NIGHTSEYE = "Nightseye Panther";		-- Nightseye Panther
KHT_UNRAVELLER = "Rage of the Unraveller";	-- Hourglass of the Unraveller
KHT_LUST = "Lust for Battle";				-- Bloodlust Brooch
KHT_HASTE = "Haste";					-- Abacus of the Violent Odds and Dragonspine Trophy
KHT_HEROISM = "Heroism";					-- Terrokar Tablet of Precision
KHT_TSUNAMI = "Fury of the Crashing Waves";	-- Tsunami Talisman
KHT_ASHTONGUE = "Deadly Aim";				-- Ashtongue Talisman of Swiftness
KHT_WRATH = "Aura of Wrath";				-- Darkmoon Card: Wrath
KHT_DELUSIONAL = "Delusional";			-- Darkmoon Card: Madness
KHT_KLEPTOMANIA = "Kleptomania";			-- Darkmoon Card: Madness
KHT_MANIC = "Manic";					-- Darkmoon Card: Madness
KHT_MARTYR = "Martyr Complex";			-- Darkmoon Card: Madness
KHT_NARCISSISM = "Narcissism";			-- Darkmoon Card: Madness
KHT_PARANOIA = "Paranoia";				-- Darkmoon Card: Madness
KHT_TALON = "Shot Power";				-- Talon of Al'ar
KHT_SKYGUARD = "Combat Valor";			-- Skyguard Silver Cross
KHT_MADNESS = "Forceful Strike";			-- Madness of the Betrayer
KHT_BERSERKER = "Call of the Berserker";	-- Berserker's Call

--Pet Abilities
KHT_PET_INTIM = "Pet Intimidation";
KHT_INTIM = "Intimidation";
KHT_BW = "Bestial Wrath";
KHT_FEED_PET = "Feed Pet";
KHT_MEND_PET = "Mend Pet";
KHT_PET_FRENZY = "Frenzy";
KHT_KILL_COMMAND = "Kill Command";
KHT_SCREECH = "Screech";

--Traps
KHT_TRAP = "Trap";
KHT_FROST_TRAP = "Frost Trap";
KHT_EXPL_TRAP = "Explosive Trap";
KHT_IMMO_TRAP = "Immolation Trap";
KHT_FREEZING_TRAP = "Freezing Trap";
KHT_SNAKE_TRAP = "Snake Trap";
KHT_VENOMOUS = "Venomous Snake";
KHT_ENTRAPMENT = "Entrapment";
KHT_AURA = "aura";
KHT_PRIMED = "primed";

--Melee Abilities
KHT_WING_CLIP = "Wing Clip";
KHT_IMP_WC = "Improved Wing Clip";
KHT_IMP_WC_SHORT = "Imp. Wing Clip";
KHT_COUNTER = "Counterattack";
KHT_DETERRENCE = "Deterrence";

--Stings
KHT_STING = "Sting";
KHT_WYVERN = "Wyvern Sting";
KHT_WYVERN_TEXT = "Wyvern Sting (Sleep)";
KHT_SERPENT = "Serpent Sting";
KHT_VIPER = "Viper Sting";
KHT_SCORPID = "Scorpid Sting";

--Other
KHT_FLARE = "Flare";
KHT_FEAR_BEAST = "Scare Beast";
KHT_DONE = "Done!"
KHT_FEIGN_DEATH = "Feign Death";

--Enemies
KHT_FRENZY = "Frenzy";
KHT_FRENZY_EMOTE = "goes into a killing frenzy!";
KHT_FRENZY_FLAMEGOR = "goes into a frenzy!";
KHT_CHROMAGGUS = "Chromaggus";
KHT_FLAMEGOR = "Flamegor";
KHT_MAGMADAR = "Magmadar";
KHT_HUHURAN = "Princess Huhuran";
KHT_GLUTH = "Gluth";

--Status Text---------------------------------------
KHT_ON = "on";
KHT_OFF = "off";
--Slash Text
KHT_SLASH_HELP = {
	[1] = "Kharthus's Hunter Timers "..KHT_VERSION,
	[2] = "Commands: /kht",
	[3] = "/kht "..KHT_ON.."/"..KHT_OFF,
	[4] = "/kht menu (bring up the gui menu)",
	[5] = "/kht reset (resets all the visible bars)",
	[6] = "/kht resetpos (resets the bar frame position)",
	[7] = "/kht delay <time> (time is in milliseconds)",
	[8] = "/kht flash <timeleft> (timeleft in seconds to flash the bar, 0 for off)",
	[9] = "/kht step <step> (higher step means faster flashing when time is low)",
	[10] = "/kht barcolor r g b (where r, g, b are between 0 and 1)",
	[11] = "/kht barendcolor r g b (where r, g, b are between 0 and 1)",
	[12] = "/kht setbgcolor r g b a (where r, g, b, a are between 0 and 10)",
	[13] = "/kht colorchange "..KHT_ON.."/"..KHT_OFF.." (color change feature)",
	[14] = "/kht up/down (cascade bars up or down)",
	[15] = "/kht scale % (/kht scale 100 = 100% scale)",
	[16] = "/kht lock/unlock (lock or unlock the frame)",
	[17] = "/kht status",
	[18] = "/kht clear all (resets all options to defaults)",
	[19] = "/kht debug (debug info for testing purposes)"
};
KHT_STATUS_STRINGS = {
	[1] = "|cFFFFFF00Kharthus's Hunter Timers "..KHT_VERSION.."|r",
	[2] = "|cFFFFFF00Status:|r %s",
	[3] = "|cFFFFFF00Shot delay:|r %dms", 
	[4] = "|cFFFFFF00Flash time:|r %ds |cFFFFFF00Step:|r %f",
	[5] = "|cFFFFFF00Barcolor:|r %s |cFFFFFF00Barcolorend:|r %s",
	[6] = "|cFFFFFF00Colorchange:|r %s |cFFFFFF00Growth:|r %s",
	[7] = "|cFFFFFF00Scale:|r %d%%"
};

KHT_OPTIONS_COLOR_CHANGE = "Color Change";
KHT_OPTIONS_MILI = "ms";
KHT_OPTIONS_LOCK = "Lock";
KHT_OPTIONS_BAR_DIST = "Distance Between Bars";
KHT_OPTIONS_SCALE = "Scale";
KHT_OPTIONS_FLASH = "Flash Time";
KHT_OPTIONS_STEP = "Flash Step";
KHT_OPTIONS_BARSTART = "Bar Start Color";
KHT_OPTIONS_BAREND = "Bar End Color";
KHT_OPTIONS_BACKDROP = "Backdrop Color";
KHT_OPTIONS_TIMERS_TEXT = "Timers";
KHT_OPTIONS_BARS_TEXT = "Bars";
KHT_OPTIONS_DECIMALS = "Decimals";
KHT_OPTIONS_SHOT_DELAY = "Shot Delay";
KHT_OPTIONS_SHOW_TEX = "Show Textures";
KHT_OPTIONS_LARGE_TEX = "Large Textures";
KHT_OPTIONS_APPEND = "Append Target";
KHT_OPTIONS_BORDER = "Border Color";
KHT_OPTIONS_TEXT_COLOR = "Text Color";
KHT_OPTIONS_TIME_COLOR = "Time Color";
KHT_OPTIONS_TARGET_COLOR = "Target Text Color";
KHT_OPTIONS_OVERALL_OPACITY = "Overall Opacity";
KHT_OPTIONS_HIDE_TEXT = "Hide Text";
KHT_OPTIONS_HIDE_TIME = "Hide Time";
KHT_OPTIONS_HIDE_GAP = "Hide Gap";
KHT_OPTIONS_BAR_THICKNESS = "Bar Thickness";
KHT_OPTIONS_HIDE_PADDING = "Hide Padding";
KHT_OPTIONS_STICKY = "Sticky Auto Shot";
KHT_OPTIONS_DOWN = "Cascade Bars Down";

KHT_RACIALS = "Racials";
KHT_SETITEM = "Set/Item Procs";
KHT_TALENT = "Talent Procs";
KHT_TRINKETS = "Trinkets";

--Options moved to globals because they dealt with other variables
