if( GetLocale() == "deDE" ) then
	--abilities-----------------------------------------
	--shots
	KHT_CONC_SHOT = "Ersch\195\188tternder Schuss";
	KHT_IMP_CONC = "Verbesserter Ersch\195\188tternder Schuss";
	KHT_IMP_CONC_SHORT = "Verb. Ersch\195\188tternder Schuss";
	KHT_SCATTER = "Streuschuss";
	KHT_AUTO_SHOT = "Automatischer Schuss";
	KHT_SILENCE_SHOT = "Unterdr\195\188ckender Schuss";

	--buffs
	KHT_HUNTERS_MARK = "Mal des J\195\164gers";
	KHT_RAPID_FIRE = "Schnellfeuer";
	KHT_MISDIRECTION = "Irref\195\188hrung";

	--Racials
	KHT_BERSERKING = "Berserker";
	KHT_BLOOD_FURY = "Kochendes Blut";
	KHT_STONEFORM = "Steingestalt";
	KHT_WAR_STOMP = "Kriegsdonner";
	KHT_ARCANE = "Arkaner Strom";

	--Set/Item Procs
	KHT_EXPOSE_WEAKNESS = "Schw\195\164che aufdecken";
	KHT_PRIMAL_BLESSING = "Ursegen";
	KHT_SANTOS = "Santos' Segen";						-- Don Santos' Famous Hunting Rifle
	KHT_HEROIC = "Heldenhafte Entschlossenheit";			-- Desolation 4-piece bonus
	KHT_SKYFIRE = "Schnelligkeit des Himmelsdonners";		-- Thundering Skyfire Diamond
	KHT_BEASTLORD = "Schwachpunkt ausnutzen";			-- Beast Lord 4-piece bonus
	KHT_CHAMPION = "Schlachtzugsfraktionsnahkampfring";	-- Band of the Eternal Champion

	--Talent Procs
	KHT_QUICK_SHOTS = "Schnelle Sch\195\188sse";
	KHT_FEROCIOUS = "Wilde Eingebung";
	KHT_RAPID_KILLING = "Schneller Tod";
	KHT_TACTICIAN = "Meister der Taktik";
	KHT_CONC_BARRAGE = "Ersch\195\188tterndes Sperrfeuer";
	KHT_AIMED_SHOT = "Gezielter Schuss";

	--Trinkets
	KHT_DEVILSAUR = "Zorn des Teufelssauriers";
	KHT_ZHM = "Ruhelose St\195\164rke";
	KHT_EARTHSTRIKE = "Erdschlag";
	KHT_SWARMGUARD = "Abzeichen der Schwarmwache";
	KHT_JOM_GABBAR = "Jom Gabbar";
	KHT_KISS_SPIDER = "Kuss der Spinne";
	KHT_FEROCITY = "Wildheit";						-- Bladefist's Breath and Ancient Draenei War Talisman
	KHT_BURNING_HATRED = "Brennender Hass";				-- Uniting Charm and Ogre Mauler's Badge
	KHT_ANCIENT_POWER = "Macht der Urahnen";			-- Core of Ar'kelos
	KHT_NIGHTSEYE = "Nachtaugenpanther";				-- Nightseye Panther
	KHT_UNRAVELLER = "Zorn des Entwirrers";				-- Hourglass of the Unraveller
	KHT_LUST = "Nahkampfschmuck";						-- Bloodlust Brooch
	KHT_HASTE = "Hast";								-- Abacus of the Violent Odds
	KHT_HEROISM = "Heldentum";						-- Terrokar Tablet of Precision
	KHT_TSUNAMI = "Furor der brechenden Wellen";			-- Tsunami Talisman
	KHT_ASHTONGUE = "T\195\182dliche Zielgenauigkeit";	-- Ashtongue Talisman of Swiftness
	KHT_WRATH = "Aura des Zorns";						-- Darkmoon Card: Wrath
	KHT_DELUSIONAL = "Irrsinn";						-- Darkmoon Card: Madness
	KHT_KLEPTOMANIA = "Kleptomanie";					-- Darkmoon Card: Madness
	KHT_MANIC = "Manie";							-- Darkmoon Card: Madness
	KHT_MARTYR = "M\195\164rtyrerkomplex";				-- Darkmoon Card: Madness
	KHT_NARCISSISM = "Narzissmus";					-- Darkmoon Card: Madness
	KHT_PARANOIA = "Paranoia";						-- Darkmoon Card: Madness
	KHT_TALON = "Schusskraft";						-- Talon of Al'ar
	KHT_SKYGUARD = "Heldenmut";						-- Skyguard Silver Cross
	KHT_MADNESS = "Kraftvoller Sto\195\159";			-- Madness of the Betrayer
	KHT_BERSERKER = "Ruf des Berserkers";				-- Berserker's Call

	--pet abilities
	KHT_PET_INTIM = "Tier Einsch\195\188chterung";
	KHT_INTIM = "Einsch\195\188chterung";
	KHT_BW = "Zorn des Wildtiers";
	KHT_FEED_PET = "Tier f\195\188ttern";
	KHT_MEND_PET = "Tier heilen";
	KHT_PET_FRENZY = "Raserei";
	KHT_KILL_COMMAND = "Fass!";
	KHT_SCREECH = "Schrei";

	--traps
	KHT_TRAP = "falle";
	KHT_FROST_TRAP = "Frostfalle";
	KHT_EXPL_TRAP = "Sprengfalle";
	KHT_IMMO_TRAP = "Feuerbrandfalle";
	KHT_FREEZING_TRAP = "Eisk\195\164ltefalle";
	KHT_SNAKE_TRAP = "Schlangenfalle";
	KHT_VENOMOUS = "Giftige Schlange";
	KHT_ENTRAPMENT = "Einfangen";
	KHT_AURA = "-Aura";
	KHT_PRIMED = "gelegt";
	
	--Melee abilities
	KHT_WING_CLIP = "Zurechtstutzen";
	KHT_IMP_WC = "Verbessertes Zurechtstutzen";
	KHT_IMP_WC_SHORT = "Verb. Zurechtstutzen";
	KHT_COUNTER = "Gegenangriff";
	KHT_DETERRENCE = "Abschreckung";
	
	--Stings
	KHT_STING = "biss|stich|Stich";
	-- needs to be "biss" or "stich" or "Stich"
	KHT_WYVERN = "Stich des Fl\195\188geldrachen";
	KHT_WYVERN_TEXT = "Stich des Fl\195\188geldrachen (Schlaf)";
	KHT_SERPENT = "Schlangenbiss";
	KHT_VIPER = "Vipernbiss";
	KHT_SCORPID = "Skorpidstich";
	
	--other
	KHT_FLARE = "Leuchtfeuer";
	KHT_FEAR_BEAST = "Wildtier \195\164ngstigen";
	KHT_DONE = "Fertig!"
	KHT_FEIGN_DEATH = "Totstellen";
	
	--enemies
	KHT_FRENZY = "Raserei";
	KHT_FRENZY_EMOTE = "ger\195\164t in t\195\182dliche Raserei!";
	KHT_FRENZY_FLAMEGOR = "ger\195\164t in Raserei!";
	KHT_CHROMAGGUS = "Chromaggus";
	KHT_FLAMEGOR = "Flammenmaul";
	KHT_MAGMADAR = "Magmadar";
	KHT_HUHURAN = "Prinzessin Huhuran";
	KHT_GLUTH = "Gluth";
	
	--status text---------------------------------------
	KHT_ON = "an";
	KHT_OFF = "aus";
	--Slash text
	KHT_SLASH_HELP = {
		[1] = "Kharthus's Hunter Timers "..KHT_VERSION,
		[2] = "Befehle: /kht",
		[3] = "/kht "..KHT_ON.."/"..KHT_OFF,
		[4] = "/kht menu (zeigt das KHT Men\195\188)",
		[5] = "/kht reset (resets all the visible bars)",
		[6] = "/kht resetpos (resets the bar frame position)",
		[7] = "/kht delay <Zeit> (Zeit in Milisekunden f\195\188r Lagverz\195\182gerung)",
		[8] =  "/kht flash <Zeit> (\195\188brige Zeit in Sekunden, ab der die Leiste blinkt, 0 f\195\188r Aus)",
		[9] =  "/kht step <Schritt> (Gr\195\182ssere Schritte bedeutet schnelleres Blinken wenn Zeit abl\195\164uft)",
		[10] = "/kht barcolor r g b (Leistenfarbe, r, g, b Werte zwischen 0 und 1)",
		[11] = "/kht barendcolor r g b (Leisten-Endfarbe, r, g, b Werte zwischen 0 und 1)",
		[12] = "/kht setbgcolor r g b a (Hintergrundfarbe, r, g, b, a Werte zwischen 0 und 10)",
		[13] = "/kht colorchange "..KHT_ON.."/"..KHT_OFF.." (color change feature)",
		[14] = "/kht up/down (cascade bars up or down)",
		[15] = "/kht scale % (/kht scale 100 = 100% Skalierung)",
		[16] = "/kht lock/unlock (lock or unlock the frame)",
		[17] = "/kht status",
		[18] = "/kht clear all (resets all options to defaults)",
		[19] = "/kht debug (debug info for testing purposes)"
	};
	KHT_STATUS_STRINGS = {
		[1] = "|cFFFFFF00Kharthus's Hunter Timers "..KHT_VERSION.."|r",
		[2] = "|cFFFFFF00Status:|r %s",
		[3] = "|cFFFFFF00Schuss Verz\195\182gerung:|r %dms", 
		[4] = "|cFFFFFF00Flash time:|r %ds |cFFFFFF00Step:|r %f",
		[5] = "|cFFFFFF00Leistenfarbe:|r %s |cFFFFFF00Leisten-Endfarbe:|r %s",
		[6] = "|cFFFFFF00Farb\195\164nderung:|r %s |cFFFFFF00Vergr\195\182sserung:|r %s",
		[7] = "|cFFFFFF00Skalierung:|r %d%%"
	};
	
	KHT_OPTIONS_COLOR_CHANGE = "Farb\195\164nderung";
	KHT_OPTIONS_MILI = "ms";
	KHT_OPTIONS_LOCK = "Sperren";
	KHT_OPTIONS_BAR_DIST = "Abstand zwischen Leisten";
	KHT_OPTIONS_SCALE = "Skalierung";
	KHT_OPTIONS_FLASH = "Blink Zeit";
	KHT_OPTIONS_STEP = "Blink Schritte";
	KHT_OPTIONS_BARSTART = "Leiste Anfangsfarbe";
	KHT_OPTIONS_BAREND = "Leiste Endfarbe";
	KHT_OPTIONS_BACKDROP = "Hintergrundfarbe";
	KHT_OPTIONS_TIMERS_TEXT = "Timer";
	KHT_OPTIONS_BARS_TEXT = "Leisten";
	KHT_OPTIONS_DECIMALS = "Dezimalstellen";
	KHT_OPTIONS_SHOT_DELAY = "Schuss Verz\195\182gerung";
	KHT_OPTIONS_SHOW_TEX = "Zeige Texturen";
	KHT_OPTIONS_LARGE_TEX = "Grosse Texturen";
	KHT_OPTIONS_APPEND = "Ziel anh\195\164ngen";
	KHT_OPTIONS_BORDER = "Rahmenfarbe";
	KHT_OPTIONS_TEXT_COLOR = "Text Farbe";
	KHT_OPTIONS_TIME_COLOR = "Zeit Farbe";
	KHT_OPTIONS_TARGET_COLOR = "Ziel Text Farbe";
	KHT_OPTIONS_OVERALL_OPACITY = "Durchsichtigkeit";
	KHT_OPTIONS_HIDE_TEXT = "Verstecke Text";
	KHT_OPTIONS_HIDE_TIME = "Verstecke Zeit";
	KHT_OPTIONS_HIDE_GAP = "Verstecke L\195\188cke";
	KHT_OPTIONS_BAR_THICKNESS = "Leistendicke";
	KHT_OPTIONS_HIDE_PADDING = "Verstecke Padding";
	KHT_OPTIONS_STICKY = "Sticky Auto Shot";
	
	-- Beutju
	
	--Options moved to globals because they dealt with other variables
		
end
	
