if( GetLocale() == "zhTW" ) then
	--abilities-----------------------------------------
	--shots
	KHT_CONC_SHOT = "震盪射擊";
	KHT_IMP_CONC = "強化震盪射擊";
	KHT_IMP_CONC_SHORT = "強化震盪射擊";
	KHT_SCATTER = "驅散射擊";
	KHT_AUTO_SHOT = "自動射擊";
	KHT_SILENCE_SHOT = "沉默射擊";

	--buffs
	KHT_HUNTERS_MARK = "獵人印記";
	KHT_RAPID_FIRE = "急速射擊";
	KHT_MISDIRECTION = "誤導";

	--Racials
	KHT_BERSERKING = "狂暴";
	KHT_BLOOD_FURY = "血性狂暴";
	KHT_STONEFORM = "石像形態";
	KHT_WAR_STOMP = "戰爭踐踏";
--	KHT_ARCANE = "Arcane Torrent";

	--Set/Item Procs
	KHT_EXPOSE_WEAKNESS = "破甲虛弱";
	KHT_PRIMAL_BLESSING = "遠古神靈的祝福";
	KHT_SANTOS = "桑朵的祝福";			-- Don Santos' Famous Hunting Rifle
--	KHT_HEROIC = "Heroic Resolution";			-- Desolation 4-piece bonus
--	KHT_SKYFIRE = "Skyfire Swiftness";			-- Thundering Skyfire Diamond
--	KHT_BEASTLORD = "Exploited Weakness";		-- Beast Lord 4-piece bonus
--	KHT_CHAMPION = "Band of the Eternal Champion";	-- Band of the Eternal Champion

	--Talent Procs
	KHT_QUICK_SHOTS = "快速射擊";
	KHT_FEROCIOUS = "兇性鼓舞";
	KHT_RAPID_KILLING = "急速殺穆";
	KHT_TACTICIAN = "戰術大師";
	KHT_CONC_BARRAGE = "震盪狙擊";
	KHT_AIMED_SHOT = "瞄準射擊";

	--Trinkets
	KHT_DEVILSAUR = "魔暴龍之怒";
	KHT_ZHM = "充沛之力";
	KHT_EARTHSTRIKE = "大地之擊";
	KHT_SWARMGUARD = "蟲群守衛徽章";
	KHT_JOM_GABBAR = "姜姆·蓋伯";
	KHT_KISS_SPIDER = "蜘蛛之吻";
	KHT_FEROCITY = "兇暴";					-- Bladefist's Breath and Ancient Draenei War Talisman
	KHT_BURNING_HATRED = "燃燒憎恨";		-- Uniting Charm and Ogre Mauler's Badge
	KHT_ANCIENT_POWER = "上古能量";		-- Core of Ar'kelos
	KHT_NIGHTSEYE = "夜眼石獵豹";			-- Nightseye Panther
	KHT_UNRAVELLER = "破壞者之怒";		-- Hourglass of the Unraveller
	KHT_LUST = "戰鬥慾望";				-- Bloodlust Brooch
	KHT_HASTE = "加速";					-- Abacus of the Violent Odds
--	KHT_HEROISM = "Heroism";					-- Terrokar Tablet of Precision
--	KHT_TSUNAMI = "Fury of the Crashing Waves";	-- Tsunami Talisman
--	KHT_ASHTONGUE = "Deadly Aim";				-- Ashtongue Talisman of Swiftness
--	KHT_WRATH = "Aura of Wrath";				-- Darkmoon Card: Wrath
--	KHT_DELUSIONAL = "Delusional";			-- Darkmoon Card: Madness
--	KHT_KLEPTOMANIA = "Kleptomania";			-- Darkmoon Card: Madness
--	KHT_MANIC = "Manic";					-- Darkmoon Card: Madness
--	KHT_MARTYR = "Martyr Complex";			-- Darkmoon Card: Madness
--	KHT_NARCISSISM = "Narcissism";			-- Darkmoon Card: Madness
--	KHT_PARANOIA = "Paranoia";				-- Darkmoon Card: Madness
--	KHT_TALON = "Shot Power";				-- Talon of Al'ar
--	KHT_SKYGUARD = "Combat Valor";			-- Skyguard Silver Cross
--	KHT_MADNESS = "Forceful Strike";			-- Madness of the Betrayer
--	KHT_BERSERKER = "Call of the Berserker";	-- Berserker's Call

	--pet abilities
	KHT_PET_INTIM = "脅迫";
	KHT_INTIM = "脅迫";
	KHT_BW = "狂野怒火";
	KHT_FEED_PET = "餵養寵物";
--	KHT_MEND_PET = "Mend Pet";
--	KHT_PET_FRENZY = "Frenzy";
--	KHT_KILL_COMMAND = "Kill Command";
	KHT_SCREECH = "尖嘯";
	
	--traps
	KHT_TRAP = "陷阱";
	KHT_FROST_TRAP = "冰霜陷阱";
	KHT_EXPL_TRAP = "爆炸陷阱";
	KHT_IMMO_TRAP = "獻祭陷阱";
	KHT_FREEZING_TRAP = "冰凍陷阱";
	KHT_SNAKE_TRAP = "毒蛇陷阱";
--	KHT_VENOMOUS = "Venomous Snake";
	KHT_ENTRAPMENT = "誘捕";
	KHT_AURA = "光環";
	KHT_PRIMED = "效果";

	--Melee abilities
	KHT_WING_CLIP = "摔絆";
	KHT_IMP_WC = "強化摔絆";
	KHT_IMP_WC_SHORT = "強化摔絆";
	KHT_COUNTER = "反擊";
	KHT_DETERRENCE = "威懾";

	--Stings
	KHT_STING = "釘刺";
	KHT_WYVERN = "翼龍釘刺";
	KHT_WYVERN_TEXT = "翼龍釘刺(沉睡)";
	KHT_SERPENT = "毒蛇釘刺";
	KHT_VIPER = "蝮蛇釘刺";
	KHT_SCORPID = "毒蠍釘刺";

	--other
	KHT_FLARE = "照明彈";
	KHT_FEAR_BEAST = "恐嚇野獸";
	KHT_DONE = "完成!";
	KHT_FEIGN_DEATH = "假死";

	--enemies
	KHT_FRENZY = "BOSS狂暴提示";
	KHT_FRENZY_EMOTE = "變得極為狂暴!";
	KHT_FRENZY_FLAMEGOR = "變得極為狂暴";
	KHT_CHROMAGGUS = "克洛瑪古斯";
	KHT_FLAMEGOR = "弗萊格爾";
	KHT_MAGMADAR = "瑪格曼達";
	KHT_HUHURAN = "哈霍蘭公主";
	KHT_GLUTH = "古魯斯";
	
	--status text---------------------------------------
	KHT_ON = "on";
	KHT_OFF = "off";
	--Slash text
	KHT_SLASH_HELP = {
		[1] = "Kharthus's Hunter Timers "..KHT_VERSION,
		[2] = "命令: /kht",
		[3] = "/kht "..KHT_ON.."/"..KHT_OFF,
		[4] = "/kht menu (顯示設置目錄)命令: ",
		[5] = "/kht reset (重設計時條位置)",
		[6] = "/kht resetpos (重設計時條框位置)",
		[7] = "/kht delay <time> (time單位為微秒)",
		[8] =  "/kht flash <timeleft> (倒計時在<timeleft>秒時閃爍計時條, 0 為關閉)",
		[9] =  "/kht step <step> (<step>為閃爍頻率)",
		[10] = "/kht barcolor r g b (設定計時條顏色. r, g, b 取值範圍: 0 - 1)",
		[11] = "/kht barendcolor r g b (設定計時末尾顏色. r, g, b 取值範圍: 0 - 1)",
		[12] = "/kht setbgcolor r g b a (設定背景顏色. r, g, b, a 取值範圍: 0 - 10)",
		[13] = "/kht colorchange on/off (開/關自動變換顏色)",
		[14] = "/kht up/down (向上/下移動計時條)",
		[15] = "/kht scale % (縮放比例. /kht scale 100 = 100% 比例)",
		[16] = "/kht lock/unlock (鎖定/解鎖計時條位置)",
		[17] = "/kht status",
		[18] = "/kht clear all (resets all options to defaults)",
		[19] = "/kht debug (debug info for testing purposes)"
	};
	KHT_STATUS_STRINGS = {
		[1] = "|cFFFFFF00Kharthus's Hunter Timers "..KHT_VERSION.."|r",
		[2] = "|cFFFFFF00狀態:|r %s",
		[3] = "|cFFFFFF00射擊延時:|r %dms",
		[4] = "|cFFFFFF00閃爍時間:|r %ds |cFFFFFF00頻率:|r %f",
		[5] = "|cFFFFFF00計時條顏色:|r %s |cFFFFFF00計時末尾顏色:|r %s",
		[6] = "|cFFFFFF00顏色變換:|r %s |cFFFFFF00增長:|r %s",
		[7] = "|cFFFFFF00縮放比例:|r %d%%"
	};

	KHT_OPTIONS_COLOR_CHANGE = "自動變換顏色";
	KHT_OPTIONS_MILI = "ms";
	KHT_OPTIONS_LOCK = "鎖定計時條";
	KHT_OPTIONS_BAR_DIST = "計時條間隔";
	KHT_OPTIONS_SCALE = "縮放比例";
	KHT_OPTIONS_FLASH = "閃爍時間";
	KHT_OPTIONS_STEP = "閃爍頻率";
	KHT_OPTIONS_BARSTART = "計時起始顏色";
	KHT_OPTIONS_BAREND = "計時結尾顏色";
	KHT_OPTIONS_BACKDROP = "背景顏色";
	KHT_OPTIONS_TIMER_TEXT = "計時器";
	KHT_OPTIONS_BARS_TEXT = "計時條";
	KHT_OPTIONS_DECIMALS = "小數位";
	KHT_OPTIONS_SHOT_DELAY = "射擊延時";
	KHT_OPTIONS_SHOW_TEX = "顯示圖示";
	KHT_OPTIONS_LARGE_TEX = "大圖示";
	KHT_OPTIONS_APPEND = "顯示作用目標";
	KHT_OPTIONS_BORDER = "邊框顏色";
	KHT_OPTIONS_TEXT_COLOR = "文本顏色";
	KHT_OPTIONS_TIME_COLOR = "時間顏色";
	KHT_OPTIONS_TARGET_COLOR = "目標文字顏色";
	KHT_OPTIONS_OVERALL_OPACITY = "透明度";
	KHT_OPTIONS_HIDE_TEXT = "隱藏文字";
	KHT_OPTIONS_HIDE_TIME = "隱藏時間";
	KHT_OPTIONS_HIDE_GAP = "隱藏間隙";
	KHT_OPTIONS_BAR_THICKNESS = "計時條粗細";
	KHT_OPTIONS_HIDE_PADDING = "隱藏內邊框";
	KHT_OPTIONS_STICKY = "依附自動射擊";

	--Options moved to globals because they dealt with other variables

end
