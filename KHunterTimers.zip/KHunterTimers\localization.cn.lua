if( GetLocale() == "zhCN" ) then
	--abilities-----------------------------------------
	--shots
	KHT_CONC_SHOT = "震荡射击";
	KHT_IMP_CONC = "强化震荡射击";
	KHT_IMP_CONC_SHORT = "强化震荡射击";
	KHT_SCATTER = "驱散射击";
	KHT_AUTO_SHOT = "自动射击";
--	KHT_SILENCE_SHOT = "Silencing Shot";

	--buffs
	KHT_HUNTERS_MARK = "猎人印记";
	KHT_RAPID_FIRE = "急速射击";
--	KHT_MISDIRECTION = "Misdirection";

	--Racials
	KHT_BERSERKING = "狂暴";
	KHT_BLOOD_FURY = "血性狂暴";
	KHT_STONEFORM = "石像形态";
	KHT_WAR_STOMP = "战争践踏";
--	KHT_ARCANE = "Arcane Torrent";

	--Set/Item Procs
	KHT_EXPOSE_WEAKNESS = "破甲虚弱";
	KHT_PRIMAL_BLESSING = "远古神灵的祝福";
--	KHT_SANTOS = "Santos' Blessing";			-- Don Santos' Famous Hunting Rifle
--	KHT_HEROIC = "Heroic Resolution";			-- Desolation 4-piece bonus
--	KHT_SKYFIRE = "Skyfire Swiftness";			-- Thundering Skyfire Diamond
--	KHT_BEASTLORD = "Exploited Weakness";		-- Beast Lord 4-piece bonus
--	KHT_CHAMPION = "Band of the Eternal Champion";	-- Band of the Eternal Champion
	
	--Talent Procs
	KHT_QUICK_SHOTS = "快速射击";
--	KHT_FEROCIOUS = "Ferocious Inspiration";
--	KHT_RAPID_KILLING = "Rapid Killing";
--	KHT_TACTICIAN = "Master Tactician";
--	KHT_CONC_BARRAGE = "Concussive Barrage";
	KHT_AIMED_SHOT = "瞄准射击";
	
	--Trinkets
	KHT_DEVILSAUR = "魔暴龙之怒";
	KHT_ZHM = "充沛之力";
	KHT_EARTHSTRIKE = "大地之击";
	KHT_SWARMGUARD = "虫群卫士徽�";
	KHT_JOM_GABBAR = "沙虫之毒";
	KHT_KISS_SPIDER = "蜘蛛之吻";
--	KHT_FEROCITY = "Ferocity";				-- Bladefist's Breath and Ancient Draenei War Talisman
--	KHT_BURNING_HATRED = "Burning Hatred";		-- Uniting Charm and Ogre Mauler's Badge
--	KHT_ANCIENT_POWER = "Ancient Power";		-- Core of Ar'kelos
--	KHT_NIGHTSEYE = "Nightseye Panther";		-- Nightseye Panther
--	KHT_UNRAVELLER = "Rage of the Unraveller";	-- Hourglass of the Unraveller
--	KHT_LUST = "Lust for Battle";				-- Bloodlust Brooch
--	KHT_HASTE = "Haste";					-- Abacus of the Violent Odds
--	KHT_HEROISM = "Heroism";					-- Terrokar Tablet of Precision
--	KHT_TSUNAMI = "Fury of the Crashing Waves";	-- Tsunami Talisman
--	KHT_ASHTONGUE = "Deadly Aim";				-- Ashtongue Talisman of Swiftness
--	KHT_WRATH = "Aura of Wrath";				-- Darkmoon Card: Wrath
--	KHT_DELUSIONAL = "Delusional";			-- Darkmoon Card: Madness
--	KHT_KLEPTOMANIA = "Kleptomania";			-- Darkmoon Card: Madness
--	KHT_MANIC = "Manic";					-- Darkmoon Card: Madness
--	KHT_MARTYR = "Martyr Complex";			-- Darkmoon Card: Madness
--	KHT_NARCISSISM = "Narcissism";			-- Darkmoon Card: Madness
--	KHT_PARANOIA = "Paranoia";				-- Darkmoon Card: Madness
--	KHT_TALON = "Shot Power";				-- Talon of Al'ar
--	KHT_SKYGUARD = "Combat Valor";			-- Skyguard Silver Cross
--	KHT_MADNESS = "Forceful Strike";			-- Madness of the Betrayer
--	KHT_BERSERKER = "Call of the Berserker";	-- Berserker's Call

	--pet abilities
	KHT_PET_INTIM = "胁迫";
	KHT_INTIM = "胁迫";
	KHT_BW = "狂野怒火";
	KHT_FEED_PET = "喂养宠物";
--	KHT_MEND_PET = "Mend Pet";
--	KHT_PET_FRENZY = "Frenzy";
--	KHT_KILL_COMMAND = "Kill Command";
	KHT_SCREECH = "尖啸";
	
	--traps
	KHT_TRAP = "陷阱";
	KHT_FROST_TRAP = "冰霜陷阱";
	KHT_EXPL_TRAP = "爆炸陷阱";
	KHT_IMMO_TRAP = "献祭陷阱";
	KHT_FREEZING_TRAP = "冰冻陷阱";
--	KHT_SNAKE_TRAP = "Snake Trap";
--	KHT_VENOMOUS = "Venomous Snake";
	KHT_ENTRAPMENT = "诱捕";
	KHT_AURA = "光环";
	KHT_PRIMED = "效果";

	--Melee abilities
	KHT_WING_CLIP = "摔绊";
	KHT_IMP_WC = "强化摔绊";
	KHT_IMP_WC_SHORT = "强化摔绊";
	KHT_COUNTER = "反击";
	KHT_DETERRENCE = "威慑";

	--Stings
	KHT_STING = "钉刺";
	KHT_WYVERN = "翼龙钉刺";
	KHT_WYVERN_TEXT = "翼龙钉刺(沉睡)";
	KHT_SERPENT = "毒蛇钉刺";
	KHT_VIPER = "蝰蛇钉刺";
	KHT_SCORPID = "毒蝎钉刺";

	--other
	KHT_FLARE = "照明弹";
	KHT_FEAR_BEAST = "恐吓野兽";
	KHT_DONE = "完成";
	KHT_FEIGN_DEATH = "假死";

	--enemies
	KHT_FRENZY = "BOSS狂暴提示";
	KHT_FRENZY_EMOTE = "变得极为狂暴";
	KHT_FRENZY_FLAMEGOR = "变得极为狂暴";
	KHT_CHROMAGGUS = "克洛玛古斯";
	KHT_FLAMEGOR = "弗莱格尔";
	KHT_MAGMADAR = "玛格曼达";
	KHT_HUHURAN = "哈霍兰公主";
	KHT_GLUTH = "格拉斯";

	--status text---------------------------------------
	KHT_ON = "on";
	KHT_OFF = "off";
	--Slash text
	KHT_SLASH_HELP = {
		[1] = "Kharthus's Hunter Timers "..KHT_VERSION,
		[2] = "命令: /kht",
		[3] = "/kht "..KHT_ON.."/"..KHT_OFF,
		[4] = "/kht menu (显示配置菜单)命令: ",
		[5] = "/kht reset (重设计时条位置)",
		[6] = "/kht resetpos (重设计时条框位置)",
		[7] = "/kht delay <time> (time单位为微秒)",
		[8] = "/kht flash <timeleft> (倒计时在<timeleft>秒时闪烁计时条, 0 为关闭)",
		[9] = "/kht step <step> (<step>为闪烁频率)",
		[10] = "/kht barcolor r g b (设定计时条颜色. r, g, b 取值范围: 0 - 1)",
		[11] = "/kht barendcolor r g b (设定计时末尾颜色. r, g, b 取值范围: 0 - 1)",
		[12] = "/kht setbgcolor r g b a (设定背景颜色. r, g, b, a 取值范围: 0 - 10)",
		[13] = "/kht colorchange on/off (开/关自动变换颜色)",
		[14] = "/kht up/down (向上/下移动计时条)",
		[15] = "/kht scale % (缩放比例. /kht scale 100 = 100% 比例)",
		[16] = "/kht lock/unlock (锁定/解锁计时条位置)",
		[17] = "/kht status",
		[18] = "/kht clear all (resets all options to defaults)",
		[19] = "/kht debug (debug info for testing purposes)"
	};
	KHT_STATUS_STRINGS = {
		[1] = "|cFFFFFF00Kharthus's Hunter Timers "..KHT_VERSION.."|r",
		[2] = "|cFFFFFF00状态:|r %s",
		[3] = "|cFFFFFF00射击延时:|r %dms",
		[4] = "|cFFFFFF00闪烁时间:|r %ds |cFFFFFF00频率:|r %f",
		[5] = "|cFFFFFF00计时条颜色:|r %s |cFFFFFF00计时末尾颜色:|r %s",
		[6] = "|cFFFFFF00颜色变换:|r %s |cFFFFFF00增长:|r %s",
		[7] = "|cFFFFFF00缩放比例:|r %d%%"
	};

	KHT_OPTIONS_COLOR_CHANGE = "自动变换颜色";
	KHT_OPTIONS_MILI = "ms";
	KHT_OPTIONS_LOCK = "锁定计时条";
	KHT_OPTIONS_BAR_DIST = "计时条间隔";
	KHT_OPTIONS_SCALE = "缩放比例";
	KHT_OPTIONS_FLASH = "闪烁时间";
	KHT_OPTIONS_STEP = "闪烁频率";
	KHT_OPTIONS_BARSTART = "计时起始颜色";
	KHT_OPTIONS_BAREND = "计时结尾颜色";
	KHT_OPTIONS_BACKDROP = "背景颜色";
	KHT_OPTIONS_TIMERS_TEXT = "计时器";
	KHT_OPTIONS_BARS_TEXT = "计时条";
	KHT_OPTIONS_DECIMALS = "小数位";
	KHT_OPTIONS_SHOT_DELAY = "射击延时";
	KHT_OPTIONS_SHOW_TEX = "显示图标";
	KHT_OPTIONS_LARGE_TEX = "大图标";
	KHT_OPTIONS_APPEND = "显示作用目标";
	KHT_OPTIONS_BORDER = "边框颜色";
	KHT_OPTIONS_TEXT_COLOR = "文本颜色";
	KHT_OPTIONS_TIME_COLOR = "时间颜色";
	KHT_OPTIONS_TARGET_COLOR = "目标文本颜色";
	KHT_OPTIONS_OVERALL_OPACITY = "透明度";
	KHT_OPTIONS_HIDE_TEXT = "隐藏文本";
	KHT_OPTIONS_HIDE_TIME = "隐藏时间";
	KHT_OPTIONS_HIDE_GAP = "隐藏间隙";
	KHT_OPTIONS_BAR_THICKNESS = "计时条粗细";
	KHT_OPTIONS_HIDE_PADDING = "隐藏内边框";
	KHT_OPTIONS_STICKY = "自动射击";

	--Options moved to globals because they dealt with other variables

end
