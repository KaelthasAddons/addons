if( GetLocale() == "frFR" ) then
	--abilities-----------------------------------------
	--shots
	KHT_CONC_SHOT = "Trait de choc";
	KHT_IMP_CONC = "Trait de choc am\195\169lior\195\169";
	KHT_IMP_CONC_SHORT = "Trait de choc am\195\169lior\195\169";
	KHT_SCATTER = "Fl\195\168che de dispersion";
	KHT_AUTO_SHOT = "Tir automatique";
	KHT_SILENCE_SHOT = "Fl\195\168che-ba\195\174llon";

	--buffs
	KHT_HUNTERS_MARK = "Marque du chasseur";
	KHT_RAPID_FIRE = "Tir rapide";
	KHT_MISDIRECTION = "D\195\169tournement";

	--Racials
	KHT_BERSERKING = "Berserker";
	KHT_BLOOD_FURY = "Fureur sanguinaire";
	KHT_STONEFORM = "Forme de pierre";
	KHT_WAR_STOMP = "Choc martial";
	KHT_ARCANE = "Torrent arcanique";

	--Set/Item Procs
	KHT_EXPOSE_WEAKNESS = "Perce-faille";
	KHT_PRIMAL_BLESSING = "B\195\169n\195\169diction primordiale";
	KHT_SANTOS = "B\195\169n\195\169diction de Santos";		-- Don Santos' Famous Hunting Rifle
	KHT_HEROIC = "R\195\169solution h\195\169ro\195\175que";	-- Desolation 4-piece bonus
	KHT_SKYFIRE = "Rapidit\195\169 Br\195\187le-ciel";		-- Thundering Skyfire Diamond
	KHT_BEASTLORD = "Faiblesse exploit\195\169e";			-- Beast Lord 4-piece bonus
	KHT_CHAMPION = "Bague du champion \195\169ternel";		-- Band of the Eternal Champion

	--Talent Procs
	KHT_QUICK_SHOTS = "Tirs acc\195\169l\195\169r\195\169s";
	KHT_FEROCIOUS = "Inspiration f\195\169roce";
	KHT_RAPID_KILLING = "Tueur rapide";
	KHT_TACTICIAN = "Ma\195\174tre tacticien";
	KHT_CONC_BARRAGE = "Barrage commotionnant";
	KHT_AIMED_SHOT = "Vis\195\169e";

	--Trinkets
	KHT_DEVILSAUR = "Fureur du diablosaure";
	KHT_ZHM = "Force inconstante";
	KHT_EARTHSTRIKE = "Choc de terre";
	KHT_SWARMGUARD = "Insigne de garde-essaim";
	KHT_JOM_GABBAR = "Jom Gabbar";
	KHT_KISS_SPIDER = "Baiser de l'araign\195\169e";
	KHT_FEROCITY = "F\195\169rocit\195\169";
	KHT_BURNING_HATRED = "Haine ardente";
	KHT_ANCIENT_POWER = "Puissance ancienne";		-- Core of Ar'kelos
	KHT_NIGHTSEYE = "Panth\195\168re d'oeil de nuit";	-- Nightseye Panther
	KHT_UNRAVELLER = "Rage du d\195\169trameur";		-- Hourglass of the Unraveller
	KHT_LUST = "Soif de bataille";				-- Bloodlust Brooch
	KHT_HASTE = "H\195\162te";					-- Abacus of the Violent Odds
	KHT_HEROISM = "H\195\169ro\195\175sme";			-- Terrokar Tablet of Precision
	KHT_TSUNAMI = "Fureur des d\195\169ferlantes";	-- Tsunami Talisman
	KHT_ASHTONGUE = "Vis\195\169e mortelle";		-- Ashtongue Talisman of Swiftness
	KHT_WRATH = "Aura de courroux";				-- Darkmoon Card: Wrath
	KHT_DELUSIONAL = "D\195\169lirant";			-- Darkmoon Card: Madness
	KHT_KLEPTOMANIA = "Kleptomanie";				-- Darkmoon Card: Madness
	KHT_MANIC = "Maniaque";						-- Darkmoon Card: Madness
	KHT_MARTYR = "Complexe du martyr";				-- Darkmoon Card: Madness
	KHT_NARCISSISM = "Narcissisme";				-- Darkmoon Card: Madness
	KHT_PARANOIA = "Parano\195\175a";				-- Darkmoon Card: Madness
	KHT_TALON = "Puissance de tir";				-- Talon of Al'ar
	KHT_SKYGUARD = "Vaillance au combat";			-- Skyguard Silver Cross
	KHT_MADNESS = "Frappe \195\169nergique";		-- Madness of the Betrayer
	KHT_BERSERKER = "Appel du berserker";			-- Berserker's Call

	--pet abilities
	KHT_PET_INTIM = "Pet Intimidation";
	KHT_INTIM = "Intimidation";
	KHT_BW = "Courroux bestial";
	KHT_FEED_PET = "Nourrir le familier";
	KHT_MEND_PET = "Gu\195\169rison du familier";
	KHT_PET_FRENZY = "fr\195\169n\195\169sie";
	KHT_KILL_COMMAND = "Ordre de tuer";
	KHT_SCREECH = "Hurlement";

	--traps
	KHT_TRAP = "Pi\195\168ge";
	KHT_FROST_TRAP = "Pi\195\168ge de givre";
	KHT_EXPL_TRAP = "Pi\195\168ge explosif";
	KHT_IMMO_TRAP = "Pi\195\168ge d'immolation";
	KHT_FREEZING_TRAP = "Pi\195\168ge givrant";
	KHT_SNAKE_TRAP = "Pi\195\168ge \195\160 serpent";
	KHT_VENOMOUS = "Serpent venimeux";
	KHT_ENTRAPMENT = "Pi\195\168ge";
	KHT_AURA = "aura";
	KHT_PRIMED = "pos\195\169";
	
	--Melee abilities
	KHT_WING_CLIP = "Coupure d'ailes";
	KHT_IMP_WC = "Coupure d'ailes am\195\169lior\195\169e";
	KHT_IMP_WC_SHORT = "Imp. Wing Clip";
	KHT_COUNTER = "Contre-attaque";
	KHT_DETERRENCE = "Dissuasion";
	
	--Stings
	KHT_STING = "Morsure|Piq\195\187re";
	KHT_WYVERN = "Piq\195\187re de wyverne";
	KHT_WYVERN_TEXT = "Wyvern Sting (Sleep)";
	KHT_SERPENT = "Morsure de serpent";
	KHT_VIPER = "Morsure de vip\195\168re";
	KHT_SCORPID = "Piq\195\187re de scorpide";
	
	--other
	KHT_FLARE = "Fus\195\169e \195\169clairante";
	KHT_FEAR_BEAST = "Effrayer une b\195\170te";
	KHT_DONE = "Fini!";
	KHT_FEIGN_DEATH = "Feindre la mort";
	
	--enemies
	KHT_FRENZY = "fr\195\169n\195\169sie";
	KHT_FRENZY_EMOTE = "rentre en fr\195\169n\195\169sie sanglante!";
	KHT_FRENZY_FLAMEGOR = "rentre en fr\195\169n\195\169sie!";
	KHT_CHROMAGGUS = "Chromaggus";
	KHT_FLAMEGOR = "Flamegor";
	KHT_MAGMADAR = "Magmadar";
	KHT_HUHURAN = "Princesse Huhuran";
	KHT_GLUTH = "Gluth";
	
	--status text---------------------------------------
	KHT_ON = "on";
	KHT_OFF = "off";
	--Slash text
	KHT_SLASH_HELP = {
		[1] = "Kharthus's Hunter Timers "..KHT_VERSION,
		[2] = "Commands: /kht",
		[3] = "/kht "..KHT_ON.."/"..KHT_OFF,
		[4] = "/kht menu (bring up the gui menu)",
		[5] = "/kht reset (resets all the visible bars)",
		[6] = "/kht resetpos (resets the bar frame position)",
		[7] = "/kht delay <time> (time is in milliseconds)",
		[8] =  "/kht flash <timeleft> (timeleft in seconds to flash the bar, 0 for off)",
		[9] =  "/kht step <step> (higher step means faster flashing when time is low)",
		[10] = "/kht barcolor r g b (where r, g, b are between 0 and 1)",
		[11] = "/kht barendcolor r g b (where r, g, b are between 0 and 1)",
		[12] = "/kht setbgcolor r g b a (where r, g, b, a are between 0 and 10)",
		[13] = "/kht colorchange "..KHT_ON.."/"..KHT_OFF.." (color change feature)",
		[14] = "/kht up/down (cascade bars up or down)",
		[15] = "/kht scale % (/kht scale 100 = 100% scale)",
		[16] = "/kht lock/unlock (lock or unlock the frame)",
		[17] = "/kht status",
		[18] = "/kht clear all (resets all options to defaults)",
		[19] = "/kht debug (debug info for testing purposes)"
	};
	KHT_STATUS_STRINGS = {
		[1] = "|cFFFFFF00Kharthus's Hunter Timers "..KHT_VERSION.."|r",
		[2] = "|cFFFFFF00Status:|r %s",
		[3] = "|cFFFFFF00Shot delay:|r %dms", 
		[4] = "|cFFFFFF00Flash time:|r %ds |cFFFFFF00Step:|r %f",
		[5] = "|cFFFFFF00Barcolor:|r %s |cFFFFFF00Barcolorend:|r %s",
		[6] = "|cFFFFFF00Colorchange:|r %s |cFFFFFF00Growth:|r %s",
		[7] = "|cFFFFFF00Scale:|r %d%%"
	};
	
	KHT_OPTIONS_COLOR_CHANGE = "Color Change";
	KHT_OPTIONS_MILI = "ms";
	KHT_OPTIONS_LOCK = "Lock";
	KHT_OPTIONS_BAR_DIST = "Distance Between Bars";
	KHT_OPTIONS_SCALE = "Scale";
	KHT_OPTIONS_FLASH = "Flash Time";
	KHT_OPTIONS_STEP = "Flash Step";
	KHT_OPTIONS_BARSTART = "Bar Start Color";
	KHT_OPTIONS_BAREND = "Bar End Color";
	KHT_OPTIONS_BACKDROP = "Backdrop Color";
	KHT_OPTIONS_TIMERS_TEXT = "Timers";
	KHT_OPTIONS_BARS_TEXT = "Bars";
	KHT_OPTIONS_DECIMALS = "Decimals";
	KHT_OPTIONS_SHOT_DELAY = "Shot Delay";
	KHT_OPTIONS_SHOW_TEX = "Show Textures";
	KHT_OPTIONS_LARGE_TEX = "Large Textures";
	KHT_OPTIONS_APPEND = "Append Target";
	KHT_OPTIONS_BORDER = "Border Color";
	KHT_OPTIONS_TEXT_COLOR = "Text Color";
	KHT_OPTIONS_TIME_COLOR = "Time Color";
	KHT_OPTIONS_TARGET_COLOR = "Target Text Color";
	KHT_OPTIONS_OVERALL_OPACITY = "Overall Opacity";
	KHT_OPTIONS_HIDE_TEXT = "Hide Text";
	KHT_OPTIONS_HIDE_TIME = "Hide Time";
	KHT_OPTIONS_HIDE_GAP = "Hide Gap";
	KHT_OPTIONS_BAR_THICKNESS = "Bar Thickness";
	KHT_OPTIONS_HIDE_PADDING = "Hide Padding";
	KHT_OPTIONS_STICKY = "Sticky Auto Shot";
	
	--Options moved to globals because they dealt with other variables
		
end
	
