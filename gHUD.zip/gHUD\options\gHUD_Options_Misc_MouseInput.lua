function gHUDLoadInput()
	if (Options.frame.input==1) then
		MouseInputCB:SetChecked(true)
	elseif (Options.frame.input==0) then
		MouseInputCB:SetChecked(false)
	end
end
	
function gHUDInputOnLoad()
	if (Options.frame.input==1) then
	
		HP_PLAYER_FRAME:EnableMouse(true)
		HP_Player_Button:EnableMouse(true)
		MP_PLAYER_FRAME:EnableMouse(true)
		MP_Player_Button:EnableMouse(true)
		
		HP_TARGET_FRAME:EnableMouse(true)
		HP_Target_Button:EnableMouse(true)
		MP_TARGET_FRAME:EnableMouse(true)
		MP_Target_Button:EnableMouse(true)
		
		--need update solution because this is OnUpdate
		HP_TARGETTARGET_FRAME:EnableMouse(true)
		HP_TargetTarget_Button:EnableMouse(true)
		MP_TARGETTARGET_FRAME:EnableMouse(true)
		MP_TargetTarget_Button:EnableMouse(true)
					
		HP_PET_FRAME:EnableMouse(true)
		HP_Pet_Button:EnableMouse(true)
		MP_PET_FRAME:EnableMouse(true)
		MP_Pet_Button:EnableMouse(true)
		
		HP_PARTY1_FRAME:EnableMouse(true)
		HP_Party1_Button:EnableMouse(true)
		MP_PARTY1_FRAME:EnableMouse(true)
		MP_Party1_Button:EnableMouse(true)
		
		HP_PARTY2_FRAME:EnableMouse(true)
		HP_Party2_Button:EnableMouse(true)
		MP_PARTY2_FRAME:EnableMouse(true)
		MP_Party2_Button:EnableMouse(true)
		
		HP_PARTY3_FRAME:EnableMouse(true)
		HP_Party3_Button:EnableMouse(true)
		MP_PARTY3_FRAME:EnableMouse(true)
		MP_Party3_Button:EnableMouse(true)
		
		HP_PARTY4_FRAME:EnableMouse(true)
		HP_Party4_Button:EnableMouse(true)
		MP_PARTY4_FRAME:EnableMouse(true)
		MP_Party4_Button:EnableMouse(true)
		
		HP_PARTYPET1_FRAME:EnableMouse(true)
		HP_PartyPet1_Button:EnableMouse(true)
		MP_PARTYPET1_FRAME:EnableMouse(true)
		MP_PartyPet1_Button:EnableMouse(true)
		
		HP_PARTYPET2_FRAME:EnableMouse(true)
		HP_PartyPet2_Button:EnableMouse(true)
		MP_PARTYPET2_FRAME:EnableMouse(true)
		MP_PartyPet2_Button:EnableMouse(true)
		
		HP_PARTYPET2_FRAME:EnableMouse(true)
		HP_PartyPet2_Button:EnableMouse(true)
		MP_PARTYPET2_FRAME:EnableMouse(true)
		MP_PartyPet2_Button:EnableMouse(true)
		
		HP_PARTYPET2_FRAME:EnableMouse(true)
		HP_PartyPet2_Button:EnableMouse(true)
		MP_PARTYPET2_FRAME:EnableMouse(true)
		MP_PartyPet2_Button:EnableMouse(true)
		
	elseif (Options.frame.input==0) then
	
		HP_PLAYER_FRAME:EnableMouse(false)
		HP_Player_Button:EnableMouse(false)
		MP_PLAYER_FRAME:EnableMouse(false)
		MP_Player_Button:EnableMouse(false)
		
		HP_TARGET_FRAME:EnableMouse(false)
		HP_Target_Button:EnableMouse(false)
		MP_TARGET_FRAME:EnableMouse(false)
		MP_Target_Button:EnableMouse(false)
		
		--need update solution because this is OnUpdate
		HP_TARGETTARGET_FRAME:EnableMouse(false)
		HP_TargetTarget_Button:EnableMouse(false)
		MP_TARGETTARGET_FRAME:EnableMouse(false)
		MP_TargetTarget_Button:EnableMouse(false)
		
		HP_PET_FRAME:EnableMouse(false)
		HP_Pet_Button:EnableMouse(false)
		MP_PET_FRAME:EnableMouse(false)
		MP_Pet_Button:EnableMouse(false)
		
		HP_PARTY1_FRAME:EnableMouse(false)
		HP_Party1_Button:EnableMouse(false)
		MP_PARTY1_FRAME:EnableMouse(false)
		MP_Party1_Button:EnableMouse(false)
		
		HP_PARTY2_FRAME:EnableMouse(false)
		HP_Party2_Button:EnableMouse(false)
		MP_PARTY2_FRAME:EnableMouse(false)
		MP_Party2_Button:EnableMouse(false)
		
		HP_PARTY3_FRAME:EnableMouse(false)
		HP_Party3_Button:EnableMouse(false)
		MP_PARTY3_FRAME:EnableMouse(false)
		MP_Party3_Button:EnableMouse(false)
		
		HP_PARTY4_FRAME:EnableMouse(false)
		HP_Party4_Button:EnableMouse(false)
		MP_PARTY4_FRAME:EnableMouse(false)
		MP_Party4_Button:EnableMouse(false)
		
		HP_PARTYPET1_FRAME:EnableMouse(false)
		HP_PartyPet1_Button:EnableMouse(false)
		MP_PARTYPET1_FRAME:EnableMouse(false)
		MP_PartyPet1_Button:EnableMouse(false)
		
		HP_PARTYPET2_FRAME:EnableMouse(false)
		HP_PartyPet2_Button:EnableMouse(false)
		MP_PARTYPET2_FRAME:EnableMouse(false)
		MP_PartyPet2_Button:EnableMouse(false)
		
		HP_PARTYPET2_FRAME:EnableMouse(false)
		HP_PartyPet2_Button:EnableMouse(false)
		MP_PARTYPET2_FRAME:EnableMouse(false)
		MP_PartyPet2_Button:EnableMouse(false)
		
		HP_PARTYPET2_FRAME:EnableMouse(false)
		HP_PartyPet2_Button:EnableMouse(false)
		MP_PARTYPET2_FRAME:EnableMouse(false)
		MP_PartyPet2_Button:EnableMouse(false)
	end
end	
function gHUDInputOnClick()
	if (Options.frame.input==0) then
		Options.frame.input=1
		HP_PLAYER_FRAME:EnableMouse(true)
		HP_Player_Button:EnableMouse(true)
		MP_PLAYER_FRAME:EnableMouse(true)
		MP_Player_Button:EnableMouse(true)
		
		HP_TARGET_FRAME:EnableMouse(true)
		HP_Target_Button:EnableMouse(true)
		MP_TARGET_FRAME:EnableMouse(true)
		MP_Target_Button:EnableMouse(true)
		
		--need update solution because this is OnUpdate
		HP_TARGETTARGET_FRAME:EnableMouse(true)
		HP_TargetTarget_Button:EnableMouse(true)
		MP_TARGETTARGET_FRAME:EnableMouse(true)
		MP_TargetTarget_Button:EnableMouse(true)
					
		HP_PET_FRAME:EnableMouse(true)
		HP_Pet_Button:EnableMouse(true)
		MP_PET_FRAME:EnableMouse(true)
		MP_Pet_Button:EnableMouse(true)
		
		HP_PARTY1_FRAME:EnableMouse(true)
		HP_Party1_Button:EnableMouse(true)
		MP_PARTY1_FRAME:EnableMouse(true)
		MP_Party1_Button:EnableMouse(true)
		
		HP_PARTY2_FRAME:EnableMouse(true)
		HP_Party2_Button:EnableMouse(true)
		MP_PARTY2_FRAME:EnableMouse(true)
		MP_Party2_Button:EnableMouse(true)
		
		HP_PARTY3_FRAME:EnableMouse(true)
		HP_Party3_Button:EnableMouse(true)
		MP_PARTY3_FRAME:EnableMouse(true)
		MP_Party3_Button:EnableMouse(true)
		
		HP_PARTY4_FRAME:EnableMouse(true)
		HP_Party4_Button:EnableMouse(true)
		MP_PARTY4_FRAME:EnableMouse(true)
		MP_Party4_Button:EnableMouse(true)
		
		HP_PARTYPET1_FRAME:EnableMouse(true)
		HP_PartyPet1_Button:EnableMouse(true)
		MP_PARTYPET1_FRAME:EnableMouse(true)
		MP_PartyPet1_Button:EnableMouse(true)
		
		HP_PARTYPET2_FRAME:EnableMouse(true)
		HP_PartyPet2_Button:EnableMouse(true)
		MP_PARTYPET2_FRAME:EnableMouse(true)
		MP_PartyPet2_Button:EnableMouse(true)
		
		HP_PARTYPET2_FRAME:EnableMouse(true)
		HP_PartyPet2_Button:EnableMouse(true)
		MP_PARTYPET2_FRAME:EnableMouse(true)
		MP_PartyPet2_Button:EnableMouse(true)
		
		HP_PARTYPET2_FRAME:EnableMouse(true)
		HP_PartyPet2_Button:EnableMouse(true)
		MP_PARTYPET2_FRAME:EnableMouse(true)
		MP_PartyPet2_Button:EnableMouse(true)
	
	elseif (Options.frame.input==1) then
		Options.frame.input=0
		HP_PLAYER_FRAME:EnableMouse(false)
		HP_Player_Button:EnableMouse(false)
		MP_PLAYER_FRAME:EnableMouse(false)
		MP_Player_Button:EnableMouse(false)
		
		HP_TARGET_FRAME:EnableMouse(false)
		HP_Target_Button:EnableMouse(false)
		MP_TARGET_FRAME:EnableMouse(false)
		MP_Target_Button:EnableMouse(false)
		
		--need update solution because this is OnUpdate
		HP_TARGETTARGET_FRAME:EnableMouse(false)
		HP_TargetTarget_Button:EnableMouse(false)
		MP_TARGETTARGET_FRAME:EnableMouse(false)
		MP_TargetTarget_Button:EnableMouse(false)
		
		HP_PET_FRAME:EnableMouse(false)
		HP_Pet_Button:EnableMouse(false)
		MP_PET_FRAME:EnableMouse(false)
		MP_Pet_Button:EnableMouse(false)
		
		HP_PARTY1_FRAME:EnableMouse(false)
		HP_Party1_Button:EnableMouse(false)
		MP_PARTY1_FRAME:EnableMouse(false)
		MP_Party1_Button:EnableMouse(false)
		
		HP_PARTY2_FRAME:EnableMouse(false)
		HP_Party2_Button:EnableMouse(false)
		MP_PARTY2_FRAME:EnableMouse(false)
		MP_Party2_Button:EnableMouse(false)
		
		HP_PARTY3_FRAME:EnableMouse(false)
		HP_Party3_Button:EnableMouse(false)
		MP_PARTY3_FRAME:EnableMouse(false)
		MP_Party3_Button:EnableMouse(false)
		
		HP_PARTY4_FRAME:EnableMouse(false)
		HP_Party4_Button:EnableMouse(false)
		MP_PARTY4_FRAME:EnableMouse(false)
		MP_Party4_Button:EnableMouse(false)
		
		HP_PARTYPET1_FRAME:EnableMouse(false)
		HP_PartyPet1_Button:EnableMouse(false)
		MP_PARTYPET1_FRAME:EnableMouse(false)
		MP_PartyPet1_Button:EnableMouse(false)
		
		HP_PARTYPET2_FRAME:EnableMouse(false)
		HP_PartyPet2_Button:EnableMouse(false)
		MP_PARTYPET2_FRAME:EnableMouse(false)
		MP_PartyPet2_Button:EnableMouse(false)
		
		HP_PARTYPET2_FRAME:EnableMouse(false)
		HP_PartyPet2_Button:EnableMouse(false)
		MP_PARTYPET2_FRAME:EnableMouse(false)
		MP_PartyPet2_Button:EnableMouse(false)
		
		HP_PARTYPET2_FRAME:EnableMouse(false)
		HP_PartyPet2_Button:EnableMouse(false)
		MP_PARTYPET2_FRAME:EnableMouse(false)
		MP_PartyPet2_Button:EnableMouse(false)
	end
end