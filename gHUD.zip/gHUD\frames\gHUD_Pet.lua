function Load_HP_Pet()
	if (event=="ADDON_LOADED") and (arg1=="gHUD") and (Options~=nil) then
		if (Options.pet.frame.active==1) then
		--set position
			HP_PET_FRAME:ClearAllPoints()
			HP_PET_FRAME:SetPoint("BOTTOMRIGHT", nil, "CENTER", Options.pet.frame.position.hpx, Options.pet.frame.position.hpy)
		--texture
			HP_PET_BAR_TEXTURE:SetTexture(Options.texture.BarHeight)
		
			HP_PET_BG_TEXTURE1:SetHeight(Options.player.frame.bg.height/2)
			HP_PET_BG_TEXTURE1:SetWidth(Options.player.frame.bg.width)
			HP_PET_BG_TEXTURE2:SetHeight((Options.player.frame.bg.height/2)-2)
			HP_PET_BG_TEXTURE2:SetWidth(Options.player.frame.bg.width-2)
		
			HP_PET_BAR:SetWidth(Options.player.frame.bar.width)
			HP_PET_FRAME:SetHeight(Options.player.frame.bg.height/2)
			HP_PET_FRAME:SetWidth(Options.player.frame.bg.width)
			
			HP_Pet_Button:SetHeight(Options.player.frame.bg.height/2)
			HP_Pet_Button:SetWidth(Options.player.frame.bg.width)
		--hp pet max text
			HP_PET_MAX:SetFont(Options.font.font, Options.font.size, Options.font.flags)
			HP_PET_MAX:SetTextColor(0, 1, 0, 1)
		--hp pet percent text
			HP_PET_PERCENT:SetFont(Options.font.font, Options.font.size, Options.font.flags)
		--hp pet deficit text
			HP_PET_DEFICIT:SetFont(Options.font.font, Options.font.size, Options.font.flags)
		--hp pet name text
			HP_PET_NAME:SetFont(Options.font.font, Options.font.size, Options.font.flags)
		end
	end
end

function Load_MP_Pet()
	if (event=="ADDON_LOADED") and (arg1=="gHUD") and (Options~=nil) then
		if (Options.pet.frame.active==1) then
		--set position
			MP_PET_FRAME:ClearAllPoints()
			MP_PET_FRAME:SetPoint("BOTTOMLEFT", nil, "CENTER", Options.pet.frame.position.mpx, Options.pet.frame.position.mpy)
		--texture
			MP_PET_BAR_TEXTURE:SetTexture(Options.texture.BarHeight)
		
			MP_PET_BG_TEXTURE1:SetHeight(Options.player.frame.bg.height/2)
			MP_PET_BG_TEXTURE1:SetWidth(Options.player.frame.bg.width)
			MP_PET_BG_TEXTURE2:SetHeight((Options.player.frame.bg.height/2)-2)
			MP_PET_BG_TEXTURE2:SetWidth(Options.player.frame.bg.width-2)
		
			MP_PET_BAR:SetWidth(Options.player.frame.bar.width)
			MP_PET_FRAME:SetHeight(Options.player.frame.bg.height/2)
			MP_PET_FRAME:SetWidth(Options.player.frame.bg.width)
		
			MP_Pet_Button:SetHeight(Options.player.frame.bg.height/2)
			MP_Pet_Button:SetWidth(Options.player.frame.bg.width)
		--hp pet max text
			MP_PET_MAX:SetFont(Options.font.font, Options.font.size, Options.font.flags)
		--hp pet percent text
			MP_PET_PERCENT:SetFont(Options.font.font, Options.font.size, Options.font.flags)
		--hp pet deficit text
			MP_PET_DEFICIT:SetFont(Options.font.font, Options.font.size, Options.font.flags)
		end
	end
end

function HP_Pet(arg1)
	local unit = "pet"
	local tBar = HP_PET_BAR_TEXTURE
	local tBG  = HP_PET_BG_TEXTURE1
	local tBG2 = HP_PET_BG_TEXTURE2
	local fBut = HP_Pet_Button
	local fBar = HP_PET_BAR
	local fBG	 = HP_PET_FRAME	
	local fMax = HP_PET_MAX
	local fPer = HP_PET_PERCENT
	local fDef = HP_PET_DEFICIT
	local fNam = HP_PET_NAME
	
	local fUn = HP_PET_FRAME
	
	if (Options.pet.frame.active==1) then
		--enable frame
		EnableFrame(fUn)
		
		this.TimeSinceLastUpdate=this.TimeSinceLastUpdate + arg1
		if (this.TimeSinceLastUpdate > Options.update) then
			if (UnitExists(unit)) then	
			--Color
				ColorHealth(unit,tBar,tBG,tBG2,fPer,fDef, fUn)
			--selected
				HighlightSelectedUnit(unit,fBut)
			--Health
			local cur, max = UnitHealth(unit), UnitHealthMax(unit)
			local deficit = max-cur
			--hp bar
				if (cur==0) then
					fBar:SetHeight(1)
				else
					if (max>=cur) then
						fBar:SetHeight((Options.player.frame.bg.height/2)/max*cur)
					else
						fBar:SetHeight(Options.player.frame.bg.height/2)
					end
				end
			--hp name text
				--UnitNames(unit,fNam)
				NamePet(unit,fNam)
			--hp max text
				fMax:SetText(max)
			--hp percent text
				fPer:SetText(string.format("%.0f", (100/max*cur)) .."%")
			--hp deficit text
				DeficitHealthPet(cur,max,fDef,deficit)
			end
			this.TimeSinceLastUpdate=0
		end
	else
		--disable frame
		DisableFrame(fUn)
	end
end

function MP_Pet(arg1)
	local unit = "pet"
	local tBar = MP_PET_BAR_TEXTURE
	local tBG  = MP_PET_BG_TEXTURE1	
	local tBG2 = MP_PET_BG_TEXTURE2
	local fBut = MP_Pet_Button
	local fBar = MP_PET_BAR
	local fBG	 = MP_PET_FRAME	
	local fMax = MP_PET_MAX
	local fPer = MP_PET_PERCENT
	local fDef = MP_PET_DEFICIT
	
	local fUn = MP_PET_FRAME
	
	if (Options.pet.frame.active==1) then
		--enable frame
		EnableFrame(fUn)
		
		this.TimeSinceLastUpdate=this.TimeSinceLastUpdate + arg1
		if (this.TimeSinceLastUpdate > Options.update) then	
			if (UnitExists(unit)) then	
			--Color
				ColorMana(unit,tBar,tBG,tBG2,fPer,fDef, fUn)
			--Health
			local cur, max = UnitMana(unit), UnitManaMax(unit)
			local deficit = max-cur	
			--mp bar
				if (cur==0) then
					fBar:SetHeight(1)
				else
					if (max>=cur) then
						fBar:SetHeight((Options.player.frame.bg.height/2)/max*cur)
					else
						fBar:SetHeight(Options.player.frame.bg.height/2)
					end
				end
			--mp max text
				fMax:SetText(max)
				ColorPowerType(unit,fMax)
			--mp percent text
				fPer:SetText(string.format("%.0f", (100/max*cur)) .."%")
			--mp deficit text
				DeficitManaPet(cur,max,fDef,deficit,unit)
			end
			this.TimeSinceLastUpdate=0
		end
	else
		--disable frame
		DisableFrame(fUn)
	end
end

