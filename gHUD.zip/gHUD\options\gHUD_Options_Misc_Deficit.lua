function defFormatCBOnLoad()
	if (Options.player.deficit.format==0) then
		defFormatCB:SetChecked(false)
	elseif (Options.player.deficit.format==1) then
		defFormatCB:SetChecked(true)
	end
end

function defFormatCBOnClick()
	if (defFormatCB:GetChecked(false)) then
		defFormatCB:SetChecked(true)
		Options.player.deficit.format=1
		Options.target.deficit.format=1
		Options.party.deficit.format=1
		Options.pet.deficit.format=1
		Options.tt.deficit.format=1
	else defFormatCB:SetChecked(false)
		Options.player.deficit.format=0
		Options.target.deficit.format=0
		Options.party.deficit.format=0
		Options.pet.deficit.format=0
		Options.tt.deficit.format=0
	end	
end
---------------------------------------------------------
function defModeCBOnLoad()
	if (Options.party.deficit.mode==0) then
		defModeCB:SetChecked(false)
	elseif (Options.party.deficit.mode==1) then
		defModeCB:SetChecked(true)
	end
end

function defModeCBOnClick()
	if (defModeCB:GetChecked(false)) then
		defModeCB:SetChecked(true)
		Options.player.deficit.mode=1
		Options.target.deficit.mode=1
		Options.party.deficit.mode=1
		Options.pet.deficit.mode=1
		Options.tt.deficit.mode=1
	else defModeCB:SetChecked(false)
		Options.player.deficit.mode=0
		Options.target.deficit.mode=0
		Options.party.deficit.mode=0
		Options.pet.deficit.mode=0
		Options.tt.deficit.mode=0
	end	
end