

function gHUDOnLoad()
--Slash Commands	
	SLASH_gHUD_1 = "/groggy hud"
	SLASH_gHUD_2 = "/ghud"
	SlashCmdList["gHUD_"] = gHUD_Command

--Handlers
	this:RegisterEvent("ADDON_LOADED")
	this:RegisterEvent("PLAYER_TARGET_CHANGED") 
	this:RegisterEvent("PARTY_MEMBERS_CHANGED")
	this:RegisterEvent("UNIT_PET")
	
	this:RegisterEvent("PLAYER_REGEN_DISABLED")
	this:RegisterEvent("PLAYER_REGEN_ENABLED")
	this:RegisterEvent("RAID_ROSTER_UPDATE")
	
	this.TimeSinceLastUpdate=0
end

function TargetChangeOnEvent()
	--show/hide target frames
	if (event=="PLAYER_TARGET_CHANGED") then
		
	end
end


function RaidRosterUpdate()
	--show/hide party in raid
	if (event=="RAID_ROSTER_UPDATE") then
		
		
		if UinitInRaid("player") then
			if (Options.party.hideinraid==0) then
				--show party
				--EnableFrame(fUn)
			else
				--hide party
				--DisableFrame(fUn)
			end
		end
	--does it need a condition for party?
	end
end

function PetChangeOnEvent()
	--show/hide pet frames
	if (event=="UNIT_PET") then
		if (UnitExists("pet")) then
			HP_PET_FRAME:Show()
			MP_PET_FRAME:Show()
		else 
			HP_PET_FRAME:Hide()
			MP_PET_FRAME:Hide()
		end
		
		--resize partypet frames when pets change
		ScalePetFrames();
		
	end
end
---------------------------------------------------------
function DisableFrame(fUn)
	if (fUn:IsMouseEnabled()) then
		fUn:SetAlpha(0)
		fUn:EnableMouse(false)
		--DEFAULT_CHAT_FRAME:AddMessage("disabled")
	end
end

function EnableFrame(fUn)
	if (not fUn:IsMouseEnabled()) then
		fUn:SetAlpha(Colors.mp100.a)
		fUn:EnableMouse(true)
		--DEFAULT_CHAT_FRAME:AddMessage("enabled")
	end
end
---------------------------------------------------------
function HighlightSelectedUnit(unit,fBut)
	if (UnitIsUnit(unit,"target")==1)  then
	--	DEFAULT_CHAT_FRAME:AddMessage("true")
		fBut:LockHighlight()
	elseif (UnitIsUnit(unit,"target")==nil) then
	--	DEFAULT_CHAT_FRAME:AddMessage("false")
		fBut:UnlockHighlight()
	end
end
---------------------------------------------------------
--[[			
function MyFrame:OnUpdate()  
	-- Some code  
	if self:GetScale() ~= x then  
		self:DoScaling(x);  
	end  
	-- More code  
end  
	  
function MyFrame:DoScaling(x)  
	if ~InCombatLockdown() then  
		self:SetScale(x)  
	end  
end 
--]]
