function fontSizeSliderOnLoad()
	fontSizeSlider:SetMinMaxValues(6,30)
	local sliderMin, sliderMax = fontSizeSlider:GetMinMaxValues()
	local _,size,_ = HP_PLAYER_MAX:GetFont()
	getglobal(fontSizeSlider:GetName().."Low"):SetText(sliderMin)
	getglobal(fontSizeSlider:GetName().."High"):SetText(sliderMax)
	fontSizeSlider:SetOrientation("HORIZONTAL")
	fontSizeSlider:SetValueStep(1)
	fontSizeSlider:SetValue(Options.font.size)
end

function fontSizeSliderOnValueChanged()
	if fontSizeSlider:GetValue() then 
	local font, size, flags = Options.font.font, Options.font.size, Options.font.flags
	
		fontSizeSlider:SetValue(fontSizeSlider:GetValue())
		size=fontSizeSlider:GetValue()
		fontSizeStatus:SetText(size)
		Options.font.size=fontSizeSlider:GetValue()
		
		HP_PLAYER_MAX:SetFont(font, size, flags)
		HP_PLAYER_PERCENT:SetFont(font, size, flags)
		HP_PLAYER_DEFICIT:SetFont(font, size, flags)
		HP_PLAYER_NAME:SetFont(font, size, flags)
		MP_PLAYER_MAX:SetFont(font, size, flags)
		MP_PLAYER_PERCENT:SetFont(font, size, flags)
		MP_PLAYER_DEFICIT:SetFont(font, size, flags)
		
		HP_TARGET_MAX:SetFont(font, size, flags)
		HP_TARGET_PERCENT:SetFont(font, size, flags)
		HP_TARGET_DEFICIT:SetFont(font, size, flags)
		HP_TARGET_NAME:SetFont(font, size, flags)
		MP_TARGET_MAX:SetFont(font, size, flags)
		MP_TARGET_PERCENT:SetFont(font, size, flags)
		MP_TARGET_DEFICIT:SetFont(font, size, flags)
		
		HP_PARTY1_DEFICIT:SetFont(font, size, flags)
		HP_PARTY1_NAME:SetFont(font, size, flags)
		MP_PARTY1_DEFICIT:SetFont(font, size, flags)
		HP_PARTY2_DEFICIT:SetFont(font, size, flags)
		HP_PARTY2_NAME:SetFont(font, size, flags)
		MP_PARTY2_DEFICIT:SetFont(font, size, flags)
		HP_PARTY3_DEFICIT:SetFont(font, size, flags)
		HP_PARTY3_NAME:SetFont(font, size, flags)
		MP_PARTY3_DEFICIT:SetFont(font, size, flags)
		HP_PARTY4_DEFICIT:SetFont(font, size, flags)
		HP_PARTY4_NAME:SetFont(font, size, flags)
		MP_PARTY4_DEFICIT:SetFont(font, size, flags)
		
		
		HP_PARTYPET1_NAME:SetFont(font, size, flags)
		HP_PARTYPET2_NAME:SetFont(font, size, flags)
		HP_PARTYPET3_NAME:SetFont(font, size, flags)
		HP_PARTYPET4_NAME:SetFont(font, size, flags)
		
		HP_PET_MAX:SetFont(font, size, flags)
		HP_PET_PERCENT:SetFont(font, size, flags)
		HP_PET_DEFICIT:SetFont(font, size, flags)
		HP_PET_NAME:SetFont(font, size, flags)
		MP_PET_MAX:SetFont(font, size, flags)
		MP_PET_PERCENT:SetFont(font, size, flags)
		MP_PET_DEFICIT:SetFont(font, size, flags)
		
		HP_TARGETTARGET_MAX:SetFont(font, size, flags)
		HP_TARGETTARGET_PERCENT:SetFont(font, size, flags)
		HP_TARGETTARGET_DEFICIT:SetFont(font, size, flags)
		HP_TARGETTARGET_NAME:SetFont(font, size, flags)
		MP_TARGETTARGET_MAX:SetFont(font, size, flags)
		MP_TARGETTARGET_PERCENT:SetFont(font, size, flags)
		MP_TARGETTARGET_DEFICIT:SetFont(font, size, flags)
	end
end
---------------------------------------------------------
function fontFlagsSliderOnLoad()
	fontFlagsSlider:SetMinMaxValues(1,6)
	local sliderMin, sliderMax = fontFlagsSlider:GetMinMaxValues()
	local flags=Options.font.flags
	--local _,_,flags = HP_PLAYER_MAX:GetFont()
	getglobal(fontFlagsSlider:GetName().."Low"):SetText(sliderMin)
	getglobal(fontFlagsSlider:GetName().."High"):SetText(sliderMax)
	fontFlagsSlider:SetOrientation("HORIZONTAL")
	fontFlagsSlider:SetValueStep(1)
	
	if (flags=="none") then	
		fontFlagsSlider:SetValue(1)
	elseif (flags=="OUTLINE") then	
		fontFlagsSlider:SetValue(2)
	elseif (flags=="THICKOUTLINE") then	
		fontFlagsSlider:SetValue(3)
	elseif (flags=="MONOCHROME") then	
		fontFlagsSlider:SetValue(4)
	elseif (flags=="OUTLINE, MONOCHROME") then	
		fontFlagsSlider:SetValue(5)
	elseif (flags=="THICKOUTLINE, MONOCHROME") then	
		fontFlagsSlider:SetValue(6)
	end
end

function fontFlagsSliderOnValueChanged()
	local font, size, flags = Options.font.font, Options.font.size, Options.font.flags
	
	if (fontFlagsSlider:GetValue()==1) then
		flags="none"
		fontFlagsStatus:SetText(flags)
	elseif (fontFlagsSlider:GetValue()==2) then
		flags="OUTLINE"
		fontFlagsStatus:SetText(flags)
	elseif (fontFlagsSlider:GetValue()==3) then
		flags="THICKOUTLINE"
		fontFlagsStatus:SetText(flags)
	elseif (fontFlagsSlider:GetValue()==4) then
		flags="MONOCHROME"
		fontFlagsStatus:SetText(flags)
	elseif (fontFlagsSlider:GetValue()==5) then
		flags="OUTLINE, MONOCHROME"
		fontFlagsStatus:SetText(flags)
	elseif (fontFlagsSlider:GetValue()==6) then
		flags="THICKOUTLINE, MONOCHROME"
		fontFlagsStatus:SetText(flags)
	end
	
	Options.font.flags=fontFlagsStatus:GetText()
		
	HP_PLAYER_MAX:SetFont(font, size, flags)
	HP_PLAYER_PERCENT:SetFont(font, size, flags)
	HP_PLAYER_DEFICIT:SetFont(font, size, flags)
	HP_PLAYER_NAME:SetFont(font, size, flags)
	MP_PLAYER_MAX:SetFont(font, size, flags)
	MP_PLAYER_PERCENT:SetFont(font, size, flags)
	MP_PLAYER_DEFICIT:SetFont(font, size, flags)
		
	HP_TARGET_MAX:SetFont(font, size, flags)
	HP_TARGET_PERCENT:SetFont(font, size, flags)
	HP_TARGET_DEFICIT:SetFont(font, size, flags)
	HP_TARGET_NAME:SetFont(font, size, flags)
	MP_TARGET_MAX:SetFont(font, size, flags)
	MP_TARGET_PERCENT:SetFont(font, size, flags)
	MP_TARGET_DEFICIT:SetFont(font, size, flags)
		
	HP_PARTY1_DEFICIT:SetFont(font, size, flags)
	HP_PARTY1_NAME:SetFont(font, size, flags)
	MP_PARTY1_DEFICIT:SetFont(font, size, flags)
	HP_PARTY2_DEFICIT:SetFont(font, size, flags)
	HP_PARTY2_NAME:SetFont(font, size, flags)
	MP_PARTY2_DEFICIT:SetFont(font, size, flags)
	HP_PARTY3_DEFICIT:SetFont(font, size, flags)
	HP_PARTY3_NAME:SetFont(font, size, flags)
	MP_PARTY3_DEFICIT:SetFont(font, size, flags)
	HP_PARTY4_DEFICIT:SetFont(font, size, flags)
	HP_PARTY4_NAME:SetFont(font, size, flags)
	MP_PARTY4_DEFICIT:SetFont(font, size, flags)
		
	HP_PARTYPET1_NAME:SetFont(font, size, flags)
	HP_PARTYPET2_NAME:SetFont(font, size, flags)
	HP_PARTYPET3_NAME:SetFont(font, size, flags)
	HP_PARTYPET4_NAME:SetFont(font, size, flags)

	HP_PET_MAX:SetFont(font, size, flags)
	HP_PET_PERCENT:SetFont(font, size, flags)
	HP_PET_DEFICIT:SetFont(font, size, flags)
	HP_PET_NAME:SetFont(font, size, flags)
	MP_PET_MAX:SetFont(font, size, flags)
	MP_PET_PERCENT:SetFont(font, size, flags)
	MP_PET_DEFICIT:SetFont(font, size, flags)
		
	HP_TARGETTARGET_MAX:SetFont(font, size, flags)
	HP_TARGETTARGET_PERCENT:SetFont(font, size, flags)
	HP_TARGETTARGET_DEFICIT:SetFont(font, size, flags)
	HP_TARGETTARGET_NAME:SetFont(font, size, flags)
	MP_TARGETTARGET_MAX:SetFont(font, size, flags)
	MP_TARGETTARGET_PERCENT:SetFont(font, size, flags)
	MP_TARGETTARGET_DEFICIT:SetFont(font, size, flags)
end