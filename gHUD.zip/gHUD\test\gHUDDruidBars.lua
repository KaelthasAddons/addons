
--[[

*	display mana for druids if in cat/bear form
		-- is it possible? 
		-- solution to display it?
			--split bar?
			--new bar?
		
		--stance = GetShapeshiftForm(arg1);
		Druid 
		0 = humanoid form 
		1 = Bear/Dire Bear Form 
		2 = Aquatic Form 
		3 = Cat Form 
		4 = Travel Form 
		5 = Moonkin/Tree Form 
		6 = Flight Form 

---------------------------------------------------------------------------------
		
	--substract manacost of shapeshifting cast and consider the mp/5 regeneration
	
		--shapeshift manacost:
		
		
		--mp/5 Druids:
		
		
Aquatic Form 		stance=2
Shapeshift Feral Combat 13%
 
Travel Form 		stance=4
Shapeshift Feral Combat 13%
 
Flight Form 		stance=6
Shapeshift Feral Combat 13% 
 
Swift Flight Form 	stance=6?
Shapeshift Feral Combat 13%
 
Bear Form 			stance=1
Shapeshift Feral Combat 35% 
 
Cat Form 			stance=3
Shapeshift Feral Combat 35% 
 
Dire Bear Form 		stance=1
Shapeshift Feral Combat 35% 




talents : 
Hearth of the wild 	2/15  increases int by		(4%, 8%, 12%, 16%, 20%)  	*4
Survival of the fittest	2/16 	increase all stats by	(1%, 2% 3%) 	
Natural Shapeshifter  	3/5	reduce manacost of shapeshift by  (10%, 20%, 30%)	*10
--]]


function gHUDShiftCost()
	local spellcost = 0
	local playerClass, englishClass = UnitClass("player")
	local base, stat, posBuff, negBuff = UnitStat("player", 4)
	local mpmax = UnitManaMax("player")

	if (englishClass=="DRUID") then
		
		--druid talent check
		local _, _, _, _, currentRank, _, _, _ = GetTalentInfo(3, 5)
		local div = (1.0 + currentRank*10/100)
		local managain = ((base*div*15)-280)
		
		
		--13%
		cost= 0.13
		
		--35%
		cost = 0.35
		
			
		spellcost = ((mpmax-managain)*cost)
	
	end
end


