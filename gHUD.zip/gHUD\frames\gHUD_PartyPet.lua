		
function Load_HP_PartyPet1()	
	if (event=="ADDON_LOADED") and (arg1=="gHUD") and (Options~=nil) then	
		LoadOptions();
		if (Options.partypet.frame.active==1) then
		--set position
			HP_PARTYPET1_FRAME:ClearAllPoints()
			HP_PARTYPET1_FRAME:SetPoint("BOTTOMRIGHT", nil, "CENTER", Options.partypet.frame.position.hpx, Options.partypet.frame.position.hpy)
		--texture
			PARTYPETPERCENT:Hide()
			PARTYPETDEF:Hide()
			HP_PARTYPET1_BAR_TEXTURE:SetTexture(Options.texture.BarHeight)
			
			HP_PARTYPET1_BG_TEXTURE1:SetWidth(Options.player.frame.bg.width)
			HP_PARTYPET1_BG_TEXTURE2:SetWidth(Options.player.frame.bg.width-2)
		
			HP_PARTYPET1_BAR:SetWidth(Options.player.frame.bar.width)
			HP_PARTYPET1_FRAME:SetWidth(Options.player.frame.bg.width)
			
			HP_PartyPet1_Button:SetWidth(Options.player.frame.bg.width)
		--hp partypet1 name text
			HP_PARTYPET1_NAME:SetFont(Options.font.font, Options.font.size, Options.font.flags)
		end
	end
end

function Load_HP_PartyPet2()
	if (event=="ADDON_LOADED") and (arg1=="gHUD") and (Options~=nil) then	
		if (Options.partypet.frame.active==1) then
		--texture
			HP_PARTYPET2_BAR_TEXTURE:SetTexture(Options.texture.BarHeight)
			
			HP_PARTYPET2_BG_TEXTURE1:SetWidth(Options.player.frame.bg.width)
			HP_PARTYPET2_BG_TEXTURE2:SetWidth(Options.player.frame.bg.width-2)
		
			HP_PARTYPET2_BAR:SetWidth(Options.player.frame.bar.width)
			HP_PARTYPET2_FRAME:SetWidth(Options.player.frame.bg.width)
			
			HP_PartyPet2_Button:SetWidth(Options.player.frame.bg.width)
		--hp partypet2 name text
			HP_PARTYPET2_NAME:SetFont(Options.font.font, Options.font.size, Options.font.flags)
		end
	end
end

function Load_HP_PartyPet3()
	if (event=="ADDON_LOADED") and (arg1=="gHUD") and (Options~=nil) then	
		if (Options.partypet.frame.active==1) then
		--texture
			HP_PARTYPET3_BAR_TEXTURE:SetTexture(Options.texture.BarHeight)
			
			HP_PARTYPET3_BG_TEXTURE1:SetWidth(Options.player.frame.bg.width)
			HP_PARTYPET3_BG_TEXTURE2:SetWidth(Options.player.frame.bg.width-2)
		
			HP_PARTYPET3_BAR:SetWidth(Options.player.frame.bar.width)
			HP_PARTYPET3_FRAME:SetWidth(Options.player.frame.bg.width)
			
			HP_PartyPet3_Button:SetWidth(Options.player.frame.bg.width)
		--hp partypet3 name text
			HP_PARTYPET3_NAME:SetFont(Options.font.font, Options.font.size, Options.font.flags)
		end
	end
end

function Load_HP_PartyPet4()
	if (event=="ADDON_LOADED") and (arg1=="gHUD") and (Options~=nil) then	
		if (Options.partypet.frame.active==1) then
		--texture
			HP_PARTYPET4_BAR_TEXTURE:SetTexture(Options.texture.BarHeight)
			
			HP_PARTYPET4_BG_TEXTURE1:SetWidth(Options.player.frame.bg.width)
			HP_PARTYPET4_BG_TEXTURE2:SetWidth(Options.player.frame.bg.width-2)
		
			HP_PARTYPET4_BAR:SetWidth(Options.player.frame.bar.width)
			HP_PARTYPET4_FRAME:SetWidth(Options.player.frame.bg.width)
			
			HP_PartyPet4_Button:SetWidth(Options.player.frame.bg.width)
		--hp partypet4 name text
			HP_PARTYPET4_NAME:SetFont(Options.font.font, Options.font.size, Options.font.flags)
		end
	end
end


function Load_MP_PartyPet1()
	if (event=="ADDON_LOADED") and (arg1=="gHUD") and (Options~=nil) then
		if (Options.partypet.frame.active==1) then
		--set position
			MP_PARTYPET1_FRAME:ClearAllPoints()
			MP_PARTYPET1_FRAME:SetPoint("BOTTOMLEFT", nil, "CENTER", Options.partypet.frame.position.mpx, Options.partypet.frame.position.mpy)
		--texture
			MP_PARTYPET1_BAR_TEXTURE:SetTexture(Options.texture.BarHeight)
			
			MP_PARTYPET1_BG_TEXTURE1:SetWidth(Options.player.frame.bg.width)
			MP_PARTYPET1_BG_TEXTURE2:SetWidth(Options.player.frame.bg.width-2)
		
			MP_PARTYPET1_BAR:SetWidth(Options.player.frame.bar.width)
			MP_PARTYPET1_FRAME:SetWidth(Options.player.frame.bg.width)
		
			MP_PartyPet1_Button:SetWidth(Options.player.frame.bg.width)
		end
	end
end

function Load_MP_PartyPet2()
	if (event=="ADDON_LOADED") and (arg1=="gHUD") and (Options~=nil) then
		if (Options.partypet.frame.active==1) then	
		--texture
			MP_PARTYPET2_BAR_TEXTURE:SetTexture(Options.texture.BarHeight)
			
			MP_PARTYPET2_BG_TEXTURE1:SetWidth(Options.player.frame.bg.width)
			MP_PARTYPET2_BG_TEXTURE2:SetWidth(Options.player.frame.bg.width-2)
		
			MP_PARTYPET2_BAR:SetWidth(Options.player.frame.bar.width)
			MP_PARTYPET2_FRAME:SetWidth(Options.player.frame.bg.width)
		
			MP_PartyPet2_Button:SetWidth(Options.player.frame.bg.width)
		end
	end
end

function Load_MP_PartyPet3()
	if (event=="ADDON_LOADED") and (arg1=="gHUD") and (Options~=nil) then
		if (Options.partypet.frame.active==1) then
		--texture
			MP_PARTYPET3_BAR_TEXTURE:SetTexture(Options.texture.BarHeight)
			
			MP_PARTYPET3_BG_TEXTURE1:SetWidth(Options.player.frame.bg.width)
			MP_PARTYPET3_BG_TEXTURE2:SetWidth(Options.player.frame.bg.width-2)
		
			MP_PARTYPET3_BAR:SetWidth(Options.player.frame.bar.width)
			MP_PARTYPET3_FRAME:SetWidth(Options.player.frame.bg.width)
		
			MP_PartyPet3_Button:SetWidth(Options.player.frame.bg.width)
		end
	end
end

function Load_MP_PartyPet4()
	if (event=="ADDON_LOADED") and (arg1=="gHUD") and (Options~=nil) then
		if (Options.partypet.frame.active==1) then	
		--texture
			MP_PARTYPET4_BAR_TEXTURE:SetTexture(Options.texture.BarHeight)
			
			MP_PARTYPET4_BG_TEXTURE1:SetWidth(Options.player.frame.bg.width)
			MP_PARTYPET4_BG_TEXTURE2:SetWidth(Options.player.frame.bg.width-2)
		
			MP_PARTYPET4_BAR:SetWidth(Options.player.frame.bar.width)
			MP_PARTYPET4_FRAME:SetWidth(Options.player.frame.bg.width)
		
			MP_PartyPet4_Button:SetWidth(Options.player.frame.bg.width)
		end
	end
end

function HP_PartyPet1(arg1)	
	local unit = "partypet1"
	local tBar = HP_PARTYPET1_BAR_TEXTURE
	local tBG  = HP_PARTYPET1_BG_TEXTURE1
	local tBG2 = HP_PARTYPET1_BG_TEXTURE2
	local fBut = HP_PartyPet1_Button
	local fBar = HP_PARTYPET1_BAR
	local fBG  = HP_PARTYPET1_FRAME
	local fNam = HP_PARTYPET1_NAME
	local fDef = PARTYPETDEF
	local fPer = PARTYPETPERCENT
	
	local fUn = HP_PARTYPET1_FRAME
	
	if (Options.partypet.frame.active==1) then
		--enable frame
		EnableFrame(fUn)
		
		this.TimeSinceLastUpdate=this.TimeSinceLastUpdate + arg1
		if (this.TimeSinceLastUpdate > Options.update) then
			if (UnitExists("party1")) then	
			--Color
				ColorHealth(unit,tBar,tBG,tBG2,fPer,fDef, fUn)
			--selected
				HighlightSelectedUnit(unit,fBut)
			--Health
			local cur, max = UnitHealth(unit), UnitHealthMax(unit)
			local deficit = max-cur
			--hp bar
				ScalePartyPetFrame(tBG,tBG2,fBG,fBut)
				ScalePartyPetBar(fBar,max,cur)
			--hp name text
				--UnitNames(unit,fNam)
				NamePartyPet(unit,fNam)
			end
			this.TimeSinceLastUpdate=0
		end	
	else
		--disable frame
		DisableFrame(fUn)
	end
end

function HP_PartyPet2(arg1)
	local unit = "partypet2"
	local tBar = HP_PARTYPET2_BAR_TEXTURE
	local tBG  = HP_PARTYPET2_BG_TEXTURE1
	local tBG2 = HP_PARTYPET2_BG_TEXTURE2
	local fBut = HP_PartyPet2_Button
	local fBar = HP_PARTYPET2_BAR
	local fBG	= HP_PARTYPET2_FRAME
	local fNam = HP_PARTYPET2_NAME
	local fDef = PARTYPETDEF
	local fPer = PARTYPETPERCENT	
	
	local fUn = HP_PARTYPET2_FRAME
	
	if (Options.partypet.frame.active==1) then
		--enable frame
		EnableFrame(fUn)
		
		this.TimeSinceLastUpdate=this.TimeSinceLastUpdate + arg1
		if (this.TimeSinceLastUpdate > Options.update) then
			if (UnitExists("party1")) then	
			--Color
				ColorHealth(unit,tBar,tBG,tBG2,fPer,fDef, fUn)
			--selected
				HighlightSelectedUnit(unit,fBut)
			--Health
			local cur, max = UnitHealth(unit), UnitHealthMax(unit)
			local deficit = max-cur
			--hp bar
				ScalePartyPetFrame(tBG,tBG2,fBG,fBut)
				ScalePartyPetBar(fBar,max,cur)
				
				fUn:ClearAllPoints()
				fUn:SetPoint("BOTTOM", HP_PARTYPET1_FRAME, "TOP", 0, Options.party.frame.gap+fUn:GetHeight())
			--hp name text
				--UnitNames(unit,fNam)
				NamePartyPet(unit,fNam)
			end
			this.TimeSinceLastUpdate=0
		end	
	else
		--disable frame
		DisableFrame(fUn)
	end
end

function HP_PartyPet3(arg1)	
	local unit = "partypet3"
	local tBar = HP_PARTYPET3_BAR_TEXTURE
	local tBG  = HP_PARTYPET3_BG_TEXTURE1
	local tBG2 = HP_PARTYPET3_BG_TEXTURE2
	local fBut = HP_PartyPet3_Button
	local fBar = HP_PARTYPET3_BAR
	local fBG	 = HP_PARTYPET3_FRAME
	local fNam = HP_PARTYPET3_NAME
	local fDef = PARTYPETDEF
	local fPer = PARTYPETPERCENT
	
	local fUn = HP_PARTYPET3_FRAME
	
	if (Options.partypet.frame.active==1) then
		--enable frame
		EnableFrame(fUn)
		
		this.TimeSinceLastUpdate=this.TimeSinceLastUpdate + arg1
		if (this.TimeSinceLastUpdate > Options.update) then
			if (UnitExists("party1")) then	
			--Color
				ColorHealth(unit,tBar,tBG,tBG2,fPer,fDef, fUn)
			--selected
				HighlightSelectedUnit(unit,fBut)
			--Health
			local cur, max = UnitHealth(unit), UnitHealthMax(unit)
			local deficit = max-cur
			--hp bar
				ScalePartyPetFrame(tBG,tBG2,fBG,fBut)
				ScalePartyPetBar(fBar,max,cur)
				fUn:ClearAllPoints()
				fUn:SetPoint("BOTTOM", HP_PARTYPET2_FRAME, "TOP", 0, Options.party.frame.gap+fUn:GetHeight())
			--hp name text
				--UnitNames(unit,fNam)
				NamePartyPet(unit,fNam)
			end
			this.TimeSinceLastUpdate=0
		end	
	else
		--disable frame
		DisableFrame(fUn)
	end
end

function HP_PartyPet4(arg1)
	local unit = "partypet4"
	local tBar = HP_PARTYPET4_BAR_TEXTURE
	local tBG  = HP_PARTYPET4_BG_TEXTURE1
	local tBG2 = HP_PARTYPET4_BG_TEXTURE2
	local fBut = HP_PartyPet4_Button
	local fBar = HP_PARTYPET4_BAR
	local fBG	 = HP_PARTYPET4_FRAME
	local fNam = HP_PARTYPET4_NAME
	local fDef = PARTYPETDEF
	local fPer = PARTYPETPERCENT
	
	local fUn = HP_PARTYPET4_FRAME
	
	if (Options.partypet.frame.active==1) then
		--enable frame
		EnableFrame(fUn)
		
		this.TimeSinceLastUpdate=this.TimeSinceLastUpdate + arg1
		if (this.TimeSinceLastUpdate > Options.update) then
			if (UnitExists("party1")) then	
			--Color
				ColorHealth(unit,tBar,tBG,tBG2,fPer,fDef, fUn)
			--selected
				HighlightSelectedUnit(unit,fBut)
			--Health
			local cur, max = UnitHealth(unit), UnitHealthMax(unit)
			local deficit = max-cur
			--hp bar
				ScalePartyPetFrame(tBG,tBG2,fBG,fBut)
				ScalePartyPetBar(fBar,max,cur)
				fUn:ClearAllPoints()
				fUn:SetPoint("BOTTOM", HP_PARTYPET3_FRAME, "TOP", 0, Options.party.frame.gap+fUn:GetHeight())
			--hp name text
				--UnitNames(unit,fNam)
				NamePartyPet(unit,fNam)
			end
			this.TimeSinceLastUpdate=0
		end	
	else
		--disable frame
		DisableFrame(fUn)
	end
end

function MP_PartyPet1(arg1)	
	local unit = "partypet1"
	local tBar = MP_PARTYPET1_BAR_TEXTURE
	local tBG  = MP_PARTYPET1_BG_TEXTURE1
	local tBG2 = MP_PARTYPET1_BG_TEXTURE2
	local fBut = MP_PartyPet1_Button
	local fBar = MP_PARTYPET1_BAR
	local fBG	= MP_PARTYPET1_FRAME
	local fDef = PARTYPETDEF
	local fPer = PARTYPETPERCENT
	
	local fUn = MP_PARTYPET1_FRAME
	
	if (Options.partypet.frame.active==1) then
		--enable frame
		EnableFrame(fUn)
		
		this.TimeSinceLastUpdate=this.TimeSinceLastUpdate + arg1
		if (this.TimeSinceLastUpdate > Options.update) then	
			if (UnitExists("party1")) then
		--Color
			ColorMana(unit,tBar,tBG,tBG2,fPer,fDef, fUn)
		--Health
			local cur, max = UnitMana(unit), UnitManaMax(unit)
			local deficit = max-cur
			--mp bar
				ScalePartyPetFrame(tBG,tBG2,fBG,fBut)
				ScalePartyPetBar(fBar,max,cur)
			end
			this.TimeSinceLastUpdate=0
		end
	else
		--disable frame
		DisableFrame(fUn)
	end
end

function MP_PartyPet2(arg1)
	local unit = "partypet2"
	local tBar = MP_PARTYPET2_BAR_TEXTURE
	local tBG  = MP_PARTYPET2_BG_TEXTURE1
	local tBG2 = MP_PARTYPET2_BG_TEXTURE2
	local fBut = MP_PartyPet2_Button
	local fBar = MP_PARTYPET2_BAR
	local fBG	 = MP_PARTYPET2_FRAME
	local fDef = PARTYPETDEF
	local fPer = PARTYPETPERCENT
	
	local fUn = MP_PARTYPET2_FRAME
	
	if (Options.partypet.frame.active==1) then
		--enable frame
		EnableFrame(fUn)
		
		this.TimeSinceLastUpdate=this.TimeSinceLastUpdate + arg1
		if (this.TimeSinceLastUpdate > Options.update) then	
			if (UnitExists("party1")) then
		--Color
			ColorMana(unit,tBar,tBG,tBG2,fPer,fDef, fUn)
		--Health
			local cur, max = UnitMana(unit), UnitManaMax(unit)
			local deficit = max-cur
			--mp bar
				ScalePartyPetFrame(tBG,tBG2,fBG,fBut)
				ScalePartyPetBar(fBar,max,cur)
				fUn:ClearAllPoints()
				fUn:SetPoint("BOTTOM", MP_PARTYPET1_FRAME, "TOP", 0, Options.party.frame.gap+fUn:GetHeight())
			end
			this.TimeSinceLastUpdate=0
		end
	else
		--disable frame
		DisableFrame(fUn)
	end
end

function MP_PartyPet3(arg1)
	local unit = "partypet3"
	local tBar = MP_PARTYPET3_BAR_TEXTURE
	local tBG  = MP_PARTYPET3_BG_TEXTURE1
	local tBG2 = MP_PARTYPET3_BG_TEXTURE2
	local fBut = MP_PartyPet3_Button
	local fBar = MP_PARTYPET3_BAR
	local fBG  = MP_PARTYPET3_FRAME
	local fDef = PARTYPETDEF
	local fPer = PARTYPETPERCENT
	
	local fUn = MP_PARTYPET3_FRAME
	
	if (Options.partypet.frame.active==1) then
		--enable frame
		EnableFrame(fUn)
		
		this.TimeSinceLastUpdate=this.TimeSinceLastUpdate + arg1
		if (this.TimeSinceLastUpdate > Options.update) then	
			if (UnitExists("party1")) then
		--Color
			ColorMana(unit,tBar,tBG,tBG2,fPer,fDef, fUn)
		--Health
			local cur, max = UnitMana(unit), UnitManaMax(unit)
			local deficit = max-cur
			--mp bar
				ScalePartyPetFrame(tBG,tBG2,fBG,fBut)
				ScalePartyPetBar(fBar,max,cur)
				fUn:ClearAllPoints()
				fUn:SetPoint("BOTTOM", MP_PARTYPET2_FRAME, "TOP", 0, Options.party.frame.gap+fUn:GetHeight())
			end
			this.TimeSinceLastUpdate=0
		end
	else
		--disable frame
		DisableFrame(fUn)
	end
end

function MP_PartyPet4(arg1)
	local unit = "partypet4"
	local tBar = MP_PARTYPET4_BAR_TEXTURE
	local tBG  = MP_PARTYPET4_BG_TEXTURE1
	local tBG2 = MP_PARTYPET4_BG_TEXTURE2
	local fBut = MP_PartyPet4_Button
	local fBar = MP_PARTYPET4_BAR
	local fBG	=MP_PARTYPET4_FRAME
	local fDef = PARTYPETDEF
	local fPer = PARTYPETPERCENT
	
	local fUn = MP_PARTYPET4_FRAME
	
	if (Options.partypet.frame.active==1) then
		--enable frame
		EnableFrame(fUn)
		
		this.TimeSinceLastUpdate=this.TimeSinceLastUpdate + arg1
		if (this.TimeSinceLastUpdate > Options.update) then	
			if (UnitExists("party1")) then
		--Color
			ColorMana(unit,tBar,tBG,tBG2,fPer,fDef, fUn)
		--Health
			local cur, max = UnitMana(unit), UnitManaMax(unit)
			local deficit = max-cur
			--mp bar
				ScalePartyPetFrame(tBG,tBG2,fBG,fBut)
				ScalePartyPetBar(fBar,max,cur)
				fUn:ClearAllPoints()
				fUn:SetPoint("BOTTOM", MP_PARTYPET3_FRAME, "TOP", 0, Options.party.frame.gap+fUn:GetHeight())
			end
			this.TimeSinceLastUpdate=0
		end
	else
		--disable frame
		DisableFrame(fUn)
	end
end
