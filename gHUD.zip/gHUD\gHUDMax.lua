function MaxHealthPlayer(fMax,max,deficit,cur)
	if (not UnitInParty("party1") or (Options.party.frame.active==0)) then
		fMax:SetText(max)
	else 
		if (deficit==0) then
			fMax:SetText(max)
		elseif (deficit~=0) and (Options.player.max.mode==0) then
			fMax:SetText(max)
		elseif (deficit~=0) and (Options.player.max.mode==1) then
			fMax:SetText("-" ..deficit)
		elseif (deficit~=0) and (Options.player.max.mode==2) then
			fMax:SetText(cur)
		end
	end	
end

function MaxManaPlayer(fMax, max, deficit, cur, unit)
	local power = UnitPowerType(unit)
	if (not UnitInParty("party1") or (Options.party.frame.active==0)) then
		fMax:SetText(max)
	else 
		if (power==0) then
			if (deficit==0) then
				fMax:SetText(max)
			elseif (deficit~=0) and (Options.player.max.mode==0) then
				fMax:SetText(max)
			elseif (deficit~=0) and (Options.player.max.mode==1) then
				fMax:SetText("-" ..deficit)
			elseif (deficit~=0) and (Options.player.max.mode==2) then
				fMax:SetText(cur)
			end
		else
			fMax:SetText(cur)
		end
	end
end
