
function ColorClass(unit,fNam)
	local playerClass, englishClass = UnitClass(unit)
	if (englishClass=="DRUID") then
			fNam:SetTextColor(1.0, 0.49, 0.04, Colors.hp100.a)
	elseif (englishClass=="HUNTER") then
			fNam:SetTextColor(0.67, 0.83, 0.45, Colors.hp100.a)
	elseif (englishClass=="MAGE") then
			fNam:SetTextColor(0.41, 0.8, 0.94, Colors.hp100.a)
	elseif (englishClass=="PALADIN") then
			fNam:SetTextColor(0.96, 0.55, 0.73, Colors.hp100.a)
	elseif (englishClass=="PRIEST") then
			fNam:SetTextColor(1.0, 1.0, 1.0, Colors.hp100.a)
	elseif (englishClass=="ROGUE") then
			fNam:SetTextColor(1.0, 0.96, 0.41, Colors.hp100.a)
	elseif (englishClass=="SHAMAN") then
			fNam:SetTextColor(0.14, 0.35, 1.0, Colors.hp100.a)
	elseif (englishClass=="WARLOCK") then
			fNam:SetTextColor(0.58, 0.51, 0.79, Colors.hp100.a)
	elseif (englishClass=="WARRIOR") then
			fNam:SetTextColor(0.78, 0.61, 0.43, Colors.hp100.a)
	end
end

function ColorPowerType(unit,fMax)
	local power = UnitPowerType(unit)
	if (power==0) then
		fMax:SetTextColor(0, 0, 1, 1)
	elseif (power==1) then
		fMax:SetTextColor(1, 0, 0, 1)
	elseif (power==2) then
		fMax:SetTextColor(1, 1, 0, 1)
	elseif (power==3) then
		fMax:SetTextColor(1, 1, 0, 1)
	end
end

function ColorFrames(tBar,tBG,fPer,fDef,r,g,b)
	tBar:SetVertexColor(r,g,b)
	tBG:SetVertexColor(r,g,b)
	fPer:SetTextColor(r,g,b)
	fDef:SetTextColor(r,g,b)
end

---------------------------------------------------------

function ColorHealth(unit,tBar,tBG,tBG2,fPer,fDef, fUn)
	local deficit = (1-(UnitHealth(unit)/UnitHealthMax(unit)))
		--local def = (1-(UnitHealth("target")/UnitHealthMax("target")))
		local a = Colors.hp100.a
	
		--fade
		gHUDFadeFrame(unit, deficit, tBar, tBG, fUn, a);
		
	-- grey frame for those conditions
	if (UnitIsTapped(unit)) and (not UnitIsTappedByPlayer(unit))
	or (UnitIsTrivial(unit))
	or (UnitIsDeadOrGhost(unit))
	or (not UnitIsConnected(unit)) then
		local r,g,b = 0.5, 0.5, 0.5
		---[[
			ColorFrames(tBar,tBG,fPer,fDef,r,g,b)
		--]]
	else
		--100
		if (deficit == 0) then 
			local r,g,b = Colors.hp100.r, Colors.hp100.g, Colors.hp100.b
			---[[
				ColorFrames(tBar,tBG,fPer,fDef,r,g,b)
			--]]
		--  > 0 < 0.5
		elseif (deficit > 0) and (deficit < 0.5) then 
			local r,g,b = deficit*2, Colors.hp100.g, Colors.hp100.b
			---[[
				ColorFrames(tBar,tBG,fPer,fDef,r,g,b)
			--]]
		-- >0.5 < 0.8
		elseif (deficit > 0.5) and (deficit <= 0.8) then
			local r,g,b = Colors.hp50.r, (1-deficit)*2, Colors.hp50.b
			---[[
				ColorFrames(tBar,tBG,fPer,fDef,r,g,b)
			--]]
		-- 20-
		elseif (deficit > 0.8) then 
			local r,g,b = Colors.hp20.r, Colors.hp20.g, Colors.hp20.b
			---[[
				ColorFrames(tBar,tBG,fPer,fDef,r,g,b)
			--]]
		end
	end
end

function ColorMana(unit,tBar,tBG,tBG2,fPer,fDef, fUn)
	local deficit = (1-(UnitMana(unit)/UnitManaMax(unit)))
	local a = Colors.mp100.a
	
	--fade
	gHUDFadeFrame(unit, deficit, tBar, tBG, fUn, a);
	
	--powertype mana
	if (UnitPowerType(unit)==0) then 
		-- grey frame for those conditions
		if (UnitIsTapped(unit)) and (not UnitIsTappedByPlayer(unit))
		or (UnitIsTrivial(unit))
		or (UnitIsDeadOrGhost(unit))
		or (not UnitIsConnected(unit)) then
			local r,g,b = 0.5, 0.5, 0.5
			--fade in
			ColorFrames(tBar,tBG,fPer,fDef,r,g,b)
		else
			--100
			if (deficit == 0) then				
			local r,g,b = Colors.mp100.r, Colors.mp100.g, Colors.mp100.b
				ColorFrames(tBar,tBG,fPer,fDef,r,g,b)
			--  > 0 < 0.5
			elseif ((deficit > 0) and (deficit < 0.5)) then
				local r,g,b = deficit*2, deficit*2, Colors.mp100.b
				ColorFrames(tBar,tBG,fPer,fDef,r,g,b)
			-- >0.5 < 0.8
			elseif (deficit > 0.5) and (deficit <= 0.8) then
				local r,g,b = Colors.mp50.r, (1-deficit)*2, (1-deficit)*2
				--fade in
				ColorFrames(tBar,tBG,fPer,fDef,r,g,b)
			-- 20-
			elseif (deficit > 0.8) then
				local r,g,b = Colors.mp20.r, Colors.mp20.g, Colors.mp20.b
				ColorFrames(tBar,tBG,fPer,fDef,r,g,b)
			end
		end
	--powertype rage
	elseif (UnitPowerType(unit)==1) then 
		-- grey frame for those conditions
		if (UnitIsTapped(unit)) and (not UnitIsTappedByPlayer(unit))
		or (UnitIsTrivial(unit))
		or (UnitIsDeadOrGhost(unit))
		or (not UnitIsConnected(unit)) then
			local r,g,b = 0.5, 0.5, 0.5
			ColorFrames(tBar,tBG,fPer,fDef,r,g,b)
		else
			local r,g,b = 1, 0, 0
			ColorFrames(tBar,tBG,fPer,fDef,r,g,b)
		end
	--powertype focus/energy
	elseif (UnitPowerType(unit)==2) or (UnitPowerType(unit)==3) then -- grey frame for those conditions
		if (UnitIsTapped(unit)) and (not UnitIsTappedByPlayer(unit))
		or (UnitIsTrivial(unit))
		or (UnitIsDeadOrGhost(unit))
		or (not UnitIsConnected(unit)) then
			local r,g,b = 0.5, 0.5, 0.5
			ColorFrames(tBar,tBG,fPer,fDef,r,g,b)
		else
			local r,g,b = 1, 1, 0
			ColorFrames(tBar,tBG,fPer,fDef,r,g,b)
		end
	end
end

