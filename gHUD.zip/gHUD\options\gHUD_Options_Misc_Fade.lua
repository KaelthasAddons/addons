function fadeCBOnLoad()
	if (Options.fade.active==0) then
		fadeCB:SetChecked(false)
	elseif (Options.fade.active==1) then
		fadeCB:SetChecked(true)
	end
end

function fadeCBOnClick()
	if (fadeCB:GetChecked(false)) then
		fadeCB:SetChecked(true)
		Options.fade.active=1
	else fadeCB:SetChecked(false)
		Options.fade.active=0
	end	
end


function fadeAlphaSliderOnLoad()
	fadeAlphaSlider:SetMinMaxValues(0,100)
	local sliderMin, sliderMax = fadeAlphaSlider:GetMinMaxValues()
	getglobal(fadeAlphaSlider:GetName().."Low"):SetText(sliderMin/100)
	getglobal(fadeAlphaSlider:GetName().."High"):SetText(sliderMax/100)
	fadeAlphaSlider:SetOrientation("HORIZONTAL")
	fadeAlphaSlider:SetValueStep(1)
	fadeAlphaSlider:SetValue(Options.fade.alpha*100)
end

function fadeAlphaSliderOnValueChanged()
	if fadeAlphaSlider:GetValue() then 
		fadeAlphaSlider:SetValue(fadeAlphaSlider:GetValue())
		Options.fade.alpha=fadeAlphaSlider:GetValue()/100
		fadeAlphaStatus:SetText(Options.fade.alpha)
		gHUDResetAlpha();
	end
end
---------------------------------------------------------
function fadeAlphaInSliderOnLoad()
	fadeAlphaInSlider:SetMinMaxValues(0,200)
	local sliderMin, sliderMax = fadeAlphaInSlider:GetMinMaxValues()
	getglobal(fadeAlphaInSlider:GetName().."Low"):SetText(sliderMin/100)
	getglobal(fadeAlphaInSlider:GetName().."High"):SetText(sliderMax/100)
	fadeAlphaInSlider:SetOrientation("HORIZONTAL")
	fadeAlphaInSlider:SetValueStep(1)
	fadeAlphaInSlider:SetValue(Options.fade.inTime*100)
end

function fadeAlphaInSliderOnValueChanged()
	if fadeAlphaInSlider:GetValue() then 
		fadeAlphaInSlider:SetValue(fadeAlphaInSlider:GetValue())
		Options.fade.inTime=fadeAlphaInSlider:GetValue()/100
		fadeAlphaInStatus:SetText(Options.fade.inTime)
		--gHUDResetAlpha();
	end
end
---------------------------------------------------------
function fadeAlphaOutSliderOnLoad()
	fadeAlphaOutSlider:SetMinMaxValues(0,200)
	local sliderMin, sliderMax = fadeAlphaOutSlider:GetMinMaxValues()
	getglobal(fadeAlphaOutSlider:GetName().."Low"):SetText(sliderMin/100)
	getglobal(fadeAlphaOutSlider:GetName().."High"):SetText(sliderMax/100)
	fadeAlphaOutSlider:SetOrientation("HORIZONTAL")
	fadeAlphaOutSlider:SetValueStep(1)
	fadeAlphaOutSlider:SetValue(Options.fade.outTime*100)
end

function fadeAlphaOutSliderOnValueChanged()
	if fadeAlphaOutSlider:GetValue() then 
		fadeAlphaOutSlider:SetValue(fadeAlphaOutSlider:GetValue())
		Options.fade.outTime=fadeAlphaOutSlider:GetValue()/100
		fadeAlphaOutStatus:SetText(Options.fade.outTime)
		--gHUDResetAlpha();
	end
end