﻿
if (GetLocale() == "deDE") then
	gHUD_GOTW 	= "";
	gHUD_AB		= "";
	gHUD_HL		= "";
	gHUD_FH		= "";
	gHUD_LHW	= "";
elseif (GetLocale() == "frFR") then
	gHUD_GOTW 	= "";
	gHUD_AB		= "";
	gHUD_HL		= "";
	gHUD_FH		= "";
	gHUD_LHW	= "";
elseif (GetLocale == "zhCN") then 
	gHUD_GOTW 	= "";
	gHUD_AB		= "";
	gHUD_HL		= "";
	gHUD_FH		= "";
	gHUD_LHW	= "";
elseif (GetLocale() == "koKR") then
	gHUD_GOTW 	= "";
	gHUD_AB		= "";
	gHUD_HL		= "";
	gHUD_FH		= "";
	gHUD_LHW	= "";
elseif (GetLocale() == "zhTW") then
	gHUD_GOTW 	= "";
	gHUD_AB		= "";
	gHUD_HL		= "";
	gHUD_FH		= "";
	gHUD_LHW	= "";
else
	gHUD_GOTW 	= "Gift of the Wild";
	gHUD_AB		= "Arcane Brilliance";
	gHUD_HL		= "Holy Light";
	gHUD_FH		= "Lesser Heal";
	gHUD_LHW	= "Lesser Healing Wave";
end

function gHUDResetAlpha()
	--fUn:SetAlpha(1)
	HP_PLAYER_FRAME:SetAlpha(1)
	HP_TARGET_FRAME:SetAlpha(1)
	HP_TARGETTARGET_FRAME:SetAlpha(1)
	HP_PET_FRAME:SetAlpha(1)
	HP_PARTY1_FRAME:SetAlpha(1)
	HP_PARTY2_FRAME:SetAlpha(1)
	HP_PARTY3_FRAME:SetAlpha(1)
	HP_PARTY4_FRAME:SetAlpha(1)
	
	MP_PLAYER_FRAME:SetAlpha(1)
	MP_TARGET_FRAME:SetAlpha(1)
	MP_TARGETTARGET_FRAME:SetAlpha(1)
	MP_PET_FRAME:SetAlpha(1)
	MP_PARTY1_FRAME:SetAlpha(1)
	MP_PARTY2_FRAME:SetAlpha(1)
	MP_PARTY3_FRAME:SetAlpha(1)
	MP_PARTY4_FRAME:SetAlpha(1)
end

function gHUDFadeFrame(unit, deficit, tBar, tBG, fUn, a)
	
	local inRange = 0
	local playerClass, englishClass = UnitClass("player")
		
	if (englishClass=="DRUID") then
		rangespell = gHUD_GOTW
		if UnitExists(unit) and UnitIsVisible(unit) and UnitIsFriend("player",unit) then
		inRange = IsSpellInRange(rangespell,unit)
		end
	elseif (englishClass=="HUNTER") then
		if UnitExists(unit) and UnitIsVisible(unit) and UnitIsFriend("player",unit) then
		inRange = CheckInteractDistance(unit, 1)
		end
	elseif (englishClass=="MAGE") then
		rangespell = gHUD_AB
		if UnitExists(unit) and UnitIsVisible(unit) and UnitIsFriend("player",unit) then
		inRange = IsSpellInRange(rangespell,unit)
		end
	elseif (englishClass=="PALADIN") then
		rangespell = gHUD_HL
		if UnitExists(unit) and UnitIsVisible(unit) and UnitIsFriend("player",unit) then
		inRange = IsSpellInRange(rangespell,unit)
		end
	elseif (englishClass=="PRIEST") then
		rangespell = gHUD_FH
		if UnitExists(unit) and UnitIsVisible(unit) and UnitIsFriend("player",unit) then
		inRange = IsSpellInRange(rangespell,unit)
		end
	elseif (englishClass=="ROGUE") then
		if UnitExists(unit) and UnitIsVisible(unit) and UnitIsFriend("player",unit) then
		inRange = CheckInteractDistance(unit, 1)
		end
	elseif (englishClass=="SHAMAN") then
		rangespell = gHUD_LHW
		if UnitExists(unit) and UnitIsVisible(unit) and UnitIsFriend("player",unit) then
		inRange = IsSpellInRange(rangespell,unit)
		end
	elseif (englishClass=="WARLOCK") then
		if UnitExists(unit) and UnitIsVisible(unit) and UnitIsFriend("player",unit) then
		inRange = CheckInteractDistance(unit, 1)
		end
	elseif (englishClass=="WARRIOR") then
		if UnitExists(unit) and UnitIsVisible(unit) and UnitIsFriend("player",unit) then
		inRange = CheckInteractDistance(unit, 1)
		end
	end
	
	
	if (unit=="target") or (unit=="targettarget") then
		gHUDMPTypeTarget(unit, fUn);
		gHUDFlashStart(deficit, tBar, tBG, a);
	else
	--mana units
		if (UnitPowerType(unit)==0) then
			if ((Options.fade.active==1) and (Options.range.active==1)) then
				if (inRange==1) and ((UnitAffectingCombat(unit)==1) or (deficit ~= 0) or UnitIsUnit(unit, "target")) then
					gHUDFadeIn(deficit, tBar, tBG, fUn, a);
					--gHUDFlashStart(deficit, tBar, tBG, a);
				elseif (inRange~=1) and (not UnitIsFriend("player",unit) or UnitIsUnit(unit, "target")) then
					gHUDFadeIn(deficit, tBar, tBG, fUn, a);
					--gHUDFlashStart(deficit, tBar, tBG, a);
				else
					gHUDFadeOut(fUn,tBar,tBG,  a);
					--gHUDFlashStop(tBar,tBG);
				end
			end
			
			if ((Options.fade.active==1) and (Options.range.active==0)) then
				if ((UnitAffectingCombat(unit)==1) or (deficit ~= 0) or UnitIsUnit(unit, "target")) then
					gHUDFadeIn(deficit, tBar, tBG, fUn, a);
					--gHUDFlashStart(deficit, tBar, tBG, a);
				elseif (not UnitIsFriend("player",unit) or UnitIsUnit(unit, "target")) then
					gHUDFadeIn(deficit, tBar, tBG, fUn, a);
					--gHUDFlashStart(deficit, tBar, tBG, a);
				else
					gHUDFadeOut(fUn,tBar,tBG,  a);
					--gHUDFlashStop(tBar,tBG);
				end		
			end
			
			if ((Options.fade.active==0) and (Options.range.active==1)) then
				if (inRange==1) or UnitIsUnit(unit, "target") then
					gHUDFadeIn(deficit, tBar, tBG, fUn, a);
					--gHUDFlashStart(deficit, tBar, tBG, a);
				elseif (inRange~=1) and (not UnitIsFriend("player",unit) or UnitIsUnit(unit, "target")) then
					gHUDFadeIn(deficit, tBar, tBG, fUn, a);
					--gHUDFlashStart(deficit, tBar, tBG, a);
				else
					gHUDFadeOut(fUn,tBar,tBG, a);
				--	gHUDFlashStop(tBar,tBG);
				end
			end
			
			if ((Options.fade.active==0) and (Options.range.active==0) or UnitIsUnit(unit, "target")) then
				gHUDFadeIn(deficit, tBar, tBG, fUn, a);
				--gHUDFlashStart(deficit, tBar, tBG, a);
			end
			
		--no mana units	
		elseif (UnitPowerType(unit)~=0) then
			local def = (1-(UnitHealth(unit)/UnitHealthMax(unit)))
			
			if ((Options.fade.active==1) and (Options.range.active==1)) then
				if (inRange==1) and ((UnitAffectingCombat(unit)==1) or (def ~= 0) or UnitIsUnit(unit, "target")) then
					gHUDFadeIn(deficit, tBar, tBG, fUn, a);
				elseif (inRange~=1) and (not UnitIsFriend("player",unit) or UnitIsUnit(unit, "target")) then
					gHUDFadeIn(deficit, tBar, tBG, fUn, a);
				else
					gHUDFadeOut(fUn,tBar,tBG,  a);
				end
			end
			
			if ((Options.fade.active==1) and (Options.range.active==0)) then
				if ((UnitAffectingCombat(unit)==1) or (def ~= 0) or UnitIsUnit(unit, "target")) then
					gHUDFadeIn(deficit, tBar, tBG, fUn, a);
				elseif (not UnitIsFriend("player",unit) or UnitIsUnit(unit, "target")) then
					gHUDFadeIn(deficit, tBar, tBG, fUn, a);
				else
					gHUDFadeOut(fUn,tBar,tBG,  a);
				end		
			end
			
			if ((Options.fade.active==0) and (Options.range.active==1)) then
				if (inRange==1) or UnitIsUnit(unit, "target") then
					gHUDFadeIn(deficit, tBar, tBG, fUn, a);
				elseif (inRange~=1) and (not UnitIsFriend("player",unit) or UnitIsUnit(unit, "target")) then
					gHUDFadeIn(deficit, tBar, tBG, fUn, a);
				else
					gHUDFadeOut(fUn,tBar,tBG,  a);
				end
			end
			
			if ((Options.fade.active==0) and (Options.range.active==0) or UnitIsUnit(unit, "target")) then
				gHUDFadeIn(deficit, tBar, tBG, fUn, a);
			end
		end
	end		
end

function gHUDMPTypeTarget(unit, fUn)
	---[[
	if (fUn==MP_TARGET_FRAME) or (fUn==MP_TARGETTARGET_FRAME) then
		if (UnitIsPlayer(unit)==nil) 
		and (UnitPowerType(unit)==1)  then
			fUn:SetAlpha(0) 
		else
			fUn:SetAlpha(Colors.mp100.a) 
		end
	else 
		fUn:SetAlpha(Colors.hp100.a)
	end
	--]]
end

function gHUDFadeIn(deficit, tBar, tBG, fUn, a)
	if (fUn:GetAlpha()<=Options.fade.alpha) then
		UIFrameFadeIn(fUn, Options.fade.inTime, Options.fade.alpha, a)
	end
	gHUDFlashStart(deficit, tBar, tBG, a);
end

function gHUDFadeOut(fUn, tBar, tBG, a)
	if (fUn:GetAlpha()==a) then
		UIFrameFadeOut(fUn, Options.fade.outTime, a, Options.fade.alpha)
	end
	gHUDFlashStop(tBar,tBG);
end		

------------------------------------------------------------------------------------------------------

function gHUDFlashStart(deficit, tBar, tBG, a)
	local ftime = (Options.flash.In + Options.flash.Out + Options.flash.InHold + Options.flash.OutHold)
	
	if (Options.flash.Bar==1) then
		if (deficit > Options.flash.value) then
			UIFrameFlash(tBar, Options.flash.In, Options.flash.Out, ftime, false, Options.flash.OutHold, Options.flash.InHold)
		else
			if not tBar:IsShown() then
				tBar:Show()
			end
		end
	end
	
	if (Options.flash.BG==1) then
		if (deficit > Options.flash.value) then
			UIFrameFlash(tBG, Options.flash.In, Options.flash.Out, ftime, false, Options.flash.OutHold, Options.flash.InHold)
		else
			if not tBG:IsShown() then
				tBG:Show()
			end
		end
	end
end

function gHUDFlashStop(tBar,tBG)
	if UIFrameIsFlashing(tBar) then
		UIFrameFlashRemoveFrame(tBar)
		tBar:Show()
	end
	if UIFrameIsFlashing(tBG) then
		UIFrameFlashRemoveFrame(tBG)
		tBG:Show()
	end
end

