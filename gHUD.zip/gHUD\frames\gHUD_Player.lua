function Load_HP_Player()
	if (event=="ADDON_LOADED") and (arg1=="gHUD") then
	--load/unload blizz frame
		LoadOptions();
		BlizzOnLoad();
		gHUDInputOnLoad();
	--set position
		HP_PLAYER_FRAME:ClearAllPoints()
		HP_PLAYER_FRAME:SetPoint(Options.frame.anchor.a3, nil, Options.frame.anchor.a5, Options.player.frame.position.hpx, Options.player.frame.position.hpy)
	--texture
		HP_PLAYER_BAR_TEXTURE:SetTexture(Options.texture.BarHeight)
		
		HP_PLAYER_BG_TEXTURE1:SetHeight(Options.player.frame.bg.height)
		HP_PLAYER_BG_TEXTURE1:SetWidth(Options.player.frame.bg.width)
		HP_PLAYER_BG_TEXTURE2:SetHeight(Options.player.frame.bg.height-2)
		HP_PLAYER_BG_TEXTURE2:SetWidth(Options.player.frame.bg.width-2)
		
		HP_PLAYER_BAR:SetWidth(Options.player.frame.bar.width)
		HP_PLAYER_FRAME:SetHeight(Options.player.frame.bg.height)
		HP_PLAYER_FRAME:SetWidth(Options.player.frame.bg.width)
		
		HP_Player_Button:SetHeight(Options.player.frame.bg.height)
		HP_Player_Button:SetWidth(Options.player.frame.bg.width)
	--hp player max text
		HP_PLAYER_MAX:SetFont(Options.font.font, Options.font.size, Options.font.flags)
		HP_PLAYER_MAX:SetTextColor(0, 1, 0, 1)
	--hp player percent text
		HP_PLAYER_PERCENT:SetFont(Options.font.font, Options.font.size, Options.font.flags)
	--hp player deficit text
		HP_PLAYER_DEFICIT:SetFont(Options.font.font, Options.font.size, Options.font.flags)
	--hp player name text
		HP_PLAYER_NAME:SetFont(Options.font.font, Options.font.size, Options.font.flags)
	--font direction
		gHUDNameDirection();
		
		
	end
end

function Load_MP_Player()
	if (event=="ADDON_LOADED") and (arg1=="gHUD") then
	--set position
		MP_PLAYER_FRAME:ClearAllPoints()
		MP_PLAYER_FRAME:SetPoint(Options.frame.anchor.a4, nil, Options.frame.anchor.a5, Options.player.frame.position.mpx, Options.player.frame.position.mpy)
	--texture
		MP_PLAYER_BAR_TEXTURE:SetTexture(Options.texture.BarHeight)
		
		MP_PLAYER_BG_TEXTURE1:SetHeight(Options.player.frame.bg.height)
		MP_PLAYER_BG_TEXTURE1:SetWidth(Options.player.frame.bg.width)
		MP_PLAYER_BG_TEXTURE2:SetHeight(Options.player.frame.bg.height-2)
		MP_PLAYER_BG_TEXTURE2:SetWidth(Options.player.frame.bg.width-2)
		
		MP_PLAYER_BAR:SetWidth(Options.player.frame.bar.width)
		--MP_PLAYER_BAR:SetAlpha(Colors.mp100.a)
		
		MP_PLAYER_FRAME:SetHeight(Options.player.frame.bg.height)
		MP_PLAYER_FRAME:SetWidth(Options.player.frame.bg.width)
		
		MP_Player_Button:SetHeight(Options.player.frame.bg.height)
		MP_Player_Button:SetWidth(Options.player.frame.bg.width)
	--hp player max text
		MP_PLAYER_MAX:SetFont(Options.font.font, Options.font.size, Options.font.flags)
	--hp player percent text
		MP_PLAYER_PERCENT:SetFont(Options.font.font, Options.font.size, Options.font.flags)
	--hp player deficit text
		MP_PLAYER_DEFICIT:SetFont(Options.font.font, Options.font.size, Options.font.flags)
	end
end

function HP_Player(arg1)
	local unit = "player"
	local tBar = HP_PLAYER_BAR_TEXTURE
	local tBG  = HP_PLAYER_BG_TEXTURE1
	local tBG2 = HP_PLAYER_BG_TEXTURE2
	local fBut = HP_Player_Button
	local fBar = HP_PLAYER_BAR
	local fMax = HP_PLAYER_MAX
	local fPer = HP_PLAYER_PERCENT
	local fDef = HP_PLAYER_DEFICIT
	local fNam = HP_PLAYER_NAME
	
	local fUn = HP_PLAYER_FRAME
	
	this.TimeSinceLastUpdate=this.TimeSinceLastUpdate + arg1
	if (this.TimeSinceLastUpdate > Options.update) then	
	--Color
		ColorHealth(unit,tBar,tBG,tBG2,fPer,fDef, fUn)
	--selected
		HighlightSelectedUnit(unit,fBut)
	--Health
		local cur, max = UnitHealth(unit), UnitHealthMax(unit)
		local deficit = max-cur
	--hp bar
		if (cur==0) then
			fBar:SetHeight(1)
		else
			if (max>=cur) then
				fBar:SetHeight(Options.player.frame.bg.height/max*cur)
			else
				fBar:SetHeight(Options.player.frame.bg.height)
			end
		end
	--hp name text
		--UnitNames(unit,fNam)
		NamePlayer(unit,fNam)
	--hp max text
		MaxHealthPlayer(fMax,max,deficit,cur)	
	--hp percent text
		fPer:SetText(string.format("%.0f", (100/max*cur)) .."%")
	--hp deficit text
		DeficitHealthPlayer(cur,max,fDef,deficit)
		this.TimeSinceLastUpdate=0
	end
end
------------------------------------------------------------------------------------------------------------------
function MP_Player(arg1)
	local unit = "player"
	local tBar = MP_PLAYER_BAR_TEXTURE
	local tBG  = MP_PLAYER_BG_TEXTURE1
	local tBG2 = MP_PLAYER_BG_TEXTURE2
	local fBar = MP_PLAYER_BAR
	local fMax = MP_PLAYER_MAX
	local fPer = MP_PLAYER_PERCENT
	local fDef = MP_PLAYER_DEFICIT
	
	local fUn = MP_PLAYER_FRAME
	
	this.TimeSinceLastUpdate=this.TimeSinceLastUpdate + arg1
	if (this.TimeSinceLastUpdate > Options.update) then	
	--Color
		ColorMana(unit,tBar,tBG,tBG2,fPer,fDef, fUn)
	--Health
		local cur, max = UnitMana(unit), UnitManaMax(unit)
		local deficit = max-cur
	--mp bar
		if (cur==0) then
			fBar:SetHeight(1)
		else
			if (max>=cur) then
				fBar:SetHeight(Options.player.frame.bg.height/max*cur)
			else
				fBar:SetHeight(Options.player.frame.bg.height)
			end
		end
	--mp max text
		MaxManaPlayer(fMax, max, deficit, cur, unit)
		ColorPowerType(unit,fMax)
	--mp percent text
		fPer:SetText(string.format("%.0f", (100/max*cur)) .."%")
	--mp deficit text
		DeficitManaPlayer(cur,max,fDef,deficit,unit)
		this.TimeSinceLastUpdate=0
	end
end