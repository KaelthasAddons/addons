-- make them OnUpdate to hide them? 
	-- problem: if new target is selected the frame shows again
		--solution: call the frame:Hide() on target change?
function BlizzFramesCBOnLoad()
	if (Options.frame.blizz==0) then
		hideBlizzFrames:SetChecked(false)
	elseif (Options.frame.blizz==1) then
		hideBlizzFrames:SetChecked(true)
	end
end

function BlizzFramesCBOnClick()
	if (hideBlizzFrames:GetChecked(false)) then
		hideBlizzFrames:SetChecked(true)
		Options.frame.blizz=1
		
		PlayerFrame:Hide()
		PlayerFrame:UnregisterAllEvents();
		TargetFrame:Hide()		
		TargetFrame:UnregisterAllEvents();
		
		PartyMemberFrame1:Hide()
		PartyMemberFrame2:Hide()
		PartyMemberFrame3:Hide()
		PartyMemberFrame4:Hide()
		PartyMemberFrame1:UnregisterAllEvents();
		PartyMemberFrame2:UnregisterAllEvents();
		PartyMemberFrame3:UnregisterAllEvents();
		PartyMemberFrame4:UnregisterAllEvents();
		
	
	else hideBlizzFrames:SetChecked(false)
		Options.frame.blizz=0
		
		PlayerFrame:RegisterAllEvents();
		TargetFrame:RegisterAllEvents();
		PlayerFrame:Show()
		
		
	end	
end

function BlizzOnLoad()
	if (Options.frame.blizz==1) then
		
		PlayerFrame:Hide()
		PlayerFrame:UnregisterAllEvents();
		TargetFrame:Hide()		
		TargetFrame:UnregisterAllEvents();
		
		PartyMemberFrame1:Hide()
		PartyMemberFrame2:Hide()
		PartyMemberFrame3:Hide()
		PartyMemberFrame4:Hide()
		PartyMemberFrame1:UnregisterAllEvents();
		PartyMemberFrame2:UnregisterAllEvents();
		PartyMemberFrame3:UnregisterAllEvents();
		PartyMemberFrame4:UnregisterAllEvents();

	end
end