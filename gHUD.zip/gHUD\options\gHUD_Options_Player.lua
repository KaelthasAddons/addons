function playerNameCBOnLoad()
	if (Options.player.name.active==0) then
		playerNameCB:SetChecked(false)
	elseif (Options.player.name.active==1) then
		playerNameCB:SetChecked(true)
	end
end

function playerNameCBOnClick()
	if (playerNameCB:GetChecked(false)) then
		playerNameCB:SetChecked(true)
		Options.player.name.active=1
	else playerNameCB:SetChecked(false)
		Options.player.name.active=0
	end	
end


function playerHpXSliderOnLoad()
	playerHpXSlider:SetMinMaxValues(-1000,1000)
	local sliderMin, sliderMax = playerHpXSlider:GetMinMaxValues()
	getglobal(playerHpXSlider:GetName().."Low"):SetText(sliderMin)
	getglobal(playerHpXSlider:GetName().."High"):SetText(sliderMax)
	playerHpXSlider:SetOrientation("HORIZONTAL")
	playerHpXSlider:SetValueStep(1)
	playerHpXSlider:SetValue(Options.player.frame.position.hpx)
end

function playerHpXSliderOnValueChanged()
	if playerHpXSlider:GetValue() then 
		playerHpXSlider:SetValue(playerHpXSlider:GetValue())
		Options.player.frame.position.hpx=playerHpXSlider:GetValue()
		playerHpXStatus:SetText(Options.player.frame.position.hpx)
		
		HP_PLAYER_FRAME:ClearAllPoints()
		HP_PLAYER_FRAME:SetPoint(Options.frame.anchor.a3, nil, Options.frame.anchor.a5, Options.player.frame.position.hpx, Options.player.frame.position.hpy)
	end
end
---------------------------------------------------------
function playerHpYSliderOnLoad()
	playerHpYSlider:SetMinMaxValues(-1000,1000)
	local sliderMin, sliderMax = playerHpYSlider:GetMinMaxValues()
	getglobal(playerHpYSlider:GetName().."Low"):SetText(sliderMin)
	getglobal(playerHpYSlider:GetName().."High"):SetText(sliderMax)
	playerHpYSlider:SetOrientation("HORIZONTAL")
	playerHpYSlider:SetValueStep(1)
	playerHpYSlider:SetValue(Options.player.frame.position.hpy)
end

function playerHpYSliderOnValueChanged()
	if playerHpYSlider:GetValue() then 
		playerHpYSlider:SetValue(playerHpYSlider:GetValue())
		Options.player.frame.position.hpy=playerHpYSlider:GetValue()
		playerHpYStatus:SetText(Options.player.frame.position.hpy)
		
		HP_PLAYER_FRAME:ClearAllPoints()
		HP_PLAYER_FRAME:SetPoint(Options.frame.anchor.a3, nil, Options.frame.anchor.a5, Options.player.frame.position.hpx, Options.player.frame.position.hpy)
	end
end		
---------------------------------------------------------
function playerMpXSliderOnLoad()
	playerMpXSlider:SetMinMaxValues(-1000,1000)
	local sliderMin, sliderMax = playerMpXSlider:GetMinMaxValues()
	getglobal(playerMpXSlider:GetName().."Low"):SetText(sliderMin)
	getglobal(playerMpXSlider:GetName().."High"):SetText(sliderMax)
	playerMpXSlider:SetOrientation("HORIZONTAL")
	playerMpXSlider:SetValueStep(1)
	playerMpXSlider:SetValue(Options.player.frame.position.mpx)
end

function playerMpXSliderOnValueChanged()
	if playerMpXSlider:GetValue() then 
		playerMpXSlider:SetValue(playerMpXSlider:GetValue())
		Options.player.frame.position.mpx=playerMpXSlider:GetValue()
		playerMpXStatus:SetText(Options.player.frame.position.mpx)
		
		MP_PLAYER_FRAME:ClearAllPoints()
		MP_PLAYER_FRAME:SetPoint(Options.frame.anchor.a4, nil, Options.frame.anchor.a5, Options.player.frame.position.mpx, Options.player.frame.position.mpy)
	end
end
---------------------------------------------------------
function playerMpYSliderOnLoad()
	playerMpYSlider:SetMinMaxValues(-1000,1000)
	local sliderMin, sliderMax = playerMpYSlider:GetMinMaxValues()
	getglobal(playerMpYSlider:GetName().."Low"):SetText(sliderMin)
	getglobal(playerMpYSlider:GetName().."High"):SetText(sliderMax)
	playerMpYSlider:SetOrientation("HORIZONTAL")
	playerMpYSlider:SetValueStep(1)
	playerMpYSlider:SetValue(Options.player.frame.position.mpy)
end

function playerMpYSliderOnValueChanged()
	if playerMpYSlider:GetValue() then 
		playerMpYSlider:SetValue(playerMpYSlider:GetValue())
		Options.player.frame.position.mpy=playerMpYSlider:GetValue()
		playerMpYStatus:SetText(Options.player.frame.position.mpy)
		
		MP_PLAYER_FRAME:ClearAllPoints()
		MP_PLAYER_FRAME:SetPoint(Options.frame.anchor.a4, nil, Options.frame.anchor.a5, Options.player.frame.position.mpx, Options.player.frame.position.mpy)
	end
end	
---------------------------------------------------------
function playerDefMaxSliderOnLoad()
	playerDefMaxSlider:SetMinMaxValues(0,100)
	local sliderMin, sliderMax = playerDefMaxSlider:GetMinMaxValues()
	getglobal(playerDefMaxSlider:GetName().."Low"):SetText(sliderMin)
	getglobal(playerDefMaxSlider:GetName().."High"):SetText(sliderMax)
	playerDefMaxSlider:SetOrientation("HORIZONTAL")
	playerDefMaxSlider:SetValueStep(1)
	playerDefMaxSlider:SetValue(Options.player.deficit.max*100)
end

function playerDefMaxSliderOnValueChanged()
	if playerDefMaxSlider:GetValue() then 
		playerDefMaxSlider:SetValue(playerDefMaxSlider:GetValue())
		Options.player.deficit.max=playerDefMaxSlider:GetValue()/100
		playerDefMaxStatus:SetText(Options.player.deficit.max*100)
	end
end	
---------------------------------------------------------
function playerDefMinSliderOnLoad()
	playerDefMinSlider:SetMinMaxValues(0,100)
	local sliderMin, sliderMax = playerDefMinSlider:GetMinMaxValues()
	getglobal(playerDefMinSlider:GetName().."Low"):SetText(sliderMin)
	getglobal(playerDefMinSlider:GetName().."High"):SetText(sliderMax)
	playerDefMinSlider:SetOrientation("HORIZONTAL")
	playerDefMinSlider:SetValueStep(1)
	playerDefMinSlider:SetValue(Options.player.deficit.min*100)
end

function playerDefMinSliderOnValueChanged()
	if playerDefMinSlider:GetValue() then 
		playerDefMinSlider:SetValue(playerDefMinSlider:GetValue())
		Options.player.deficit.min=playerDefMinSlider:GetValue()/100
		playerDefMinStatus:SetText(Options.player.deficit.min*100)
	end
end	