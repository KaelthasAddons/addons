
function hpplayerFontDirectionCBOnLoad()
	if (Options.font.direction.hpplayer==0) then
		hpplayerFontDirectionCB:SetChecked(false)
	elseif (Options.font.direction.hpplayer==1) then
		hpplayerFontDirectionCB:SetChecked(true)
	end
end

function hpplayerFontDirectionCBOnClick()
	if (hpplayerFontDirectionCB:GetChecked(false)) then
		hpplayerFontDirectionCB:SetChecked(true)
		Options.font.direction.hpplayer=1
	else hpplayerFontDirectionCB:SetChecked(false)
		Options.font.direction.hpplayer=0
	end	
	gHUDNameDirection();
end
---------------------------------------------------------
function mpplayerFontDirectionCBOnLoad()
	if (Options.font.direction.mpplayer==0) then
		mpplayerFontDirectionCB:SetChecked(false)
	elseif (Options.font.direction.mpplayer==1) then
		mpplayerFontDirectionCB:SetChecked(true)
	end
end

function mpplayerFontDirectionCBOnClick()
	if (mpplayerFontDirectionCB:GetChecked(false)) then
		mpplayerFontDirectionCB:SetChecked(true)
		Options.font.direction.mpplayer=1
	else mpplayerFontDirectionCB:SetChecked(false)
		Options.font.direction.mpplayer=0
	end	
	gHUDNameDirection();
end
---------------------------------------------------------
function hptargetFontDirectionCBOnLoad()
	if (Options.font.direction.hptarget==0) then
		hptargetFontDirectionCB:SetChecked(false)
	elseif (Options.font.direction.hptarget==1) then
		hptargetFontDirectionCB:SetChecked(true)
	end
end

function hptargetFontDirectionCBOnClick()
	if (hptargetFontDirectionCB:GetChecked(false)) then
		hptargetFontDirectionCB:SetChecked(true)
		Options.font.direction.hptarget=1
	else hptargetFontDirectionCB:SetChecked(false)
		Options.font.direction.hptarget=0
	end	
	gHUDNameDirection();
end
---------------------------------------------------------
function mptargetFontDirectionCBOnLoad()
	if (Options.font.direction.mptarget==0) then
		mptargetFontDirectionCB:SetChecked(false)
	elseif (Options.font.direction.mptarget==1) then
		mptargetFontDirectionCB:SetChecked(true)
	end
end

function mptargetFontDirectionCBOnClick()
	if (mptargetFontDirectionCB:GetChecked(false)) then
		mptargetFontDirectionCB:SetChecked(true)
		Options.font.direction.mptarget=1
	else mptargetFontDirectionCB:SetChecked(false)
		Options.font.direction.mptarget=0
	end	
	gHUDNameDirection();
end
---------------------------------------------------------
function hppartyFontDirectionCBOnLoad()
	if (Options.font.direction.hpparty==0) then
		hppartyFontDirectionCB:SetChecked(false)
	elseif (Options.font.direction.hpparty==1) then
		hppartyFontDirectionCB:SetChecked(true)
	end
end

function hppartyFontDirectionCBOnClick()
	if (hppartyFontDirectionCB:GetChecked(false)) then
		hppartyFontDirectionCB:SetChecked(true)
		Options.font.direction.hpparty=1
	else hppartyFontDirectionCB:SetChecked(false)
		Options.font.direction.hpparty=0
	end	
	gHUDNameDirection();
end
---------------------------------------------------------
function mppartyFontDirectionCBOnLoad()
	if (Options.font.direction.mpparty==0) then
		mppartyFontDirectionCB:SetChecked(false)
	elseif (Options.font.direction.mpparty==1) then
		mppartyFontDirectionCB:SetChecked(true)
	end
end

function mppartyFontDirectionCBOnClick()
	if (mppartyFontDirectionCB:GetChecked(false)) then
		mppartyFontDirectionCB:SetChecked(true)
		Options.font.direction.mpparty=1
	else mppartyFontDirectionCB:SetChecked(false)
		Options.font.direction.mpparty=0
	end	
	gHUDNameDirection();
end
---------------------------------------------------------
function hppartypetFontDirectionCBOnLoad()
	if (Options.font.direction.hppartypet==0) then
		hppartypetFontDirectionCB:SetChecked(false)
	elseif (Options.font.direction.hppartypet==1) then
		hppartypetFontDirectionCB:SetChecked(true)
	end
end

function hppartypetFontDirectionCBOnClick()
	if (hppartypetFontDirectionCB:GetChecked(false)) then
		hppartypetFontDirectionCB:SetChecked(true)
		Options.font.direction.hppartypet=1
	else hppartypetFontDirectionCB:SetChecked(false)
		Options.font.direction.hppartypet=0
	end	
	gHUDNameDirection();
end
---------------------------------------------------------
function mppartypetFontDirectionCBOnLoad()
	if (Options.font.direction.mppartypet==0) then
		mppartypetFontDirectionCB:SetChecked(false)
	elseif (Options.font.direction.mppartypet==1) then
		mppartypetFontDirectionCB:SetChecked(true)
	end
end

function mppartypetFontDirectionCBOnClick()
	if (mppartypetFontDirectionCB:GetChecked(false)) then
		mppartypetFontDirectionCB:SetChecked(true)
		Options.font.direction.mppartypet=1
	else mppartypetFontDirectionCB:SetChecked(false)
		Options.font.direction.mppartypet=0
	end	
	gHUDNameDirection();
end
---------------------------------------------------------

function hppetFontDirectionCBOnLoad()
	if (Options.font.direction.hppet==0) then
		hppetFontDirectionCB:SetChecked(false)
	elseif (Options.font.direction.hppet==1) then
		hppetFontDirectionCB:SetChecked(true)
	end
end

function hppetFontDirectionCBOnClick()
	if (hppetFontDirectionCB:GetChecked(false)) then
		hppetFontDirectionCB:SetChecked(true)
		Options.font.direction.hppet=1
	else hppetFontDirectionCB:SetChecked(false)
		Options.font.direction.hppet=0
	end	
	gHUDNameDirection();
end
---------------------------------------------------------
function mppetFontDirectionCBOnLoad()
	if (Options.font.direction.mppet==0) then
		mppetFontDirectionCB:SetChecked(false)
	elseif (Options.font.direction.mppet==1) then
		mppetFontDirectionCB:SetChecked(true)
	end
end

function mppetFontDirectionCBOnClick()
	if (mppetFontDirectionCB:GetChecked(false)) then
		mppetFontDirectionCB:SetChecked(true)
		Options.font.direction.mppet=1
	else mppetFontDirectionCB:SetChecked(false)
		Options.font.direction.mppet=0
	end	
	gHUDNameDirection();
end
---------------------------------------------------------
function hpttFontDirectionCBOnLoad()
	if (Options.font.direction.hptt==0) then
		hpttFontDirectionCB:SetChecked(false)
	elseif (Options.font.direction.hptt==1) then
		hpttFontDirectionCB:SetChecked(true)
	end
end

function hpttFontDirectionCBOnClick()
	if (hpttFontDirectionCB:GetChecked(false)) then
		hpttFontDirectionCB:SetChecked(true)
		Options.font.direction.hptt=1
	else hpttFontDirectionCB:SetChecked(false)
		Options.font.direction.hptt=0
	end	
	gHUDNameDirection();
end
---------------------------------------------------------
function mpttFontDirectionCBOnLoad()
	if (Options.font.direction.mptt==0) then
		mpttFontDirectionCB:SetChecked(false)
	elseif (Options.font.direction.mptt==1) then
		mpttFontDirectionCB:SetChecked(true)
	end
end

function mpttFontDirectionCBOnClick()
	if (mpttFontDirectionCB:GetChecked(false)) then
		mpttFontDirectionCB:SetChecked(true)
		Options.font.direction.mptt=1
	else mpttFontDirectionCB:SetChecked(false)
		Options.font.direction.mptt=0
	end	
	gHUDNameDirection();
end
