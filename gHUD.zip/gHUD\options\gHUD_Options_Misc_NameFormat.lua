function playerNameFormatSliderOnLoad()
	playerNameFormatSlider:SetMinMaxValues(-1,40)
	local sliderMin, sliderMax = playerNameFormatSlider:GetMinMaxValues()
	getglobal(playerNameFormatSlider:GetName().."Low"):SetText(sliderMin)
	getglobal(playerNameFormatSlider:GetName().."High"):SetText(sliderMax)
	playerNameFormatSlider:SetOrientation("HORIZONTAL")
	playerNameFormatSlider:SetValueStep(1)
	playerNameFormatSlider:SetValue(Options.player.name.format)
end

function playerNameFormatSliderOnValueChanged()
	if playerNameFormatSlider:GetValue() then 
		playerNameFormatSlider:SetValue(playerNameFormatSlider:GetValue())
		Options.player.name.format=playerNameFormatSlider:GetValue()
		playerNameFormatStatus:SetText(Options.player.name.format)
	end
end