

--is it possible to create one frame and copy and transform it for the other frames?

gHUD = {};

function gHUDLoadEvents()
	this:RegisterEvent("ADDON_LOADED")
	this:RegisterEvent("PLAYER_TARGET_CHANGED")
	this:RegisterEvent("PLAYER_COMBO_POINTS")	

end

function gHUD:FrameCreator(framename,parent,point,rpoint,posx,posy,h,w,v,u)
	
	local frame;
	local value = {};
	
	--create anchor
	frame = CreateFrame("Frame", framename.."Anchor", parent);
	frame:ClearAllPoints();
	frame:SetHeight(h);
	frame:SetWidth(w);
	frame:SetFrameStrata("HIGH");
	frame:SetPoint(point,parent,rpoint, posx, posy);
	frame:Hide();
	value["anchor"] = frame;
	
	--create first layer
	frame = value["anchor"]:CreateTexture(framename.."Layer1", "BACKGROUND");
	frame:ClearAllPoints();
	frame:SetHeight(h);
	frame:SetWidth(w);
	frame:SetPoint("CENTER",framename.."Anchor","CENTER");
	frame:SetTexture(0,0,0,1)
	value["layer1"] = frame;
	
	--create second layer
	frame = value["anchor"]:CreateTexture(framename.."Layer2", "LOW");
	frame:ClearAllPoints();
	frame:SetHeight(h-v);
	frame:SetWidth(w-u);
	frame:SetPoint("CENTER",framename.."Layer1","CENTER");
	frame:SetTexture(1,0,0,1)
	value["layer2"] = frame;
		
end

function gHUD:FrameDestroyer()
	
end

function gHUDOnEvent()

	gHUD:CreateComboPoints();
	gHUDComboPoints();

end

function gHUD:CreateComboPoints()
	local playerClass, englishClass = UnitClass("player")

	if (event=="ADDON_LOADED") and (arg1=="gHUD") and (englishClass=="DRUID" or englishClass=="ROGUE") then
		--framename,parent,point,rpoint,posx,posy,h,w,v,u
		self.combopoint1 = self:FrameCreator("gHUDComboPoint1",HP_TARGET_FRAME,"BOTTOMLEFT","BOTTOMRIGHT",	5,0,30,16,4,12)
		self.combopoint2 = self:FrameCreator("gHUDComboPoint2",gHUDComboPoint1Anchor,"BOTTOM","TOP",		0,0,30,16,4,10)
		self.combopoint3 = self:FrameCreator("gHUDComboPoint3",gHUDComboPoint2Anchor,"BOTTOM","TOP",		0,0,30,16,4,8)
		self.combopoint4 = self:FrameCreator("gHUDComboPoint4",gHUDComboPoint3Anchor,"BOTTOM","TOP",		0,0,30,16,4,6)
		self.combopoint5 = self:FrameCreator("gHUDComboPoint5",gHUDComboPoint4Anchor,"BOTTOM","TOP",		0,0,30,16,4,4)
	end
end


--gHUD:FrameCreator(framename,parent,point,rpoint,posx,posy,h,w,v,u)

--create frames for bar bender
--get the amount of points from the heigth of the bar and the point height 

--[[
function gHUD:CreatePoint()
 
	local x1=0
	local y1=0
	local u1=5
	local v1=5
	
	local height=200
	
	local multiplier=1
 
 self.basepoint = self:FrameCreator("basepoint",UIParent,"CENTER","CENTER",0,0,5,5)

 self.point1 = self:FrameCreator("point1",basepoint,"CENTER","CENTER", 5,5,5,5)
 --self.point2 = self:FrameCreator("point2",basepoint,"CENTER","CENTER", u1*2,v1*2,u1,v1)
 --self.point3 = self:FrameCreator("point2",basepoint,"CENTER","CENTER", u1*3,v1*3,u1,v1)



end

--]]

