--[[
function BarOnMouseDown()
	
	if (arg1 == "LeftButton") then
		this:SetWidth(Options.player.frame.bar.width-4)
	end
end
function BarOnMouseUp()

	if (arg1 == "LeftButton") then
		this:SetWidth(Options.player.frame.bar.width)
	end
end
--]]

function gHUDOnMouseDown()
	this:SetWidth(Options.player.frame.bar.width-4)
end


function HPPlayerOnMouseDown()
	HP_PLAYER_BAR:SetWidth(Options.player.frame.bar.width-4)
end

function HPPlayerOnMouseUp()
	HP_PLAYER_BAR:SetWidth(Options.player.frame.bar.width)
end

--]]
function MPPlayerOnMouseDown()
	MP_PLAYER_BAR:SetWidth(Options.player.frame.bar.width-4)
end
function MPPlayerOnMouseUp()
	MP_PLAYER_BAR:SetWidth(Options.player.frame.bar.width)
end
---------------------------------------------------------
function HPParty1OnMouseDown()
	HP_PARTY1_BAR:SetWidth(Options.player.frame.bar.width-4)
end
function HPParty1OnMouseUp()
	HP_PARTY1_BAR:SetWidth(Options.player.frame.bar.width)
end
function MPParty1OnMouseDown()
	MP_PARTY1_BAR:SetWidth(Options.player.frame.bar.width-4)
end
function MPParty1OnMouseUp()
	MP_PARTY1_BAR:SetWidth(Options.player.frame.bar.width)
end
---------------------------------------------------------
function HPParty2OnMouseDown()
	HP_PARTY2_BAR:SetWidth(Options.player.frame.bar.width-4)
end
function HPParty2OnMouseUp()
	HP_PARTY2_BAR:SetWidth(Options.player.frame.bar.width)
end
function MPParty2OnMouseDown()
	MP_PARTY2_BAR:SetWidth(Options.player.frame.bar.width-4)
end
function MPParty2OnMouseUp()
	MP_PARTY2_BAR:SetWidth(Options.player.frame.bar.width)
end
---------------------------------------------------------
function HPParty3OnMouseDown()
	HP_PARTY3_BAR:SetWidth(Options.player.frame.bar.width-4)
end
function HPParty3OnMouseUp()
	HP_PARTY3_BAR:SetWidth(Options.player.frame.bar.width)
end
function MPParty3OnMouseDown()
	MP_PARTY3_BAR:SetWidth(Options.player.frame.bar.width-4)
end
function MPParty3OnMouseUp()
	MP_PARTY3_BAR:SetWidth(Options.player.frame.bar.width)
end
---------------------------------------------------------
function HPParty4OnMouseDown()
	HP_PARTY4_BAR:SetWidth(Options.player.frame.bar.width-4)
end
function HPParty4OnMouseUp()
	HP_PARTY4_BAR:SetWidth(Options.player.frame.bar.width)
end
function MPParty4OnMouseDown()
	MP_PARTY4_BAR:SetWidth(Options.player.frame.bar.width-4)
end
function MPParty4OnMouseUp()
	MP_PARTY4_BAR:SetWidth(Options.player.frame.bar.width)
end
---------------------------------------------------------
function HPPartyPet1OnMouseDown()
	HP_PARTYPET1_BAR:SetWidth(Options.player.frame.bar.width-4)
end
function HPPartyPet1OnMouseUp()
	HP_PARTYPET1_BAR:SetWidth(Options.player.frame.bar.width)
end
function MPPartyPet1OnMouseDown()
	MP_PARTYPET1_BAR:SetWidth(Options.player.frame.bar.width-4)
end
function MPPartyPet1OnMouseUp()
	MP_PARTYPET1_BAR:SetWidth(Options.player.frame.bar.width)
end
---------------------------------------------------------
function HPPartyPet2OnMouseDown()
	HP_PARTYPET2_BAR:SetWidth(Options.player.frame.bar.width-4)
end
function HPPartyPet2OnMouseUp()
	HP_PARTYPET2_BAR:SetWidth(Options.player.frame.bar.width)
end
function MPPartyPet2OnMouseDown()
	MP_PARTYPET2_BAR:SetWidth(Options.player.frame.bar.width-4)
end
function MPPartyPet2OnMouseUp()
	MP_PARTYPET2_BAR:SetWidth(Options.player.frame.bar.width)
end
---------------------------------------------------------
function HPPartyPet3OnMouseDown()
	HP_PARTYPET3_BAR:SetWidth(Options.player.frame.bar.width-4)
end
function HPPartyPet3OnMouseUp()
	HP_PARTYPET3_BAR:SetWidth(Options.player.frame.bar.width)
end
function MPPartyPet3OnMouseDown()
	MP_PARTYPET3_BAR:SetWidth(Options.player.frame.bar.width-4)
end
function MPPartyPet3OnMouseUp()
	MP_PARTYPET3_BAR:SetWidth(Options.player.frame.bar.width)
end
---------------------------------------------------------
function HPPartyPet4OnMouseDown()
	HP_PARTYPET4_BAR:SetWidth(Options.player.frame.bar.width-4)
end
function HPPartyPet4OnMouseUp()
	HP_PARTYPET4_BAR:SetWidth(Options.player.frame.bar.width)
end
function MPPartyPet4OnMouseDown()
	MP_PARTYPET4_BAR:SetWidth(Options.player.frame.bar.width-4)
end
function MPPartyPet4OnMouseUp()
	MP_PARTYPET4_BAR:SetWidth(Options.player.frame.bar.width)
end
---------------------------------------------------------

function HPTargetOnMouseDown()
	HP_TARGET_BAR:SetWidth(Options.player.frame.bar.width-4)
end
function HPTargetOnMouseUp()
	HP_TARGET_BAR:SetWidth(Options.player.frame.bar.width)
end
function MPTargetOnMouseDown()
	MP_TARGET_BAR:SetWidth(Options.player.frame.bar.width-4)
end
function MPTargetOnMouseUp()
	MP_TARGET_BAR:SetWidth(Options.player.frame.bar.width)
end
---------------------------------------------------------
function HPPetOnMouseDown()
	HP_PET_BAR:SetWidth(Options.player.frame.bar.width-4)
end
function HPPetOnMouseUp()
	HP_PET_BAR:SetWidth(Options.player.frame.bar.width)
end
function MPPetOnMouseDown()
	MP_PET_BAR:SetWidth(Options.player.frame.bar.width-4)
end
function MPPetOnMouseUp()
	MP_PET_BAR:SetWidth(Options.player.frame.bar.width)
end
---------------------------------------------------------
function HPTargetTargetOnMouseDown()
	HP_TARGETTARGET_BAR:SetWidth(Options.player.frame.bar.width-4)
end
function HPTargetTargetOnMouseUp()
	HP_TARGETTARGET_BAR:SetWidth(Options.player.frame.bar.width)
end
function MPTargetTargetOnMouseDown()
	MP_TARGETTARGET_BAR:SetWidth(Options.player.frame.bar.width-4)
end
function MPTargetTargetOnMouseUp()
	MP_TARGETTARGET_BAR:SetWidth(Options.player.frame.bar.width)
end