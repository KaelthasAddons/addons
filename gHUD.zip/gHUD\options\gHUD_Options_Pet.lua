function petShowCBLoad()
	if (Options.pet.frame.active==0) then
		showPetCB:SetChecked(false)
	elseif (Options.pet.frame.active==1) then
		showPetCB:SetChecked(true)
	end
end

function petShowCBOnClick()
	if (showPetCB:GetChecked(false)) then
		showPetCB:SetChecked(true)
		Options.pet.frame.active=1
	else showPetCB:SetChecked(false)
		Options.pet.frame.active=0
	end	
end
---------------------------------------------------------
function petNameCBOnLoad()
	if (Options.pet.name.active==0) then
		petNameCB:SetChecked(false)
	elseif (Options.pet.name.active==1) then
		petNameCB:SetChecked(true)
	end
end

function petNameCBOnClick()
	if (petNameCB:GetChecked(false)) then
		petNameCB:SetChecked(true)
		Options.pet.name.active=1
	else petNameCB:SetChecked(false)
		Options.pet.name.active=0
	end	
end


function petNameFormatSliderOnLoad()
	petNameFormatSlider:SetMinMaxValues(1,40)
	local sliderMin, sliderMax = petNameFormatSlider:GetMinMaxValues()
	getglobal(petNameFormatSlider:GetName().."Low"):SetText(sliderMin)
	getglobal(petNameFormatSlider:GetName().."High"):SetText(sliderMax)
	petNameFormatSlider:SetOrientation("HORIZONTAL")
	petNameFormatSlider:SetValueStep(1)
	petNameFormatSlider:SetValue(Options.pet.name.format)
end

function petNameFormatSliderOnValueChanged()
	if petNameFormatSlider:GetValue() then 
		petNameFormatSlider:SetValue(petNameFormatSlider:GetValue())
		Options.pet.name.format=petNameFormatSlider:GetValue()
		petNameFormatStatus:SetText(Options.pet.name.format)
	end
end
---------------------------------------------------------
function petHpXSliderOnLoad()
	petHpXSlider:SetMinMaxValues(-1000,1000)
	local sliderMin, sliderMax = petHpXSlider:GetMinMaxValues()
	getglobal(petHpXSlider:GetName().."Low"):SetText(sliderMin)
	getglobal(petHpXSlider:GetName().."High"):SetText(sliderMax)
	petHpXSlider:SetOrientation("HORIZONTAL")
	petHpXSlider:SetValueStep(1)
	petHpXSlider:SetValue(Options.pet.frame.position.hpx)
end

function petHpXSliderOnValueChanged()
	if petHpXSlider:GetValue() then 
		petHpXSlider:SetValue(petHpXSlider:GetValue())
		Options.pet.frame.position.hpx=petHpXSlider:GetValue()
		petHpXStatus:SetText(Options.pet.frame.position.hpx)
		
		HP_PET_FRAME:ClearAllPoints()
		HP_PET_FRAME:SetPoint("BOTTOMRIGHT", nil, "CENTER", Options.pet.frame.position.hpx, Options.pet.frame.position.hpy)
	end
end
---------------------------------------------------------
function petHpYSliderOnLoad()
	petHpYSlider:SetMinMaxValues(-1000,1000)
	local sliderMin, sliderMax = petHpYSlider:GetMinMaxValues()
	getglobal(petHpYSlider:GetName().."Low"):SetText(sliderMin)
	getglobal(petHpYSlider:GetName().."High"):SetText(sliderMax)
	petHpYSlider:SetOrientation("HORIZONTAL")
	petHpYSlider:SetValueStep(1)
	petHpYSlider:SetValue(Options.pet.frame.position.hpy)
end

function petHpYSliderOnValueChanged()
	if petHpYSlider:GetValue() then 
		petHpYSlider:SetValue(petHpYSlider:GetValue())
		Options.pet.frame.position.hpy=petHpYSlider:GetValue()
		petHpYStatus:SetText(Options.pet.frame.position.hpy)
		
		HP_PET_FRAME:ClearAllPoints()
		HP_PET_FRAME:SetPoint("BOTTOMRIGHT", nil, "CENTER", Options.pet.frame.position.hpx, Options.pet.frame.position.hpy)
	end
end
---------------------------------------------------------
function petMpXSliderOnLoad()
	petMpXSlider:SetMinMaxValues(-1000,1000)
	local sliderMin, sliderMax = petMpXSlider:GetMinMaxValues()
	getglobal(petMpXSlider:GetName().."Low"):SetText(sliderMin)
	getglobal(petMpXSlider:GetName().."High"):SetText(sliderMax)
	petMpXSlider:SetOrientation("HORIZONTAL")
	petMpXSlider:SetValueStep(1)
	petMpXSlider:SetValue(Options.pet.frame.position.mpx)
end

function petMpXSliderOnValueChanged()
	if petMpXSlider:GetValue() then 
		petMpXSlider:SetValue(petMpXSlider:GetValue())
		Options.pet.frame.position.mpx=petMpXSlider:GetValue()
		petMpXStatus:SetText(Options.pet.frame.position.mpx)
		
		MP_PET_FRAME:ClearAllPoints()
		MP_PET_FRAME:SetPoint("BOTTOMLEFT", nil, "CENTER", Options.pet.frame.position.mpx, Options.pet.frame.position.mpy)
	end
end
---------------------------------------------------------
function petMpYSliderOnLoad()
	petMpYSlider:SetMinMaxValues(-1000,1000)
	local sliderMin, sliderMax = petMpYSlider:GetMinMaxValues()
	getglobal(petMpYSlider:GetName().."Low"):SetText(sliderMin)
	getglobal(petMpYSlider:GetName().."High"):SetText(sliderMax)
	petMpYSlider:SetOrientation("HORIZONTAL")
	petMpYSlider:SetValueStep(1)
	petMpYSlider:SetValue(Options.pet.frame.position.mpy)
end

function petMpYSliderOnValueChanged()
	if petMpYSlider:GetValue() then 
		petMpYSlider:SetValue(petMpYSlider:GetValue())
		Options.pet.frame.position.mpy=petMpYSlider:GetValue()
		petMpYStatus:SetText(Options.pet.frame.position.mpy)
		
		MP_PET_FRAME:ClearAllPoints()
		MP_PET_FRAME:SetPoint("BOTTOMLEFT", nil, "CENTER", Options.pet.frame.position.mpx, Options.pet.frame.position.mpy)
	end
end
---------------------------------------------------------
function petDefMaxSliderOnLoad()
	petDefMaxSlider:SetMinMaxValues(0,100)
	local sliderMin, sliderMax = petDefMaxSlider:GetMinMaxValues()
	getglobal(petDefMaxSlider:GetName().."Low"):SetText(sliderMin)
	getglobal(petDefMaxSlider:GetName().."High"):SetText(sliderMax)
	petDefMaxSlider:SetOrientation("HORIZONTAL")
	petDefMaxSlider:SetValueStep(1)
	petDefMaxSlider:SetValue(Options.pet.deficit.max*100)
end

function petDefMaxSliderOnValueChanged()
	if petDefMaxSlider:GetValue() then 
		petDefMaxSlider:SetValue(petDefMaxSlider:GetValue())
		Options.pet.deficit.max=petDefMaxSlider:GetValue()/100
		petDefMaxStatus:SetText(Options.pet.deficit.max*100)
	end
end	
---------------------------------------------------------
function petDefMinSliderOnLoad()
	petDefMinSlider:SetMinMaxValues(0,100)
	local sliderMin, sliderMax = petDefMinSlider:GetMinMaxValues()
	getglobal(petDefMinSlider:GetName().."Low"):SetText(sliderMin)
	getglobal(petDefMinSlider:GetName().."High"):SetText(sliderMax)
	petDefMinSlider:SetOrientation("HORIZONTAL")
	petDefMinSlider:SetValueStep(1)
	petDefMinSlider:SetValue(Options.pet.deficit.min*100)
end

function petDefMinSliderOnValueChanged()
	if petDefMinSlider:GetValue() then 
		petDefMinSlider:SetValue(petDefMinSlider:GetValue())
		Options.pet.deficit.min=petDefMinSlider:GetValue()/100
		petDefMinStatus:SetText(Options.pet.deficit.min*100)
	end
end	