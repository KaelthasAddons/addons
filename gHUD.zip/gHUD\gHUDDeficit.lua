function DeficitHealthPlayer(cur,max,fDef,deficit)
--hp deficit text
	if (cur/max)>Options.player.deficit.max
	or (cur/max)<Options.player.deficit.min
	or UnitInParty("party1") and (Options.party.frame.active==1) then
		fDef:Hide() 
	else
		fDef:Show()
		--defmode deficit
		if (Options.player.deficit.mode==1) then
			if (Options.player.deficit.format==0) then
				fDef:SetText("-" ..deficit)
			elseif (Options.player.deficit.format==1) then		
				fDef:SetText(string.format("-%.1f", (deficit/1000)))
			end
			--defmode current
		elseif (Options.player.deficit.mode==0) then
			if (Options.player.deficit.format==0) then
				fDef:SetText(cur)
			elseif (Options.player.deficit.format==1) then		
				fDef:SetText(string.format("%.1f", (cur/1000)))
			end
		end
	end
end

function DeficitManaPlayer(cur,max,fDef,deficit,unit)
if (cur/max)>Options.player.deficit.max
		or (cur/max)<Options.player.deficit.min
		or UnitInParty("party1") and (Options.party.frame.active==1) then 
			fDef:Hide()
		else
			if (UnitPowerType(unit)==0) then
			fDef:Show()
			--defmode deficit
			if (Options.player.deficit.mode==1) then
				if (Options.player.deficit.format==0) then
					fDef:SetText("-" ..deficit)
				elseif (Options.player.deficit.format==1) then		
					fDef:SetText(string.format("-%.1f", (deficit/1000)))
				end
			--defmode current
			elseif (Options.player.deficit.mode==0) then
				if (Options.player.deficit.format==0) then
					fDef:SetText(UnitMana(unit))
				elseif (Options.player.deficit.format==1) then		
					fDef:SetText(string.format("%.1f", (cur/1000)))
				end
			end
		elseif (UnitPowerType(unit)==1)
		or (UnitPowerType(unit)==2)
		or (UnitPowerType(unit)==3) then
			fDef:Show()
			fDef:SetText(cur)
		end
	end
		
end

function DeficitHealthTarget(cur,max,fDef,deficit)
	if (cur/max)>Options.target.deficit.max
		or (cur/max)<Options.target.deficit.min then
			fDef:Hide() 
		else
			fDef:Show()
			--defmode deficit
		if (Options.target.deficit.mode==1) then
			if (Options.target.deficit.format==0) then
				fDef:SetText("-" ..deficit)
			elseif (Options.target.deficit.format==1) then		
				fDef:SetText(string.format("-%.1f", (deficit/1000)))
			end
			--defmode current
		elseif (Options.target.deficit.mode==0) then
			if (Options.target.deficit.format==0) then
				fDef:SetText(cur)
			elseif (Options.target.deficit.format==1) then		
				fDef:SetText(string.format("%.1f", (cur/1000)))
			end
		end
	end
end

function DeficitManaTarget(cur,max,fDef,deficit,unit)
	if (cur/max)>Options.target.deficit.max
		or (cur/max)<Options.target.deficit.min then 
			MP_TARGET_DEFICIT:Hide()
		else
			if (UnitPowerType(unit)==0) then
			fDef:Show()
			--defmode deficit
			if (Options.target.deficit.mode==1) then
				if (Options.target.deficit.format==0) then
					fDef:SetText("-" ..deficit)
				elseif (Options.target.deficit.format==1) then		
					fDef:SetText(string.format("-%.1f", (deficit/1000)))
				end
			--defmode current
			elseif (Options.target.deficit.mode==0) then
				if (Options.target.deficit.format==0) then
					fDef:SetText(UnitMana(unit))
				elseif (Options.target.deficit.format==1) then		
					fDef:SetText(string.format("%.1f", (cur/1000)))
				end
			end
		elseif (UnitPowerType(unit)==1)
		or (UnitPowerType(unit)==2)
		or (UnitPowerType(unit)==3) then
			fDef:Show()
			fDef:SetText(cur)
		end
	end
end




function DeficitHealthPet(cur,max,fDef,deficit)
	if (cur/max)>Options.pet.deficit.max
		or (cur/max)<Options.pet.deficit.min then
			fDef:Hide() 
		else
			fDef:Show()
			--defmode deficit
		if (Options.pet.deficit.mode==1) then
			if (Options.pet.deficit.format==0) then
				fDef:SetText("-" ..deficit)
			elseif (Options.pet.deficit.format==1) then		
				fDef:SetText(string.format("-%.1f", (deficit/1000)))
			end
			--defmode current
		elseif (Options.pet.deficit.mode==0) then
			if (Options.pet.deficit.format==0) then
				fDef:SetText(cur)
			elseif (Options.pet.deficit.format==1) then		
				fDef:SetText(string.format("%.1f", (cur/1000)))
			end
		end
	end
end

function DeficitManaPet(cur,max,fDef,deficit,unit)
	if (cur/max)>Options.pet.deficit.max
		or (cur/max)<Options.pet.deficit.min then 
			fDef:Hide()
		else
			if (UnitPowerType(unit)==0) then
			fDef:Show()
			--defmode deficit
			if (Options.pet.deficit.mode==1) then
				if (Options.pet.deficit.format==0) then
					fDef:SetText("-" ..deficit)
				elseif (Options.pet.deficit.format==1) then		
					fDef:SetText(string.format("-%.1f", (deficit/1000)))
				end
			--defmode current
			elseif (Options.pet.deficit.mode==0) then
				if (Options.pet.deficit.format==0) then
					fDef:SetText(UnitMana(unit))
				elseif (Options.pet.deficit.format==1) then		
					fDef:SetText(string.format("%.1f", (cur/1000)))
				end
			end
		elseif (UnitPowerType(unit)==1)
		or (UnitPowerType(unit)==2)
		or (UnitPowerType(unit)==3) then
			fDef:Show()
			fDef:SetText(cur)
		end
		end

end

function DeficitHealthTT(cur,max,fDef,deficit)
	if (cur/max)>Options.tt.deficit.max
		or (cur/max)<Options.tt.deficit.min then
			fDef:Hide() 
		else
			fDef:Show()
			--defmode deficit
		if (Options.tt.deficit.mode==1) then
			if (Options.tt.deficit.format==0) then
				fDef:SetText("-" ..deficit)
			elseif (Options.tt.deficit.format==1) then		
				fDef:SetText(string.format("-%.1f", (deficit/1000)))
			end
			--defmode current
		elseif (Options.tt.deficit.mode==0) then
			if (Options.tt.deficit.format==0) then
				fDef:SetText(cur)
			elseif (Options.tt.deficit.format==1) then		
				fDef:SetText(string.format("%.1f", (cur/1000)))
			end
		end
	end
end

function DeficitManaTT(cur,max,fDef,deficit,unit)
	if (cur/max)>Options.tt.deficit.max
		or (cur/max)<Options.tt.deficit.min then 
			fDef:Hide()
		else
			if (UnitPowerType(unit)==0) then
			fDef:Show()
			--defmode deficit
			if (Options.tt.deficit.mode==1) then
				if (Options.tt.deficit.format==0) then
					fDef:SetText("-" ..deficit)
				elseif (Options.tt.deficit.format==1) then		
					fDef:SetText(string.format("-%.1f", (deficit/1000)))
				end
			--defmode current
			elseif (Options.tt.deficit.mode==0) then
				if (Options.tt.deficit.format==0) then
					fDef:SetText(UnitMana(unit))
				elseif (Options.tt.deficit.format==1) then		
					fDef:SetText(string.format("%.1f", (cur/1000)))
				end
			end
		elseif (UnitPowerType(unit)==1)
		or (UnitPowerType(unit)==2)
		or (UnitPowerType(unit)==3) then
			fDef:Show()
			fDef:SetText(cur)
		end
	end
end

function DeficitHealthParty(cur,max,fDef,deficit)
	if (cur/max)>Options.party.deficit.max
	or (cur/max)<Options.party.deficit.min then
		fDef:Hide() 
	else
		fDef:Show()
		--defmode deficit
		if (Options.party.deficit.mode==1) then
			if (Options.party.deficit.format==0) then
				fDef:SetText("-" ..deficit)
			elseif (Options.party.deficit.format==1) then		
				fDef:SetText(string.format("-%.1f", (deficit/1000)))
			end
			--defmode current
		elseif (Options.party.deficit.mode==0) then
			if (Options.party.deficit.format==0) then
				fDef:SetText(cur)
			elseif (Options.party.deficit.format==1) then		
				fDef:SetText(string.format("%.1f", (cur/1000)))
			end
		end
	end
end



function DeficitManaParty(unit,cur,max,fDef,deficit)
	if (cur/max)>Options.party.deficit.max
	or (cur/max)<Options.party.deficit.min then 
		fDef:Hide()
	else
		if (UnitPowerType(unit)==0) then
			fDef:Show()
			--defmode deficit
			if (Options.party.deficit.mode==1) then
				if (Options.party.deficit.format==0) then
					fDef:SetText("-" ..deficit)
				elseif (Options.party.deficit.format==1) then		
					fDef:SetText(string.format("-%.1f", (deficit/1000)))
				end
			--defmode current
			elseif (Options.party.deficit.mode==0) then
				if (Options.party.deficit.format==0) then
					fDef:SetText(UnitMana(unit))
				elseif (Options.party.deficit.format==1) then		
					fDef:SetText(string.format("%.1f", (cur/1000)))
				end
			end
		elseif (UnitPowerType(unit)==1)
		or (UnitPowerType(unit)==2)
		or (UnitPowerType(unit)==3) then
			fDef:Show()
			fDef:SetText(cur)
		end
	end
end

