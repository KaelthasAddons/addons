function Load_HP_Target()
	if (event=="ADDON_LOADED") and (arg1=="gHUD") then	
	--set position
		HP_TARGET_FRAME:ClearAllPoints()
		HP_TARGET_FRAME:SetPoint("BOTTOMLEFT", nil, "CENTER", Options.target.frame.position.hpx, Options.target.frame.position.hpy)
	--texture
		HP_TARGET_BAR_TEXTURE:SetTexture(Options.texture.BarHeight)
		
		HP_TARGET_BG_TEXTURE1:SetHeight(Options.player.frame.bg.height)
		HP_TARGET_BG_TEXTURE1:SetWidth(Options.player.frame.bg.width)
		HP_TARGET_BG_TEXTURE2:SetHeight(Options.player.frame.bg.height-2)
		HP_TARGET_BG_TEXTURE2:SetWidth(Options.player.frame.bg.width-2)
		
		HP_TARGET_BAR:SetWidth(Options.player.frame.bar.width)
		HP_TARGET_FRAME:SetHeight(Options.player.frame.bg.height)
		HP_TARGET_FRAME:SetWidth(Options.player.frame.bg.width)
		
		HP_Target_Button:SetHeight(Options.player.frame.bg.height)
		HP_Target_Button:SetWidth(Options.player.frame.bg.width)
	--hp target max text
		HP_TARGET_MAX:SetFont(Options.font.font, Options.font.size, Options.font.flags)
		HP_TARGET_MAX:SetTextColor(0, 1, 0, 1)
	--hp target percent text
		HP_TARGET_PERCENT:SetFont(Options.font.font, Options.font.size, Options.font.flags)
	--hp target deficit text
		HP_TARGET_DEFICIT:SetFont(Options.font.font, Options.font.size, Options.font.flags)
	--hp target name text
		HP_TARGET_NAME:SetFont(Options.font.font, Options.font.size, Options.font.flags)
	end
end

function Load_MP_Target()
	if (event=="ADDON_LOADED") and (arg1=="gHUD") then	
	--set position
		MP_TARGET_FRAME:ClearAllPoints()
		MP_TARGET_FRAME:SetPoint("BOTTOMRIGHT", nil, "CENTER", Options.target.frame.position.mpx, Options.target.frame.position.mpy)
	--texture
		MP_TARGET_BAR_TEXTURE:SetTexture(Options.texture.BarHeight)
		
		MP_TARGET_BG_TEXTURE1:SetHeight(Options.player.frame.bg.height)
		MP_TARGET_BG_TEXTURE1:SetWidth(Options.player.frame.bg.width)
		MP_TARGET_BG_TEXTURE2:SetHeight(Options.player.frame.bg.height-2)
		MP_TARGET_BG_TEXTURE2:SetWidth(Options.player.frame.bg.width-2)
		
		MP_TARGET_BAR:SetWidth(Options.player.frame.bar.width)
		MP_TARGET_FRAME:SetHeight(Options.player.frame.bg.height)
		MP_TARGET_FRAME:SetWidth(Options.player.frame.bg.width)
		
		MP_Target_Button:SetHeight(Options.player.frame.bg.height)
		MP_Target_Button:SetWidth(Options.player.frame.bg.width)
	--hp target max text
		MP_TARGET_MAX:SetFont(Options.font.font, Options.font.size, Options.font.flags)
	--hp target percent text
		MP_TARGET_PERCENT:SetFont(Options.font.font, Options.font.size, Options.font.flags)
	--hp target deficit text
		MP_TARGET_DEFICIT:SetFont(Options.font.font, Options.font.size, Options.font.flags)
	end
end

function HP_Target(arg1)
	local unit = "target"
	local tBar = HP_TARGET_BAR_TEXTURE
	local tBG  = HP_TARGET_BG_TEXTURE1
	local tBG2 = HP_TARGET_BG_TEXTURE2
	local fBar = HP_TARGET_BAR
	local fMax = HP_TARGET_MAX
	local fPer = HP_TARGET_PERCENT
	local fDef = HP_TARGET_DEFICIT
	local fNam = HP_TARGET_NAME
	
	local fUn = HP_TARGET_FRAME
	
	
	
		this.TimeSinceLastUpdate=this.TimeSinceLastUpdate + arg1
		if (this.TimeSinceLastUpdate > Options.update) then
		if (UnitExists(unit)) then
			
			--Color
			ColorHealth(unit,tBar,tBG,tBG2,fPer,fDef, fUn)
			--MobHealth
				local cur, max, found
				local deficit
				if MobHealth3 then
					cur, max, found = MobHealth3:GetUnitHealth(unit, UnitHealth(unit), UnitHealthMax(unit))
					deficit = max-cur
				else
					cur, max = UnitHealth(unit), UnitHealthMax(unit)
					deficit = max-cur
				end
			--hp target bar
				if (cur==0) then
					fBar:SetHeight(1)
				else
					if (max>=cur) then
						fBar:SetHeight(Options.player.frame.bg.height/max*cur)
					else
						fBar:SetHeight(Options.player.frame.bg.height)
					end
				end
			--hp name text
				--UnitNames(unit,fNam)
				NameTarget(unit,fNam)
			--hp max text
				fMax:SetText(max)
			--hp percent text
				fPer:SetText(string.format("%.0f", (100/max*cur)) .."%")
			--hp deficit text
				DeficitHealthTarget(cur,max,fDef,deficit)
			end
			this.TimeSinceLastUpdate=0
		end
end

function MP_Target(arg1)
		local unit = "target"
		local tBar = MP_TARGET_BAR_TEXTURE
		local tBG  = MP_TARGET_BG_TEXTURE1
		local tBG2 = MP_TARGET_BG_TEXTURE2
		local fBar = MP_TARGET_BAR
		local fMax = MP_TARGET_MAX
		local fPer = MP_TARGET_PERCENT
		local fDef = MP_TARGET_DEFICIT
		
		local fUn = MP_TARGET_FRAME
		
		this.TimeSinceLastUpdate=this.TimeSinceLastUpdate + arg1
		if (this.TimeSinceLastUpdate > Options.update) then	
			if (UnitExists(unit)) then	
			--Color
				ColorMana(unit,tBar,tBG,tBG2,fPer,fDef, fUn)
			--Health
				local cur, max = UnitMana(unit), UnitManaMax(unit)
				local deficit = max-cur
			--targettarget
				--ManaFrameTargetTarget()
			--mp bar
				if (cur==0) then
					fBar:SetHeight(1)
				else
					if (max>=cur) then
						fBar:SetHeight(Options.player.frame.bg.height/max*cur)
					else
						fBar:SetHeight(Options.player.frame.bg.height)
					end
				end
			--mp max text
				fMax:SetText(max)
				ColorPowerType(unit,fMax)
			--mp percent text
				fPer:SetText(string.format("%.0f", (100/max*cur)) .."%")
			--mp deficit text
				DeficitManaTarget(cur,max,fDef,deficit,unit)
			end
			this.TimeSinceLastUpdate=0
		end
	
end

