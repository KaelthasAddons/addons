function partyShowCBLoad()
	if (Options.party.frame.active==0) then
		showPartyCB:SetChecked(false)
	elseif (Options.party.frame.active==1) then
		showPartyCB:SetChecked(true)
	end
end

function partyShowCBOnClick()
	if (showPartyCB:GetChecked(false)) then
		showPartyCB:SetChecked(true)
		Options.party.frame.active=1
	else showPartyCB:SetChecked(false)
		Options.party.frame.active=0
	end	
end
---------------------------------------------------------
function partyNameCBOnLoad()
	if (Options.party.name.active==0) then
		partyNameCB:SetChecked(false)
	elseif (Options.party.name.active==1) then
		partyNameCB:SetChecked(true)
	end
end

function partyNameCBOnClick()
	if (partyNameCB:GetChecked(false)) then
		partyNameCB:SetChecked(true)
		Options.party.name.active=1
	else partyNameCB:SetChecked(false)
		Options.party.name.active=0
	end	
end


function partyNameFormatSliderOnLoad()
	partyNameFormatSlider:SetMinMaxValues(1,40)
	local sliderMin, sliderMax = partyNameFormatSlider:GetMinMaxValues()
	getglobal(partyNameFormatSlider:GetName().."Low"):SetText(sliderMin)
	getglobal(partyNameFormatSlider:GetName().."High"):SetText(sliderMax)
	partyNameFormatSlider:SetOrientation("HORIZONTAL")
	partyNameFormatSlider:SetValueStep(1)
	partyNameFormatSlider:SetValue(Options.party.name.format)
end

function partyNameFormatSliderOnValueChanged()
	if partyNameFormatSlider:GetValue() then 
		partyNameFormatSlider:SetValue(partyNameFormatSlider:GetValue())
		Options.party.name.format=partyNameFormatSlider:GetValue()
		partyNameFormatStatus:SetText(Options.party.name.format)
	end
end
---------------------------------------------------------
function partyHpXSliderOnLoad()
	partyHpXSlider:SetMinMaxValues(-1000,1000)
	local sliderMin, sliderMax = partyHpXSlider:GetMinMaxValues()
	getglobal(partyHpXSlider:GetName().."Low"):SetText(sliderMin)
	getglobal(partyHpXSlider:GetName().."High"):SetText(sliderMax)
	partyHpXSlider:SetOrientation("HORIZONTAL")
	partyHpXSlider:SetValueStep(1)
	partyHpXSlider:SetValue(Options.party.frame.position.hpx)
end

function partyHpXSliderOnValueChanged()
	if partyHpXSlider:GetValue() then 
		partyHpXSlider:SetValue(partyHpXSlider:GetValue())
		Options.party.frame.position.hpx=partyHpXSlider:GetValue()
		partyHpXStatus:SetText(Options.party.frame.position.hpx)
		
		HP_PARTY1_FRAME:ClearAllPoints()
		HP_PARTY1_FRAME:SetPoint("BOTTOMRIGHT", nil, "CENTER", Options.party.frame.position.hpx, Options.party.frame.position.hpy)
	end
end
---------------------------------------------------------
function partyHpYSliderOnLoad()
	partyHpYSlider:SetMinMaxValues(-1000,1000)
	local sliderMin, sliderMax = partyHpYSlider:GetMinMaxValues()
	getglobal(partyHpYSlider:GetName().."Low"):SetText(sliderMin)
	getglobal(partyHpYSlider:GetName().."High"):SetText(sliderMax)
	partyHpYSlider:SetOrientation("HORIZONTAL")
	partyHpYSlider:SetValueStep(1)
	partyHpYSlider:SetValue(Options.party.frame.position.hpy)
end

function partyHpYSliderOnValueChanged()
	if partyHpYSlider:GetValue() then 
		partyHpYSlider:SetValue(partyHpYSlider:GetValue())
		Options.party.frame.position.hpy=partyHpYSlider:GetValue()
		partyHpYStatus:SetText(Options.party.frame.position.hpy)
		
		HP_PARTY1_FRAME:ClearAllPoints()
		HP_PARTY1_FRAME:SetPoint("BOTTOMRIGHT", nil, "CENTER", Options.party.frame.position.hpx, Options.party.frame.position.hpy)
	end
end
---------------------------------------------------------
function partyMpXSliderOnLoad()
	partyMpXSlider:SetMinMaxValues(-1000,1000)
	local sliderMin, sliderMax = partyMpXSlider:GetMinMaxValues()
	getglobal(partyMpXSlider:GetName().."Low"):SetText(sliderMin)
	getglobal(partyMpXSlider:GetName().."High"):SetText(sliderMax)
	partyMpXSlider:SetOrientation("HORIZONTAL")
	partyMpXSlider:SetValueStep(1)
	partyMpXSlider:SetValue(Options.party.frame.position.mpx)
end

function partyMpXSliderOnValueChanged()
	if partyMpXSlider:GetValue() then 
		partyMpXSlider:SetValue(partyMpXSlider:GetValue())
		Options.party.frame.position.mpx=partyMpXSlider:GetValue()
		partyMpXStatus:SetText(Options.party.frame.position.mpx)
		
		MP_PARTY1_FRAME:ClearAllPoints()
		MP_PARTY1_FRAME:SetPoint("BOTTOMLEFT", nil, "CENTER", Options.party.frame.position.mpx, Options.party.frame.position.mpy)
	end
end
---------------------------------------------------------
function partyMpYSliderOnLoad()
	partyMpYSlider:SetMinMaxValues(-1000,1000)
	local sliderMin, sliderMax = partyMpYSlider:GetMinMaxValues()
	getglobal(partyMpYSlider:GetName().."Low"):SetText(sliderMin)
	getglobal(partyMpYSlider:GetName().."High"):SetText(sliderMax)
	partyMpYSlider:SetOrientation("HORIZONTAL")
	partyMpYSlider:SetValueStep(1)
	partyMpYSlider:SetValue(Options.party.frame.position.mpy)
end

function partyMpYSliderOnValueChanged()
	if partyMpYSlider:GetValue() then 
		partyMpYSlider:SetValue(partyMpYSlider:GetValue())
		Options.party.frame.position.mpy=partyMpYSlider:GetValue()
		partyMpYStatus:SetText(Options.party.frame.position.mpy)
		
		MP_PARTY1_FRAME:ClearAllPoints()
		MP_PARTY1_FRAME:SetPoint("BOTTOMLEFT", nil, "CENTER", Options.party.frame.position.mpx, Options.party.frame.position.mpy)
	end
end
---------------------------------------------------------
function partyDefMaxSliderOnLoad()
	partyDefMaxSlider:SetMinMaxValues(0,100)
	local sliderMin, sliderMax = partyDefMaxSlider:GetMinMaxValues()
	getglobal(partyDefMaxSlider:GetName().."Low"):SetText(sliderMin)
	getglobal(partyDefMaxSlider:GetName().."High"):SetText(sliderMax)
	partyDefMaxSlider:SetOrientation("HORIZONTAL")
	partyDefMaxSlider:SetValueStep(1)
	partyDefMaxSlider:SetValue(Options.party.deficit.max*100)
end

function partyDefMaxSliderOnValueChanged()
	if partyDefMaxSlider:GetValue() then 
		partyDefMaxSlider:SetValue(partyDefMaxSlider:GetValue())
		Options.party.deficit.max=partyDefMaxSlider:GetValue()/100
		partyDefMaxStatus:SetText(Options.party.deficit.max*100)
	end
end	
---------------------------------------------------------
function partyDefMinSliderOnLoad()
	partyDefMinSlider:SetMinMaxValues(0,100)
	local sliderMin, sliderMax = partyDefMinSlider:GetMinMaxValues()
	getglobal(partyDefMinSlider:GetName().."Low"):SetText(sliderMin)
	getglobal(partyDefMinSlider:GetName().."High"):SetText(sliderMax)
	partyDefMinSlider:SetOrientation("HORIZONTAL")
	partyDefMinSlider:SetValueStep(1)
	partyDefMinSlider:SetValue(Options.party.deficit.min*100)
end

function partyDefMinSliderOnValueChanged()
	if partyDefMinSlider:GetValue() then 
		partyDefMinSlider:SetValue(partyDefMinSlider:GetValue())
		Options.party.deficit.min=partyDefMinSlider:GetValue()/100
		partyDefMinStatus:SetText(Options.party.deficit.min*100)
	end
end	
---------------------------------------------------------
function partyGapSliderOnLoad()
	partyGapSlider:SetMinMaxValues(1,Options.player.frame.bg.height/4)
	local sliderMin, sliderMax = partyGapSlider:GetMinMaxValues()
	getglobal(partyGapSlider:GetName().."Low"):SetText(sliderMin)
	getglobal(partyGapSlider:GetName().."High"):SetText(sliderMax)
	partyGapSlider:SetOrientation("HORIZONTAL")
	partyGapSlider:SetValueStep(1)
	partyGapSlider:SetValue(Options.party.frame.gap)
end

function partyGapSliderOnValueChanged()
	if partyGapSlider:GetValue() then 
		partyGapSlider:SetValue(partyGapSlider:GetValue())
		Options.party.frame.gap=partyGapSlider:GetValue()
		partyGapStatus:SetText(Options.party.frame.gap)
		
		HP_PARTY2_FRAME:ClearAllPoints()
		HP_PARTY2_FRAME:SetPoint("BOTTOM", HP_PARTY1_FRAME, "TOP", 0, Options.party.frame.gap)
		MP_PARTY2_FRAME:ClearAllPoints()
		MP_PARTY2_FRAME:SetPoint("BOTTOM", MP_PARTY1_FRAME, "TOP", 0, Options.party.frame.gap)
		
		HP_PARTY3_FRAME:ClearAllPoints()
		HP_PARTY3_FRAME:SetPoint("BOTTOM", HP_PARTY2_FRAME, "TOP", 0, Options.party.frame.gap)
		MP_PARTY3_FRAME:ClearAllPoints()
		MP_PARTY3_FRAME:SetPoint("BOTTOM", MP_PARTY2_FRAME, "TOP", 0, Options.party.frame.gap)
			
		HP_PARTY4_FRAME:ClearAllPoints()
		HP_PARTY4_FRAME:SetPoint("BOTTOM", HP_PARTY3_FRAME, "TOP", 0, Options.party.frame.gap)
		MP_PARTY4_FRAME:ClearAllPoints()
		MP_PARTY4_FRAME:SetPoint("BOTTOM", MP_PARTY3_FRAME, "TOP", 0, Options.party.frame.gap)
	end
end