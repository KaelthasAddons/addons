Default = {
	name	="gHUD",
	version	=10031,
	author	="Mahiro/Grognaz - Aegwynn(EU)",
}

Colors = {
	hp100 = {
		["r"]	=0,
		["g"]	=1,
		["b"]	=0,
		["a"]	=1,
	},
	hp50 = {
		["r"]	=1,
		["g"]	=1,
		["b"]	=0,
		["a"]	=1,
	},
	hp20 = {
		["r"]	=1,
		["g"]	=0,
		["b"]	=0,
		["a"]	=1,
	},
	mp100 = {
		["r"]	=0,
		["g"]	=0,
		["b"]	=1,
		["a"]	=1,
	},
	mp50 = {
		["r"]	=1,
		["g"]	=1,
		["b"]	=1,
		["a"]	=1,
	},
	mp20 = {
		["r"]	=1,
		["g"]	=0,
		["b"]	=0,
		["a"]	=1,
	},
}

function LoadOptions()

	if (Options==nil) then

		Options = {
			["version"] 	= 10031,
			["update"] 		= 0.05,
			--["standby"] 		=  0,
			["debug"] 		= 0,
			
			flash = {
				["In"] 		= 0.2,
				["OutHold"] = 0,
				["Out"] 	= 0.6,
				["InHold"] 	= 0,
				["BG"] 		= 0,
				["Bar"] 	= 0,
				["value"]	= 0.8
			},
			
			font = {
				["flags"] 	= "OUTLINE",	--OUTLINE, THICKOUTLINE and/or MONOCHROME
				["font"] 	= "Interface\\AddOns\\gHUD\\fonts\\comicbd.ttf",
				["size"] 	= 11,
				
				direction = {		--1 = left /0 = right
					["hpplayer"] = 1,
					["mpplayer"] = 0,
					["hptarget"] = 0,
					["mptarget"] = 1,
					["hpparty"] = 1,
					["mpparty"] = 0,
					["hppartypet"] = 1,
					["mppartypet"] = 0,
					["hppet"] = 1,
					["mppet"] = 0,
					["hptt"] = 0,
					["mptt"] = 1,
				},
				offset = {
					["x1"] = 0,
					["x2"] = 2,
					["y1"] = 0,
					["y2"] = 2,
					["y3"] = 4,		
				},
			},
			
			texture = {
				["BarHeightINV"] 	= "Interface\\AddOns\\gHUD\\texture\\barINV",
				["BarHeight"] 		= "Interface\\AddOns\\gHUD\\texture\\bar",
			},
			
			fade = {
				["active"] 	= 1,
				["outTime"] = 2,
				["inTime"] 	= 0.5,
				["alpha"] 	= 0.2,		
			},
			
			range ={	
				["active"] 	= 1,
				["alpha"]	= 0.5,
			},
			
			player = {
				deficit = {
					["active"] 	= 1,
					["format"] 	= 0,
					["mode"] 	= 1,
					["max"] 	= 0.99,
					["min"] 	= 0.01,
				},
				name = {
					["active"] 	= 1,
					["format"] 	= -1,
					["level"] 	= 1,
				},
				max = {
					mode = 1, 	-- value for max frame if player is grouped (0 max only, 1 deficit, 2 current)
				},
				frame = {
					["active"] 	= 1, 
					position = {
						["hpx"] = -305,
						["hpy"] = -250,
						["mpx"] = 305,
						["mpy"] = -250,
					},
					bg = {
						["height"] 	= 250,
						["width"] 	= 14,
					},
					bar = {
						["width"] 	= 14,
					},
				},
			},
			
			target = {
				deficit = {
					["active"] 	= 1,
					["format"] 	= 0,
					["mode"] 	= 1,
					["max"] 	= 0.99,
					["min"] 	= 0.01,
				},
				name = {
					["active"] 	= 1,
					["format"] 	= -1,
					["level"] 	= 1,
				},
				frame = {
					["active"] 	= 1, 
					position = {
						["hpx"] = -275,
						["hpy"] = -250,
						["mpx"] = 275,
						["mpy"] = -250,
					},
				},
			},
			
			party = {
				["hideinraid"] = 0,
				deficit = {
					["active"] 	= 1,
					["format"] 	= 0,
					["mode"] 	= 1,
					["max"] 	= 0.8,
					["min"] 	= 0.15,
				},
				name = {
					["active"] 	= 1,
					["format"] 	= 4,
					["level"] 	= 0,
				},
				frame = {
					["active"] 	= 1,
					["gap"] 	= 5,	
					position = {
						["hpx"]	= -330,
						["hpy"] = -250,
						["mpx"] = 330,
						["mpy"] = -250,
					},
				},
			},
			
			partypet = {
				["hideinraid"] = 0,
				name = {
					["active"] 	= 1,
					["format"] 	= 4,
					["level"] 	= 0,
				},
				frame = {
					["active"] 	= 1,
					--["gap"] 	= 5,	
					position = {
						["hpx"]	= -350,
						["hpy"] = -250,
						["mpx"] = 350,
						["mpy"] = -250,
					},
				},
			},
			
			pet = {
				deficit = {
					["active"] 	= 1,
					["format"] 	= 0,
					["mode"] 	= 1,
					["max"] 	= 0.99,
					["min"] 	= 0.01,
				},
				name = {
					["active"] 	= 1,
					["format"] 	= 4,
					["level"] 	= 1,
				},
				frame = {
					["active"] 	= 1,
					position = {
						["hpx"] = -360,
						["hpy"] = -250,
						["mpx"] = 360,
						["mpy"] = -250,
					},
				},
			},
			
			tt = {
				deficit = {
					["active"] 	= 1,
					["format"] 	= 0,
					["mode"] 	= 1,
					["max"] 	= 0.99,
					["min"] 	= 0.01,
				},
				name = {
					["active"] 	= 1,
					["format"] 	= 4,
					["level"] 	= 1,
				},
				frame = {
					["active"] 	= 1,
					position = {
						["hpx"] = -215,
						["hpy"] = -250,
						["mpx"] = 215,
						["mpy"] = -250,
					},
				},
			},	
			
			frame = {
				["blizz"] = 0,
				["input"] = 1,
				anchor = {
					["a1"] = "TOPRIGHT",
					["a2"] = "TOPLEFT",
					["a3"] = "BOTTOMRIGHT",
					["a4"] = "BOTTOMLEFT",	
					["a5"] = "CENTER",
					["a6"] = "RIGHT",
					["a7"] = "LEFT",
					["a8"] = "BOTTOM",
					["a9"] = "TOP",
				},
			},	
		}
	
	else 
		Options=Options
	end
	
	if (Options~=nil) and
	((Options.version=="10027") or (Options.version==10030)) then
		
		Options.partypet = {}
		Options.partypet.name = {}
		Options.partypet.frame = {}
		Options.partypet.frame.position = {}
		
		Options.frame.input = 1
		Options.partypet.hideinraid = 0
		Options.partypet.name.active = 1
		Options.partypet.name.format = 4
		Options.partypet.name.level = 0
		Options.partypet.frame.active = 1
		Options.partypet.frame.position.hpx = -350
		Options.partypet.frame.position.hpy = -250
		Options.partypet.frame.position.mpx = 350
		Options.partypet.frame.position.mpy = -250
		Options.font.direction.hppartypet = 1
		Options.font.direction.mppartypet = 0
		Options.version = 10031
	end
end

