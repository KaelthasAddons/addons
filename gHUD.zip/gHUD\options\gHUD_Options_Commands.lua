function gHUD_Command(cmd)
--list
	---[[	
	if (cmd=="help") then 
		DEFAULT_CHAT_FRAME:AddMessage("|cFF00FF00" ..Default.name .." - |rCommands:")
		DEFAULT_CHAT_FRAME:AddMessage("- /" ..Default.name)
		DEFAULT_CHAT_FRAME:AddMessage("- /" ..Default.name .." menu")
		DEFAULT_CHAT_FRAME:AddMessage("- /" ..Default.name .." status")
		DEFAULT_CHAT_FRAME:AddMessage("- /" ..Default.name .." fade (TEST)")
		DEFAULT_CHAT_FRAME:AddMessage("- /" ..Default.name .." range (TEST)")

	end
	--]]
--status
	if (cmd=="status") then
		DEFAULT_CHAT_FRAME:AddMessage("|cFF00FF00" ..Default.name .." - |rVersion: |cFFFF0000" ..Default.version)
		DEFAULT_CHAT_FRAME:AddMessage("|cFF00FF00" ..Default.name .." - |rAuthor: |cFFFF0000" ..Default.author)
	end
	
--menu
	if (cmd=="menu") or (cmd=="") then
		gHUDLoadMenu();
	end

--spellcheck
	if (cmd=="range") then
		if (Options.range.active==1) then
			Options.range.active=0
			DEFAULT_CHAT_FRAME:AddMessage("|cFF00FF00" ..Default.name .." - |rRange: |cFFFF0000" ..Options.range.active)
		elseif (Options.range.active==0) then
			Options.range.active=1
			DEFAULT_CHAT_FRAME:AddMessage("|cFF00FF00" ..Default.name .." - |rRange: |cFFFF0000" ..Options.range.active)
		end
	end
	
--fade	
	if (cmd=="fade") then
		if (Options.fade.active==1) then
			Options.fade.active=0
			DEFAULT_CHAT_FRAME:AddMessage("|cFF00FF00" ..Default.name .." - |rFade: |cFFFF0000" ..Options.fade.active)
		elseif (Options.fade.active==0) then
			Options.fade.active=1
			DEFAULT_CHAT_FRAME:AddMessage("|cFF00FF00" ..Default.name .." - |rFade: |cFFFF0000" ..Options.fade.active)		
		end
	end
	
--raid 
	if (cmd=="raid") then
		if (Options.party.hideinraid==1) then
			Options.party.hideinraid=0
			--DisableFrame(fUn)
			DEFAULT_CHAT_FRAME:AddMessage(Options.party.hideinraid)
		elseif (Options.party.hideinraid==0) then
			Options.party.hideinraid=1
			--EnableFrame(fUn)
			DEFAULT_CHAT_FRAME:AddMessage(Options.party.hideinraid)
		end
	end
	
--create frame
	if (cmd=="create") then
		--gHUD:FrameSetup()
	end
	if (cmd=="destroy") then
		gHUD:FrameDestroyer()
	end
	
end
------------------------------------------------------------------------------------------------------------------
 --mouse up
function gHUD_mouse_OnMouseUp()
		if (this.isMoving) then
		this:StopMovingOrSizing()
		this.isMoving = false
	end
end

--mouse down
function gHUD_mouse_OnMouseDown()
	if (this:IsMovable()) then	
		if ((not this.isLocked) or (this.isLocked == 0) and (arg1 == "LeftButton")) then
			this:StartMoving()
			this.isMoving = true
		end
	end
end

function gHUDShowAllFrames()

		if not (UnitExists("target")) then
			HP_TARGET_FRAME:Show()
			MP_TARGET_FRAME:Show()
			HP_TARGET_FRAME:SetAlpha(1)
			MP_TARGET_FRAME:SetAlpha(1)
		end
		if not (UnitExists("targettarget")) then
			HP_TARGETTARGET_FRAME:Show()
			MP_TARGETTARGET_FRAME:Show()
			HP_TARGETTARGET_FRAME:SetAlpha(1)
			MP_TARGETTARGET_FRAME:SetAlpha(1)
		end
		if not (UnitExists("pet")) then				
			HP_PET_FRAME:Show()
			MP_PET_FRAME:Show()		
			HP_PET_FRAME:SetAlpha(1)
			MP_PET_FRAME:SetAlpha(1)
		end
		if not (UnitExists("party1")) then	
			HP_PARTY1_FRAME:Show()
			MP_PARTY1_FRAME:Show()
			HP_PARTY1_FRAME:SetAlpha(1)
			MP_PARTY1_FRAME:SetAlpha(1)
		end
		if not (UnitExists("party2")) then	
			HP_PARTY2_FRAME:Show()
			MP_PARTY2_FRAME:Show()
			HP_PARTY2_FRAME:SetAlpha(1)
			MP_PARTY2_FRAME:SetAlpha(1)
		end
		if not (UnitExists("party3")) then	
			HP_PARTY3_FRAME:Show()
			MP_PARTY3_FRAME:Show()
			HP_PARTY3_FRAME:SetAlpha(1)
			MP_PARTY3_FRAME:SetAlpha(1)
		end
		if not (UnitExists("party4")) then	
			HP_PARTY4_FRAME:Show()
			MP_PARTY4_FRAME:Show()
			HP_PARTY4_FRAME:SetAlpha(1)
			MP_PARTY4_FRAME:SetAlpha(1)
		end
		if not (UnitExists("partypet1")) then	
			HP_PARTYPET1_FRAME:Show()
			MP_PARTYPET1_FRAME:Show()	
			HP_PARTYPET1_FRAME:SetAlpha(1)
			MP_PARTYPET1_FRAME:SetAlpha(1)
		end
		if not (UnitExists("partypet2")) then	
			HP_PARTYPET2_FRAME:Show()
			MP_PARTYPET2_FRAME:Show()
			HP_PARTYPET2_FRAME:SetAlpha(1)
			MP_PARTYPET2_FRAME:SetAlpha(1)
		end
		if not (UnitExists("partypet3")) then	
			HP_PARTYPET3_FRAME:Show()
			MP_PARTYPET3_FRAME:Show()
			HP_PARTYPET3_FRAME:SetAlpha(1)
			MP_PARTYPET3_FRAME:SetAlpha(1)
		end
		if not (UnitExists("partypet4")) then	
			HP_PARTYPET4_FRAME:Show()
			MP_PARTYPET4_FRAME:Show()
			HP_PARTYPET4_FRAME:SetAlpha(1)
			MP_PARTYPET4_FRAME:SetAlpha(1)
		end
end


function gHUDLoadMenu()
		gHUDMenu:Show();
				
		playerNameCBOnLoad();
		targetNameCBOnLoad();
		partyShowCBLoad();
		partyNameCBOnLoad();
		petShowCBLoad();
		petNameCBOnLoad();
		ttShowCBLoad();
		ttNameCBOnLoad();
		defFormatCBOnLoad();
		defModeCBOnLoad();
		flashBarCBOnLoad();
		flashBGCBOnLoad();
		
		playerNameFormatSliderOnLoad();
		bgHeightSliderOnLoad();
		barWidthSliderOnLoad();	
		playerHpXSliderOnLoad();
		playerHpYSliderOnLoad();
		playerMpXSliderOnLoad();
		playerMpYSliderOnLoad();
		playerDefMaxSliderOnLoad();
		playerDefMinSliderOnLoad();
		
		targetNameFormatSliderOnLoad();
		targetHpXSliderOnLoad();
		targetHpYSliderOnLoad();
		targetMpXSliderOnLoad();
		targetMpYSliderOnLoad();
		
		partyNameFormatSliderOnLoad();
		partyHpXSliderOnLoad();
		partyHpYSliderOnLoad();
		partyMpXSliderOnLoad();
		partyMpYSliderOnLoad();
		partyDefMaxSliderOnLoad();
		partyDefMinSliderOnLoad();
		partyGapSliderOnLoad();
		
		partypetNameFormatSliderOnLoad();
		partypetHpXSliderOnLoad();
		partypetHpYSliderOnLoad();
		partypetMpXSliderOnLoad();
		partypetMpYSliderOnLoad();
		
		petNameFormatSliderOnLoad();
		petHpXSliderOnLoad();
		petHpYSliderOnLoad();
		petMpXSliderOnLoad();
		petMpYSliderOnLoad();
		petDefMaxSliderOnLoad();
		petDefMinSliderOnLoad();
		
		ttNameFormatSliderOnLoad();
		ttHpXSliderOnLoad();
		ttHpYSliderOnLoad();
		ttMpXSliderOnLoad();
		ttMpYSliderOnLoad();
		ttDefMaxSliderOnLoad();
		ttDefMinSliderOnLoad();
		
		updateSliderOnLoad();
		fontSizeSliderOnLoad();
		fontFlagsSliderOnLoad();
		flashInSliderOnLoad();
		flashOutSliderOnLoad();
		flashHoldInSliderOnLoad();
		flashHoldOutSliderOnLoad();	
		fadeAlphaSliderOnLoad();
		fadeAlphaInSliderOnLoad();
		fadeAlphaOutSliderOnLoad();
		BlizzFramesCBOnLoad();
		gHUDLoadInput();
		
		hpplayerFontDirectionCBOnLoad();
		mpplayerFontDirectionCBOnLoad();
		hptargetFontDirectionCBOnLoad();
		mptargetFontDirectionCBOnLoad();
		hppartyFontDirectionCBOnLoad();
		mppartyFontDirectionCBOnLoad();
		
		hppartypetFontDirectionCBOnLoad();
		mppartypetFontDirectionCBOnLoad();
		
		hppetFontDirectionCBOnLoad();
		mppetFontDirectionCBOnLoad();
		hpttFontDirectionCBOnLoad();
		mpttFontDirectionCBOnLoad();
end