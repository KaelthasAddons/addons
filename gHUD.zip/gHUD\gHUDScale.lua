function ScalePartyFrame(tBG,tBG2,fBG,fBut)
	--if (InCombatLockdown()==nil) then
	
	local n = GetNumPartyMembers();
	local height = ((Options.player.frame.bg.height-(n-1)*Options.party.frame.gap)/n)
	tBG:SetHeight(height)
	tBG2:SetHeight(height-2)
	fBG:SetHeight(height)
	fBut:SetHeight(height)
end

function ScalePartyBar(fBar,max,cur)
--if (InCombatLockdown()==nil) then

	local n = GetNumPartyMembers();
	local height = ((Options.player.frame.bg.height-(n-1)*Options.party.frame.gap)/n)
	if (cur==0) then
		fBar:SetHeight(1)
	else
		if (max>=cur) then
			fBar:SetHeight(height/max*cur)
		else 
			fBar:SetHeight(height)
		end
	end
end
---------------------------------------------------------

function ScalePartyPetFrame(tBG,tBG2,fBG,fBut)
	--if (InCombatLockdown()==nil) then
	local n = GetNumPartyMembers();
	local height = ((Options.player.frame.bg.height-(n-1)*Options.party.frame.gap)/n)/2
	tBG:SetHeight(height)
	tBG2:SetHeight(height-2)
	fBG:SetHeight(height)
	fBut:SetHeight(height)
end

function ScalePartyPetBar(fBar,max,cur)
--if (InCombatLockdown()==nil) then

	local n = GetNumPartyMembers();
	local height = ((Options.player.frame.bg.height-(n-1)*Options.party.frame.gap)/n)/2
	if (cur==0) then
		fBar:SetHeight(1)
	else
		if (max>=cur) then
			fBar:SetHeight(height/max*cur)
		else 
			fBar:SetHeight(height)
		end
	end
end

function ScalePetFrames()
	
	HP_PARTYPET1_FRAME:Show()
	MP_PARTYPET1_FRAME:Show()	
	--HP_PARTYPET1_FRAME:SetAlpha(1)
	--MP_PARTYPET1_FRAME:SetAlpha(1)
	HP_PARTYPET2_FRAME:Show()
	MP_PARTYPET2_FRAME:Show()
	--HP_PARTYPET2_FRAME:SetAlpha(1)
	--MP_PARTYPET2_FRAME:SetAlpha(1)
	HP_PARTYPET3_FRAME:Show()
	MP_PARTYPET3_FRAME:Show()
	--HP_PARTYPET3_FRAME:SetAlpha(1)
	--MP_PARTYPET3_FRAME:SetAlpha(1)
	HP_PARTYPET4_FRAME:Show()
	MP_PARTYPET4_FRAME:Show()
	--HP_PARTYPET4_FRAME:SetAlpha(1)
	--MP_PARTYPET4_FRAME:SetAlpha(1)
		
end