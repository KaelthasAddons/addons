
--[[
"PLAYER_COMBO_POINTS" Category: Player,Combat  
   Fired when your combo points change. 

arg1
always "player", not the number of combo points you have. 
Use the GetComboPoints() API to get the exact number of combo points you have. 

GetComboPoints() 0-5

 --]]

function gHUDComboPoints()
	local playerClass, englishClass = UnitClass("player")

	if (event=="PLAYER_COMBO_POINTS") and (englishClass=="DRUID" or englishClass=="ROGUE") then 
		if (GetComboPoints("player")==0) then
			gHUDComboPoint1Anchor:Hide();
			gHUDComboPoint2Anchor:Hide();
			gHUDComboPoint3Anchor:Hide();
			gHUDComboPoint4Anchor:Hide();
			gHUDComboPoint5Anchor:Hide();
			
		elseif (GetComboPoints("player")==1) then
			gHUDComboPoint1Anchor:Show();
			gHUDComboPoint2Anchor:Hide();
			gHUDComboPoint3Anchor:Hide();
			gHUDComboPoint4Anchor:Hide();
			gHUDComboPoint5Anchor:Hide();
			
		elseif (GetComboPoints("player")==2) then
			gHUDComboPoint1Anchor:Show();
			gHUDComboPoint2Anchor:Show();
			gHUDComboPoint3Anchor:Hide();
			gHUDComboPoint4Anchor:Hide();
			gHUDComboPoint5Anchor:Hide();
			
		elseif (GetComboPoints("player")==3) then
			gHUDComboPoint1Anchor:Show();
			gHUDComboPoint2Anchor:Show();
			gHUDComboPoint3Anchor:Show();
			gHUDComboPoint4Anchor:Hide();
			gHUDComboPoint5Anchor:Hide();
			
		elseif (GetComboPoints("player")==4) then
			gHUDComboPoint1Anchor:Show();
			gHUDComboPoint2Anchor:Show();
			gHUDComboPoint3Anchor:Show();
			gHUDComboPoint4Anchor:Show();
			gHUDComboPoint5Anchor:Hide();
			
		elseif (GetComboPoints("player")==5) then
			gHUDComboPoint1Anchor:Show();
			gHUDComboPoint2Anchor:Show();
			gHUDComboPoint3Anchor:Show();
			gHUDComboPoint4Anchor:Show();
			gHUDComboPoint5Anchor:Show();
		end
	end
end
	
