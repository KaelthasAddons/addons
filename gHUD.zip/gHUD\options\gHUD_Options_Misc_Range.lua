function rangeCBOnLoad()
	if (Options.range.active==0) then
		rangeCB:SetChecked(false)
	elseif (Options.range.active==1) then
		rangeCB:SetChecked(true)
	end
end

function rangeCBOnClick()
	if (rangeCB:GetChecked(false)) then
		rangeCB:SetChecked(true)
		Options.range.active=1
	else rangeCB:SetChecked(false)
		Options.range.active=0
	end	
end