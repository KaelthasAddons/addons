
---------------------------------------------------------

function FlashStart(a,tBar,tBG,tBG2)
	--reset for bg alpha
	if ((not UIFrameIsFlashing(tBG)) and (tBG:GetAlpha()~=1))
	or ((not UIFrameIsFlashing(tBG2)) and (tBG2:GetAlpha()~=1)) then
		tBG:SetAlpha(1)
		tBG2:SetAlpha(1)
		tBar:SetAlpha(1)
	end
	
	if (Options.flash.Bar==1) then
		UIFrameFlash(tBar, Options.flash.In, Options.flash.Out, (Options.flash.In + Options.flash.Out + Options.flash.InHold + Options.flash.OutHold), false, Options.flash.OutHold, Options.flash.InHold)
	end
	if (Options.flash.BG==1) then
		UIFrameFlash(tBG, Options.flash.In, Options.flash.Out, (Options.flash.In + Options.flash.Out + Options.flash.InHold + Options.flash.OutHold), false, Options.flash.OutHold, Options.flash.InHold)
	end	
end

function FlashStop(tBar,tBG)
	if UIFrameIsFlashing(tBar) then
		UIFrameFlashRemoveFrame(tBar)	
	elseif UIFrameIsFlashing(tBG) then
		UIFrameFlashRemoveFrame(tBG)
	end
end

function ShowAfterFlash(a,tBar,tBG,tBG2)
	if ((tBar:IsVisible()==nil) 
	or (tBG:IsVisible()==nil)
	or (tBG2:IsVisible()==nil))
	then
		tBar:Show()
		tBar:SetAlpha(a)
		tBG:Show()
		tBG:SetAlpha(a)
		tBG2:Show()
		tBG2:SetAlpha(a)
	end
end


