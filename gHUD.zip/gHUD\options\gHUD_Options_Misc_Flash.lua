function flashBarCBOnLoad()
	if (Options.flash.Bar==0) then
		flashBarCB:SetChecked(false)
	elseif (Options.flash.Bar==1) then
		flashBarCB:SetChecked(true)
	end
end

function flashBarCBOnClick()
	if (flashBarCB:GetChecked(false)) then
		flashBarCB:SetChecked(true)
		Options.flash.Bar=1
	else flashBarCB:SetChecked(false)
		Options.flash.Bar=0
	end	
end
---------------------------------------------------------
function flashBGCBOnLoad()
	if (Options.flash.BG==0) then
		flashBGCB:SetChecked(false)
	elseif (Options.flash.BG==1) then
		flashBGCB:SetChecked(true)
	end
end

function flashBGCBOnClick()
	if (flashBGCB:GetChecked(false)) then
		flashBGCB:SetChecked(true)
		Options.flash.BG=1
	else flashBGCB:SetChecked(false)
		Options.flash.BG=0
	end	
end


function flashInSliderOnLoad()
	flashInSlider:SetMinMaxValues(0,200)
	local sliderMin, sliderMax = flashInSlider:GetMinMaxValues()
	getglobal(flashInSlider:GetName().."Low"):SetText(sliderMin/100)
	getglobal(flashInSlider:GetName().."High"):SetText(sliderMax/100)
	flashInSlider:SetOrientation("HORIZONTAL")
	flashInSlider:SetValueStep(1)
	flashInSlider:SetValue(Options.flash.In*100)
end

function flashInSliderOnValueChanged()
	if flashInSlider:GetValue() then 
		flashInSlider:SetValue(flashInSlider:GetValue())
		Options.flash.In=flashInSlider:GetValue()/100
		flashInStatus:SetText(Options.flash.In)
	end
end
---------------------------------------------------------
function flashOutSliderOnLoad()
	flashOutSlider:SetMinMaxValues(0,200)
	local sliderMin, sliderMax = flashOutSlider:GetMinMaxValues()
	getglobal(flashOutSlider:GetName().."Low"):SetText(sliderMin/100)
	getglobal(flashOutSlider:GetName().."High"):SetText(sliderMax/100)
	flashOutSlider:SetOrientation("HORIZONTAL")
	flashOutSlider:SetValueStep(1)
	flashOutSlider:SetValue(Options.flash.Out*100)
end

function flashOutSliderOnValueChanged()
	if flashOutSlider:GetValue() then 
		flashOutSlider:SetValue(flashOutSlider:GetValue())
		Options.flash.Out=flashOutSlider:GetValue()/100
		flashOutStatus:SetText(Options.flash.Out)
	end
end
---------------------------------------------------------
function flashHoldInSliderOnLoad()
	flashHoldInSlider:SetMinMaxValues(0,200)
	local sliderMin, sliderMax = flashHoldInSlider:GetMinMaxValues()
	getglobal(flashHoldInSlider:GetName().."Low"):SetText(sliderMin/100)
	getglobal(flashHoldInSlider:GetName().."High"):SetText(sliderMax/100)
	flashHoldInSlider:SetOrientation("HORIZONTAL")
	flashHoldInSlider:SetValueStep(1)
	flashHoldInSlider:SetValue(Options.flash.InHold*100)
end

function flashHoldInSliderOnValueChanged()
	if flashHoldInSlider:GetValue() then 
		flashHoldInSlider:SetValue(flashHoldInSlider:GetValue())
		Options.flash.InHold=flashHoldInSlider:GetValue()/100
		flashHoldInStatus:SetText(Options.flash.InHold)
	end
end
---------------------------------------------------------
function flashHoldOutSliderOnLoad()
	flashHoldOutSlider:SetMinMaxValues(0,200)
	local sliderMin, sliderMax = flashHoldOutSlider:GetMinMaxValues()
	getglobal(flashHoldOutSlider:GetName().."Low"):SetText(sliderMin/100)
	getglobal(flashHoldOutSlider:GetName().."High"):SetText(sliderMax/100)
	flashHoldOutSlider:SetOrientation("HORIZONTAL")
	flashHoldOutSlider:SetValueStep(1)
	flashHoldOutSlider:SetValue(Options.flash.OutHold*100)
end

function flashHoldOutSliderOnValueChanged()
	if flashHoldOutSlider:GetValue() then 
		flashHoldOutSlider:SetValue(flashHoldOutSlider:GetValue())
		Options.flash.OutHold=flashHoldOutSlider:GetValue()/100
		flashHoldOutStatus:SetText(Options.flash.OutHold)
	end
end