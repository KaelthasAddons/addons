function ttShowCBLoad()
	if (Options.tt.frame.active==0) then
		showTTCB:SetChecked(false)
	elseif (Options.tt.frame.active==1) then
		showTTCB:SetChecked(true)
	end
end

function ttShowCBOnClick()
	if (showTTCB:GetChecked(false)) then
		showTTCB:SetChecked(true)
		Options.tt.frame.active=1
	else showTTCB:SetChecked(false)
		Options.tt.frame.active=0
	end	
end
---------------------------------------------------------
function ttNameCBOnLoad()
	if (Options.tt.name.active==0) then
		ttNameCB:SetChecked(false)
	elseif (Options.tt.name.active==1) then
		ttNameCB:SetChecked(true)
	end
end

function ttNameCBOnClick()
	if (ttNameCB:GetChecked(false)) then
		ttNameCB:SetChecked(true)
		Options.tt.name.active=1
	else ttNameCB:SetChecked(false)
		Options.tt.name.active=0
	end	
end


function ttNameFormatSliderOnLoad()
	ttNameFormatSlider:SetMinMaxValues(1,40)
	local sliderMin, sliderMax = ttNameFormatSlider:GetMinMaxValues()
	getglobal(ttNameFormatSlider:GetName().."Low"):SetText(sliderMin)
	getglobal(ttNameFormatSlider:GetName().."High"):SetText(sliderMax)
	ttNameFormatSlider:SetOrientation("HORIZONTAL")
	ttNameFormatSlider:SetValueStep(1)
	ttNameFormatSlider:SetValue(Options.tt.name.format)
end

function ttNameFormatSliderOnValueChanged()
	if ttNameFormatSlider:GetValue() then 
		ttNameFormatSlider:SetValue(ttNameFormatSlider:GetValue())
		Options.tt.name.format=ttNameFormatSlider:GetValue()
		ttNameFormatStatus:SetText(Options.tt.name.format)
	end
end
---------------------------------------------------------
function ttHpXSliderOnLoad()
	ttHpXSlider:SetMinMaxValues(-1000,1000)
	local sliderMin, sliderMax = ttHpXSlider:GetMinMaxValues()
	getglobal(ttHpXSlider:GetName().."Low"):SetText(sliderMin)
	getglobal(ttHpXSlider:GetName().."High"):SetText(sliderMax)
	ttHpXSlider:SetOrientation("HORIZONTAL")
	ttHpXSlider:SetValueStep(1)
	ttHpXSlider:SetValue(Options.tt.frame.position.hpx)
end

function ttHpXSliderOnValueChanged()
	if ttHpXSlider:GetValue() then 
		ttHpXSlider:SetValue(ttHpXSlider:GetValue())
		Options.tt.frame.position.hpx=ttHpXSlider:GetValue()
		ttHpXStatus:SetText(Options.tt.frame.position.hpx)
		
		HP_TARGETTARGET_FRAME:ClearAllPoints()
		HP_TARGETTARGET_FRAME:SetPoint("BOTTOMLEFT", nil, "CENTER", Options.tt.frame.position.hpx, Options.tt.frame.position.hpy)
	end
end
---------------------------------------------------------
function ttHpYSliderOnLoad()
	ttHpYSlider:SetMinMaxValues(-1000,1000)
	local sliderMin, sliderMax = ttHpYSlider:GetMinMaxValues()
	getglobal(ttHpYSlider:GetName().."Low"):SetText(sliderMin)
	getglobal(ttHpYSlider:GetName().."High"):SetText(sliderMax)
	ttHpYSlider:SetOrientation("HORIZONTAL")
	ttHpYSlider:SetValueStep(1)
	ttHpYSlider:SetValue(Options.tt.frame.position.hpy)
end

function ttHpYSliderOnValueChanged()
	if ttHpYSlider:GetValue() then 
		ttHpYSlider:SetValue(ttHpYSlider:GetValue())
		Options.tt.frame.position.hpy=ttHpYSlider:GetValue()
		ttHpYStatus:SetText(Options.tt.frame.position.hpy)
		
		HP_TARGETTARGET_FRAME:ClearAllPoints()
		HP_TARGETTARGET_FRAME:SetPoint("BOTTOMLEFT", nil, "CENTER", Options.tt.frame.position.hpx, Options.tt.frame.position.hpy)
	end
end
---------------------------------------------------------
function ttMpXSliderOnLoad()
	ttMpXSlider:SetMinMaxValues(-1000,1000)
	local sliderMin, sliderMax = ttMpXSlider:GetMinMaxValues()
	getglobal(ttMpXSlider:GetName().."Low"):SetText(sliderMin)
	getglobal(ttMpXSlider:GetName().."High"):SetText(sliderMax)
	ttMpXSlider:SetOrientation("HORIZONTAL")
	ttMpXSlider:SetValueStep(1)
	ttMpXSlider:SetValue(Options.tt.frame.position.mpx)
end

function ttMpXSliderOnValueChanged()
	if ttMpXSlider:GetValue() then 
		ttMpXSlider:SetValue(ttMpXSlider:GetValue())
		Options.tt.frame.position.mpx=ttMpXSlider:GetValue()
		ttMpXStatus:SetText(Options.tt.frame.position.mpx)
		
		MP_TARGETTARGET_FRAME:ClearAllPoints()
		MP_TARGETTARGET_FRAME:SetPoint("BOTTOMRIGHT", nil, "CENTER", Options.tt.frame.position.mpx, Options.tt.frame.position.mpy)
	end
end
---------------------------------------------------------
function ttMpYSliderOnLoad()
	ttMpYSlider:SetMinMaxValues(-1000,1000)
	local sliderMin, sliderMax = ttMpYSlider:GetMinMaxValues()
	getglobal(ttMpYSlider:GetName().."Low"):SetText(sliderMin)
	getglobal(ttMpYSlider:GetName().."High"):SetText(sliderMax)
	ttMpYSlider:SetOrientation("HORIZONTAL")
	ttMpYSlider:SetValueStep(1)
	ttMpYSlider:SetValue(Options.tt.frame.position.mpy)
end

function ttMpYSliderOnValueChanged()
	if ttMpYSlider:GetValue() then 
		ttMpYSlider:SetValue(ttMpYSlider:GetValue())
		Options.tt.frame.position.mpy=ttMpYSlider:GetValue()
		ttMpYStatus:SetText(Options.tt.frame.position.mpy)
		
		MP_TARGETTARGET_FRAME:ClearAllPoints()
		MP_TARGETTARGET_FRAME:SetPoint("BOTTOMRIGHT", nil, "CENTER", Options.tt.frame.position.mpx, Options.tt.frame.position.mpy)
	end
end
---------------------------------------------------------
function ttDefMaxSliderOnLoad()
	ttDefMaxSlider:SetMinMaxValues(0,100)
	local sliderMin, sliderMax = ttDefMaxSlider:GetMinMaxValues()
	getglobal(ttDefMaxSlider:GetName().."Low"):SetText(sliderMin)
	getglobal(ttDefMaxSlider:GetName().."High"):SetText(sliderMax)
	ttDefMaxSlider:SetOrientation("HORIZONTAL")
	ttDefMaxSlider:SetValueStep(1)
	ttDefMaxSlider:SetValue(Options.tt.deficit.max*100)
end

function ttDefMaxSliderOnValueChanged()
	if ttDefMaxSlider:GetValue() then 
		ttDefMaxSlider:SetValue(ttDefMaxSlider:GetValue())
		Options.tt.deficit.max=ttDefMaxSlider:GetValue()/100
		ttDefMaxStatus:SetText(Options.tt.deficit.max*100)
	end
end	
---------------------------------------------------------
function ttDefMinSliderOnLoad()
	ttDefMinSlider:SetMinMaxValues(0,100)
	local sliderMin, sliderMax = ttDefMinSlider:GetMinMaxValues()
	getglobal(ttDefMinSlider:GetName().."Low"):SetText(sliderMin)
	getglobal(ttDefMinSlider:GetName().."High"):SetText(sliderMax)
	ttDefMinSlider:SetOrientation("HORIZONTAL")
	ttDefMinSlider:SetValueStep(1)
	ttDefMinSlider:SetValue(Options.tt.deficit.min*100)
end

function ttDefMinSliderOnValueChanged()
	if ttDefMinSlider:GetValue() then 
		ttDefMinSlider:SetValue(ttDefMinSlider:GetValue())
		Options.tt.deficit.min=ttDefMinSlider:GetValue()/100
		ttDefMinStatus:SetText(Options.tt.deficit.min*100)
	end
end	