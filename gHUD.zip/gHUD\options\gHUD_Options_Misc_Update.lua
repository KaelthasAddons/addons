function updateSliderOnLoad()
	updateSlider:SetMinMaxValues(10,200)
	local sliderMin, sliderMax = updateSlider:GetMinMaxValues()
	getglobal(updateSlider:GetName().."Low"):SetText(sliderMin)
	getglobal(updateSlider:GetName().."High"):SetText(sliderMax)
	updateSlider:SetOrientation("HORIZONTAL")
	updateSlider:SetValueStep(1)
	updateSlider:SetValue(1/Options.update)
end

function updateSliderOnValueChanged()
	if updateSlider:GetValue() then 
		updateSlider:SetValue(updateSlider:GetValue())
		Options.update=1/updateSlider:GetValue()
		UpdateStatus:SetText(1/Options.update)
		--DEFAULT_CHAT_FRAME:AddMessage(Options.update)
	end
end