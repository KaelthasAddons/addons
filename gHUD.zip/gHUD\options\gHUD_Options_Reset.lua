
function ResetFrameOnClick()
	DEFAULT_CHAT_FRAME:AddMessage("|cFF00FF00" ..Default.name .." - |rReset Frame: |cFFFF0000 Not active")
end

function ResetAllOnClick()
	DEFAULT_CHAT_FRAME:AddMessage("|cFF00FF00" ..Default.name .." - |rReset All: |cFFFF0000 Not active")
end
