function Load_HP_TargetTarget()
	if (event=="ADDON_LOADED") and (arg1=="gHUD") then
		if (Options.tt.frame.active==1) then
		--set position
			HP_TARGETTARGET_FRAME:ClearAllPoints()
			HP_TARGETTARGET_FRAME:SetPoint("BOTTOMLEFT", nil, "CENTER", Options.tt.frame.position.hpx, Options.tt.frame.position.hpy)
		--texture
			HP_TARGETTARGET_BAR_TEXTURE:SetTexture(Options.texture.BarHeight)
		
			HP_TARGETTARGET_BG_TEXTURE1:SetHeight(Options.player.frame.bg.height/2)
			HP_TARGETTARGET_BG_TEXTURE1:SetWidth(Options.player.frame.bg.width)
			HP_TARGETTARGET_BG_TEXTURE2:SetHeight((Options.player.frame.bg.height/2)-2)
			HP_TARGETTARGET_BG_TEXTURE2:SetWidth(Options.player.frame.bg.width-2)
		
			HP_TARGETTARGET_BAR:SetWidth(Options.player.frame.bar.width)
			HP_TARGETTARGET_FRAME:SetHeight(Options.player.frame.bg.height/2)
			HP_TARGETTARGET_FRAME:SetWidth(Options.player.frame.bg.width)
		
			HP_TargetTarget_Button:SetHeight(Options.player.frame.bg.height/2)
			HP_TargetTarget_Button:SetWidth(Options.player.frame.bg.width)
		--hp targettarget max text
			HP_TARGETTARGET_MAX:SetFont(Options.font.font, Options.font.size, Options.font.flags)
			HP_TARGETTARGET_MAX:SetTextColor(0, 1, 0, 1)
		--hp targettarget percent text
			HP_TARGETTARGET_PERCENT:SetFont(Options.font.font, Options.font.size, Options.font.flags)
		--hp targettarget deficit text
			HP_TARGETTARGET_DEFICIT:SetFont(Options.font.font, Options.font.size, Options.font.flags)
		--hp targettarget name text
			HP_TARGETTARGET_NAME:SetFont(Options.font.font, Options.font.size, Options.font.flags)
		end
	end
end

function Load_MP_TargetTarget()
	if (event=="ADDON_LOADED") and (arg1=="gHUD") then
		if (Options.tt.frame.active==1) then	
		--set position
			MP_TARGETTARGET_FRAME:ClearAllPoints()
			MP_TARGETTARGET_FRAME:SetPoint("BOTTOMRIGHT", nil, "CENTER", Options.tt.frame.position.mpx, Options.tt.frame.position.mpy)
		--texture
			MP_TARGETTARGET_BAR_TEXTURE:SetTexture(Options.texture.BarHeight)
		
			MP_TARGETTARGET_BG_TEXTURE1:SetHeight(Options.player.frame.bg.height/2)
			MP_TARGETTARGET_BG_TEXTURE1:SetWidth(Options.player.frame.bg.width)
			MP_TARGETTARGET_BG_TEXTURE2:SetHeight((Options.player.frame.bg.height/2)-2)
			MP_TARGETTARGET_BG_TEXTURE2:SetWidth(Options.player.frame.bg.width-2)
		
			MP_TARGETTARGET_BAR:SetWidth(Options.player.frame.bar.width)
			MP_TARGETTARGET_FRAME:SetHeight(Options.player.frame.bg.height/2)
			MP_TARGETTARGET_FRAME:SetWidth(Options.player.frame.bg.width)
			
			MP_TargetTarget_Button:SetHeight(Options.player.frame.bg.height/2)
			MP_TargetTarget_Button:SetWidth(Options.player.frame.bg.width)
		--hp targettarget max text
			MP_TARGETTARGET_MAX:SetFont(Options.font.font, Options.font.size, Options.font.flags)
		--hp targettarget percent text
			MP_TARGETTARGET_PERCENT:SetFont(Options.font.font, Options.font.size, Options.font.flags)
		--hp targettarget deficit text
			MP_TARGETTARGET_DEFICIT:SetFont(Options.font.font, Options.font.size, Options.font.flags)
		end
	end
end

function HP_TargetTarget(arg1)
	local unit = "targettarget"
	local tBar = HP_TARGETTARGET_BAR_TEXTURE
	local tBG  = HP_TARGETTARGET_BG_TEXTURE1
	local tBG2 = HP_TARGETTARGET_BG_TEXTURE2
	local fBut = HP_TargetTarget_Button
	local fBar = HP_TARGETTARGET_BAR
	local fBG	 = HP_TARGETTARGET_FRAME	
	local fMax = HP_TARGETTARGET_MAX
	local fPer = HP_TARGETTARGET_PERCENT
	local fDef = HP_TARGETTARGET_DEFICIT
	local fNam = HP_TARGETTARGET_NAME
	
	local fUn = HP_TARGETTARGET_FRAME
	
	if (Options.tt.frame.active==1) then
		--enable frame
		EnableFrame(fUn)
		
		this.TimeSinceLastUpdate=this.TimeSinceLastUpdate + arg1
		if (this.TimeSinceLastUpdate > Options.update) then
			if (UnitExists(unit)) then
			--Color
				ColorHealth(unit,tBar,tBG,tBG2,fPer,fDef, fUn)
			--selected
				HighlightSelectedUnit(unit,fBut)
			--MobHealth
				local cur, max, found
				local deficit
				if MobHealth3 then
					cur, max, found = MobHealth3:GetUnitHealth(unit, UnitHealth(unit), UnitHealthMax(unit))
					deficit = max-cur
				else
					cur, max = UnitHealth(unit), UnitHealthMax(unit)
					deficit = max-cur
				end
			--hp bar
				if (cur==0) then
					fBar:SetHeight(1)
				else
					if (max>=cur) then
						fBar:SetHeight((Options.player.frame.bg.height/2)/max*cur)
					else
						fBar:SetHeight(Options.player.frame.bg.height/2)
					end
				end
			--hp name text
				--UnitNames(unit,fNam)
				NameTargetTarget(unit,fNam)
			--hp max text
				fMax:SetText(max)
			--hp percent text
				fPer:SetText(string.format("%.0f", (100/max*cur)) .."%")
			--hp deficit text
				DeficitHealthTT(cur,max,fDef,deficit)
			end
			this.TimeSinceLastUpdate=0
		end
	else
		--disable frame
		DisableFrame(fUn)
	end
end

function MP_TargetTarget(arg1)
	local unit = "targettarget"
	local tBar = MP_TARGETTARGET_BAR_TEXTURE
	local tBG  = MP_TARGETTARGET_BG_TEXTURE1
	local tBG2 = MP_TARGETTARGET_BG_TEXTURE2	
	local fBut = MP_TargetTarget_Button
	local fBar = MP_TARGETTARGET_BAR
	local fBG	= MP_TARGETTARGET_FRAME	
	local fMax = MP_TARGETTARGET_MAX
	local fPer = MP_TARGETTARGET_PERCENT
	local fDef = MP_TARGETTARGET_DEFICIT
	
	local fUn = MP_TARGETTARGET_FRAME
	
	if (Options.tt.frame.active==1) then
		--enable frame
		EnableFrame(fUn)
		
		this.TimeSinceLastUpdate=this.TimeSinceLastUpdate + arg1
		if (this.TimeSinceLastUpdate > Options.update) then	
			if (UnitExists(unit)) then
			--Color
				ColorMana(unit,tBar,tBG,tBG2,fPer,fDef, fUn)
			--Health
			local cur, max = UnitMana(unit), UnitManaMax(unit)
			local deficit = max-cur	
			--mp bar
				if (cur==0) then
					fBar:SetHeight(1)
				else
					if (max>=cur) then
						fBar:SetHeight((Options.player.frame.bg.height/2)/max*cur)
					else
						fBar:SetHeight(Options.player.frame.bg.height/2)
					end
				end
			--mp max text
				fMax:SetText(max)
				ColorPowerType(unit,fMax)
			--mp percent text
				fPer:SetText(string.format("%.0f", (100/max*cur)) .."%")
			--mp deficit text
				DeficitManaTT(cur,max,fDef,deficit,unit)
			end
			this.TimeSinceLastUpdate=0
		end
	else
		--disable frame
		DisableFrame(fUn)
	end
end