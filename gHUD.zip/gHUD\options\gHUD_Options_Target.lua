function targetNameCBOnLoad()
	if (Options.target.name.active==0) then
		targetNameCB:SetChecked(false)
	elseif (Options.target.name.active==1) then
		targetNameCB:SetChecked(true)
	end
end

function targetNameCBOnClick()
	if (targetNameCB:GetChecked(false)) then
		targetNameCB:SetChecked(true)
		Options.target.name.active=1
	else targetNameCB:SetChecked(false)
		Options.target.name.active=0
	end	
end


function targetNameFormatSliderOnLoad()
	targetNameFormatSlider:SetMinMaxValues(-1,40)
	local sliderMin, sliderMax = targetNameFormatSlider:GetMinMaxValues()
	getglobal(targetNameFormatSlider:GetName().."Low"):SetText(sliderMin)
	getglobal(targetNameFormatSlider:GetName().."High"):SetText(sliderMax)
	targetNameFormatSlider:SetOrientation("HORIZONTAL")
	targetNameFormatSlider:SetValueStep(1)
	targetNameFormatSlider:SetValue(Options.target.name.format)
end

function targetNameFormatSliderOnValueChanged()
	if targetNameFormatSlider:GetValue() then 
		targetNameFormatSlider:SetValue(targetNameFormatSlider:GetValue())
		Options.target.name.format=targetNameFormatSlider:GetValue()
		targetNameFormatStatus:SetText(Options.target.name.format)
	end
end
---------------------------------------------------------
function targetHpXSliderOnLoad()
	targetHpXSlider:SetMinMaxValues(-1000,1000)
	local sliderMin, sliderMax = targetHpXSlider:GetMinMaxValues()
	getglobal(targetHpXSlider:GetName().."Low"):SetText(sliderMin)
	getglobal(targetHpXSlider:GetName().."High"):SetText(sliderMax)
	targetHpXSlider:SetOrientation("HORIZONTAL")
	targetHpXSlider:SetValueStep(1)
	targetHpXSlider:SetValue(Options.target.frame.position.hpx)
end

function targetHpXSliderOnValueChanged()
	if targetHpXSlider:GetValue() then 
		targetHpXSlider:SetValue(targetHpXSlider:GetValue())
		Options.target.frame.position.hpx=targetHpXSlider:GetValue()
		targetHpXStatus:SetText(Options.target.frame.position.hpx)
		
		HP_TARGET_FRAME:ClearAllPoints()
		HP_TARGET_FRAME:SetPoint("BOTTOMLEFT", nil, "CENTER", Options.target.frame.position.hpx, Options.target.frame.position.hpy)
	end
end
---------------------------------------------------------
function targetHpYSliderOnLoad()
	targetHpYSlider:SetMinMaxValues(-1000,1000)
	local sliderMin, sliderMax = targetHpYSlider:GetMinMaxValues()
	getglobal(targetHpYSlider:GetName().."Low"):SetText(sliderMin)
	getglobal(targetHpYSlider:GetName().."High"):SetText(sliderMax)
	targetHpYSlider:SetOrientation("HORIZONTAL")
	targetHpYSlider:SetValueStep(1)
	targetHpYSlider:SetValue(Options.target.frame.position.hpy)
end

function targetHpYSliderOnValueChanged()
	if targetHpYSlider:GetValue() then 
		targetHpYSlider:SetValue(targetHpYSlider:GetValue())
		Options.target.frame.position.hpy=targetHpYSlider:GetValue()
		targetHpYStatus:SetText(Options.target.frame.position.hpy)
		
		HP_TARGET_FRAME:ClearAllPoints()
		HP_TARGET_FRAME:SetPoint("BOTTOMLEFT", nil, "CENTER", Options.target.frame.position.hpx, Options.target.frame.position.hpy)
	end
end
---------------------------------------------------------
function targetMpXSliderOnLoad()
	targetMpXSlider:SetMinMaxValues(-1000,1000)
	local sliderMin, sliderMax = targetMpXSlider:GetMinMaxValues()
	getglobal(targetMpXSlider:GetName().."Low"):SetText(sliderMin)
	getglobal(targetMpXSlider:GetName().."High"):SetText(sliderMax)
	targetMpXSlider:SetOrientation("HORIZONTAL")
	targetMpXSlider:SetValueStep(1)
	targetMpXSlider:SetValue(Options.target.frame.position.mpx)
end

function targetMpXSliderOnValueChanged()
	if targetMpXSlider:GetValue() then 
		targetMpXSlider:SetValue(targetMpXSlider:GetValue())
		Options.target.frame.position.mpx=targetMpXSlider:GetValue()
		targetMpXStatus:SetText(Options.target.frame.position.mpx)
		
		MP_TARGET_FRAME:ClearAllPoints()
		MP_TARGET_FRAME:SetPoint("BOTTOMRIGHT", nil, "CENTER", Options.target.frame.position.mpx, Options.target.frame.position.mpy)
	end
end
---------------------------------------------------------
function targetMpYSliderOnLoad()
	targetMpYSlider:SetMinMaxValues(-1000,1000)
	local sliderMin, sliderMax = targetMpYSlider:GetMinMaxValues()
	getglobal(targetMpYSlider:GetName().."Low"):SetText(sliderMin)
	getglobal(targetMpYSlider:GetName().."High"):SetText(sliderMax)
	targetMpYSlider:SetOrientation("HORIZONTAL")
	targetMpYSlider:SetValueStep(1)
	targetMpYSlider:SetValue(Options.target.frame.position.mpy)
end

function targetMpYSliderOnValueChanged()
	if targetMpYSlider:GetValue() then 
		targetMpYSlider:SetValue(targetMpYSlider:GetValue())
		Options.target.frame.position.mpy=targetMpYSlider:GetValue()
		targetMpYStatus:SetText(Options.target.frame.position.mpy)
		
		MP_TARGET_FRAME:ClearAllPoints()
		MP_TARGET_FRAME:SetPoint("BOTTOMRIGHT", nil, "CENTER", Options.target.frame.position.mpx, Options.target.frame.position.mpy)
	end
end