function Load_HP_Party1()
	if (event=="ADDON_LOADED") and (arg1=="gHUD") and (Options~=nil) then	
		LoadOptions();
		if (Options.party.frame.active==1) then
		--set position
			HP_PARTY1_FRAME:ClearAllPoints()
			HP_PARTY1_FRAME:SetPoint("BOTTOMRIGHT", nil, "CENTER", Options.party.frame.position.hpx, Options.party.frame.position.hpy)
		--texture
			PARTYPERCENT:Hide()			
			HP_PARTY1_BAR_TEXTURE:SetTexture(Options.texture.BarHeight)
			
			HP_PARTY1_BG_TEXTURE1:SetWidth(Options.player.frame.bg.width)
			HP_PARTY1_BG_TEXTURE2:SetWidth(Options.player.frame.bg.width-2)
		
			HP_PARTY1_BAR:SetWidth(Options.player.frame.bar.width)
			HP_PARTY1_FRAME:SetWidth(Options.player.frame.bg.width)
			
			HP_Party1_Button:SetWidth(Options.player.frame.bg.width)
		--hp party1 deficit text
			HP_PARTY1_DEFICIT:SetFont(Options.font.font, Options.font.size, Options.font.flags)
		--hp party1 name text
			HP_PARTY1_NAME:SetFont(Options.font.font, Options.font.size, Options.font.flags)
		end
	end
end

function Load_HP_Party2()
	if (event=="ADDON_LOADED") and (arg1=="gHUD") and (Options~=nil) then	
		if (Options.party.frame.active==1) then
		--set position
			HP_PARTY2_FRAME:ClearAllPoints()
			HP_PARTY2_FRAME:SetPoint("BOTTOM", HP_PARTY1_FRAME, "TOP", 0, Options.party.frame.gap)
		--texture
			HP_PARTY2_BAR_TEXTURE:SetTexture(Options.texture.BarHeight)
			
			HP_PARTY2_BG_TEXTURE1:SetWidth(Options.player.frame.bg.width)
			HP_PARTY2_BG_TEXTURE2:SetWidth(Options.player.frame.bg.width-2)
		
			HP_PARTY2_BAR:SetWidth(Options.player.frame.bar.width)
			HP_PARTY2_FRAME:SetWidth(Options.player.frame.bg.width)
			
			HP_Party2_Button:SetWidth(Options.player.frame.bg.width)
		--hp party2 deficit text
			HP_PARTY2_DEFICIT:SetFont(Options.font.font, Options.font.size, Options.font.flags)
		--hp party2 name text
			HP_PARTY2_NAME:SetFont(Options.font.font, Options.font.size, Options.font.flags)
		end
	end
end

function Load_HP_Party3()
	if (event=="ADDON_LOADED") and (arg1=="gHUD") and (Options~=nil) then	
		if (Options.party.frame.active==1) then
		--set position
			HP_PARTY3_FRAME:ClearAllPoints()
			HP_PARTY3_FRAME:SetPoint("BOTTOM", HP_PARTY2_FRAME, "TOP", 0, Options.party.frame.gap)
		--texture
			HP_PARTY3_BAR_TEXTURE:SetTexture(Options.texture.BarHeight)
			
			HP_PARTY3_BG_TEXTURE1:SetWidth(Options.player.frame.bg.width)
			HP_PARTY3_BG_TEXTURE2:SetWidth(Options.player.frame.bg.width-2)
		
			HP_PARTY3_BAR:SetWidth(Options.player.frame.bar.width)
			HP_PARTY3_FRAME:SetWidth(Options.player.frame.bg.width)
			
			HP_Party3_Button:SetWidth(Options.player.frame.bg.width)
		--hp party3 deficit text
			HP_PARTY3_DEFICIT:SetFont(Options.font.font, Options.font.size, Options.font.flags)
		--hp party3 name text
			HP_PARTY3_NAME:SetFont(Options.font.font, Options.font.size, Options.font.flags)
		end
	end
end

function Load_HP_Party4()
	if (event=="ADDON_LOADED") and (arg1=="gHUD") and (Options~=nil) then	
		if (Options.party.frame.active==1) then
		--set position
			HP_PARTY4_FRAME:ClearAllPoints()
			HP_PARTY4_FRAME:SetPoint("BOTTOM", HP_PARTY3_FRAME, "TOP", 0, Options.party.frame.gap)
		--texture
			HP_PARTY4_BAR_TEXTURE:SetTexture(Options.texture.BarHeight)
			
			HP_PARTY4_BG_TEXTURE1:SetWidth(Options.player.frame.bg.width)
			HP_PARTY4_BG_TEXTURE2:SetWidth(Options.player.frame.bg.width-2)
		
			HP_PARTY4_BAR:SetWidth(Options.player.frame.bar.width)
			HP_PARTY4_FRAME:SetWidth(Options.player.frame.bg.width)
			
			HP_Party4_Button:SetWidth(Options.player.frame.bg.width)
		--hp party4 deficit text
			HP_PARTY4_DEFICIT:SetFont(Options.font.font, Options.font.size, Options.font.flags)
		--hp party4 name text
			HP_PARTY4_NAME:SetFont(Options.font.font, Options.font.size, Options.font.flags)
		end
	end
end


function Load_MP_Party1()
	if (event=="ADDON_LOADED") and (arg1=="gHUD") and (Options~=nil) then
		if (Options.party.frame.active==1) then
		--set position
			MP_PARTY1_FRAME:ClearAllPoints()
			MP_PARTY1_FRAME:SetPoint("BOTTOMLEFT", nil, "CENTER", Options.party.frame.position.mpx, Options.party.frame.position.mpy)
		--texture
			MP_PARTY1_BAR_TEXTURE:SetTexture(Options.texture.BarHeight)
			
			MP_PARTY1_BG_TEXTURE1:SetWidth(Options.player.frame.bg.width)
			MP_PARTY1_BG_TEXTURE2:SetWidth(Options.player.frame.bg.width-2)
		
			MP_PARTY1_BAR:SetWidth(Options.player.frame.bar.width)
			MP_PARTY1_FRAME:SetWidth(Options.player.frame.bg.width)
		
			MP_Party1_Button:SetWidth(Options.player.frame.bg.width)
		--hp party1 deficit text
			MP_PARTY1_DEFICIT:SetFont(Options.font.font, Options.font.size, Options.font.flags)
		end
	end
end

function Load_MP_Party2()
	if (event=="ADDON_LOADED") and (arg1=="gHUD") and (Options~=nil) then
		if (Options.party.frame.active==1) then	
		--set position
			MP_PARTY2_FRAME:ClearAllPoints()
			MP_PARTY2_FRAME:SetPoint("BOTTOM", MP_PARTY1_FRAME, "TOP", 0, Options.party.frame.gap)
		--texture
			MP_PARTY2_BAR_TEXTURE:SetTexture(Options.texture.BarHeight)
			
			MP_PARTY2_BG_TEXTURE1:SetWidth(Options.player.frame.bg.width)
			MP_PARTY2_BG_TEXTURE2:SetWidth(Options.player.frame.bg.width-2)
		
			MP_PARTY2_BAR:SetWidth(Options.player.frame.bar.width)
			MP_PARTY2_FRAME:SetWidth(Options.player.frame.bg.width)
		
			MP_Party2_Button:SetWidth(Options.player.frame.bg.width)
		--hp party2 deficit text
			MP_PARTY2_DEFICIT:SetFont(Options.font.font, Options.font.size, Options.font.flags)
		end
	end
end

function Load_MP_Party3()
	if (event=="ADDON_LOADED") and (arg1=="gHUD") and (Options~=nil) then
		if (Options.party.frame.active==1) then
		--set position
			MP_PARTY3_FRAME:ClearAllPoints()
			MP_PARTY3_FRAME:SetPoint("BOTTOM", MP_PARTY2_FRAME, "TOP", 0, Options.party.frame.gap)
		--texture
			MP_PARTY3_BAR_TEXTURE:SetTexture(Options.texture.BarHeight)
			
			MP_PARTY3_BG_TEXTURE1:SetWidth(Options.player.frame.bg.width)
			MP_PARTY3_BG_TEXTURE2:SetWidth(Options.player.frame.bg.width-2)
		
			MP_PARTY3_BAR:SetWidth(Options.player.frame.bar.width)
			MP_PARTY3_FRAME:SetWidth(Options.player.frame.bg.width)
		
			MP_Party3_Button:SetWidth(Options.player.frame.bg.width)
		--hp party3 deficit text
			MP_PARTY3_DEFICIT:SetFont(Options.font.font, Options.font.size, Options.font.flags)
		end
	end
end

function Load_MP_Party4()
	if (event=="ADDON_LOADED") and (arg1=="gHUD") and (Options~=nil) then
		if (Options.party.frame.active==1) then	
		--set position
			MP_PARTY4_FRAME:ClearAllPoints()
			MP_PARTY4_FRAME:SetPoint("BOTTOM", MP_PARTY3_FRAME, "TOP", 0, Options.party.frame.gap)
		--texture
			MP_PARTY4_BAR_TEXTURE:SetTexture(Options.texture.BarHeight)
			
			MP_PARTY4_BG_TEXTURE1:SetWidth(Options.player.frame.bg.width)
			MP_PARTY4_BG_TEXTURE2:SetWidth(Options.player.frame.bg.width-2)
		
			MP_PARTY4_BAR:SetWidth(Options.player.frame.bar.width)
			MP_PARTY4_FRAME:SetWidth(Options.player.frame.bg.width)
		
			MP_Party4_Button:SetWidth(Options.player.frame.bg.width)
		--hp party4 deficit text
			MP_PARTY4_DEFICIT:SetFont(Options.font.font, Options.font.size, Options.font.flags)
		end
	end
end

function HP_Party1(arg1)	
	local unit = "party1"
	local tBar = HP_PARTY1_BAR_TEXTURE
	local tBG  = HP_PARTY1_BG_TEXTURE1
	local tBG2 = HP_PARTY1_BG_TEXTURE2
	local fBut = HP_Party1_Button
	local fBar = HP_PARTY1_BAR
	local fBG  = HP_PARTY1_FRAME
	local fDef = HP_PARTY1_DEFICIT
	local fNam = HP_PARTY1_NAME
	local fPer = PARTYPERCENT
	
	local fUn = HP_PARTY1_FRAME
	
	if (Options.party.frame.active==1) then
		--enable frame
		EnableFrame(fUn)
		
		this.TimeSinceLastUpdate=this.TimeSinceLastUpdate + arg1
		if (this.TimeSinceLastUpdate > Options.update) then
			if (UnitExists(unit)) then	
			--Color
				ColorHealth(unit,tBar,tBG,tBG2,fPer,fDef, fUn)
			--selected
				HighlightSelectedUnit(unit,fBut)
			--Health
			local cur, max = UnitHealth(unit), UnitHealthMax(unit)
			local deficit = max-cur
			--hp bar
				ScalePartyFrame(tBG,tBG2,fBG,fBut)
				ScalePartyBar(fBar,max,cur)
			--hp name text
				--UnitNames(unit,fNam)
				NameParty(unit,fNam)
			--hp deficit text
				DeficitHealthParty(cur,max,fDef,deficit)
			end
			this.TimeSinceLastUpdate=0
		end	
	else
		--disable frame
		DisableFrame(fUn)
	end
end

function HP_Party2(arg1)
	local unit = "party2"
	local tBar = HP_PARTY2_BAR_TEXTURE
	local tBG  = HP_PARTY2_BG_TEXTURE1
	local tBG2 = HP_PARTY2_BG_TEXTURE2
	local fBut = HP_Party2_Button
	local fBar = HP_PARTY2_BAR
	local fBG	= HP_PARTY2_FRAME
	local fDef = HP_PARTY2_DEFICIT
	local fNam = HP_PARTY2_NAME
	local fPer = PARTYPERCENT	
	
	local fUn = HP_PARTY2_FRAME
	
	if (Options.party.frame.active==1) then
		--enable frame
		EnableFrame(fUn)
		
		this.TimeSinceLastUpdate=this.TimeSinceLastUpdate + arg1
		if (this.TimeSinceLastUpdate > Options.update) then
			if (UnitExists(unit)) then	
			--Color
				ColorHealth(unit,tBar,tBG,tBG2,fPer,fDef, fUn)
			--selected
				HighlightSelectedUnit(unit,fBut)
			--Health
			local cur, max = UnitHealth(unit), UnitHealthMax(unit)
			local deficit = max-cur
			--hp bar
				ScalePartyFrame(tBG,tBG2,fBG,fBut)
				ScalePartyBar(fBar,max,cur)
			--hp name text
				--UnitNames(unit,fNam)
				NameParty(unit,fNam)
			--hp deficit text
				DeficitHealthParty(cur,max,fDef,deficit)
			end
			this.TimeSinceLastUpdate=0
		end	
	else
		--disable frame
		DisableFrame(fUn)
	end
end

function HP_Party3(arg1)	
	local unit = "party3"
	local tBar = HP_PARTY3_BAR_TEXTURE
	local tBG  = HP_PARTY3_BG_TEXTURE1
	local tBG2 = HP_PARTY3_BG_TEXTURE2
	local fBut = HP_Party3_Button
	local fBar = HP_PARTY3_BAR
	local fBG	 = HP_PARTY3_FRAME
	local fDef = HP_PARTY3_DEFICIT
	local fNam = HP_PARTY3_NAME
	local fPer = PARTYPERCENT
	
	local fUn = HP_PARTY3_FRAME
	
	if (Options.party.frame.active==1) then
		--enable frame
		EnableFrame(fUn)
		
		this.TimeSinceLastUpdate=this.TimeSinceLastUpdate + arg1
		if (this.TimeSinceLastUpdate > Options.update) then
			if (UnitExists(unit)) then	
			--Color
				ColorHealth(unit,tBar,tBG,tBG2,fPer,fDef, fUn)
			--selected
				HighlightSelectedUnit(unit,fBut)
			--Health
			local cur, max = UnitHealth(unit), UnitHealthMax(unit)
			local deficit = max-cur
			--hp bar
				ScalePartyFrame(tBG,tBG2,fBG,fBut)
				ScalePartyBar(fBar,max,cur)
			--hp name text
				--UnitNames(unit,fNam)
				NameParty(unit,fNam)
			--hp deficit text
				DeficitHealthParty(cur,max,fDef,deficit)
			end
			this.TimeSinceLastUpdate=0
		end	
	else
		--disable frame
		DisableFrame(fUn)
	end
end

function HP_Party4(arg1)
	local unit = "party4"
	local tBar = HP_PARTY4_BAR_TEXTURE
	local tBG  = HP_PARTY4_BG_TEXTURE1
	local tBG2 = HP_PARTY4_BG_TEXTURE2
	local fBut = HP_Party4_Button
	local fBar = HP_PARTY4_BAR
	local fBG	 = HP_PARTY4_FRAME
	local fDef = HP_PARTY4_DEFICIT
	local fNam = HP_PARTY4_NAME
	local fPer = PARTYPERCENT
	
	local fUn = HP_PARTY4_FRAME
	
	if (Options.party.frame.active==1) then
		--enable frame
		EnableFrame(fUn)
		
		this.TimeSinceLastUpdate=this.TimeSinceLastUpdate + arg1
		if (this.TimeSinceLastUpdate > Options.update) then
			if (UnitExists(unit)) then	
			--Color
				ColorHealth(unit,tBar,tBG,tBG2,fPer,fDef, fUn)
			--selected
				HighlightSelectedUnit(unit,fBut)
			--Health
			local cur, max = UnitHealth(unit), UnitHealthMax(unit)
			local deficit = max-cur
			--hp bar
				ScalePartyFrame(tBG,tBG2,fBG,fBut)
				ScalePartyBar(fBar,max,cur)
			--hp name text
				--UnitNames(unit,fNam)
				NameParty(unit,fNam)
			--hp deficit text
				DeficitHealthParty(cur,max,fDef,deficit)
			end
			this.TimeSinceLastUpdate=0
		end	
	else
		--disable frame
		DisableFrame(fUn)
	end
end

function MP_Party1(arg1)	
	local unit = "party1"
	local tBar = MP_PARTY1_BAR_TEXTURE
	local tBG  = MP_PARTY1_BG_TEXTURE1
	local tBG2 = MP_PARTY1_BG_TEXTURE2
	local fBut = MP_Party1_Button
	local fBar = MP_PARTY1_BAR
	local fBG	= MP_PARTY1_FRAME
	local fDef = MP_PARTY1_DEFICIT
	local fPer = PARTYPERCENT
	
	local fUn = MP_PARTY1_FRAME
	
	if (Options.party.frame.active==1) then
		--enable frame
		EnableFrame(fUn)
		
		this.TimeSinceLastUpdate=this.TimeSinceLastUpdate + arg1
		if (this.TimeSinceLastUpdate > Options.update) then	
			if (UnitExists(unit)) then
		--Color
			ColorMana(unit,tBar,tBG,tBG2,fPer,fDef, fUn)
		--Health
			local cur, max = UnitMana(unit), UnitManaMax(unit)
			local deficit = max-cur
			--mp bar
				ScalePartyFrame(tBG,tBG2,fBG,fBut)
				ScalePartyBar(fBar,max,cur)
			--mp deficit text
				DeficitManaParty(unit,cur,max,fDef,deficit)
			end
			this.TimeSinceLastUpdate=0
		end
	else
		--disable frame
		DisableFrame(fUn)
	end
end

function MP_Party2(arg1)
	local unit = "party2"
	local tBar = MP_PARTY2_BAR_TEXTURE
	local tBG  = MP_PARTY2_BG_TEXTURE1
	local tBG2 = MP_PARTY2_BG_TEXTURE2
	local fBut = MP_Party2_Button
	local fBar = MP_PARTY2_BAR
	local fBG	 = MP_PARTY2_FRAME
	local fDef = MP_PARTY2_DEFICIT
	local fPer = PARTYPERCENT
	
	local fUn = MP_PARTY2_FRAME
	
	if (Options.party.frame.active==1) then
		--enable frame
		EnableFrame(fUn)
		
		this.TimeSinceLastUpdate=this.TimeSinceLastUpdate + arg1
		if (this.TimeSinceLastUpdate > Options.update) then	
			if (UnitExists(unit)) then
		--Color
			ColorMana(unit,tBar,tBG,tBG2,fPer,fDef, fUn)
		--Health
			local cur, max = UnitMana(unit), UnitManaMax(unit)
			local deficit = max-cur
			--mp bar
				ScalePartyFrame(tBG,tBG2,fBG,fBut)
				ScalePartyBar(fBar,max,cur)
			--mp deficit text
				DeficitManaParty(unit,cur,max,fDef,deficit)
			end
			this.TimeSinceLastUpdate=0
		end
	else
		--disable frame
		DisableFrame(fUn)
	end
end

function MP_Party3(arg1)
	local unit = "party3"
	local tBar = MP_PARTY3_BAR_TEXTURE
	local tBG  = MP_PARTY3_BG_TEXTURE1
	local tBG2 = MP_PARTY3_BG_TEXTURE2
	local fBut = MP_Party3_Button
	local fBar = MP_PARTY3_BAR
	local fBG	 = MP_PARTY3_FRAME
	local fDef = MP_PARTY3_DEFICIT
	local fPer = PARTYPERCENT
	
	local fUn = MP_PARTY3_FRAME
	
	if (Options.party.frame.active==1) then
		--enable frame
		EnableFrame(fUn)
		
		this.TimeSinceLastUpdate=this.TimeSinceLastUpdate + arg1
		if (this.TimeSinceLastUpdate > Options.update) then	
			if (UnitExists(unit)) then
		--Color
			ColorMana(unit,tBar,tBG,tBG2,fPer,fDef, fUn)
		--Health
			local cur, max = UnitMana(unit), UnitManaMax(unit)
			local deficit = max-cur
			--mp bar
				ScalePartyFrame(tBG,tBG2,fBG,fBut)
				ScalePartyBar(fBar,max,cur)
			--mp deficit text
				DeficitManaParty(unit,cur,max,fDef,deficit)
			end
			this.TimeSinceLastUpdate=0
		end
	else
		--disable frame
		DisableFrame(fUn)
	end
end

function MP_Party4(arg1)
	local unit = "party4"
	local tBar = MP_PARTY4_BAR_TEXTURE
	local tBG  = MP_PARTY4_BG_TEXTURE1
	local tBG2 = MP_PARTY4_BG_TEXTURE2
	local fBut = MP_Party4_Button
	local fBar = MP_PARTY4_BAR
	local fBG	= MP_PARTY4_FRAME
	local fDef = MP_PARTY4_DEFICIT
	local fPer = PARTYPERCENT
	
	local fUn = MP_PARTY4_FRAME
	
	if (Options.party.frame.active==1) then
		--enable frame
		EnableFrame(fUn)
		
		this.TimeSinceLastUpdate=this.TimeSinceLastUpdate + arg1
		if (this.TimeSinceLastUpdate > Options.update) then	
			if (UnitExists(unit)) then
		--Color
			ColorMana(unit,tBar,tBG,tBG2,fPer,fDef, fUn)
		--Health
			local cur, max = UnitMana(unit), UnitManaMax(unit)
			local deficit = max-cur
			--mp bar
				ScalePartyFrame(tBG,tBG2,fBG,fBut)
				ScalePartyBar(fBar,max,cur)
			--mp deficit text
				DeficitManaParty(unit,cur,max,fDef,deficit)
			end
			this.TimeSinceLastUpdate=0
		end
	else
		--disable frame
		DisableFrame(fUn)
	end
end
