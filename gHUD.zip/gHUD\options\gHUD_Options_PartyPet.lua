function partypetShowCBLoad()
	if (Options.partypet.frame.active==0) then
		showPartyPetCB:SetChecked(false)
	elseif (Options.partypet.frame.active==1) then
		showPartyPetCB:SetChecked(true)
	end
end

function partypetShowCBOnClick()
	if (showPartyPetCB:GetChecked(false)) then
		showPartyPetCB:SetChecked(true)
		Options.partypet.frame.active=1
	else showPartyPetCB:SetChecked(false)
		Options.partypet.frame.active=0
	end	
end
---------------------------------------------------------
function partypetNameCBOnLoad()
	if (Options.partypet.name.active==0) then
		partypetNameCB:SetChecked(false)
	elseif (Options.partypet.name.active==1) then
		partypetNameCB:SetChecked(true)
	end
end

function partypetNameCBOnClick()
	if (partypetNameCB:GetChecked(false)) then
		partypetNameCB:SetChecked(true)
		Options.partypet.name.active=1
	else partypetNameCB:SetChecked(false)
		Options.partypet.name.active=0
	end	
end


function partypetNameFormatSliderOnLoad()
	partypetNameFormatSlider:SetMinMaxValues(1,40)
	local sliderMin, sliderMax = partypetNameFormatSlider:GetMinMaxValues()
	getglobal(partypetNameFormatSlider:GetName().."Low"):SetText(sliderMin)
	getglobal(partypetNameFormatSlider:GetName().."High"):SetText(sliderMax)
	partypetNameFormatSlider:SetOrientation("HORIZONTAL")
	partypetNameFormatSlider:SetValueStep(1)
	partypetNameFormatSlider:SetValue(Options.partypet.name.format)
end

function partypetNameFormatSliderOnValueChanged()
	if partypetNameFormatSlider:GetValue() then 
		partypetNameFormatSlider:SetValue(partypetNameFormatSlider:GetValue())
		Options.partypet.name.format=partypetNameFormatSlider:GetValue()
		partypetNameFormatStatus:SetText(Options.partypet.name.format)
	end
end
---------------------------------------------------------
function partypetHpXSliderOnLoad()
	partypetHpXSlider:SetMinMaxValues(-1000,1000)
	local sliderMin, sliderMax = partypetHpXSlider:GetMinMaxValues()
	getglobal(partypetHpXSlider:GetName().."Low"):SetText(sliderMin)
	getglobal(partypetHpXSlider:GetName().."High"):SetText(sliderMax)
	partypetHpXSlider:SetOrientation("HORIZONTAL")
	partypetHpXSlider:SetValueStep(1)
	partypetHpXSlider:SetValue(Options.partypet.frame.position.hpx)
end

function partypetHpXSliderOnValueChanged()
	if partypetHpXSlider:GetValue() then 
		partypetHpXSlider:SetValue(partypetHpXSlider:GetValue())
		Options.partypet.frame.position.hpx=partypetHpXSlider:GetValue()
		partypetHpXStatus:SetText(Options.partypet.frame.position.hpx)
		
		HP_PARTYPET1_FRAME:ClearAllPoints()
		HP_PARTYPET1_FRAME:SetPoint("BOTTOMRIGHT", nil, "CENTER", Options.partypet.frame.position.hpx, Options.partypet.frame.position.hpy)
	end
end
---------------------------------------------------------
function partypetHpYSliderOnLoad()
	partypetHpYSlider:SetMinMaxValues(-1000,1000)
	local sliderMin, sliderMax = partypetHpYSlider:GetMinMaxValues()
	getglobal(partypetHpYSlider:GetName().."Low"):SetText(sliderMin)
	getglobal(partypetHpYSlider:GetName().."High"):SetText(sliderMax)
	partypetHpYSlider:SetOrientation("HORIZONTAL")
	partypetHpYSlider:SetValueStep(1)
	partypetHpYSlider:SetValue(Options.partypet.frame.position.hpy)
end

function partypetHpYSliderOnValueChanged()
	if partypetHpYSlider:GetValue() then 
		partypetHpYSlider:SetValue(partypetHpYSlider:GetValue())
		Options.partypet.frame.position.hpy=partypetHpYSlider:GetValue()
		partypetHpYStatus:SetText(Options.partypet.frame.position.hpy)
		
		HP_PARTYPET1_FRAME:ClearAllPoints()
		HP_PARTYPET1_FRAME:SetPoint("BOTTOMRIGHT", nil, "CENTER", Options.partypet.frame.position.hpx, Options.partypet.frame.position.hpy)
	end
end
---------------------------------------------------------
function partypetMpXSliderOnLoad()
	partypetMpXSlider:SetMinMaxValues(-1000,1000)
	local sliderMin, sliderMax = partypetMpXSlider:GetMinMaxValues()
	getglobal(partypetMpXSlider:GetName().."Low"):SetText(sliderMin)
	getglobal(partypetMpXSlider:GetName().."High"):SetText(sliderMax)
	partypetMpXSlider:SetOrientation("HORIZONTAL")
	partypetMpXSlider:SetValueStep(1)
	partypetMpXSlider:SetValue(Options.partypet.frame.position.mpx)
end

function partypetMpXSliderOnValueChanged()
	if partypetMpXSlider:GetValue() then 
		partypetMpXSlider:SetValue(partypetMpXSlider:GetValue())
		Options.partypet.frame.position.mpx=partypetMpXSlider:GetValue()
		partypetMpXStatus:SetText(Options.partypet.frame.position.mpx)
		
		MP_PARTYPET1_FRAME:ClearAllPoints()
		MP_PARTYPET1_FRAME:SetPoint("BOTTOMLEFT", nil, "CENTER", Options.partypet.frame.position.mpx, Options.partypet.frame.position.mpy)
	end
end
---------------------------------------------------------
function partypetMpYSliderOnLoad()
	partypetMpYSlider:SetMinMaxValues(-1000,1000)
	local sliderMin, sliderMax = partypetMpYSlider:GetMinMaxValues()
	getglobal(partypetMpYSlider:GetName().."Low"):SetText(sliderMin)
	getglobal(partypetMpYSlider:GetName().."High"):SetText(sliderMax)
	partypetMpYSlider:SetOrientation("HORIZONTAL")
	partypetMpYSlider:SetValueStep(1)
	partypetMpYSlider:SetValue(Options.partypet.frame.position.mpy)
end

function partypetMpYSliderOnValueChanged()
	if partypetMpYSlider:GetValue() then 
		partypetMpYSlider:SetValue(partypetMpYSlider:GetValue())
		Options.partypet.frame.position.mpy=partypetMpYSlider:GetValue()
		partypetMpYStatus:SetText(Options.partypet.frame.position.mpy)
		
		MP_PARTYPET1_FRAME:ClearAllPoints()
		MP_PARTYPET1_FRAME:SetPoint("BOTTOMLEFT", nil, "CENTER", Options.partypet.frame.position.mpx, Options.partypet.frame.position.mpy)
	end
end
---------------------------------------------------------
