
function gHUDDropdownMenu()

	local frame = this:GetName()
	local n = GetNumPartyMembers()
	local x = Options.player.frame.bg.width
	local y1 = Options.player.frame.bg.height
	local y2 = ((Options.player.frame.bg.height-(n-1)*Options.party.frame.gap)/n)
	
	if (arg1 == "RightButton") then
		if (frame=="HP_Player_Button") or (frame=="MP_Player_Button") then
			ToggleDropDownMenu(1, nil, PlayerFrameDropDown, frame, x, y1)
		elseif (frame=="HP_Target_Button") or (frame=="MP_Target_Button") then
			ToggleDropDownMenu(1, nil, TargetFrameDropDown, frame, x, y1)
		elseif (frame=="HP_Pet_Button") or (frame=="MP_Pet_Button") then
			ToggleDropDownMenu(1, nil, PetFrameDropDown, frame, x, y1/2)
		elseif (frame=="HP_Party1_Button") or (frame=="MP_Party1_Button") then
			ToggleDropDownMenu(1, nil, PartyMemberFrame1DropDown, frame, x, y2)
		elseif (frame=="HP_Party2_Button") or (frame=="MP_Party2_Button") then
			ToggleDropDownMenu(1, nil, PartyMemberFrame2DropDown, frame, x, y2)
		elseif (frame=="HP_Party3_Button") or (frame=="MP_Party3_Button") then
			ToggleDropDownMenu(1, nil, PartyMemberFrame3DropDown, frame, x, y2)
		elseif (frame=="HP_Party4_Button") or (frame=="MP_Party4_Button") then
			ToggleDropDownMenu(1, nil, PartyMemberFrame4DropDown, frame, x, y2)
		else 
			DEFAULT_CHAT_FRAME:AddMessage("no match")
		end
	end
end
