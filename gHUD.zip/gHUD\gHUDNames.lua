

function NamePlayer(unit,fNam)
	---[[
	local name = string.sub(UnitName(unit), 1, Options.player.name.format)
	local level = UnitLevel(unit)
	
	if ((Options.player.name.active==1) and (Options.player.name.level==0)) then
		ColorClass(unit,fNam)
		fNam:SetText(name) 
	elseif ((Options.player.name.active==1) and (Options.player.name.level==1)) then
		ColorClass(unit,fNam)
		fNam:SetText(level .." " ..name) 
	elseif ((Options.player.name.active==0) and (Options.player.name.level==1)) then
		ColorClass(unit,fNam)
		fNam:SetText(level) 
	elseif ((Options.player.name.active==0) and (Options.player.name.level==0)) then
		if (fNam:GetText()~=nil) then
			fNam:SetText()
		end
	end		
	--]]
end

function NameParty(unit,fNam)
---[[
	local name = string.sub(UnitName(unit), 1, Options.party.name.format)
	local level = UnitLevel(unit)
	
	if ((Options.party.name.active==1) and (Options.party.name.level==0)) then
		ColorClass(unit,fNam)
		fNam:SetText(name) 
	elseif ((Options.party.name.active==1) and (Options.party.name.level==1)) then
		ColorClass(unit,fNam)
		fNam:SetText(level .." " ..name) 
	elseif ((Options.party.name.active==0) and (Options.party.name.level==1)) then
		ColorClass(unit,fNam)
		fNam:SetText(level) 
	elseif ((Options.party.name.active==0) and (Options.party.name.level==0)) then
		if (fNam:GetText()~=nil) then
			fNam:SetText()
		end
	end		
	---]]
end

function NamePartyPet(unit,fNam)
---[[
	if UnitName(unit)==nil then unit = "player" end
	
	local name = string.sub(UnitName(unit), 1, Options.partypet.name.format)
	local level = UnitLevel(unit)
	
	if ((Options.partypet.name.active==1) and (Options.partypet.name.level==0)) then
		ColorClass(unit,fNam)
		fNam:SetText(name) 
	elseif ((Options.partypet.name.active==1) and (Options.partypet.name.level==1)) then
		ColorClass(unit,fNam)
		fNam:SetText(level .." " ..name) 
	elseif ((Options.partypet.name.active==0) and (Options.partypet.name.level==1)) then
		ColorClass(unit,fNam)
		fNam:SetText(level) 
	elseif ((Options.partypet.name.active==0) and (Options.partypet.name.level==0)) then
		if (fNam:GetText()~=nil) then
			fNam:SetText()
		end
	end		
	---]]
end

function NamePet(unit,fNam)
---[[
	local name = string.sub(UnitName(unit), 1, Options.pet.name.format)
	local level = UnitLevel(unit)
	
	if ((Options.pet.name.active==1) and (Options.pet.name.level==0)) then
		ColorClass(unit,fNam)
		fNam:SetText(name) 
	elseif ((Options.pet.name.active==1) and (Options.pet.name.level==1)) then
		ColorClass(unit,fNam)
		fNam:SetText(level .." " ..name) 
	elseif ((Options.pet.name.active==0) and (Options.pet.name.level==1)) then
		ColorClass(unit,fNam)
		fNam:SetText(level) 
	elseif ((Options.pet.name.active==0) and (Options.pet.name.level==0)) then
		if (fNam:GetText()~=nil) then
			fNam:SetText()
		end
	end		
	---]]
end

function NameTarget(unit,fNam)
---[[
	local name = string.sub(UnitName(unit), 1, Options.target.name.format)
	local level = UnitLevel(unit)
	local class = UnitClassification(unit)  	-- "worldboss", "rareelite", "elite", "rare" or "normal"
	
	if ((Options.target.name.active==1) and (Options.target.name.level==0)) then
		if (class=="elite") then
			ColorClass(unit,fNam)
			fNam:SetText(name .." (Elite)") 
		elseif (class=="rare") then
			ColorClass(unit,fNam)
			fNam:SetText(name .." (Rare)") 
		elseif (class=="rareelite") then
			ColorClass(unit,fNam)
			fNam:SetText(name .." (RareElite)") 
		elseif (class=="normal") then
			ColorClass(unit,fNam)
			fNam:SetText(name) 
		elseif (class=="worldboss") then
			ColorClass(unit,fNam)
			fNam:SetText(name .." (Worldboss)") 
		end
	elseif ((Options.target.name.active==1) and (Options.target.name.level==1)) then
		if (class=="elite") then
			ColorClass(unit,fNam)
			fNam:SetText(name .." " ..level .." (Elite)") 
		elseif (class=="rare") then
			ColorClass(unit,fNam)
			fNam:SetText(name .." " ..level .." (Rare)") 
		elseif (class=="rareelite") then
			ColorClass(unit,fNam)
			fNam:SetText(name .." " ..level .." (RareElite)") 
		elseif (class=="normal") then
			ColorClass(unit,fNam)
			fNam:SetText(name .." " ..level) 
		elseif (class=="worldboss") then
			ColorClass(unit,fNam)
			fNam:SetText(name .." (Worldboss)") 
		end
	elseif ((Options.target.name.active==0) and (Options.target.name.level==1)) then
		if (class=="elite") then
			ColorClass(unit,fNam)
			fNam:SetText(level .." (Elite)") 
		elseif (class=="rare") then
			ColorClass(unit,fNam)
			fNam:SetText(level .." (Rare)") 
		elseif (class=="rareelite") then
			ColorClass(unit,fNam)
			fNam:SetText(level .." (RareElite)") 
		elseif (class=="normal") then
			ColorClass(unit,fNam)
			fNam:SetText(level) 
		elseif (class=="worldboss") then
			ColorClass(unit,fNam)
			fNam:SetText(name .." (Worldboss)") 
		end
	elseif ((Options.target.name.active==0) and (Options.target.name.level==0)) then
		if (fNam:GetText()~=nil) then
			fNam:SetText()
		end
	end		
	---]]
end

function NameTargetTarget(unit,fNam)
---[[
	local name = string.sub(UnitName(unit), 1, Options.tt.name.format)
	local level = UnitLevel(unit)
	local class = UnitClassification(unit)  	-- "worldboss", "rareelite", "elite", "rare" or "normal"
	
	if ((Options.tt.name.active==1) and (Options.tt.name.level==0)) then
		if (class=="elite") then
			ColorClass(unit,fNam)
			fNam:SetText(name .." (Elite)") 
		elseif (class=="rare") then
			ColorClass(unit,fNam)
			fNam:SetText(name .." (Rare)") 
		elseif (class=="rareelite") then
			ColorClass(unit,fNam)
			fNam:SetText(name .." (RareElite)") 
		elseif (class=="normal") then
			ColorClass(unit,fNam)
			fNam:SetText(name) 
		elseif (class=="worldboss") then
			ColorClass(unit,fNam)
			fNam:SetText(name .." (Worldboss)") 
		end
	elseif ((Options.tt.name.active==1) and (Options.tt.name.level==1)) then
		if (class=="elite") then
			ColorClass(unit,fNam)
			fNam:SetText(name .." " ..level .." (Elite)") 
		elseif (class=="rare") then
			ColorClass(unit,fNam)
			fNam:SetText(name .." " ..level .." (Rare)") 
		elseif (class=="rareelite") then
			ColorClass(unit,fNam)
			fNam:SetText(name .." " ..level .." (RareElite)") 
		elseif (class=="normal") then
			ColorClass(unit,fNam)
			fNam:SetText(name .." " ..level) 
		elseif (class=="worldboss") then
			ColorClass(unit,fNam)
			fNam:SetText(name .." (Worldboss)") 
		end
	elseif ((Options.tt.name.active==0) and (Options.tt.name.level==1)) then
		if (class=="elite") then
			ColorClass(unit,fNam)
			fNam:SetText(level .." (Elite)") 
		elseif (class=="rare") then
			ColorClass(unit,fNam)
			fNam:SetText(level .." (Rare)") 
		elseif (class=="rareelite") then
			ColorClass(unit,fNam)
			fNam:SetText(level .." (RareElite)") 
		elseif (class=="normal") then
			ColorClass(unit,fNam)
			fNam:SetText(level) 
		elseif (class=="worldboss") then
			ColorClass(unit,fNam)
			fNam:SetText(name .." (Worldboss)") 
		end
	elseif ((Options.tt.name.active==0) and (Options.tt.name.level==0)) then
		if (fNam:GetText()~=nil) then
			fNam:SetText()
		end
	end		
	---]]
end


function gHUDNameDirection()
	
	if (Options.font.direction.hpplayer==1) then
		HP_PLAYER_MAX:ClearAllPoints()
		HP_PLAYER_MAX:SetPoint(Options.frame.anchor.a3, 		HP_PLAYER_FRAME, 	Options.frame.anchor.a1, Options.font.offset.x1, Options.font.offset.y3)
		HP_PLAYER_NAME:ClearAllPoints()
		HP_PLAYER_NAME:SetPoint(Options.frame.anchor.a3, 		HP_PLAYER_MAX, 		Options.frame.anchor.a1, Options.font.offset.x1, Options.font.offset.y3)
		HP_PLAYER_PERCENT:ClearAllPoints()
		HP_PLAYER_PERCENT:SetPoint(Options.frame.anchor.a1, 	HP_PLAYER_FRAME, 	Options.frame.anchor.a3, Options.font.offset.x1, -Options.font.offset.y2)
		HP_PLAYER_DEFICIT:ClearAllPoints()
		HP_PLAYER_DEFICIT:SetPoint(Options.frame.anchor.a1, 	HP_PLAYER_BAR, 		Options.frame.anchor.a2, -Options.font.offset.x2, Options.font.offset.y1)
	elseif (Options.font.direction.hpplayer==0) then
		HP_PLAYER_MAX:ClearAllPoints()		
		HP_PLAYER_MAX:SetPoint(Options.frame.anchor.a4, 		HP_PLAYER_FRAME, 	Options.frame.anchor.a2, Options.font.offset.x1, Options.font.offset.y3)
		HP_PLAYER_NAME:ClearAllPoints()
		HP_PLAYER_NAME:SetPoint(Options.frame.anchor.a4, 		HP_PLAYER_MAX, 		Options.frame.anchor.a2, Options.font.offset.x1, Options.font.offset.y3)
		HP_PLAYER_PERCENT:ClearAllPoints()
		HP_PLAYER_PERCENT:SetPoint(Options.frame.anchor.a2, 	HP_PLAYER_FRAME, 	Options.frame.anchor.a4, Options.font.offset.x1, -Options.font.offset.y2)
		HP_PLAYER_DEFICIT:ClearAllPoints()
		HP_PLAYER_DEFICIT:SetPoint(Options.frame.anchor.a2, 	HP_PLAYER_BAR, 		Options.frame.anchor.a1, Options.font.offset.x2, Options.font.offset.y1)
	end
	
	if (Options.font.direction.hpparty==1) then
		HP_PARTY1_NAME:ClearAllPoints()
		HP_PARTY1_NAME:SetPoint(Options.frame.anchor.a1, 		HP_PARTY1_BG_TEXTURE1, 		Options.frame.anchor.a2, -Options.font.offset.x2, Options.font.offset.y1)
		HP_PARTY1_DEFICIT:ClearAllPoints()
		HP_PARTY1_DEFICIT:SetPoint(Options.frame.anchor.a1, 	HP_PARTY1_BAR, 				Options.frame.anchor.a2, -Options.font.offset.x2, Options.font.offset.y1)
		HP_PARTY2_NAME:ClearAllPoints()
		HP_PARTY2_NAME:SetPoint(Options.frame.anchor.a1, 		HP_PARTY2_BG_TEXTURE1, 		Options.frame.anchor.a2, -Options.font.offset.x2, Options.font.offset.y1)
		HP_PARTY2_DEFICIT:ClearAllPoints()
		HP_PARTY2_DEFICIT:SetPoint(Options.frame.anchor.a1, 	HP_PARTY2_BAR, 				Options.frame.anchor.a2, -Options.font.offset.x2, Options.font.offset.y1)
		HP_PARTY3_NAME:ClearAllPoints()
		HP_PARTY3_NAME:SetPoint(Options.frame.anchor.a1, 		HP_PARTY3_BG_TEXTURE1, 		Options.frame.anchor.a2, -Options.font.offset.x2, Options.font.offset.y1)
		HP_PARTY3_DEFICIT:ClearAllPoints()
		HP_PARTY3_DEFICIT:SetPoint(Options.frame.anchor.a1, 	HP_PARTY3_BAR, 				Options.frame.anchor.a2, -Options.font.offset.x2, Options.font.offset.y1)
		HP_PARTY4_NAME:ClearAllPoints()
		HP_PARTY4_NAME:SetPoint(Options.frame.anchor.a1, 		HP_PARTY4_BG_TEXTURE1, 		Options.frame.anchor.a2, -Options.font.offset.x2, Options.font.offset.y1)
		HP_PARTY4_DEFICIT:ClearAllPoints()
		HP_PARTY4_DEFICIT:SetPoint(Options.frame.anchor.a1, 	HP_PARTY4_BAR, 				Options.frame.anchor.a2, -Options.font.offset.x2, Options.font.offset.y1)
	elseif (Options.font.direction.hpparty==0) then
		HP_PARTY1_NAME:ClearAllPoints()
		HP_PARTY1_NAME:SetPoint(Options.frame.anchor.a2, 		HP_PARTY1_BG_TEXTURE1, 		Options.frame.anchor.a1, Options.font.offset.x2, Options.font.offset.y1)
		HP_PARTY1_DEFICIT:ClearAllPoints()
		HP_PARTY1_DEFICIT:SetPoint(Options.frame.anchor.a2, 	HP_PARTY1_BAR, 				Options.frame.anchor.a1, Options.font.offset.x2, Options.font.offset.y1)
		HP_PARTY2_NAME:ClearAllPoints()
		HP_PARTY2_NAME:SetPoint(Options.frame.anchor.a2, 		HP_PARTY2_BG_TEXTURE1, 		Options.frame.anchor.a1, Options.font.offset.x2, Options.font.offset.y1)
		HP_PARTY2_DEFICIT:ClearAllPoints()
		HP_PARTY2_DEFICIT:SetPoint(Options.frame.anchor.a2, 	HP_PARTY2_BAR, 				Options.frame.anchor.a1, Options.font.offset.x2, Options.font.offset.y1)
		HP_PARTY3_NAME:ClearAllPoints()
		HP_PARTY3_NAME:SetPoint(Options.frame.anchor.a2, 		HP_PARTY3_BG_TEXTURE1, 		Options.frame.anchor.a1, Options.font.offset.x2, Options.font.offset.y1)
		HP_PARTY3_DEFICIT:ClearAllPoints()
		HP_PARTY3_DEFICIT:SetPoint(Options.frame.anchor.a2, 	HP_PARTY3_BAR, 				Options.frame.anchor.a1, Options.font.offset.x2, Options.font.offset.y1)
		HP_PARTY4_NAME:ClearAllPoints()
		HP_PARTY4_NAME:SetPoint(Options.frame.anchor.a2, 		HP_PARTY4_BG_TEXTURE1, 		Options.frame.anchor.a1, Options.font.offset.x2, Options.font.offset.y1)
		HP_PARTY4_DEFICIT:ClearAllPoints()
		HP_PARTY4_DEFICIT:SetPoint(Options.frame.anchor.a2, 	HP_PARTY4_BAR, 				Options.frame.anchor.a1, Options.font.offset.x2, Options.font.offset.y1)
	end
	
	if (Options.font.direction.hppartpet==1) then
		HP_PARTYPET1_NAME:ClearAllPoints()
		HP_PARTYPET1_NAME:SetPoint(Options.frame.anchor.a1, 		HP_PARTYPET1_BG_TEXTURE1, 		Options.frame.anchor.a2, -Options.font.offset.x2, Options.font.offset.y1)
		HP_PARTYPET2_NAME:ClearAllPoints()
		HP_PARTYPET2_NAME:SetPoint(Options.frame.anchor.a1, 		HP_PARTYPET2_BG_TEXTURE1, 		Options.frame.anchor.a2, -Options.font.offset.x2, Options.font.offset.y1)
		HP_PARTYPET3_NAME:ClearAllPoints()
		HP_PARTYPET3_NAME:SetPoint(Options.frame.anchor.a1, 		HP_PARTYPET3_BG_TEXTURE1, 		Options.frame.anchor.a2, -Options.font.offset.x2, Options.font.offset.y1)
		HP_PARTYPET4_NAME:ClearAllPoints()
		HP_PARTYPET4_NAME:SetPoint(Options.frame.anchor.a1, 		HP_PARTYPET4_BG_TEXTURE1, 		Options.frame.anchor.a2, -Options.font.offset.x2, Options.font.offset.y1)
	elseif (Options.font.direction.hppartpet==0) then
		HP_PARTYPET1_NAME:ClearAllPoints()
		HP_PARTYPET1_NAME:SetPoint(Options.frame.anchor.a2, 		HP_PARTYPET1_BG_TEXTURE1, 		Options.frame.anchor.a1, Options.font.offset.x2, Options.font.offset.y1)
		HP_PARTYPET2_NAME:ClearAllPoints()
		HP_PARTYPET2_NAME:SetPoint(Options.frame.anchor.a2, 		HP_PARTYPET2_BG_TEXTURE1, 		Options.frame.anchor.a1, Options.font.offset.x2, Options.font.offset.y1)
		HP_PARTYPET3_NAME:ClearAllPoints()
		HP_PARTYPET3_NAME:SetPoint(Options.frame.anchor.a2, 		HP_PARTYPET3_BG_TEXTURE1, 		Options.frame.anchor.a1, Options.font.offset.x2, Options.font.offset.y1)
		HP_PARTYPET4_NAME:ClearAllPoints()
		HP_PARTYPET4_NAME:SetPoint(Options.frame.anchor.a2, 		HP_PARTYPET4_BG_TEXTURE1, 		Options.frame.anchor.a1, Options.font.offset.x2, Options.font.offset.y1)
	end
	
	if (Options.font.direction.hppet==1) then
		HP_PET_MAX:ClearAllPoints()
		HP_PET_MAX:SetPoint(Options.frame.anchor.a3, 		HP_PET_FRAME, 	Options.frame.anchor.a1, Options.font.offset.x1, Options.font.offset.y3)
		HP_PET_NAME:ClearAllPoints()
		HP_PET_NAME:SetPoint(Options.frame.anchor.a3, 		HP_PET_MAX, 	Options.frame.anchor.a1, Options.font.offset.x1, Options.font.offset.y3)
		HP_PET_PERCENT:ClearAllPoints()
		HP_PET_PERCENT:SetPoint(Options.frame.anchor.a1, 	HP_PET_FRAME, 	Options.frame.anchor.a3, Options.font.offset.x1, -Options.font.offset.y2)
		HP_PET_DEFICIT:ClearAllPoints()
		HP_PET_DEFICIT:SetPoint(Options.frame.anchor.a1, 	HP_PET_BAR, 	Options.frame.anchor.a2, -Options.font.offset.x2, Options.font.offset.y1)
	elseif (Options.font.direction.hppet==0) then
		HP_PET_MAX:ClearAllPoints()		
		HP_PET_MAX:SetPoint(Options.frame.anchor.a4, 		HP_PET_FRAME, 	Options.frame.anchor.a2, Options.font.offset.x1, Options.font.offset.y3)
		HP_PET_NAME:ClearAllPoints()
		HP_PET_NAME:SetPoint(Options.frame.anchor.a4, 		HP_PET_MAX, 	Options.frame.anchor.a2, Options.font.offset.x1, Options.font.offset.y3)
		HP_PET_PERCENT:ClearAllPoints()
		HP_PET_PERCENT:SetPoint(Options.frame.anchor.a2, 	HP_PET_FRAME, 	Options.frame.anchor.a4, Options.font.offset.x1, -Options.font.offset.y2)
		HP_PET_DEFICIT:ClearAllPoints()
		HP_PET_DEFICIT:SetPoint(Options.frame.anchor.a2, 	HP_PET_BAR, 	Options.frame.anchor.a1, Options.font.offset.x2, Options.font.offset.y1)
	end
	
	if (Options.font.direction.hptarget==1) then
		HP_TARGET_MAX:ClearAllPoints()
		HP_TARGET_MAX:SetPoint(Options.frame.anchor.a3, 		HP_TARGET_FRAME, 	Options.frame.anchor.a1, Options.font.offset.x1, Options.font.offset.y3)
		HP_TARGET_NAME:ClearAllPoints()
		HP_TARGET_NAME:SetPoint(Options.frame.anchor.a3, 		HP_TARGET_MAX, 		Options.frame.anchor.a1, Options.font.offset.x1, Options.font.offset.y3)
		HP_TARGET_PERCENT:ClearAllPoints()
		HP_TARGET_PERCENT:SetPoint(Options.frame.anchor.a1, 	HP_TARGET_FRAME, 	Options.frame.anchor.a3, Options.font.offset.x1, -Options.font.offset.y2)
		HP_TARGET_DEFICIT:ClearAllPoints()
		HP_TARGET_DEFICIT:SetPoint(Options.frame.anchor.a1, 	HP_TARGET_BAR, 		Options.frame.anchor.a2, -Options.font.offset.x2, Options.font.offset.y1)
	elseif (Options.font.direction.hptarget==0) then
		HP_TARGET_MAX:ClearAllPoints()		
		HP_TARGET_MAX:SetPoint(Options.frame.anchor.a4, 		HP_TARGET_FRAME, 	Options.frame.anchor.a2, Options.font.offset.x1, Options.font.offset.y3)
		HP_TARGET_NAME:ClearAllPoints()
		HP_TARGET_NAME:SetPoint(Options.frame.anchor.a4, 		HP_TARGET_MAX, 		Options.frame.anchor.a2, Options.font.offset.x1, Options.font.offset.y3)
		HP_TARGET_PERCENT:ClearAllPoints()
		HP_TARGET_PERCENT:SetPoint(Options.frame.anchor.a2, 	HP_TARGET_FRAME, 	Options.frame.anchor.a4, Options.font.offset.x1, -Options.font.offset.y2)
		HP_TARGET_DEFICIT:ClearAllPoints()
		HP_TARGET_DEFICIT:SetPoint(Options.frame.anchor.a2, 	HP_TARGET_BAR, 		Options.frame.anchor.a1, Options.font.offset.x2, Options.font.offset.y1)
	end
	
	if (Options.font.direction.hptt==1) then
		HP_TARGETTARGET_MAX:ClearAllPoints()
		HP_TARGETTARGET_MAX:SetPoint(Options.frame.anchor.a3, 		HP_TARGETTARGET_FRAME, 		Options.frame.anchor.a1, Options.font.offset.x1, Options.font.offset.y3)
		HP_TARGETTARGET_NAME:ClearAllPoints()
		HP_TARGETTARGET_NAME:SetPoint(Options.frame.anchor.a3, 		HP_TARGETTARGET_MAX, 		Options.frame.anchor.a1, Options.font.offset.x1, Options.font.offset.y3)
		HP_TARGETTARGET_PERCENT:ClearAllPoints()
		HP_TARGETTARGET_PERCENT:SetPoint(Options.frame.anchor.a1, 	HP_TARGETTARGET_FRAME, 		Options.frame.anchor.a3, Options.font.offset.x1, -Options.font.offset.y2)
		HP_TARGETTARGET_DEFICIT:ClearAllPoints()
		HP_TARGETTARGET_DEFICIT:SetPoint(Options.frame.anchor.a1, 	HP_TARGETTARGET_BAR, 		Options.frame.anchor.a2, -Options.font.offset.x2, Options.font.offset.y1)
	elseif (Options.font.direction.hptt==0) then
		HP_TARGETTARGET_MAX:ClearAllPoints()		
		HP_TARGETTARGET_MAX:SetPoint(Options.frame.anchor.a4, 		HP_TARGETTARGET_FRAME, 		Options.frame.anchor.a2, Options.font.offset.x1, Options.font.offset.y3)
		HP_TARGETTARGET_NAME:ClearAllPoints()
		HP_TARGETTARGET_NAME:SetPoint(Options.frame.anchor.a4, 		HP_TARGETTARGET_MAX, 		Options.frame.anchor.a2, Options.font.offset.x1, Options.font.offset.y3)
		HP_TARGETTARGET_PERCENT:ClearAllPoints()
		HP_TARGETTARGET_PERCENT:SetPoint(Options.frame.anchor.a2, 	HP_TARGETTARGET_FRAME, 		Options.frame.anchor.a4, Options.font.offset.x1, -Options.font.offset.y2)
		HP_TARGETTARGET_DEFICIT:ClearAllPoints()
		HP_TARGETTARGET_DEFICIT:SetPoint(Options.frame.anchor.a2, 	HP_TARGETTARGET_BAR, 		Options.frame.anchor.a1, Options.font.offset.x2, Options.font.offset.y1)
	end
	
	if (Options.font.direction.mpplayer==1) then
		MP_PLAYER_MAX:ClearAllPoints()
		MP_PLAYER_MAX:SetPoint(Options.frame.anchor.a3, 		MP_PLAYER_FRAME, 	Options.frame.anchor.a1, Options.font.offset.x1, Options.font.offset.y3)
		MP_PLAYER_PERCENT:ClearAllPoints()
		MP_PLAYER_PERCENT:SetPoint(Options.frame.anchor.a1, 	MP_PLAYER_FRAME, 	Options.frame.anchor.a3, Options.font.offset.x1, -Options.font.offset.y2)
		MP_PLAYER_DEFICIT:ClearAllPoints()
		MP_PLAYER_DEFICIT:SetPoint(Options.frame.anchor.a1, 	MP_PLAYER_BAR, 		Options.frame.anchor.a2, -Options.font.offset.x2, Options.font.offset.y1)
	elseif (Options.font.direction.mpplayer==0) then
		MP_PLAYER_MAX:ClearAllPoints()		
		MP_PLAYER_MAX:SetPoint(Options.frame.anchor.a4, 		MP_PLAYER_FRAME, 	Options.frame.anchor.a2, Options.font.offset.x1, Options.font.offset.y3)
		MP_PLAYER_PERCENT:ClearAllPoints()
		MP_PLAYER_PERCENT:SetPoint(Options.frame.anchor.a2, 	MP_PLAYER_FRAME, 	Options.frame.anchor.a4, Options.font.offset.x1, -Options.font.offset.y2)
		MP_PLAYER_DEFICIT:ClearAllPoints()
		MP_PLAYER_DEFICIT:SetPoint(Options.frame.anchor.a2, 	MP_PLAYER_BAR, 		Options.frame.anchor.a1, Options.font.offset.x2, Options.font.offset.y1)
	end
	
	if (Options.font.direction.mpparty==1) then
		MP_PARTY1_DEFICIT:ClearAllPoints()
		MP_PARTY1_DEFICIT:SetPoint(Options.frame.anchor.a1, 	MP_PARTY1_BAR, 		Options.frame.anchor.a2, -Options.font.offset.x2, Options.font.offset.y1)
		MP_PARTY2_DEFICIT:ClearAllPoints()
		MP_PARTY2_DEFICIT:SetPoint(Options.frame.anchor.a1, 	MP_PARTY2_BAR, 		Options.frame.anchor.a2, -Options.font.offset.x2, Options.font.offset.y1)
		MP_PARTY3_DEFICIT:ClearAllPoints()
		MP_PARTY3_DEFICIT:SetPoint(Options.frame.anchor.a1, 	MP_PARTY3_BAR, 		Options.frame.anchor.a2, -Options.font.offset.x2, Options.font.offset.y1)
		MP_PARTY4_DEFICIT:ClearAllPoints()
		MP_PARTY4_DEFICIT:SetPoint(Options.frame.anchor.a1, 	MP_PARTY4_BAR, 		Options.frame.anchor.a2, -Options.font.offset.x2, Options.font.offset.y1)
	elseif (Options.font.direction.mpparty==0) then
		MP_PARTY1_DEFICIT:ClearAllPoints()
		MP_PARTY1_DEFICIT:SetPoint(Options.frame.anchor.a2, 	MP_PARTY1_BAR, 		Options.frame.anchor.a1, Options.font.offset.x2, Options.font.offset.y1)
		MP_PARTY2_DEFICIT:ClearAllPoints()
		MP_PARTY2_DEFICIT:SetPoint(Options.frame.anchor.a2, 	MP_PARTY2_BAR, 		Options.frame.anchor.a1, Options.font.offset.x2, Options.font.offset.y1)
		MP_PARTY3_DEFICIT:ClearAllPoints()
		MP_PARTY3_DEFICIT:SetPoint(Options.frame.anchor.a2, 	MP_PARTY3_BAR, 		Options.frame.anchor.a1, Options.font.offset.x2, Options.font.offset.y1)
		MP_PARTY4_DEFICIT:ClearAllPoints()
		MP_PARTY4_DEFICIT:SetPoint(Options.frame.anchor.a2, 	MP_PARTY4_BAR, 		Options.frame.anchor.a1, Options.font.offset.x2, Options.font.offset.y1)
	end
		
	if (Options.font.direction.mppet==1) then
		MP_PET_MAX:ClearAllPoints()
		MP_PET_MAX:SetPoint(Options.frame.anchor.a3, 		MP_PET_FRAME, 	Options.frame.anchor.a1, Options.font.offset.x1, Options.font.offset.y3)
		MP_PET_PERCENT:ClearAllPoints()
		MP_PET_PERCENT:SetPoint(Options.frame.anchor.a1, 	MP_PET_FRAME, 	Options.frame.anchor.a3, Options.font.offset.x1, -Options.font.offset.y2)
		MP_PET_DEFICIT:ClearAllPoints()
		MP_PET_DEFICIT:SetPoint(Options.frame.anchor.a1, 	MP_PET_BAR, 	Options.frame.anchor.a2, -Options.font.offset.x2, Options.font.offset.y1)
	elseif (Options.font.direction.mppet==0) then
		MP_PET_MAX:ClearAllPoints()		
		MP_PET_MAX:SetPoint(Options.frame.anchor.a4, 		MP_PET_FRAME, 	Options.frame.anchor.a2, Options.font.offset.x1, Options.font.offset.y3)
		MP_PET_PERCENT:ClearAllPoints()
		MP_PET_PERCENT:SetPoint(Options.frame.anchor.a2, 	MP_PET_FRAME, 	Options.frame.anchor.a4, Options.font.offset.x1, -Options.font.offset.y2)
		MP_PET_DEFICIT:ClearAllPoints()
		MP_PET_DEFICIT:SetPoint(Options.frame.anchor.a2, 	MP_PET_BAR, 	Options.frame.anchor.a1, Options.font.offset.x2, Options.font.offset.y1)
	end
	
	if (Options.font.direction.mptarget==1) then
		MP_TARGET_MAX:ClearAllPoints()
		MP_TARGET_MAX:SetPoint(Options.frame.anchor.a3, 		MP_TARGET_FRAME, 	Options.frame.anchor.a1, Options.font.offset.x1, Options.font.offset.y3)
		MP_TARGET_PERCENT:ClearAllPoints()
		MP_TARGET_PERCENT:SetPoint(Options.frame.anchor.a1, 	MP_TARGET_FRAME, 	Options.frame.anchor.a3, Options.font.offset.x1, -Options.font.offset.y2)
		MP_TARGET_DEFICIT:ClearAllPoints()
		MP_TARGET_DEFICIT:SetPoint(Options.frame.anchor.a1, 	MP_TARGET_BAR, 		Options.frame.anchor.a2, -Options.font.offset.x2, Options.font.offset.y1)
	elseif (Options.font.direction.mptarget==0) then
		MP_TARGET_MAX:ClearAllPoints()		
		MP_TARGET_MAX:SetPoint(Options.frame.anchor.a4, 		MP_TARGET_FRAME, 	Options.frame.anchor.a2, Options.font.offset.x1, Options.font.offset.y3)
		MP_TARGET_PERCENT:ClearAllPoints()
		MP_TARGET_PERCENT:SetPoint(Options.frame.anchor.a2, 	MP_TARGET_FRAME, 	Options.frame.anchor.a4, Options.font.offset.x1, -Options.font.offset.y2)
		MP_TARGET_DEFICIT:ClearAllPoints()
		MP_TARGET_DEFICIT:SetPoint(Options.frame.anchor.a2, 	MP_TARGET_BAR, 		Options.frame.anchor.a1, Options.font.offset.x2, Options.font.offset.y1)
	end
	
	if (Options.font.direction.mptt==1) then
		MP_TARGETTARGET_MAX:ClearAllPoints()
		MP_TARGETTARGET_MAX:SetPoint(Options.frame.anchor.a3, 		MP_TARGETTARGET_FRAME, 		Options.frame.anchor.a1, Options.font.offset.x1, Options.font.offset.y3)
		MP_TARGETTARGET_PERCENT:ClearAllPoints()
		MP_TARGETTARGET_PERCENT:SetPoint(Options.frame.anchor.a1, 	MP_TARGETTARGET_FRAME, 		Options.frame.anchor.a3, Options.font.offset.x1, -Options.font.offset.y2)
		MP_TARGETTARGET_DEFICIT:ClearAllPoints()
		MP_TARGETTARGET_DEFICIT:SetPoint(Options.frame.anchor.a1, 	MP_TARGETTARGET_BAR, 		Options.frame.anchor.a2, -Options.font.offset.x2, Options.font.offset.y1)
	elseif (Options.font.direction.mptt==0) then
		MP_TARGETTARGET_MAX:ClearAllPoints()		
		MP_TARGETTARGET_MAX:SetPoint(Options.frame.anchor.a4, 		MP_TARGETTARGET_FRAME, 		Options.frame.anchor.a2, Options.font.offset.x1, Options.font.offset.y3)
		MP_TARGETTARGET_PERCENT:ClearAllPoints()
		MP_TARGETTARGET_PERCENT:SetPoint(Options.frame.anchor.a2, 	MP_TARGETTARGET_FRAME, 		Options.frame.anchor.a4, Options.font.offset.x1, -Options.font.offset.y2)
		MP_TARGETTARGET_DEFICIT:ClearAllPoints()
		MP_TARGETTARGET_DEFICIT:SetPoint(Options.frame.anchor.a2, 	MP_TARGETTARGET_BAR, 		Options.frame.anchor.a1, Options.font.offset.x2, Options.font.offset.y1)
	end		
end


