local L = LibStub("AceLocale-3.0"):NewLocale("BT_Gruul", "enUS", true)
if not L then return end

--infos
L["Module resetted"] = "Module resetted" --dont change this line!

L["info"] = "|cff91069ETactics by|r rpguides\n|cff91069EImages by|r Vonswan, rpguides\n|cff91069EModule by|r Sorontur\n\n|cffC0C0C0[http://www.kdh-wow.de]\n[http://www.rpguides.de]|r"

--add here localized tactic texts

L["tactic Maulgar"] =  [[
not yet available

]]

L["tactic Gruul"] =  [[
not yet available

]]

--texts for trash

L["trash Maulgar"] = [[
]]

L["trash Gruul"] = [[]]

--ra text messages every line separated by \n
L["ra Maulgar"] = "line1\nline2\nlin3"
L["ra Gruul"] = ""

--button captions

L["Magertank"] = true
L["Huntertank"] = true
L["group 1"] = true
L["group 2"] = true
L["group 3"] = true
L["group 4"] = true
L["group 5"] = true