-- [item id] = required level, --name
ScrollList_Agility = {
	["3012"] = 10, 	--Scroll of Agility
	["1477"] = 25, 	--Scroll of Agility II
	["4425"] = 40, 	--Scroll of Agility III
	["10309"] = 55, --Scroll of Agility IV
	["27498"] = 60,	--Scroll of Agility V
	["33457"] = 70 	--Scroll of Agility VI
}
ScrollList_Intellect = {	
	["955"] = 5,	--Scroll of Intellect
	["2290"] = 20, 	--Scroll of Intellect II
	["4419"] = 35, 	--Scroll of Intellect III
	["10308"] = 50, --Scroll of Intellect IV
	["27499"] = 60,	--Scroll of Intellect V
	["33458"] = 70 	--Scroll of Intellect VI
}
ScrollList_Protection = {
	["3013"] = 1, 	--Scroll of Protection
	["1478"] = 15, 	--Scroll of Protection II
	["4421"] = 30, 	--Scroll of Protection III
	["10305"] = 45, --Scroll of Protection IV
	["27500"] = 60,	--Scroll of Protection V
	["33459"] = 70 	--Scroll of Protection VI	
}
ScrollList_Spirit = {
	["1181"] = 1, 	--Scroll of Spirit
	["1712"] = 15, 	--Scroll of Spirit II
	["4424"] = 30, 	--Scroll of Spirit III
	["10306"] = 45, --Scroll of Spirit IV
	["27501"] = 60,	--Scroll of Spirit V
	["33460"] = 70 	--Scroll of Spirit VI	
}
ScrollList_Stamina = {
	["1180"] = 5,	--Scroll of Stamina
	["1711"] = 20,	--Scroll of Stamina II
	["4422"] = 35,	--Scroll of Stamina III
	["10307"] = 50,	--Scroll of Stamina IV
	["27502"] = 60,	--Scroll of Stamina V
	["33461"] = 70	--Scroll of Stamina VI
}
ScrollList_Strength = {	
	["954"] = 10,	--Scroll of Strength
	["2289"] = 25,	--Scroll of Strength II
	["4426"] = 40,	--Scroll of Strength III
	["10310"] = 55,	--Scroll of Strength IV
	["27503"] = 60,	--Scroll of Strength V
	["33462"] = 70	--Scroll of Strength VI	
}