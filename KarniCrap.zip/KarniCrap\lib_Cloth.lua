clothList = {
	["2589"] = 5, 	--"Linen Cloth"
	["2592"] = 15, 	--"Wool Cloth"
	["4306"] = 30, 	--"Silk Cloth"
	["4338"] = 40, 	--"Mageweave Cloth"
	["14047"] = 50, --"Runecloth"
	["21877"] = 60, --"Netherweave Cloth"
	["33470"] = 70 	--"Frostweave Cloth"
}