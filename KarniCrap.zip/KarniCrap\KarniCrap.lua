local KARNICRAP_VERSION = "1.8";
--local debug = 1; -- uncomment to show debug messages

--TODO
-- update cooking list
-- update skinnable/gatherable/minable mob list
-- add scroll level sensing
-- ui stuff?
-- add pickpocketing?

-- add a failed message for adding stuff to the white/blacklists
-- Replace blizzard autoloot
-- battleground stuff?
-- add tailor cloths to cloth list
-- prospecting
-- pickpocketing?

--DONE
-- will milling and prospecting work automatically due to lock mechanics?
-- fixed problem with blacklisted items not in cache
-- looting all after skinning/milling/etc should work all the time now. Before it you skinned a corpse and
-- moused over another object (like a totem), it would consider the totem to be the source of the loot and 
-- wouldn't correctly autoloot everything

-- handling of opened objects in inventory
-- added pickpocketing
-- added milling
-- added prospecting

-- added new wotlk health and mana potions
-- added new wotlk food and water


-- OnLoad
function KarniCrap_OnLoad(self)
	echo("Karni's Crap Filter v"..KARNICRAP_VERSION.." loaded (/crap for options)");

	-- Register for player events
	self:RegisterEvent("VARIABLES_LOADED")
	self:RegisterEvent("LOOT_OPENED")
	self:RegisterEvent("LOOT_CLOSED")
	self:RegisterEvent("PARTY_MEMBERS_CHANGED")
	self:RegisterEvent("PLAYER_LEVEL_UP")
	self:RegisterEvent("QUEST_FINISHED")
	self:RegisterEvent("UNIT_SPELLCAST_SUCCEEDED")
	
	
	-- Register for slash functions
	SLASH_KARNICRAP1 = "/karnicrap";
	SLASH_KARNICRAP2 = "/crap";
	SlashCmdList["KARNICRAP"] = function(msg, editBox)
		KarniCrap_CommandHandler(msg);
	end

	SLASH_KARNINOTCRAP1 = "/notcrap";
	SlashCmdList["KARNINOTCRAP"] = function(msg)
		KarniCrap_CommandHandlerNotCrap(msg);
	end
end


-- VARIABLES
	local KarniCrap_variablesLoaded = false		-- shows if variables have been loaded or not

	local selected_category = 1
	local quest_delay = 3						-- amount of delay before quest objectives are checked
	local loot_all = nil						-- variable to set next loot opened to loot all items
	local pickpocketing = nil					-- used to register and unregister events used for pickpocketing
	local listeningforspells = nil				-- used to unregister listening for spell successes
	local details = ""							-- specific filter

	local amount_poor = 0						-- totalled amount for poor filter
	local amount_common = 0						-- totalled amount for common filter
	local item_database = false 				-- set to true if user has an item database mod, else disable first 2 options
	local loot_threshold = 5					-- loot under threshold rarity will be autolooted (default is legendary
	local numberingroup = 0						-- number of people currently in group/raid, 0 is soloing
	local playerlevel = nil						-- tracks current player level
	local playerclass = nil
	
	local blacklist_selected = nil				
	local blacklist_maxVisible = 15			
	local blacklist_numItems = 0
	local blacklist_items = {}

	local whitelist_selected = nil
	local whitelist_maxVisible = 15
	local whitelist_numItems = 0
	local whitelist_items = {}

	local QuestItemList = {}
	local default_Whitelist = {
		["22572"] = "Mote of Air",
		["22573"] = "Mote of Earth",
		["22574"] = "Mote of Fire",
		["22575"] = "Mote of Life",
		["22576"] = "Mote of Mana",
		["22577"] = "Mote of Shadow",
		["22578"] = "Mote of Water",
		["29434"] = "Badge of Justice"
	}


	

-- echos text to the chatbox
function echo(text)
	DEFAULT_CHAT_FRAME:AddMessage(text)
end



-- Handles all the arguements passed in through the slash command
function KarniCrap_CommandHandler(text)
	if ( string.match (text:lower (), "help") ) then
		echo(" ---[ Karni's Crap Filter Help ]---")
		echo(" /crap or /karnicrap will open the options menu")
		echo(" /crap [item] will add an item to the Never Loot list")
		echo(" /notcrap [item] will add an item to the Always Loot list")
	
	elseif ( text ~= "" ) then
		KarniCrap_AddLootToBlacklist(text)

	else
		local frame = getglobal("KarniCrap")
		if (frame) then
			if frame:IsVisible() then
				frame:Hide()
			else
				frame:Show()
			end
		end
	end
end



-- Handles whitelist
function KarniCrap_CommandHandlerNotCrap(text)
	if ( text ~= "" ) then
		KarniCrap_AddLootToWhitelist(text)
	else
		echo("KarniCrap: /notcrap [itemlink] to add an item to the Always Loot list")
	end
end




function KarniCrap_GetUnitID()
	local unitString = UnitGUID("mouseover")
	if (unitString) then -- not a chest/object
		local unitType = bit.band(string.sub(unitString, 1, 5), "0x00F")
		if (unitType == 3) then -- npc and can be compared to the skinnable list
			-- extract the unit ID
		 	local id = tonumber(string.sub(unitString, 6, 12), 16)
		 	id = tostring(id);
			if (id) then
				if debug then echo("UnitID is "..id) end
				return id
			else
				return nil
			end
		end
	end
end



-- attempts to loot everything
function KarniCrap_LootEverything()
	if debug then echo("Looting all") end
	for i = 1, GetNumLootItems() do	LootSlot(i) end
	loot_all = nil --unset loot_all

	return 1
end



-- Event Handler function
function KarniCrap_OnEvent(event)
	
	if event == "VARIABLES_LOADED" then
		KarniCrap_VARIABLES_LOADED();
	
	elseif event == "PLAYER_LEVEL_UP" then
		playerlevel = tonumber(arg1);
	
	elseif event == "PARTY_MEMBERS_CHANGED" then
		loot_threshold = GetLootThreshold();
		numberingroup = GetNumPartyMembers() + GetNumRaidMembers();
		if GetLootMethod() == "freeforall" or numberingroup == 0 then 
			loot_threshold = 5 	
		end
		
	elseif event == "QUEST_FINISHED" then
		-- if debug then echo("QUEST_FINISHED triggered, starting timer") end
		KarniCrap_TimerFrame:Show()	
	
	-- spellcast detection needs to be in here so it will override any value thresholds
		-- that the user may have and autoloot items from inventory or when using tradeskills
	-- Prospecting and Mining settings are theoretically not needed since when using these skills it will
		-- lock an item in inventory and automatically go to 'loot_all' mode
	elseif event == "UNIT_SPELLCAST_SUCCEEDED" and arg1 == "player" then
		if arg2 == "Mining" then loot_all = true 
		elseif arg2 == "Skinning" then loot_all = true 
		elseif arg2 == "Herb Gathering" then loot_all = true 
		elseif arg2 == "Engineering" then loot_all = true 
		--elseif arg2 == "Disenchant" then loot_all = true 
		--elseif arg2 == "Prospecting" then loot_all = true 
		--elseif arg2 == "Milling" then loot_all = true 
		elseif KarniCrapConfig.Pickpocketing and arg2 == "Pick Pocket" then 
			KarniCrap_Scripts:RegisterEvent("COMBAT_LOG_EVENT_UNFILTERED")
			KarniCrap_Scripts:RegisterEvent("UI_ERROR_MESSAGE")
			pickpocketing = true
		end
		if debug then echo("UNIT_SPELLCAST_SUCCEEDED: "..arg2) end


	elseif event == "COMBAT_LOG_EVENT_UNFILTERED" then
		if arg2 == "SPELL_AURA_REMOVED" and arg8 == 1297 and arg10 == "Stealth" then
			-- pickpocket was resisted and player was kicked out of stealth
			KarniCrap_Scripts:UnregisterEvent("COMBAT_LOG_EVENT_UNFILTERED")
			KarniCrap_Scripts:UnregisterEvent("UI_ERROR_MESSAGE") 
			pickpocketing = nil
			if debug then echo("Pickpocket failed, unregister COMBAT_LOG and UI_ERROR") end
		end


	elseif event == "UI_ERROR_MESSAGE" then
		if arg1 == "Your target has already had its pockets picked" then
			if debug then echo("UI ERROR caught, cancelling loot all/pickpocketing. unregister COMBAT_LOG and UI_ERROR") end
			KarniCrap_Scripts:UnregisterEvent("UI_ERROR_MESSAGE")
			KarniCrap_Scripts:UnregisterEvent("COMBAT_LOG_EVENT_UNFILTERED")
			pickpocketing = nil
		end
	
	
	elseif event == "LOOT_CLOSED" then
		loot_all = nil
		
		
	elseif event == "LOOT_OPENED" then
		local looted = nil
		local item_locked = nil
		
		if pickpocketing then 
			if debug then echo("Pickpocket succeeded, unregister COMBAT_LOG and UI_ERROR") end
			KarniCrap_Scripts:UnregisterEvent("COMBAT_LOG_EVENT_UNFILTERED")
			KarniCrap_Scripts:UnregisterEvent("UI_ERROR_MESSAGE")
			pickpocketing = nil
			loot_all = true 
		end

		if arg1 == 0 then
			if not loot_all then 
				for bag = 0, 4 do			
					if GetContainerNumSlots(bag) > 0 then
						for slot = 0, GetContainerNumSlots(bag) do
							local texture, itemCount, locked, quality = GetContainerItemInfo(bag, slot);
							if locked then
								if debug then echo("Item is locked") end
								item_locked = true
								loot_all = true
								break
							end
						end
						if item_locked then break 
						else 
							--if debug then echo("No locked items in bag "..bag) end
						end
					end
				end
			end
			
			-- loot_all if it has been set
			if loot_all then
				looted = KarniCrap_LootEverything()	
			end
	
				
			-- if fishing
			if not looted and KarniCrapConfig.Fishing and IsFishingLoot() then
				if debug then echo("Fishing") end
				looted = KarniCrap_LootEverything();
			end
			
			-- get the source unit ID
			local unitID = KarniCrap_GetUnitID();

			-- if one of the gathering items is checked, check the mob type
			if not looted and ( KarniCrapConfig.Skinnable or KarniCrapConfig.Gatherable or KarniCrapConfig.Minable or KarniCrapConfig.Engineerable ) then
				-- Check skinnable/minable/gatherable mob list
				if unitID then
					if (KarniCrapConfig.Skinnable and mobsSkinnableList[unitID]) then
						if debug then echo("Mob is skinnable") end
						looted = KarniCrap_LootEverything();
					elseif (KarniCrapConfig.Minable and mobsMinableList[unitID]) then
						if debug then echo("Mob is minable") end
						looted = KarniCrap_LootEverything();
					elseif (KarniCrapConfig.Gatherable and mobsGatherableList[unitID]) then
						if debug then echo("Mob is gatherable") end
						looted = KarniCrap_LootEverything();
					elseif (KarniCrapConfig.Engineerable and mobsEngineerableList[unitID]) then
						if debug then echo("Mob is engineerable") end
						looted = KarniCrap_LootEverything();
					end
				end
			end

			-- close loot window if nothing left
			if GetNumLootItems() == 0 then CloseLoot() looted = true end
			
			-- if an attempt to loot everything hasn't been made, then do checks
			if not looted then
				for i = 1, GetNumLootItems() do
					-- always loot money
					if LootSlotIsCoin(i) then 
						LootSlot(i);
					
					-- if item loot
					else
						local lootLink = GetLootSlotLink(i);
						local check = CheckLoot(lootLink, unitID);
						-- item passed filters and will be looted
						if check == 1 then
							LootSlot(i)
						-- item did not pass filter	
						elseif check == nil then
							if KarniCrapConfig.Echo then
								if KarniCrapConfig.Details then
									echo("KarniCrap: Not looting "..lootLink.." because it's crap! ("..details..")");
								else
									echo("KarniCrap: Not looting "..lootLink.." because it's crap!");
								end
							end
						end
						-- otherwise item is over loot threshold and won't attempt to loot
					end
				end
				if GetNumLootItems() == 0 then CloseLoot() end
			end
		end
	end
end






function CheckLoot(lootLink, unitID)
	local _, _, itemID = string.find(lootLink, "item:(%d+):")
	local lootName, _, lootRarity, lootLevel, _, lootType, lootSubType, lootStackCount = GetItemInfo(itemID)
	local temp
	details = ""

	if debug then echo("name:"..lootName..", type:"..lootType..", subtype:"..lootSubType) end

	-- check against blacklist
	if ( KarniBlacklist[itemID] ) then details = "blacklist" return nil end
	
	-- check against whitelist & quest type items
	if ( KarniWhitelist[itemID] or lootType == "Quest") then return 1 end
	
	
	-- loot if enchanting items regardless of loot threshold
	-- if ( lootSubType == "Enchanting" ) then	return 1 end
	
	-- check for and loot quest items
	if ( lootRarity > 0 ) then
		for key, value in pairs(QuestItemList) do
			if (value == lootName) then	
				if debug then echo("Item is on quest item list") end
				return 1 
			end
		end
	end
	-- check against the loot threshold, skip if higher
	if ( lootRarity >= loot_threshold ) then return 0 end

	-- profession options: check if usable for cooking
	if ( KarniCrapConfig.Cooking and cookingList[itemID] ) then	return 1 end

	-- CLOTH -- 
	if ( itemID == "2589" and KarniCrapConfig.Cloth_Linen ) then return 1
	elseif ( itemID == "2592" and KarniCrapConfig.Cloth_Wool ) then return 1
	elseif ( itemID == "4306" and KarniCrapConfig.Cloth_Silk ) then return 1
	elseif ( itemID == "4338" and KarniCrapConfig.Cloth_Mageweave ) then return 1
	elseif ( itemID == "14047" and KarniCrapConfig.Cloth_Runecloth ) then return 1
	elseif ( itemID == "21877" and KarniCrapConfig.Cloth_Netherweave ) then return 1
	elseif ( itemID == "33470" and KarniCrapConfig.Cloth_Frostweave ) then return 1
	end

	-- SCROLLS -- need to localize subtype
	if lootSubType == "Scroll" then
		if KarniCrapConfig.Scroll_Agility and ScrollList_Agility[itemID] then 
			if KarniCrapConfig.ScrollMax then
				if CheckScroll(itemID, ScrollList_Agility) then return 1
				else details = "scroll filter" return nil end
			else return 1 end 
		elseif KarniCrapConfig.Scroll_Intellect and ScrollList_Intellect[itemID] then 
			if KarniCrapConfig.ScrollMax then
				if CheckScroll(itemID, ScrollList_Intellect) then return 1
				else details = "scroll filter" return nil end
			else return 1 end 
		elseif KarniCrapConfig.Scroll_Protection and ScrollList_Protection[itemID] then
			if KarniCrapConfig.ScrollMax then
				if CheckScroll(itemID, ScrollList_Protection) then return 1
				else details = "scroll filter" return nil end
			else return 1 end 
		elseif KarniCrapConfig.Scroll_Spirit and ScrollList_Spirit[itemID] then 
			if KarniCrapConfig.ScrollMax then
				if CheckScroll(itemID, ScrollList_Spirit) then return 1
				else details = "scroll filter" return nil end
			else return 1 end 
		elseif KarniCrapConfig.Scroll_Stamina and ScrollList_Stamina[itemID] then 
			if KarniCrapConfig.ScrollMax then
				if CheckScroll(itemID, ScrollList_Stamina) then return 1
				else details = "scroll filter" return nil end
			else return 1 end 
		elseif KarniCrapConfig.Scroll_Strength and ScrollList_Strength[itemID] then 
			if KarniCrapConfig.ScrollMax then
				if CheckScroll(itemID, ScrollList_Strength) then return 1
				else details = "scroll filter" return nil end
			else return 1 end 
		end
	end
	
	-- FOOD --
	if KarniCrapConfig.AlwaysFood or KarniCrapConfig.NeverFood then 
		if foodList[itemID] then
			if KarniCrapConfig.NeverFood then 
				if debug then echo("never loot food") end
				details = "food filter" return nil 
			elseif KarniCrapConfig.AlwaysFood then
				if KarniCrapConfig.FoodMax then
					if foodList[itemID] > playerlevel - 10 then 
						if debug then echo("max food") end
						return 1
					else 
						if debug then echo("not max food") end
						details = "food filter" return nil	
					end
				else
					if debug then echo("always loot food") end
					return 1
				end
			end
		end
	end

	-- WATER --
	if KarniCrapConfig.AlwaysWater or KarniCrapConfig.NeverWater then 
		if waterList[itemID] then
			if KarniCrapConfig.NeverWater then 
				if debug then echo("never loot water") end
				details = "water filter" return nil 
			elseif KarniCrapConfig.AlwaysWater then
				if KarniCrapConfig.WaterMax then
					if waterList[itemID] > playerlevel - 10 then 
						if debug then echo("max water") end
						return 1
					else 
						if debug then echo("not max water") end
						details = "water filter" return nil
					end
				else
					if debug then echo("always loot water") end
					return 1
				end
			end
		end
	end

	-- HEALTH POTIONS --
	if KarniCrapConfig.AlwaysHealth or KarniCrapConfig.NeverHealth then 
		if HealingPotionList[itemID] then
			if KarniCrapConfig.NeverHealth then 
				if debug then echo("never loot health") end
			 	details = "potion filter" return nil 
			elseif KarniCrapConfig.AlwaysHealth then
				if KarniCrapConfig.HealthMax then
					if HealingPotionList[itemID] == 55 then 
						if debug then echo("max health") end
						return 1 
					else 
						if debug then echo("not max health") end
						details = "potion filter" return nil	
					end
				else
					if debug then echo("always loot health") end
					return 1
				end
			end
		end
	end

	-- MANA POTIONS --
	if KarniCrapConfig.AlwaysMana or KarniCrapConfig.NeverMana then 
		if ManaPotionList[itemID] then
			if KarniCrapConfig.NeverMana then 
				if debug then echo("never loot mana") end
				details = "potion filter" return nil 
			elseif KarniCrapConfig.AlwaysMana then
				if KarniCrapConfig.ManaMax then
					if ManaPotionList[itemID] == 55 then echo("max mana") 
						if debug then echo("max mana") end
						return 1
					else 
						if debug then echo("not max mana") end
						details = "potion filter" return nil
					end
				else
					if debug then echo("always loot mana") end
					return 1
				end
			end
		end
	end

	-- check prices
	if item_database then
		local itemValue = GetSellValue(itemID);

		-- if itemValue not found, loot it so it can be brought to a vendor and checked
		-- if itemValue is zero then item cannot be sold to a vendor and probably should be looted
		if itemValue == nil or itemValue == 0 then return 1 end
		
		if KarniCrapConfig.UseStackValue == true then itemValue = itemValue * lootStackCount end
	
		-- if a poor (vendortrash) item
		if (lootRarity == 0 and KarniCrapConfig.Poor and amount_poor >= 0) then
			if debug then echo("poor price filter "..itemValue.." vs "..amount_poor) end
			if itemValue then
				if itemValue > amount_poor then
					return 1
				else
					details = "price filter" return nil
				end
			end
	
		-- if a common non-quest item
		elseif lootRarity == 1 and KarniCrapConfig.Common and amount_common >= 0 and lootType ~= "Quest" then
			if debug then echo("checking common") end
			if itemValue then
				if debug then echo("Common price filter, item value "..itemValue.." vs threshold "..amount_common) end
				if itemValue > amount_common then
					return 1
				else
					details = "price filter" return nil
				end
			end
		end
	end
	
	if debug then echo("No filters apply") end
	-- passed or didn't qualify for filters
	return 1;
	
end















-- Dims echo the input boxes if poor isn't checked
function KarniCrap_CheckButtonPoor()
	if (KarniCrap_Tab1_CBPoor:GetChecked()) then
		KarniCrapConfig.Poor = true;
		KarniCrap_Tab1_Option1_GoldInputBox1:Show();
		KarniCrap_Tab1_Option1_GoldTexture1:SetAlpha(1);
		KarniCrap_Tab1_Option1_SilverInputBox1:Show();
		KarniCrap_Tab1_Option1_SilverTexture1:SetAlpha(1);
		KarniCrap_Tab1_Option1_CopperInputBox1:Show();
		KarniCrap_Tab1_Option1_CopperTexture1:SetAlpha(1);
	else
		KarniCrapConfig.Poor = false;
		KarniCrap_Tab1_Option1_GoldInputBox1:Hide();
		KarniCrap_Tab1_Option1_GoldTexture1:SetAlpha(0.3);
		KarniCrap_Tab1_Option1_SilverInputBox1:Hide();
		KarniCrap_Tab1_Option1_SilverTexture1:SetAlpha(0.3);
		KarniCrap_Tab1_Option1_CopperInputBox1:Hide();
		KarniCrap_Tab1_Option1_CopperTexture1:SetAlpha(0.3);
	end
end



-- Dims echo the input boxes if common isn't checked
function KarniCrap_CheckButtonCommon()
	if (KarniCrap_Tab1_CBCommon:GetChecked()) then
		KarniCrapConfig.Common = true;
		KarniCrap_Tab1_Option2_GoldInputBox2:Show();
		KarniCrap_Tab1_Option2_GoldTexture2:SetAlpha(1);
		KarniCrap_Tab1_Option2_SilverInputBox2:Show();
		KarniCrap_Tab1_Option2_SilverTexture2:SetAlpha(1);
		KarniCrap_Tab1_Option2_CopperInputBox2:Show();
		KarniCrap_Tab1_Option2_CopperTexture2:SetAlpha(1);
	else
		KarniCrapConfig.Common = false;
		KarniCrap_Tab1_Option2_GoldInputBox2:Hide();
		KarniCrap_Tab1_Option2_GoldTexture2:SetAlpha(0.3);
		KarniCrap_Tab1_Option2_SilverInputBox2:Hide();
		KarniCrap_Tab1_Option2_SilverTexture2:SetAlpha(0.3);
		KarniCrap_Tab1_Option2_CopperInputBox2:Hide();
		KarniCrap_Tab1_Option2_CopperTexture2:SetAlpha(0.3);
	end


end



function CheckScroll(itemID, scroll_list)
	local scroll_level, next_scroll_level
	local sorted_list = {}
  	
  	scroll_level = scroll_list[itemID]
  	
  	for id, value in pairs(scroll_list) do table.insert(sorted_list, value) end 
	table.insert(sorted_list, 100) -- add a high value to the end of the array so it won't crash when doing index+1
  	table.sort(sorted_list)
  	
  	-- get the level of the next highest scroll of that type
  	for i = 1, 6 do
  		if scroll_level == sorted_list[i] then 
  			next_scroll_level = sorted_list[i + 1]
  			if debug then echo("next scroll level is "..next_scroll_level) end
  			break
  		end
  	end
  	if debug then echo("scroll_level "..scroll_level.." >= player level "..playerlevel.." or "..playerlevel.." > "..scroll_level.." and "..playerlevel.." <= "..next_scroll_level) end
	if scroll_level >= playerlevel or ( playerlevel > scroll_level and playerlevel <= next_scroll_level ) then
		return true
	else
		return nil
	end
end


function ScrollLevels(list)
	local level_string = ""
	local level_list = {
		[1] = "I",
		[2] = "II",
		[3] = "III",
		[4] = "IV",
		[5] = "V",
		[6] = "VI"
	}
	local sorted_list = {}
  	for id, value in pairs(list) do table.insert(sorted_list, value) end 
	table.insert(sorted_list, 100) -- add a high value to the end of the array so it won't crash when doing index+1
  	table.sort(sorted_list)
			
	local lastindex = 1
	local i = 1
	
	for index = 1, 6 do
		-- check or change  playerlevel <= sorted_list[index] to < for wotlk ?
		if debug then echo(index.."--"..sorted_list[index]..">="..playerlevel.." or "..playerlevel..">"..sorted_list[index].." and "..playerlevel.."<="..sorted_list[index+1]..")") end

		-- if scroll level >= player level OR if player level > scroll level AND player level <= next scroll level
		if sorted_list[index] >= playerlevel or ( playerlevel > sorted_list[index] and playerlevel <= sorted_list[index + 1] ) then
			if level_string == "" then
				level_string = level_list[index]
			else
				level_string = level_string..","..level_list[index]
			end
		end
		lastindex = index
	end
	return level_string
end



function KarniCrap_CBMaxScrolls() 
	if (KarniCrap_Scrolls_CBMaxScrolls:GetChecked()) then
		-- scrollmax should set the scrolls to be character level usable and above
		-- if character is lvl 60, scrolls included should be IV-VI
	
		KarniCrapConfig.ScrollMax = true
		
		KarniCrap_Scrolls_CBScrollAgility_Text2:SetText("[Agility "..ScrollLevels(ScrollList_Agility).."]")
		KarniCrap_Scrolls_CBScrollIntellect_Text2:SetText("[Intellect "..ScrollLevels(ScrollList_Intellect).."]")
		KarniCrap_Scrolls_CBScrollProtection_Text2:SetText("[Protection "..ScrollLevels(ScrollList_Protection).."]")
		KarniCrap_Scrolls_CBScrollSpirit_Text2:SetText("[Spirit "..ScrollLevels(ScrollList_Spirit).."]")
		KarniCrap_Scrolls_CBScrollStamina_Text2:SetText("[Stamina "..ScrollLevels(ScrollList_Stamina).."]")
		KarniCrap_Scrolls_CBScrollStrength_Text2:SetText("[Strength "..ScrollLevels(ScrollList_Strength).."]")
	else
		KarniCrapConfig.ScrollMax = false
		KarniCrap_Scrolls_CBScrollAgility_Text2:SetText("[Agility I - VI]")
		KarniCrap_Scrolls_CBScrollIntellect_Text2:SetText("[Intellect I - VI]")
		KarniCrap_Scrolls_CBScrollProtection_Text2:SetText("[Protection I - VI]")
		KarniCrap_Scrolls_CBScrollSpirit_Text2:SetText("[Spirit I - VI]")
		KarniCrap_Scrolls_CBScrollStamina_Text2:SetText("[Stamina I - VI]")
		KarniCrap_Scrolls_CBScrollStrength_Text2:SetText("[Strength I - VI]")
	end
end










function KarniCrap_RBHealth()
	local r, g, b, a = KarniCrap_Potions_RBHealth1_Text2:GetTextColor();
	if (KarniCrap_Potions_RBHealth1:GetChecked()) then
		KarniCrapConfig.NeverHealth = true;
		KarniCrapConfig.AlwaysHealth = false;
		KarniCrap_Potions_RBHealth2:SetChecked(nil);
		KarniCrap_Potions_CBHealthMax:SetAlpha(0.3); 
		KarniCrap_Potions_CBHealthMax:Disable(); 
		KarniCrap_Potions_RBHealth1_Text1:SetTextColor(1,1,1);
		KarniCrap_Potions_RBHealth2_Text1:SetTextColor(r,g,b,a);
	elseif (KarniCrap_Potions_RBHealth2:GetChecked()) then
		KarniCrapConfig.NeverHealth = false;
		KarniCrapConfig.AlwaysHealth = true;
		KarniCrap_Potions_RBHealth1:SetChecked(nil);
		KarniCrap_Potions_CBHealthMax:SetAlpha(1); 
		KarniCrap_Potions_CBHealthMax:Enable(); 
		KarniCrap_Potions_RBHealth1_Text1:SetTextColor(r,g,b,a);
		KarniCrap_Potions_RBHealth2_Text1:SetTextColor(1,1,1);	
	else
		KarniCrapConfig.NeverHealth = false;
		KarniCrapConfig.AlwaysHealth = false;
		KarniCrap_Potions_CBHealthMax:SetAlpha(0.3); 
		KarniCrap_Potions_CBHealthMax:Disable(); 
		KarniCrap_Potions_RBHealth1_Text1:SetTextColor(r,g,b,a);
		KarniCrap_Potions_RBHealth2_Text1:SetTextColor(r,g,b,a);
	end
end


function KarniCrap_RBMana()
	local r, g, b, a = KarniCrap_Potions_RBMana1_Text2:GetTextColor();
	if (KarniCrap_Potions_RBMana1:GetChecked()) then
		KarniCrapConfig.NeverMana = true;
		KarniCrapConfig.AlwaysMana = false;
		KarniCrap_Potions_CBManaMax:SetAlpha(0.3); 
		KarniCrap_Potions_CBManaMax:Disable(); 
		KarniCrap_Potions_RBMana1_Text1:SetTextColor(1,1,1);
		KarniCrap_Potions_RBMana2_Text1:SetTextColor(r,g,b,a);
	elseif (KarniCrap_Potions_RBMana2:GetChecked()) then
		KarniCrapConfig.NeverMana = false;
		KarniCrapConfig.AlwaysMana = true;
		KarniCrap_Potions_CBManaMax:SetAlpha(1); 
		KarniCrap_Potions_CBManaMax:Enable(); 
		KarniCrap_Potions_RBMana1_Text1:SetTextColor(r,g,b,a);
		KarniCrap_Potions_RBMana2_Text1:SetTextColor(1,1,1);
	else
		KarniCrapConfig.NeverMana = false;
		KarniCrapConfig.AlwaysMana = false;
		KarniCrap_Potions_CBManaMax:SetAlpha(0.3); 
		KarniCrap_Potions_CBManaMax:Disable(); 
		KarniCrap_Potions_RBMana1_Text1:SetTextColor(r,g,b,a);
		KarniCrap_Potions_RBMana2_Text1:SetTextColor(r,g,b,a);
	end
end



-- Dims echo the food subselections if the checkbox isn't checked
function KarniCrap_RBFood()
	local r, g, b, a = KarniCrap_Consumables_RBFood1_Text2:GetTextColor();
	
	if KarniCrap_Consumables_RBFood1:GetChecked() then
		KarniCrapConfig.AlwaysFood = false;
		KarniCrapConfig.NeverFood = true;
		KarniCrap_Consumables_CBFoodMax:SetAlpha(0.3); 
		KarniCrap_Consumables_CBFoodMax:Disable();
		KarniCrap_Consumables_RBFood1_Text1:SetTextColor(1,1,1);
		KarniCrap_Consumables_RBFood2_Text1:SetTextColor(r,g,b,a);
	elseif KarniCrap_Consumables_RBFood2:GetChecked()  then
		KarniCrapConfig.AlwaysFood = true;
		KarniCrapConfig.NeverFood = false;
		KarniCrap_Consumables_CBFoodMax:SetAlpha(1); 
		KarniCrap_Consumables_CBFoodMax:Enable();
		KarniCrap_Consumables_RBFood1_Text1:SetTextColor(r,g,b,a);
		KarniCrap_Consumables_RBFood2_Text1:SetTextColor(1,1,1);
	else
		KarniCrapConfig.AlwaysFood = false;
		KarniCrapConfig.NeverFood = false;
		KarniCrap_Consumables_CBFoodMax:SetAlpha(0.3); 
		KarniCrap_Consumables_CBFoodMax:Disable();
		KarniCrap_Consumables_RBFood1_Text1:SetTextColor(r,g,b,a);
		KarniCrap_Consumables_RBFood2_Text1:SetTextColor(r,g,b,a);

	end
end



-- Dims echo the water subselections if the checkbox isn't checked
function KarniCrap_RBWater()
	local r, g, b, a = KarniCrap_Consumables_RBWater1_Text2:GetTextColor();

	if KarniCrap_Consumables_RBWater1:GetChecked() then
		KarniCrapConfig.NeverWater = true;
		KarniCrapConfig.AlwaysWater = false;
		KarniCrap_Consumables_CBWaterMax:SetAlpha(0.3); 
		KarniCrap_Consumables_CBWaterMax:Disable();
		KarniCrap_Consumables_RBWater1_Text1:SetTextColor(1,1,1);
		KarniCrap_Consumables_RBWater2_Text1:SetTextColor(r,g,b,a);
	elseif KarniCrap_Consumables_RBWater2:GetChecked() then
		KarniCrapConfig.NeverWater = false;
		KarniCrapConfig.AlwaysWater = true;
		KarniCrap_Consumables_CBWaterMax:SetAlpha(1); 
		KarniCrap_Consumables_CBWaterMax:Enable();
		KarniCrap_Consumables_RBWater1_Text1:SetTextColor(r,g,b,a);
		KarniCrap_Consumables_RBWater2_Text1:SetTextColor(1,1,1);
	else
		KarniCrapConfig.NeverWater = false;
		KarniCrapConfig.AlwaysWater = false;
		KarniCrap_Consumables_CBWaterMax:SetAlpha(0.3);	
		KarniCrap_Consumables_CBWaterMax:Disable();
		KarniCrap_Consumables_RBWater1_Text1:SetTextColor(r,g,b,a);
		KarniCrap_Consumables_RBWater2_Text1:SetTextColor(r,g,b,a);
	end
end


function KarniCrap_EchoSettings()
	if KarniCrap_Tab1_CBEcho:GetChecked() then
		KarniCrapConfig.Echo = true
		KarniCrap_Tab1_CBDetails:Enable()
		KarniCrap_Tab1_CBDetails:SetAlpha(1);
	else
		KarniCrapConfig.Echo = false
		KarniCrap_Tab1_CBDetails:Disable()
		KarniCrap_Tab1_CBDetails:SetAlpha(0.3);
	end
end


function KarniCrap_CalcPoorThreshold() 
	amount_poor = 
		KarniCrapConfig.PoorThreshold_Gold * 10000 + 
		KarniCrapConfig.PoorThreshold_Silver * 100 + 
		KarniCrapConfig.PoorThreshold_Copper;
end

function KarniCrap_CalcCommonThreshold()
	amount_common = 
		KarniCrapConfig.CommonThreshold_Gold * 10000 + 
		KarniCrapConfig.CommonThreshold_Silver * 100 + 
		KarniCrapConfig.CommonThreshold_Copper;
end











-- BLACKLIST FUNCTIONS --
-- BLACKLIST FUNCTIONS --
-- BLACKLIST FUNCTIONS --

function KarniCrapScrollBar_Update()

	local hex, line; -- 1 through 5 of our window to scroll
	local lineplusoffset; -- an index into our data calculated from the scroll offset

	
	FauxScrollFrame_Update(KarniCrapScrollBar,blacklist_numItems,blacklist_maxVisible,16);
	
	for line = 1, blacklist_maxVisible do
		-- create the button frames for the list
		lineplusoffset = line + FauxScrollFrame_GetOffset(KarniCrapScrollBar);
		
		if lineplusoffset < blacklist_numItems + 1 then
			if (blacklist_items[lineplusoffset].quality == "red") then
				hex = "|cFFFF0000"
			else
		  		_, _, _, hex = GetItemQualityColor(blacklist_items[lineplusoffset].quality);
		  	end
		  	_G["KarniCrapEntry"..line]:SetTextFontObject("GameFontNormalSmall"); -- Delete for WotLK
			_G["KarniCrapEntry"..line]:SetText(hex..blacklist_items[lineplusoffset].name);
			_G["KarniCrapEntry"..line]:SetID(blacklist_items[lineplusoffset].id);
			
			KarniCrap_SelectBlacklistItem("KarniCrapEntry"..line, blacklist_items[lineplusoffset].id)
			_G["KarniCrapEntry"..line]:Show();
		else
			_G["KarniCrapEntry"..line]:Hide();
		end

	end
end

function KarniCrap_InitializeBlacklist()
	blacklist_selected = nil;
	KarniCrap_Tab2_RemoveItemButton:Disable();

	local index = 0;

	local temp_table = {}
  	for id, name in pairs(KarniBlacklist) do table.insert(temp_table, name.."["..id.."]") end 
  	table.sort(temp_table)
  	
  	-- temp_table has the names of the items in alphabetical order, get the ID format is name[id]
    for k,v in ipairs(temp_table) do 
 	
    	local id = gsub(strmatch(v,"%[.+%]"),"[%[|%]]","") 
       	local itemInfo = {};
    	local itemName, itemLink, itemQuality = GetItemInfo(id); 
		
		if itemName then
   		    index = index + 1;
	    	itemInfo["id"] = id;
			itemInfo["name"] = "["..itemName.."]";
			itemInfo["quality"] = itemQuality;
			blacklist_items[index] = itemInfo;
		else
			index = index + 1;
			itemInfo["id"] = id;
			itemInfo["name"] = "["..KarniBlacklist[id].."]";
			itemInfo["quality"] = "red";
			blacklist_items[index] = itemInfo;
			
			if debug then echo("blacklist item "..KarniBlacklist[id].." not in cache") end
		end
	end
	blacklist_numItems = index;
	KarniCrapScrollBar_Update()
end

function KarniCrap_AddLootToBlacklist(itemLink)
	local itemName = GetItemInfo(itemLink) 
	local _, _, itemID = string.find(itemLink, "item:(%d+):")
	if (itemName and itemID) then
		if (KarniWhitelist[itemID]) then KarniCrap_RemoveFromWhitelist(itemID) end
	
		KarniBlacklist[itemID] = itemName;
		echo("KarniCrap: Added " .. itemLink .. " to the Never Loot list.")
	else
		echo("KarniCrap: /notcrap [itemlink] to add an item to the Never Loot list")	
	end
	KarniCrap_InitializeBlacklist()
end

function KarniCrap_RemoveFromBlacklist(id)
	local itemName, itemLink, itemRarity = GetItemInfo(id); 

	if itemLink then
		echo("KarniCrap: Removed " .. itemLink .. " from the Always Loot list.")
	else
		echo("KarniCrap: Removed ["..KarniBlacklist[tostring(id)].."] from the Always Loot list.")
	end
	KarniBlacklist[tostring(id)] = nil;
	KarniCrap_Tab2_RemoveItemButton:Disable();
	KarniCrap_InitializeBlacklist()
end

function KarniCrap_SelectBlacklistItem(id)
	local line;

	for line = 1, blacklist_maxVisible do
		if (id) then
			-- highlight selected item
			if (_G["KarniCrapEntry"..line]:GetID() == id ) then
				_G["KarniCrapEntry"..line.."_Background"]:SetTexture(.3,.3,.5,.6);
			else 
				_G["KarniCrapEntry"..line.."_Background"]:SetTexture(0,0,0,0);
			end
		end
	end
end









-- WHITELIST FUNCTIONS --
-- WHITELIST FUNCTIONS --
-- WHITELIST FUNCTIONS --

function KarniNotCrapScrollBar_Update()
	local hex, line, lineplusoffset; -- an index into our data calculated from the scroll offset
	
	FauxScrollFrame_Update(KarniNotCrapScrollBar,whitelist_numItems,whitelist_maxVisible,16);
	
	for line = 1, whitelist_maxVisible do
		-- create the button frames for the list
		lineplusoffset = line + FauxScrollFrame_GetOffset(KarniNotCrapScrollBar);
		
		if lineplusoffset < whitelist_numItems + 1 then
			if (whitelist_items[lineplusoffset].quality == "red") then
				hex = "|cFFFF0000"
			else
		  		_, _, _, hex = GetItemQualityColor(whitelist_items[lineplusoffset].quality);
		  	end
		  	_G["KarniNotCrapEntry"..line]:SetTextFontObject("GameFontNormalSmall"); -- Delete for WotLK
			_G["KarniNotCrapEntry"..line]:SetText(hex..whitelist_items[lineplusoffset].name);
			_G["KarniNotCrapEntry"..line]:SetID(whitelist_items[lineplusoffset].id);
			
			KarniCrap_SelectWhitelistItem("KarniNotCrapEntry"..line, whitelist_items[lineplusoffset].id)
			_G["KarniNotCrapEntry"..line]:Show();
		else
			_G["KarniNotCrapEntry"..line]:Hide();
		end

	end
end

function KarniCrap_InitializeWhitelist()
	whitelist_selected = nil;
	KarniCrap_Tab2_NotCrapRemoveItemButton:Disable();
	local index = 0;
	local temp_table = {}
	
  	for id, name in pairs(KarniWhitelist) do table.insert(temp_table, name.."["..id.."]") end 
  	table.sort(temp_table)
  	
  	-- temp_table has the names of the items in alphabetical order, get the ID format as name[id]
    for k,v in ipairs(temp_table) do 
    	local id = gsub(strmatch(v,"%[.+%]"),"[%[|%]]","") 
       	local itemInfo = {};
    	local itemName, itemLink, itemQuality = GetItemInfo(id); 
   		if (itemName) then
   		    index = index + 1;
	    	itemInfo["id"] = id;
			itemInfo["name"] = "["..itemName.."]";
			itemInfo["quality"] = itemQuality;
			whitelist_items[index] = itemInfo;
		else
			index = index + 1;
			itemInfo["id"] = id;
			itemInfo["name"] = "["..KarniWhitelist[id].."]";
			itemInfo["quality"] = "red";
			whitelist_items[index] = itemInfo;
			
			if debug then echo("whitelist item "..KarniWhitelist[id].." not in cache") end
		end
	end
	whitelist_numItems = index;
	KarniNotCrapScrollBar_Update()
end

function KarniCrap_AddLootToWhitelist(itemLink)
	local itemName = GetItemInfo(itemLink) 
	local _, _, itemID = string.find(itemLink, "item:(%d+):")
	if (itemName and itemID) then
		if (KarniBlacklist[itemID]) then KarniCrap_RemoveFromBlacklist(itemID) end
		KarniWhitelist[itemID] = itemName;
		echo("KarniCrap: Added " .. itemLink .. " to the Always Loot list.")
	else
		echo("KarniCrap: /notcrap [itemlink] to add an item to the Always Loot list")
	end
	KarniCrap_InitializeWhitelist()
end

-- remove an item from the Whitelist
function KarniCrap_RemoveFromWhitelist(id)
	local itemName, itemLink, itemRarity = GetItemInfo(id); 
	
	if itemLink then
		echo("KarniCrap: Removed " .. itemLink .. " from the Always Loot list.")
	else
		echo("KarniCrap: Removed ["..KarniWhitelist[tostring(id)].."] from the Always Loot list.")
	end
	KarniWhitelist[tostring(id)] = nil;
	KarniCrap_Tab2_NotCrapRemoveItemButton:Disable();
	KarniCrap_InitializeWhitelist()
end

function KarniCrap_SelectWhitelistItem(id)
	local line;

	for line = 1, whitelist_maxVisible do
		if (id) then
			-- highlight selected item
			if (_G["KarniNotCrapEntry"..line]:GetID() == id ) then
				_G["KarniNotCrapEntry"..line.."_Background"]:SetTexture(.3,.3,.5,.6);
			else 
				_G["KarniNotCrapEntry"..line.."_Background"]:SetTexture(0,0,0,0);
			end
		end
	end
end










 function KarniCrap_VARIABLES_LOADED()

  	-- poor item settings
	local default_Poor = true; 					-- amount of money that loot must be worth?
	local default_PoorThreshold_Gold = 0;		-- gold threshold for poor items
	local default_PoorThreshold_Silver = 50;	-- silver threshold for poor items
	local default_PoorThreshold_Copper = 0;		-- copper threshold for poor items
	-- common item settings
	local default_Common = true; 				-- filter white items as well?
	local default_CommonThreshold_Gold = 0;		-- gold threshold for poor items
	local default_CommonThreshold_Silver = 10;	-- silver threshold for poor items
	local default_CommonThreshold_Copper = 0;	-- copper threshold for poor items
	-- general settings
	local default_UseStackValue = true;			-- use full stack value for filtering
	local default_Echo = true; 					-- echo to chatbox when loot is filtered
	local default_Details = false;				-- 
	-- cloth settings
	local default_Linen = false;
	local default_Cloth_Wool = false;
	local default_Cloth_Silk = false;
	local default_Cloth_Mageweave = false;
	local default_Cloth_Runecloth = true;
	local default_Cloth_Netherweave = true;
	local default_Cloth_Frostweave = true;
	-- scroll settings
	local default_ScrollMax = false;
	local default_Scroll_Agility = false;
	local default_Scroll_Intellect = false;
	local default_Scroll_Protection = false;
	local default_Scroll_Spirit = false;
	local default_Scroll_Stamina = false;
	local default_Scroll_Strength = false;
	-- food settings
	local default_NeverFood = false;
	local default_AlwaysFood = false; 			-- don't loot food
	local default_FoodMax = false;				-- unless food is current max level or higher
	-- water settings
	local default_NeverWater = false;
	local default_AlwaysWater = false; 			-- don't loot water
	local default_WaterMax = false;				-- unless water is current max level or higher
	-- health potion settings
	local default_NeverHealth = false;
	local default_AlwaysHealth = false; 			-- don't loot food
	local default_HealthMax = false;				-- unless food is current max level or higher
	-- mana potion settings
	local default_NeverMana = false;
	local default_AlwaysMana = false; 			-- don't loot water
	local default_ManaMax = false;				-- unless water is current max level or higher	
	-- tradeskill settings
	local default_Skinnable = false;			-- override filters when looting skinnable corpses
	local default_Gatherable = false;			-- override filters when looting gatherable corpses
	local default_Minable = false;				-- override filters when looting minable corpses
	local default_Engineerable = false;				-- override filters when looting minable corpses

	local default_Cooking = false;				-- loot all cooking materials
	local default_Fishing = true;				-- loot all items when fishing
	local default_Gathering = true;				-- items looted when gathering
	local default_Mining = true;				-- items looted when mining
	local default_Skinning = true;				-- items looted when skinning
	local default_Prospecting = true;			-- items looted when prospecting
	local default_Milling = true;				-- items looted when milling items
  	local default_Pickpocketing = false;		-- items looted when pickpocketing

  
  
	-- load each option, set default if not there
	if not KarniCrapConfig then KarniCrapConfig = {} end;
	if not KarniBlacklist then KarniBlacklist = {} end;
	if not KarniWhitelist then KarniWhitelist = default_Whitelist end;
	if not KarniQuestlist then KarniQuestlist = {} end;
	
	-- get the current level of the player for the food/water options
	if not playerlevel then playerlevel = tonumber(UnitLevel("player")) end;

	-- loading the external files
	if not foodList then foodList = {}  echo("Error loading lib_Food.lua") end
	if not waterList then waterList = {}  echo("Error loading lib_Water.lua") end
	if not clothList then clothList = {} echo("Error loading lib_Cloth.lua")  end
	if not cookingList then cookingList = {} echo("Error loading lib_Cooking.lua") end
	if not mobsEngineerableList then mobsEngineerableList = {} echo("Error loading lib_mobsEngineerable.lua") end
	if not mobsMinableList then mobsMinableList = {} echo("Error loading lib_MobsMinable.lua") end
	if not mobsGatherableList then mobsGatherableList = {} echo("Error loading lib_MobsGatherable.lua") end
	if not mobsSkinnableList then mobsSkinnableList = {} echo("Error loading lib_MobsSkinnable.lua") end
	if not HealingPotionList then HealingPotionList = {} echo("Error loading lib_Potions.lua") end
	if not ManaPotionList then ManaPotionList = {} echo("Error loading lib_Potions.lua") end

	if not ScrollList_Agility then ScrollList_Agility = {} echo("Error loading lib_Scrolls.lua") end
	if not ScrollList_Intellect then ScrollList_Intellect = {} echo("Error loading lib_Scrolls.lua") end
	if not ScrollList_Protection then ScrollList_Protection = {} echo("Error loading lib_Scrolls.lua") end
	if not ScrollList_Spirit then ScrollList_Spirit = {} echo("Error loading lib_Scrolls.lua") end
	if not ScrollList_Stamina then ScrollList_Stamina = {} echo("Error loading lib_Scrolls.lua") end
	if not ScrollList_Strength then ScrollList_Strength = {} echo("Error loading lib_Scrolls.lua") end

	if( KarniCrapConfig.PoorThreshold_Gold == nil) then KarniCrapConfig.PoorThreshold_Gold = default_PoorThreshold_Gold end;
	if( KarniCrapConfig.PoorThreshold_Silver == nil) then KarniCrapConfig.PoorThreshold_Silver = default_PoorThreshold_Silver end
	if( KarniCrapConfig.PoorThreshold_Copper == nil) then KarniCrapConfig.PoorThreshold_Copper = default_PoorThreshold_Copper end

	if( KarniCrapConfig.CommonThreshold_Gold == nil ) then KarniCrapConfig.CommonThreshold_Gold = default_CommonThreshold_Gold end
	if( KarniCrapConfig.CommonThreshold_Silver == nil ) then KarniCrapConfig.CommonThreshold_Silver = default_CommonThreshold_Silver end
	if( KarniCrapConfig.CommonThreshold_Copper == nil ) then KarniCrapConfig.CommonThreshold_Copper = default_CommonThreshold_Copper end
		
	-- if function exists, there is an item database
	if GetSellValue then
		item_database = true
		if KarniCrapConfig.Poor == nil then KarniCrapConfig.Poor = default_Poor end
		if KarniCrapConfig.Common == nil then KarniCrapConfig.Common = default_Common end
		if KarniCrapConfig.UseStackValue == nil then KarniCrapConfig.UseStackValue = default_UseStackValue end
	else
		KarniCrapConfig.Poor = false
		KarniCrapConfig.Common = false
		KarniCrapConfig.UseStackValue = false
	end
	
	if( KarniCrapConfig.Echo == nil ) then KarniCrapConfig.Echo = default_Echo end
	if( KarniCrapConfig.Details == nil ) then KarniCrapConfig.Details = default_Details end
	
	-- tradeskill settings
	if KarniCrapConfig.Skinnable == nil then KarniCrapConfig.Skinnable = default_Skinnable end
	if KarniCrapConfig.Gatherable == nil then KarniCrapConfig.Gatherable = default_Gatherable end
	if KarniCrapConfig.Minable == nil then KarniCrapConfig.Minable = default_Minable end
	if KarniCrapConfig.Engineerable == nil then KarniCrapConfig.Engineerable = default_Engineerable end
	if KarniCrapConfig.Cooking == nil then KarniCrapConfig.Cooking = default_Cooking end
	if KarniCrapConfig.Fishing == nil then KarniCrapConfig.Fishing = default_Fishing end
	if KarniCrapConfig.Pickpocketing == nil then KarniCrapConfig.Pickpocketing = default_Pickpocketing end
	
	-- cloth settings
	if( KarniCrapConfig.Cloth_Linen == nil ) then KarniCrapConfig.Cloth_Linen = default_Linen end
	if( KarniCrapConfig.Cloth_Wool == nil ) then KarniCrapConfig.Cloth_Wool = default_Cloth_Wool end
	if( KarniCrapConfig.Cloth_Silk == nil ) then KarniCrapConfig.Cloth_Silk = default_Cloth_Silk end
	if( KarniCrapConfig.Cloth_Mageweave == nil ) then KarniCrapConfig.Cloth_Mageweave = default_Cloth_Mageweave end
	if( KarniCrapConfig.Cloth_Runecloth == nil ) then KarniCrapConfig.Cloth_Runecloth = default_Cloth_Runecloth end
	if( KarniCrapConfig.Cloth_Netherweave == nil ) then KarniCrapConfig.Cloth_Netherweave = default_Cloth_Netherweave end
	if( KarniCrapConfig.Cloth_Frostweave == nil ) then KarniCrapConfig.Cloth_Frostweave = default_Cloth_Frostweave end


	-- scroll settings
	if KarniCrapConfig.ScrollMax == nil then KarniCrapConfig.ScrollMax = default_ScrollMax end
	if KarniCrapConfig.Scroll_Agility == nil then KarniCrapConfig.Scroll_Agility = default_Scroll_Agility end
	if KarniCrapConfig.Scroll_Intellect == nil then KarniCrapConfig.Scroll_Intellect = default_Scroll_Intellect end	
	if KarniCrapConfig.Scroll_Protection == nil then KarniCrapConfig.Scroll_Protection = default_Scroll_Protection end
	if KarniCrapConfig.Scroll_Spirit == nil then KarniCrapConfig.Scroll_Spirit = default_Scroll_Spirit end
	if KarniCrapConfig.Scroll_Stamina == nil then KarniCrapConfig.Scroll_Stamina = default_Scroll_Stamina end
	if KarniCrapConfig.Scroll_Strength == nil then KarniCrapConfig.Scroll_Strength = default_Scroll_Strength end	

	-- food settings
	if( KarniCrapConfig.NeverFood == nil) then KarniCrapConfig.NeverFood = default_NeverFood end
	if( KarniCrapConfig.AlwaysFood == nil) then KarniCrapConfig.AlwaysFood = default_AlwaysFood end
	if( KarniCrapConfig.FoodMax == nil) then KarniCrapConfig.FoodMax = default_FoodMax end
	-- water settings
	if( KarniCrapConfig.NeverWater == nil) then KarniCrapConfig.NeverWater = default_NeverWater end
	if( KarniCrapConfig.AlwaysWater == nil) then KarniCrapConfig.AlwaysWater = default_AlwaysWater end
	if( KarniCrapConfig.WaterMax == nil) then KarniCrapConfig.WaterMax = default_WaterMax end
	-- health potion settings
	if( KarniCrapConfig.NeverHealth == nil) then KarniCrapConfig.NeverHealth = default_NeverHealth end
	if( KarniCrapConfig.AlwaysHealth == nil) then KarniCrapConfig.AlwaysHealth = default_AlwaysHealth end
	if( KarniCrapConfig.HealthMax == nil) then KarniCrapConfig.HealthMax = default_HealthMax end
	-- mana potion settings
	if not KarniCrapConfig.NeverMana then KarniCrapConfig.NeverMana = default_NeverMana end
	if not KarniCrapConfig.AlwaysMana then KarniCrapConfig.AlwaysMana = default_AlwaysMana end
	if not KarniCrapConfig.ManaMax then KarniCrapConfig.ManaMax = default_ManaMax end
	
	-- record that we have been loaded
	KarniCrap_variablesLoaded = true
	
	KarniCrap_CalcPoorThreshold()
	KarniCrap_CalcCommonThreshold()

	-- get player's class
	_, playerclass = UnitClass("player")
	if debug then echo("Player class is "..playerclass) end

	-- configuration might have changed
	--KarniCrap_ListenForSpells()
	KarniCrap_InitializeUI()
 end




 function KarniCrap_InitializeUI()
 	-- setup menu items
	CategoryItem1:SetText("Cloth")
 	CategoryItem2:SetText("Corpses")
 	CategoryItem3:SetText("Food & Drink")
 	CategoryItem4:SetText("Pickpocketing")
 	CategoryItem5:SetText("Potions")
 	CategoryItem6:SetText("Scrolls")
 	CategoryItem7:SetText("Tradeskills") 	


 
	-- make sure that our profile has been loaded before allowing this function to be called
	if ( not KarniCrap_variablesLoaded ) then -- config not loaded
		echo("KarniCrap: Error loading saved variables")
	else
	 	KarniCrap_VersionText:SetText("Version "..KARNICRAP_VERSION);
	 	
		KarniCrap_Tab1_CBPoor:SetChecked(KarniCrapConfig.Poor);
		KarniCrap_Tab1_Option1_GoldInputBox1:SetNumber(KarniCrapConfig.PoorThreshold_Gold)
		KarniCrap_Tab1_Option1_SilverInputBox1:SetNumber(KarniCrapConfig.PoorThreshold_Silver)
		KarniCrap_Tab1_Option1_CopperInputBox1:SetNumber(KarniCrapConfig.PoorThreshold_Copper)
		KarniCrap_CheckButtonPoor();

		KarniCrap_Tab1_CBCommon:SetChecked(KarniCrapConfig.Common);
		KarniCrap_Tab1_Option2_GoldInputBox2:SetNumber(KarniCrapConfig.CommonThreshold_Gold)
		KarniCrap_Tab1_Option2_SilverInputBox2:SetNumber(KarniCrapConfig.CommonThreshold_Silver)
		KarniCrap_Tab1_Option2_CopperInputBox2:SetNumber(KarniCrapConfig.CommonThreshold_Copper)
		KarniCrap_CheckButtonCommon();
	
		KarniCrap_Tab1_CBUseStackValue:SetChecked(KarniCrapConfig.UseStackValue);
		KarniCrap_Tab1_CBEcho:SetChecked(KarniCrapConfig.Echo);
		KarniCrap_Tab1_CBDetails:SetChecked(KarniCrapConfig.Details);
		KarniCrap_EchoSettings()
		
		-- check for item database dependency and set item_database = true/false;
		if not item_database then
			KarniCrap_Tab1_CBPoor:Disable();
			KarniCrap_Tab1_Option1:SetAlpha(0.3);
			KarniCrap_Tab1_CBCommon:Disable();
			KarniCrap_Tab1_Option2:SetAlpha(0.3);
			KarniCrap_Tab1_CBUseStackValue:Disable();
			KarniCrap_Tab1_UseStackValue:SetAlpha(0.3);
		else
			KarniCrap_CheckButtonPoor();
			KarniCrap_CheckButtonCommon();
		end

		-- tradeskill settings
		KarniCrap_Corpses_CBSkinnable:SetChecked(KarniCrapConfig.Skinnable)
		KarniCrap_Corpses_CBGatherable:SetChecked(KarniCrapConfig.Gatherable)
		KarniCrap_Corpses_CBMinable:SetChecked(KarniCrapConfig.Minable)
		KarniCrap_Corpses_CBEngineerable:SetChecked(KarniCrapConfig.Engineerable)
		
		KarniCrap_Tradeskills_CBCooking:SetChecked(KarniCrapConfig.Cooking)
		KarniCrap_Tradeskills_CBFishing:SetChecked(KarniCrapConfig.Fishing)
	


		-- default pickpocket option to disabled unless player is a rogue
		KarniCrap_Pickpocketing_CBPickpocketing:SetChecked(KarniCrapConfig.Pickpocketing)
		KarniCrap_Pickpocketing_CBPickpocketing:Disable()
		KarniCrap_Pickpocketing_CBPickpocketing:SetAlpha(0.3)
		if playerclass == "ROGUE" then 
			KarniCrap_Pickpocketing_CBPickpocketing:Enable()
			KarniCrap_Pickpocketing_CBPickpocketing:SetAlpha(1)
		end
		
		
		-- cloth
		KarniCrap_Cloth_CBLinen:SetChecked(KarniCrapConfig.Cloth_Linen)
		KarniCrap_Cloth_CBWool:SetChecked(KarniCrapConfig.Cloth_Wool)
		KarniCrap_Cloth_CBSilk:SetChecked(KarniCrapConfig.Cloth_Silk)
		KarniCrap_Cloth_CBMageweave:SetChecked(KarniCrapConfig.Cloth_Mageweave)
		KarniCrap_Cloth_CBRunecloth:SetChecked(KarniCrapConfig.Cloth_Runecloth)
		KarniCrap_Cloth_CBNetherweave:SetChecked(KarniCrapConfig.Cloth_Netherweave)
		KarniCrap_Cloth_CBFrostweave:SetChecked(KarniCrapConfig.Cloth_Frostweave)
		
		-- scrolls
		KarniCrap_Scrolls_CBMaxScrolls:SetChecked(KarniCrapConfig.ScrollMax)
		KarniCrap_Scrolls_CBScrollAgility:SetChecked(KarniCrapConfig.Scroll_Agility)
		KarniCrap_Scrolls_CBScrollIntellect:SetChecked(KarniCrapConfig.Scroll_Intellect)
		KarniCrap_Scrolls_CBScrollProtection:SetChecked(KarniCrapConfig.Scroll_Protection)
		KarniCrap_Scrolls_CBScrollSpirit:SetChecked(KarniCrapConfig.Scroll_Spirit)
		KarniCrap_Scrolls_CBScrollStamina:SetChecked(KarniCrapConfig.Scroll_Stamina)
		KarniCrap_Scrolls_CBScrollStrength:SetChecked(KarniCrapConfig.Scroll_Strength)
		KarniCrap_CBMaxScrolls()
		
		-- food & water 
		KarniCrap_Consumables_RBFood1:SetChecked(KarniCrapConfig.NeverFood)
		KarniCrap_Consumables_RBFood2:SetChecked(KarniCrapConfig.AlwaysFood)
		KarniCrap_Consumables_CBFoodMax:SetChecked(KarniCrapConfig.FoodMax)
		KarniCrap_Consumables_RBWater1:SetChecked(KarniCrapConfig.NeverWater)
		KarniCrap_Consumables_RBWater2:SetChecked(KarniCrapConfig.AlwaysWater)
		KarniCrap_Consumables_CBWaterMax:SetChecked(KarniCrapConfig.WaterMax)
		KarniCrap_RBFood()
		KarniCrap_RBWater()
		
		-- potions 
		KarniCrap_Potions_RBHealth1:SetChecked(KarniCrapConfig.NeverHealth)
		KarniCrap_Potions_RBHealth2:SetChecked(KarniCrapConfig.AlwaysHealth)
		KarniCrap_Potions_CBHealthMax:SetChecked(KarniCrapConfig.HealthMax)
		KarniCrap_Potions_RBMana1:SetChecked(KarniCrapConfig.NeverMana)
		KarniCrap_Potions_RBMana2:SetChecked(KarniCrapConfig.AlwaysMana)
		KarniCrap_Potions_CBManaMax:SetChecked(KarniCrapConfig.ManaMax)
		KarniCrap_RBHealth()
		KarniCrap_RBMana()
		
		KarniCrap_SelectCategory(selected_category)
		KarniCrap_InitializeBlacklist()
		KarniCrap_InitializeWhitelist()
	
		-- get quest item list --
		KarniCrap_GetQuestItems()
	end
 end



-- Pulls needed quest items from quests in log
function KarniCrap_GetQuestItemInfo(index)
	local leaderboardTxt, itemType, isDone = GetQuestLogLeaderBoard(index)
--	if debug then echo("leaderboardTxt="..leaderboardTxt.." itemType="..itemType) end
	local i, j, itemName, numItems, numNeeded = string.find(tostring(leaderboardTxt), "(.*):%s*([%d]+)%s*/%s*([%d]+)");
	return itemType, itemName, numItems, numNeeded, isDone
end


-- for debugging quest item looting
function ShowQuestItems()
	for index, value in pairs(QuestItemList) do
		echo("item "..index.." is: "..value)
	end
end


-- Timer to delay quest item grabbing till its really in the quest list
function KarniCrap_Timer(self, elapsed)
	self.TimeSinceLastUpdate = self.TimeSinceLastUpdate + elapsed;
	if self.TimeSinceLastUpdate > quest_delay then
		if debug then echo("Time elapsed...populating quest item list") end
		self.TimeSinceLastUpdate = 0;
		KarniCrap_TimerFrame:Hide()
		KarniCrap_GetQuestItems()
	end
end


function KarniCrap_GetQuestItems()
	local i;
	local numEntries, numQuests = GetNumQuestLogEntries()
	QuestItemList = {}

	if numEntries > 0 then
		for i=1, numEntries do
			SelectQuestLogEntry(i)
			local _, _, _, _, isHeader, _, isComplete, _ = GetQuestLogTitle(i)
			if not isHeader and not isComplete then
				local numObjects=GetNumQuestLeaderBoards()
				for i=1, numObjects do
					local itemType, itemName, numItems, numNeeded, isDone = KarniCrap_GetQuestItemInfo(i)
					if itemName and itemType == "item" then
						table.insert(QuestItemList,itemName)
						if (itemName == nil) or (itemName == "") or (itemName == " ") then
							if debug then echo("Item is not in quest list yet, restarting timer.") end
							-- wait 3 seconds and try again
							KarniCrap_TimerFrame:Show()
						end
					end
				end
			end
		end
	end
end



local categoryList = {
	[1] = "Cloth",
	[2] = "Corpses",
	[3] = "Consumables",
 	[4] = "Pickpocketing",
 	[5] = "Potions",
 	[6] = "Scrolls",
 	[7] = "Tradeskills"
}

function KarniCrap_SelectCategory(id)
	local line, name

	selected_category = id	
	for line = 1, 7 do
		name = _G["CategoryItem"..line]:GetText()

		if (_G["CategoryItem"..line]:GetID() == id ) then
		  	_G["CategoryItem"..line]:SetTextFontObject("GameFontHighlightSmall"); -- Delete for WotLK
			_G["CategoryItem"..line.."_Background"]:SetTexture("Interface\\FriendsFrame\\UI-FriendsFrame-HighlightBar.blp")
			KarniCrap_OptionsFrame_Header:SetText(name)
			_G["KarniCrap_"..categoryList[line]]:Show()
		else 
			-- Unhighlight item
		  	_G["CategoryItem"..line]:SetTextFontObject("GameFontNormalSmall"); -- Delete for WotLK	
			_G["CategoryItem"..line.."_Background"]:SetTexture(nil);
			_G["KarniCrap_"..categoryList[line]]:Hide()
		end
	end
end


-- tab 1 show/hide stuff so I can keep stuff parented to things that make sense
function KarniCrap_ShowTab1()
	PanelTemplates_SetTab(KarniCrap, 1);
	_G["KarniCrap_"..categoryList[selected_category]]:Show()
	KarniCrap_CategoryFrame:Show()
	KarniCrap_CategoryScrollBar:Show()
	KarniCrap_OptionsFrame:Show()
	KarniCrap_Tab1:Show();
	KarniCrap_Tab2:Hide();

end

-- tab 2 show/hide stuff so I can keep stuff parented to things that make sense
function KarniCrap_ShowTab2()
	PanelTemplates_SetTab(KarniCrap, 2)
	_G["KarniCrap_"..categoryList[selected_category]]:Hide()
	KarniCrap_CategoryFrame:Hide()
	KarniCrap_CategoryScrollBar:Hide()
	KarniCrap_OptionsFrame:Hide()
	KarniCrap_Tab1:Hide()
	KarniCrap_Tab2:Show()
end




-- handles the option categories scroll area. Not enough options to need it yet :)
function KarniCrap_CategoryScrollBarUpdate()
	local line, lineplusoffset; -- an index into our data calculated from the scroll offset
	local numitems = 7
	local maxvisible = 7
	
	FauxScrollFrame_Update(KarniCrap_CategoryScrollBar,numitems,maxvisible,16);
	
	for line = 1, maxvisible do
		-- create the button frames for the list
		lineplusoffset = line + FauxScrollFrame_GetOffset(KarniCrap_CategoryScrollBar);
		
		if lineplusoffset < numitems + 1 then
			_G["CategoryItem"..line]:Show();
		else
			_G["CategoryItem"..line]:Hide();
		end
	end
end