-- table has the ID and the min required level to use

foodList = {
	["17344"] = 0, 	--Candy Cane
	["2070"] = 0, 	--Darnassian Bleu
	["4604"] = 0,	--Forest Mushroom Cap
	["20857"] = 0,	--Honey Bread
	["7097"] = 0, 	--Leg Meat
	["4536"] = 0, 	--Shiny Red Apple
	["787"] = 0, 	--Slitherskin Mackerel
	["4656"] = 0,	--Small Pumpkin
	["4540"] = 0, 	--Tough Hunk of Bread
	["117"] = 0, 	--Tough Jerky
	
	["414"] = 5, 	--Dalaran Sharp
	["4541"] = 5, 	--Freshly Baked Bread
	["2287"] = 5, 	--Haunch of Meat
	["17406"] = 5,	--Holiday Cheesewheel
	["4592"] = 5,	--Longjaw Mud Snapper
	["6458"] = 5, 	--Oil Covered Fish (crappy)
	["6317"] = 5, 	--Raw Loch Frenzy (crappy)
	["6289"] = 5, 	--Raw Longjaw Mud Snapper (crappy)
	["6361"] = 5, 	--Raw Rainbow Fin Albacore (crappy)
	["4605"] = 5, 	--Red-speckled Mushroom
	["4537"] = 5, 	--Tel'Abim Banana

	["4593"] = 15,	--Bristle Whisker Catfish
	["422"] = 15, 	--Dwarven Mild
	["4542"] = 15, 	--Moist Cornbread
	["3770"] = 15, 	--Mutton Chop
	["6308"] = 15, --Raw Bristle Whisker Catfish (crappy)
	["4538"] = 15, 	--Snapvine Watermelon
	["4606"] = 15, 	--Spongy Morel

	["4607"] = 25, --Delicious Cave Mold
	["4539"] = 25, --Goldenbark Apple
	["17407"] = 25, --Graccu's Homemade Meat Pie
	["8364"] = 25, --Mithril Head Trout
	["4544"] = 25, --Mulgore Spice Bread
	["6362"] = 25, --Raw Rockscale Cod (crappy)
	["4594"] = 25, -- Rockscale Cod
	["1707"] = 25, --Stormwind Brie
	["3771"] = 25, --Wild Hog Shank

	["4599"] = 35, --Cured Ham Steak
	["3927"] = 35, --Fine Aged Cheddar
	["4602"] = 35, --Moon Harvest Pumpkin
	["4608"] = 35, --Raw Black Truffle
	["4601"] = 35, --Soft Banana Bread
	["6887"] = 35, --Spotted Yellowtail

	["8932"] = 45, --Alterac Swiss
	--Arathi Basin Enriched Ration
	["8953"] = 45, --Deep Fried Plantains
	["8948"] = 45, --Dried King Bolete
	["11444"] = 45, --Grim Guzzler Boar
	["8950"] = 45, --Homemade Cherry Pie
	["8952"] = 45, --Roasted Quail
	--Warsong Gulch Enriched Ration

	["27857"] = 55, --Garadar Sharp
	["27855"] = 55, --Mag'har Grainbread
	["27856"] = 55, --Skethyl Berries
	["30610"] = 55, --Smoked Black Bear Meat
	["27854"] = 55, --Smoked Talbuk Venison
	["30458"] = 55, --Stromgarde Muenster
	["27858"] = 55, --Sunspring Carp
	["27859"] = 55, --Zangar Caps

	["29453"] = 65, --Sporeggar Mushroom"

	["33443"] = 70, --Sour Goat Cheese 13200hp/30sec
	["33454"] = 70, --Salted Venison 13200hp/30sec
	["33452"] = 70, --Honey Spiced Lichen 13200hp/30sec
	["37252"] = 70, --Frostberries 13200hp/30sec
	["33451"] = 70, --Fillet of Icefin 13200hp/30sec
	["33449"] = 70, --Crusty Flatbread 13200hp/30sec
	
	["35947"] = 75, --Sparkling Frostcap 15000hp/30sec
	
	
	
	
}


-- 61hp/18sec (level 5, req level 0)
-- 243hp/21sec (level 15, req level 5)
-- 552hp/24sec (level 25, req level 15)
-- 874hp/27sec (level 35, req level 25)
-- 1392hp/30sec (level 45, req level 35)
-- 2148hp/30sec (level 55, req level 45)
-- 4320hp/30sec (level 65, req level 55)
-- 7500hp/30sec (level 75, req level 65)
