Small Totembars addon with readded timers

Looks like a flexible totembar

Shift-Click will now throw a Rank 1 totem.

Short introduction into the Totemsets feature:

The Add dialog will ask you for a name and while this dialog is open you can swap buttons to add those swappings to your set.

Support for Hiding/Showing of Popup Buttons in Sets added:

You have two Buttons Hide/Show now (Red/Green), where you can drag&drop your Totem on and this will either hide/show this button for this set.
This will only work in order, you can't create holes in the popup menu.


Character based profiles are default now:
To merge your old profile, use Profiles->Copy from->"Default"

It is probably a wise idea to get the SharedMedia addon for more Timerbar Textures

You can find the YataTotemStomper macro, which is /castsequence reset=combat/resetbutton <Your Main Buttons> in your characters local macros section.

Press enter after pressing a keybinding to log it in, press escape to clear it