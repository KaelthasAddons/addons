


--	==================================== 	Trade frame	====================================
function GHI_TradeHookings()
	this:RegisterEvent("TRADE_CLOSED");
	this:RegisterEvent("TRADE_ACCEPT_UPDATE");
	--this:RegisterEvent("TRADE_SHOW");
	
	--Old_Script_ItemButton1 = TradePlayerItem1ItemButton:GetScript("OnClick");
	--TradePlayerItem1ItemButton:SetScript("OnClick", function() GHI_TradeItemButton1OnClick(); end);
	
	Orig_ClickTradeButton = ClickTradeButton;
	ClickTradeButton = GHI_ClickTradeButton;
	
	Orig_TradeFrame_UpdatePlayerItem = TradeFrame_UpdatePlayerItem;
	TradeFrame_UpdatePlayerItem = GHI_TradeFrame_UpdatePlayerItem;
	
	Orig_TradeFrame_UpdateRecipientItem = TradeFrame_UpdateTargetItem;
	TradeFrame_UpdateTargetItem = GHI_TradeFrame_UpdateRecipientItem;
	--	Tooltip
	Old_Script_ItemButton = TradePlayerItem1ItemButton:GetScript("OnEnter");
	TradePlayerItem1ItemButton:SetScript("OnEnter", function() Old_Script_ItemButton(); GHI_TradeItemButtonOnEnter(this:GetParent():GetID()); end);
	TradePlayerItem2ItemButton:SetScript("OnEnter", function() Old_Script_ItemButton(); GHI_TradeItemButtonOnEnter(this:GetParent():GetID()); end);
	TradePlayerItem3ItemButton:SetScript("OnEnter", function() Old_Script_ItemButton(); GHI_TradeItemButtonOnEnter(this:GetParent():GetID()); end);
	TradePlayerItem4ItemButton:SetScript("OnEnter", function() Old_Script_ItemButton(); GHI_TradeItemButtonOnEnter(this:GetParent():GetID()); end);
	TradePlayerItem5ItemButton:SetScript("OnEnter", function() Old_Script_ItemButton(); GHI_TradeItemButtonOnEnter(this:GetParent():GetID()); end);
	TradePlayerItem6ItemButton:SetScript("OnEnter", function() Old_Script_ItemButton(); GHI_TradeItemButtonOnEnter(this:GetParent():GetID()); end);
	TradePlayerItem7ItemButton:SetScript("OnEnter", function() Old_Script_ItemButton(); GHI_TradeItemButtonOnEnter(this:GetParent():GetID()); end);

	Old_Script_ItemButtonUpdate = TradePlayerItem1ItemButton:GetScript("OnUpdate");
	TradePlayerItem1ItemButton:SetScript("OnUpdate", function() Old_Script_ItemButtonUpdate(); GHI_TradeItemButtonOnUpdate(arg1); end);
	TradePlayerItem2ItemButton:SetScript("OnUpdate", function() Old_Script_ItemButtonUpdate(); GHI_TradeItemButtonOnUpdate(arg1); end);
	TradePlayerItem3ItemButton:SetScript("OnUpdate", function() Old_Script_ItemButtonUpdate(); GHI_TradeItemButtonOnUpdate(arg1); end);
	TradePlayerItem4ItemButton:SetScript("OnUpdate", function() Old_Script_ItemButtonUpdate(); GHI_TradeItemButtonOnUpdate(arg1); end);
	TradePlayerItem5ItemButton:SetScript("OnUpdate", function() Old_Script_ItemButtonUpdate(); GHI_TradeItemButtonOnUpdate(arg1); end);
	TradePlayerItem6ItemButton:SetScript("OnUpdate", function() Old_Script_ItemButtonUpdate(); GHI_TradeItemButtonOnUpdate(arg1); end);
	TradePlayerItem7ItemButton:SetScript("OnUpdate", function() Old_Script_ItemButtonUpdate(); GHI_TradeItemButtonOnUpdate(arg1); end);
	
	--recipient
	Old_Script_RecipientItemButton = TradeRecipientItem1ItemButton:GetScript("OnEnter");
	TradeRecipientItem1ItemButton:SetScript("OnEnter", function() Old_Script_RecipientItemButton(); GHI_RecipientTradeItemButtonOnEnter(this:GetParent():GetID()); end);
	TradeRecipientItem2ItemButton:SetScript("OnEnter", function() Old_Script_RecipientItemButton(); GHI_RecipientTradeItemButtonOnEnter(this:GetParent():GetID()); end);
	TradeRecipientItem3ItemButton:SetScript("OnEnter", function() Old_Script_RecipientItemButton(); GHI_RecipientTradeItemButtonOnEnter(this:GetParent():GetID()); end);
	TradeRecipientItem4ItemButton:SetScript("OnEnter", function() Old_Script_RecipientItemButton(); GHI_RecipientTradeItemButtonOnEnter(this:GetParent():GetID()); end);
	TradeRecipientItem5ItemButton:SetScript("OnEnter", function() Old_Script_RecipientItemButton(); GHI_RecipientTradeItemButtonOnEnter(this:GetParent():GetID()); end);
	TradeRecipientItem6ItemButton:SetScript("OnEnter", function() Old_Script_RecipientItemButton(); GHI_RecipientTradeItemButtonOnEnter(this:GetParent():GetID()); end);
	TradeRecipientItem7ItemButton:SetScript("OnEnter", function() Old_Script_RecipientItemButton(); GHI_RecipientTradeItemButtonOnEnter(this:GetParent():GetID()); end);

	Old_Script_RecipientItemButtonUpdate = TradeRecipientItem1ItemButton:GetScript("OnUpdate");
	TradeRecipientItem1ItemButton:SetScript("OnUpdate", function() Old_Script_RecipientItemButtonUpdate(); GHI_RecipientTradeItemButtonOnUpdate(arg1); end);
	TradeRecipientItem2ItemButton:SetScript("OnUpdate", function() Old_Script_RecipientItemButtonUpdate(); GHI_RecipientTradeItemButtonOnUpdate(arg1); end);
	TradeRecipientItem3ItemButton:SetScript("OnUpdate", function() Old_Script_RecipientItemButtonUpdate(); GHI_RecipientTradeItemButtonOnUpdate(arg1); end);
	TradeRecipientItem4ItemButton:SetScript("OnUpdate", function() Old_Script_RecipientItemButtonUpdate(); GHI_RecipientTradeItemButtonOnUpdate(arg1); end);
	TradeRecipientItem5ItemButton:SetScript("OnUpdate", function() Old_Script_RecipientItemButtonUpdate(); GHI_RecipientTradeItemButtonOnUpdate(arg1); end);
	TradeRecipientItem6ItemButton:SetScript("OnUpdate", function() Old_Script_RecipientItemButtonUpdate(); GHI_RecipientTradeItemButtonOnUpdate(arg1); end);
	TradeRecipientItem7ItemButton:SetScript("OnUpdate", function() Old_Script_RecipientItemButtonUpdate(); GHI_RecipientTradeItemButtonOnUpdate(arg1); end);
	
	--Old_Script_TradeFrameTradeButtonClick = TradeFrameTradeButton:GetScript("OnClick");
	--TradeFrameTradeButton:SetScript("OnClick", function() Old_Script_TradeFrameTradeButtonClick(); GHI_AcceptTrade(); end);
	Old_Script_TradeOnShow = TradeFrame:GetScript("OnShow");
	TradeFrame:SetScript("OnShow", function() GHI_TradeItemsPlayer = {} GHI_TradeItemsRecipient = {}; GHI_TradeLinksSend = {}; Old_Script_TradeOnShow(); end);
	
end

GHI_TradeFrame_PlayerAcceptState = 0;
GHI_TradeFrame_RecipientAcceptState = 0;

function OnTradeEvent()
	if ( event == "TRADE_CLOSED" ) then
		if (GHI_TradeFrame_PlayerAcceptState == 1 and GHI_TradeFrame_RecipientAcceptState == 1) then
			
			GHI_SendData("TradeAccepted",true,GHI_TradePlayer);
			GHI_AcceptTrade();
		end
		GHI_ClearLocked();
		
	elseif ( event == "TRADE_ACCEPT_UPDATE" ) then
		
		GHI_TradeFrame_PlayerAcceptState = TradeHighlightPlayer:IsShown(); --arg1;
		GHI_TradeFrame_RecipientAcceptState = TradeHighlightRecipient:IsShown(); --arg2;
		
		GHI_TradePlayer = TradeFrameRecipientNameText:GetText();
	elseif ( event == "TRADE_SHOW" ) then
		GHI_TradeItemsPlayer = {}
		GHI_TradeItemsRecipient = {}
		GHI_TradeLinksSend = {};
		GHI_RecipientHasGHI = false;
	end
end

GHI_TradeItemsPlayer = {}

GHI_TradeItemsRecipient = {}

GHI_TradeLinksSend = {};
RecipientHasGHIError = "Trade recipient havent got GHI.";
IsBagError = "Please empty bag before trading it.";
function GHI_ClickTradeButton(slot)
	
	local Type,details = GHI_GetCursor();
		
	if (GetTradePlayerItemInfo(slot)) then --normal item
		if Type == "item" then
			if not(GHI_RecipientHasGHI == true) then
				GHI_Message(RecipientHasGHIError);
				return;
			end
			local bagSlot = details.ItemOrigFrame:GetID();
			local bag = details.ItemOrigFrame:GetParent():GetID();
				
			local ID = GHI_ContainerData[bag][bagSlot].ID;
			
			local amount = tonumber(GHI_CurserItemAmount);
			
			local isBag = GHI_IsBagEmpty(ID)
			if isBag == false then
				GHI_Message(IsBagError);
				return;
			end
			
			-- remove the old one
			Orig_ClickTradeButton(slot)	
			
			
			if amount == 0 then
				amount = GHI_ContainerData[bag][bagSlot].amount;
			end
			
			GHI_SetTradeButton(slot,ID,amount);
			
			GHI_TradeItemsPlayer[slot] = {};
			GHI_TradeItemsPlayer[slot].ID = ID;
			GHI_TradeItemsPlayer[slot].amount = amount;
			GHI_TradeItemsPlayer[slot].OrriginalFrame = details.ItemOrigFrame;
			GHI_TradeItemsPlayer[slot].ItemOrigBag = details.ItemOrigBag;
			
			
			GHI_ResetCursor();
			--	Lock the slot again
			GHI_ContainerData[bag][bagSlot].locked = true;
			GHI_UpdateContainers()
		else
			Orig_ClickTradeButton(slot)
		end
		
	elseif GHI_TradeItemsPlayer[slot] then  -- GHI item
		if Type == "item" then
			if not(GHI_RecipientHasGHI == true) then
				GHI_Message(RecipientHasGHIError);
				return;
			end
			local bagSlot = details.ItemOrigFrame:GetID();
			local bag = details.ItemOrigFrame:GetParent():GetID();
			
			local ID = GHI_ContainerData[bag][bagSlot].ID;
			local origFrame = details.ItemOrigFrame;
			local amount = tonumber(details.ItemAmount);
			local isBag = GHI_IsBagEmpty(ID)
			if isBag == false then
				GHI_Message(IsBagError);
				return;
			end
			
			if amount == 0 then
				amount = GHI_ContainerData[bag][bagSlot].amount;
			end
			
			GHI_PickupGHITradeItem(slot)
			
			GHI_SetTradeButton(slot,ID,amount);
			
			GHI_TradeItemsPlayer[slot] = {};
			GHI_TradeItemsPlayer[slot].ID = ID;
			GHI_TradeItemsPlayer[slot].amount = amount;
			GHI_TradeItemsPlayer[slot].OrriginalFrame = origFrame;
			GHI_TradeItemsPlayer[slot].ItemOrigBag = details.ItemOrigBag;
			
			GHI_ContainerData[bag][bagSlot].locked = true;
			GHI_UpdateContainers()
			
		else 
			--local cursorItem = CursorHasItem();
			
			local a = GHI_TradeItemsPlayer[slot];
			GHI_TradeItemsPlayer[slot] = nil;
			Orig_ClickTradeButton(slot);
			GHI_TradeItemsPlayer[slot] = a;
			
			GHI_PickupGHITradeItem(slot);
			
			--if not(cursorItem) then
			GHI_ClearTradeButton(slot);
			local player = TradeFrameRecipientNameText:GetText();
			GHI_SendData("Trade<"..slot.."",0,player);  -- removes the GHI item for reciepient.
			--end
		end
	else									-- no items
		if Type == "item" then
			if not(GHI_RecipientHasGHI == true) then
				GHI_Message(RecipientHasGHIError);
				return;
			end
			
			local bagSlot = details.ItemOrigFrame:GetID();
			local bag = details.ItemOrigFrame:GetParent():GetID();
			local ID = GHI_ContainerData[bag][bagSlot].ID;
			
			local amount = tonumber(details.ItemAmount);
			local amount2;
			local isBag = GHI_IsBagEmpty(ID)
			if isBag == false then
				GHI_Message(IsBagError);
				return;
			end
			
			if amount == 0 then
				amount2 = GHI_ContainerData[bag][bagSlot].amount;
			else
				amount2 = amount;
			end
			
			
			
			
			
			GHI_TradeItemsPlayer[slot] = {};
			GHI_TradeItemsPlayer[slot].ID = ID;
			GHI_TradeItemsPlayer[slot].amount = amount2;
			
			GHI_TradeItemsPlayer[slot].OrriginalFrame = details.ItemOrigFrame;
			GHI_TradeItemsPlayer[slot].ItemOrigBag = details.ItemOrigBag;
			
			GHI_SetTradeButton(slot,ID,amount2);
			
			GHI_ResetCursor();
			--GHI_Message("Locking "..bag.." : "..bagSlot);
			GHI_ContainerData[bag][bagSlot].locked = true;
			GHI_UpdateContainers()
		else
			Orig_ClickTradeButton(slot)
		end
	end
	
	
end

function GHI_ClearTradeButton(slot)
	local itemButton = getglobal("TradePlayerItem"..slot.."ItemButton");
	
	SetItemButtonTexture(itemButton, "");
	SetItemButtonCount(itemButton, 1);
	
	getglobal(((itemButton:GetParent()):GetName()).."Name"):SetText("");
	
	getglobal("GHI_PlayerTradeType"..slot):Hide();
	getglobal("GHI_PlayerTradeType"..slot.."Label"):SetText("");
end

function GHI_SetTradeButton(slot,ID,amount)
	local name,texture = GHI_GetItemInfo(ID);
	if not(name) then return; end
	
	local itemButton = getglobal("TradePlayerItem"..slot.."ItemButton");
		
	if amount == nil then amount = 1 end;
	
	
	SetItemButtonTexture(itemButton, texture);
	SetItemButtonCount(itemButton, amount);
	
	local itemType;
	if GHI_IsOfficialItem(ID) then  -- official item
		itemType = "|CFF" ..string.format("%.2x",0.7*255) .. string.format("%.2x",0*255) .. string.format("%.2x",0*255) .."Official GH item|r"
	else
		itemType = "|CFF" ..string.format("%.2x",0.0*255) .. string.format("%.2x",0.7*255) .. string.format("%.2x",0.5*255) .."Custom made item|r"
	end
	getglobal("GHI_PlayerTradeType"..slot):Show();
	getglobal("GHI_PlayerTradeType"..slot.."Label"):SetText(itemType);
	
	getglobal(((itemButton:GetParent()):GetName()).."Name"):SetText(name);
	
	--.."\nOfficial item");
	
	
	--- Send data to Recipient
	local player = TradeFrameRecipientNameText:GetText();
	
	local send = false;
	for index,value in pairs(GHI_TradeLinksSend) do 
		if value == ID then
			send = true;
			--GHI_Message("Link already send");
		end
	end
	
	if not(GHI_IsOfficialItem(ID)) and send == false then
		table.insert(GHI_SendItemsID,1,ID);
		table.insert(GHI_TradeLinksSend,ID);
		GHI_SendLink(name,player);
		
	end
	GHI_SendData("Trade<"..slot.."",ID.."-"..amount,player);
	
	-- todo Send duration for "on trade" event
	local bag_slot = GHI_TradeItemsPlayer[slot].OrriginalFrame:GetID();
	local bag = GHI_TradeItemsPlayer[slot].ItemOrigBag;
	
	local data1,data2 = GetContainerDurationInfo(bag,bag_slot);
	local size,Type,start_event = GetDurationInfo(ID);
	if Type then
		
		local duration = 0;
		if data1 then
			if Type == "real_time" then
				duration = floor(data1 - GetTime());
					
				
			elseif Type == "played_time" then
				duration = floor(data1 - (GetTime() - GHI_StartedPlayedTime));
					
				
			elseif Type == "charges" then
				duration = data1;
			end
		elseif start_event == "traded" then
			duration = floor(size);
		end
		GHI:SendCommMessage("WHISPER",player, false, "TradeDuration", slot,duration,Type,data2);
		GHI_TradeItemsPlayer[slot].duration = duration;
		GHI_TradeItemsPlayer[slot].durationType = Type;
		GHI_TradeItemsPlayer[slot].data2 = data2;
		
	end
	
	
	
	
	--GHI_Message("Sended "..ID.." to "..player);
end

function GHI_PickupGHITradeItem(slot)
	if not(GHI_TradeItemsPlayer[slot] == nil) then
		--ClearCursor();
		--SetCursor("ITEM_CURSOR");
		local temp = {};
		local name,icon = GHI_GetItemInfo(GHI_TradeItemsPlayer[slot].ID);
		temp.iconTexture = icon;
		temp.ID = GHI_TradeItemsPlayer[slot].ID;
		--GHI_CursorIcon:SetScale(0.8);
		--GHI_CursorIcon:Show();
		--GHI_CurserHasItem = true;
		temp.ItemOrigFrame = GHI_TradeItemsPlayer[slot].OrriginalFrame;
		temp.ItemOrigBag = GHI_TradeItemsPlayer[slot].ItemOrigBag;
		--GHI_Message("Getting original frame: "..type(temp.ItemOrigFrame));
		temp.ItemAmount = 	GHI_TradeItemsPlayer[slot].amount;
		GHI_SetCursor("item",temp);
		
		--GHIClickOverlayer:Show();
		
		GHI_TradeItemsPlayer[slot] = nil;
	end
end

function GHI_TradeFrame_UpdatePlayerItem(slot)
	
	if not(GHI_TradeItemsPlayer[slot]) then
		Orig_TradeFrame_UpdatePlayerItem(slot)
		if slot < 7 then
			getglobal("GHI_PlayerTradeType"..slot):Hide();
		end
	end
end

function GHI_TradeItemButtonOnEnter(slot)
	if (GHI_TradeItemsPlayer[slot]) then
		
		GameTooltip:SetOwner(this, "ANCHOR_RIGHT");
		
		local ID = GHI_TradeItemsPlayer[slot].ID;
		GHI_ItemTooltip(this,ID)
		
		CursorUpdate();
	end
end

function GHI_TradeItemButtonOnUpdate(elapsed)
	if ( this.updateTooltip ) then
		this.updateTooltip = this.updateTooltip - elapsed;
		if ( this.updateTooltip > 0 ) then
			return;
		end
	end

	if ( GameTooltip:IsOwned(this) ) then
		GHI_TradeItemButtonOnEnter(this:GetParent():GetID());
	end
end

function GHI_RecieveTradeItem(slot,data,player)
	
	slot = tonumber(slot);
	if tonumber(data) == 0 then
		GHI_ClearRecipientButton(slot);
		GHI_TradeItemsRecipient[slot] = {};
		return;
	end
	
	local a = string.find(data,"-");
	--GHR_Message(slot);
	
	if not(a) then return end
	local ID = string.sub(data,0,a-1);
	local amount = tonumber(string.sub(data,a+1));
	
	if not(ID) or not(amount) then return end;
	--GHI_Message(ID..": "..amount);
	GHI_SetRecipientButton(slot,ID,amount)
	
	GHI_TradeItemsRecipient[slot] = {};
	GHI_TradeItemsRecipient[slot].ID = ID;
	GHI_TradeItemsRecipient[slot].amount = amount;
	
end

function GHI_RecieveTradeDuration(slot,duration,durationType,data2)
	
	slot = tonumber(slot);
	GHI_TradeItemsRecipient[slot].duration = duration;
	GHI_TradeItemsRecipient[slot].durationType = durationType;
	GHI_TradeItemsRecipient[slot].data2 = data2;
	
	
end

function GHI_SetRecipientButton(slot,ID,amount)
	local name,texture = GHI_GetItemInfo(ID);
	if not(name) then return; end
	
	
	local itemButton = getglobal("TradeRecipientItem"..slot.."ItemButton");
	
	if amount == nil then amount = 1 end;
	
	
	SetItemButtonTexture(itemButton, texture);
	SetItemButtonCount(itemButton, amount);
	
	local itemType;
	if GHI_IsOfficialItem(ID) then  -- official item
		itemType = "|CFF" ..string.format("%.2x",0.7*255) .. string.format("%.2x",0*255) .. string.format("%.2x",0*255) .."Official GH item|r"
	else
		itemType = "|CFF" ..string.format("%.2x",0.0*255) .. string.format("%.2x",0.7*255) .. string.format("%.2x",0.5*255) .."Custom made item|r"
	end
	
	getglobal(((itemButton:GetParent()):GetName()).."Name"):SetText(name);
	
	getglobal("GHI_RecipientTradeType"..slot):Show();
	getglobal("GHI_RecipientTradeType"..slot.."Label"):SetText(itemType);
end

function GHI_ClearRecipientButton(slot)
	local itemButton = getglobal("TradeRecipientItem"..slot.."ItemButton");
	
	SetItemButtonTexture(itemButton, "");
	SetItemButtonCount(itemButton, 1);
	
	getglobal(((itemButton:GetParent()):GetName()).."Name"):SetText("");
	
	getglobal("GHI_RecipientTradeType"..slot):Hide();
	getglobal("GHI_RecipientTradeType"..slot.."Label"):SetText("");
	
end

function GHI_RecipientTradeItemButtonOnEnter(slot)
	if (GHI_TradeItemsRecipient[slot]) then
		
		GameTooltip:SetOwner(this, "ANCHOR_RIGHT");
		
		local ID = GHI_TradeItemsRecipient[slot].ID;
		GHI_ItemTooltip(this,ID)
		
		CursorUpdate();
	end
end

function GHI_RecipientTradeItemButtonOnUpdate(elapsed)
	if ( this.updateTooltip ) then
		this.updateTooltip = this.updateTooltip - elapsed;
		if ( this.updateTooltip > 0 ) then
			return;
		end
	end

	if ( GameTooltip:IsOwned(this) ) then
		GHI_RecipientTradeItemButtonOnEnter(this:GetParent():GetID());
	end
end

function GHI_TradeFrame_UpdateRecipientItem(slot)
	
	if not(GHI_TradeItemsRecipient[slot]) then
		Orig_TradeFrame_UpdateRecipientItem(slot)
		if slot < 7 then
			getglobal("GHI_RecipientTradeType"..slot):Hide();
		end
	end
	if slot == 1 then
		GHI_RecipientHasGHI = false;
		local player = TradeFrameRecipientNameText:GetText();
		GHI_SendData("AddonVersionReq",nil,player)
		GHI_TradePlayer = player;
	end
end

GHI_TradeOverFlow = {}

function GHI_AcceptTrade()
	local player = TradeFrameRecipientNameText:GetText();
	--GHR_Message(player);
	--  Delete items traded away
	local ID,amount;
	for i = 1,6 do
		if GHI_TradeItemsPlayer[i] then
			ID = GHI_TradeItemsPlayer[i].ID;
			amount = GHI_TradeItemsPlayer[i].amount;
			
			if ID and amount then
				local amountLeft = amount;
				local bag, slot;
				
				local slot = GHI_TradeItemsPlayer[i].OrriginalFrame:GetID();
				local bag = GHI_TradeItemsPlayer[i].ItemOrigBag;
				
				local slotAmount = GHI_ContainerData[bag][slot].amount;
						
				if amountLeft < slotAmount then
					GHI_ContainerData[bag][slot].amount = slotAmount - amountLeft;
					amountLeft = 0;
				else
					GHI_ContainerData[bag][slot] = nil;
					amountLeft = amountLeft - slotAmount;
				end
				
				while amountLeft > 0 do
					
					bag, slot = GHI_FindItem(ID);
					if bag and slot then
						local slotAmount = GHI_ContainerData[bag][slot].amount;
						
						if amountLeft < slotAmount then
							GHI_ContainerData[bag][slot].amount = slotAmount - amountLeft;
							amountLeft = 0;
						else
							GHI_ContainerData[bag][slot] = nil;
							amountLeft = amountLeft - slotAmount;
						end
					else
						GHI_Message("Could not find all items");
						break;
					end
					
				end
								
				
			end			
		end
	end
	
	
	
	
	-- insert recieved items.
	local ID,amount,bag,space;
	local msgFlag = 0;
	
	for i = 1,6 do
		if GHI_TradeItemsRecipient[i] then
			ID = GHI_TradeItemsRecipient[i].ID;
			amount = GHI_TradeItemsRecipient[i].amount;
			
			if ID and amount then
				
				--	Get item data from the recipient, by sending own version number of the item data.
				if not(GHI_IsOfficialItem(ID)) then
					
					local v1,v2 = GHI_GetVersions(ID);
					GHI:SendCommMessage("WHISPER",player,false,"ItemDataVersions",ID,v1,v2)
				end
				--	Insert
				bag,space = GHI_GetFreeSpace();
				if bag and space then
					GHI_ContainerData[bag][space] = {};
					GHI_ContainerData[bag][space].ID = ID;
					GHI_ContainerData[bag][space].amount = amount;
					
					-- Duration
					local duration = GHI_TradeItemsRecipient[i].duration;
					local durationType = GHI_TradeItemsRecipient[i].durationType;
					local data2 = GHI_TradeItemsRecipient[i].data2;
					if durationType == "real_time" then
						duration = GetTime()  + duration;
					elseif durationType == "played_time" then
						duration = (GetTime()-GHI_StartedPlayedTime)  +duration;
					end
					SetContainerDurationInfo(bag,space,duration,data2);
				else
					if msgFlag == 0 then
						GHI_Message("Your bags are full, please clear out your bags");
					end
					local array = {}
					array.ID = ID;
					array.amount = amount;
					table.insert(GHI_TradeOverFlow,array);
				end
			end			
		end
	end
	
	GHI_MaintainMainBags();
	GHI_UpdateContainers()
	
	GHI_TradeFrame_PlayerAcceptState = 0;
	GHI_TradeFrame_RecipientAcceptState = 0;
	
	GHI_TradeItemsPlayer = {}
	GHI_TradeItemsRecipient = {}
	GHI_TradeLinksSend = {};
	GHI_ClearLocked();
	
end
