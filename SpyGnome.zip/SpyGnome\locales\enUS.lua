local L = AceLibrary("AceLocale-2.2"):new("SpyGnome")

L:RegisterTranslations("enUS", function() return {
	["Player"] = true,
	["Addons in the %s category."] = true,
	["Uncategorized"] = true,
	["Uncategorized addons."] = true,
	["Toggle whether to query for %s."] = true,
	["|cffff0000Red|r is newer than yours, |cff0000ffBlue|r is older than yours, and |cff00ff00Green|r is the same version. \"N/A\" means the person does not have an addon, \"Unknown\" means that no version information could be found."] = true,
	["The SpyGnome is lurking just behind you, in the shadows. He has no new information for you at this time."] = true,

	["N/A"] = true,
	["Unknown"] = true,
} end)

