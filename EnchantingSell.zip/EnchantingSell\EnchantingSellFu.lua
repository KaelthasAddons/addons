ESellerFu = AceLibrary("AceAddon-2.0"):new("AceEvent-2.0", "AceConsole-2.0", "AceDB-2.0", "FuBarPlugin-2.0");
local L = AceLibrary("AceLocale-2.2"):new("EnchantingSell")
local Tablet = AceLibrary("Tablet-2.0")

--fubar plugin options
ESellerFu.hasIcon = true;
ESellerFu.hasNoColor = true;
ESellerFu.hasNoText = true;
ESellerFu.hideWithoutStandby = true;		--allows to hide the minimap icon, without suspending the addon.
ESellerFu.clickableTooltip = false
ESellerFu.cannotDetachTooltip = true;
ESellerFu.defaultPosition = "MINIMAP";
ESellerFu.defaultMinimapPosition = 155;
ESellerFu:RegisterDB("EnchantingSellerFuDB", nil, "char")

local waterfall = AceLibrary:HasInstance("Waterfall-1.0") and AceLibrary("Waterfall-1.0")

function ESellerFu:OnEnable()
    self:Update();	--fubarplugin
end

function ESellerFu:OnTooltipUpdate()
	local cat = Tablet:AddCategory("columns", 2)
	Tablet:SetHint(L["\n|cffeda55fShift-Click|r to open Enchanting.\n|cffeda55fAlt-Click|r to open Options.\n|cffeda55fLeft-Click|r to toggle EnchantingSell"])
end

--handle the fubar onclick
function ESellerFu:OnClick(button)
--	if (GetCraftSkillLine(1)==L["Enchanting"] and ESeller:isCraftFrameOpen()) then
--	if (GetCraftSkillLine(1)==L["Enchanting"]) then
--		ESeller:Print("setShouldCloseCraftFrame true");
--		ESeller:setShouldCloseCraftFrame(true);
--	else
--		ESeller:Print("setShouldCloseCraftFrame false");
--		ESeller:setShouldCloseCraftFrame(false);
--	end

	if IsShiftKeyDown() then
		if (not ESeller:isDisableCraftFrame()) then
			CastSpellByName(L["Enchanting"]);
		end
	elseif IsAltKeyDown() then
		if (waterfall) then
			ESeller:OpenOptions()
		else
			self:Print(L["Waterfall-1.0 is required to access the GUI."])
		end	
	else
		ESeller:Launch()
	end
end
