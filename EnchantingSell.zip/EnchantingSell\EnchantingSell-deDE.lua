local L = AceLibrary("AceLocale-2.2"):new("EnchantingSell")

EnchantingSell_Quality = {
	["Quality_Health"] = {
		[1] = {"Schwache"; 5};
		[2] = {"Geringe"; 15};
		[3] = {"None"; 25};
		[4] = {"Gro\195\159e"; 35};
		[5] = {"\195\156berragende"; 50};
		[6] = {"Erhebliche"; 100};
	};
	["Quality_Defence"] = {
		[1] = {"Geringe"; 1};
		[2] = {"Schwache"; 2};
		[3] = {"None"; 3};
		[4] = {"Gro\195\159e"; 0};
		[5] = {"\195\156berragende"; 0};
		[6] = {"Erhebliche"; 0};
	};	
	["Quality_Mana"] = {
		[1] = {"Schwaches"; 5};
		[2] = {"Geringes"; 20};
		[3] = {"None"; 30};
		[4] = {"Gro\195\159es"; 50};
		[5] = {"\195\156berragendes"; 65};
		[6] = {"Erhebliches"; 100};
	};
	["Quality_Armschiene"] = {
		[1] = {"Manaregenaration"; "4 Mana 5 Sek"};
		[2] = {"Heilkraft"; "Heilkraft +24"};
	};
	["Quality_Absorption"] = {
		[1] = {"Schwache"; "2%"};
		[2] = {"Geringe"; "5%"};
		[3] = {"None"; 0};
		[4] = {"Gro\195\159e"; 0};
		[5] = {"\195\156berragende"; 0};
		[6] = {"Erhebliche"; 0};
	};	
	["Quality_OneCarac"] = {
		[1] = {"Schwache"; 1};
		[2] = {"Geringe"; 3};
		[3] = {"None"; 5};
		[4] = {"Gro\195\159e"; 7};
		[5] = {"\195\156berragende"; 9};
		[6] = {"Erhebliche"; 9}; --added Lordrod 29.01.2006
	};
	["Quality_Int_Bracers"] = {
		[1] = {"Schwache"; 1};
		[2] = {"Geringe"; 3};
		[3] = {"None"; 5};
		[4] = {"Gro\195\159e"; 7};
		[5] = {"\195\156berragende"; 9};
		[6] = {"Erhebliche"; 12};
	};
	["Quality_Maechtige20"] = {
		[1] = {"Schwache"; 1};
		[2] = {"Geringe"; 3};
		[3] = {"None"; 5};
		[4] = {"Gro\195\159e"; 7};
		[5] = {"\195\156berragende"; 9};
		[6] = {"Erhebliche"; 9}; --added Lordrod 29.01.2006
		[0] = {"M\195\164chtige"; 20}; --added Lordrod 29.01.2006 Blizzard's Deutschübersetzter haben keine Ahnung vom Spiel und was sie schon mal übersetzt haben!
	};
	["Quality_Maechtige22"] = {
		[0] = {"M\195\164chtige"; 22}; --added Lordrod 29.01.2006 Blizzard's Deutschübersetzter haben keine Ahnung vom Spiel und was sie schon mal übersetzt haben!
	};
	["Quality_None15"] = { --added LordRod 2006-08-15 add so its possible to see the difference between 15 and 25
		[0] = {"None"; 15};
	};
	["Quality_None25"] = { --added LordRod 2006-08-15 add so its possible to see the difference between 15 and 25
		[0] = {"None"; 25};
	};
	
	["Quality_Caract"] = {
		[1] = {"Schwache"; 1};
		[2] = {"Geringe"; 2};
		[3] = {"None"; 3};
		[4] = {"Gro\195\159e"; 0};
		[5] = {"\195\156berragende"; 0};
		[6] = {"Erhebliche"; 0};
	};	
	["Quality_Armure"] = {
		[1] = {"Schwache"; 10};
		[2] = {"Geringe"; 20};
		[3] = {"None"; 30};
		[4] = {"Gro\195\159e"; 50};
		[5] = {"\195\156berragende"; 70};
		[6] = {"Erhebliche"; 0};
	};	
	["Quality_Armure_Bouclier"] = {
		[1] = {"Schwache"; 0};
		[2] = {"Geringer"; 30};
		[3] = {"None"; 0};
		[4] = {"Gro\195\159e"; 0};
		[5] = {"\195\156berragende"; 0};
		[6] = {"Erhebliche"; 0};
	};	
	["Quality_Degat1M"] = {
		[1] = {"Schwache"; 1};
		[2] = {"Geringe"; 2};
		[3] = {"None"; 3};
		[4] = {"Gro\195\159e"; 4};
		[5] = {"\195\156berragende"; 5};
		[6] = {"Erhebliche"; 0};
	};	
	["Quality_Degat2M"] = {
		[1] = {"Schwache"; 2};
		[2] = {"Geringe"; 3};
		[3] = {"None"; 5};
		[4] = {"Gro\195\159e"; 7};
		[5] = {"\195\156berragende"; 9};
		[6] = {"Erhebliche"; 0};
	};	
	["Quality_Blocage"] = {
		[1] = {"Schwache"; "0%"};
		[2] = {"Geringe"; "2%"};
		[3] = {"None"; "0%"};
		[4] = {"Gro\195\159e"; "0%"};
		[5] = {"\195\156berragende"; "0%"};
		[6] = {"Erhebliche"; "0%"};
	};	
	["Quality_Tueur"] = {
		[1] = {"Schwache"; 2};
		[2] = {"Geringer"; 6};
		[3] = {"None"; 0};
		[4] = {"Gro\195\159e"; 0};
		[5] = {"\195\156berragende"; 0};
		[6] = {"Erhebliche"; 0};
	};	
	["Quality_Depecage"] = {
		[1] = {"Schwache"; 0};
		[2] = {"Geringe"; 0};
		[3] = {"None"; 5};
		[4] = {"Gro\195\159e"; 0};
		[5] = {"\195\156berragende"; 0};
		[6] = {"Erhebliche"; 0};
	};	
	["Quality_Metier"] = {
		[1] = {"nul"; 0};
		[2] = {"nul"; 0};
		[3] = {"None"; 2};
		[4] = {"Hochentwickelte"; 5}; --fixed Lordrod 29.01.2006
		[5] = {"\195\156berragende"; 0};
		[6] = {"Erhebliche"; 0};
	};	
	["Quality_Haste"] = {
		[1] = {"Schwache"; "1%"};
		[2] = {"Geringe"; 0};
		[3] = {"None"; 0};
		[4] = {"Gro\195\159e"; 0};
		[5] = {"\195\156berragende"; 0};
		[6] = {"Erhebliche"; 0};
	};	
	["Quality_ResistFeu"] = {
		[1] = {"Schwache"; 0};
		[2] = {"Geringe"; 5};
		[3] = {"None"; 7};
		[4] = {"Gro\195\159e"; 15}; --added Lordrod 29.01.2006
		[5] = {"\195\156berragende"; 0};
		[6] = {"Major"; 0};
	};	
	["Quality_ResistOmbre"] = {
		[1] = {"Schwache"; 0};
		[2] = {"Geringe"; 10};
		[3] = {"None"; 0};
		[4] = {"Gro\195\159e"; 0};
		[5] = {"\195\156berragende"; 0};
		[6] = {"Erhebliche"; 0};
	};	
	["Quality_AllResist"] = {
		[1] = {"Schwache"; 1};
		[2] = {"Geringe"; 0};
		[3] = {"None"; 3};
		[4] = {"Gro\195\159e"; 5};
		[5] = {"\195\156berragende"; 0};
		[6] = {"Erhebliche"; 0};
	};	
	["Quality_ResistFroid"] = {
		[1] = {"Schwache"; 0};
		[2] = {"Geringe"; 0};
		[3] = {"None"; 8};
		[4] = {"Gro\195\159e"; 0};
		[5] = {"\195\156berragende"; 0};
		[6] = {"Erhebliche"; 0};
	};	
	["Quality_ForNew"] = {
		[1] = {"Schwache"; 0};
		[2] = {"Geringe"; 0};
		[3] = {"None"; 0};
		[4] = {"Gro\195\159e"; 0};
		[5] = {"\195\156berragende"; 0};
		[6] = {"Erhebliche"; 0};
	};	
	["Quality_Agility_Gloves"] = {
		[1] = {"None"; 5};
		[2] = {"Gro\195\159e"; 7};
		[3] = {"\195\156berragende"; 15};
	};
    };

L:RegisterTranslations("deDE", function() return {
    ["Enchanting"] = "Verzauberkunst",
    ["Enchant"] = "Verzaubern",
    ["Enchanting Seller"] = "Enchanting Seller",
    ["Filter By Armor"] = "Filter By Armor",
    ["Have Materials"] = "Have Materials",
    ["Sort by feasibility"] = "Sort by feasibility",
    ["EnchantingSeller has prevented you from changing this filter.  Changing this filter can have an unexpected result while using EnchantingSeller."] = "EnchantingSeller has prevented you from changing this filter.  Changing this filter can have an unexpected result while using EnchantingSeller.",
    ["EnchantingSeller has detected that your database is outdated.  It will be reset now."] = "EnchantingSeller has detected that your database is outdated.  It will be reset now.",
    ["PATTERN_EnchantName"] = "^(.+)%s%-%s.+",
    ["PATTERN_Quality"] = "^.+%s%-%s(.+)",
    ["Header tooltip"] = "Kopfzeile Verzauberungen\n\r\n\rKlick: Sortiere diese Spalte\n\rNochmaliges Klicken: Umgekehrte Sortierung",
    ["Reagent Header tooltip"] = "Click to send reagent list to chat",
    ["A copy of your enchants and reagents has been created.  Logoff and exit the game and follow the rest of the instructions"] = "A copy of your enchants and reagents has been created.  Logoff and exit the game and follow the rest of the instructions",
    ["Default database not yet supported for your client locale"] = "Default database not yet supported for your client locale",
    ["Import complete"] = "Import complete",
    ["ENCHANT_ALT"] = "Color Schemes:\n\rClear green-> You have all the ingredients and rod in your bags.\n\rDark green-> Some ingredients necessary are in the bank.\n\rBrown-> Some ingredients necessary are on Alts.\n\rGray-> You do not know this enchant.";

    ["ARMOR_TYPES"] = {
	[1] = {"Armschiene", "Armschiene"};		--bracers
	[2] = {"Brust", "Brust"};			--chest
	[3] = {"Gemischt", "Gemischt"};			--Other		
	[4] = {"Handschuhe", "Handschuhe"};		--gloves
	[5] = {"Öl", "Öl"};				--Oil
	[6] = {"Rute", "Rute"};				--Rod
	[7] = {"Schild", "Schild"};			--shield
	[8] = {"Stab", "Stab"};				--Wand
	[9] = {"Stiefel", "Stiefel"};			--boots
	[10] = {"Umhang", "Umhang"};			--cloak
	[11] = {"Waffe", "Waffe"};			--weapon
	[12] = {"Zweihandwaffe", "Zweihandwaffe"};	--2h weapon
	[13] = {"Ring", "Ring"};			--Ring
	[14] = {"Schmuck", "Schmuck"};			--Trinket
    };

    ["OBJECT_TYPES"] = {
	{"Runenverzierte Kupferrute", "Runenverzierte Kupferrute", "Rute"},
	{"Runenverzierte Silberrute", "Runenverzierte Silberrute", "Rute"},
	{"Runenverzierte Goldrute", "Runenverzierte Goldrute", "Rute"},
	{"Runenverzierte Echtsilberrute", "Runenverzierte Echtsilberrute", "Rute"},
	{"Runenverzierte Arkanitrute", "Runenverzierte Arkanitrute", "Rute"},
	{"Geringer Magiezauberstab", "(Arc)dps:11.3", "Stab"},
	{"Gro\195\159er Magiezauberstab", "(Arc)dps:17.5", "Stab"},
	{"Geringer Mystikerzauberstab", "(Arc)dps:25.4", "Stab"},
	{"Gro\195\159er Mystikerzauberstab", "(Arc)dps:29.0", "Stab"},
	{"Schwaches Zauber\195\182l", "Z. Sch. +8", "Ã–l"},				--minor wizard
	{"Geringes Zauber\195\182l", "Z. Sch. +16", "Ã–l"},				--lesser wizard
	{"Zauber\195\182l", "Z. Sch. +24", "Ã–l"},					--wizard oil
	{"Hervorragendes Zauber\195\182l", "Z. Sch. +36", "Ã–l"},			--Brilliant wizard
	{"Schwaches Mana\195\182l", "4 Mana 5 Sek", "Ã–l"},				--minor mana
	{"Geringes Mana\195\182l", "8 Mana 5 Sek", "Ã–l"},				--lesser mana
	{"Hervorragendes Mana\195\182l", "12 Mana 5 Sek", "Ã–l"},			--Brilliant mana	
	{"Verzaubertes Thorium", "Verzaubertes Thorium", "Gemischt"},			--Enchanted Thorium
	{"Verzaubertes Leder", "Verzaubertes Leder", "Gemischt"},			--Enchanted Leather
	{"Rauchendes Herz des Berges", "Rauchendes Herz des Berges", "Schmuck"},	--Smoking Heart of the Mountain
	{"Gro\195\159er Prismasplitter", "Gro\195\159er Prismasplitter", "Gemischt"},	--Large Prismatic Shard
    };



    ["BONUS_TYPES"] = {
	{"Schutz";														"Schutz";														EnchantingSell_Quality["Quality_Armure_Bouclier"];	"Schild"};
	{"Schutz";														"R\195\188stung";										EnchantingSell_Quality["Quality_Armure"];						nil};
	{"Verteidigung";											"R\195\188stung";										EnchantingSell_Quality["Quality_Armure"];						nil};
	{"Deflect";														"Def";															EnchantingSell_Quality["Quality_Defence"];					nil};
	{"Abwehr";														"Vert";															EnchantingSell_Quality["Quality_Defence"];					nil};
	{"Hast";															"Angriffst.";												EnchantingSell_Quality["Quality_Haste"];						nil};
	{"Tempo";															"Tempo";														EnchantingSell_Quality["Quality_Haste"];						nil};
	{"Ausdauer";													"Ausdauer";													EnchantingSell_Quality["Quality_OneCarac"];					nil};
	{"Willenskraft";											"Willen";														EnchantingSell_Quality["Quality_Maechtige20"];					  "Waffe"};
	{"Willenskraft";											"Willen";														EnchantingSell_Quality["Quality_OneCarac"];					  nil};
	{"Beweglichkeit";											"Bewegl.";												EnchantingSell_Quality["Quality_None15"];					"Waffe"};
	{"Beweglichkeit";											"Bewegl.";												EnchantingSell_Quality["Quality_None25"];					"Zweihandwaffe"};
	{"Beweglichkeit";											"Bewegl.";												EnchantingSell_Quality["Quality_OneCarac"];					nil};
	{"St\195\164rke";											"St\195\164rke";										EnchantingSell_Quality["Quality_None15"];					"Waffe"};
	{"St\195\164rke";											"St\195\164rke";										EnchantingSell_Quality["Quality_OneCarac"];					nil};
	{"Intelligenz";												"Int";															EnchantingSell_Quality["Quality_Maechtige22"];					"Waffe"};
	{"Intelligenz";												"Int";															EnchantingSell_Quality["Quality_Int_Bracers"];					nil};
	{"Werte";															"Werte";														EnchantingSell_Quality["Quality_Caract"];						nil};
	{"Manaregeneration";									"4 Mana 5 Sek";											nil;																								nil};
	{"Mana";															"Mana";															EnchantingSell_Quality["Quality_Mana"];							nil};
	{"Heilkraft";													"Heilkraft +55";										nil;																								"Waffe"};
	{"Heilkraft";													"Heilkraft +24";										nil;																								"Armschiene"};
	{"Gesundheit";												"Gesundh.";													EnchantingSell_Quality["Quality_Health"];						nil};
	{"Absorption";												"Absorb.";													EnchantingSell_Quality["Quality_Absorption"];				nil};
	{"Wildtiert\195\182ter";							"Wildtier.";							EnchantingSell_Quality["Quality_Tueur"];						nil};
	{"Elementart\195\182ter";							"Elementar.";				EnchantingSell_Quality["Quality_Tueur"];						nil};
	{"D\195\164monent\195\182ten";				"D\195\164monent\195\182ten";				nil;																								nil};
	{"Wintermacht";				"Frostsch. +7";				nil;																								nil};
	{"Schlagen";													"Schlagen";													EnchantingSell_Quality["Quality_Degat1M"];					nil};
	{"Einschlag";													"Einschlag";												EnchantingSell_Quality["Quality_Degat2M"];					nil};
	{"Feuerwiderstand";										"Feuerr";														EnchantingSell_Quality["Quality_ResistFeu"];				nil};
	{"Frostwiderstand";										"Frostr";														EnchantingSell_Quality["Quality_ResistFroid"];			nil};
	{"Schattenwiderstand";								"Schattenr";												EnchantingSell_Quality["Quality_ResistOmbre"];			nil};
	{"Widerstand";												"Widerstand";												EnchantingSell_Quality["Quality_AllResist"];				nil};
	{"Kr\195\164uterkunde";								"Kr\195\164uterk.";									EnchantingSell_Quality["Quality_Metier"];						nil};
	{"Bergbau";														"Bergbau";													EnchantingSell_Quality["Quality_Metier"];						nil};
	{"Angeln";														"Angeln";														EnchantingSell_Quality["Quality_Metier"];						nil};
	{"K\195\188rschnerei";								"K\195\188rschn.";										EnchantingSell_Quality["Quality_Depecage"];					nil};
	{"Blocken";														"Blocken";													EnchantingSell_Quality["Quality_Blocage"];					nil};
    };

} end)
