local L = AceLibrary("AceLocale-2.2"):new("EnchantingSell")

EnchantingSell_Quality = {
	["Quality_OneCarac"] = {
		[1] = {"mineur"; 1};
		[2] = {"inf\195\169rieur"; 3};
		[3] = {"None"; 5};
		[4] = {"sup\195\169rieur"; 7};
		[5] = {"excellent"; 9};
	};
	["Quality_Int_Bracers"] = {
		[1] = {"mineur"; 1};
		[2] = {"inf\195\169rieur"; 3};
		[3] = {"None"; 5};
		[4] = {"sup\195\169rieur"; 7};
		[5] = {"excellent"; 9};
		[6] = {"majeur"; 12};
	};
	["Quality_Int_Weapon"] = {
		[1] = {"mineur"; 1};
		[2] = {"inf\195\169rieur"; 3};
		[3] = {"None"; 5};
		[5] = {"sup\195\169rieur"; 7};
		[6] = {"excellent"; 9};
		[7] = {"puissant"; 22};
	};
	["Quality_Spirit_Weapon"] = {
		[1] = {"mineur"; 1};
		[2] = {"inf\195\169rieur"; 3};
		[3] = {"None"; 5};
		[5] = {"sup\195\169rieur"; 7};
		[6] = {"excellent"; 9};
		[7] = {"puissant"; 20};
	};
	["Quality_Life"] = {
		[1] = {"mineur"; 5};
		[2] = {"inf\195\169rieur"; 15};
		[3] = {"None"; 25};
		[4] = {"sup\195\169rieur"; 35};
		[5] = {"excellent"; 50};
		[6] = {"majeur"; 100};
	};
	["Quality_Mana"] = {
		[1] = {"mineur"; 5};
		[2] = {"inf\195\169rieur"; 20};
		[3] = {"None"; 30};
		[4] = {"sup\195\169rieur"; 50};
		[5] = {"excellent"; 65};
	};
	["Quality_Caract"] = {
		[1] = {"mineur"; 1};
		[2] = {"inf\195\169rieur"; 2};
		[3] = {"None"; 3};
	};	
	["Quality_Armure"] = {
		[1] = {"mineur"; 10};
		[2] = {"inf\195\169rieur"; 20};
		[3] = {"None"; 30};
		[4] = {"sup\195\169rieur"; 50};
		[5] = {"excellent"; 70};
	};	
	["Quality_Defence"] = {
		[1] = {"mineur"; 1};
		[2] = {"inf\195\169rieur"; 2};
		[3] = {"None"; 3};
	};	
	["Quality_Degat1M"] = {
		[1] = {"mineur"; 1};
		[2] = {"inf\195\169rieur"; 2};
		[3] = {"None"; 3};
		[4] = {"sup\195\169rieur"; 4};
		[5] = {"excellent"; 5};
	};	
	["Quality_Degat2M"] = {
		[1] = {"mineur"; 2};
		[2] = {"inf\195\169rieur"; 3};
		[3] = {"None"; 5};
		[4] = {"sup\195\169rieur"; 7};
		[5] = {"excellent"; 9};
	};	
	["Quality_Tueur"] = {
		[1] = {"mineur"; 2};
		[2] = {"inf\195\169rieur"; 6};
	};	
	["Quality_Absorption"] = {
		[1] = {"mineur"; "2% Abs10pv"};
		[2] = {"inf\195\169rieur"; "5% Abs25pv"};
	};	
	["Quality_Metier"] = {
		[1] = {"None"; 2};
		[4] = {"avanc\195\169"; 5};
	};	
	["Quality_ResistFeu"] = {
		[1] = {"inf."; 5};
		[2] = {"None"; 7};
	};	
	["Quality_AllResist"] = {
		[1] = {"mineur"; 1};
		[3] = {"None"; 3};
		[4] = {"sup\195\169rieur"; 5};
	};	
	["Quality_ForNew"] = {
		[1] = {"mineur"; 0};
		[2] = {"inf\195\169rieur"; 0};
		[3] = {"None"; 0};
		[4] = {"sup\195\169rieur"; 0};
		[5] = {"excellent"; 0};
		[6] = {"majeur"; 0};
	};	
	["Quality_Agility_Gloves"] = {
		[1] = {"None"; 5};
		[2] = {"Greater"; 7};
		[3] = {"Superior"; 15};
	};	
    };

L:RegisterTranslations("frFR", function() return {
    ["Enchanting"] = "Enchantement",
    ["Enchant"] = "Enchanter",
    ["Enchanting Seller"] = "Enchanting Seller",
    ["Filter By Armor"] = "Filter By Armor",
    ["Have Materials"] = "Have Materials",
    ["Sort by feasibility"] = "Sort by feasibility",
    ["EnchantingSeller has prevented you from changing this filter.  Changing this filter can have an unexpected result while using EnchantingSeller."] = "EnchantingSeller has prevented you from changing this filter.  Changing this filter can have an unexpected result while using EnchantingSeller.",
    ["EnchantingSeller has detected that your database is outdated.  It will be reset now."] = "EnchantingSeller has detected that your database is outdated.  It will be reset now.",
    ["PATTERN_EnchantName"] = "^(.+)%(.+%)",
    ["PATTERN_Quality"] = "^.+%((.+)%)",
    ["Header tooltip"] = "Ent\195\170te Enchantements\n\r\n\rClic: Trie cette colonne\n\rUn deuxi\195\168me clic: Inverse le trie Croissant\n\r  en D\195\169croissant ou inversement",
    ["Reagent Header tooltip"] = "Click to send reagent list to chat",
    ["A copy of your enchants and reagents has been created.  Logoff and exit the game and follow the rest of the instructions"] = "A copy of your enchants and reagents has been created.  Logoff and exit the game and follow the rest of the instructions",
    ["Default database not yet supported for your client locale"] = "Default database not yet supported for your client locale",
    ["Import complete"] = "Import complete",
    ["ENCHANT_ALT"] = "Color Schemes:\n\rClear green-> You have all the ingredients and rod in your bags.\n\rDark green-> Some ingredients necessary are in the bank.\n\rBrown-> Some ingredients necessary are on Alts.\n\rGray-> You do not know this enchant.";

    ["ARMOR_TYPES"] = {
	[1] = {"bottes", "Bottes"};		--boots
	[2] = {"bracelets", "Bracelets"};	--bracer
	[3] = {"plastron", "Plastron"};		--chest
	[4] = {"cape", "Cape"};			--cloak
	[5] = {"gants", "Gants"};		--gloves
	[6] = {"Huile", "Huile"};		--Oil
	[7] = {"B\195\162tonnet", "B\195\162tonnet"};	--Rod
	[8] = {"bouclier", "Bouclier"};		--shield
	[9] = {"Baguette", "Baguette"};		--wand
	[10] = {"arme 2M", "Arme 2M"};		--2h weapon
	[11] = {"arme", "Arme"};		--weapon
	[12] = {"Autres", "Autres"};		--Other
    };

    ["OBJECT_TYPES"] = {
	{"B\195\162tonnet runique en cuivre", "runiq cuivre", "B\195\162tonnet"},
	{"B\195\162tonnet runique en argent", "runiq argent", "B\195\162tonnet"},
	{"B\195\162tonnet runique en or", "runiq or", "B\195\162tonnet"},
	{"B\195\162tonnet runique en vrai-argent", "runiq v-argent", "B\195\162tonnet"},
	{"B\195\162tonnet runique en arcanite", "runiq arcanite", "B\195\162tonnet"},
	{"Baguette magique inf\195\169rieure", "(Arc)dps:05.7", "Baguette"},
	{"Baguette magique sup\195\169rieure", "(Arc)dps:11.9", "Baguette"},
	{"Baguette mystique inf\195\169rieure", "(Arc)dps:23.1", "Baguette"},
	{"Baguette mystique sup\195\169rieure", "(Arc)dps:27.2", "Baguette"},
	{"Huile de mana mineure", "Mana +4", "Huile"},
	{"Huile de mana inférieure", "Mana +8", "Huile"},
	{"Huile de mana brillante", "Mana +12", "Huile"},		--Brilliant Mana Oil 
	{"Huile de sorcier mineure", "Spl Dmg +8", "Huile"},
	{"Huile de sorcier inférieure", "Spl Dmg +16", "Huile"},
	{"Huile de sorcier", "Spl Dmg +24", "Huile"},
	{"Huile de sorcier brillante", "Spl Dmg +36", "Huile"},		--Brilliant Oil 
    };



    ["BONUS_TYPES"] = {
	{"Protection";							"Armure";					{[1] = {"inf\195\169rieur"; 30}};					"Bouclier"};
	{"Agilit\195\169";						"Agi";						{[1] = {"None"; 15}};								"Arme"};
	{"Agilit\195\169";						"Agi";						{[1] = {"None"; 25}};								"Arme 2M"};
	{"Agilit\195\169";						"Agi";						EnchantingSell_Quality["Quality_OneCarac"];			nil};
	{"Agilit\195\169";						"Agi";						EnchantingSell_Quality["Quality_Agility_Gloves"];					"Gants"};
	{"Force";								"Force";					{[1] = {"None"; 15}};								"Arme"};
	{"Intelligence";						"Int";						EnchantingSell_Quality["Quality_Int_Weapon"];		"Arme"};
	{"Esprit";								"Esprit";					EnchantingSell_Quality["Quality_Spirit_Weapon"];	"Arme"};
	{"Intelligence";						"Int";						EnchantingSell_Quality["Quality_Int_Bracers"];			nil};
	{"Esprit";								"Esprit";					EnchantingSell_Quality["Quality_OneCarac"];			nil};
	{"Endurance";							"End";						EnchantingSell_Quality["Quality_OneCarac"];			nil};
	{"Force";								"Force";					EnchantingSell_Quality["Quality_OneCarac"];			nil};
	{"Vie";									"Vie";						EnchantingSell_Quality["Quality_Life"];				nil};
	{"Sant\195\169";						"Vie";						EnchantingSell_Quality["Quality_Life"];				nil};
	{"Mana";								"Mana";						EnchantingSell_Quality["Quality_Mana"];				nil};
	{"Caract\195\169ristiques";				"Carac";					EnchantingSell_Quality["Quality_Caract"];			nil};
	{"Caract.";								"Carac";					EnchantingSell_Quality["Quality_Caract"];			nil};
	{"D\195\169fense";						"Armure";					EnchantingSell_Quality["Quality_Armure"];			nil};
	{"Protection";							"Armure";					EnchantingSell_Quality["Quality_Armure"];			nil};
	{"D\195\169viation";					"D\195\169fence";			EnchantingSell_Quality["Quality_Defence"];			nil};
	{"R\195\169sistance \195\160 l'ombre";	"R\195\169si omb";			{[1] = {"inf."; 10}};								nil};
	{"R\195\169sistance au feu";			"R\195\169si  feu";			EnchantingSell_Quality["Quality_ResistFeu"];		nil};
	{"R\195\169sistance";					"R\195\169si";				EnchantingSell_Quality["Quality_AllResist"];		nil};
	{"Frappe";								"D\195\169gats";			EnchantingSell_Quality["Quality_Degat1M"];			nil};
	{"Impact";								"D\195\169gats";			EnchantingSell_Quality["Quality_Degat2M"];			nil};
	{"impact";								"D\195\169gats";			EnchantingSell_Quality["Quality_Degat2M"];			nil};
	{"Tueur de d\195\169mons";				"T Demons";					nil;												nil};
	{"Tueur de b\195\170te";				"T B\195\170te";			EnchantingSell_Quality["Quality_Tueur"];			nil};
	{"Tueur d'\195\169l\195\169mentaire";	"T El\195\169ment";			EnchantingSell_Quality["Quality_Tueur"];			nil};
	{"Blocage";								"Blocage";					{[1] = {"inf\195\169rieur"; "2%"}};					nil};
	{"D\195\169pe\195\167age";				"D\195\169pe\195\167age";	{[1] = {"None"; 5}};								nil};
	{"Absorption";							"";							EnchantingSell_Quality["Quality_Absorption"];		nil};
	{"Herboristerie";						"Herbo";					EnchantingSell_Quality["Quality_Metier"];			nil};
	{"Minage";								"Minage";					EnchantingSell_Quality["Quality_Metier"];			nil};
	{"P\195\170che";						"P\195\170che";				EnchantingSell_Quality["Quality_Metier"];			nil};
	{"H\195\162te";							"Vit d'atta";				{[1] = {"mineur"; "1%"}};							nil};
    };

} end)
