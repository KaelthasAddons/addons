﻿-- Local stuff

if (GetLocale() == "frFR") then
        XPERL_RAID_MONITOR_TITLE	= "Moniteur de lancement de sort |c00A04040(BETA)|r"
	XPERL_RAID_MONITOR_TOTALS	= "Bascule l'affichage des totaux et des statistiques"

	XPERL_RAID_MONITOR_STATS_RAID_MANA	= "Mana du raid"
	XPERL_RAID_MONITOR_STATS_HIGH_MANA	= "Haut en mana"
	XPERL_RAID_MONITOR_STATS_LOW_MANA	= "Bas en mana"
	XPERL_RAID_MONITOR_STATS_RAID_HEALTH	= "Vie du raid"

	XPERL_MONITOR_LEFTCLICK			= "|c00FFFFFFClique gauche|r pour %s"
	XPERL_MONITOR_RIGHTCLICK		= "|c00FFFFFFClique droit|r pour %s"
	XPERL_MONITOR_CLICKCAST			= "lancement de sort |c0000FF00%s|r"
	XPERL_MONITOR_CLICKTARGET		= "|c00FFFF80cible|r"

	XPERL_MONITOR_INNERVATE		= "Innervation"
	XPERL_MONITOR_MANATIDE		= "Totem de Vague de mana"
end
