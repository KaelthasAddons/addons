local L = LibStub("AceLocale-3.0"):NewLocale("BT_BlackTemple", "enUS", true)
if not L then return end

--infos
L["Module resetted"] = "Module resetted" --dont change this line!

L["info"] = "|cff91069ETactics by|r rpguides\n|cff91069EImages by|r Vonswan, rpguides\n|cff91069EModule by|r Sorontur\n\n|cffC0C0C0[http://www.kdh-wow.de]\n[http://www.rpguides.de]|r"

--add here localized tactic texts

L["tactic Naj'entus"] = [[

not yet available

]]

L["tactic Supremus"] =  [[

not yet available

]]

L["tactic Akama"] = [[

not yet available

]]

L["tactic Gorefiend"] = [[

not yet available

]]

L["tactic Bloodboil"]  = [[

not yet available

]]

L["tactic Souls"] = [[

not yet available

]]

L["tactic Mother Shahraz"] = [[

not yet available

]]

L["tactic Illidari Council"] = [[

not yet available

]]

L["tactic Illidan"] = [[

not yet available

]]

--texts for trash

L["trash Naj'entus"] = [[

not yet available

]]

L["trash Supremus"] = [[

not yet available

]]

L["trash Akama"] = [[

not yet available

]]

L["trash Gorefiend"] = [[

not yet available

]]

L["trash Bloodboil"] = [[

not yet available

]]

L["trash Souls"] = [[

not yet available

]]

L["trash Mother Shahraz"]  = [[

not yet available

]]

L["trash Illidari Council"] = [[

not yet available

]]



--ra text messages every line separated by \n
L["ra Naj'entus"] = ""
L["ra Supremus"] = ""
L["ra Akama"] = ""
L["ra Gorefiend"] = ""
L["ra Bloodboil"] = ""
L["ra Souls"] = ""
L["ra Mother Shahraz"] = ""
L["ra Illidari Council"] = ""
L["ra Illidan"] = ""

--button captions
L["Channeler"] = true
L["Akama"] = true
L["die zone"] = true
L["Bloodboil gr1"] = "group 1"
L["Bloodboil gr2"] = "group 2"
L["Bloodboil gr3"] = "group 3"
L["shadowzone"] = ""
L["healer range"] = "healer & range"
L["Blades of Azzinoth"] = true
L["Flames of Azzinoth"] = true
L["Warlock Tank"] = true
L["Shadow Demon"] = true

--fontstrings
L["Phase1&2"] = "Phase 1 & 2"
L["Phase1"] = true
L["Phase2"] = true
L["Phase3&5"] = "Phase 3 & 5"
L["Phase4"] = true