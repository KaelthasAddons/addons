﻿local L = LibStub("AceLocale-3.0"):NewLocale("BT_BlackTemple", "deDE")
if not L then return end

--Umlaute: ö:\195\182 ü:\195\188 ä:\195\164 Ö:\195\150 Ü:\195\156 Ä: \195\132

-- infos
L["Module resetted"] = "Modul zur\195\188ckgesetzt" --diese zeile nicht verändern!

L["info"] = "|cff91069ETactics by|r rpguides\n|cff91069EImages by|r Vonswan, rpguides\n|cff91069EModule by|r Sorontur\n\n|cffC0C0C0[http://www.kdh-wow.de]\n[http://www.rpguides.de]|r"
--füge hier die taktiktexte lokalisiert ein:

L["tactic Naj'entus"] =  [[
|cffff0000Gruppenzusammenstellung
----------------------------------|r

Die Konfrontation erfordert lediglich einen einzigen Tank, dafür aber um so mehr Schadensverursacher. Auf Grund des Nadelstachels sind Nahkämpfer hier mal wieder nicht so geeignet. Es sollten nicht mehr als vier oder fünf sein. Da sie schon in dieser Anzahl viel Heilung benötigen.

    * 1 Tank
    * 7 - 9 Heiler
    * 15 - 17 Schadensverursacher (4 Nahkämpfer, Rest Fernkämpfer)

|cffff0000Stärkungszauber, Tränke und andere Ausrüstung
-------------------------------------------------------------|r

Für diesen Kampf benötigt jeder Spieler mehr als 8.500 Trefferpunkte, 10.000 sind gewissermaßen ein Muss und für die ersten Versuche sind 11.000 - 12.000 zu empfehlen. Dem entsprechend sollte jeder Spieler Buffs benutzen, die ihn an diese Schwelle bringen. Darüber hinaus sind natürlich die entsprechenden Schaden/Heilungsverstärkenden Buffs von Vorteil.
Alle Spieler sollten für jeden Versuch vier Erhebliche Frostschutztränke oder Große Frostschutztränke bereithalten.

|cffff0000Fähigkeiten
---------------|r

Trefferpunkte: 3.800.000
Nahkampfschaden: 5.000 (gegen Plattenträger)

|cff5929C7Durchbohrender Stachel|r (Needle Spine)
Feuert einen Stachel auf einen zufällig ausgewählten Spieler, der 2.890 bis 3.910 Körperschaden anrichtet. Dieser Stachel verursacht zudem 2.280 bis 2.520 Frostschaden bei allen Spieler innerhalb von sechs Metern um den getroffenen.

|cff5929C7Aufspießender Stachel|r (Impaling Spine)
Naj'entus feuert einen riesigen Stachel auf ein zufällig ausgewähltes Ziel, dieser Verursacht 4.513 bis 4.987 Körperschaden und lähmt das Ziel. Der Spieler bleibt so lange am Boden liegen, bis ein anderer Spieler den Stachel - sieht aus wie Naj'entus Arm - aus seinem Rücken zieht (Rechtsklick auf den Stachel). Während der Spieler aufgespießt ist, erleidet er pro Tick - alle drei Sekunden - 2.750 Körperschaden. Diese Fähigkeit kann Naj'entus nicht auf den Main Tank anwenden.

|cff5929C7Gezeitenschild|r (Tidal Shield)
Naj'entus errichtet alle 60 Sekunden diesen Schild, der aussieht wie das Wassergrab von Hydross. Wenn der Schild hochgefahren ist, ist er immun gegen jede Art von Angriffen und regeneriert alle zwei Sekunden ein Prozent seiner Trefferpunkte. Der Schild kann nur durch den aufgesammelten Stachel zerstört werden. In dem Augenblick, in dem der Schild fällt, erleidet jeder Spieler Reichweitenunabhängig 8.500 Frostschaden durch die Gezeitenexplosion.

|cff5929C7Wutanfall|r (Enrage)
Wie so viele Bosse verfällt auch Naj'entus nach acht Minuten in einen Wutanfall und tötet somit jeden Spieler mit einem einzigen Angriff.

|cffff0000Taktik
--------|r

|cFFDBD533Positionierung|r
Alle Spieler verteilen sich mit mindestens sieben Metern Abstand zueinander im Raum. Hierbei sollte darauf geachtet werden, dass sich in jeder Gruppe möglichst ein Heiler befindet und die Gruppenmitglieder in einem Block stehen. So ist zum einen gewährleistet, dass die Gruppenheilungen alle erreichen und zum anderen weiß jeder wer in seiner Gruppe/Nähe ist, um so schneller auf einen Aufspießenden Stachel bei einem Kameraden zu reagieren. Die vier Nahkämpfer sollten bei der Aufstellung an Naj'entus ebenfalls auf die Abstände achten und sich daher im Kreis um ihn verteilen.

Sobald alle Spieler an Position sind, lockt ein Jäger den Obersten Kriegsfürsten Naj'entus zum Tank in der Mitte des Raumes. Wo dieser einige Sekunden lang Hass aufbaut, bevor die Schadensverursacher mit ihren Angriffen beginnen.

Während des gesamten Kampfes setzt Naj'entus alle 20 Sekunden eine Fähigkeit ein:

    * 20. Sekunde: Aufspießender Stachel
    * 40. Sekunde: Aufspießender Stachel
    * 60. Sekunde: Gezeitenschild

Demnach muss jede 20. und 40. Sekunde ein Spieler zu dem vom aufspießenden Stachel getroffenen Spieler laufen und den Stachel aufnehmen (Rechtsklick) und diesen in der 60. Sekunde auf Naj'entus werfen. Jeder kann bis zu fünf Stachel in seinem Inventar haben.

Das Problem des Kampfes entsteht hierbei lediglich durch den angerichteten Schaden, der rechtzeitig von den Heilern kompensiert werden muss. Das ist besonders nach dem Gezeitenschild ein Problem. Da durch die Zerstörung jeder Spieler 8.500 Punkte Frostschaden erleidet und Naj'entus 15 Sekunden später schon wieder mit seinen Nadelstachel Angriffen anfängt. Damit die Heiler nicht vollkommen überlastet werden, sollte jeder Spieler in der 60. Sekunde einen seiner Frostschutztränke zu sich nehmen. Selbstverständlich ist dieses maximal alle zwei Minuten - also nur zu jedem zweiten Gezeitenschild - möglich.
]]

L["tactic Supremus"] =  [[
|cffff0000Gruppenzusammenstellung
----------------------------------|r

Besondere Anforderungen stellt der Kampf nicht. Benötigt werden auf alle Fälle zwei Tanks (Druiden oder Krieger) und ungefähr sieben Heiler. Der Rest ist relativ offen. Da der Raserei-Timer bei 14 Minuten liegt, können auch ein oder zwei Heiler mehr mitgenommen werden. Fernkämpfer sind in dem Kampf mal wieder leicht bevorteilt, wobei der Kampf auch mit einer Großzahl von Nahkämpfern machbar ist.
Feuermagier sind für den Kampf jedoch ungeeignet, da Supremus einen sehr hohen Feuerwiderstand hat und ihre Zauber somit nur leichten Schaden anrichten. Selbiges gilt natürlich für die Feuerzauber der Hexenmeister.

    * 2 Tanks
    * 7 Heiler
    * 14 Schadensverursacher

|cffff0000Stärkungszauber, Tränke und andere Ausrüstung
-------------------------------------------------------------|r

Die Tanks sollten selbstverständlich so viel Gesundheit wie möglich haben, um die fünfstelligen Schadensspitzen kompensieren zu können. Davon abgesehen sind für diesen Kampf wirklich wenig Buffs erforderlich. Der 14 Minuten Raserei Timer wird vermutlich auch von einer nicht gebufften Gruppe nur schwer erreicht.

|cffff0000Fähigkeiten
---------------|r

Trefferpunkte: 4.500.000
Nahkampfschaden: 7.000 Körperschaden

Der Kampf ist in zwei Phasen unterteilt. Die sich ungefähr alle 60 Sekunden abwechseln und in denen Supremus teilweise unterschiedliche Fähigkeiten besitzt. Am Ende von Phase zwei findet ein Hasslisten-Reset statt.

|cff5929C7Glühende Flamme|r (Molten Flame) |cff00ff00[Phase 1 & 2]|r
Ein bläulich leuchtende Flammenwand, die sich in Richtung eines zufällig gewählten Spielers auszubreiten scheint. Spieler die in ihrem Einflussbereich stehen erleiden jede Sekunde zwischen 3.325 und 3.675 Feuerschaden. Die Fähigkeit hat eine Abklingzeit von 20 Sekunden.

|cff5929C7Hasserfüllter Stoß|r (Hurtful Strike) |cff00ff00[Phase 1]|r
Ein starker Nahkampfangriff, welcher auf den nächst höchsten Spieler mit den meisten Trefferpunkten im Nahkampfbereich neben dem Tank zielt. Befindet sich gar kein Spieler außer dem Tank im Nahkampfbereich, erleidet dieser zusätzlich den Hasserfüllten Stoß. Der Schlag richtet bei einem Krieger mit 17.000 Rüstung ca. 7.000 - 8.000 Schaden an und tötet Schurken sowie Stoffträger augenblicklich.

|cff5929C7Vulkangeysir|r (Volcanic Geyser) |cff00ff00[Phase 2]|r
Während seiner Verfolgungsjagd in Phase zwei wirkt Supremus immer wieder Vulkanausbruch, wodurch ein Vulkangeysir entsteht, der in einem 15 Meter Radius um sich bläuliche Gesteinsbrocken verschießt, die auf dem Boden angelangt 4.163 - 4.837 Feuerschaden anrichten.

|cff5929C7Blick|r (Gaze) |cff00ff00[Phase 2]|r
Diese Fähigkeit erinnert stark an Thaladred und hält die gesamte Phase an. Supremus verfolgt dabei für zehn Sekunden lang einen zufällig ausgewählten Spieler. Er bewegt sich währenddessen mit 90% der normalen Bewegungsgeschwindigkeit fort. Setzt aber von Zeit zu Zeit seinen Sturmangriff ein. Nach Ablauf der zehn Sekunden wechselt er auf einen anderen Spieler.

|cff5929C7Glühender Hieb|r (Molten Punch) |cff00ff00[Phase 2]|r
Spieler, die Supremus durch seinen Blick verfolgt, werden oftmals mit seinem Glühenden Hieb von ihm weggeschleudert, wenn sie innerhalb einer 40 Meter Reichweite sind. Der Rückstoß verursacht 5.250 Körperschaden

|cff5929C7Sturmangriff|r (Charge)|cff00ff00[Phase 2]|r
Ähnlich dem Krieger Sturmangriff nutzt Supremus diese Fähigkeit um sich seinem Ziel zu nähern. Oft folgt darauf ein Glühender Hieb.

|cff5929C7Raserei|r (Enrage)
Angeblich verfällt Supremus nach 14 Minuten in Raserei. Dieser Zeitraum ist jedoch so lang, dass dieser wohl nicht erreicht wird.

|cffff0000Taktik
--------|r

|cff00ff00Phase 1|r

Die erste Phase läuft ähnlich ab wie der Kampf gegen Gruul.

|cFFDBD533Positionierung|r
Der Tank läuft oder reitet (das ist auf dem gesamten Hof möglich) zu Supremus und bindet ihn an seiner Position. Als nächstes läuft der zweite Tank heran und beginnt ebenfalls Hass aufzubauen. Andere Nahkämpfer müssen warten bis der zweite Tank an Position ist. Andernfalls würden sie den ersten Hasserfüllten Stoß erleiden und daran sterben. Sie sollten sich im Nahkampfbereich möglichst gut verteilen, damit die Glühende Flamme nicht alle auf einmal erreicht. Die Fernkämpfer stellen sich daraufhin im Halbkreis um Supremus auf und beginnen mit ihren Angriffen. Die Jäger sollten wie üblich die beiden Tanks mit Irreführung beim Hassaufbau unterstützen.

|cFFDBD533Kampfverlauf|r
Der Kampfverlauf ist relativ unspektakulär. Abgesehen von den Glühenden Flammen gibt es hier nichts zu beachten. Diese erwecken jedoch den Eindruck als würden sie beim Ausbreiten einem bestimmten Spieler folgen. Nehmt ihm Zweifelsfall also mehr als einen Schritt Abstand.

Ansonsten müsst ihr lediglich auf eure Position in der Hassliste achten und dabei so viel Schaden wie möglich anrichten.

Ungefähr fünf Sekunden vor Ende der Phase sollten sich alle Nahkämpfer (abgesehen von den Tanks) von Supremus entfernen.

|cFF1DDD2FHeiler|r:
Ein einziger schmetternder Schlag wird den Tank schnell unter 50% seiner Trefferpunkte bringen. Versucht seine Gesundheit daher immer am Maximum zu halten.

|cff00ff00Phase 2|r

Diese Phase könnte man als Thaladred 2.0 bezeichnen. Supremus verhalten ist ähnlich. Ihr müsst aber zusätzlich den entstehenden Vulkangeysiren ausweichen.

|cFFDBD533Positionierung|r
Die gesamte Gruppe muss in Bewegung bleiben und sollte dabei versuchen Supremus in eine einheitliche Richtung zu locken. Wohin ist dabei euch überlassen. Ihr könnt in Schleifen um die Hindernisse, oder den Hof auf und ab laufen. Letzteres hat sich bei uns jedoch als effektiver erwiesen. Versucht bei jeder Phase zwei Supremus ans andere Ende des Hofes zu locken. Damit die Vulkane und Flammen hinter euch liegen und euch nicht in Phase eins behindern. Achtet außerdem darauf, dass kein Hindernis direkt vor euch liegt. Sollte Supremus mal näher an euch heran kommen, seinen Glühender Hieb einsetzen und euch dabei gegen das Hindernis schleudern, wird er euch mit dem nächsten Schlag sicherlich töten.

|cFFDBD533Kampfverlauf|r
Supremus Blick ist das Einzige, was ihn in dieser Phase auf euch ziehen kann. Macht so viel Schaden wie ihr wollt, setzt Dots etc. Aber achtet darauf, dass sie vor Ende der Phase ausgelaufen sind!

Über die gesamte Phase hinweg wird Supremus sowohl seine Glühenden Flammen weiter einsetzen, als auch Vulkangeysire bei Spielern erscheinen lassen. Weicht diesen sofort aus. Das Spielerfeld wird sich in der Phase wahrscheinlich leicht zerstreuen und der nächste Heiler kann somit leicht außer Reichweite sein. Verbindet euch selbstständig.

Am Ende der Phase sollten die beiden Tanks sich bereits wieder auf Supremus zu bewegen, um in Phase eins die ersten Schläge ausführen zu können. Mit Beginn der nächsten ersten Phase wird die Hassliste komplett gelöscht. Die Schadensverursacher sollten den Tanks also zunächst wieder ein paar Sekunden zum Hassaufbau gewähren.

|cFF7D923CJäger|r:
Ihr könnt in dieser Phase eure Begleiter auf Supremus hetzen. Sie werden vom Blick nicht ausgewählt. Sollte Supremus auf seiner Route jedoch durch Geysire oder Flammen laufen, werden sie sicherlich am Schaden erlittenen sterben.

|cFF1DDD2FHeiler|r:
Versucht die Tanks am Ende der Phase bei voller Gesundheit zu haben, damit die erste Aktion, auf die Supremus in der nächsten ersten Phase reagiert, nicht eure Heilung ist. Gebt den Tanks am Besten auch einen Schild und Gebet der Besserung mit. HoTs sollten erst wenige Sekunden nach Beginn der ersten Phase wieder gewirkt werden.

|cFFDEDC30Nahkämpfer|r:
Ihr solltet in Phase zwei gänzlich auf Schaden verzichten. Denn beim Blickwechsel werdet ihr 100%ig nicht mehr aus seiner Schlagreichweite kommen.
]]

L["tactic Akama"] = [[
|cffff0000Gruppenzusammenstellung
----------------------------------|r

Der Kampf erfordert drei Tanks, eventuell kann ein vierter hilfreich sein, falls die erste Phase zu lange dauert und sich zu viele Verteidiger ansammeln. Jeder Tank benötigt einen Heiler und der bzw. die Tanks der Verteidiger wahrscheinlich drei. Ein oder zwei weitere für die Gruppe können ebenfalls nicht schaden. Die restlichen Plätze sollten mit einer Mischung aus Nah- und Fernkämpfern aufgefüllt werden. Für diese sind zwei bis vier Magier zu empfehlen, damit die Wellen besser kontrolliert werden können.

    * 3 -4 Tanks
    * 5 - 7 Heiler
    * 14 - 17 Schadensverursacher (mindestens 2 - 4 Magier)

|cffff0000Fähigkeiten
---------------|r

Dieser Kampf tobt zwischen Akama und Akamas Schemen. Sie nehmen also beide am Kampf teil und haben unterschiedliche Fähigkeiten. Akamas Schemen ist dabei der zu besiegende, während euch Akama selbst hilft.

Ähnlich der Nefarian Schlacht aus dem Pechschwingenhort, stürmen sobald der Kampf begonnen hat von beiden Seiteneingängen alle 35 - 40 Sekunden je eine Gruppe bestehend aus einem Schurken, Geistbinder und Elementarist der Aschenzungen in den Raum und versucht zu Akamas Schemen (dem Bösen) zu gelangen. Zusätzlich kommt alle 15 Sekunden ein Verteidiger der Aschenzungen aus einem der beiden Gänge und läuft zu Akama (dem Guten). Sporadisch erscheinen außerdem Zauberhexer, welche die Kanalisierer bei Akamas Schemen ablösen. Diese Mobs haben folgende Fähigkeiten:

|cFF4DFFFDAkamas Schemen (der Böse)|r
Trefferpunkte: 1.000.000
Nahkampfschaden: 8.000 - 12.000 (25.000 schmetternd)

Akamas Schemen besitzt keine besonderen Fähigkeiten.

|cFF4DFFFDAkama (der Gute)|r
Nahkampfschaden: 5.000 - 7.000 (8.500 schmetternd)

|cff5929C7Kettenblitzschlag|r
Akama wirkt diesen gegen seinen Schemen, sobald er aus der Verbannung kommt. Der Kettenblitzschlag springt auf bis zu vier Verteidiger über und richtet an diesen bis zu 4.000 Naturschaden an.

|cff5929C7Zerstörerisches Gift|r
Ein stapelbarer Debuff, der sämtlichen Schaden auf Akamas Schemen um 5% erhöht.

|cFF4DFFFDKanalisierer der Aschenzungen|r (Ashtongue Channeler)
Trefferpunkte: 100.000
Sechs dieser Kanalisierer umringen Akamas Schemen und halten ihn verbannt. So lange die Kanalisierer leben bleibt der Schemen verbannt und unverwundbar. Die Kanalisierer wehren sich nicht gegen Angriffe. Sie vollführen lediglich ihre Verbannungszauber bis sie tot sind.

|cFF4DFFFDZauberhexer der Aschenzungen|r (Ashtongue Sorcerer)
Trefferpunkte: 100.000
Mengenkontrolle: Immun gegen Verwandlung, Betäubung etc.
Mit den Angriffswellen kommen diese Zauberhexer in den Raum. Sie nehmen den Platz ihrer toten Kanalisierer-Kameraden ein und versuchen Akamas Schemen verbannt zu halten.

|cFF4DFFFDVerteidiger der Aschenzungen|r (Ashtongue Defender)
Trefferpunkte: 79.000
Mengenkontrolle: Anfällig für Verwandlung, Furcht, Betäubung, etc.
Verteidiger versuchen augenblicklich zu Akama zu gelangen und diesen anzugreifen.

|cff5929C7Entkräftender Stoß|r (Debilitating Strike):
Ihr wohl mächtigster Angriff richtet 1.200 - 2.400 Körperschaden an und hinterlässt einen Debuff, der jeglichen angerichteten Schaden für fünf Sekunden um 75% reduziert

|cff5929C7Heldenhafter Stoß|r (Heroic Strike):
In starker Nakampfangriff, der an einem Tank 3.600 - 3.800 Körperschaden anrichtet.

|cff5929C7Schildhieb|r (Shield Bash):
Schlägt das Ziel mit dem Schild, verursacht dabei 1.200 Körperschaden und unterbricht den zur Zeit wirkenden Zauber für drei Sekunden.

|cFF4DFFFDSchurke der Aschenzungen|r (Ashtongue Rogue)
Trefferpunkte: 28.000
Mengenkontrolle: Anfällig für Verwandlung, Furcht, Betäubung, etc.

|cff5929C7Entkräftigendes Gift|r (Debilitating Poison):
Ein acht Sekunden anhaltendes Gift, welches alle zwei Sekunden 1.422 Naturschaden verursacht und die Angriffs- sowie Zaubergeschwindigkeit um 50% reduziert.

|cFF4DFFFDGeistbinder der Aschenzungen|r (Ashtongue Spiritbinder)
Trefferpunkte: 23.000
Mengenkontrolle: Anfällig für Verwandlung, Furcht, Betäubung, etc.

|cff5929C7Geistheilen|r (Spirit Mend):
Ein HoT, der einen Aschenzungenverbündeten zehn Sekunden lang für 2.500 alle zwei Sekunden heilt.

|cff5929C7Kettenheilung|r (Chain Heal):
Wie die Kettenheilung eines Schamanen heilt auch diese bis zu fünf Aschenzungen für bis zu 8.000 Trefferpunkte.

|cFF4DFFFDElementarist der Aschenzungen|r (Ashtongue Elementalist)
Trefferpunkte: 23.000
Mengenkontrolle: Anfällig für Verwandlung, Furcht, Betäubung, etc.

|cff5929C7Blitzschlag|r (Lightning Strike):
Wie der Schamanenzauber richtet er an einem einzelnen Ziel zwischen 2.050 - 2.450 Naturschaden an.

|cff5929C7Feuerregen|r (Rain of Fire):
Ist dem Hexenmeisterzauber in Größe und Aussehen ähnlich. Der Flächenzauber verursacht über acht Sekunden alle zwei Sekunden 3238-3762 Feuerschaden

|cffff0000Taktik
--------|r

|cFFDBD533Positionierung|r
Der Kampf beginnt sobald ihr der am Eingang stehenden, verstohlenen Akama ansprecht. D.h. ihr habt genügend Zeit um euch im Raum aufzustellen, bevor jemand Akama zum Kampfbeginn anspricht. Das Ziel des Kampfes besteht darin Akamas Schemen zu töten, bevor dieser oder seine Verteidiger Akama töten können. Akamas Schemen wird jedoch durch die Kanalisierer gebannt.

Sobald der Kampf beginnt kommen alle 35 Sekunden Aschenzungenangriffswellen aus den beiden Seiteneingängen und versuchen zu Akamas Schemen zu laufen. Außerdem kommt alle 15 Sekunden ein Verteidiger aus einer der beiden Türen (aus welcher ist Zufall) und greift Akama an.

Um diesen drei Gegnergruppen entgegenzuwirken, muss sich eure Schlachtgruppe ebenfalls in drei bzw. vier Gruppen aufteilen:

|cFFDBD533* Gruppe 1 & 2 - Wellen:|r
Auf jeder Seite muss ein Tank, ein Heiler und drei Schadensverursacher stehen. Die Gruppen sollten aus mindestens einem Magier (besser zwei) einem Jäger und Schamanen bestehen. Der Tank stellt sich knapp vor der Tür auf, während die Schadensverursacher und der Heiler vor der jeweiligen Säule der Seite Stellung beziehen.
|cFFDBD533* Gruppe 3 - Verteidiger:|r
Quasi der Main Tank dieses Kampfes (am besten ein Druide) und seine drei Heiler. Der Main Tank stellt sich vor Akama auf und wartet auf die nahenden Verteidiger. Die Heiler verteilen sich vor den Säulen, bei den Heilern von Gruppe eins.
|cFFDBD533* Gruppe 4 - Kanalisierer:|r
Alle verbleibenden Schadensverursacher stellen sich zu den Kanalisierern und bekämpfen diese. Falls die Schadensverursacher der Wellengruppen nicht hinterherkommen, kann pro Gruppe ein weiterer Spieler zu den Wellengruppen überstellt werden. Für Gruppe vier können am Besten Nahkämpfer und Fernkämpfer mit Dots (Gebrechenshexer und Schattenpriester) verwendet werden.

|cFFDBD533Kampfverlauf|r
Gruppe 1 & 2:
Kurz nachdem Akama angesprochen wurde, erscheinen in den beiden Gängen die ersten Wellen. Gruppe eins und zwei kümmern sich auf ihrer Seite jeweils darum sie zu vernichten. Die Priorität liegt auf den Elementaristen, anschließend den Geistesbindern und zuletzt den Schurken der Aschenzungen. Schurken (und Elementaristen) sollten möglichst zunächst verwandelt werden. Währenddessen bindet der Tank den Geisterbinder (und Elementaristen) an sich und die Schadensverursacher eröffnen das Feuer auf diese.

Gruppe 3:
Der Main Tank wartet vor Akama auf den ersten Verteidiger, sobald sich dieser nähert bindet er ihn an sich und hält ihn für den Rest des Kampfes auf sich. Er verfährt mit allen neuen Verteidigern genauso. Es werden sich ungefähr fünf bis sechs Verteidiger ansammeln, bis Akamas Schemen frei kommt. Jeder Verteidiger schlägt für 1.700 - 2.000 Körperschaden zu. Somit muss der Main Tank nach ein bis zwei Minuten ununterbrochen geheilt werden.

Gruppe 4:
Die Hexenmeister und Schattenspriester legen sich eine Rotation fest, in der sie alle Kanalisierer und nachrückenden Zauberhexer mit Dots versehen und zwischendurch auf das aktuelle Ziel der Nahkämpfer feuern. Die Nahkämpfer vernichten im Uhrzeigersinn einen Kanalisierer und anschließend Zauberhexer nach dem anderen.

Alle Gruppen setzen diese Rotationen fort bis Akamas Schemen aus der Verbannung kommt.

|cFFDBD533Verbannung aufgehoben|r
Nach drei bis vier Minuten sollten alle Kanalisierer und Zauberhexer tot sein und Akamas Schemen aus der Verbannung kommen. Er wird sofort auf Akama zu laufen und diesen Angreifen. Verbliebene Mobs mit 25% oder weniger Trefferpunkten sollten noch schnell getötet werden, alle anderen werden fortan in der Verwandlung oder unter Furcht gehalten, während alle Spieler Akama angreifen.

Haltet für diese Phase alle Fähigkeiten mit langen Abklingzeiten bereit und setzt sie jetzt ein! Akama wird euch mit seinem Zerstörerischen Gift helfen seinen Schemen zu Fall zu bringen. Aber den Schaden müsst noch immer ihr machen. In dieser Phase gibt es fasst nichts mehr zu heilen, daher sollten auch alle Heiler versuchen Akamas Schemen zu stoppen.

|cFF7D923CJäger|r:
Legt vor den Seiteneingängen Frostfallen ab, um die hereinkommenden Mobs zu verlangsamen.

|cFF5D2B17Krieger|r:
Benutzt Kniesehne und durchdringendes Geheul um die Geisterbinder und Elementaristen am Weglaufen zu hindern.

|cFF03D7DFMagier|r:
Verwandelt primär die Schurken und wenn genug von euch da sind, dann kümmert euch auch noch um die Elementaristen. Verwendet euren Feuerzauberschutz, um den Feuerschaden des Regens zu reduzieren.

|cFF0313DFSchamane|r:
Wenn ihr in Gruppe eins oder zwei seit, dann stellt Verlangsamungstotems an den Eingängen auf, um die Aschenzungen am Vordringen zu hindern.

|cFFDEDC30Schurke|r:
Ihr könnt so viel Hass erzeugen wie ihr wollt! Die Kanalisierer werden euch niemals angreifen und einfach ununterbrochen versuchen Akamas Schemen zu
]]

L["tactic Gorefiend"] = [[
|cffff0000Gruppenzusammenstellung
----------------------------------|r

Der Kampf erfordert einen Tank und mehr sollten sich auch nicht in der Gruppe befinden. Wie schon bei Vaelastrasz im Pechschwingenhort, sterben die Spieler mit der Zeit automatisch und somit geht es nur darum möglichst schnell Schaden an Teron Blutschatten anzurichten. Entsprechend hoch muss die Anzahl der Schadensverursacher sein. Annähernd zehn Heiler sollte es aber dennoch geben, da der erlittene Schaden ebenfalls recht hoch ist und nicht abgeschätzt werden kann, welche Klasse zum Rachsüchtigen Geist wird.

    * 1 Tank
    * 8 - 9 Heiler
    * 15 - 16 Schadensverursacher

|cffff0000Stärkungszauber, Tränke und andere Ausrüstung
-------------------------------------------------------------|r

Schattenschutzkleidung ist für den Kampf zwar nicht erforderlich, aber Gebet des Schattenschutzes sollte auf alle Fälle gebuffed werden. Zudem helfen erhebliche Schattenschutztränke bzw. ein Kessel des erheblichen Schattenschutzes den Schaden zu minimieren und die Heiler zu entlasten. Darüber hinaus werden natürlich die Standard-Buffs (Elixiere zur Gesundheits-, Schadenserhöhung etc.) benötigt.

|cffff0000Fähigkeiten
---------------|r

Trefferpunkte: 4.900.000
Mana: 1.693.500
Nahkampfschaden: 7.100 - 9.500 (bei 17.000 Rüstung); 11.500 schmetternd

|cff5929C7Verdammnisblüte|r (Doom Blossom)
Eine dunkle Wolke erscheint über Teron Blutschattens Position und verschießt einen Schattenblitz mit 2.000-3.000 Schattenschaden gegen ein einzelnes Ziel. Von Spielern erzeugte Objekte werden davon ebenfalls erfasst.

|cff5929C7Zerschmetternde Schatten|r (Crushing Shadows)
Fügt fünf zufällig ausgewählten Spielern einen Debuff zu, der 15 Sekunden lang erlittenen Schattenschaden um 50% erhöht. Kann von Immunisierungseffekten aufgehoben werden.

|cff5929C7Verbrennen|r (Incinerate)
Fügt einem Spieler augenblicklich 2.800 - 3.300 Feuerschaden hinzu und hinterlässt einen Dot, der über drei Sekunden jede Sekunde ungefähr 3.000 Feuerschaden zufügt. Der Angriff kommt alle 20 - 30 Sekunden zum Einsatz. Der Dot kann entfernt werden.

|cff5929C7Schatten des Todes|r (Shadow of Death)
Teron Blutschatten fügt diesen Debuff alle 30 Sekunden einem zufällig ausgewählten Spieler zu. Dieses kann nicht den höchsten Spieler der Hassliste treffen. Nach Ablauf von 55 Sekunden stirbt der Spieler unweigerlich und wird für 60 Sekunden zu einem Rachsüchtigen Geist.

|cffff0000Taktik
--------|r

|cFFDBD533Monster-Übersicht|r

Rachsüchtiger Geist
Der durch den Schatten des Todes gestorbene Spieler verwandelt sich für 60 Sekunden in einen Rachsüchtigen Geist. In dieser Form bekommt er die folgenden Fähigkeiten, mit denen er die Skelettschöpfungen aufhalten kann:

Geisterketten (Spirit Chains)
Wie die Frostnova fesselt auch dieser Zauber alle Ziele in einem zwölf Meter Radius für fünf Sekunden. Der Zauber verursacht dabei 1.900 - 2.100 Frostschaden. Schaden an einem gefesseltem Ziel hebt den Fesselungseffekt auf.

Geisterlanze (Spirit Lance)
Ähnlich der Eislanze des Magiers verursacht dieser Zauber 6.175 - 6.825 Frostschaden und reduziert die Bewegungsgeschwindigkeit des Opfers für neun Sekunden um 30%. Der Effekt ist drei mal stapelbar. Der Zauber hat eine Reichweite von 30 Metern.

Geistersalve (Spirit Volley)
Dieser Flächenzauber fügt allen Zielen in einem zwölf Meter Radius um den Geist 9.900 - 12.100 Frostschaden zu. Die Abklingzeit des Zaubers beträgt 15 Sekunden.

Geisterstoß (Spirit Strike)
Ein ungefähr fünf Meter weit reichender Schlag, der dem Ziel 638 - 862 Frostschaden zufügt und seinen angerichteten Schaden für fünf Sekunden um 10% verringert.

Geisterschild (Spirit Shield)
Beschützt ein freundlich gesinntes Ziel mit einem Schild, welcher maximal 12.600 Schattenschaden absorbiert. Der Schild hält für 30 Sekunden oder bis der Schadenswert aufgebraucht ist. Er hat 90 Sekunden Abklingzeit und eine Reichweite von 40 Metern.

Skelettschöpfung (Shadowy Constructs)

Nahkampfschaden: 300 Körperschaden

Schattenhieb
Fügt dem im Nahkampf angegriffenen Spieler 2.100 - 2.500 Schattenschaden zu. Wird durch Zerschmetternde Schatten verstärkt.

Erschöpfen (Atrophy)
Dieser Debuff wird jedes mal zugefügt wenn eine Skelettschöpfung einen Spieler im Nahkampf trifft (300 Schattenschaden). Der Debuff verringert die Angriffs-/Zaubergeschwindigkeit um 5% und ist bis zu 10 mal stapelbar (50%).

|cFFDBD533Positionierung|r
Der Main Tank eröffnet den Kampf, in dem er auf Teron Blutschatten zuläuft und diesen am Fuße der Treppe seiner Plattform hält. Die anderen Schlachtzugteilnehmer folgen dem Main Tank und laufen an Teron Blutschatten vorbei in den hinteren Teil der Plattform, wo sie sich im Halbkreis aufstellen. Während des Einmarsches sollten selbstverständlich schon Gebet der Besserung, Machtwort: Schild und Hots auf dem Tank sein.

|cFFDBD533Kampfverlauf|r
Die Schadensverursacher sollten dem Main Tank noch ein oder zwei Sekunden Zeit geben, wenn sie in Position sind. Anschließend können sie mit den Angriffen beginnen.

Zehn Sekunden nach Kampfbeginn und anschließend alle 30 Sekunden erhält ein Spieler den "Schatten des Todes" Debuff von Teron Blutschatten. Dieser Spieler kann noch ca. 35 Sekunden seiner normalen Tätigkeit nachgehen und muss anschließend so weit wie möglich vom Gruppenstandort weglaufen. Denn mit seinem Tod bei Ablauf des Debuffs erscheinen um ihn herum vier Skelettschöpfungen, die nur in der resultierenden Geistform verletzt werden können. Da der Geist selbst nicht verletzt werden kann und auch keinen Hass erzeugt, sind die lebenden Spieler ihr einziges Ziel.

Die nicht vom Debuff betroffenen Schadensverursacher müssen lediglich während der gesamten Kampfzeit so viel Schaden wie möglich machen und dabei in der Hassliste nicht über den Main Tank rutschen.

Die Heiler hingegen haben im Kampfverlauf immer mehr Schaden zu kompensieren. Da die Verdammnisblüten zunehmen und ihr Schaden von Terons Zerschmetternden Schatten verstärkt wird. Darüber hinaus werden Spieler vom Verbrennen erfasst und müssen umgehend davon kuriert werden.

|cFFDBD533Rachsüchtiger Geist|r
Mit dem Einsetzen des Schatten des Todes habt ihr noch 55 Sekunden zu leben. Es ist lebenswichtig für die gesamte Schlachtgruppe, dass ihr nicht bei ihnen sterbt! Denn um euch herum werden vier Skelettschöpfungen erscheinen, welche die Spieler der Schlachtgruppe nicht verletzen können. Ihr könnt also noch ca. 35 Sekunden Schaden machen oder heilen und müsst die letzten 20 Sekunden nutzen, um zum anderen Ende des Raumes (Eingang) zu rennen.

Mit der Verwandlung in einen Rachsüchtigen Geist bekommt ihr eine zusätzliche Aktionsleiste. Hierbei handelt es sich um die Begleiter (Pet) Leiste. Sie sollte also selbstverständlich nicht durch Addons eines Drittanbieters deaktiviert sein. In dieser Leiste habt ihr die in der Übersicht aufgeführten Fähigkeiten, mit denen ihr jetzt die Skelttschöpfungen töten müsst. Als Geist seit ihr Immun gegen die Angriffe der Skelettschöpfungen und könnt auch keinen Hass aufbauen. Versucht die folgende Angriffsreihenfolge zur Beseitigung der Skelettschöpfungen einzuhalten:

    * Geistersalve:
      Der Zauber hat genau wie die Geisterketten 15 Sekunden Abklingzeit und macht am meisten Schaden. Sie muss daher als erstes eingesetzt werden.
    * Geisterketten:
      Sofort nach der Salve solltet ihr alle Skelettschöpfungen fesseln.
    * Geisterlanze:
      Rotiert mit Tab durch die Skelettschöpfungen und beschießt jede einzelne mit einer Geisterlanze, damit sie sich langsamer auf die Schlachtgruppe zu bewegen. Feuert so lange auf sie bis die Geistersalve wieder verfügbar ist und beginnt dann von Vorne mit den drei Schritten.

Mit etwas Übung solltet ihr alle Skelettschöpfungen nach 40 Sekunden getötet haben, was euch noch 20 Sekunden Spielraum gibt. Nutzt diese Zeit um einem Spieler das Schattenschadenabsorbierende Geisterschild zu geben und schlagt anschließend mit Geisterstoß auf Teron Blutschatten ein, um den Schadenerhöhungsbuff in die Höhe zu treiben. Sollten noch Skelettschöpfungen von anderen Spielern leben oder sogar in der Gruppe sein, könnt ihr auch die vernichten.

Alternativ zur Begleiterleiste könnt ihr euch vor dem Kampf Angriffsmakros für die Geisterfähigkeiten machen und diese auf eine eurer normalen Buttonleisten legen, um so bequemer angreifen zu können. Die erste Standard-Button-Leiste der normalen Benutzeroberfläche wird in dieser Form aber deaktivert! Benutzt also unbedingt eine zusätzlich einblendbare. Wenn ihr Buttonleisten-Addons wie Bongos o.ä. benutzt verschwindet die Leiste nicht!

Die Fähigkeiten lauten wie folgt:

/cast spirit volley 
/cast spirit chains 
/cast spirit lance

/wirken Geistersalve
/wirken Geisterketten
/wirken Geisterlanze


Zum Üben des Geisterkampfes könnt ihr diesen Teron Gorefiend Simulator benutzen. [http://www.variuse.de/feroxtgs2/]

|cFFE66C00Druide|r:
Zusammen mit den Schamanen seit ihr für das Überleben der Gruppe zuständig, die während des Kampfes ununterbrochen Schatten- und Feuerschaden bekommen. Haltet sie mit Hots am Leben.

|cFF861ABEHexenmeister|r:
Bereitet eure Seelensteine vor dem Kampf vor, verteilt sie aber erst wenn ein Spieler den Debuff erhält. Auf diese Weise kann er nach der Geisterphase wieder in den Kampf mit einsteigen.

|cFF7D923CJäger|r:
Ihr solltet den Main Tank wie üblich mit Irreführung beim Hassaufbau unterstützen. Legt im Kampfverlauf immer wieder Schlangenfallen in Terons Nähe ab, damit diese die Schattenblitze der Verdamnisblüten abfangen.

|cFFFF65F2Paladin|r:
Der Main Tank benötigt mindestens vier Heiler, wofür ihr und die Priester am Besten geeignet sind. Weiterhin sollte ein Paladin abgestellt werden, um primär das Verbrennen zu entfernen.

Priester:
Der Main Tank benötigt mindestens vier Heiler, wofür ihr und die Paladine am Besten geeignet sind.

|cFF0313DFSchamane|r:
Stellt so viele Totems wie möglich. Sie werden ebenfalls von den Schattenblitzen der Verdamnisblüten erfasst und ersparen euch (neben den Buffs) somit etwas Heilung. Haltet die Gruppen mit Kettenheilungen am Leben.

]]

L["tactic Bloodboil"]  = [[
|cffff0000Gruppenzusammenstellung
----------------------------------|r

Wie beim Leerhäscher sollten sich drei Tanks bei der Hass-Rotation abwechseln. Auf Grund des Desorientierens und des Rauswurfs sollten es nicht weniger als drei sein. Da der Kampf sehr Heilungsintensiv ist, empfehlen sich zwei Schattenpriester, die auf die Heilergruppen verteilt werden.

    * 3 Tanks
    * 8 - 9 Heiler
    * 13 - 14 Schadensverursacher

|cffff0000Stärkungszauber, Tränke und andere Ausrüstung
-------------------------------------------------------------|r

Es wird keine besondere Widerstandskleidung benötigt. Alle Spieler sollten jedoch versuchen möglichst viel Ausdauer-steigernde-Gegenstände zu tragen, damit sie Gurtoggs Angriffe, wenn sich in Phase zwei die Teufelswut bekommen, überleben können. Heiler sollten möglichst Manaregenerierende Elixiere/Fläschchen einsetzen.
Obwohl der ein oder andere Angriff magischen Schaden verursacht, empfiehlt sich "Magie verstärken" für alle Schlachtzugmitglieder.

|cffff0000Fähigkeiten
---------------|r

Der Kampf unterteilt sich in zwei Phasen. Phase eins hält 60 Sekunden an und ist ähnlich aufgebaut wie die Leerhäscher Konfrontation aus der Festung der Stürme. Phase zwei hingegen hält 30 Sekunden. Während dieser Zeit wird ein Spieler zufällig ausgewählt und muss währenddessen Gurtoggs Angriffe überleben. Die Phasen wechseln sich bis zu 10 Minuten lang ab.

Trefferpunkte: 5.600.000
Nahkampfschaden: 6.000 - 7.000 (bei 17.000 Rüstung)

|cff00ff00Phase 1|r

|cff5929C7Bogenzerkracher|r (Arcing Smash):
Ein frontaler Spalten-Angriff der Tanks (mit 17.000 Rüstung) für 6.300 - 7.000 Körperschaden trifft. Er fügt den Betroffenen außerdem einen Debuff zu, der alle Heilungen für vier Sekunden um 50% verringert. Diese Fähigkeit hat zehn Sekunden Abklingzeit.

|cff5929C7Desorientieren|r (Disorient):
Desorientiert zufällig den aktuellen Tank für fünf Sekunden und wechselt daraufhin auf den zweiten Spieler der Hassliste.

|cff5929C7Rauswurf|r (Knockback):
Schleudert das aktuelle Ziel (Main Tank) zurück (900 - 1.850 Schaden) und verringert seinen Hass. Die Fähigkeit hat 15 Sekunden Abklingzeit.

|cff5929C7Säurewunde|r (Acidic Wound):
Fügt dem aktuellen Ziel (Main Tank) alle zwei Sekunden diesen Dot zu, der bis zu 60 Mal stapelbar ist. Der Dot verringert die Rüstung des Tanks um 500 und fügt alle drei Sekunden 300 Schaden zu. Der Dot ist nicht entfernbar, außer durch Segen des Schutzes.

|cff5929C7Siedeblut|r (Bloodboil):
Ein bis zu fünf Mal stapelbarer Dot, der alle zehn Sekunden auf die fünf am weitesten entfernten Spieler verschossen wird. Betroffene Spieler erleiden pro Stapel 24 Sekunden lang jede Sekunde 600 Körperschaden.

|cff5929C7Teufelssäureatem|r (Fel-Acid Breath):
Ein frontal ausgerichteter Kegelförmiger Flächenangriff, der Initial 2.400 - 4.500 Naturschaden anrichtet und anschließend alle drei Sekunden zusätzliche 2.750 Naturschaden zufügt. Der Dot hält zehn Sekunden. Dem Angriff kann widerstanden werden.

|cff00ff00Phase 2|r

|cff5929C7Bedeutungslosigkeit|r (Insignificance):
Dieser Debuff trifft zu Beginn von Phase zwei alle Spieler, welche nicht die Teufelswut bekommen. Alle Aktionen des betroffenen Spielers erzeugen keinerlei Bedrohung.

|cff5929C7Bogenzerkracher|r (Arcing Smash):
Ein frontaler Spalten-Angriff der Spieler für ungefähr 12.000 Körperschaden trifft. Er fügt den Betroffenen außerdem einen Debuff zu, der alle Heilungen für vier Sekunden um 50% verringert. Diese Fähigkeit hat zehn Sekunden Abklingzeit.

|cff5929C7Teufelswut|r (Fel Rage):
Ein 30 Sekunden anhaltender Debuff, der alle 90 Sekunden einen zufälligen Spieler trifft. Während der Debuff aktiv ist greift Gurtogg ausschließlich den betroffenen Spieler an. Die Teufelswut gewährt dem betroffenen Spieler außerdem eine Sammlung von drei Buffs:

Teufelswut 1:

    * Erhöht die Rüstung um 15.000
    * Erhöht die Gesundheit um 30.000
    * Erhöht die Größe um 175%

Teufelswut 2:

    * Erhöht Heilungen um 100%
    * Erhöht den angerichteten Schaden um 300%
    * Verringert die Kosten von Zaubern und Fähigkeiten um 50%

|cff5929C7Teufelssäureatem|r (Fel-Acid Breath):
Ein frontal ausgerichteter Kegelförmiger Flächenangriff, der Initial 2.400 - 4.500 Naturschaden anrichtet und anschließend alle drei Sekunden zusätzliche 2.750 Naturschaden zufügt. Der Dot hält zehn Sekunden. Dem Angriff kann widerstanden werden.

|cff5929C7Teufelsgeysir|r (Acid Geyser):
Ein auf den von Teufelswut erfassten Spieler ausgerichteter Flächenangriff, welcher in einem sechs Meter Radius 3.300 - 3.800 Naturschaden anrichtet.

|cff5929C7Raserei|r (Enrage)
Nach Ablauf von zehn Minuten verfällt Gurtogg Siedeblut in Raserei und tötet alle Gruppenmitglieder.

|cffff0000Taktik
--------|r

|cff00ff00Phase 1|r

|cFFDBD533Positionierung|r
Die fünf Gruppen des Schlachtzuges müssen vor dem Kampf so unterteilt werden, dass es drei Gruppen gibt, die nur aus Fernkämpfern oder Heilern bestehen. Die restlichen Spieler (Tanks, Nahkämpfer und verbleibende Heiler/Fernkämpfer) wandern in die Gruppen vier und fünf.

Wo genau Gurtogg Siedeblut bekämpft wird ist relativ egal. Ihr könnt ihn sowohl auf der Rampe halten, wie die Abbildung zeigt, oder unten am Wasserfall in seinem Raum bezwingen. Wichtig ist dabei nur, dass die Tanks eine Wand im Rücken haben und die Abstände zu Gurtogg von den einzelnen Spielern/Gruppen eingehalten werden.

Die drei Tanks stellen sich also mit dem Rücken zur Wand auf und ein Jäger lockt Gurtogg Siedeblut mit Irreführung zu ihnen hin. Sobald dieser in Position ist, können sich die anderen Nahkämpfer hinter ihm aufreihen. Die drei Siedeblut-Gruppen rotieren auf Abstand in zwei Linien hinter Gurtogg an der gegenüber liegenden Wand. Gruppe eins steht dabei ganz an der Wand (am weitesten von Gurtogg weg) und die anderen davor in einem Haufen.

|cFFDBD533Kampfverlauf|r
Während der gesamten Phase müssen die drei Siedeblut-Gruppen immer wieder alle 10 bzw. 20 Sekunden die Position wechseln. Sobald die hinten stehende (erste) Gruppe den Siedeblut Dot bekommen hat, wechselt sie an die vordere Position (zu Gruppe zwei und drei) und die nächste Gruppe (zwei) läuft nach hinten. Hat diese Gruppe (zwei) ebenfalls den Dot läuft sie wieder nach Vorne und die nächste Gruppe (drei) rennt zurück. Wenn Gruppe drei den Dot bekommen hat, sollte er bei Gruppe eins gerade auslaufen. Womit die Rotation von Vorne anfangen kann.

Wenige Sekunden vor Ende von Phase eins müssen sich die Gruppen verteilen, um den Initialschaden beim Tankwechsel in Phase zwei zu reduzieren. Von den Siedeblutgruppen kann eine nach oben und die andere nach unten ausweichen. Die Nahkämpfer-Gruppen sollten ihnen das innerhalb der Gruppe gleich tun.

|cFF4C43FFFernkämpfer|r:
Alle Fernkämpfer (und Nahkämpfer) sollten sich bei der Bedrohungsgenerierung extrem zurückhalten. Gurtogg Siedeblut ist nicht Spotbar, was es für die drei Tanks extrem schwer macht Schaden gleichmäßig aufzubauen und zu halten. Jeder Fernkämpfer muss in der Hassliste unterhalb aller drei Tanks bleiben. Es kann im schlimmsten Fall passieren, dass der erste Tank den Rauswurf und der zweite die Desorientierung bekommt. Was dann nur noch den dritten Tank vor euch lässt.

|cFF1DDD2FHeiler|r:
Die Heiler müssen sich verteilt nach Klasse auf die beiden Heilaufgaben aufteilen. Den drei Tanks sollten insgesamt sechs Heiler (primär Paladine oder Priester) zugeteilt werden. Die restlichen Heiler (am Besten Schamanen) sollten sich um die Gruppe und somit den Schaden der Siedeblut Dots kümmern.

|cFF7D923CJäger|r:
Die Jäger sollten immer wieder den zweiten oder dritten Tank mit Irreführung beim Hassaufbau unterstützen.

|cFF5D2B17Tanks|r:
Ihr habt in diesem Kampf die schwierigste Aufgabe. Ihr müsst beim Hass-Aufbau möglichst auf einem Nenner bleiben, damit nicht ein Tank zu lange an der Spitze liegt und durch die Säurewunde, die der Hasshalter alle zwei Sekunden abbekommt, verstirbt. Dabei unterliegt ihr alle dem Problem, das Gurtogg sich nicht verspotten lässt. Ihr müsst den Hass also selbstständig produzieren. Glücklicherweise hat Gurtogg mehrere Flächenangriffe, durch die ihr ausreichend Wut bekommt. Ihr solltet aber so häufig wie möglich Schildblock einsetzen.

Nach spätestens 15 Sekunden wird Gurtogg den ersten von euch Tanks rauswerfen. In dem Augenblick wechselt er zum zweiten Spieler seiner Hassliste, was ebenfalls ein Tank sein sollte. Zudem desorientiert er von Zeit zu Zeit Spieler. Diesem Effekt kann durch einen hohen Vermeidungswert widerstanden werden. Leider ist der Effekt jedoch vollkommen zufällig. Er kann während der gesamten zehn Minuten nicht auftreten, aber auch innerhalb von zehn Sekunden gleich zwei Tanks außer Gefecht setzen, was nur noch einen Tank zurück lässt.

Wenn ein Tank so weit vorne liegt, dass er durch den Rauswurf allein nicht die Spitzenposition verliert, sollte er umgehend alle Angriffe einstellen. Andernfalls kann es passieren, dass er durch die 7.000er Schläge kombiniert mit der Säurewunde frühzeitig verstirbt. Bevor dieses passiert könnte ein Paladin in äußersten Notfällen Segen des Schutzes auf ihn wirken.

|cff00ff00Phase 2|r

|cFFDBD533Kampfverlauf|r
Die Phase beginnt mit einem Teufelsgeysir auf einem zufälligen Spieler. Dieser Spieler bekommt zudem den Teufelswut Buff. Wenn alle Spieler sich am Ende von Phase eins wie beschrieben verteilt haben, sollten nur der Teufelswut-Spieler den Teufeslgeysir, Bogenkracher etc. abbekommen. Wenn dieser Spieler feststeht und noch Spieler in seiner Umgebung sind, müssen sie sich umgehend von ihm distanzieren.

Der Teufelswut-Spieler wird sehr viel Schaden erleiden. Zwar wird er durch die Teufelswut gebuffed, aber nicht unsterblich. Gerade wenn Magier oder Priester davon betroffen sind, benötigen sie sehr viel Heilung, da Gurtogg sie mit bis zu 20.000 Körperschaden pro Schlag trifft. Es sollten also möglichst alle Heiler ihre Zauber auf den einen Spieler konzentrieren.

Bedauerlicherweise laufen zu diesem Zeitpunkt die Dots aus Phase eins weiter. D.h. zwei Gruppen bekommen noch Schaden durch das Siedeblut und die Tanks leiden noch immer an der Säurewunde. Die betroffenen Spieler sollten versuchen sich durch Gesundheitssteinen, Heiltränken usw. selbst am Leben zu halten. Maximal ein oder zwei Heiler können es sich erlauben nicht den Teufelswut-Spieler zu heilen und sich um die Gruppe zu kümmern.

Sollte der Teufelswut-Spieler dennoch sterben, kehrt Gurtogg Siedeblut zu dem ersten Spieler der Hassliste aus Phase eins zurück. Bei ihm handelt es sich hoffentlich um einen Krieger-Tank. Denn dieser sollte sofort Schildwall aktivieren. Nur dann ist es möglich, dass er Gurtoggs Angriffe ohne Teufelswut-Buff überlebt. Dieses Szenario führt jedoch häufig zum Tod der gesamten Gruppe.

Selbiges passiert wenn der Teufelswut-Spieler eine Immunitäts-Fähigkeit wie Eisblock, Gottesschild oder ähnliches einsetzt. Dieses darf also ebenfalls auf keinen Fall passieren.

In dieser Phase könnt ihr durch den Bedeutungslosigkeit-Buff keinerlei Bedrohung erzeugen. Daher solltet ihr alle Fähigkeiten und Gegenstände mit Abklingzeiten für diese 30 Sekunden aufbewahren und nun zum Einsatz bringen. Richtet so viel Schaden wie möglich an.

Mit dem Ende der 30-Sekündigen-Teufelswut beginnt Phase eins von Vorn und das heißt Gurtogg läuft zum letzten Hasslisten-Spitzenkandidaten zurück, was hoffentlich ein Tank war.

Spieler mit Teufelswut sollten je nach Klasse folgende Fähigkeiten einsetzen:

|cFFE66C00Druide|r:
Heilungs-Druiden sollten im Falle von Teufelswut Baumrinde aktivieren und sich selbst heilen. Verwendet dabei alle Hots und haltet euch bereit Schnelligkeit der Natur und Rasche Heilung einzusetzen.

Wilder-Kampf-Druiden hingegen müssen auf alle Fälle in ihre Bär-Form wechseln. Haltet Demoralisierendes Gebrüll auf Gurtogg und macht so viel Schaden wie ihr könnt. Rasende Regeneration heilt euch logischerweise für doppelt so viel wie normal. Setzt es weise ein.

|cFF861ABEHexenmeister|r:
Lebensentzug sollte euer erster Zauber sein (wenn ihr ihn habt), sobald ihr die Teufelswut habt. Darauf kann ein Todesmantel folgen und die restliche Zeit solltet ihr euch mit Leben entziehen am Leben halten. Wenn ihr unterbrochen werdet, wirkt es erneut.

|cFF7D923CJäger|r:
Benutzt den Aspekt des Affen, um euch gegen Gurtoggs Angriffe zu schützen. Versucht im Nahkampf so viel Schaden wie möglich zu machen.

|cFF5D2B17Krieger|r:
Als Tank solltet ihr mit der Teufelswut am wenigsten Probleme haben. Wenn ihr ein Offensiv-Krieger seit, dann wechselt augenblicklich in die Verteidigungs-Haltung und legt einen Schild an. Haltet Befehlsruf ununterbrochen oben und versucht trotz Schild so viel Schaden wie möglich zu machen.

|cFF03D7DFMagier|r:
Setzt auf keinen Fall Eisblock ein, wenn ihr die Teufelswut bekommt! Benutzt stattdessen sofort eure Eisrüstung. Die 25%ige Reduzierung von Gurtoggs Angriffsgeschwindigkeit könnte euch das Leben retten. Eisbarriere solltet ihr, so fern ihr sie habt, ebenfalls aktivieren und wenn eure Trefferpunkte stark sinken setzt euer Manaschild ein. Wenn ihr dann noch Mana überbehaltet, rückt Gurtogg mit Eislanzen und Feuerschlag zu Leibe.

|cFFFF65F2Paladin|r:
Setzt auf keinen Fall Gottesschild ein und heilt euch stattdessen ununterbrochen.

Priester:
Haltet Machtwort: Schild und eine Erneuerung dauerhaft aktiv und wirkt ununterbrochen Blitzheilungen auf euch selbst.

|cFF0313DFSchamane|r:
Wenn ihr ein Wiederherstellungs-Schamane seid, dann wirkt ein Erdschild auf euch selbst und heilt euch ununterbrochen.

Als Verstärker/Elementar-Schamane könnt ihr besser Schaden an Gurtogg anrichten.

|cFFDEDC30Schurke|r:
Aktiviert Entrinnen und haut alle eure Abklingzeiten raus, um so viel Schaden wie möglich anzurichten. Wenn ihr den Teufelssäureatem abbekommt, setzt euren Mantel der Schatten ein.
]]

L["tactic Souls"] = [[
|cffff0000Gruppenzusammenstellung
----------------------------------|r

Der Kampf erfordert mindestens einen Defensiv-Krieger als Tank, um das Abstumpfen in Phase zwei reflektieren zu können. Zum Tanken der Essenz des Leidens während des Wutanfalls werden Schurken benötigt, die ebenfalls gut zum Zauber unterbrechen in Phase zwei geeignet sind. Daher sollten sich mindestens drei in der Gruppe befinden. Ein bis zwei Schattenpriester sind für die Manaregeneration in Phase zwei und drei sehr vorteilhaft.

    * 1 Tank
    * 7-9 Heiler
    * 15-17 Schadensverursacher

|cffff0000Stärkungszauber, Tränke und andere Ausrüstung
-------------------------------------------------------------|r

Der Kampf erfordert keinerlei besondere Widerstandskleidung. Jeder Spieler benötigt aber sehr wohl für jeden ernsthaften Versuch in Phase drei einen Naturschutztrank und am Besten zusätzlich einen Schattenschutztrank.

Die Schurken oder Tanks anderer Klassen, die für den Wutanfall in Phase eins zuständig sind, sollten Ausrüstung mit hoher Ausweichwertung (z.B. Moroes' Glückstaschenuhr) besitzen.

Ausdauer/Willenskraft-Essen ist für den Kampf anzuraten. Heiler sollten bei der Wahl ihrer Elixiere/Fläschchen auf Heilungssteigernde und nicht Manaregenrierende zurückgreifen.

|cffff0000Fähigkeiten
---------------|r

Das Relikt der Seelen ist eine Figur mit drei Gesichtern, von denen jedes eine Phase mit unterschiedlichen Fähigkeiten darstellt.

|cFF4DFFFDEssenz des Leidens|r (Essence Of Suffering)
Trefferpunkte: 2.300.000
Nahkampfschaden: 1.050 - 1.350 Körperschaden

|cff5929C7Aura des Leidens|r (Aura of Suffering):
Diese Aura ist während der gesamten Lebzeit der Essenz des Leidens (Phase 1) aktiv und trifft alle Spieler des Schlachtzuges. Sie verringert, Regenerationseffekte und die Rüstung um 100% und die Verteidigung um 500.

|cff5929C7Fixieren|r (Fixated):
Dieser Debuff wird alle fünf Sekunden auf den Spieler gewirkt, welcher der Essenz des Leidens am nächsten ist. Der Spieler wird für den Dauer des Fixierens von der Essenz angegriffen.

|cff5929C7Seelensauger|r (Soul Drain):
Der Dot wird auf einen zufällig ausgewählten Spieler gewirkt. Er entzieht dem Spieler über 30 Sekunden alle drei Sekunden 2.625-3.375 Gesundheit/Mana. Dem Dot kann widerstanden und er kann entfernt werden.

|cff5929C7Wutanfall|r (Enrage):
Jede Minute verfällt die Essenz des Leidens für 15 Sekunden in einen Wutanfall. Während dieser Zeit verursacht sie deutlich mehr Schaden (3.000 - 4.000 Körperschaden).

|cFF4DFFFDEssenz der Begierde|r (Essence Of Desire)
Trefferpunkte: 3.000.000
Nahkampfschaden: 4.000 - 5.300 (bei 17.000 Rüstung)

|cff5929C7Aura der Begierde|r (Aura of Desire):
Diese Aura ist während der gesamten Lebzeit der Essenz der Begierde (Phase 2) aktiv und trifft alle Spieler des Schlachtzuges. Spieler erleiden 50% des Schadens, den sie selbst Schaden verursachen. Heilungen werden um 100% erhöht. Das maximale Mana wird alle acht Sekunden verringert. Nach 160 Sekunden ist das gesamte Mana aufgebraucht.

|cff5929C7Abstumpfen|r (Deaden):
Dieser Debuff erhöht zehn Sekunden lang den erlittenen Schaden um 100%. Er wird immer auf das aktuelle Ziel gewirkt und hat eine 30-Sekündige-Abklingzeit. Der Zauber kann unterbrochen und reflektiert werden.

|cff5929C7Geistschock|r (Spirit Shock):
Fügt dem aktuellen Ziel (Main Tank) bis zu 11.000 Arkanschaden zu und desorientiert ihn für fünf Sekunden, wo durch die Essenz der Begierde auf das nächst höhere Ziel der Hassliste wechselt. Die Zauberzeit beträgt eine Sekunde. Der Geistschock kommt alle fünf Sekunden zum Einsatz. Der Zauber kann und sollte unterbrochen werden.

|cff5929C7Runenschild|r (Rune Shield):
Die Essenz der Begierde wirkt diesen 50.000 Schaden absorbierenden Schild auf sich selbst. Er macht sie immun gegen Unterbrechungen und erhöht die Angriffs und Zaubergeschwindigkeit um 100%. Kann mit Magie Verschlingen (Teufelsjäger), Zauberraub (Magier) oder Reinigen (Schamane) entfernt werden.

|cFF4DFFFDEssenz des Zorns|r (Essence Of Anger)
Trefferpunkte: 3.000.000
Nahkampfschaden: 4.800 - 6.000 (bei 17.000 Rüstung)

|cff5929C7Aura des Zorns|r (Aura of Anger):
Diese Aura ist während der gesamten Lebzeit der Essenz des Zorns (Phase 3) aktiv und trifft alle Spieler des Schlachtzuges. Spieler erleiden alle drei Sekunden Schattenschaden. Der Schaden beginnt mit 100 und erhöht sich mit jedem Tick um weitere 100 (200, 300, 400...)

|cff5929C7Brodeln|r (Seethe):
Ein Debuff, der die erzeugte Bedrohung um 200% erhöht. Er hält zehn Sekunden an und setzt nur ein wenn die Essenz des Zorns auf ein neues Ziel wechselt (durch Spot, Dahinscheiden eines Spielers, etc.).

|cff5929C7Seelenschrei|r (Soul Scream):
Ein frontal ausgerichteter kegelförmiger Angriff, der 2.625 - 3.375 Schattenschaden zufügt und 4.375 - 5.625 Mana/Wut verbrennt. Für jeden verbrannten Wutpunkt erhält der getroffene Spieler 100 Schattenschaden. So kann der Tank zusätzlich zu dem Grundschaden leicht 8.000 zusätzlichen Schattenschaden erhalten, wenn er zu viel Wut hat.

|cff5929C7Bosheit|r (Spite):
Ein zufällig auf drei Gruppenmitglieder gewirkter Debuff, welcher den Betroffenen für sechs Sekunden immun gegen jeglichen Schaden macht. Nach Ablauf der sechs Sekunden erhält der Betroffene 7.444 - 7.556 Naturschaden.

|cffff0000Taktik
--------|r

Der Kampf ist, wie oben geschildert, in drei Phasen unterteilt. In jeder dieser Phasen kämpft ihr gegen eine Seite des Seelenrelikts. Ist ein Gesicht besiegt, zieht sich das Seelenrelikt kurz zurück und eine Reihe von gefesselten Seelen (Geistern) stürmt auf euch ein, die ihr leicht mit Flächenzaubern besiegen könnt. In dieser Zeit wird eure Gesundheits- und Manaregeneration stark angehoben. Damit ihr für die nächste Phase ohne Essenspause wieder vollkommen genesen seit.

|cff00ff00Phase 1|r

|cFFDBD533Positionierung|r
Das Überleben in dieser Phase liegt zu einem Großteil in der richtigen Positionierung. Alle Klassen mit einem relativ hohem Rüstungs- oder Ausweichen-Wert (Druiden (nur Wilder-Kampf) Jäger, Krieger, Paladine, Schamanen und Schurken) müssen sich abwechselnd innerhalb des roten Kreises befinden, der sich am Boden abzeichnet, wenn die Essenz des Leidens angewählt ist. Die Stoff-Klassen (Hexenmeister, Magier und Priester) hingegen stellen sich auf ungefähr 30 Meter Abstand in einer Gruppe auf. Der Abstand sollte so gewählt sein, das jeder innerhalb seiner Zauberreichweite ist (besonders die Paladine und Priester müssen darauf achten, dass sie nah genug zum Magie entfernen an allen Schlachtzugmitgliedern stehen).

Zum Start des Kampfes sollten nur die Jäger innerhalb des Kreises selbst stehen und alle anderen hierfür angedachten Klassen einen Schritt dahinter.

|cFFDBD533Kampfverlauf|r
Das große Problem dieser Phase ist das vollkommen Ausbleiben von Heilungen. Sämtliche Heilwirkungen werden durch die Aura des Leidens negiert. Das gilt sowohl für die normalen Heilzauber und Vampirumarmungen des Schattenpriester als auch Gesundheitssteine, Verbände und dergleichen. Da die Essenz des Leidens aber permanent Schaden an einem bestimmten Spieler anrichtet, muss dieser Schaden durch eine Rotation auf alle Gruppenmitglieder verteilt werden. Den Anfang machen hierbei die Jäger, damit sie für den Rest der Phase ebenfalls auf Distanz bleiben und Schaden anrichten können. Sobald der erste Jäger also von der Essenz des Leidens fixiert wird, macht er zwei Schritte zurück (nur so weit, das sich die Essenz selbst nicht bewegt) und vermeidet somit erneut von ihr fixiert zu werden, da die anderen Spieler (Jäger) jetzt näher an ihr stehen. Nach Ablauf der fünf Sekunden sollte die Essenz somit auf den nächsten Spieler/Jäger wechseln.

Diese Rotation muss während der gesamten ersten Phase aufrecht gehalten werden. Sobald die Jäger verbraucht sind, wechseln die anderen Klassen ein. Lediglich die Schurken sollten sich in der "normalen" Phase zurückhalten. Denn ihnen fällt die leidige Aufgabe zu den Wutanfall zu abzufangen. Das kann auf zweierlei Art geschehen:

    * Der Schurke aktiviert Entrinnen und erhöht damit für die 15 Sekunden seine Ausweichchance um 50%.
    * Der Schurke benutzt Sprinten und zieht die Essenz des Leidens damit 15 Sekunden lang hinter sich her durch den Raum. In diesem Fall müssen sich die anderen Schlachtzug-Mitglieder frühzeitig von dem Schurken distanzieren, damit die Essenz nicht aus Versehen an jemand anderem hängen bleibt.

Welche Fähigkeit auch genutzt wird, der Schurke sollte in beiden Fällen von der Gruppe geschützt werden. Paladine sollten also Segen der Freiheit und Priester Machtwort: Schild auf ihn wirken.

Alternativ kann die Rolle des Wutanfall-Tanks auch ein Krieger oder Druide übernehmen. Bei ihnen ist die Wahrscheinlichkeit auf einen Treffer jedoch wesentlich höher, daher sollten sie über möglichst viel Gesundheit verfügen.

Theoretisch kann ein Spieler in dieser Phase vor dem Tod bewahrt werden, in dem er einen Segen des Schutzes von einem Paladin erhält, oder einen anderen Immunisierungseffekt benutzt. Praktisch solltet ihr diese Fähigkeiten aber nicht einsetzen. Denn die Essenz des Leidens hat natürlich eine normale Hassliste und wenn der fixierte Spieler ausfällt, greift die Essenz des Leidens den obersten bzw. nächsten Spieler dieser an. Was schnell tödlich enden kann.

Nur weil die Heillungen aufgehoben werden, bedeutet das nicht, dass die Heiler in dieser Phase nichts zu tun haben. Alle Heiler sollten in dieser Phase versuchen Schaden an der Essenz des Leidens zu machen. Durch die mit Patch 2.3 eingeführten 30% Schaden auf Heilungsausrüstung sollte das zumindest eingeschränkt möglich sein. Paladine und Priester müssen aber primär auf den Seelensauger-Dot achten und diesen umgehend entfernen. Er wird ungefähr alle zehn Sekunden auf vier bis sechs Spielern auftauchen.

Nach zwei oder drei Wutanfall-Phasen sollte die Essenz des Leidens bezwungen sein und die erste Regenerationspause beginnen. Versammelt euch schnell an einem Punkt und vernichtet die Gefesselten Seelen mit Flächenzaubern.

|cff00ff00Phase 2|r

|cFFDBD533Positionierung|r
In dieser Phase ist das Relikt der Seelen wieder wie übliche jeder andere Boss an einen Spieler bindbar und auch jeder heilbar. Daher sollte der Defensiv-Krieger-Tank auf die Essenz der Begierde zu laufen und diese auf sich ziehen. Die Nahkämpfer stellen sich wie immer hinter der Essenz auf und die Fernkämpfer positionieren sich auf einem Haufen auf ca. 30 Meter Abstand. Dieses ist wichtig, damit die Heiler mit Gruppenheilungen (Kettenheilung, Kreis der Heilung, Gelassenheit) arbeiten können.

|cFFDBD533Kampfverlauf|r
Während der gesamten Phase ist die Aura der Begierde aktiv. D.h. euch werden 50% des angerichteten Schaden selbst zugefügt. Das hat für die Zauberkundigen leider den Nachteil, das kanalisierte Zauber unterbrochen und die Zauberzeit anderer Nicht-Spontan-Zauber durch den Dot-Schaden erhöht wird.

Das ist jedoch nur einer der Effekte der Aura. Der andere verringert konstant das Manamaximum jedes Spielers, bis es nach 160 Sekunden auf null ist und keinerlei Zauber mehr gewirkt werden können. Das führt unweigerlich zum Tod des Tanks und aller weiteren Spieler bzw. zum Ende der Phase wenige Sekunden später.
Je nachdem wie schnell eure Schlachtgruppe bisher am Hyjalgipfel und dem Schwarzen Tempel vorangekommen ist, wird der angerichtete Schaden eurer Mitglieder allein nicht ausreichen, um die Essenz der Begierde innerhalb der 160 Sekunden zu töten. Aber deshalb habt ihr einen Krieger als Tank mitgebracht. Dieser muss das Abstumpfen sofort mit Zauberreflektion auf die Essenz zurückwerfen und erhöht somit den angerichteten Schaden um 100%.

Leider wird dieses Vorhaben durch die Geistschocks erschwert. Wann immer diese gewirkt werden, müssen Schurken, Krieger und Magier sie sofort unterbrechen. Hierzu teilt ihr die genannten Klassen am Besten in drei Gruppen ein und sagt die Gruppen, die den nächsten Geistschock abbrechen sollen, per Schlachtzug-Meldungen oder Sprach-Chat an. Dabei kann halt passieren, das versehentlich ein Abstumpfen statt einem Geistschock abgebrochen wird. Ein derartiges Versehen kann je nach Ausrüstungsstand schon zu einem Wipe führen.

Das fünfte und letzte Hindernis der Phase ist das Runenschild. Es absorbiert 50.000 Schaden und muss daher umgehend entfernt werden. Welche Klasse dieses übernimmt sollte von der Gruppenzusammenstellung abhängen. Ideal ist es wenn ein Magier das Runenschild mit Zauberraub übernimmt. So kann er anschließend einige Zauber wirken, ohne Schaden zu nehmen oder beim Zaubern unterbrochen zu werden. Der Nachteil liegt aber auf der Hand: Zauberraub kostet viel Mana. Deshalb sollte diese Technik nur angewendet werden, wenn sich ein oder zwei Schattenpriester in der Schlachtgruppe befinden, die den Magiern bei der Manaregeneration helfen. Die Alternativlösung liegt in Teufelsjägern der Hexenmeister. Diese können das Runenschild automatisch mit Magie verschlingen entfernen. Kommt diese Taktik zum Einsatz, sollten die Hexenmeister beim Übergang von Phase eins zu zwei ihre Teufelsjäger beschwören (in Phase eins sind Wichtel deutlich nützlicher).

Sobald die Trefferpunkte der Essenz der Begierde auf 1% gesunken sind, findet der letzte Phasenwechsel statt.

|cFF1DDD2FHeiler|r:
Die Heiler sollten je nach Klasse auf die zwei Aufgabengebiete verteilt werden: Paladine heilen den Main Tank und Schamanen die Gruppe. Druiden und Priester können je nach Bedarf auf eine der beiden Gebiete verteilt werden. Die Priester sollten ihren Inneren Fokus für die Sekunden nach Ablauf Manaverringerung aufbewahren. Denn mit diesem können sie auch danach noch mal eine Große Heilung wirken. Selbiges gilt für das Hand auflegen der Paladine. Auch diese kann dem Main Tank noch mal das Leben retten. Die Zauberreflektion des Kriegers und der Tritt des Schurken funktionieren glücklicherweise auch noch ohne Mana.

|cff00ff00Phase 3|r

|cFFDBD533Positionierung|r
Die Aufstellung für diese Phase ist mit der vorangegangenen identisch. Der Main Tank läuft auf die Essenz des Zorns zu, bindet sie an sich und dreht sie mit dem Gesicht von der Schlachtgruppe weg. Die restlichen Spieler stellen sich je nach Klasse mit dem entsprechenden Abstand zur Essenz des Zorns auf.

|cFFDBD533Kampfverlauf|r
Während der ersten zehn Sekunden kann der Main Tank den Brodeln Debuff benutzen um etwas Hass aufzubauen. Innerhalb dieser Zeit sollten sich die Schadensverursacher noch zurückhalten. Da sich die Aura des Zorns nicht Krieger-Fähigkeiten wie Rüstung zerreißen, Schildschlag usw. auswirkt.

Das Brodeln sollte ausschließlich den Main Tank treffen. Wird wiedererwartend doch ein Schadensverursacher davon erfasst, muss er sofort alle Angriffe abbrechen, bis der Debuff aufhört.

Ihr habt für diese Phase nur ungefähr anderthalb Minuten Zeit. Nach Ablauf dieser wird der Schaden, den ihr durch die Aura erleidet so groß sein, dass die Heiler ihn nicht mehr kompensieren können. Aus diesem Grund müsst ihr alle Spezialfähigkeiten, Schmuckstücke und dergleichen zünden, was euren Schaden steigern kann. Haltet euch den Tränke-Timer aber frei, um einen Widerstandstrank benutzen zu können. Denn Falls euch die Bosheit erwischt, werdet ihr sie mit einem Naturschutztrank abschwächen wollen. Sollte euch nach den 90 Sekunden immer noch keine Bosheit erwischt haben, dann nutzt stattdessen einen Schattenschutztrank und negiert damit den Schaden der Aura. Diese wenigen Sekunden können euch die Oberhand in diesem Kampf geben.

Sehr Vorteilhaft ist es, wenn euch für diese Phase noch Seelensteine, Ankh oder Wiederbelebungen von Druiden zur Verfügung stehen. Denn die Aura wird nach dem Ableben resetet. D.h. wenn ihr wieder belebt werdet fängt sie wieder bei 100 an, auch wenn ihr zuvor bereits an 4.000er Ticks gestorben seit. Gegebenenfalls solltet ihr daher Spieler mit Ankhs oder Seelensteinen sterben lassen und andere heilen, um so den Gesamtschaden niedriger zu halten.

|cFF1DDD2FHeiler|r:
Die Heiler sollten genauso eingeteilt werden wie in der vorherigen Phase. Der Tank braucht starke Heilungen, da er die Nahkampfattacken, die Aura und zusätzlich noch den Seelenschrei erleidet und alle Spieler der Gruppe werden schon nach kurzer Zeit alle drei Sekunden 2.000 - 3.000 Schattenschaden abbekommen.

]]

L["tactic Mother Shahraz"] = [[
|cffff0000Gruppenzusammenstellung
----------------------------------|r

Der Kampf erfordert drei Tanks (Defensiv-Krieger oder Wilder-Kampf-Druiden), die sich den Säbelhieb teilen. Druiden sind auf Grund des hohen Rüstungswertes sehr gut als Off-Tanks geeignet. Der hohe Schadenswert der Verhängnisvollen Affäre und Strahlen sollte von ungefähr neun Heilern abgefangen werden. Die restlichen Plätze können mit Schadensverursachern aufgefüllt werden.

    * 3 Tanks
    * 9 Heiler
    * 13 Schadensverursacher

|cffff0000Stärkungszauber, Tränke und andere Ausrüstung
-------------------------------------------------------------|r

Der Kampf erfordert von allen Spielern den maximalen Schattenwiderstandswert von 365 (mit Buffs). Dementsprechend sollte jeder (ausgenommen der drei Tanks) mit Ausrüstungsgegenständen annähernd 295 erreichen. Es ist also nicht nötig, dass jeder Spieler alle fünf herstellbaren Ausrüstungsteile trägt. Vier sind jedoch zu empfehlen. Hier eine kurze Aufstellung der möglichen Gegenstände:

    * Hals: Medaillon von Karabor (40)
    * Rücken: Nachtend (40) mit Schattenwiderstandsverzauberung (15)
    * Gürtel: Gurt der Seelenwache (54)
    * Armschienen: Armschienen der Seelenwache (40)
    * Hose: Gamaschen der Seelenwache (72) mit Schattenrüstungsset (8) oder Schattenwächter (10)
    * Schuhe: Schuhe der Seelenwache (54) mit Schattenrüstungsset (8)

Zudem sind für den Kampf Erhebliche Schattenschutztränke zu empfehlen, um den Schattenschaden im Vorfeld abzufangen und alle Mana-Klassen sollten Elixiere des erheblichen Magierbluts und Heiler Fläschchen der mächtigen Wiederherstellung und Überragendes Manaöl bereithalten, um dem Manabrand entgegen zu wirken.

|cffff0000Fähigkeiten
---------------|r

Trefferpunkte: 4.500.000
Mana: 338.700
Nahkampfschaden: 5.800 - 7.600 (bei 17.000 Rüstung)

|cff5929C7Strahlen|r (Beams):
Im Verlauf des Kampfes setzt Mutter Shahraz unentwegt ihre Strahlen ein. Um welchen Strahl es sich handelt und welche Spieler von diesem getroffen werden ist vollkommen zufällig. Die Anzahl der Opfer ist jedoch auf zehn Spieler begrenzt. Es jetzt dabei bis zu drei mal hintereinander ein und den selben Strahl ein und wechselt anschließend auf einen neuen. Die vier Strahlenarten sind:

|cff5929C7Sündhafter Strahl|r (Sinful Beam):
Trifft einen Spieler und bis zu neun weitere in dessen Umgebung für 6.938-8.062 Schattenschaden.

|cff5929C7Heimtückischer Strahl|r (Vile Beam):
Trifft einen Spieler und bis zu neun weitere in dessen Umgebung für 4.000 Schattenschaden

|cff5929C7Finsterer Strahl|r (Sinister Beam):
Trifft einen Spieler und bis zu neun weitere in dessen Umgebung für 2.000 Schattenschaden und schleudert sie ein Stück zurück.

|cff5929C7Boshafter Strahl|r (Wicked Beam):
Entzieht den Opfern 1.000 Mana. Dem Effekt kann nicht durch Schattenresistenz widerstanden werden.

|cff5929C7Säbelhieb|r (Saber Lash):
Ein Frontal ausgelegter Flächenangriff auf einen ca. 1 - 2 Meter Bereich um das aktuelle Hasslistenziel. Der Säbelhieb richtet bis zu 84.000 Körperschaden (ohne Rüstungsmodifikator) an, welcher gleichermaßen durch die Anzahl der getroffenen Spieler geteilt wird. Deshalb werden für diesen Angriff bzw. Kampf drei Tanks empfohlen.

Säbelhieb-Tanks erhalten einen "Unterdrückender Schrei" Debuff, welcher sie Immun gegen den Rückstoß vom Finsteren Strahl und den Schaden der Verhängnisvollen Affäre macht. Dies gilt auch, wenn sie dem Angriff ausweichen oder ihn parieren.

|cff5929C7Verhängnisvolle Affäre|r (Fatal Attraction):
Teleportiert bis zu drei Spieler an einen zufälligen Ort und belegt sie mit dem Verhängnisvolle Affäre Debuff. Dieser verursacht in der ersten Sekunde 750 Schaden, 1500 in der zweiten, 2250 in der dritten und 3000 Schadenspunkte in allen darauf folgenden Sekunden an allen Spielern in einem 25 Meter Radius um die Betroffenen. Der Debuff/Schaden endet wenn sich alle zwei/drei Spieler mehr als 25 Meter voneinander entfernen.

Der Debuff ist nicht entfernbar, der erlittene Schaden kann jedoch durch Immunisierungseffekte wie Eisblock, Gottesschild etc. negiert werden. Der Effekt hat keinerlei Einfluss auf die drei Main Tanks.

Wenn der Debuff nur einen einzigen Spieler trifft, kann er einfach zu seinem früheren Standort zurück laufen.

|cff5929C7Prismatische Aura|r (Prismatic Aura):
Reduziert den Schaden einer zufälligen Magieschule und verstärkt den Schaden der entgegengesetzten Magieschule um 25%. Die Aura-Art wechselt alle 15 Sekunden.

Prismatische Aura: Arkan
Verursachter Arkanschaden um 25% verringert.
Verursachter Naturschaden um 25% erhöht.

Prismatische Aura: Feuer
Verursachter Feuerschaden um 25% verringert.
Verursachter Frostschaden um 25% erhöht.

Prismatische Aura: Frost
Verursachter Frostschaden um 25% verringert.
Verursachter Feuerschaden um 25% erhöht.

Prismatische Aura: Heilig
Verursachter Heiligschaden um 25% verringert.
Verursachter Schattenschaden um 25% erhöht.

Prismatische Aura: Natur
Verursachter Naturschaden um 25% verringert.
Verursachter Arkanschaden um 25% erhöht.

Prismatische Aura: Schatten
Verursachter Schattenschaden um 25% verringert.
Verursachter Heiligschaden um 25% erhöht.

|cff5929C7Raserei|r (Enrage)
Nach zehn Minuten setzt die bekannte Raserei ein, welche innerhalb weniger Sekunden zum Tod der gesamten Gruppe führt.

|cffff0000Taktik
--------|r

|cFFDBD533Positionierung|r
Die richtige Positionierung der Gruppe für diesen Kampf ist auf Grund des Verhängnisvolle Affäre Effektes sehr wichtig. Welche Taktik ihr dabei genau anstrebt steht euch relativ frei. Die bekannten Varianten reichen von einem bis zu vier Standorten. Die Vor- und Nachteile liegen klar auf der Hand:

Bei einem Gruppenstandort ist die Wahrscheinlichkeit am Geringsten, dass die teleportierten Spieler in der Gruppe landen. Passiert es dennoch ist der angerichtete Schaden jedoch auch am höchsten, weil fasst der ganze Schlachtzug 3.000 Schattenschaden pro Sekunde bekommt.

Verwendet ihr vier Gruppen ist die Chance, dass die Spieler in einer der Gruppen landen natürlich vier mal so hoch. Aber es werden auch nur vier oder fünf Spieler von dem Schaden erfasst.

Unabhängig davon wie viele Gruppenstandorte ihr verwendet, müsst ihr darauf achten, dass die Heiler sich auf diese verteilen und an jedem mindestens ein Gruppenheiler steht.

Die hier beschriebene Taktik soll einen einzigen Gruppenstandort und den Nahkämpfer-Standort umfassen. Der Main Tank und seine beiden Säbelhieb-Tank-Kollegen positionieren sich also am Rande des Weges und ein Jäger lockt Mutter Shahraz mit Irreführung zu ihnen. Die Fernkämpfer und Heiler verteilen sich auf 30 - 40 Meter Abstand zum Main Tank auf der Mitte des Weges nahe dem Pool. Die Nahkämpfer beziehen hinter Mutter Shahraz Position sobald sie ihren Bestimmungsort erreicht hat.

|cFFDBD533Kampfverlauf|r
Sobald Mutter Shahraz beim Tank angelangt ist, wird sie einen ihrer Strahlen einsetzen. Ihr könnt diesen ignorieren, egal um welchen es sich handelt. Der erlittene Schaden wird schlichtweg durch die Schattenwiderstandskleidung reduziert und der Rest muss von den Heilern wiederhergestellt werden. Die Art des Strahls wird sich spätestens nach dem dritten Angriff ändern. Mit etwas Glück bekommt ihr durch diese Änderung des 2.2 Patches nur noch selten den Boshaften Strahl ab.

Kurze Zeit darauf werden alle Spieler der Prismatischen Aura ausgesetzt werden. Auch diese werdet ihr einfach ertragen müssen. Genau so schnell wie die Aura kann der Säbelhieb kommen. Sein Einsatz ist vollkommen zufällig. Bei drei Tanks mit ungefähr 17.000 Rüstung wird er jeweils knapp 10.000 Schaden anrichten.

Das große Problem des Kampfes ist offensichtlich die Verhängnissvolle Affäre. Sie kann zehn Sekunden nach Kampfbeginn kommen, aber auch erst nach gut einer Minute einsetzen. Das wichtigste dabei ist, dass die betroffenen Spieler sofort reagieren und voneinander wegrennen. Jeder von ihnen sollte versuchen so weit wie möglich von den anderen weg zu kommen und keiner darf dem anderen nachrennen!

Wichtig ist dabei auch die Klasse der teleportierten Spieler. Handelt es sich Beispielsweise um zwei Schadensverursacher und einen Heiler, kann der Heiler stehen bleiben und die Spieler in seiner Umgebung heilen, während die Schadensverursacher versuchen Abstand zu gewinnen. Sind mehrere Heiler betroffen, müssen sie natürlich ebenfalls loslaufen. Daher sollten alle drei betroffenen Spieler per Sprechchat angesagt werden.

Mehr ist in dem Kampf nicht zu beachten. Es gibt lediglich eine Phase und in dieser wechseln ständig die Auren und Strahlen, während immer mal wieder Spieler teleportiert werden.

|cFF861ABEHexenmeister|r:
Achtet auf die Art der Prismatischen Aura und setzt dementsprechend Zauber der verstärkten Magieschule (Feuer oder Schatten) ein, um euren Schadensausstoß zu maximieren.

|cFF5D2B17Krieger|r:
Die drei Säbelhieb-Tanks müssen ihre normale Defensiv-Kleidung tragen. Selbstverständlich muss der Main Tank an Position eins der Hassliste sein. Die anderen beiden sollten außer Schildblock und einem anfänglichen Schlag möglichst gar nichts machen. Es reicht vollkommen wenn sie da sind, um den Säbelhieb abzufangen. Zusätztliche Angriffe führen nur dazu, dass der Mutter Shahraz Swintimer schneller resetet und dadurch der nächste Schlag 40% schneller kommt. Was wiederum mehr Schaden für den Main Tank bedeutet. Alle Tanks müssen an genau der gleichen Stelle stehen und nicht ein oder zwei Meter auseinander. Ab dem 2.4.3 Patch erhöhen Angriffe nicht mehr den Schwung-Timer. Somit dürfen die anderen beiden Tanks ebenfalls Hass aufbauen und Schaden anrichten.

|cFF03D7DFMagier|r:
Achtet auf die Art der Prismatischen Aura und setzt dementsprechend Zauber der verstärkten Magieschule (Arkan, Feuer oder Frost) ein, um euren Schadensausstoß zu maximieren.
]]

L["tactic Illidari Council"] = [[
|cffff0000Gruppenzusammenstellung
----------------------------------|r

Der Kampf hat vergleichsweise viele Anforderungen an die Klassenzusammenstellung. Neben den drei normalen Tanks wird (wie bei Krosh Feuerhand in Gruuls Unteschlupf) ein Magier als Tank für Hochnethermant Zerevor benötigt. Hinzu kommen sieben Heiler. Einer mehr ist auch möglich, zögert den aber ohnehin schon langen Kampf weiter hinaus.
Weiterhin werden für das Unterbrechen von Lady Malandes Kreis der Heilung und Göttlichem Zorn insgesamt vier Spieler benötigt. Wegen der zwei unterschiedlichen Schildtypen sollten es zwei Nahkämpfer (Schurke oder Offensiv-Krieger) und zwei Zauberkundige sein. Für letzteres ist ein Elementar-Schamane am besten geeignet (Heil-Schamanen haben zu wenig Zaubertrefferwertung). Magier können die Aufgabe zwar auch übernehmen, sind auf Grund der hohen Gegenzauber-Abklingzeit aber weniger gut geeignet und sollten somit nur die zweite Rolle spielen.
Der Kampf an sich dauert sehr lange, was vor allem bei dem Magier-Tank zu Problemen führen kann. Daher sollte die Gruppe weiterhin mindestens einen Schattenpriester beinhalten.

    * 3 Tanks
    * 7-8 Heiler
    * 14-15 Schadensverursacher

|cffff0000Stärkungszauber, Tränke und andere Ausrüstung
-------------------------------------------------------------|r

Die Standard-Fläschchen bzw. Elixiere sind selbstverständlich auch für diesen Kampf erforderlich. Heiler sollten auf Grund der Länge des Kampfes Fläschchen der mächtigen Wiederherstellung nutzen. Darüber hinaus sollte jeder Spieler mit Buffs mindestens 10.000 Trefferpunkte haben.

Für die hinterlistigen Angriffe von Veras Schwarzschatten empfiehlt sich ein Kessel des erheblichen Naturschutzes bzw. Erhebliche Naturschutztränke.

Der Maiger, welcher Hochnethermant Zerevor an sich binden muss, sollte durch Ausrüstung und Talente ungefähr 16% Trefferchance haben.

|cFFDBD533Fähigkeiten
---------------|r

Trefferpunkte: 2.984.000
Raserei (Enrage): Nach 15 Minuten

|cFF4DFFFDVeras Schwarzschatten|r (Schurke)

|cff5929C7Tödliches Gift|r (Deadly Poison):
Fügt dem Ziel über vier Sekunden jede Sekunde 1.000 Naturschaden zu. Dieser Effekt ist nicht stapelbar.

|cff5929C7Vergiften|r (Envenom):
Ein Finishing-Move, der das Tödliche Gift der Opfers aufbraucht und dem Ziel 4.250 - 5.750 Naturschaden zufügt. Ob das Tödliche Gift vorher mehrfach oder gar nicht tickt ist unterschiedlich.

|cff5929C7Verschwinden|r (Vanish):
Genau wie die normale Schurkenfähigkeit setzt Veras es alle 30 - 40 Sekunden ein.

|cFF4DFFFDGathios der Zerschmetterer|r (Paladin)

|cff5929C7Aura der Hingabe|r (Devotion Aura):
Spendet den anderen drei Boss-Mobs für 30 Sekunden 20% mehr Rüstung. Teilt sich eine sechzigsekündige Abklingzeit mit der Aura des chromatischen Widerstands.

|cff5929C7Aura des chromatischen Widerstands|r (Chromatic Resistance Aura):
Erhöht für 30 Sekunden die Widerstände gegen alle Magieschulen bei den drei anderen Boss-Mobs um 250. Teilt sich eine sechzigsekündige Abklingzeit mit der Aura der Hingabe.

|cff5929C7Hammer der Gerechtigkeit|r (Hammer of Justice)
Betäubt einen zufälligen Spieler in einem 10 - 40 Meter Reichweite um Gathios. Der Magie-Effekt kann entfernt werden.

|cff5929C7Segen des Schutzes|r (Blessing of Protection):
Der Segen macht einen der anderen drei Boss-Mobs für 15 Sekunden immun gegen physikalischen Schaden. Er wird jedoch zu 90% auf Lady Malande gewirkt. Der Segen teilt sich eine fünfzehnsekündige Abklingzeit mit dem Segen des Zauberschutzes.

|cff5929C7Segen des Zauberschutzes|r (Blessing of Spell Warding):
Der Segen macht einen der anderen drei Boss-Mobs für 15 Sekunden immun gegen Zauberschaden. Er wird jedoch zu 90% auf Lady Malande gewirkt. Der Segen teilt sich eine fünfzehnsekündige Abklingzeit mit dem Segen des Schutzes.

|cff5929C7Siegel des Blutes|r (Seal of Blood):
Ein Buff, den Gathios auf sich selbst wirkt und der 30 Sekunden lang bei jedem Angriff zusätzliche 677 Heiligschaden anrichtet. Wenn Gathios anschließend Richturteil des Blutes wirkt, fügt er seinem Opfer über neun Sekunden 10.800 Heiligschaden zu.

|cff5929C7Siegel des Befehls|r (Seal of Command):
Ein Buff, den Gathios auf sich selbst wirkt und der 30 Sekunden lang zusätzlichen Heiligschaden, entsprechend 70% seines normalen Waffenschadens anrichtet. Wenn Gathios anschließend Richturteil des Befehls wirkt, fügt er seinem Opfer (Tank) damit 5.450 - 6.825 Heiligschaden zu. Das Richturteil kann auf Gathios reflektiert werden. Das Siegel teilt sich seine Abklingzeit mit dem Siegel des Blutes.

|cff5929C7Weihe|r (Consecration):
Der Boden um Gathios wird in einem 10 Meter Radius geweiht und verursacht bei allen Spielern, die sich darin befinden, alle drei Sekunden 2.250 Heiligschaden. Die Weihe hält 21 Sekunden lang und kommt ungefähr alle 30 Sekunden zum Einsatz.

|cFF4DFFFDLady Malande|r (Priesterin)

|cff5929C7Machtvolle Pein|r (Empowered Smite):
Fügt dem Ziel (Tank) 4.700 - 5.200 Heiligschaden zu. Der Zauber hat eine zweisekündige Zauberzeit und 30 Sekunden Abklingzeit.

|cff5929C7Reflektierender Schild|r (Reflective Shield):
Schildet Lady Malande von sämtlichem physikalischem und magischem Schaden in Höhe von bis zu 25.000 und macht sie Immun gegen Unterbrechungen. Der Schild wirft die Hälfte des angerichteten Schadens auf den Angreifer zurück. Er hält für 20 Sekunden oder bis er aufgebraucht ist.

|cff5929C7Göttlicher Zorn|r (Divine Wrath):
Verzehrt einen zufälligen Spieler für 4.230 Heiligschaden Heiligschaden und hinterlässt einen Dot, der weitere 2.500 Heiligschaden alle zwei Sekunden über acht Sekunden (10.000 insgesamt) anrichtet.

|cff5929C7Kreis der Heilung|r (Circle of Healing):
Heilt einen der vier Boss-Mobs und alle weiteren in einem 15 Meter Radius um diesen für 95.000 - 105.000 Trefferpunkte. Lady Malande wählt als Ziel zu 90% den Paladin Gathios aus. Durch die verbundenen Trefferpunkte bekommen selbstverständlich alle vier Boss-Mobs wieder Gesundheit hinzu. Dennoch macht es einen Unterschied ob einer oder mehrere in dem Kreis der Heilung stehen. Der Zauber hat 2,5 Sekunden Zauberzeit, 20 Sekunden Abklingzeit und kann unterbrochen werden.

|cFF4DFFFDHochnethermant Zerevor|r (Magier)

|cff5929C7Arkanblitz|r (Arcane Bolt):
Ein zweisekündiger Zauber, der gegen den Hasslistenhöchsten gerichtet ist und 12.500 - 15.000 Arkanschaden anrichtet. Kann mit Zerevors Magiedämpen Fähigkeit auf ca. 3.450 - 3.900 Arkanschaden reduziert werden.

|cff5929C7Arkane Explosion|r (Arcane Explosion):
Wie Imperator Vek'lor setzt Hochnethermant Zerevor diese immer ein wenn ein Spieler auf fünf Meter oder weniger an ihn heran kommt. Die Arkane Explosion richtet in einem 20 Meter Radius um Zerevor an jedem Spieler 9.000 - 12.000 Arkanschaden an.

|cff5929C7Blizzard|r:
Der bekannte Magier-Zauber kann überall im Raum einschlagen und richtet dort in einem 10 Meter Radius für zwölf Sekunden alle zwei Sekunden 4.375 to 5.625 Frostschaden an.

|cff5929C7Flammenstoß|r (Flamestrike):
Eine Flammensäule, die auf einen zufällig ausgewählten Spieler herabrast und im Umkreis von 10 initial Metern 4.625 - 5.375 Feuerschaden sowie anschließend für zwölf Sekunden jede Sekunde 2.800 - 3.200 Feuerschaden anrichtet.

|cff5929C7Magie Dämpfen|r (Dampen Magic):
Ein fünfminütiger Selbstbuff, der Magieschaden um bis zu 75% und Heilung um bis zu 500 verringert.

|cFFDBD533Taktik
--------|r

Wie Anfangs erwähnt, ist die Gesundheit aller vier Gegner miteinander verbunden. Wodurch es augenscheinlich egal ist, an welchem Boss-Mob Schaden gemacht wird. Im Endeffekt sollte jedoch Gathios das Hauptangriffsziel sein, da er der einzige Gegner ist, der dauerhaft angegriffen werden kann. Denn Zerevor (Magier) darf sich keiner nähern, Veras (Schurke) verschwindet immer wieder und Lady Malande (Priesterin) wird alle 15 Sekunden immun gegen eine Schadensart.

|cFFDBD533Positionierung|r
Der wichtigste und schwierigste Faktor des Kampfes ist die richtige Positionierung bzw. die vier Gegner gut zu verteilen.

Der Kampf beginnt damit, dass der tankende Magier einen Segen des Schutzes und daraufhin mit einem Feuerball oder Pyroschlag auf Hochnethermant Zerevor feuert. Anschließend stielt er ihm mit Zauberraub seinen Magie Dämpfen Buff. Hochnethermant Zerevor wird daraufhin für die restliche Dauer des Kampfes im Westen an der Treppe gehalten. Dem Magier-Tank sollte ein Paladin als Heiler zugeteilt werden.

Es empfiehlt sich Lady Malande in der Nähe ihrer Startposition (oberhalb der Treppe) zu halten. Der dafür zuständige Tank sollte ihr zu Kampfbeginn mit Sturmangriff zu Leibe rücken. Ihm sollte möglichst ebenfalls ein Paladin als Heiler zugewiesen werden. Reicht die Heilung eines einzelnen für den Tank und die Unterbrechergruppe nicht aus, muss hierfür ein weiterer Heiler eingeteilt werden.

Veras Schwarzschatten muss von seiner Startposition aus in die Ecke Vorne links (Südwesten) gezogen werden. Dafür sollte ein Jäger Irreführung auf dem zuständigen Tank setzen und Veras somit in die Ecke führen. Für diesen Tank empfiehlt sich ein Druide. Die benötigte Heilung für den Tank fällt sehr gering aus, weshalb der Druide zusätzlich auf die Spieler bei Gathios acht geben kann.

Gathios der Zerschmetterer ist das Hauptangriffsziel und für ihn wird auch der meiste Platz benötigt. Er sollte zum Kampfbeginn ebenfalls mit der Irreführung eines Jägers auf den zuständigen Tank im Eingangsbereich der Halle gelenkt werden. Ihm müssen mehrere Heiler überstellt werden, da er sehr hohe Schadensspitzen einfährt. Neben den Angriffen Gathios' selbst kommen immer wieder die Zauber den Magiers hinzu. Es sollten sich also am Besten ein Priester mit Inspirations-Talent oder ein Schamane mit Heilung der Ahnen um ihn kümmern, damit die kritischen Treffer ausgebremst werden und mindestens zwei weitere Heiler.

|cFFDBD533Kampfverlauf|r
Wenn die ersten zehn Sekunden überstand sind, alle Bosse sich an den vorgesehenen Positionen befinden und noch alle Gruppenmitglieder leben, ist der schwierigste Teil des Kampfes bereits überstanden. Dennoch habt ihr mit zwei weiteren schwerwiegenden Problemen zu kämpfen. Das Unterbrechen der Priesterzauber und das Ausweichen der Flächenangriffe um Gathios.

Gathios der Zerschmetterer
Der Eingangsbereich der Halle sollte weiträumig frei geräumt sein. Die anderen drei Boss-Mobs wurden mit Absicht auf Abstand verteilt, damit die gesamte Gruppe hier viel Bewegungsspielraum hat.

Der Main Tank legt eine rechteckige Fläche fest, in welcher er den Paladin, Gathios, im Uhrzeigersinn bewegt. Wann immer er selbst in einen Flammenstoß, Blizzard oder die Weihe gerät, zieht er den Paladin eine Ecke weiter.

Die Fernkämpfer müssen möglichst viel Abstand zueinander einhalten, damit im Falle eines Blizzards oder Flammenstoßes nur einer oder maximal zwei Spieler in Mitleidenschaft gezogen werden. Sie sollten sich dabei den Bewegungen des Main Tanks / Paladins ununterbrochen anpassen.

Die Nahkämpfer müssen extrem aufpassen! Sie werden neben den zufälligen Blizzards/Flammenstößen auch immer wieder in die Weihe geraten, was sie schnell das Leben kosten kann.

Gathios ist mit 90%iger Wahrscheinlichkeit das Ziel von Lady Malandes Kreis der Heilung. Nur wenn sich Veras Schwarzschatten gerade getarnt in seiner Nähe umherschleicht, wird er ebenfalls zwischendurch geheilt. Es sollten zwar eigentlich alle Heilungen unterbrochen werden, aber für den Fall, dass doch mal eine Heilung durch kommt, müssen sich Heilungsverringernde Debuffs (Tödlicher Stoß, Verhexung der Schwäche, etc.) auf Gathios befinden.

Lady Malande
Der Göttliche Zorn muss genau so unterbrochen werden wie der Kreis der Heilung. Das gestaltet sich auf Grund der drei verschiedenen Schilde/Segen jedoch etwas problematisch. Hierzu werden vier Schadensverursacher benötigt. Für den physikalischen Schaden sind zwei Schurken vorzuziehen und für den magischen ein Elementar-Schamane sowie ein Magier (zwei Magier gehen Notfalls auch).

Wenn der Reflektierende Schild oben ist, muss sich die Zauberer-Fraktion mit Gegenzauber oder Erdschocks um das Unterbrechen der Zauber kümmern. Ist er unten, können die Schurken zutreten.

Selbiges gilt für die beiden Paladin Schilde. Ist der Segen des Zauberschutzes aktiv, müssen die Schurken die Zauber mit Tritten abbrechen. Wird der Segen des Schutzes aktiv, sind die Schamanen/Magier gefragt.

Damit die beiden Fraktionen eine höhere Chance zum Unterbrechen haben, sollte ein Hexenmeister Fluch der Sprachen auf Lady Malande aufrecht halten.

Die Magier bzw. der Schamane sollten sich so positionieren, dass sie während der Segen des Zauberschutzes Phase Gathios angreifen können.

Veras Schwarzschatten
Der Schurke macht den Kampf für den zuständigen Tank zu einem kleinen Fangspiel. Ungefähr alle 30 - 40 Sekunden wird Veras Schwarzschatten verschwinden und ein paar Sekunden später hinter einem zufälligen Spieler auftauchen, um diesen zu vergiften (knapp 6.000 Naturschaden).

Mir Addons wie Big Wigs wird der entsprechende Spieler kurz vor Veras Erscheinen mit einem Totenkopf gekennzeichnet. Wodurch der Tank eine höhere Chance hat in die richtige Richtung zu sprinten und der Spieler selbst kurzerhand einen Naturschutztrank einwerfen kann, um den Schaden zu kompensieren. Der Vergiftungsschaden alleine wird zwar keinen Spieler direkt töten, verbunden mit einem Blizzard, Flammenstoß, Weihe etc. ist er aber schnell tödlich.

Hochnethermant Zerevor
Der Magier Zerevor sollte im gesamten Kampfverlauf kein Problem darstellen, so lange sich ihm kein Spieler in Nahkampfreichweite nähert und der Zauberraub immer funktioniert. Um letzteres zu gewährleisten sollte der tankende Magier möglichst 16% Zaubertrefferchance haben und Magie erkennen auf Hochnethermant Zerevor halten. Da kein anderer Spieler den Magier angreift, sollte es auch kein Hasslistenrangeleien geben.

|cFF861ABEHexenmeister|r:
Haltet Fluch der Sprachen bei Lady Malande aufrecht. Auf diese Weise können die Unterbrechungen und der Zauberraub eher gelingen. Verteilt eure Seelensteine auf die Heiler.

|cFF7D923CJäger|r:
Unterstützt im Kampfverlauf den Schurken-Tank beim Einfangen von Veras Schwarzschatten mit Irreführung.

|cFF5D2B17Krieger|r:
Sowohl der Priester- (Lady Malande) als auch Paladin-Tank (Gathios der Zerschmetterer) können Zauberreflektion verwenden, um Machtvolle Pein und Hammer der Gerechtigkeit auf ihre Verursacher zurück zu werfen.
]]

L["tactic Illidan"] = [[

Illidan Sturmgrimm, durch seine Machenschaften gegen die Nachtelfen als "der Verräter" bekannt, wurde als Bruder von Malfurion Sturmgrimm und somit ebenfalls Nachtelf geboren. In Folge seiner unaufhaltsamen Gier nach Macht ist er zu einer Mischung aus Dämon und Nachtelf geworden. Als Fürst der Scherbenwelt regiert er vom Dach des Schwarzen Tempels aus. Wo ihr ihn als neunten und letzten Boss der Schlachtzug-Instanz bekämpfen müsst.

Der Kampf erfordert sehr viel Koordination (vor allem von den Tanks) und einiges an Feuerkraft. Denn insgesamt müssen ungefähr 8.000.000 Trefferpunkte in weniger als 25 Minuten dezimiert werden.

|cffff0000Gruppenzusammenstellung
----------------------------------|r

Der Kampf erfordert drei Krieger-Tanks sowie einen weiteren Hexenmeister als Tank für Phase 4. Um die Gesundheit dieser und der Rest des Schlachtzuges sollten sich acht bis neun Heiler kümmern. Zur Beseitigung der schädlichen Schattengeister sind darüber hinaus mindestens zwei Magier zu empfehlen. Die verbleibenden Plätze können mit beliebigen Schadensverursachern aufgefüllt werden. Für die späteren Phasen sind Fernkämpfer etwas besser geeignet als Nahkämpfer.

    * 3 Tanks
    * 8 - 9 Heiler
    * 13 - 14 Schadensverursacher

|cffff0000Stärkungszauber, Tränke und andere Ausrüstung
-------------------------------------------------------------|r

Zwei der drei Tanks sollten Feuerschutzkleidung (365 Feuerresistenz) tragen und der auserwählte Hexenmeister-Tank Schattenwiderstandskleidung (mit mindestens 250 Schattenresistenz). Alle restlichen Spieler sollten Ausrüstung tragen, mit der sie mindestens 10.000 Trefferpunkte erlangen.

Darüber hinaus sind die üblichen Buffs zu empfehlen. Erhebliche Feuerschutztränke bzw. ein Kessel des Feuerschutzes kann hilfreich sein, ist aber nicht zwingend erforderlich.

|cFFDBD533Fähigkeiten
---------------|r

Trefferpunkte: 5.900.000
Nahkampfschaden: 6.000 - 8.000 (bei 18.000 Rüstung)
Raserei: 25 Minuten

|cff00ff00Phase 1|r
Die Phase beginnt 30 Sekunden nachdem ihr Akama angesprochen habt und endet wenn Illidans Gesundheit auf unter 65% fällt.

|cff5929C7Abscheren|r (Shear):
Ein gegen das Hauptziel gerichteter Zauber mit 1,5 Sekunden Zauberzeit, welcher die Gesundheit des Spielers für sieben Sekunden um 60% reduziert. Der Angriff kann mit Schildblock abgewehrt werden.

|cff5929C7Flammenschlag|r (Flame Crash):
Illidan springt in die Luft und erzeugt direkt unter sich einen 10 Meter großen blauen Flammenteppich. Spieler, die in diesen hineingeraten, erleiden alle zwei Sekunden 5.000 Feuerschaden. Der Flammenteppich hält 60 Sekunden lang.

|cff5929C7Schädlicher Schattengeist|r (Parasitic Shadowfiend):
Ein zufällig ausgewählter Spieler wird mit diesem Debuff belegt, der für zehn Sekunden alle zwei Sekunden 3.000 Schattenschaden anrichtet. Nach Ablauf der zehn Sekunden erscheinen in dem Spieler zwei Schädliche Schattengeister, die automatisch versuchen den Spieler mit der höchsten globalen Bedrohung anzugreifen. Wenn sie in Nahkampfreichweite eines weiteren Spieler gelangen und diesen Schlagen, erhält er ebenfalls den Debuff. Die Schattengeister haben ungefähr 6.000 Trefferpunkte

|cff5929C7Seele anziehen|r (Draw Soul):
Trifft alle Spieler in einem 70 Grad Radius vor Illidan für 3.800 - 5.300 Schattenschaden und heilt Illidan für 100.000 Trefferpunkte. Dem Zauber kann widerstanden werden.

|cff00ff00Phase 2|r
In Phase 2 erhebt sich Illidan in die Luft und wird unangreifbar. Kurz darauf schleudert er seine beiden Klingen auf das Dach des Tempels. Bei ihnen erscheint je eine Flamme von Azzinoth (Flames of Azzinoth). Die Phase endet erst wenn beide Flammen ausgelöscht sind.

|cff5929C7Augenfeuer|r (Eye Beam):
Ein blauer Feuerstrahl, der alle 30 Sekunden zum Einsatz kommt und bei Berührung 17.000 Schattenschaden verursacht. Der Strahl hinterlässt am Boden ein bläuliches Feuer, das pro Tick 2.000 Feuerschaden anrichtet. Dem Strahl kann nicht widerstanden werden, dem Feuer aber schon.

|cff5929C7Feuerball|r (Fireball):
Wenn Illidan kein Augenfeuer wirkt, schleudert er Feuerballsalven auf das Metallgitter des Daches. Diese blauen Feuerbälle treffen mehrere Spieler für 2.550 - 3.450 Feuerschaden.

|cff5929C7Dunkles Sperrfeuer|r (Dark Barrage):
Ein zufällig ausgewählter Spieler wird von diesem lilanen Strahl erfasst, welcher zehn Sekunden lang jede Sekunde 3.000 Schattenschaden anrichtet (30.000 insgesamt).

|cff00ff00Phase 3|r
Phase 3 und 4 wechseln sich ab bis Illidans Trefferpunkte unter 30% fallen. Phase 3 ist immer 60 Sekunden lang und Phase 4 40 Sekunden lang.

In dieser Phase benutzt Illidan die gleichen Fähigkeiten wie in Phase 1 (Abscheren, Flammenschlag, Schädlicher Schattengeist und Seele anziehen) und zusätzlich:

|cff5929C7Peinigende Flammen|r (Agonizing Flames):
Ein blauer Flammenschlag wird auf einen zufälligen Spieler gewirkt. Der Spieler sowie alle weiteren Spieler in einem Umkreis von zehn Metern um diesen erleiden Initial 4.000 Feuerschaden. Anschließend verursacht der Debuff über 60 Sekunden alle fünf Sekunden sich steigernden Feuerschaden (5. Sekunde 1.200; 10. Sekunde 1.200; 15. Sekunde 1.200; 20. Sekunde 2.400; 25. Sekunde 2.400; 30. Sekunde 2.400; 35. Sekunde 3.600 Feuerschaden usw.)

|cff00ff00Phase 4|r
In dieser Phase verwandelt sich Illidan in einen schwarzen Dämon und bleibt für 30 Sekunden in dieser Form. Anschließend tritt wieder Phase 3 in Kraft.

|cff5929C7Schattenschlag|r (Shadow Blast):
Eine Art Schattenblitz, der gegen den Spieler mit der höchsten Bedrohung gerichtet ist. Er verursacht bei seinem Ziel 8.750 - 11.250 Schattenschaden und greift auf Spieler über, die sich in einem 20 Meter Radius um diesen befinden. Dem Zauber kann widerstanden werden.

|cff5929C7Flammenschlag|r (Flame Burst):
Alle 20 Sekunden schleudert Illidan blaue Feuerbälle auf jeden einzelnen Spieler. Diese richten 3.238 - 3.762 Feuerschaden an und treffen Spieler in fünf Meter Reichweite um das Opfer zusätzlich in dieser Höhe. Dem Zauber kann widerstanden werden.

|cff5929C7Schattendämonen|r (Shadow Demons):
Maximal alle 30 Sekunden spawnen zu Illidans Füßen vier Schattendämonen, die jeder einen zufällig ausgewählten Spieler ins Ziel nehmen. Der betroffene Spieler wird dabei paralysiert. Die Schattendämonen bewegen sich entlang des lilanen Strahls auf den Spieler zu und töten diesen augenblicklich, wenn sie bei ihm angelangen. Jeder Schattendämon hat ungefähr 22.000 Trefferpunkte.

|cff5929C7Aura des Schreckens|r (Aura of Dread):
Diese Aura umgibt Illidan Sturmgrimm. Sie verursacht bei jedem Spieler in einem 15 Meter Radius um ihn pro Sekunden 1.000 Schattenschaden und erhöht den erlittenen Schattenschaden um 30%. Der Debuff stapelt sich mit der Zeit.

|cff00ff00Phase 5|r
Diese Phase beginn wenn Illidans Gesundheit auf 30% fällt. Sie erweitert die vorhandenen Fähigkeiten der 3. Phase (Abscheren, Flammenschlag, Schädlicher Schattengeist, Seele anziehen und Peinigende Flammen) wiederum um folgende:

|cff5929C7Schattengefängnis|r (Shadow Prison):
Bei 30% Gesundheit versetzt Illidan alle Spieler für 30 Sekunden in Schattengefängnisse (dunkel blau leuchtende Blasen). Diese machen euch Immun gegen jeglichen Schaden aber auch Handlungsunfähig. In diesem Moment folgt eine kurze Zwischensequenz, bei der Maiev Shadowsong mit in den Kampf einsteigt.

|cff5929C7Wutanfall|r (Enrage):
Nachdem Illidan sich eine Zeit lang wie in Phase 3 verhalten hat, wird er einen Wutanfall bekommen, welcher seine Angriffsgeschwindigkeit und -stärke erhöht. Der Wutanfall kann nur aufgehalten werden, in dem Illidan in eine von Maiev's Fallen manövriert wird.

|cff5929C7Flamme von Azzinoth|r
Je einer dieser Feuerelementare erscheint aus einem der beiden Splitter von Azzinoth (Illidans Waffen), die Illidan zu Beginn der zweiten Phase auf den Boden schleudert.

Trefferpunkte: 1.100.000
Nahkampf: 10.000 Feuerschaden

Ihre Nahkampfangriffe gelten als Feuerschaden, können aber dennoch kritisch oder schmetternd treffen. Die ungefähr 10.000 Feuerschaden pro Schlag können durch 365 Feuerwiderstand auf 2.000 - 3.000 reduziert werden.

|cff5929C7Lohe|r (Blaze)
Die Flammen hinterlassen einen Flammenteppich unter sich, welcher pro Sekunde ungefähr 2.000 Feuerschaden anrichtet und stapelbar ist. Dieser kann den Tank sehr schnell in die Knie zwingen. Weshalb die Flamme von Azzinoth permanent in Bewegung gehalten werden muss.

|cff5929C7Wutanfall/Ansturm|r (Enrage/Charge)
Die beiden in den Boden gerammten Gleven verfügen über eine Art unsichtbare Aura von ungefähr 25 Metern Reichweite. So lange sich jeder Spieler innnerhalb eines 25 Meter Radius um die Gleven aufhält, ist alles in Ordnung. Entfernt sich jedoch ein beliebiger Spieler zu weit davon, stürmt die Flamme diesen an und verfällt in einen Wutanfall. Dieses führt dazu, dass die Flamme nicht mehr vom Tank gehalten werden kann und daraus der Tod der gesamten Schlachtgruppe resultiert.

|cff5929C7Schattendämonen|r (Shadow Demons)
Diese Beholder Dämonen erscheinen in der vierten Phase zu viert zu Illidans Füßen und nehmen jeweils einen zufällig gewählten Spieler ins Visier, auf den sie sich zu bewegen.

Trefferpunkte: 22.000
Nahkampf: tödlich

|cff5929C7Paralysieren|r (Paralyze)
Jeder der vier Schattendämonen visiert einen zufälligen Spieler an und paralysiert diesen. Um welchen Spieler es sich dabei handelt wird durch einen lilafarbenen Strahl dargestellt, welcher vom Schattendämon zum Opfer reicht. Der betroffene Spieler kann sich weder bewegen noch Fähigkeiten benutzen. Erreicht der Schattendämon sein Opfer, tötet er es mit einem einzigen Schlag und sucht sich ein neues Paralysieren-Ziel.

Alle nicht von der Paralyse betroffenen Schadensverursacher müssen sich umgehend um die Schattendämonen kümmern. Höchste Priorität hat selbstverständlich ein evtl. getroffener Tank (Hexer oder Krieger). Die Schattendämonen sollten auf ihrem Vormarsch unbedingt gebremst werden. Dazu können Frostfallen von Jäger, Erdbindungs-Totems von Schamanen usw. genutzt werden.

|cFFDBD533Taktik
--------|r

|cff00ff00Phase 1|r (100% - 65%)

Die Begegnung wird gestartet indem ein Spieler Akama an der Treppe zum Dach anspricht. Akama beginnt daraufhin ein Gespräch mit Illidan Sturmgrimm, welches 30 Sekunden später damit endet, dass Illidan angreifbar wird. Der Main Tank muss ihn daraufhin an sich binden uns augenblicklich von der Schlachtgruppe abwenden, damit nur er unter dem Einfluss von Seele entziehen geraten kann.

|cFFDBD533Positionierung|r
Für den Verlauf der ersten Phase müssen drei Punkte definiert werden:

    * |cFFDBD533Main Tank Route|r
Illidan steht zu Beginn des Kampfes nördlich des großen Bodenkreises zwischen den beiden gigantischen Säulen. Er sollte vom Main Tank beim Start des Kampfes schnell zu der einen gezogen werden und über dem Verlauf des Kampfes verteilt, bei jedem Flammenschlag ein Stück weiter zur gegenüberliegenden bewegt werden. Die Nahkämpfer folgen dabei immer den Bewegungen des Main Tanks.
    * |cFFDBD533Gruppenstandort|r
Die Gruppe selbst steht auf einem Haufen am äußeren Rand des Gitterkreises (je nach Fähigkeitenreichweite auf außerhalb).
    * |cFFDBD533Schattengeizt-Zone|r
Wann immer ein Spieler den "Schädlichen Schattengeist" Debuff bekommt, muss er möglichst weit von anderen Spielern entfernt stehen, um diese nicht ebenfalls damit zu infizieren. Hierzu empfiehlt sich eine abgelegene Stelle im Westen der Dachterrasse.

Von dieser ersten Positionierung abgesehen, ist die Phase für die meisten Gruppenmitglieder relativ unspektakulär.

|cFF1DDD2FHeiler|r:
Ein Heiler sollte sich in dieser Phase um die Magier kümmern, welche sich um die schädlichen Schattengeister bekämpfen. Die restlichen Heiler achten darauf, dass der Main Tank nicht stirbt. Heilungen für die restliche Gruppe sind in dieser Phase eigentlich nicht von Nöten.

|cFF5D2B17Main Tank|r:
Die schwierigste Aufgabe dieser Phase fällt dem Main Tank zu. Er muss ständig auf Illidan Sturmgrimms Aktionen achten und diese entsprechend kontern. Wann immer sich Illidan in die Luft erhebt, wird ein Flammenschlag (blaue Kreise am Boden) folgen. Diese verursachen pro Tick 5.000 Feuerschaden. Daher muss Illidan ca. sieben Meter zur Seite gezogen werden. Abscheren ist ein anderthalbsekündiger Zauber, der direkt gegen den Main Tank gerichtet ist ihn sieben Sekunden lang 60% seiner Gesundheit raubt. Dieser Zauber muss daher unbedingt mit Schildblock gekontert werden. Gelingt es nicht, muss der Main Tank sofort sein letztes Gefecht oder Schildwall aktivieren. Bei allen Aktionen muss darauf geachtet werden, dass Illidan immer nach Norden (oder zumindest von der Gruppe weg) guckt. Der Tank muss sich als Einziger nicht explizit bewegen, wenn er den Schädlicher Schattengeist Debuff erhält.

|cFFDEDC30Nahkämpfer|r:
Die Nahkämpfer müssen sich immer hinter Illidan aufhalten, um so ebenfalls dem Seele anziehen zu entgehen. Selbstverständlich müssen sie zusätzlich auf die Flammenschlag kreise achten und diesen aus dem Weg gehen. So fern sich ein Krieger mit tödlichem Stoß in der Gruppe befindet, muss er ihn dauerhaft aufrecht erhalten, damit sich Illidan durch sein Seele anziehen möglichst wenig heilt. Steht dieser nicht zur Verfügung, müssen sich die Schurken mit Giften darum kümmern. Falls der Main Tank den schädlicher Schattengeist Debuff erhält, müssen sich alle Nahkämpfer umgehend von ihm und Illidan entfernen und den Magiern Platz machen.

|cFF03D7DFMagier|r:
Die zwei oder drei Magier müssen abwechselnd mit dem infizierten Spieler zum vorbestimmten Punkt laufen und dort die beiden schädlichen Schattengeister vernichten. Hierzu empfiehlt sich zunächst eine Frostnova und anschließend ein Drachenodem. Auf diese Weise können die Parasiten während ihrer Lebzeit keinen Schaden anrichten.

Priester:
Manarückgewinnung durch euren Schattengeist ist im gesamten Kampf sehr schwierig. An den Flammen der Phase zwei stirbt er sofort und auch Illidans Fähigkeiten erschweren ihm stark das Leben. Eine recht hohe Lebensdauer hat der Schattengeist jedoch wenn ihr ihn in dem Moment losschickt, in dem Illidan Seele anziehen wirkt (die Animation sieht aus wie von einem Schattenblitz).

|cff00ff00Phase 2|r (Flammen von Azzinoth)

Mit Erreichen der 65% Marke erhebt sich Illidan Sturmgrimm in die Luft und wird unangreifbar. Von dort aus schleudert er seine beiden Kriegsgleven gen Boden an den Rand des runden Gitters. Neben jeder Klinge erscheint daraufhin eine Flamme von Azzinoth, die von jeweils einem Tank in Feuerwiderstandsausrüstung gebunden und von der Schlachtgruppe weggedreht werden müssen.

Der Schlachtzug verteilt sich währenddessen in drei ungefähr gleichgroßen Gruppen von Norden nach Süden auf dem Gitter. Während den Schadensverursachern hier mal wieder die einfachste Aufgabe zufällt (sie müssen lediglich eine Flamme nach der anderen vernichten und sich dabei nicht bewegen), haben die Heiler schon etwas mehr zu tun. Neben dem normalen Schaden, welchen die Tanks durch die Flammen von Azzinoth erleiden und dem Feuerball-Schaden auf der Gruppe, müssen sie ebenfalls auf das dunkle Sperrfeuer achten und das Ziel sofort heilen (es bekommt 3.000 Schaden pro Sekunde).

|cFF1DDD2FHeiler|r:
Jeder der beiden Tanks muss von mindestens zwei Heilern am Leben gehalten werden. Sehr effektiv sind hier ein Paladin und ein Priester pro Tank und ein weiterer Druide, der beide mit Hots versorgt. Um die verbleibende Schlachtgruppe sollten sich vier Heiler kümmern. Hierfür sind wiederum Schamanen oder Priester die ideale Wahl. Sobald das dunkle Sperrfeuer einsetzt sollten sich alle Gruppenheiler auf dieses Ziel konzentrieren.

|cFF5D2B17Tanks|r:
Der Illidan Tank (ohne Feuerwiderstandsausrüstung) ist dieser Phase vollkommen nutzlos. Während er sich mit der restlichen Gruppe in der Mitte aufstellt, kann er auf Illidans Handlungen achten und diese über Sprachchat ansagen. Es ist für die beiden Tanks relativ wichtig zu wissen, bei wem das nächste Augenfeuer einsetzt.
Die beiden Feuerwiderstandstanks müssen sich die (auf der Karte markierten) Punkte einprägen, damit sie wissen wohin sie den Strahlen ausweichen können. Sie sollten sich grundlegend in einem Halbkreis langsam von Norden nach Süden bewegen. Hierzu steht ihnen der dickere Kreis außerhalb des Bodengitters zur Verfügung. Um dem Augenfeuer ausweichen zu können, müssen sie dann von der Außen- auf die Innenseite wechseln oder umgekehrt.

Unabhängig von den Flammen können die beiden Tanks ebenfalls das dunkle Sperrfeuer abbekommen. Wenn dieses geschieht sollten sie sofort Schildwall oder letztes Gefecht zünden, um die Schadensspitze kompensieren zu können.

|cFFDEDC30Nahkämpfer|r:
Während der ersten Versuche sollten sich Nahkämpfer in dieser Phase zurückhalten und bei der Gruppe bleiben. Wenn der Schlachtzug Übung in dem Kampf hat und genügend Heilung vorhanden ist, können sie sich ebenfalls an die Flammen von Azzinoth ran stellen.

|cff00ff00Phase 3|r

Wenn beide Flammen von Azzinoth vernichtet sind, setzt Fürst Illidan Sturmgrimm zur Landung in der Mitte des Metallgitters an. Er sollte dort vom Main Tank in Empfang genommen und anschließend wieder auf der gleichen Bahn wie in der ersten Phase gezogen werden.

Abgesehen vom "Peinigende Flammen" Angriff Illidans ist Phase 3 genau so wie Phase 1. Wegen diesem muss sich der ganze Schlachtzug weiträumig verteilen. Denn Spieler, die von diesem blauen leuchten erfasst sind erleiden für 60 Sekunden Feuerschaden und übertragen diesen auch auf andere Spieler in einem fünf Meter Radius um sie selbst.

Priester:
Priester können die kurze Landungsphase von Illidan dazu nutzen Mana zu regenerieren. Denn während er vom Main Tank an die endgültige Tankposition gezogen wird, werden dessen Spezialangriffe den Schattengeist noch nicht verletzen.

|cff00ff00Phase 4|r

Phase 3 und 4 wechseln sich von nun an immer wieder ab bis Illidans Gesundheit auf 30% sinkt. Der erste Wechsel findet 60 Sekunden nach Beginn von Phase 3 statt. Illidan Sturmgrimm verwandelt sich dabei in seine (schwarze) Dämonenform. Die Verwandlung in diese und zurück dauern jeweils zehn Sekunden. Die Dämonen-Phase selbst ist 40 Sekunden lang (mit Verwandlungen 60 Sekunden).

In dieser Form verhindert die Aura des Schreckens das sich Nahkämpfer Illidan nähern. Daher muss ein Hexenmeister ihn auf Distanz halten und mit Dots und Fernkampfzaubern Hass aufbauen.

Die restliche Schlachtgruppe sollte Illidan Sturmgrimm in dieser Phase relativ ignorieren. Die Priorität liegt stattdessen der Schadensbegrenzung des Flammenschlags und der Vernichtung der Schattendämonen.

Illidans Angriffe in dieser Phase verlaufen wie folgt:

    * 10. Sekunde: Erster Flammenschalg
    * 20. - 25. Sekunde: Schattendämonen erscheinen
    * 30. Sekunde: Zweiter Flammenschlag
    * 50. Sekunde: Dritter Flammenschlag
    * 60. Sekunde: Illidan hat wieder seine normale Form angenommen

|cFFDBD533Positionierung:|r
Alle Spieler distanzieren sich so weit wie möglich von Illidan weg und dabei auf einem Mindestabstand von fünf Metern zueinander. Besonders der Krieger-Main-Tank sollte in dieser Phase von ganz Vorne relativ weit nach hinten laufen (Einschreiten nutzen), da er in dieser Phase den geringsten Nutzen hat und sein Tod am Verherensten ist. Klassen mit Verlangsamungseffekten sollten in dieser Aufstellung generell etwas weiter Vorne aufgestellt sein, um diese möglichst schnell auf die Schattendämonen anwenden zu können.

Sobald Illidan seine Verwandlung in die Dämonenform vollzogen hat, verschießt er seinen ersten Flammenschlag, d.h. pro Spieler fliegt ein blauer Feuerball durch die Luft und schlägt auf diesen ein. Zehn Sekunden später erscheinen die vier Schattendämonen. Was jedem Spieler genügend Zeit gibt sich selbst durch einen Verband vom Flammenschlagschaden zu heilen. Jäger und Schamanen sollten spätestens jetzt ihre Frostfallen und Erdbindungstotem vor dem Spielerfeld aufstellen, um die Schattendämonen auszubremsen.

Ungefähr mit der 20. Sekunde können die Schattendämonen spawnen. Fernkämpfer können diese unter Feuer nehmen, sobald sie auf der Bildfläche erscheinen, so lange sie dabei den erforderlichen Abstand zu ihrem Nebemann wahren. Die Nahkämpfer sollten zunächst noch den zweiten Flammenschlag abwarten. Anschließend müssen die Schattendämonen von allen Spielern zerfeuert werden. Priorität hat hierbei logischerweise der Spieler mit der kürzesten Lebenslinie (also der Spieler, bei dem der Schattendämon am Nächsten ist). Wenn der Hexenmeister-Tank von einem Dämonen erfasst ist, hat er selbstverständlich die höchste Priorität.

Alle Dämonen sollten tot und jeder Spieler wieder an seiner Position sein, wenn der dritte und letzte Feuerschlag einsetzt. Anschließend beginnt erneut Phase 3.

|cFF861ABEHexenmeister-Tank|r:
Der Hexenmeister, welcher in dieser Phase Illidan an sich binden soll, kann sobald er auf die Knie sinkt und sich verwandelt Beginnen Dots und Sengenden Schmerz auf Illidan zu wirken. Es gibt zwar einen Hasslisten-Reset, sobald die Verwandlung vollzogen ist, aber die Dots stellen sicher, dass der Hexer nach dem Reset als erster die Aufmerksamkeit bekommt. Sobald der Spieler sich sicher ist mit Sengendem Schmerz ausreichend Hass aufgebaut zu haben, sollte er zum Selbstschutz übergehen. D.h. Schatten-Zauberschutz muss am Abklingzeitmaximum sein, Lebensentzug sollte immer Aufrechtgehalten werden (wenn geskillt) und ansonsten sollte überwiegend Blutsauger verwendet werden.
Er muss sich an der gegenüberliegenden Säule auf Maximalabstand zu Illidan aufhalten. Auf diese Weise ist er halbwegs sicher vor den Schattendämonen.

|cff00ff00Phase 5|r

In dem Moment, in dem Illidan Sturmgrimms Gesundheit auf 30% fällt, werden alle Schlachtzugmitglieder in dunkelblauen Kugeln (Schattengefängnis) eingeschlossen und für 30 Sekunden Handlungsunfähig gemacht. Während dieser Zeit greift Maiev Shadowsong in den Kampf ein und es läuft ein weiterer Dialog wie am Anfang des Kampfes ab.

Anmerkung: Aus früheren Patches bekannte Bugs, wie z.B. das ein schädlicher Schattengeist durch den Schlachtzug läuft und einen Spieler nach dem anderen infiziert oder Illidan in seiner Dämonenform verbuggt, gibt es aktuell nicht mehr. Stattdessen entfernt das Schattengefängnis alle negativen Effekte und verlängert gewissermaßen die aktuelle Phase. Falls Illidan also kurz vor der Verwandlung in einen Dämon stand, habt ihr danach wieder den Beginn der Phase 3 nur halt mit Maiev.

Wie am Anfang Akama hilft euch von hier an Maiev beim restlichen Kampf. Er schlägt auf Illidan ein und bringt ein weiteres Element in den Kampf ein: Fallen. Diese Fallen sind der einzige Weg Illidans Wutanfall zu stoppen. Falls Maiev eine Falle in der näheren Umgebung des Tanks ablegt, sollte dieser Illidan unbedingt da hinein ziehen. Fürst Sturmgrimm wird darin für zehn Sekunden gefangen und kann in dieser Zeit keinen Schaden anrichten, sehr wohl aber nehmen.

Liegen die Fallen zu weit entfernt, können sie genau so gut ignoriert werden. Der erhöhte Schaden durch den Wutanfall ist immer noch im heilbaren Bereich und die Gefahr, dass Illidans Seele Anziehen Fähigkeit in den Schlachtzug geht, ist dabei relativ hoch.

Kurz nach seinem Aufenthalt in der Falle wird Illidan sich wieder in einen Dämonen verwandeln und dem entsprechend seine Phase 4 Fähigkeiten annehmen. Der Wechsel zwischen Phase 4 und 5 geht so lange weiter von statten bis Illidan Sturmgrimm tot ist.
]]

--hier die Texte für den Trash

L["trash Naj'entus"] = [[

|cFF4DFFFDAqueouswoger|r

|cFFDBD533Fähigkeiten:|r
Giftblitzsalve: Schießt Gift auf den Feind, fügt ihm 2.000 Naturschaden und dann 6 Sekunden lang alle 2 Sekunden 1.000 Naturschaden zu.
|cFFDBD533Kontrollierbar durch:|r Verbannen, Betäubungseffekte
|cFFDBD533Taktik:|r Betäube die Woger, um der Giftplitzsalve vorzubeugen.

|cFF4DFFFDMeeresrufer der Echsennarbe|r

|cFFDBD533Fähigkeiten:|r
Gabelblitzschlag: Fügt Feinden in einem kegelförmigen Bereich vor der Meeresruferin 2.200 Naturschaden zu.
Hurrikan: Erzeugt einen wütenden Sturm im Zielgebiet, der allen in der Nähe befindlichen Feinden alle 3 Sekunden 1.665 bis 1935 Naturschaden zufügt und die Zeit zwischen Angriffen um 67% erhöht. Hält 20 Sekunden lang an, muss kannalisiert werden.
|cFFDBD533Kontrollierbar durch:|r Verwandeln, Betäubungseffekte, Verführen, Eiskältefalle
|cFFDBD533Taktik:|r Zunächst verwandeln.


|cFF4DFFFDGeneral der Echsennarbe|r

|cFFDBD533Fähigkeiten:|r
Donnernde Stimme: Erhöht 30 Sekunden lang das Nahkampfangriffstempo und verringert die Zauberzeit von in der Nähe befindlichen Verbündeten um 25%.
Freund befreien: Befreit ein in der Nähe befindliches Monster von bewegungseinschränkenden Effekten.
|cFFDBD533Kontrollierbar durch:|r immun
|cFFDBD533Taktik:|r Beseitige zuerst die Generäle!

|cFF4DFFFDZänker der Echsennarbe|r

|cFFDBD533Fähigkeiten:|r
Spalten: Fügt einem Fein und seinen nächsten Verbündeten 110% des normalen Nahkampfschadens zu (ca. 2500). Wirkt auf bis zu 3 Ziele.
Elektrische Sporen: Versetzt einen in der Nähe befindlichen Leviathan in Raserei und erhöht dessen Angriffstempo.
Blitzstoß: Schleudert einen Blitzschlag auf den Feind, der auf in der Nähe befindliche Gegner überspringt und jedem Ziel 2.275 bis 3.225 Naturschaden zufügt.
|cFFDBD533Kontrollierbar durch:|r immun
|cFFDBD533Taktik:|r Töte zuerst die Zänker und drehe sie von der Gruppe weg.

|cFF4DFFFDLeviathan|r

|cFFDBD533Fähikeiten:|r
Entkräftender Nebel: Schließt Gift auf einen Gegner und verringert 10 Sekunden lang den von ihm verusachten schaden und gewirkte Heilung um 50%.
Schwanzfeger: Fügt Feinden in einem Kegelförmigen Bereich hinter dem Leviathan 900 bis 1.500 Schaden zu und stößt sie zurück.
Giftspucken: Schießt Gift auf einen Gegner, fügt 2.000 Naturschaden zu, danach 10 Sekunden lang alle 5 Sekunden 2.500 Schaden.
|cFFDBD533Kontrollierbar durch:|r immun
|cFFDBD533Taktik:|r Der Tank benötigt viel Heilung.

|cFF4DFFFDAqueousbrut|r

Fähigkeiten:
Verschmelzen: Verschmilzt mit einem Aqueouslord und heilt diesen dadurch.
Schlammnova: Schießt Gift auf eine Gruppe von Feinden, fügt ihnen 2.000 Naturschaden und dann 9 Sekunden lang alle 3 Sekunden 900 Naturschaden zu. Verlansamt außerdem das Bewegungstempo der betroffenen Ziele um 20%.
Kontrollierbar durch: Verbannen, Betäubungseffekte
Taktik: Da die grünen Schleimbolzen ihre großen Brüder heilen, musst du aufpassen, wenn man sie im Kampf added. Sie respawnen alle 20 Minunten.

|cFF4DFFFDAqueouslord|r

|cFFDBD533Fähigkeiten:|r
Brechende Welle: Eine Welle von vergiftetem Wasser spült in einem Kegel von 65 Metern über Feinde hinweg und verursacht 2.313 bis 2.678 Naturschaden.
Übler Schleim: Verursachter Schaden und Heilung um 50% reduziert. Fügt außerdem alle 3 Sekunden 500 Natruschaden zu.
|cFFDBD533Kontrollierbar durch:|r immun
|cFFDBD533Taktik:|r Beschwört Aqueousbrut und ist immun gegen Spott

|cFF4DFFFDSterndeuterin der Echsennarbe|r

Fähigkeiten:
Heilige Nova: Verursacht eine Explosion göttlichen Lichts, fügt in der Nähe befindlichen Zielen 1.750 bis 2.250 Heiligschaden zu.
Wiederherstellung: Heilt einen Verbündeten 15 Sekunden lang alle 3 Sekunden um 9.250 bis 10.750 Lebenspunkte.
Kontrollierbar durch: Verwandeln, Betäubungseffekte, Verführen, Eiskältefalle
Taktik: Zunächst verwandeln

|cFF4DFFFDHarpunenkämpfer der Echsennarbe|r

|cFFDBD533Fähigkeiten:|r
Mal des Harpunenkämpfers: Legt das Mal des Harpunenkämpfers auf das Ziel. Dies zwingt alle in der Nähe befindlichen Drachenschildkröten dazu, sich auf den betroffenen zu konzentrieren.
|cFFDBD533Hakennetz:|r Macht in der Nähe befindliche Feinde 6 Sekundenlang bewegungsunfähig und verursacht 2.500 bis 3.000 Schaden.
|cFFDBD533Speerwurf:|r Wirft eine Waffe nach einem Feind und fügt 1.200 bis 1.700 Schaden zu.

|cFFDBD533Kontrollierbar durch:|r Verwandeln, Betäubungseffekte, Verführen, Eiskältefalle
|cFFDBD533Taktik:|r zunächst verwandeln.

|cFF4DFFFDDrachenschildkröte|r

|cFFDBD533Fähigkeiten:|r
Panzerschild: Reflektiert 50% des erlittenen Magieschadens. Hält 12 Sekunden lang an.
Wasser spucken: Schleudert ein wässriges Geschoss auf einen Feind und fügt 1.530 bis 1.870 Frostschaden zu.
|cFFDBD533Kontrollierbar durch:|r Verwandeln, Betäubungseffekte, Verführen, Eiskältefalle
|cFFDBD533Taktik:|r Begleiter des Harpunenkämpfers. Keine große Bedrohung, am besten zunächst verwandeln.

]]

L["trash Supremus"] = [[

|cFF4DFFFDArbeiter der Knochenmalmer|r

|cFFDBD533Fähigkeiten:|r
Hacke werfen: Fügt zwischen 300 und 500 Schaden zu und entwaffnet das Ziel.
|cFFDBD533Kontrollierbar durch:|r immun
|cFFDBD533Taktik:|r Benutze Flächenzauber, um die Arbeiter zu beseitigen.

|cFF4DFFFDSklaventreiber der Knochenmalmalmer|r

|cFFDBD533Fähigkeiten:|r
Aufgebracht: Der Sklaventreiber versetzt sich selbst in Rage und erhöht seinen Schaden um 200% sowie seine Maximale Gesundheit um 200%.
|cFFDBD533Kontrollierbar durch:|r immun
|cFFDBD533Taktik:|r Durch den MT beschäftigen

|cFF4DFFFDHimmelspirscher des Drachenmals|r

|cFFDBD533Fähigkeiten:|r
Feuerbrandpfeil: Schießt einen Flammenpfeil auf einen Feind und fügt 4.000 bis 4.500 Feuerschaden zu. Der Pfeil erzeugt außerdem eine Flammenwand, in deren Nähe Spieler zwischen 1.000 und 1.600 Feuerschaden erleiden.
|cFFDBD533Kontrollierbar durch:|r immun
|cFFDBD533Taktik:|r Hexer oder Jäger tanken diese Fliegenden Einheiten.

|cFF4DFFFDDrachenrufer des Drachenmals|r

|cFFDBD533Fähigkeiten:|r
Spalten: Fügt einem Fein und seinen nächsten Verbündeten 110% des normalen Nahkampfschadens zu (ca. 2500). Wirkt auf bis zu 3 Ziele.
Fixieren: Für 10 Sekunden sucht sich der Drachenrufer ein neues Ziel und greift dieses an. Nach den 10 Sekunden läuft er zu dem Ziel, was vorher die höchste Bedrohung hatte.
Stoß: Fügt etwa 2.313 bis 2.687 Schaden zu und stößt zurück.
|cFFDBD533Kontrollierbar durch:|r immun
|cFFDBD533Taktik:|r Die Heiler müssen auf denjenigen achten, der von dem Drachenrufer ins Visier genommen wird.

|cFF4DFFFDWindhäscher des Drachenmals|r

|cFFDBD533Fähigkeiten:|r
Verdammnisblitz: Schleidert einen Blitz aus dunkler Magie auf einen Feind und verursacht 2.250 bis 2.750 Schattenschaden sowie zusätlichen Schattenschaden gegen Feinde im Zielgebiet.
Feuerball: Fügt 1.530 bis 2.580 Feuerschaden sowie 3 Sekunden lang 200 Schaden pro Sekunde zu.
Eiskälte: Fügt Feinden im Umkreis von 15 Metern 2.220 bis 2.580 Frostschaden zu und friert sie 8 Sekunden lang ein.
|cFFDBD533Kontrollierbar durch:|r immun
|cFFDBD533Taktik:|r Dem Tank die Aggro nicht klauen!

|cFF4DFFFDFurchtwecker der Illidari|r

|cFFDBD533Fähigkeiten:|r
Illidariflammen: Fügt Feinden in einem Kegelfömigen Bereich vor dem Furchtwecker 2.850 bis 3.150 Feuerschaden zu.
Regen des Chaos: Lässt einen Schmelzregen niedegehen. Jeder betroffene Spieler erleidet 3.420 bis 3.780 Feuerschaden pro Sekunde.
Kriegsdonner: Fügt allen Spielern innerhalb von 30 Metern etwa 2.240 Schaden zu und betäubt sie für 3 Sekunden.
|cFFDBD533Kontrollierbar durch:|r immun
|cFFDBD533Taktik:|r Der Betroffene Berech des Regen des Chaos muss sofort verlassen werden.
]]

L["trash Akama"] = [[

|cFF4DFFFDZenturio der Illidari|r

|cFFDBD533Kontrollierbar durch:|r immun
|cFFDBD533Taktik:|r Mit dem Rücken zum Schlachtzug tanken, damit der Schallstoß keine Wirkung hat.

|cFF4DFFFDHerzsucher der Illidari|r

|cFFDBD533Kontrollierbar durch:|r Verbannen
|cFFDBD533Taktik:|r Fluch der Herzschinder macht das antanken nicht einfach, deshalb zuerst den Schänder der Illidari töten. Oder den Mob verbannen.

|cFF4DFFFDKnochenschnitter der Illidari|r

|cFFDBD533Kontrollierbar durch:|r Verbannen
|cFFDBD533Taktik:|r Diese nervigen Dämonen am besten verbannen.

|cFF4DFFFDSchänder der Illidari|r

|cFFDBD533Kontrollierbar durch:|r Verbannen
|cFFDBD533Taktik:|r Primärziel, da sie wenig Lebenspunkte haben und somit schnell das zeitliche segnen.

|cFF4DFFFDNachtlord der Illidari|r

|cFFDBD533Kontrollierbar durch:|r immun
|cFFDBD533Taktik:|r Da sie Furcht anwenden, muss aufgepasst werden, dass keine Spieler in andere Gruppen hineinlaufen, was in der Regel zu einem Wipe führt. Spieler die Fluch der Heilung auf sich haben, dürfen keinen Schaden machen bis er entfernt ist. Die Schattengeister am besten mit AoE vernichten.

|cFF4DFFFDKampflord der Aschenzungen|r

|cFFDBD533Kontrollierbar durch:|r immun
|cFFDBD533Taktik:|r Der erschütternde Schlag setzt den Tank für 5 Sekunden auser gefächt, weshalb er keinen Schildblock verwenden kann. Das Spalten macht ebenfalls enormen Schaden, außer dem Tank hält sich niemand vor dem Kampflord auf.

|cFF4DFFFDSturmrufer der Aschenzungen|r

|cFFDBD533Kontrollierbar durch:|r Verwandeln, Betäubungseffekte, Verführen, Eiskältefalle
|cFFDBD533Taktik:|r Durch seine niedrige Lebenspunktezahl lohnt sich das verwandeln nicht, tötet den Mob zuerst!

|cFF4DFFFDSturmzünder|r

|cFFDBD533Kontrollierbar durch:|r Verbannen
|cFFDBD533Taktik:|r Verbannt das nervige Elementar bis zum Schluss.

|cFF4DFFFDPrimalist der Aschenzungen|r

|cFFDBD533Kontrollierbar durch:|r immun
|cFFDBD533Taktik:|r Die Paladine sollten auf den Tank des Primalisten achten und ihn mit Segen der Freiheit von dem Weitreichenden Zurechtstutzen befreien.

|cFF4DFFFDWildgeist der Aschenzungen|r

|cFFDBD533Kontrollierbar durch:|r Eiskältefalle, Winterschlaf
|cFFDBD533Taktik:|r Den Wildgeist direkt nach dem Sturmrufer vernichten, da das nervige Tier andauernd Spieler anstürmt.

|cFF4DFFFDMystiger der Aschenzungen|r

|cFFDBD533Kontrollierbar durch:|r Verwandeln, Furcht, Verführen, Eiskältefalle
|cFFDBD533Taktik:|r Verwandelt diesen Mob.

|cFF4DFFFDPirscher der Aschenzungen|r

|cFFDBD533Kontrollierbar durch:|r Verwandeln, Furcht, Verführen, Eiskältefalle
|cFFDBD533Taktik:|r Am besten durch zwei Tanks beschäftigt, da die Schurken blenden einsetzen.

]]

L["trash Gorefiend"] = [[

|cFF4DFFFDHäscher des Schattenmondklans|r

|cFFDBD533Kontrollierbar durch:|r Verwandeln, Furcht, Verführen, Eiskältefalle
|cFFDBD533Taktik:|r Nur Nakampfklassen dürfen auf ihn Schaden machen, da er sonst mit hilfe der Zauberabsorbtion sich entlädt und das Mana aller umstehenden Spieler Verbrennt.

|cFF4DFFFDHeld des Schattenmondklans|r

|cFFDBD533Kontrollierbar durch:|r immun
|cFFDBD533Taktik:|r Der Tank dreht ihm vom Schlachtzug weg. Bei der Wirbelnden Klinge müssen alle aus der Reichweite des Helden.

|cFF4DFFFDHundemeister des Schattenmondklans|r

|cFFDBD533Kontrollierbar durch:|r immun
|cFFDBD533Taktik:|r Beim Pull sitzen die Hundemeister ab und ihr Kriegshund ist ein weiterer Gegner. Paladine wirken Segen der Freiheit auf den Tank, wegen des Zurechtstutzen. Der Raid muss sich aus der Salve bewegen.

|cFF4DFFFDReit- und Kriegshund des Schattenmondklans|r

|cFFDBD533Kontrollierbar durch:|r Verwandeln, Furcht, Verführen, Eiskältefalle
|cFFDBD533Taktik:|r Magier beschäftigen sie durch verwandeln.

|cFF4DFFFDBlutmagier des Schattenmondklans|r

|cFFDBD533Kontrollierbar durch:|r Verwandeln, Furcht, Verführen, Eiskältefalle
|cFFDBD533Taktik:|r der Nahkämpfer muss vom Raid weggedreht werden, da er sich sonst durch Bluttrinker wieder hochheilt.

|cFF4DFFFDGrunzer des Schattenmondklans|r

|cFFDBD533Kontrollierbar durch:|r Verwandeln, Furcht, Verführen, Eiskältefalle
|cFFDBD533Taktik:|r Sie sind keine Bedrohung da sie nur ca 32.000 Lebenspunkte besitzen, durch gezieltes Feuer fallen sie binnen Sekunden.

|cFF4DFFFDZornknochenschinder|r

|cFFDBD533Kontrollierbar durch:|r immun
|cFFDBD533Taktik:|r Ein Tank bindet den Schinder, der Schlachtzug befasst sich erst am Ende des Kampfes mit ihnen. Heiler achten auf das neue Ziel des Schinders wenn er Ignorieren wirkt.

|cFF4DFFFDWaffenmeister des Schattenmondklans|r

|cFFDBD533Kontrollierbar durch:|r immun
|cFFDBD533Taktik:|r Ein Tank kann ihn beschäftigen, vernichtet ihn erst, wenn alle andren Gegner besiegt sind.

|cFF4DFFFDSoldaten des Schattenmondklans|r

|cFFDBD533Kontrollierbar durch:|r immun
|cFFDBD533Taktik:|r Da sie nur 37.000 Lebenspunkte besitzen, zieht am besten ein Schutzpaladin in die Gruppe und anschließend beginnen die Fernkämpfer mit Flächenzaubern gegen die Soldatengruppe.

|cFF4DFFFDHand von Blutschatten|r

|cFFDBD533Kontrollierbar durch:|r immun
|cFFDBD533Taktik:|r Durch die Raserei sollten sich die Heiler auf hohe Schadensspitzen bei dem Tank einstellen.
]]

L["trash Bloodboil"] = [[

|cFF4DFFFDKlingenwüter der Knochenmalmer|r

|cFFDBD533Kontrollierbar durch:|r Verwandlung, Furcht, Eiskältefalle
|cFFDBD533Taktik:|r Vorsicht ist geboten, sobald der Klingenwüter den Wirbelwind aktiviert. Wegen der Gefahr ist er das erste Ziel.

|cFF4DFFFDBlutprophet der Knochenmalmer|r

|cFFDBD533Kontrollierbar durch:|r Verwandlung, Furcht, Eiskältefalle
|cFFDBD533Taktik:|r Zunächst verwandeln und sich am Ende des Kampfes mit ihnen beschäftigen.

|cFF4DFFFDSchildjünger der Knochenmalmer|r

|cFFDBD533Kontrollierbar durch:|r Verwandlung, Furcht, Eiskältefalle
|cFFDBD533Taktik:|r Sie teilen nicht viel Schaden aus, wenn noch ein Magier zum verwandeln vorhanden ist, sollte er das tun, an sonsten durch einen Tank beschäftigen und nach den Klingenwütern erledigen.

|cFF4DFFFDMutierter Kriegshund|r

|cFFDBD533Kontrollierbar durch:|r Verwandlung, Furcht, Eiskältefalle, Winterschlaf
|cFFDBD533Taktik:|r Druiden schicken die Hunde in Winterschlaf, vorsicht vor der Krankheitswolke, haltet euch von der Leiche des Hundes fern!

|cFF4DFFFDUngetüm der Knochenmalmer|r

|cFFDBD533Kontrollierbar durch:|r immun
|cFFDBD533Taktik:|r Es existieren zwei Versionen der Ungetüme. Eine Version verfügt über Sturmangriff des Ungetüms und Teufelsstapfen, die andre über feuriger Komet und Meteor. Bei der Variante mit Meteor bildet zwei Gruppen. Alle Nahkämpfer stehen beim Tank, so dass der Meteor möglichst viele Spieler trifft. Alle andren Klassen bilden die zweite Gruppe, dadurch trifft der Meteor nur eine der beiden Gruppen. Bei der andren Version bewegen sich die Fernkämpfer direkt zu den Nahkämpfern, dann kann Sturmangriff nicht gewirkt werden.

|cFF4DFFFDZuschauer der Knochenmalmer|r

|cFFDBD533Kontrollierbar durch:|r Verwandlung, Furcht, Eiskältefalle
|cFFDBD533Taktik:|r Durch Flächenschaden vernichten.

|cFF4DFFFDMutierter Muskelprotz|r

|cFFDBD533Kontrollierbar durch:|r immun
|cFFDBD533Taktik:|r Schlägt sehr schnell und hart zu. Der Tank muss dafür sorgen, dass kein anderer Spieler Schläge abbekommt, vernichtet den Muskelprotz erst wenn die anderen Mobs geschlagen sind.

|cFF4DFFFDKämpfer der Knochenmalmer|r

|cFFDBD533Kontrollierbar durch:|r immun
|cFFDBD533Taktik:|r Der Tank muss dafür sorgen, dass kein anderer Spieler Schläge abbekommt, vernichtet den Kämpfer erst wenn die anderen Mobs geschlagen sind.
]]

L["trash Souls"] = [[

|cFF4DFFFDKlingenwüter der Knochenmalmer|r

|cFFDBD533Kontrollierbar durch:|r Verwandlung, Furcht, Eiskältefalle
|cFFDBD533Taktik:|r Vorsicht ist geboten, sobald der Klingenwüter den Wirbelwind aktiviert. Wegen der Gefahr ist er das erste Ziel.

|cFF4DFFFDBlutprophet der Knochenmalmer|r

|cFFDBD533Kontrollierbar durch:|r Verwandlung, Furcht, Eiskältefalle
|cFFDBD533Taktik:|r Zunächst verwandeln und sich am Ende des Kampfes mit ihnen beschäftigen.

|cFF4DFFFDSchildjünger der Knochenmalmer|r

|cFFDBD533Kontrollierbar durch:|r Verwandlung, Furcht, Eiskältefalle
|cFFDBD533Taktik:|r Sie teilen nicht viel Schaden aus, wenn noch ein Magier zum verwandeln vorhanden ist, sollte er das tun, an sonsten durch einen Tank beschäftigen und nach den Klingenwütern erledigen.

|cFF4DFFFDZorniges Seelenfragment, Zehrendes Seelenfragment, Leidendes Seelenfragment|r

|cFFDBD533Kontrollierbar durch:|r immun
|cFFDBD533Taktik:|r Sie müssen bei jedem Bossangriff erneut vernichtet werden. Am besten mit Flächenschaden, mit etwas timing und Übung geht das Gefahrenlos.

]]

L["trash Mother Shahraz"]  = [[

|cFF4DFFFDTempelkonkubine, Bezaubernde Kurtisane|r

|cFFDBD533Kontrollierbar durch:|r Verwandlung, Furcht, Eiskältefalle
|cFFDBD533Taktik:|r Konzentriert nach kurzer Antankphase Flächenzauber auf diese Gegner konzentrieren und schickt sie damit massenweise über den Jordan.

|cFF4DFFFDVerzauberter Aufseher|r

|cFFDBD533Kontrollierbar durch:|r immun
|cFFDBD533Taktik:|r Einzeln nacheinander vernichten.

|cFF4DFFFDVersklavter Diener|r

|cFFDBD533Kontrollierbar durch:|r immun
|cFFDBD533Taktik:|r Haben keine Besonderen Fähigkeiten und werden zuerst vernichtet.

|cFF4DFFFDSchwester der Schmerzen, Schwester der Freuden|r

|cFFDBD533Kontrollierbar durch:|r immun
|cFFDBD533Taktik:|r Teilen sich die Lebenspunkte. Die Schwester der Schmerzen wird nur getankt, der Schlachtzug feuert ausschließlich auf die Schwester der Freuden. Die beiden müssen auf Abstand getankt werden, damit die Holy Nova nicht beide erreicht.

|cFF4DFFFDPriesterin der Lust|r

|cFFDBD533Kontrollierbar durch:|r immun
|cFFDBD533Taktik:|r Fluch der Vitalität so schnell wie möglich entfernen.

|cFF4DFFFDPriesterin des Deliriums|r

|cFFDBD533Kontrollierbar durch:|r immun
|cFFDBD533Taktik:|r Einzeln pullen. Die Heiler passen auf die Lebenspunkte des Schlachtzugs auf, Abbild erschaffen und Verwirrung stiften viel Verwirrung im Schlachtzug. Die Abbilder werden ignoriert, da sie nach 10 Sekunden verschwinden.

]]

L["trash Illidari Council"] = [[

Schildwache der Promenade

|cFFDBD533Kontrollierbar durch:|r immun
|cFFDBD533Taktik:|r Der Schlachtzug erleidet massivst Schaden. Zwei Heiler für den Tank einteilen, der Rest kümmert sich um den Schlachtzug. Spieler, die von der L4 Arkanen Ladund betroffen sind (weißer Lichtstrahl über dem Spieler) müssen sofort heraus laufen. Die Spieler die L5 Arkane Ladund auf sich haben, bekommen sofort ein Schild der Priester und werden umgehend hochgeheilt.

Kampfmagier der Illidari

|cFFDBD533Kontrollierbar durch:|r Verwandlung, Furcht, Eiskältefalle
|cFFDBD533Taktik:|r Zunächst verwandeln und darauf achten, dass sie niemals aus dem Schaf kommen.

Blutlord der Illidari

|cFFDBD533Kontrollierbar durch:|r immun
|cFFDBD533Taktik:|r Werden getankt bis der Archon vernichtet ist.

Auftragsmörder der Illidari

|cFFDBD533Kontrollierbar durch:|r Verwandlung, Furcht, Eiskältefalle
|cFFDBD533Taktik:|r Zunächst verwandeln. Vorsicht, durch ihre Schurkenfähigkeiten sind sie schwer zu tanken. Die Schadensverursacher sollten den Tanks auch Zeit zum antanken geben.

Archor der Illidari

|cFFDBD533Kontrollierbar durch:|r Verwandlung, Furcht, Eiskältefalle
|cFFDBD533Taktik:|r Es gibt zwei Varianten, einmal als Schattenpriester mit Gedankenschlag, Schattenwort: Tod und der Schattengestalt oder als Heiligpriester mit Heilen und Heilige Pein. Er ist immer das Primärziel.
]]

--ra text messages jede zeile durch \n getrennt
L["ra Naj'entus"] = "Jeder sollte mindestens 10.000 HP haben!\nHaltet die Frostschutztränke bereit\nVergesst nicht den Stachel aus eurem Nachbarn zu ziehen."
L["ra Supremus"] = "In Phase zwei Großen Abstand zu Supremus halten"
L["ra Akama"] = "Den Schurken verwandeln, die andren Adds vernichten.\nWenn der Schemen frei ist, vollen Schaden auf ihn konzentrieren."
L["ra Gorefiend"] = ""
L["ra Bloodboil"] = ""
L["ra Souls"] = ""
L["ra Mother Shahraz"] = ""
L["ra Illidari Council"] = ""
L["ra Illidan"] = ""

--button bezeichnungen
L["Channeler"] = "Kanalisierer"
L["Akama"] = "Akama"
L["die zone"] = "Sterbezone"
L["Bloodboil gr1"] = "Gruppe 1"
L["Bloodboil gr2"] = "Gruppe 2"
L["Bloodboil gr3"] = "Gruppe 3"
L["shadowzone"] = "Schattengeistzone"
L["healer range"] = "Heiler & Fernkämpfer"
L["Blades of Azzinoth"] = "Klingen von Azzinoth"
L["Flames of Azzinoth"] = "Flammen von Azzinoth"
L["Warlock Tank"] = "Hexertank"
L["Shadow Demon"] = "Schattendämonen"

--fontstrings
L["Phase1&2"] = "Phase 1 & 2"
L["Phase1"] = true
L["Phase2"] = true
L["Phase3&5"] = "Phase 3 & 5"
L["Phase4"] = true