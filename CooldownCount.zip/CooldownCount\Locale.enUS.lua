--[[ $Id: Locale.enUS.lua 76846 2008-06-16 15:15:09Z cremor $ ]]--

local L = LibStub("AceLocale-3.0"):NewLocale("CooldownCount","enUS", true)

L["Adjust icon shine scale."] = true
L["All settings are reset to default value."] = true
L["Common color"] = true
L["d"] = true
L["Font Color"] = true
L["Font Settings"] = true
L["Font Size"] = true
L["Font Style"] = true
L["h"] = true
L["Hide Blizzard Origin Animation"] = true
L["Hide Blizzard origin cooldown animation."] = true
L["Large font size for cooldown is longer than 10 seconds and less than 1 minutes."] = true
L["Large Size"] = true
L["m"] = true
L["Medium font size for cooldown is longer than 1 minute and less than 10 minutes."] = true
L["Medium Size"] = true
L["Minimum duration for display cooldown count."] = true
L["Minimum Duration"] = true
L["Misc"] = true
L["Reset"] = true
L["ResetDB_Confirm"] = true
L["Set cooldown value display font."] = true
L["Setup the common color for value display."] = true
L["Setup the warning color for value display."] = true
L["Shine Scale"] = true
L["Shine at finish cooldown"] = true
L["Small font size for cooldown is longer than 10 minutes."] = true
L["Small Size"] = true
L["Toggle icon shine display at finish cooldown."] = true
L["warning color"] = true
L["Warning font size for cooldown is less than 10 seconds."] = true
L["Warning Size"] = true
L["WhatIsCooldownCount"] = true
