﻿--[[
German]]
local L = LibStub("AceLocale-3.0"):NewLocale("kgPanels","deDE")
if not L then return end

--Artwork items
L["Delete from Library"] = "Aus der Bibliothek löschen"
L["Delete"] = "Löschen"
L["Are you sure?"] = "Sind Sie sicher?"
L["ART_PREVIEW"] = "Unten sehen Sie eine Vorschau der Grafiken die Sie gerade hinzugefügt haben. Wenn Sie die Grafiken nicht sehen, laden Sie bitte Ihr Interface neu, um sicherzustellen, dass sie im WoW-Pfad liegen."

-- Panel items
--L["OnLoad"] = true
L["Enter the script for OnLoad callback."] = "Geben Sie hier die Scripte für OnLoad Rückfragen ein."
--L["OnLeave"] = true
L["Enter the script for OnLeave callback."] = "Geben Sie hier die Scripte für OnLeave Rückfragen ein."
--L["OnEnter"] = true
L["Enter the script for OnEnter callback."] = "Geben Sie hier die Scripte für OnEnter Rückfragen ein."
--L["OnHide"] = true
L["Enter the script for OnHide callback."] = "Geben Sie hier die Scripte für OnHide Rückfragen ein."
--L["OnShow"] = true
L["Enter the script for OnShow callback."] = "Geben Sie hier die Scripte für OnShow Rückfragen ein."
--L["OnUpdate"] = true
L["Enter the script for OnUpdate callback."] = "Geben Sie hier die Scripte für OnUpdate Rückfragen ein."
--L["OnEvent"] = true
L["Enter the script for OnEvent callback."] = "Geben Sie hier die Scripte für OnEvent Rückfragen ein."
L["Scripts"] = "Scripte"
