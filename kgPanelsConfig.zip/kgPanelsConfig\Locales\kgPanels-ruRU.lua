﻿--[[
Russian
]]
local L = LibStub("AceLocale-3.0"):NewLocale("kgPanels","ruRU")
if not L then return end
