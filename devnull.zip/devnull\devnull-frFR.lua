AceLibrary("AceLocale-2.2"):new("devnull"):RegisterTranslations("frFR", function() return {
	["enabled"] = "activ�",
	["disabled"] = "non activ�",
} end)
