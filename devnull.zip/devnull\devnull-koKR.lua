AceLibrary("AceLocale-2.2"):new("devnull"):RegisterTranslations("koKR", function() return {
	["enabled"] = "활성화하는",
	["disabled"] = "군대를 해산하는",
} end)
