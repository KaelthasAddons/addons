AceLibrary("AceLocale-2.2"):new("devnull"):RegisterTranslations("zhCN", function() return {
	["enabled"] = "激活",
	["disabled"] = "撤销",
} end)
