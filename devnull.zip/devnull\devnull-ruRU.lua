AceLibrary("AceLocale-2.2"):new("devnull"):RegisterTranslations("ruRU", function() return {
	["enabled"] = "активировано",
	["disabled"] = "выключено",
} end)
