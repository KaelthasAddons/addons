local L = AceLibrary("AceLocale-2.2"):new("FuBar_MicroMenuFu")

L:RegisterTranslations("deDE", function() return {
    ["Button Spacing"]                              = "Taste Abstand",
    ["Button Visibility"]                           = "Taste Sicht",
    ["Set Button Spacing"]                          = "Einstellen Taste Abstand",
    ["Toggle Button Visibility"]                    = "Toggle-Taste Sicht",
    ["Toggle visibility of %s"]                     = "Toggle-Sicht von %s",
} end)
