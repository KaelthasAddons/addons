﻿local L = AceLibrary("AceLocale-2.2"):new("FuBar_MicroMenuFu")

L:RegisterTranslations("ruRU", function() return {
    ["Toggle visibility of %s"] = "Переключить отображение кнопки %s",
    ["Button Visibility"] = "Кнопки",
    ["Toggle Button Visibility"] = "Включение/отключение кнопок меню",
    ["Button Spacing"] = "Интервал между кнопками",
    ["Set Button Spacing"] = "Установка интервала между кнопками",
} end)
