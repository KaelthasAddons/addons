﻿local L = AceLibrary("AceLocale-2.2"):new("FuBar_MicroMenuFu")

L:RegisterTranslations("zhTW", function() return {
    ["Toggle visibility of %s"] = "顯示/隱藏「%s」",
    ["Button Visibility"] = "按鈕顯示",
    ["Toggle Button Visibility"] = "顯示/隱藏按鈕",
    ["Button Spacing"] = "按鈕間距",
    ["Set Button Spacing"] = "設定按鈕之間的間隔",
} end)
