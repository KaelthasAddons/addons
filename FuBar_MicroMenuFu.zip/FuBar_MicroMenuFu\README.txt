FuBar - Micro MenuFu v2.0
Author: ckknight (ckknight@gmail.com)

Shows the micro menu on FuBar.

TO INSTALL: Put the FuBar_MicroMenuFu folder into
	\World of Warcraft\Interface\AddOns\

If you find _any_ bugs, feel free to submit them at
http://ckknight.wowinterface.com/portal.php?id=54&a=listbugs

If you want to request any features, feel free to submit your ideas at
http://ckknight.wowinterface.com/portal.php?id=54&a=listfeatures