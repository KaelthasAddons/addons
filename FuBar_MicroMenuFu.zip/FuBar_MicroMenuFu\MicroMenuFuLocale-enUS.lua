local L = AceLibrary("AceLocale-2.2"):new("FuBar_MicroMenuFu")

L:RegisterTranslations("enUS", function() return {
    ["Toggle visibility of %s"] = true,
    ["Button Visibility"] = true,
    ["Toggle Button Visibility"] = true,
    ["Button Spacing"] = true,
    ["Set Button Spacing"] = true,
} end)
