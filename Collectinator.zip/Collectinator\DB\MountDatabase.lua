﻿--[[
****************************************************************************************
MountDatabase.lua
$Date: 2008-09-18 11:57:13 -0400 (Thu, 18 Sep 2008) $
$Rev: 81845 $

Author: Ackis on Illidan US Horde

****************************************************************************************
]]--

local addon = Collectinator

local BFAC		= LibStub("LibBabble-Faction-3.0"):GetLookupTable()
local BZONE		= LibStub("LibBabble-Zone-3.0"):GetLookupTable()
local BBOSS		= LibStub("LibBabble-Boss-3.0"):GetLookupTable()

-- Adds all mini-pets, by spell ID to the local database.

function addon:MakeMountTable()

	self:Print("Populating mount list.")

end
