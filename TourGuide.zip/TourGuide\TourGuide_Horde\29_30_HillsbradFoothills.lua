TourGuide:RegisterGuide("Hillsbrad Foothills (29-30)", "Arathi Highlands (30)", "Horde", function()
return [[
F Orgrimmar
h Orgrimmar

R Hillsbrad Foothills |N|Take the zeppelin outside Orgrimmar to Undercity.  Run down thru Silverpine.|
A Time To Strike |N|You get this at Southpoint Tower (20,47) as soon as you enter Hillsbrad| |QID|494| |NODEBUG|

R Tarren Mill
T Time To Strike |QID|494| |NODEBUG|
f Grab flight point
A Regthar Deathgate |QID|1361|
A The Hammer May Fall |QID|676|
]]
end)
