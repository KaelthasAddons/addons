TourGuide:RegisterGuide("Burning Steppes (53-54)", "Felwood (54)", "Horde", function()
return [[
F Burning Steppes
A Broodling Essence |QID|4726|
A Tablet of the Seven |QID|4296|

C Broodling Essence |N|To the East, grind on the dragon whelps| |QID|4726|

A A Taste of Flame |N| In the cave (94,31)| |QID|4024|
T A Taste of Flame |QID|4024|
T Dreadmaul Rock |N| At (79,45)| |QID|3821|
A Krom'Grul |QID|3822|

C Krom'Grul |N| He has two spawn points in either cave| |QID|3822|
C The Rise of the Machines (Part 1) |QID|4061|
C Tablet of the Seven |N| Loc: (54,40)| |QID|4296|

T Tablet of the Seven |QID|4296|
T Broodling Essence |QID|4726|
A Felnok Steelspring |QID|4808|

F Kargath
T Krom'Grul |QID|3822|
T The Rise of the Machines (Part 1) |QID|4061|
A The Rise of the Machines (Part 2) |QID|4062|
C The Rise of the Machines (Part 2) |QID|4062|
T The Rise of the Machines (Part 2) |N|In the Badlands (25,44)| |Z|Badlands| |QID|4062|

H The Crossroads
F Orgrimmar
T Bone-Bladed Weapons |N|(52,34)| |Z|Orgrimmar| |QID|4300|
]]
end)
