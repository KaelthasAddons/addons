TourGuide:RegisterGuide("Stonetalon Mountains (27)", "Thousand Needles (27-29)", "Horde", function()
return [[
F Sun Rock Retreat
T Ordanus |N|Skip "The Den"| |QID|1088|
h Sun Rock Retreat
A Bloodfury Bloodline |QID|6283|

C Bloodfury Bloodline |N|Kill Bloodfury Ripper (30,63), grinding along the way.| |QID|6283|

H Sun Rock Retreat
T Bloodfury Bloodline |QID|6283|

F Thunder Bluff
T The Sacred Flame (Part 1) |QID|1195|
A The Sacred Flame (Part 2) |QID|1196|
]]
end)

