TourGuide:RegisterGuide("Thousand Needles (37)", "Dustwallow Marsh (37-38)", "Horde", function()
return [[
F Orgrimmar |N|Take the zeppelin, dur!|
B Delicious Cave Mold |L|4607 5| |N|From Kor'jus in the Cleft of Shadow (49.35, 52.85)| |C|Hunter|
T Alliance Relations (Part 4) |N|Keldran in the Valley of Spirits (21,53)| |QID|1436| |Z|Orgrimmar|
F The Crossroads
h The Crossroads
F Freewind Post

N Stable Pet |C|Hunter|

T The Swarm Grows (Part 2) |N|In The Shimmering Flats| |QID|1146|
A The Swarm Grows (Part 3) |QID|1147|

P Bite (Rank 5) |N|Tame a Sparkleshell Snapper in Shimmering Flats and feed him those mushrooms you bought.| |C|Hunter|
N Keep the turtle |C|Hunter|

T Parts for Kravel |QID|1112| |N|At the Mirage Raceway (77.8, 77.2)|
A Delivery to the Gnomes |QID|1114|
T Delivery to the Gnomes |QID|1114|
T Goblin Sponsorship (Part 5) |QID|1183|

A The Eighteenth Pilot |QID|1186|
T The Eighteenth Pilot |QID|1186|

A Razzeric's Tweaking |QID|1187|
T Encrusted Tail Fins |QID|1107|
A The Rumormonger |QID|1115|

A Parts of the Swarm (Part 1) |U|5877| |N|Kill silithid to the south until the item drops to start this.| |QID|1148|
C The Swarm Grows (Part 3) |N|You must kill the Drones in order for the Invaders to spawn.| |QID|1147|
C Parts of the Swarm (Part 1) |QID|1148|
T The Swarm Grows (Part 3) |QID|1147|

H The Crossroads
N Abandon the turtle |N|If you want to| |C|Hunter|

T Parts of the Swarm (Part 1) |QID|1148|
A Parts of the Swarm (Part 2) |QID|1184|
]]end)
