TourGuide:RegisterGuide("Thousand Needles (31-32)", "Desolace (32-34)", "Horde", function()
return [[
H Orgrimmar
F The Crossroads
A The Swarm Grows (Part 1) |N|From Korran, west of windrider (51.1, 29.6)| |Z|The Barrens| |QID|1145|
T Regthar Deathgate |N|West of the Crossroads in the bunkers (45.3, 28.4)| |QID|1361|
A The Kolkar of Desolace |N|West of Crossroads in the bunkers (45.3, 28.4)| |Z|The Barrens| |QID|1362|

R Shimmering Flats |N|Run back to Crossroads and fly down to Thousand Needles|
A Hemet Nesingwary Jr. |N|From Kravel Koalbeard (77.8, 77.2)| |QID|5762|
A Wharfmaster Dizzywig |QID|1111|
A A Bump in the Road |QID|1175|
A Hardened Shells |QID|1105|
A Load Lightening |QID|1176|
A Rocket Car Parts |QID|1110|
A Salt Flat Venom |QID|1104|

C A Bump in the Road |QID|1175|
C Hardened Shells |QID|1105|
C Load Lightening |QID|1176|
C Rocket Car Parts |QID|1110|
C Salt Flat Venom |QID|1104|

T A Bump in the Road |QID|1175|
T Hardened Shells |QID|1105|
T Load Lightening |QID|1176|
A Goblin Sponsorship (Part 1) |QID|1178|
T Rocket Car Parts |QID|1110|
T Salt Flat Venom |N|Skip the follow-up| |QID|1104|
A Martek the Exiled |QID|1106|
A Encrusted Tail Fins |N|Nonelite again!| |QID|1107|

R Gadgetzan
f Grab flight point
]]
end)
