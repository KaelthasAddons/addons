TourGuide:RegisterGuide("No Guide", nil, "Alliance", function() return "K No guide loaded... |N|Click to select a guide|" end)
TourGuide:RegisterGuide("No Guide", nil, "Horde", function() return "K No guide loaded... |N|Click to select a guide|" end)
