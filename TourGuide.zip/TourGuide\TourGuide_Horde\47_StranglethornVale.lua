TourGuide:RegisterGuide("Stranglethorn Vale (47)", "Searing Gorge (47-48)", "Horde", function()
return [[
F Booty Bay |N|via zeppelin to Grom'gol|
A The Bloodsail Buccaneers (Part 5) |T| |QID|608|
A Whiskey Slim's Lost Grog |T| |QID|580|
h Booty Bay |T|
T Back to Booty Bay |T| |QID|1118|
T Deliver to MacKinley |T| |QID|2874|
A The Captain's Chest |T| |QID|614|

C The Captain's Chest |N|On the beach east of Booty Bay, head north when you reach the sea (36.3,69.7)| |QID|614|
N Loot the bottles on the beach |L|4098|
A Message in a Bottle (Part 1) |U|4098| |QID|594|
T Message in a Bottle (Part 1) |N|On the large island east of Booty Bay (38.5, 80.6)| |QID|594|
A Message in a Bottle (Part 2) |QID|630|
C Message in a Bottle (Part 2) |N|South-east side of the island (40.4, 82.7)| |QID|630|
T Message in a Bottle (Part 2) |QID|630|
C The Bloodsail Buccaneers (Part 5) |N|In the three ships off the coast - make sure to check downstairs in each one for the riddle.| |QID|608|
A Cortello's Riddle (Part 1) |N|Check downstairs in the ships, scroll is usually in the middle ship.| |U|4056| |QID|624|

H Booty Bay
T The Bloodsail Buccaneers (Part 5) |T| |QID|608|
T The Captain's Chest |T| |QID|614|
N Before you leave...  |N|Make sure you have a stack of Silk Cloth|
]]
end)
