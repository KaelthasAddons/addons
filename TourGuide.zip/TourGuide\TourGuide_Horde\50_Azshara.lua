
TourGuide:RegisterGuide("Azshara (50)", "The Hinterlands (50-51)", "Horde", function()
return [[
F Orgrimmar
h Orgrimmar

F Azshara
A Stealing Knowledge |QID|3517|
C Stealing Knowledge |N|At Ruins of Eldarath (36,54)| |QID|3517|
C Seeping Corruption (Part 1) |N|Tide Pools at: 1-(47,61) 2-(47,51) 3-(48,48) 4-(47,46)| |QID|3568|
T Stealing Knowledge |QID|3517|
A Delivery to Archmage Xylem |QID|3561|
A Delivery to Magatha |QID|3518|
A Delivery to Jes'rimon |QID|3541|
A Delivery to Andron Gant |QID|3542|
T Delivery to Archmage Xylem |N|Take teleporter at (28,50)| |QID|3561|
A Xylem's Payment to Jediga |QID|3565|

F Thunder Bluff
T Delivery to Magatha |N|Elder Rise| |QID|3518|
A Magatha's Payment to Jediga |QID|3562|

H Orgrimmar
T Rise of the Silithid |N|at (56,46)| |Z|Orgrimmar| |QID|32|
A March of the Silithid |QID|4494|
T Delivery to Jes'rimon |N|at (55,34)| |Z|Orgrimmar| |QID|3541|
A Jes'rimon's Payment to Jediga |QID|3563|
A Bone-Bladed Weapons |QID|4300|

F Undercity
T Delivery to Andron Gant |N|Apothecarium Quarter| |QID|3542|
A Andron's Payment to Jediga |QID|3564|
T Seeping Corruption (Part 1) |QID|3568|
A Vivian Lagrave |QID|4133|
A Seeping Corruption (Part 2) |QID|3569|
T Seeping Corruption (Part 2) |QID|3569|
A A Sample of Slime... |QID|4293|
A ... and a Batch of Ooze |QID|4294|
]]
end)
