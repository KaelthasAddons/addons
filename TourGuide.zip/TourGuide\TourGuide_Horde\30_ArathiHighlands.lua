TourGuide:RegisterGuide("Arathi Highlands (30)", "Stranglethorn Vale (30-31)", "Horde", function()
return [[
R Arathi Highlands
R Hammerfall |N|Northeast corner of zone (73,36)|
A Hammerfall |QID|655|
T Hammerfall |QID|655|
A Raising Spirits (Part 1) |QID|672|
f Grab flight point

C Raising Spirits (Part 1) |N|West of Hammerfall (64,37)| |QID|672|

T Raising Spirits (Part 1) |QID|672|
A Raising Spirits (Part 2) |QID|674|
T Raising Spirits (Part 2) |QID|674|
A Raising Spirits (Part 3) |QID|675|
T Raising Spirits (Part 3) |N|Skip the follow-up| |QID|675|
]]
end)
