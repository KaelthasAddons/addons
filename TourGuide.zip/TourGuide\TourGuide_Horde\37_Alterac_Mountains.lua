TourGuide:RegisterGuide("Alterac Mountains (37)", "Thousand Needles (37)", "Horde", function()
return [[
F Tarren Mill
A Prison Break In |N|From Magus Wordeen Voidglare (61.6, 20.9)| |Z|Hillsbrad Foothills| |NODEBUG| |QID|544| |NODEBUG|
A Stone Tokens |N|From Keeper Bel'varil| |QID|556|
A The Crown of Will |QID|521|
C Frostmaw |N|(37,69) up north| |QID|1136|
C The Crown of Will |N|At Ruins of Alterac (40,50)| |QID|521|

C Stone Tokens |N|At Dalaran (20,85)| |Z|Hillsbrad Foothills| |QID|556|
C Prison Break In |N|At (20,85)| |QID|544| |NODEBUG|
T Prison Break In |QID|544| |NODEBUG|
T Stone Tokens |QID|556|
T The Crown of Will |N|Skip part 2| |QID|521|

F Undercity
T To Steal From Thieves |NODEBUG| |QID|1164|
]]
end)
