
TourGuide:RegisterGuide("The Barrens (22-23)", "Stonetalon Mountains (23-25)", "Horde", function()
return [[
F Camp Taurajo
N Get pet from stable |C|Hunter| |T|
T Jorn Skyseer |T| |O| |QID|3261|
A Ishamuhale |T| |O| |PRE|Jorn Skyseer| |QID|882|
h Camp Taurajo |T|
A Weapons of Choice |T| |QID|893|

C Egg Hunt |QID|868|
C Betrayal from Within (Part 1) |QID|879|
C Weapons of Choice |QID|893|
A Gann's Reclamation |QID|843|
C Gann's Reclamation |QID|843|
T Gann's Reclamation |QID|843|
A Revenge of Gann (Part 1) |QID|846|

H Camp Taurajo
T Weapons of Choice |T| |QID|893|
T Betrayal from Within (Part 1) |T| |QID|879|
A Betrayal from Within (Part 2) |T| |QID|906|

F The Crossroads
T Betrayal from Within (Part 2) |T| |QID|906|
T Egg Hunt |T| |QID|868|

C Ishamuhale |N|Kill a Zhevra to get a carcas, then use it at the tree northwest of Ratchet (60,32) to summon the raptor.| |O| |PRE|Jorn Skyseer| |QID|882|

T Further Instructions (Part 1) |N|Down in Ratchet| |T| |QID|1094|
A Further Instructions (Part 2) |T| |QID|1095|
T Deepmoss Spider Eggs |O| |T| |QID|1069|

]]
end)

