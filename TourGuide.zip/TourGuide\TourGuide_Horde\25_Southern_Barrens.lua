TourGuide:RegisterGuide("The Barrens (25)", "Thousand Needles (25-26)", "Horde", function()
return [[
F Camp Taurajo
T Ishamuhale |O| |QID|882|
A Enraged Thunder Lizards |O| |PRE|Ishamuhale| |QID|907|
h Camp Taurajo
A A New Ore Sample |QID|1153|
C Enraged Thunder Lizards |O| |PRE|Ishamuhale| |QID|907|
C Revenge of Gann (Part 1) |N|Keel two dorfs at Bael'dun Keep (49,84), it'll make you feel alright.| |QID|846|
T Revenge of Gann (Part 1) |QID|846|
A Revenge of Gann (Part 2) |QID|849|
C Revenge of Gann (Part 2) |N|Blow up the Flying Machine (47,85)| |QID|849|
T Revenge of Gann (Part 2) |QID|849|
R The Great Lift
T Calling in the Reserves |QID|5881|
A Message to Freewind Post |QID|4542|
]]
end)

