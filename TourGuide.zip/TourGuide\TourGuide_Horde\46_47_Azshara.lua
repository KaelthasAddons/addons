TourGuide:RegisterGuide("Azshara (46-47)", "Stranglethorn Vale (47)", "Horde", function()
return [[
F Splintertree Post |N|Ashenvale|
R Azshara |N|Go east dur!|

A Spiritual Unrest |N|To the south of the road as you enter the zone (11.4,78.2)| |QID|5535|
A A Land Filled with Hatred |QID|5536|
C Spiritual Unrest |N|Ghosts in the ruins north of the road (17,66)| |QID|5535|
C A Land Filled with Hatred |N|Further north, more ruins containing satyrs (20,62)| |QID|5536|
T Spiritual Unrest |QID|5535|
T A Land Filled with Hatred |QID|5536|

R Valormok |N|North of the road, on the mountain's edge (21,52)|
T Betrayed |QID|3507|

H Orgrimmar
F Undercity
A Seeping Corruption (Part 1) |N|Apothecarium Quarter| |QID|3568|
A Errand for Apothecary Zinge (Part 1) |QID|232|
T Errand for Apothecary Zinge (Part 1) |N|Out in other room| |QID|232|
A Errand for Apothecary Zinge (Part 2) |QID|238|
T Errand for Apothecary Zinge (Part 2) |QID|238|
A Into the Field |QID|243|
]]
end)
