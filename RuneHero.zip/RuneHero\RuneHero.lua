local runePowerStatusBar;
local runePowerStatusBarDark;
local runePowerStatusBarText;

--Readability == win
local RUNETYPEC_BLOOD = 1;
local RUNETYPEC_UNHOLY = 2;
local RUNETYPEC_FROST = 3;
local RUNETYPEC_CHROMATIC = 4;

local runeY = {
	[1] = -5,
	[2] = -20,
	[3] = -35,
	[4] = -50,
	[5] = -65,
	[6] = -80
}

local runeX = 65;

RuneHero_Saved = {
	anchor = "BOTTOM",
	parent = "UIParent",
	rel = "BOTTOM",
	x = 0;
	y = 135;
};

function RunePower_Event ()

--	local mana = UnitMana("player");

--	local Xperc;
--	local Yperc;

--	if (mana == 100) then 
--		Xperc = .5;
--	elseif (mana < 30) then
--		Xperc = 0;
--	else
--		Xperc = 0.5 * math.fmod( math.floor( mana / 10 ), 2 );
--	end



--	if (mana < 50) then 
--		if (mana < 30) then
--			Yperc = 0;
--		else
--			Yperc = .25;
--		end
--	else
--		if (mana < 75) then
--			Yperc = .5;
--		else
--			Yperc = .75;
--		end
--	end

--	RuneBladeGlow:SetTexCoord( Xperc, Xperc + .5, Yperc, Yperc + .25);
end

function RuneButtonC_OnLoad (self)
	RuneFrameC_AddRune(RuneFrameC, self);
	
	self.rune = getglobal(self:GetName().."Rune");
	self.border = getglobal(self:GetName().."Border");
	self.texture = getglobal(self:GetName().."BorderTexture");
	self.bg = getglobal(self:GetName().."BG");

	self.border = getglobal(self:GetName().."Border");

	RuneButtonC_Update(self);

	self:SetScript("OnUpdate", RuneButtonC_OnUpdate);

	self:SetFrameLevel( self:GetFrameLevel() + 2*self:GetID() );
	self.border:SetFrameLevel( self:GetFrameLevel() + 1 );
end

function RuneButtonC_OnUpdate (self, elapsed)

	local start, duration, r = GetRuneCooldown(self:GetID());

	if (r) then
		self:SetPoint("TOPLEFT", "RuneFrameC", "TOPLEFT", runeX, runeY[self:GetID()] );
	else
		local remain = (duration - GetTime() + start) / duration;
		if ( remain < 0) then 
			self:SetPoint("TOPLEFT", "RuneFrameC", "TOPLEFT", runeX, runeY[self:GetID()] );
		else
			self:SetPoint("TOPLEFT", "RuneFrameC", "TOPLEFT", runeX + remain*(RuneFrameC:GetWidth()-138), runeY[self:GetID()] );
		end
	end
end

function RuneButtonC_Update (self, rune)

	--rune = rune or self:GetID();

local runeType = GetRuneType(self:GetID());

	if (runeType == RUNETYPEC_BLOOD) then
		self.rune:SetTexture("Interface\\PlayerFrame\\UI-PlayerFrame-Deathknight-Blood-On.tga" );

		self.texture:SetDesaturated(false);
		--self.texture:SetTexture("Interface\\CHARACTERFRAME\\TotemBorder");
		--self.texture:SetVertexColor(1,0,0,1);
		self.texture:SetTexture("Interface\\AddOns\\RuneHero\\textures\\Ring-test.tga");
		self.texture:SetVertexColor(.65,0,0,1);

		

		self.bg:SetVertexColor(.2,.2,.2,1);

		self.rune:SetWidth(15);	
		self.rune:SetHeight(15);

		self.bg:SetWidth(17);	
		self.bg:SetHeight(17);

		self.border:SetWidth(29);
		self.border:SetHeight(29);

	elseif (runeType == RUNETYPEC_UNHOLY) then
		--self.rune:SetTexture("Interface\\PlayerFrame\\UI-PlayerFrame-Deathknight-Death-On.tga" );
		self.rune:SetTexture("Interface\\PlayerFrame\\UI-PlayerFrame-Deathknight-Unholy");
		self.rune:SetVertexColor(0,1,0);

		self.texture:SetTexture("Interface\\AddOns\\RuneHero\\textures\\Ring-test.tga");
		self.texture:SetDesaturated(false);
		--self.texture:SetVertexColor(.25,1,0,1);
		self.texture:SetVertexColor(0,.65,0,1);


		self.bg:SetVertexColor(.2,.2,.2,1);

		--self.rune:SetWidth(15);
		--self.rune:SetHeight(15);
		self.rune:SetWidth(25);
		self.rune:SetHeight(25);

		self.bg:SetWidth(17);	
		self.bg:SetHeight(17);

		self.border:SetWidth(29);
		self.border:SetHeight(29);

	elseif (runeType == RUNETYPEC_FROST) then
		--self.rune:SetTexture("Interface\\PlayerFrame\\UI-PlayerFrame-Deathknight-Frost-On.tga" );
		self.rune:SetTexture("Interface\\PlayerFrame\\UI-PlayerFrame-Deathknight-Frost" );

		self.texture:SetTexture("Interface\\AddOns\\RuneHero\\textures\\Ring-test.tga");
		self.texture:SetDesaturated(false);
		self.texture:SetVertexColor(0,.3,1,1);

		self.bg:SetVertexColor(.2,.2,.2,1);

		--self.rune:SetWidth(15);
		--self.rune:SetHeight(15);
		self.rune:SetWidth(25);
		self.rune:SetHeight(25);
		
		self.bg:SetWidth(17);	
		self.bg:SetHeight(17);

		self.border:SetWidth(29);
		self.border:SetHeight(29);
	elseif (runeType == RUNETYPEC_CHROMATIC) then
		self.rune:SetTexture("Interface\\PlayerFrame\\UI-PlayerFrame-DeathKnight-Chromatic-On.tga" );
		self.rune:SetVertexColor(1,1,1);

		self.texture:SetTexture("Interface\\CHARACTERFRAME\\TotemBorder");
		self.texture:SetDesaturated(true);

		self.rune:SetWidth(20);
		self.rune:SetHeight(20);

		self.bg:SetWidth(20);	
		self.bg:SetHeight(20);

		self.border:SetWidth(39);
		self.border:SetHeight(39);
	end
	
	
end

function RuneFrameC_OnLoad (self)

	-- Disable rune frame if not a death knight.
	local _, class = UnitClass("player");
	
	if ( class ~= "DEATHKNIGHT" ) then
		self:Hide();
	end
	
	self:RegisterEvent("PLAYER_ENTERING_WORLD");
	self:RegisterEvent("RUNE_TYPE_UPDATE");
	self:RegisterEvent("RUNE_POWER_UPDATE");
	self:RegisterEvent("RUNE_REGEN_UPDATE");
	self:RegisterEvent("COMBAT_LOG_EVENT");

	self:RegisterEvent("VARIABLES_LOADED");
	DEFAULT_CHAT_FRAME:AddMessage("RuneHero activated! Type '/runehero' to reposition the bar.");

	self:SetScript("OnEvent", RuneFrameC_OnEvent);
	self:SetScript("OnUpdate", RuneFrameC_OnUpdate);
	
	self.runes = {};

--	RuneFrameGlow:SetTexCoord(0, .5, 0, .25);

	runePowerStatusBar = CreateFrame("StatusBar", nil, RuneFrameC);
	--runePowerStatusBar:SetWidth(140);
	--runePowerStatusBar:SetHeight(16);
	--runePowerStatusBar:SetStatusBarTexture("Interface\\AddOns\\RuneHero\\textures\\runeblade-status-bar-bright.tga");
	runePowerStatusBar:SetStatusBarTexture("Interface\\AddOns\\RuneHero\\textures\\runeblade-f.tga");
	
	runePowerStatusBar:SetStatusBarColor(1,1,1,1);
	runePowerStatusBar:SetMinMaxValues(-8,113);
	--runePowerStatusBar:SetPoint("CENTER", RuneBlade, "CENTER", 3, -2);
	runePowerStatusBar:SetAllPoints(RuneBlade);
	runePowerStatusBar:SetFrameLevel(3);

	runePowerStatusBarDark = CreateFrame("StatusBar", nil, RuneFrameC);
	runePowerStatusBarDark:SetAllPoints(runePowerStatusBar);
	runePowerStatusBarDark:SetStatusBarTexture("Interface\\AddOns\\RuneHero\\textures\\runeblade-status-bar-bright.tga");
	runePowerStatusBarDark:SetStatusBarColor(.2,.2,.2,1);
	runePowerStatusBarDark:SetMinMaxValues(0,100);
	runePowerStatusBarDark:SetValue(100);
	runePowerStatusBarDark:SetFrameLevel(6);
	runePowerStatusBarDark:Hide();


	runePowerStatusBarText = runePowerStatusBar:CreateFontString(nil, 'OVERLAY');
	runePowerStatusBarText:ClearAllPoints();
	runePowerStatusBarText:SetFontObject( WorldMapTextFont );
	runePowerStatusBarText:SetTextColor(.6,.9,1);
	runePowerStatusBarText:SetPoint("TOP", runePowerStatusBar, "TOP", runeX-80, 25 );
	runePowerStatusBarText:SetJustifyH("CENTER");
	runePowerStatusBarText:SetWidth(90);
	runePowerStatusBarText:SetHeight(40);

	--runePowerStatusBarText:SetPoint("LEFT", RuneFrameC, "LEFT", 95, 0 );
	--runePowerStatusBarText:SetPoint("RIGHT", RuneFrameC, "CENTER");
end
	


function RuneFrameC_OnUpdate(self)

	local power = UnitMana("player");

	runePowerStatusBar:SetValue( power );

	if ( power > 0) then
		runePowerStatusBarText:SetText( power );
	else
		runePowerStatusBarText:SetText( nil );
	end

end

function RuneFrameC_OnEvent (self, event, ...)
	if ( event == "COMBAT_LOG_EVENT" ) then
		if (arg10 == "Death Trance")    then
			if ( arg2 == "SPELL_AURA_APPLIED") then
				RuneBlade:SetTexture("Interface\\AddOns\\RuneHero\\textures\\runeblade-red");
			elseif (arg2=="SPELL_AURA_REMOVED") then
				RuneBlade:SetTexture("Interface\\AddOns\\RuneHero\\textures\\runeblade-d");
			end
		end
	elseif ( event == "PLAYER_ENTERING_WORLD" ) then
		for rune in next, self.runes do
			RuneButtonC_Update(self.runes[rune], rune);
		end
		RunePower_Event();
	elseif ( event == "RUNE_TYPE_UPDATE" ) then
		for rune in next, self.runes do
			RuneButtonC_Update(self.runes[rune], rune);
		end
	elseif ( event == "RUNE_POWER_UPDATE" ) then
		RunePower_Event();
	elseif ( event == "RUNE_REGEN_UPDATE" ) then
		RunePower_Event();
	elseif ( event == "VARIABLES_LOADED" ) then
		RuneFrameC:ClearAllPoints();
		RuneFrameC:SetPoint(RuneHero_Saved.anchor, RuneHero_Saved.parent,RuneHero_Saved.rel,RuneHero_Saved.x,RuneHero_Saved.y);
	
	end
end

function RuneFrameC_AddRune (runeFrameC, rune)
	tinsert(runeFrameC.runes, rune);
end

function RuneFrameC_OnDragStart()
	RuneFrameC:StartMoving();
end

function RuneFrameC_OnDragStop()
	RuneHero_Saved.anchor = "BOTTOMLEFT";
	RuneHero_Saved.parent = "UIParent";
	RuneHero_Saved.rel = "BOTTOMLEFT";
	RuneHero_Saved.x = RuneFrameC:GetLeft();
	RuneHero_Saved.y = RuneFrameC:GetBottom();
	RuneFrameC:StopMovingOrSizing();
end


function RuneHero_SlashCommand(cmd)

	if( cmd == 'bottom' ) then
		RuneFrameC:ClearAllPoints();
		RuneFrameC:SetPoint("BOTTOM", UIParent, "BOTTOM", 0, 135);

		RuneHero_Saved.anchor = "BOTTOM";
		RuneHero_Saved.parent = "UIParent";
		RuneHero_Saved.rel = "BOTTOM";
		RuneHero_Saved.x = 0;
		RuneHero_Saved.y = 135;

	elseif ( cmd == 'player' ) then
		RuneFrameC:ClearAllPoints();
		RuneFrameC:SetPoint("TOPLEFT", "PlayerFrame", "BOTTOMLEFT", 0 ,0);

		RuneHero_Saved.anchor = "TOPLEFT";
		RuneHero_Saved.parent = "PlayerFrame";
		RuneHero_Saved.rel = "BOTTOMLEFT";
		RuneHero_Saved.x = 0;
		RuneHero_Saved.y = 0;

	elseif (cmd == 'lock' ) then
		RuneButtonIndividual1C:SetMovable(false);
		RuneButtonIndividual1C:RegisterForDrag(nil);
		RuneButtonIndividual1C:SetScript('OnDragStart', nil );
		RuneFrameC:SetClampedToScreen(true);

	elseif ( cmd == 'unlock' ) then
		RuneButtonIndividual1C:SetMovable(true);
		RuneButtonIndividual1C:RegisterForDrag('LeftButton');
		RuneButtonIndividual1C:SetScript('OnDragStart', RuneFrameC_OnDragStart );
		RuneButtonIndividual1C:SetScript('OnDragStop', RuneFrameC_OnDragStop );
		RuneFrameC:SetClampedToScreen(true);

		DEFAULT_CHAT_FRAME:AddMessage(" RuneHero unlocked. Click on the top rune icon to drag.");
	
	else
		DEFAULT_CHAT_FRAME:AddMessage(" RuneHero Commands: 'bottom', 'player', 'lock', 'unlock'.");
	end	
end

-- Slash Command Support
SLASH_RUNEHERO1 = "/runehero";
SLASH_RUNEHERO2 = "/rune";
SlashCmdList["RUNEHERO"] = RuneHero_SlashCommand;