Important Notes:
----------------
1) I use Smart Auto-follow for my camera settings and I have had some people say their camera got locked in a bad direction upon a zone or death.  If your camera is off after you zone in, attempt to hit the key you bound to Quick Look - Reset and it will hopefully fix it.

2) Before you ask, YES there is a Blizzard default bind(Flip Camera) to "toggle" your camera to behind.  This "mod" adds the ability to look behind only while the key is pressed and then return after you release the key.  A function found in many FPS style games.

DESCRIPTION:
------------
Was too use to being able to look behind me quickly with one button press. The mod binds a key to Quick Look - Back under the Gar Quick Look section in the Keybindings page.  Press the bound key to look behind and release to return to forward view.

INSTALLATION:
-------------
Extract the data to your "World of Warcraft/Interface/AddOns" directory so that the "Gar_QuickLook" directory is a subdirectory of the "AddOns" directory.

USAGE:
------
Start WoW normally
Open the KeyBindings page from the Main Menu
Bind a key to "Quick Look - Back" under the "Quick Look by Garoun" section
Hit Okay to save the binding
Press the bound key to look behind and release it to return to forward view.

UNINSTALL:
----------
Delete the "Gar_QuickLook" directory in the "World of Warcraft/Interface/AddOns" directory

COMMENTS:
---------
Send all comments to wowui AT cg-dev.com

PLANS:
------
None at this time

CHANGELOG:
----------
v2.4.3.07202008
 - Version update so it matches the proper release format

v2.4.03252008
 - TOC Update
 
v2.0.01262007
 - TOC Update

v2.0.12042006
 - Finalized TBC version for the 12/5/2006 patch.

v2.0.11142006
 - Changed TOC to 20000 for TBC, no other errors found yet

v1.2.10292006
 - Fixed pressing multiple keys at once, per suggestion from Tageshi on wowinterface

v1.2.10282006
 - Updated Toc
 - Added Reset binding that will let the camera attempt to reset your view to the last used.
   Basically I try to do the opposite of the last Look function you used.

v1.1.08192005
 - Added Quick Look - Right
 - Added Quick Look - Left

v1.0.08182005
 - Initial Release
