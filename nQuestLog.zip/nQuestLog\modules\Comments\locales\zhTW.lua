﻿local L = AceLibrary("AceLocale-2.2"):new("Comments")

L:RegisterTranslations("zhTW", function() return {
	["Comments"] = "論壇討論",
	["Description"] = "來自於Wowhead.com的任務論壇討論（無中文版）。",
	["Minimum width"] = "最小寬度",
	["Set the minimum width of the Comments frame"] = "設置評論視窗的最小寬度",
	["Maximum height"] = "最大高度",
	["Set the maximum height of the Comments frame"] = "設置評論視窗的最大高度",
	
	["%s Comments"] = "%s的討論", --%s is "Lightheaded"
	["%s ID"] = "%sID", --%s is "Quest"
	["%s Info"] = "%s的信息", --%s is "Lightheaded" or "MobMap"
	["%s-only"] = "僅限%s", --%s is "Horde" or "Alliance"
	["%s Rewards"] = "%s的獎勵資訊", --%s is "Lightheaded" or "MobMap"
	["%s %s Series"] = "%s的系列%s", --%s is "Lightheaded", "Quest"
	["%s Type"] = "%s類型", --%s is "Quest"
	
	["<not yet cached>"] = "<尚未緩存>",
	["Always receive"] = "獲得",
	["Choose from"] = "從以下物品中選擇",
	["Coordinates"] = "座標",
	["Ends"] = "結束", --as in "The quest *ends* at..."
	["Quest"] = "任務",
	["Rep"] = "聲望", --abbreviation for "Reputation"
	["Req Lvl"] = "需要等級", --abbreviation for "Required Level"
	["Sharable"] = "可共用",
	["Source"] = "來源", --as in "The *source* of the quest"
	["Starts"] = "起始", --as in "The quest *starts* at..."
	["No comments found"] = "沒有任何討論",
	["%s data is from %s"] = "%s的資料來自於%s", --%s is "Lightheaded", "Wowhead"
} end)
