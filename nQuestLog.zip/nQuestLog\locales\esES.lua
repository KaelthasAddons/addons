﻿--Caution:  This file must remain encoded in UTF-8 format when saving!

local L = AceLibrary("AceLocale-2.2"):new("nQuestLog")

L:RegisterTranslations("esES", function() return {
	--Generic:
	["Auto fade"] = "AutoDesvanecer",
	["Auto show"] = "AutoMostrar",
	["Configure"] = "Configurar",
	["decrease"] = "disminuir",
	["Default : "] = "Por Defecto : ",
	[" (done)"] = " (hecho)",
	["Enabled"] = "Activado",
	["Fade-in"] = "Desvanecer-Entrar",
	["Fade-out"] = "Desvanecer-Salir",
	[" (failed)"] = " (fallado)",
	["Font outline"] = "Borde de fuente",
	["Font size"] = "Tamaño de fuente",
	[" (goto)"] = " (ir a)",
	["Grow upwards"] = "Crecer hacia arriba",
	["Hidden"] = "Oculto",
	[" hidden)"] = " oculto)",
	["Hide completed"] = "Oculta completados",
	["increase"] = "aumentar",
	["Locked"] = "Bloqueado",
	["Main settings"] = "Configuración Principal",
	["Module settings"] = "Configuración Módulo",
	["Open configuration frame"] = "Abrir marco de configuración",
	["Padding"] = "Separación",
	["Set width of frame"] = "Establecer ancho del marco",
	["settings"] = "Ajustes",
	["Shown"] = "Mostrados",
	["Smart"] = "Inteligente",
	["Toggle showing"] = "Cambiar muestra",
	["Unlocked"] = "Desbloqueado",
	[" visible)"] = " visible)",
	["Visible"] = "Visible",
	["Width"] = "Ancho",

	--Object points:
	["BOTTOMLEFT"] = "ABAJO-IZQUIERDA",
	["BOTTOMRIGHT"] = "ABAJO-DERECHA",
	["TOPLEFT"] = "ARRIBA-IZQUIERDA",
	["TOPRIGHT"] = "ARRIBA-DERECHA",

	--Mouse clicks:
	["Alt-Click"] = "Alt-Click",
	["Click"] = "Click",
	["Ctrl-Click"] = "Ctrl-Click",
	["Right-Click"] = "Click-Derecho",
	["Shift-Click"] = "Mayús-Click",

	--Minion related:
	["Add outline to minion font"] = "Añadir borde a fuente del Visor de Misiones",
	["Change font size for minion header"] = "Cambiar el tamaño de fuente para cabecera del Visor de Misiones",
	["Expand/Collapse minion"] = "Expandir/Colapsar Visor de Misiones",
	["Grow minion up"] = "Visor de Misiones crece hacia arriba",
	["Header"] = "Cabecera",
	["Lock minion"] = "Bloquear Visor de Misiones",
	["Lock/Unlock minion"] = "Des/Bloquear Visor de Misiones",
	["Minion"] = "Visor de Misiones",
	["Minion locked"] = "Visor de Misiones bloqueado",
	["Minion must be locked for proper functionality!"] = "¡El Visor de Misiones debe ser bloqueado para un funcionamiento adecuado!",
	["Minion status"] = "Estado de Visor de Misiones",
	["Minion visible"] = "Visor de Misiones Visible",
	["Note that minion will not show if you are not tracking any quests."] = "Note that minion will not show if you are not tracking any quests.", --Need translation
	["Reset minion position"] = "Reiniciar posición del Visor de Misiones",
	["Resets the position of the minion to the center of the screen"] = "Resets the position of the minion to the center of the screen", --Need translation
	["Show/Hide minion"] = "Mostrar/Ocultar Visor de Misiones",
	["Title text"] = "Texto del Título",
	expandCollapseDesc = "Expand current zone if collapsed, otherwise expand all zones.  Collapse all zones if already expanded.", --Need translation
	minionHeader = "Show header at the top of the minion.", --Need translation
	minionHeaderTitle = "Text to display as a title in the minion header.  Set to nothing to hide the title.", --Need translation
	minionAnchor = "Frame anchor", --Need translation
	minionAnchorDesc = "Used as a reference point when resizing the minion.", --Need translation
	minionAutoWidth = "Auto-redimensionar ancho",
	minionAutoWidthDesc = "Automatically resize the minion's width according to the longest zone/quest/objective name currently displayed.", --Need translation
	minionFade = "%s alpha", --%s = "Fade-in" OR "Fade-out" --Need translation
	minionFadeDesc = "When the mouse %s the minion, %s the frame opacity until it reaches this value.", --%s = minionFadeIsOver OR minionFadeLeaves, %s = "increase" OR "decrease" --Need translation
	minionFadeTime = "%s tiempo", --%s = "Fade-in" OR "Fade-out"
	minionFadeTimeDesc = "Gradually %s the frame opacity to the %s value over XX seconds.", --%s = "increase" OR "decrease", %s = "Fade-in" OR "Fade-out" --Need translation
	minionFadeDelay = "%s retraso", --%s = "Desvanecer-Entrar" O "Desvanecer-Salir"
	minionFadeDelayDesc = "Delay frame fade-out for XX seconds after the mouse leaves the minion.", --Need translation
	minionFadeIsOver = "encima", --First %s in minionFadeDesc --Need translation
	minionFadeLeaves = "abandonar", --First %s in minionFadeDesc --Need translation
	minionResetConfirm = "¿Estas seguro que deseas reiniciar la posición del Visor de Misiones?",

	--Zone related:
	["Change font size for zone"] = "Cambiar el tamaño de la fuente para zona",
	["Change padding between zones"] = "Cambiar separación entre zonas",
	["Hide zone"] = "Oculta la zona",
	["Show empty zones"] = "Muestra las zonas vacías",
	["Show hidden zones where you are not tracking any quests"] = "Show hidden zones where you are not tracking any quests", --Need translation
	["Show visible/total quests for a zone"] = "Muestra misiones Visibles/Total para una zona",
	["Show zone"] = "Muestra la zona",
	["Show zone level"] = "Muestra el nivel de la zona",
	["Shows <Zone> with X/X visible"] = "Muestra <Zona> con X/X Visibles",
	["Toggle zone visibility"] = "Cambia visibilidad de la zona",
	["Zone"] = "Zona",
	["Zone visibility:"] = "Visibilidad de Zona:",

	--Quest related:
	["Show completed quests"] = "Mostrar misiones completadas",
	showQuestsDone = "Show count of active quests for which all objectives are complete.", --Need translation
	["Show hidden quests"] = "Mostra misiones ocultas",
	showQuestsHidden = "Mostrar contador de misiones activas que están ocultas.",
	["Show active quests"] = "Mostrar misiones activas",
	showQuestsActive = "Mostrar contador de misiones activas.",
	["Show max quests"] = "Mostrar misiones máx.",
	showQuestsMax = "Mostrar número máximo de misiones activas.",
	["Auto show hidden quests when you loot a quest item for it"] = "Auto mostrar misiones ocultas cuando loot un elemento de misión for it", --Need translation
	["Auto show new quests in minion"] = "Auto mostrar nuevas misiones en el Visor de Misiones",
	["Change font size for quests"] = "Cambiar el tamaño de fuente para misiones",
	["Change padding between quests"] = "Cambiar la separación entre misiones",
	["no quests to track"] = "no hay misiones a seguir",
	["Listing all quests"] = "Enumerar todas las misiones",
	["Listing all watched quests"] = "Enumerar todas las misiones seguidas",
	["New quests"] = "Nuevas misiones",
	["Quest"] = "Misión",
	["Show quest progress"] = "Muestra el progreso de la misión",
	["%s items total"] = "%s elementos en total",
	["Watched quests"] = "Misiones Seguidas",
	["When looting quest item"] = "Cuando saqueas un elemento de misión",

	--Quest objectives related:
	["Default quest objective tracking"] = "Seguimiento del objetivo de la misión por defecto",
	hideObjs = "Oculta objetivos por defecto",
	hideObjsDesc = "Ocultar todos los objetivos de la misión por defecto.",
	hideCompletedObjs = "Oculta los objetivos terminados",
	hideCompletedObjsDesc = "Oculta todos los objetivos de misión completados.  Esto sustituye a otras opciones de visibilidad.",
	["Quest objectives"] = "Objetivos de la misión",
	["Reset manually watched objectives"] = "Reajustar los objetivos manualmente mirados",
	showDescNoObjs = "Muestra descripción si no hay objetivos",
	showDescNoObjsDesc = "Show brief quest description if no progress is available.", --Need translation
	["Show/Hide objectives"] = "Muestra/Oculta los objetivos",

	--Item related:
	["<not yet cached>"] = "<no cacheado>",
	--Unsafe item tooltip, copied from AtlasLoot
	["Unsafe Item"] = "Elemento Inseguro",
	["ItemID:"] = "Elemento ID:",
	["unsafeItemWarning"] = "This item is unsafe.  To view this item without the risk of disconnection, "..
		"you need to have first seen it in the game world.  This is a restriction enforced by Blizzard since Patch 1.10.",  --Need translation
	["queryItemWarning"] = "You can left-click to attempt to query the server.  You may be disconnected.",  --Need translation

	--nQuestLogFuBar:
	["FuBarPlugin options"] = "Opciones FuBarPlugin",
	["FuBarPlugin options desc"] = "Opciones plugin Standard, texto and opciones tooltip.",
	["Text options"] = "Opciones Texto",
	["Tooltip options"] = "Opciones Tooltip",
	["Show minion status"] = "Mostrar estado Visor de Misiones",
	["showFuMinionStatus"] = "Mostrar whether Visor de Misiones está oculto o visible y bloqueado o desbloqueado.",
	["Show hint"] = "Mostra consejos",
	["showFuHint"] = "Mostrar tooltip de consejos.",
	["Standard options"] = "Opciones Standard",
	["waterfallError"] = "Se necesita Waterfall-1.0 para acceder al marco de configuración.",
	["Quest status"] = "Estado de Misión",
	["Completed"] = "Completada",
	["Active"] = "Activa",
	["%s for options."] = "%s para opciones.", -- %s is a mouse click
	["%s to configure."] = "%s para configurar.", -- %s is a mouse click
	["%s to expand/collapse."] = "%s para expandir/colapsar.", -- %s is a mouse click
	["%s to lock/unlock."] = "%s para des/bloquear.", -- %s is a mouse click
	["%s to show/hide."] = "%s para mostrar/ocultar.", -- %s is a mouse click
} end)
