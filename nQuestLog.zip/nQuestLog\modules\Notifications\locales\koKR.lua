﻿local L = AceLibrary("AceLocale-2.2"):new("Notifications")

L:RegisterTranslations("koKR", function() return {
	Notifications = "퀘스트 완료 알림",
	Description = "퀘스트 진행상황 알림",
	
	["%s notifications"] = "알림 : %s", --%s = "Text" OR "Sound"
	["Text"] = "글자",
	["Sound"] = "소리",
	
	testOutput = "시험 출력",
	testOutputDesc = "시험 목적을 위한 모조 출력을 창조하십시오",
	fakeQuest = "테스트, 퀘스트가 완료되었습니다.",
	
	questDone = "완료된 퀘스트",
	questDoneDesc = "퀘스트가 완료되었을 때 알립니다.",
	
	objDone = "완료된 목표",
	objDoneDesc = "퀘스트의 목표가 완료되었을 때 알립니다.",
	objDoneSoundDesc = "퀘스트 목표가 완료되었을 때 소리로 알립니다.",
	objProgress = "목표 진행상황",
	objProgressDesc = "퀘스트 목표가 진행될 때 알립니다.",
	objProgressHidden = "퀘스트가 숨겨져 있을 때만",
	objProgressHiddenDesc = "퀘스트가 숨겨져 있을 때도 진행이 되면 알립니다.",
	objQuestName = "퀘스트 이름 표시",
	objQuestNameDesc = "목표 진행을 알릴 때 퀘스트 이름도 표시합니다.",
	hideBlizz = "블리자드 목표 알림 숨김",
	hideBlizzDesc = "블리자드 기본 알림창을 숨깁니다.",
	
	multiToggle = "힌트: 자동으로 다양한 소리를 냅니다.",
	["%s \"Job's done!\""] = "%s \"일이 끝났습니다!\"",
	["%s \"More work?\""] = "%s \"더 할 거 있니?\"",
	["%s \"Ready to work!\""] = "%s \"준비 완료!\"",
	["%s \"Something need doing?\""] = "%s \"필요한거 있니?\"",
	["%s \"Work complete!\""] = "%s \"완료되었습니다.!\"",
	["Flag captured"] = "깃발 회수",
	["Peasant"] = "농민", --Need translation
	["Peon"] = "일꾼",
	["Ready check"] = "준비확인", --Need translation
	
	blizzProgressPattern = "^.+: ?%d+/%d+$", -- pattern to suppress Blizzard objective progress messages
} end)
