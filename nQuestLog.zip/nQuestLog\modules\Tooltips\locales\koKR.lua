﻿local L = AceLibrary("AceLocale-2.2"):new("Tooltips")

L:RegisterTranslations("koKR", function() return {
	["Tooltips"] = "툴팁",
	["Description"] = "애드온에 대한 툴팁 및 몬스터, 아이템에 대한 툴팁을 표시해주는 모듈입니다.",
	["Enabled"] = "사용",
	
	--Tooltip anchor
	tooltipAnchor = "툴팁 위치",
	tooltipAnchorDesc = "퀘스트 알림창의 툴팁의 위치를 설정합니다.",
--	["DEFAULT"] = "DEFAULT", --Need translation
--	["TOPRIGHT"] = "TOPRIGHT", --Need translation
--	["RIGHT"] = "RIGHT", --Need translation
--	["BOTTOMRIGHT"] = "BOTTOMRIGHT", --Need translation
--	["TOPLEFT"] = "TOPLEFT", --Need translation
--	["LEFT"] = "LEFT", --Need translation
--	["BOTTOMLEFT"] = "BOTTOMLEFT", --Need translation
	
	--Item tooltip
	itemToolTip = "퀘스트/진행 상황 툴팁에 추가",
	itemToolTipDesc = "퀘스트의 진행 상황을 알림창에 가져다 댔을때 툴팁에 표시해줍니다.",
	
	--Mob tooltip
	mobToolTip = "몬스터 툴팁",
	mobToolTipDesc = "몬스터의 툴팁에 퀘스트 또는 목표를 표시합니다.",
	mobToolTipTrigger = "툴팁 위에 추가",
	mobToolTipTriggerDesc = "몬스터 툴팁에 퀘스트 데이터를 표시합니다.",
	mobToolTipTriggerBoth = "몬스터 및 유닛프레임 대상",
	mobToolTipTriggerMob = "몬스터 대상",
	disableInRaidInstance = "공격대 시에 숨김",
	disableInRaidInstanceDesc = "공격대에 참여했을 경우 툴팁을 숨깁니다. 공격대에서의 불필요한 CPU 점유율을 낮추기위해서 입니다.",
	useMobMap = "MobMap 사용",
	useMobMapDesc = "MobMap 드랍데이터를 퀘스트 목표의 아이템에 맞게 표시합니다.",
	MobMapDropRateFilter = "드랍율 기준 설정",
	MobMapDropRateFilterDesc = "MobMap 드랍율의 기준을 설정합니다. 이것은 불필요한 몬스터 룻과 툴팁의 오류를 해결해줄 것입니다.",
	addMobMapDropRates = "드랍율 보기",
	addMobMapDropRatesDesc = "몬스터 툴탑에 드랍율을 표시합니다.",
	addKillsNeeded = "몬스터 죽은 횟수 표시",
	addKillsNeededDesc = "MobMap 드랍율 계산에 사용할 수 있도록 몬스터 죽인 횟수를 표시합니다.",
	killsNeeded = "죽임 필요",
	
	trimToolTip = "툴팁 정보 정리",
	trimToolTipDesc = "몬스터 및 아이템 툴팁에 표시하기전에 정리합니다. 0이면 사용하지 않습니다.",
	
	--Minion unlocked
	["MinionUnlocked"] = "알림창 비고정",
	["PlaceMinion"] = "퀘스트 알림창을 고정할 수 있습니다.\n알림창을 고정하려면 푸바 또는 미니맵 버튼의 설정을 참고하세요.",
	
	--Zone tooltips
	["ZoneHidden"] = "지역 숨기기",
	["TrackedQuests"] = "퀘스트 보기",
	["HiddenQuests"] = "퀘스트 숨기기",
	["ZoneTips"] = "힌트 : 오른쪽 클릭하면 퀘스트를 보거나 숨기고\nAlt+클릭하면 모든 지역의 퀘스트를 볼 수 있습니다.",
	
	--Quest tooltips
	["Total"] = "모두 보기",
	["QuestTips"] = "힌트 : Alt+클릭하면 모든 목표를 보거나 숨깁니다.",
} end)
