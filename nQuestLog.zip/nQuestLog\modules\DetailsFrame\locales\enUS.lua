﻿local L = AceLibrary("AceLocale-2.2"):new("DetailsFrame")

L:RegisterTranslations("enUS", function() return {
	["DetailsFrame"] = true,
	["Description"] = "Prettier and more informative quest details frame.",
	["Minimum width"] = true,
	["Set the minimum width of the Details frame"] = true,
	["Maximum height"] = true,
	["Set the maximum height of the Details frame"] = true,
	
	["(done)"] = true,
	["(failed)"] = true,
	["Given by"] = true,
	["Required money: "] = true,
	["Text"] = true,
	["%s in %s (%d,%d)"] = true,
	
	["Description"] = true,
	["Rewards"] = true,
	["Choose from:"] = true,
	["Always receive:"] = true,
	["Spell:"] = true,
	["Money: "] = true,
	["Nothing."] = true,
	["Options"] = true,
	["- Share"] = true,
	["- Abandon"] = true,
	["[ Close ]"] = true,
	
	["<not yet cached>"] = true,
	
	["bunch-of-directions"] = {
		"([^%a%d])(north)([^%a%d])",
		"([^%a%d])(northern)([^%a%d])",
		"([^%a%d])(west)([^%a%d])",
		"([^%a%d])(western)([^%a%d])",
		"([^%a%d])(east)([^%a%d])",
		"([^%a%d])(eastern)([^%a%d])",
		"([^%a%d])(south)([^%a%d])",
		"([^%a%d])(southern)([^%a%d])",
		"([^%a%d])(northwest)([^%a%d])",
		"([^%a%d])(northwestern)([^%a%d])",
		"([^%a%d])(northeast)([^%a%d])",
		"([^%a%d])(northeastern)([^%a%d])",
		"([^%a%d])(southwest)([^%a%d])",
		"([^%a%d])(southwestern)([^%a%d])",
		"([^%a%d])(southeast)([^%a%d])",
		"([^%a%d])(southeastern)([^%a%d])",
	}
} end)
