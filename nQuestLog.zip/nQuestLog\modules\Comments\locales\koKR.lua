﻿local L = AceLibrary("AceLocale-2.2"):new("Comments")

L:RegisterTranslations("koKR", function() return {
	["Comments"] = "설명",
	["Description"] = "wowhead.com의 퀘스트 상세 설명을 표시합니다.",
	["Minimum width"] = "최소 가로 길이",
	["Set the minimum width of the Comments frame"] = "설명 창의 최소 가로 길이를 설정합니다.",
	["Maximum height"] = "최소 세로 길이",
	["Set the maximum height of the Comments frame"] = "설명 창의 최소 세로 길이를 설정합니다.",
	
	["%s Comments"] = "설명 : %s",
	["%s ID"] = "퀘스트ID : %s",
	["%s Info"] = "정보 %s",
	["%s-only"] = "%s 만",
	["%s Rewards"] = "보상 : %s",
	["%s %s Series"] = "%s %s Series",
	["%s Type"] = "퀘스트 유형 : %s",
	
	["<not yet cached>"] = "<아이템 캐쉬에 없음>",
	["Always receive"] = "받게 될 보상",
	["Choose from"] = "아래의 보상 중 선택",
	["Coordinates"] = "좌표",
	["Ends"] = "끝",
	["Quest"] = "퀘스트",
	["Rep"] = "평판",
	["Req Lvl"] = "요구 레벨",
	["Sharable"] = "공유가능",
	["Source"] = "제공자",
	["Starts"] = "시작",
	["No comments found"] = "설명이 없습니다.",
	["%s data is from %s"] = "%s 자료(%s 에서 가져옴)",
} end)
