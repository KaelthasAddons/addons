﻿local L = AceLibrary("AceLocale-2.2"):new("SmartVisibility")

L:RegisterTranslations("koKR", function() return {
	["SmartVisibility"] = "자동 표시",
	["Description"] = "자동으로 퀘스트 진행을 알리거나 숨겨주는 모듈입니다.",
	
	["Zone"] = "지역",
	zoneAutoCollapse = "다른 지역 자동 닫기", --Need translation
	zoneAutoCollapseDesc = "현재 지역을 제외한 퀘스트 수행 지역을 자동으로 숨깁니다.",
	zoneAutoExpand = "현재 지역 자동 열기",
	zoneAutoExpandDesc = "현재 지역의 퀘스트를 자동으로 표시합니다.",
	
	["Quests"] = "퀘스트",
	questHideDone = "완료된 퀘스트 숨기기",
	questHideDoneDesc = "완료된 퀘스트는 자동으로 숨깁니다. 숨긴 퀘스트를 보기 위해서는 퀘스트 지역에 오른쪽 마우스 버튼을 누르면 됩니다.",
	
	["Objectives"] = "목표",
	objShowZone = "현재 지역의 목표를 표시합니다.",
	objShowZoneDesc = "\"항상\" - 현재 지역의모든 퀘스트 목표를 항상 표시합니다.(수동으로 닫아 놓은 것도 포함)"..
		"\n\n\"기본값에 따라\" - 현재 설정에 영향 없이 수동으로 열고 닫은 퀘스트의 목표를 표시합니다."..
		" (기본값으로 초기화)",
	["option disabled"] = "설정 사용 불가",
	["Always"] = "항상",
	["By default"] = "기본값에 따라",
	objShowActive = "현재 진행중인 퀘스트 목표 보기",
	objShowActiveDesc = "X분 이내에 수행중인 퀘스트의 목표를 표시합니다. \"0\"으로 설정하면 사용하지 않습니다.",
	objShowNew = "새로운 퀘스트의 목표 보기",
	objShowNewDesc = "새로 받은 퀘스트의 목표를 표시합니다.",
} end)
