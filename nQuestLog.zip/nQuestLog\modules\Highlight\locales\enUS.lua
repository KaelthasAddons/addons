﻿local L = AceLibrary("AceLocale-2.2"):new("Highlight")

L:RegisterTranslations("enUS", function() return {
	["Highlight"] = true,
	["Description"] = "Highlights quests",
} end)
