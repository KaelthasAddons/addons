﻿local L = AceLibrary("AceLocale-2.2"):new("Comments")

L:RegisterTranslations("esES", function() return {
	["Comments"] = "Comentarios",
	["Description"] = "Comentarios de wowhead.com en detalles de misión.",
	["Minimum width"] = "Ancho mínimo",
	["Set the minimum width of the Comments frame"] = "Establece el ancho mínimo del marco de Comentarios",
	["Maximum height"] = "Altura máxima",
	["Set the maximum height of the Comments frame"] = "Establece la altura máxima del marco de Comentarios",

	["%s Comments"] = "Comentarios %s", --%s is "Lightheaded"
	["%s ID"] = "ID %s", --%s is "Quest"
	["%s Info"] = "Info %s", --%s is "Lightheaded" or "MobMap"
	["%s-only"] = "Solo %s", --%s is "Horde" or "Alliance"
	["%s Rewards"] = "Recompensa %s", --%s is "Lightheaded" or "MobMap"
	["%s %s Series"] = "Serie %s %s", --%s is "Lightheaded", "Quest"
	["%s Type"] = "Tipo %s", --%s is "Quest"

	["<not yet cached>"] = "<No cacheado>",
	["Always receive"] = "Siempre recibe",
	["Choose from"] = "Elegir entre",
	["Coordinates"] = "Coordenadas",
	["Ends"] = "Finaliza", --as in "The quest *ends* at..."
	["Quest"] = "Misión",
	["Rep"] = "Rep", --abbreviation for "Reputation"
	["Req Lvl"] = "Nvl Req", --abbreviation for "Required Level"
	["Sharable"] = "Compartible",
	["Source"] = "Origen", --as in "The *source* of the quest"
	["Starts"] = "Comienza", --as in "The quest *starts* at..."
	["No comments found"] = "Sin comentarios",
	["%s data is from %s"] = "Datos %s son de %s", --%s is "Lightheaded", "Wowhead"
} end)
