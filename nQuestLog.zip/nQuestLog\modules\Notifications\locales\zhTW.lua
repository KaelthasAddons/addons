﻿local L = AceLibrary("AceLocale-2.2"):new("Notifications")

L:RegisterTranslations("zhTW", function() return {
	Notifications = "進度通知",
	Description = "當任務有進度時通知",
	
	["%s notifications"] = "%s通知", --%s = "Text" OR "Sound"
	["Text"] = "文本",
	["Sound"] = "聲音",
	
	testOutput = "測試",
	testOutputDesc = "點擊開始發出一個測試用的通知",
	fakeQuest = "嘿，你剛剛完成了一個有趣的任務！",
	
	questDone = "任務完成", --also used in notifications
	questDoneDesc = "當整個任務完成時通知",
	
	objDone = "完成任務目標", --also used in notifications
	objDoneDesc = "當某項任務目標完成時通知",
	objDoneSoundDesc = "當某項任務完成了一個目標，但是至少還有一個以上的目標沒有完成時通知。",
	objProgress = "目標進展",
	objProgressDesc = "當某項目標有所進展時通知。",
	objProgressHidden = "僅當任務隱藏時",
	objProgressHiddenDesc = "只有當這個任務處於隱藏狀態時才通知進展。",
	objQuestName = "包含任務名稱",
	objQuestNameDesc = "在目標通知時也同時顯示該目標所屬的任務名稱。",
	hideBlizz = "隱藏暴雪的任務通知",
	hideBlizzDesc = "隱藏螢幕上方暴雪原有的任務進度通知文字。",
	
	multiToggle = "小竅門：如果選擇了多項，便可以自動在這些選項中隨機挑選一個聲音播放。",
	["%s \"Job's done!\""] = "%s \"Job's done!\"",
	["%s \"More work?\""] = "%s \"還有工作要做？\"",
	["%s \"Ready to work!\""] = "%s \"準備工作！\"",
	["%s \"Something need doing?\""] = "%s \"有事情要做嗎？\"",
	["%s \"Work complete!\""] = "%s \"工作完成！\"",
	["Flag captured"] = "奪得旗幟",
	["Peasant"] = "農民",
	["Peon"] = "苦工",
	["Ready check"] = "就緒確認",
	
	blizzProgressPattern = "^.+: ?%d+/%d+$", -- pattern to suppress Blizzard objective progress messages
} end)
