﻿local L = AceLibrary("AceLocale-2.2"):new("BlizzardFrames")

L:RegisterTranslations("esES", function() return {
	["BlizzardFrames"] = "Marcos Blizzard",
	["Description"] = "This module hooks blizzard frames and displays quest levels",
	hideTracker = "Ocultar Visor de Misiones",
	hideTrackerDesc = "Oculta el marco del Visor de Misiones por defecto de Blizzard",
	["Quest log"] = "Descripción de misión",
	["Add quest levels"] = "Añadir niveles de misión",
	["addLogQuestLevels"] = "Muestra los niveles de misión en la descripción de misión de Blizzard.",
	["Add quest givers"] = "Añadir donantes de misión",
	["addLogQuestGivers"] = "Muestra de quien se obtuvo la misión en el panel de detalles de la descripción de la misión de Blizzard.",
	logMove = "Movible",
	logMoveDesc = "Permite arrastrar y reposicionar el marco de la descripción de misión de Blizzard.",
	logScale = "Escala",
	logScaleDesc = "Establece la escala de la descripción de misión de Blizzard (relativo a la escala actual del UI).",
	["Dialog"] = "Dialogo",
	["addDialogQuestLevels"] = "Muestra niveles de misión en ventanas de selección de misión del NPC y marcos de felicitación de misión.",
	["Grey incomplete quest icons"] = "Iconos grises de misión incompleta",
	["greyIncompleteQuestIcons"] = "Iconos grises junto misiones activas o incompletas en la ventana de selección de misión del NPC y en marcos de felicitación de misión.",
	["Given by"] = "Obtenida de",
	["Location"] = "Localización",
	["yd"] = "m", --abbreviation for yard, a measure of distance, m for meter
} end)
