﻿local L = AceLibrary("AceLocale-2.2"):new("QuestGivers")

L:RegisterTranslations("zhCN", function() return {
	["QuestGivers"] = "任务委托人",
	["Description"] = "追踪委托人的NPC坐标",
	["%s in %s (%d,%d)"] = "%s － %s（%d, %d）",
	["%s in %s (%d,%d) (%d yd)"] = "%s － %s （%d, %d）（%d码）",
} end)
