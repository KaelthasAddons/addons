﻿--Caution:  This file must remain encoded in UTF-8 format when saving!
--harl windwolf (harldephin@freenode), November 26, 2007

local L = AceLibrary("AceLocale-2.2"):new("BlizzardFrames")

L:RegisterTranslations("deDE", function() return {
	["BlizzardFrames"] = "Blizzard-Fenster", --BlizzardFrames/-Fenster/-UI
	["Description"] = "Dieses Modul modifiziert die Blizzard-Fenster und zeigt zB die Quest-Stufen in diesen an.",
	hideTracker = "Tracker verstecken",
	hideTrackerDesc = "Versteckt die Quest-Verfolgung des vorgegebenen Blizzard-UI",
	["Quest log"] = "Questlog",
	["Add quest levels"] = "Füge Quest-Stufen hinzu",
	["addLogQuestLevels"] = "Zeigt die Stufen der Quests im Blizzard-Questlog an.",
	["Add quest givers"] = "Füge Questgeber hinzu",
	["addLogQuestGivers"] = "Zeigt die Questgeber in den Questbeschreibungen an.",
	logMove = "Fenster lösen",
	logMoveDesc = "Erlaubt das ziehen und verschieben des Blizzard-Questlogs.",
	logScale = "Skalierung",
	logScaleDesc = "Ändert die Skalierung des Blizzard-Questlog (relativ zur aktuellen UI-Skalierung).",
	["Dialog"] = "Dialog", --Quest-Stufen im Dialog
	["addDialogQuestLevels"] = "Zeigt die Stufen der Quests im Anrede- und Questbeschreibungs-Fenster der NSCs an.",
	["Grey incomplete quest icons"] = "Graue Symbole bei unvollständigen Quests",
	["greyIncompleteQuestIcons"] = "Setzt graue Symbole neben die aktiven, nicht abgeschlossenen Quests im NSC-Fenster.",
	["Given by"] = "Erhalten bei",
	["Location"] = "Standort",
	["yd"] = "m", --abbreviation for meter (about 1.094 yard), a measure of distance
} end)
