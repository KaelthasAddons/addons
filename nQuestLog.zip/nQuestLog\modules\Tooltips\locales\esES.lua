﻿local L = AceLibrary("AceLocale-2.2"):new("Tooltips")

L:RegisterTranslations("esES", function() return {
	["Tooltips"] = "Bocadillos",
	["Description"] = "Repartos con los diferentes bocadillos y añade información del monstruo/objeto en el bocadillo",
	["Enabled"] = "Activado",

	--Tooltip anchor
	tooltipAnchor = "Tooltip Anchor",
	tooltipAnchorDesc = "Sets the tooltip when mousing over the minion's anchor",
	["DEFAULT"] = "Por defecto",
	["TOPRIGHT"] = "ARRIBA-DERECHA",
	["RIGHT"] = "DERECHA",
	["BOTTOMRIGHT"] = "ABAJO-DERECHA",
	["TOPLEFT"] = "ARRIBA-IZQUIERDA",
	["LEFT"] = "IZQUIERDA",
	["BOTTOMLEFT"] = "ABAJO-IZQUIERDA",

	--Item tooltip
	itemToolTip = "Bocadillos de objetos",
	itemToolTipDesc = "Add related quests to item tooltips.",

	--Mob tooltip
	mobToolTip = "Bocadillos de monstruos",
	mobToolTipDesc = "Add related quests/objectives to mob tooltips",
	mobToolTipTrigger = "Añadir al bocadillo en...",
	mobToolTipTriggerDesc = "Sets the event(s) for adding quest data to mob tooltips.",
	mobToolTipTriggerBoth = "Mob and unit frame mouseover",
	mobToolTipTriggerMob = "Mob mouseover only",
	disableInRaidInstance = "Disable while raiding",
	disableInRaidInstanceDesc = "Disables mob tooltip processing while inside a raid instance.  Prevents wasting CPU cycles when they are badly needed during raids.",
	useMobMap = "Utilizar MobMap",
	useMobMapDesc = "Match quest objective items/objects to mobs using MobMap drop data",
	MobMapDropRateFilter = "Set drop rate threshold",
	MobMapDropRateFilterDesc = "Filters MobMap drop table and removes drops below the specified percent threshold.  This helps to remove invalid mob loot and avoid false positives in tooltips.",
	addMobMapDropRates = "Mostrar probabilidad de soltar",
	addMobMapDropRatesDesc = "Display MobMap drop rates in mob tooltips",
	addKillsNeeded = "Mostrar muertes restantes",
	addKillsNeededDesc = "Display an estimate of how many kills are needed based on MobMap drop rates",
	killsNeeded = "Muertes necesarias",

	trimToolTip = "Ajustar información del bocadillo",
	trimToolTipDesc = "Trim quest/objective titles to XX characters before displaying in mob and item tooltips.  Set to 0 to disable.",

	--Minion unlocked
	["MinionUnlocked"] = "Minion está desbloqueado",
	["PlaceMinion"] = "Place minion and lock it.\nYou can lock it by right clicking on the FuBar/minimap icon.",

	--Zone tooltips
	["ZoneHidden"] = "Zona oculta",
	["TrackedQuests"] = "Misiones mostradas",
	["HiddenQuests"] = "Misiones ocultas",
	["ZoneTips"] = "Sugerencia : <click-derecho> para mostrar/ocultar misiones\n           <Alt> + <click-derecho> para mostrar todas las zonas",

	--Quest tooltips
	["Total"] = "Total",
	["QuestTips"] = "Sugerencia : <Alt> click> para mostar/ocultar objetivos",
} end)
