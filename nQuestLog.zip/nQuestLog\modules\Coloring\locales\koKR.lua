﻿local L = AceLibrary("AceLocale-2.2"):new("Coloring")

L:RegisterTranslations("koKR", function() return {
	["Coloring"] = "색깔 설정",
	["Description"] = "퀘스트 알림창의 메시지에 대한 색상을 변경해주는 모듈입니다.",
	
	["level"] = "레벨",
	["progress"] = "진행상황",
	colorBy = "%s의 색상",
	colorByDesc = "%s의 색상이 사용자 색상으로 변경됩니다.",
	customColor = "사용자 %s 색상 사용",
	customColorDesc = "%s 색상의 선택한 사용자 색상을 사용합니다.",
	
	["Impossible"] = "불가능",
	["red"] = "빨강",
	["Very difficult"] = "어려움",
	["orange"] = "주황",
	["Difficult"] = "보통",
	["yellow"] = "노랑",
	["Standard"] = "쉬움",
	["green"] = "녹색",
	["Trivial"] = "아주 쉬움",
	["gray"] = "회색",
	colorFor = "\"%s\"의 색상.",
	colorDefault = "기본값 : %s.",
	
	["Start"] = "시작시",
	["Halfway"] = "50%",
	["End"] = "완료시",
	showProgress = "%s의 색상 지정",
	showProgressDesc = "%s의 색상이 지정되었습니다. 0%% 에서 100%%로 진행됨에 따라 색상이 변합니다.",
	progressDesc = "%s 진행의 색상을 변경합니다.",
	
	["Change color settings for"] = "색상 설정을 변경합니다.",
	
	["trackerBorderColor"] = "진행창 테투리 색상",
	["trackerBackgroundColor"] = "진행창 배경 색상",
	
	["zoneHeader"] = "지역 텍스트",
	["zoneLevel"] = "지역 레벨",
	
	["questHeader"] = "퀘스트 텍스트",
	["questHighlight"] = "퀘스트 강조",
	["questProgress"] = "퀘스트 진행 상황",
	["questFailed"] = "퀘스트 실패 텍스트",
	["questGoto"] = "퀘스트 방향 텍스트",
	["questDone"] = "퀘스트 완료 텍스트",
	
	["objectiveHeader"] = "퀘스트 목표 텍스트",
	["objectiveProgress"] = "퀘스트 진행 상황",
	["objectiveText"] = "퀘스트 목표 텍스트",
	
	["notificationColor"] = "알림 색상",
} end)
