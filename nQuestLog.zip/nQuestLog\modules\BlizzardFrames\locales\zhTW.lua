﻿local L = AceLibrary("AceLocale-2.2"):new("BlizzardFrames")

L:RegisterTranslations("zhTW", function() return {
	["BlizzardFrames"] = "增強任務日誌",
	["Description"] = "增強遊戲默認的任務日誌",
	hideTracker = "隱藏跟蹤器",
	hideTrackerDesc = "隱藏原有的暴雪任務跟蹤視窗",
	["Quest log"] = "任務日誌",
	["Add quest levels"] = "添加任務等級",
	["addLogQuestLevels"] = "在遊戲默認的任務日誌上添加任務等級。",
	["Add quest givers"] = "添加任務委託人",
	["addLogQuestGivers"] = "在遊戲默認的任務日誌中添加任務委託人的資訊。",
	logMove = "移動任務視窗",
	logMoveDesc = "允許拖動並重新擺放暴雪任務日誌視窗的位置。",
	logScale = "縮放",
	logScaleDesc = "設置暴雪任務日誌的縮放比例（相對於當前UI縮放比例）。",
	["Dialog"] = "對話",
	["addDialogQuestLevels"] = "在NPC閒談視窗上顯示任務等級。",
	["Grey incomplete quest icons"] = "灰色標記未完成任務",
	["greyIncompleteQuestIcons"] = "在NPC閒談窗口上對未完成的任務灰色標記。",
	["Given by"] = "委託人",
	["Location"] = "地區",
	["yd"] = "碼", --abbreviation for yard, a measure of distance
} end)
