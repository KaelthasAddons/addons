﻿local L = AceLibrary("AceLocale-2.2"):new("QuestGivers")

L:RegisterTranslations("esES", function() return {
	["QuestGivers"] = "Donantes de Misiones",
	["Description"] = "Rastrea localizaciones de donantes de misión",
	["%s in %s (%d,%d)"] = "%s en %s (%d,%d)",
	["%s in %s (%d,%d) (%d yd)"] = "%s en %s (%d,%d) (%d m)",
} end)
