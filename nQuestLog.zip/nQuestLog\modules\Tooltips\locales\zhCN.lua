﻿local L = AceLibrary("AceLocale-2.2"):new("Tooltips")

L:RegisterTranslations("zhCN", function() return {
	["Tooltips"] = "信息提示",
	["Description"] = "设置信息提示的详细选项",
	["Enabled"] = "开启",
	
	--Tooltip anchor
	tooltipAnchor = "信息提示锚定位置",
	tooltipAnchorDesc = "设置信息提示相对于追踪面板锚定点的位置",
	["DEFAULT"] = "默认",
	["TOPRIGHT"] = "右上",
	["RIGHT"] = "右",
	["BOTTOMRIGHT"] = "右下",
	["TOPLEFT"] = "左上",
	["LEFT"] = "左",
	["BOTTOMLEFT"] = "左下",
	
	--Item tooltip
	itemToolTip = "物品提示",
	itemToolTipDesc = "在物品提示中显示任务信息",
	
	--Mob tooltip
	mobToolTip = "怪物提示",
	mobToolTipDesc = "在怪物提示中显示任务信息",
	mobToolTipTrigger = "添加信息于……",
	mobToolTipTriggerDesc = "选择何时向信息提示中添加内容。",
	mobToolTipTriggerBoth = "鼠标停在怪物身上和头像上时",
	mobToolTipTriggerMob = "只有鼠标停在怪物身上时",
	disableInRaidInstance = "在团队中关闭",
	disableInRaidInstanceDesc = "在团队中时将禁用怪物提示，以节约资源。",
	useMobMap = "使用MobMap",
	useMobMapDesc = "将使用MobMap的掉落数据",
	MobMapDropRateFilter = "设置最小物品掉落等级",
	MobMapDropRateFilterDesc = "过滤数据，未到达设定等级的物品将不显示。",
	addMobMapDropRates = "显示掉落物品等级",
	addMobMapDropRatesDesc = "在怪物提示中显示MobMap的掉落物品等级",
	addKillsNeeded = "显示击杀数量提示",
	addKillsNeededDesc = "根据MobMap的数据,在怪物信息提示中显示需要击杀的大概数量",
	killsNeeded = "击杀数量",
	
	trimToolTip = "截断提示信息",
	trimToolTipDesc = "将提示信息中的文字截断为指定的字符数。设置为0则禁用。",
	
	--Minion unlocked
	["MinionUnlocked"] = "追踪面板未锁定",
	["PlaceMinion"] = "配置追踪面板并锁定.\n右键点击Fubar或者小地图上的图标可锁定面板.",
	
	--Zone tooltips
	["ZoneHidden"] = "区域隐藏",
	["TrackedQuests"] = "已显示任务",
	["HiddenQuests"] = "已隐藏任务",
	["ZoneTips"] = "提示 :\n右键点击:显示/隐藏 任务\nAlt + 右键可展开所有地区",
	
	--Quest tooltips
	["Total"] = "总共",
	["QuestTips"] = "提示 : Alt+左键 显示/隐藏 任务目标",
} end)
