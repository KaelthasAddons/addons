﻿local L = AceLibrary("AceLocale-2.2"):new("nQuestLog")

L:RegisterTranslations("zhTW", function() return {
	--Generic:
	["Auto fade"] = "自動消失",
	["Auto show"] = "自動顯示",
	["Configure"] = "設置",
	["decrease"] = "減少",
	["Default : "] = "默認:",
	[" (done)"] = "(完成)",
	["Enabled"] = "啟用",
	["Fade-in"] = "淡入",
	["Fade-out"] = "淡出",
	[" (failed)"] = "(失敗)",
	["Font outline"] = "字體描邊",
	["Font size"] = "文字大小",
	[" (goto)"] = "(轉到)",
	["Grow upwards"] = "向上擴展",
	["Hidden"] = "隱藏",
	[" hidden)"] = "隱藏)",
	["Hide completed"] = "隱藏已完成的",
	["increase"] = "增加",
	["Locked"] = "已鎖定",
	["Main settings"] = "主要設置",
	["Module settings"] = "模組設置",
	["Open configuration frame"] = "打開配置面板",
	["Padding"] = "間距",
	["Set width of frame"] = "設置表單寬度",
	["settings"] = "選項",
	["Shown"] = "顯示",
	["Smart"] = "智能",
	["Toggle showing"] = "切換顯示",
	["Unlocked"] = "解鎖",
	[" visible)"] = "可見)",
	["Visible"] = "可見",
	["Width"] = "寬度",
	
	--Object points:
	["BOTTOMLEFT"] = "左下",
	["BOTTOMRIGHT"] = "右下",
	["TOPLEFT"] = "左上",
	["TOPRIGHT"] = "右上",
	
	--Mouse clicks:
	["Alt-Click"] = "Alt+左鍵",
	["Click"] = "左鍵",
	["Ctrl-Click"] = "Ctrl+左鍵",
	["Right-Click"] = "點擊右鍵",
	["Shift-Click"] = "Shift+左鍵",
	
	--Minion related:
	["Add outline to minion font"] = "為面板中的文字描邊",
	["Change font size for minion header"] = "更改跟蹤面板標題字體大小",
	["Expand/Collapse minion"] = "展開/收起跟蹤面板",
	["Grow minion up"] = "向上擴展追蹤面板",
	["Header"] = "標題",
	["Lock minion"] = "鎖定追蹤面板",
	["Lock/Unlock minion"] = "鎖定/解鎖追蹤面板",
	["Minion"] = "追蹤面板",
	["Minion locked"] = "面板已鎖",
	["Minion must be locked for proper functionality!"] = "追蹤面板必須被鎖至合適的位置！",
	["Minion status"] = "面板狀態",
	["Minion visible"] = "顯示追蹤面板",
	["Note that minion will not show if you are not tracking any quests."] = "注意:當沒有追蹤任務時，面板會隱藏。",
	["Reset minion position"] = "重置追蹤面板位置",
	["Resets the position of the minion to the center of the screen"] = "重置追蹤面板至螢幕正中",
	["Show/Hide minion"] = "顯示/隱藏追蹤面板",
	["Title text"] = "標題文字",
	expandCollapseDesc = "如果當前區域是收起狀態則展開，否則展開全部區域。如果全部區域都已展開則會收起。",
	minionHeader = "在追蹤視窗上方顯示標題",
	minionHeaderTitle = "要在標題上顯示的文字，什麼都不寫的話就會隱藏標題。",
	minionAnchor = "框架錨點",
	minionAnchorDesc = "當更改跟蹤面板的大小時作為一個參考點。",
	minionAutoWidth = "自動更改寬度",
	minionAutoWidthDesc = "自動更改跟蹤面板的寬度以符合當前顯示的最長的區域/任務/目標名稱。",
	minionFade = "%s透明度",
	minionFadeDesc = "當滑鼠%s跟蹤面板時，逐漸%s框架的透明度，直到達到這個值。", --%s = minionFadeIsOver OR minionFadeLeaves, %s = "increase" OR "decrease"
	minionFadeTime = "%s過渡時間", --%s = "Fade-in" OR "Fade-out"
	minionFadeTimeDesc = "在指定的時間內逐漸的%s框架透明度達到%s的透明度。", --%s = "increase" OR "decrease", %s = "Fade-in" OR "Fade-out"
	minionFadeDelay = "%s延遲", --%s = "Fade-in" OR "Fade-out"
	minionFadeDelayDesc = "在滑鼠離開追蹤面板後XX秒才淡出面板。",
	minionFadeIsOver = "移動到", --First %s in minionFadeDesc
	minionFadeLeaves = "離開", --First %s in minionFadeDesc
	minionResetConfirm = "你確定要重置追蹤面板的位置麼？",
	
	--Zone related:
	["Change font size for zone"] = "更改當前區域的文字大小",
	["Change padding between zones"] = "更改兩個區域間的間隔距離",
	["Hide zone"] = "隱藏區域",
	["Show empty zones"] = "顯示空白區域",
	["Show hidden zones where you are not tracking any quests"] = "顯示/隱藏沒有追蹤任務的區域",
	["Show visible/total quests for a zone"] = "顯示任務情況",
	["Show zone"] = "顯示區域",
	["Show zone level"] = "顯示區域等級",
	["Shows <Zone> with X/X visible"] = "顯示某區域有多少任務被追蹤以及該區域的任務總數",
	["Toggle zone visibility"] = "更改區域顯示特性",
	["Zone"] = "區域",
	["Zone visibility:"] = "區域可見性：",
	
	--Quest related:
	["Show completed quests"] = "顯示已完成的任務",
	showQuestsDone = "顯示已完成的任務的總數",
	["Show hidden quests"] = "顯示隱藏的任務",
	showQuestsHidden = "顯示隱藏的任務的總數",
	["Show active quests"] = "顯示進行中的任務",
	showQuestsActive = "顯示但前正在完成的任務的總數",
	["Show max quests"] = "顯示最大任務數",
	showQuestsMax = "顯示進行中的任務的最大值",
	["Auto show hidden quests when you loot a quest item for it"] = "當拾取某任務物品時，自動顯示/隱藏與該物品相關的任務",
	["Auto show new quests in minion"] = "自動顯示新任務",
	["Change font size for quests"] = "改變任務字體",
	["Change padding between quests"] = "更改每個任務之間的間隔距離",
	["no quests to track"] = "沒有追蹤任務時",
	["Listing all quests"] = "列出所有任務",
	["Listing all watched quests"] = "列出所有已追蹤任務",
	["New quests"] = "新任務",
	["Quest"] = "任務",
	["Show quest progress"] = "顯示任務進度",
	["%s items total"] = "%s 總計",
	["Watched quests"] = "已追蹤的任務",
	["When looting quest item"] = "當拾取任務物品時",
	
	--Quest objectives related:
	["Default quest objective tracking"] = "默認追蹤任務目標",
	hideObjs = "默認隱藏目標",
	hideObjsDesc = "默認隱藏所有任務目標。",
	hideCompletedObjs = "隱藏已達成的目標",
	hideCompletedObjsDesc = "隱藏所有已經達成的目標，本選項覆蓋其他可見性選項。",
	["Quest objectives"] = "任務目標",
	["Reset manually watched objectives"] = "重置任務目標顯示設置",
	showDescNoObjs = "當沒有任務目標時,顯示任務描述",
	showDescNoObjsDesc = "在沒有任務進度可用時，顯示一個簡略的任務描述。",
	["Show/Hide objectives"] = "顯示/隱藏任務目標",
	
	--Item related:
	["<not yet cached>"] = "<尚未緩存>",
	--Unsafe item tooltip, copied from AtlasLoot
	["Unsafe Item"] = "不安全物品",
	["ItemID:"] = "物品ID：",
	["unsafeItemWarning"] = "該物品不安全，查看該物品將有從伺服器斷開連接的可能。"..
		"你必須在遊戲中見過該物品一次，這是暴雪在1.10補丁中加入的一個限定", 
	["queryItemWarning"] = "你可以用左擊該物品向伺服器查詢它，但是該行為可能導致失去連接。", 
	
	--nQuestLogFuBar:
	["FuBarPlugin options"] = "FuBar選項",
	["FuBarPlugin options desc"] = "標準的選項，外加文本和提示資訊選項。",
	["Text options"] = "文本選項",
	["Tooltip options"] = "工具條選項",
	["Show minion status"] = "顯示面板狀態",
	["showFuMinionStatus"] = "顯示所有的面板.",
	["Show hint"] = "顯示注意事項",
	["showFuHint"] = "顯示工具條注意事項.",
	["Standard options"] = "標準選項",
	["waterfallError"] = "需要庫Waterfall-1.0才能使用配置視窗.",
	["Quest status"] = "任務狀態",
	["Completed"] = "已完成",
	["Active"] = "進行中",
	["%s for options."] = "選項：%s", -- %s is a mouse click
	["%s to configure."] = "配置：%s", -- %s is a mouse click
	["%s to expand/collapse."] = "展開/收起：%s", -- %s is a mouse click
	["%s to lock/unlock."] = "鎖定/解鎖：%s", -- %s is a mouse click
	["%s to show/hide."] = "顯示/隱藏：%s", -- %s is a mouse click
} end)
