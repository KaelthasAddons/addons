﻿local L = AceLibrary("AceLocale-2.2"):new("DetailsFrame")

L:RegisterTranslations("esES", function() return {
	["DetailsFrame"] = "MarcoDetalles",
	["Description"] = "Marco de detalles de misión más informativo y más bonito",
	["Minimum width"] = "Ancho mínimo",
	["Set the minimum width of the Details frame"] = "Establece el ancho mínimo del marco de Detalles",
	["Maximum height"] = "Altura máxima",
	["Set the maximum height of the Details frame"] = "Establece la altura máxima del marco de Detalles",

	["(done)"] = "(hecho)",
	["(failed)"] = "(fallado)",
	["Given by"] = "Obtenida de",
	["Required money: "] = "Dinero necesario: ",
	["Text"] = "Texto",
	["%s in %s (%d,%d)"] = "%s en %s (%d,%d)",

	["Description"] = "Descripción",
	["Rewards"] = "Recompensa",
	["Choose from:"] = "Elegir entre:",
	["Always receive:"] = "Siempre recibe:",
	["Spell:"] = "Magia:",
	["Money: "] = "Dinero:",
	["Nothing."] = "Nada.",
	["Options"] = "Opciones",
	["- Share"] = " - Compartir",
	["- Abandon"] = "- Abandonar",
	["[ Close ]"] = "[ Cerrar ]",

	["<not yet cached>"] = "<No cacheado>",

	["bunch-of-directions"] = {
		"([^%a%d])(norte)([^%a%d])",
		"([^%a%d])(del norte)([^%a%d])",
		"([^%a%d])(oeste)([^%a%d])",
		"([^%a%d])(occidental)([^%a%d])",
		"([^%a%d])(este)([^%a%d])",
		"([^%a%d])(oriental)([^%a%d])",
		"([^%a%d])(sur)([^%a%d])",
		"([^%a%d])(meridional)([^%a%d])",
		"([^%a%d])(noroeste)([^%a%d])",
		"([^%a%d])(del noroeste)([^%a%d])",
		"([^%a%d])(noreste)([^%a%d])",
		"([^%a%d])(del noreste)([^%a%d])",
		"([^%a%d])(sudoeste)([^%a%d])",
		"([^%a%d])(del sudoeste)([^%a%d])",
		"([^%a%d])(sudeste)([^%a%d])",
		"([^%a%d])(del sudeste)([^%a%d])",
	}
} end)
