﻿local L = AceLibrary("AceLocale-2.2"):new("SmartVisibility")

L:RegisterTranslations("enUS", function() return {
	["SmartVisibility"] = true,
	["Description"] = "Deals with showing/hiding things automatically",
	
	["Zone"] = true,
	zoneAutoCollapse = "Auto-collapse zones",
	zoneAutoCollapseDesc = "Automatically collapse zone headers for all zones except the current one.",
	zoneAutoExpand = "Auto-expand zones",
	zoneAutoExpandDesc = "Automatically expand the zone header for the current zone.",
	
	["Quests"] = true,
	questHideDone = "Hide completed quests",
	questHideDoneDesc = "Automatically hide quests when all objectives have been completed.  To show a hidden quest, right-click the quest's zone or use the menu.",
	
	["Objectives"] = true,
	objShowZone = "Show objectives for current zone",
	objShowZoneDesc = "\"Always\" - Show all quest objectives (including those manually unwatched) for the current zone."..
		"\n\n\"By Default\" - Any quests that have been manually watched or unwatched are not affected by this option"..
		" (reset manually watched objectives via the menu to fix this).",
	["option disabled"] = true,
	["Always"] = true,
	["By default"] = true,
	objShowActive = "Show active quest objectives",
	objShowActiveDesc = "Show quest objectives that have been updated within X minutes.  Set to \"0\" to disable.",
	objShowNew = "Show objectives for new quests",
	objShowNewDesc = "Consider new quest objectives to be active and use the timer for showing active quest objectives.",
} end)
