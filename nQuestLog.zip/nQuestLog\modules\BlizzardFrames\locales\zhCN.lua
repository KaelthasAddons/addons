﻿local L = AceLibrary("AceLocale-2.2"):new("BlizzardFrames")

L:RegisterTranslations("zhCN", function() return {
	["BlizzardFrames"] = "增强任务日志",
	["Description"] = "增强游戏默认的任务日志",
	hideTracker = "隐藏跟踪器",
	hideTrackerDesc = "隐藏原有的暴雪任务跟踪窗口",
	["Quest log"] = "任务日志",
	["Add quest levels"] = "添加任务等级",
	["addLogQuestLevels"] = "在游戏默认的任务日志上添加任务等级。",
	["Add quest givers"] = "添加任务委托人",
	["addLogQuestGivers"] = "在游戏默认的任务日志中添加任务委托人的信息。",
	logMove = "移动任务窗口",
	logMoveDesc = "允许拖动并重新摆放暴雪任务日志窗口的位置。",
	logScale = "缩放",
	logScaleDesc = "设置暴雪任务日志的缩放比例（相对于当前UI缩放比例）。",
	["Dialog"] = "对话",
	["addDialogQuestLevels"] = "在NPC闲谈窗口上显示任务等级。",
	["Grey incomplete quest icons"] = "灰色标记未完成任务",
	["greyIncompleteQuestIcons"] = "在NPC闲谈窗口上对未完成的任务灰色标记。",
	["Given by"] = "委托人",
	["Location"] = "地区",
	["yd"] = "码", --abbreviation for yard, a measure of distance
} end)
