﻿local L = AceLibrary("AceLocale-2.2"):new("Comments")

L:RegisterTranslations("enUS", function() return {
	["Comments"] = true,
	["Description"] = "wowhead.com comments on quest details.",
	["Minimum width"] = true,
	["Set the minimum width of the Comments frame"] = true,
	["Maximum height"] = true,
	["Set the maximum height of the Comments frame"] = true,
	
	["%s Comments"] = true, --%s is "Lightheaded"
	["%s ID"] = true, --%s is "Quest"
	["%s Info"] = true, --%s is "Lightheaded" or "MobMap"
	["%s-only"] = true, --%s is "Horde" or "Alliance"
	["%s Rewards"] = true, --%s is "Lightheaded" or "MobMap"
	["%s %s Series"] = true, --%s is "Lightheaded", "Quest"
	["%s Type"] = true, --%s is "Quest"
	
	["<not yet cached>"] = true,
	["Always receive"] = true,
	["Choose from"] = true,
	["Coordinates"] = true,
	["Ends"] = true, --as in "The quest *ends* at..."
	["Quest"] = true,
	["Rep"] = true, --abbreviation for "Reputation"
	["Req Lvl"] = true, --abbreviation for "Required Level"
	["Sharable"] = true,
	["Source"] = true, --as in "The *source* of the quest"
	["Starts"] = true, --as in "The quest *starts* at..."
	["No comments found"] = true,
	["%s data is from %s"] = true, --%s is "Lightheaded", "Wowhead"
} end)
