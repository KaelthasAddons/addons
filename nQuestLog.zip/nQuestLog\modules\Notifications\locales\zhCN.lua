﻿local L = AceLibrary("AceLocale-2.2"):new("Notifications")

L:RegisterTranslations("zhCN", function() return {
	Notifications = "进度通知",
	Description = "当任务有进度时通知",
	
	["%s notifications"] = "%s通知", --%s = "Text" OR "Sound"
	["Text"] = "文本",
	["Sound"] = "声音",
	
	testOutput = "测试",
	testOutputDesc = "点击开始发出一个测试用的通知",
	fakeQuest = "嘿，你刚刚完成了一个有趣的任务！",
	
	questDone = "完成任务", --also used in notifications
	questDoneDesc = "当整个任务完成时通知",
	
	objDone = "完成任务目标", --also used in notifications
	objDoneDesc = "当某项任务目标完成时通知",
	objDoneSoundDesc = "当某项任务完成了一个目标，但是至少还有一个以上的目标没有完成时通知。",
	objProgress = "目标进展",
	objProgressDesc = "当某项目标有所进展时通知。",
	objProgressHidden = "仅当任务隐藏时",
	objProgressHiddenDesc = "只有当这个任务处于隐藏状态时才通知进展。",
	objQuestName = "包含任务名称",
	objQuestNameDesc = "在目标通知时也同时显示该目标所属的任务名称。",
	hideBlizz = "隐藏暴雪的任务通知",
	hideBlizzDesc = "隐藏屏幕上方暴雪原有的任务进度通知文字。",
	
	multiToggle = "小窍门：如果选择了多项，便可以自动在这些选项中随机挑选一个声音播放。",
	["%s \"Job's done!\""] = "%s \"Job's done!\"",
	["%s \"More work?\""] = "%s \"还有工作要做？\"",
	["%s \"Ready to work!\""] = "%s \"准备工作！\"",
	["%s \"Something need doing?\""] = "%s \"有事情要做吗？\"",
	["%s \"Work complete!\""] = "%s \"工作完成！\"",
	["Flag captured"] = "夺得旗帜",
	["Peasant"] = "农民",
	["Peon"] = "苦工",
	["Ready check"] = "就绪确认",
	
	blizzProgressPattern = "^.+：?%d+/%d+$", -- pattern to suppress Blizzard objective progress messages
} end)
