﻿--Caution:  This file must remain encoded in UTF-8 format when saving!
--harl windwolf (harldephin@freenode), November 26, 2007

local L = AceLibrary("AceLocale-2.2"):new("nQuestLog")

L:RegisterTranslations("deDE", function() return {
	--Generic:
	["Auto fade"] = "Auto fade", --Need translation
	["Auto show"] = "Autom. anzeigen",
	["Configure"] = "Konfigurieren",
	["decrease"] = "decrease", --Need translation
	["Default : "] = "Standard : ",
	[" (done)"] = " (erledigt)",
	["Enabled"] = "Enabled", --Need translation
	["Fade-in"] = "Fade-in", --Need translation
	["Fade-out"] = "Fade-out", --Need translation
	[" (failed)"] = " (fehlgeschlagen)",
	["Font outline"] = "Schrift-Kontur",
	["Font size"] = "Schriftgröße",
	[" (goto)"] = " (gehe zu)",
	["Grow upwards"] = "Nach oben ansteigen",
	["Hidden"] = "Versteckt",
	[" hidden)"] = " versteckt)",
	["Hide completed"] = "Beendete verstecken",
	["increase"] = "increase", --Need translation
	["Locked"] = "Verriegelt",
	["Main settings"] = "Haupteinstellungen",
	["Module settings"] = "Module-Einstellungen",
	["Open configuration frame"] = "Öffne das Konfigurations-Fenster",
	["Padding"] = "Abstand",
	["Set width of frame"] = "Die Breite des Fensters festlegen",
	["settings"] = "Einstellungen",
	["Shown"] = "Angezeigt",
	["Smart"] = "Smart",
	["Toggle showing"] = "Anzeigen ein/aus",
	["Unlocked"] = "Entriegelt",
	[" visible)"] = " sichtbar)",
	["Visible"] = "Sichtbar",
	["Width"] = "Breite",
	
	--Object points:
	["BOTTOMLEFT"] = "BOTTOMLEFT", --Need translation
	["BOTTOMRIGHT"] = "BOTTOMRIGHT", --Need translation
	["TOPLEFT"] = "TOPLEFT", --Need translation
	["TOPRIGHT"] = "TOPRIGHT", --Need translation
	
	--Mouse clicks:
	["Alt-Click"] = "Alt-Klick",
	["Click"] = "Klick",
	["Ctrl-Click"] = "Strg-Click",
	["Right-Click"] = "Rechts-Klick",
	["Shift-Click"] = "Shift-Klick",
	
	--Minion related:
	["Add outline to minion font"] = "Fügt der Schrift des Trackers eine Kontur hinzu",
	["Change font size for minion header"] = "Change font size for minion header", --Need translation
	["Expand/Collapse minion"] = "Expand/Collapse minion", --Need translation
	["Grow minion up"] = "Lässt den Tracker nach oben ansteigen",
	["Header"] = "Header", --Need translation
	["Lock minion"] = "Tracker festsetzen",
	["Lock/Unlock minion"] = "Ver-/Entriegele Tracker",
	["Minion"] = "Tracker",
	["Minion locked"] = "Tracker verriegelt",
	["Minion must be locked for proper functionality!"] = "Tracker muss verriegelt werden, um voll funktionsfähig zu sein!",
	["Minion status"] = "Tracker-Status",
	["Minion visible"] = "Tracker sichtbar",
	["Note that minion will not show if you are not tracking any quests."] = "Beachte, dass der Tracker nicht angezeigt wird, wenn du keine Quests verfolgst.",
	["Reset minion position"] = "Die Position des Trackers zurücksetzen",
	["Resets the position of the minion to the center of the screen"] = "Setzt die Position des Trackers auf die Mitte des Bildschirms zurück",
	["Show/Hide minion"] = "Zeige/Verstecke Tracker",
	["Title text"] = "Title text", --Need translation
	expandCollapseDesc = "Expand current zone if collapsed, otherwise expand all zones.  Collapse all zones if already expanded.", --Need translation
	minionHeader = "Show header at the top of the minion.", --Need translation
	minionHeaderTitle = "Text to display as a title in the minion header.  Set to nothing to hide the title.", --Need translation
	minionAnchor = "Frame anchor", --Need translation
	minionAnchorDesc = "Used as a reference point when resizing the minion.", --Need translation
	minionAutoWidth = "Auto-resize width", --Need translation
	minionAutoWidthDesc = "Automatically resize the minion's width according to the longest zone/quest/objective name currently displayed.", --Need translation
	minionFade = "%s alpha", --%s = "Fade-in" OR "Fade-out" --Need translation
	minionFadeDesc = "When the mouse %s the minion, %s the frame opacity until it reaches this value.", --%s = minionFadeIsOver OR minionFadeLeaves, %s = "increase" OR "decrease" --Need translation
	minionFadeTime = "%s time", --%s = "Fade-in" OR "Fade-out" --Need translation
	minionFadeTimeDesc = "Gradually %s the frame opacity to the %s value over XX seconds.", --%s = "increase" OR "decrease", %s = "Fade-in" OR "Fade-out" --Need translation
	minionFadeDelay = "%s delay", --%s = "Fade-in" OR "Fade-out" --Need translation
	minionFadeDelayDesc = "Delay frame fade-out for XX seconds after the mouse leaves the minion.", --Need translation
	minionFadeIsOver = "is over", --First %s in minionFadeDesc --Need translation
	minionFadeLeaves = "leaves", --First %s in minionFadeDesc --Need translation
	minionResetConfirm = "Are you sure you want to reset the minion position?", --Need translation
	
	--Zone related:
	["Change font size for zone"] = "Die Schriftgröße der Zone(n) ändern",
	["Change padding between zones"] = "Den Zwischenraum zwischen den Gebieten ändern",
	["Hide zone"] = "Gebiet verstecken",
	["Show empty zones"] = "Leere Gebiete anzeigen",
	["Show hidden zones where you are not tracking any quests"] = "Versteckte Gebiete, in denen du keine Quests verfolgst, anzeigen",
	["Show visible/total quests for a zone"] = "Sichtbare/Totale Quest für ein Gebiet anzeigen",
	["Show zone"] = "Gebiet anzeigen",
	["Show zone level"] = "Gebietslevel anzeigen",
	["Shows <Zone> with X/X visible"] = "Zeigt <Gebiet> mit X/X sichtbar",
	["Toggle zone visibility"] = "Gebietssichtbarkeit ein/aus",
	["Zone"] = "Gebiet",
	["Zone visibility:"] = "Gebietssichtbarkeit",
	
	--Quest related:
	["Show completed quests"] = "Zeige abgeschlossene Quests an",
	showQuestsDone = "Zeige die Anzahl aktiver Quests an, für die alle Ziele abgeschlossen sind.",
	["Show hidden quests"] = "Zeige versteckte Quests an",
	showQuestsHidden = "Zeige die Anzahl der aktiven Quests an, die versteckt sind.",
	["Show active quests"] = "Zeige aktive Quests an",
	showQuestsActive = "Zeige die Anzahl der aktiven (vorhandenen) Quests an.",
	["Show max quests"] = "Zeige maximale Quests an",
	showQuestsMax = "Zeige die maximale Anzahl an aktiven Quests an.",
	["Auto show hidden quests when you loot a quest item for it"] = "Autom. Anzeige von versteckten Quests, wenn du ein Questitem für diese Quest lootest",
	["Auto show new quests in minion"] = "Autom. Anzeige neuer Quests im Tracker",
	["Change font size for quests"] = "Ändere die Schriftgröße der Quests",
	["Change padding between quests"] = "Den Zwischenraum zwischen den Quests Ändern",
	["no quests to track"] = "keine Quests zum Verfolgen",
	["Listing all quests"] = "Alle Quests auflisten",
	["Listing all watched quests"] = "Alle beobachteten Quests auflisten",
	["New quests"] = "Neue Quests",
	["Quest"] = "Quest",
	["Show quest progress"] = "Questfortschritt anzeigen",
	["%s items total"] = "%s Gegenstände total",
	["Watched quests"] = "Beobachtete Quests",
	["When looting quest item"] = "Wenn Questgegenstände geplündert werden",
	
	--Quest objectives related:
	["Default quest objective tracking"] = "Standardmäßige Questzielverfolgung",
	hideObjs = "Hide objectives by default", --Need translation
	hideObjsDesc = "Standardmäßig alle Questziele verstecken.",
	hideCompletedObjs = "Abgeschlossene Ziele verstecken",
	hideCompletedObjsDesc = "Hide all completed quest objectives.  This overrides other visibility options.", --Need translation
	["Quest objectives"] = "Questziele",
	["Reset manually watched objectives"] = "Beobachtete Ziele manuell zurücksetzen",
	showDescNoObjs = "Beschreibung anzeigen wenn keine Ziele",
	showDescNoObjsDesc = "Eine kurze Questbeschreibung anzeigen, wenn kein Fortschritt verfügbar ist.",
	["Show/Hide objectives"] = "Zeige/Verstecke Questziele",
	
	--Item related:
	["<not yet cached>"] = "<bisher nicht gespeichert>", --might be wrong
	--Unsafe item tooltip, copied from AtlasLoot
	["Unsafe Item"] = "Unsicheres Item",
	["ItemID:"] = "ItemID:",
	["unsafeItemWarning"] = "Dieses Item ist unsicher.\nSobald du dieses Item im Spiel gesehen hast,\n"..
		"besteht nicht mehr die Gefahr eines Verbindungsabbruchs\n(Es ist dann nicht mehr unsicher). Diese\nBestimmung wurde von Blizzard mit\nPatch 1.10 festgelegt.",
	["queryItemWarning"] = "Mit einem Linksklick wird der\nServer nach dem Item abgefragt, dabei\nkönnte die Verbindung unterbrochen werden.",
	
	--nQuestLogFuBar:
	["FuBarPlugin options"] = "FuBar-Optionen",
	["FuBarPlugin options desc"] = "Standard FuBar-Optionen, plus Text- und Tooltip-Optionen.",
	["Text options"] = "Text-Optionen",
	["Tooltip options"] = "Tooltip-Optionen",
	["Show minion status"] = "Zeige Tracker-Status an",
	["showFuMinionStatus"] = "Zeigt an, ob der Tracker versteckt oder sichtbar bzw ver- oder entriegelt ist.",
	["Show hint"] = "Zeige Hinweise",
	["showFuHint"] = "Zeige die Tastatur-Hinweise im FuBar-Tooltip an.",
	["Standard options"] = "Standard-Optionen",
	["waterfallError"] = "Waterfall-1.0 wird benötigt, um das Konfigurations-Fenster nutzen zu können.",
	["Quest status"] = "Quest-Status",
	["Completed"] = "Beendet",
	["Active"] = "Aktiv",
	["%s for options."] = "%s für Optionen.", --%s is a mouse click
	["%s to configure."] = "%s für Konfiguration.", --%s is a mouse click
	["%s to expand/collapse."] = "%s zum auf-/zuklappen.", --%s is a mouse click
	["%s to lock/unlock."] = "%s zum ver-/entriegeln.", --%s is a mouse click
	["%s to show/hide."] = "%s zum verstecken/anzeigen.", --%s is a mouse click
} end)
