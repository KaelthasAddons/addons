﻿--Caution:  This file must remain encoded in UTF-8 format when saving!
--harl windwolf (harldephin@freenode), November 26, 2007

local L = AceLibrary("AceLocale-2.2"):new("Tooltips")

L:RegisterTranslations("deDE", function() return {
	["Tooltips"] = "Tooltips",
	["Description"] = "Hierbei geht's um Tooltips und das Hinzufügen von Gegner- und Gegenstands-Infos zu diesen.",
	["Enabled"] = "Aktiv",
	
	--Tooltip anchor
	tooltipAnchor = "Tooltip-Verankerung",
	tooltipAnchorDesc = "Legt den Ankerpunkt des Tracker-Tooltips fest.",
	["DEFAULT"] = "DEFAULT", --Need translation
	["TOPRIGHT"] = "TOPRIGHT", --Need translation
	["RIGHT"] = "RIGHT", --Need translation
	["BOTTOMRIGHT"] = "BOTTOMRIGHT", --Need translation
	["TOPLEFT"] = "TOPLEFT", --Need translation
	["LEFT"] = "LEFT", --Need translation
	["BOTTOMLEFT"] = "BOTTOMLEFT", --Need translation
	
	--Item tooltip
	itemToolTip = "Füge dem Gegenstandstooltip Infos hinzu",
	itemToolTipDesc = "Dies fügt Informationen über eine Quest, zu der ein bestimmter Gegenstand gehört, dessen Tooltip hinzu wenn der Mauszeiger über ihn bewegt wird.",
	
	--Mob tooltip
	mobToolTip = "Gegner-Tooltips",
	mobToolTipDesc = "Füge dem Tooltip eines Gegners die zugehörigen Quests/Ziele hinzu.",
	mobToolTipTrigger = "Hinzufügen, wenn Maus über..",
	mobToolTipTriggerDesc = "Legt die Ereignisse fest, bei denen die Quest-Infos dem Tooltip hinzugefügt werden",
	mobToolTipTriggerBoth = "Gegner oder Unitframe",
	mobToolTipTriggerMob = "Gegner (ausschließlich)",
	disableInRaidInstance = "Deaktivieren wenn im Raid",
	disableInRaidInstanceDesc = "Deaktiviert die Änderungen am Gegner-Tooltip, wenn man sich in einer Schlachtzuginstanz befindet: Weniger unbenötigte CPU-Last, wenn jede Sekunde zählt.",
	useMobMap = "Verwende MobMap",
	useMobMapDesc = "Aktiviert die Verwendung von MobMap. - Setzt mit Hilfe von MobMap die \"drop\"-Raten der quest-relevanten Gegenstände/Ziele mit denen der Gegner gleich und ermöglicht dadurch die im Folgenden erwähnte Schätzung der zur Erreichung des Questziels benötigten Anzahl an Gegnern.",
	MobMapDropRateFilter = "Grenzwert für drop-Raten",
	MobMapDropRateFilterDesc = "Filtert MobMaps Tabellen, sodass Einträge unter dem festgelegten Grenzwert nicht angezeigt werden. Dies sollte helfen, irreführende/falsche Angaben im Tooltip zu vermeiden.",
	addMobMapDropRates = "Zeige drop-Raten an",
	addMobMapDropRatesDesc = "Zeige MobMaps drop-Raten in den Tooltips der Gegner an.",
	addKillsNeeded = "Zeige benötigte Tötungen an",
	addKillsNeededDesc = "Zeigt einen geschätzten/hochgerechneten Wert darüber an, wie viele Tötungen dieses Gegners auf Basis der drop-Raten von MobMap noch nötig sind, um das Questziel zu erreichen.",
	killsNeeded = "Gegner bis Ziel",
	
	trimToolTip = "Trim tooltip info",
	trimToolTipDesc = "Trim quest/objective titles to XX characters before displaying in mob and item tooltips.  Set to 0 to disable.",
	
	--Minion unlocked
	["MinionUnlocked"] = "Der Tracker ist entriegelt.",
	["PlaceMinion"] = "Platziere den Tracker und verriegele ihn.\nRechtsklicke dazu auf das FuBar/Minimap-Symbol.",
	
	--Zone tooltips
	["ZoneHidden"] = "Gebiet versteckt",
	["TrackedQuests"] = "Angezeigte Quests",
	["HiddenQuests"] = "Versteckte Quests",
	["ZoneTips"] = "Hinweis: Rechtsklick -> zeige/verstecke Quests\n         Alt + Rechtsklick -> zeige alle Gebiete",
	
	--Quest tooltips
	["Total"] = "Gesamt", --might be wrong
	["QuestTips"] = "Hinweis: Alt + Klick -> zeige/verstecke Ziele",
} end)
