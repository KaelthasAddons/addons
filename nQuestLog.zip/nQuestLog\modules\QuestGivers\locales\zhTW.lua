﻿local L = AceLibrary("AceLocale-2.2"):new("QuestGivers")

L:RegisterTranslations("zhTW", function() return {
	["QuestGivers"] = "任務委託人",
	["Description"] = "追蹤委託人的NPC座標",
	["%s in %s (%d,%d)"] = "%s － %s（%d, %d）",
	["%s in %s (%d,%d) (%d yd)"] = "%s － %s （%d, %d）（%d碼）",
} end)
