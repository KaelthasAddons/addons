﻿--Caution:  This file must remain encoded in UTF-8 format when saving!
--harl windwolf (harldephin@freenode), November 26, 2007

local L = AceLibrary("AceLocale-2.2"):new("Coloring")

L:RegisterTranslations("deDE", function() return {
	["Coloring"] = "Färbung",
	["Description"] = "Dieses Modul ermöglicht die Einstellung einiger Farben.",
	
	["level"] = "level", --Needs translation
	["progress"] = "progress", --Needs translation
	colorBy = "Color by %s", --Needs translation
	colorByDesc = "Define custom colors to use when coloring by %s.", --Needs translation
	customColor = "Use custom %s colors", --Needs translation
	customColorDesc = "Uses the custom colors defined below when coloring by %s.", --Needs translation
	
	["Impossible"] = "Impossible", --Needs translation
	["red"] = "red", --Needs translation
	["Very difficult"] = "Very difficult", --Needs translation
	["orange"] = "orange", --Needs translation
	["Difficult"] = "Difficult", --Needs translation
	["yellow"] = "yellow", --Needs translation
	["Standard"] = "Standard", --Needs translation
	["green"] = "green", --Needs translation
	["Trivial"] = "Trivial", --Needs translation
	["gray"] = "gray", --Needs translation
	colorFor = "Color for \"%s\".", --Needs translation
	colorDefault = "Default is %s.", --Needs translation
	
	["Start"] = "Start", --Needs translation
	["Halfway"] = "Halfway", --Needs translation
	["End"] = "End", --Needs translation
	showProgress = "Define color for %s", --Needs translation
	showProgressDesc = "Define color for %s progress for further control over the color progression from 0%% to 100%%.", --Needs translation
	progressDesc = "Color to use for %s progress.", --Needs translation
	
	["Change color settings for"] = "Ändere die Farbeinstellungen für",
	
	["trackerBorderColor"] = "Tracker-Randfarbe",
	["trackerBackgroundColor"] = "Tracker-Hintergrundfarbe",
	
	["zoneHeader"] = "Gebiets-Überschrift",
	["zoneLevel"] = "Gebiets-Stufenbereich",
	
	["questHeader"] = "Quest-Überschrift",
	["questHighlight"] = "Quest-Hervorhebung",
	["questProgress"] = "Quest-Fortschritt",
	["questFailed"] = "Quest-\"fehlgeschlagen\"-Text",
	["questGoto"] = "Quest-\"gehe zu\"-Text",
	["questDone"] = "Quest-\"erledigt\"-Text",
	
	["objectiveHeader"] = "Questziel-Überschrift",
	["objectiveProgress"] = "Questziel-Fortschritt",
	["objectiveText"] = "Questziel-Text",
	
	["notificationColor"] = "Farbe der Meldungen",
} end)
