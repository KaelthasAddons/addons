﻿local L = AceLibrary("AceLocale-2.2"):new("nQuestLog")

L:RegisterTranslations("koKR", function() return {
	--Generic:
	["Auto fade"] = "자동으로 숨김",
	["Auto show"] = "자동으로 보기",
	["Configure"] = "설정",
	["decrease"] = "감소",
	["Default : "] = "기본값: ",
	[" (done)"] = " (완료)",
	["Enabled"] = "사용",
	["Fade-in"] = "서서히 표시",
	["Fade-out"] = "서서히 사라짐",
	[" (failed)"] = " (실패)",
	["Font outline"] = "글자 윤곽선",
	["Font size"] = "글자 크기",
	[" (goto)"] = " (가기)",
	["Grow upwards"] = "추가내용 위로 표시",
	["Hidden"] = "숨김",
	[" hidden)"] = "개 숨김)",
	["Hide completed"] = "숨기기 완료",
	["increase"] = "증가",
	["Locked"] = "고정",
	["Main settings"] = "메인 설정",
	["Module settings"] = "모듈 설정",
	["Open configuration frame"] = "설정창을 엽니다.",
	["Padding"] = "간격",
	["Set width of frame"] = "프레임의 길이를 설정합니다.",
	["settings"] = "설정",
	["Shown"] = "보임",
	["Smart"] = "자동",
	["Toggle showing"] = "보기 토글",
	["Unlocked"] = "풀림",
	[" visible)"] = "개 보임)",
	["Visible"] = "보임",
	["Width"] = "길이",
	
	--Object points:
--	["BOTTOMLEFT"] = "BOTTOMLEFT", --Need translation
--	["BOTTOMRIGHT"] = "BOTTOMRIGHT", --Need translation
--	["TOPLEFT"] = "TOPLEFT", --Need translation
--	["TOPRIGHT"] = "TOPRIGHT", --Need translation
	
	--Mouse clicks:
	["Alt-Click"] = "Alt-마우스클릭",
	["Click"] = "마우스클릭",
	["Ctrl-Click"] = "Ctrl-마우스클릭",
	["Right-Click"] = "오른쪽클릭",
	["Shift-Click"] = "Shift-마우스클릭",
	
	--Minion related:
	["Add outline to minion font"] = "폰트에 윤곽선을 표시합니다.",
	["Change font size for minion header"] = "알림창 표제의 글자 크기 변경",
	["Expand/Collapse minion"] = "알림창 확장/축소",
	["Grow minion up"] = "알림창에 추가되는 목표 및 퀘스트를 위로 표시합니다.",
	["Header"] = "표제",
	["Lock minion"] = "알림창 고정",
	["Lock/Unlock minion"] = "일람창 고정/풀림",
	["Minion"] = "알림창 레이아웃",
	["Minion locked"] = "알림창을 프레임을 고정했습니다.",
	["Minion must be locked for proper functionality!"] = "알림창이 고정되었습니다.",
	["Minion status"] = "알림창 상태",
	["Minion visible"] = "퀘스트 알림창 표시",
	["Note that minion will not show if you are not tracking any quests."] = "퀘스트를 받거나 퀘스트 진행이 없더라도 퀘스트 알림창을 보여줍니다.",
	["Reset minion position"] = "알림창 위치 초기화",
	["Resets the position of the minion to the center of the screen"] = "알림창의 위치가 가운데로 초기화 되었습니다.",
	["Show/Hide minion"] = "알림창 보기/숨기기",
	["Title text"] = "제목 글자",
	expandCollapseDesc = "현재 지역이 닫혀있으면 알림창을 펼칩니다. 다른 지역은 반대로 열려 있으면 닫습니다.",
	minionHeader = "알림창의 표제 표시",
	minionHeaderTitle = "알림창의 위쪽에 표재를 표시합니다. 제목을 설정하지 않아도 됩니다.",
	minionAnchor = "프레임 기준",
	minionAnchorDesc = "알림창의 기준 위치를 설정합니다.",
	minionAutoWidth = "자동 크기조절",
	minionAutoWidthDesc = "퀘스트 이름과 목표의 길이에 따라 자동으로 알림창의 길이를 조절합니다.",
	minionFade = "%s 투명도", --%s = "Fade-in" OR "Fade-out"
	minionFadeDesc = "마우스가 알림창에 %s 할 때, 투명도가 %s 합니다.", --%s = minionFadeIsOver OR minionFadeLeaves, %s = "increase" OR "decrease"
	minionFadeTime = "%s 시간", --%s = "Fade-in" OR "Fade-out"
	minionFadeTimeDesc = "XX 초 시간이 지나면 %2$s의 투명도가 %1$s 합니다.", --%s = "increase" OR "decrease", %s = "Fade-in" OR "Fade-out"
	minionFadeDelay = "%s 지연", --%s = "Fade-in" OR "Fade-out"
	minionFadeDelayDesc = "알림창의 마우스가 떠난 후 XX 초 다음에 사라집니다.",
	minionFadeIsOver = "완료", --First %s in minionFadeDesc
	minionFadeLeaves = "떠남", --First %s in minionFadeDesc
	minionResetConfirm = "퀘스트 알림창의 위치를 초기화 합니까?",
	
	--Zone related:
	["Change font size for zone"] = "알림창의 글자 크기를 설정합니다.",
	["Change padding between zones"] = "퀘스트 수행 지역간 간격을 설정합니다.",
	["Hide zone"] = "지역 숨기기",
	["Show empty zones"] = "빈 지역 보기",
	["Show hidden zones where you are not tracking any quests"] = "퀘스트 상황이 숨겨진 지역도 표시합니다.",
	["Show visible/total quests for a zone"] = "진행중인 퀘스트 갯수 표시",
	["Show zone"] = "지역 보기",
	["Show zone level"] = "퀘스트 수행 지역의 레벨을 표시합니다.",
	["Shows <Zone> with X/X visible"] = "각 지역의 '수행중/전체' 퀘스트의 갯수를 표시합니다.",
	["Toggle zone visibility"] = "지역 보기 토글",
	["Zone"] = "지역 레이아웃",
	["Zone visibility:"] = "지역 보기",
	
	--Quest related:
	["Show completed quests"] = "완료된 퀘스트 보기",
	showQuestsDone = "완료된 퀘스트를 표시합니다.",
	["Show hidden quests"] = "비진행중인 퀘스트 보기",
	showQuestsHidden = "현재 수행하고 있지 않은 퀘스트를 표시합니다.",
	["Show active quests"] = "현재 진행중인 퀘스트 보기",
	showQuestsActive = "현재 진행하고 있는 퀘스트를 표시합니다.",
	["Show max quests"] = "전체 퀘스트 보기",
	showQuestsMax = "모든 퀘스트를 표시합니다.",
	["Auto show hidden quests when you loot a quest item for it"] = "퀘스트 아이템을 집었을 때 자동으로 퀘스트를 등록합니다.",
	["Auto show new quests in minion"] = "새로운 퀘스트를 받으면 자동으로 알림창에 등록합니다.",
	["Change font size for quests"] = "퀘스트의 폰트 사이즈를 변경합니다.",
	["Change padding between quests"] = " 퀘스트사이의 간격을 설정합니다.",
	["no quests to track"] = "퀘스트 없음",
	["Listing all quests"] = "모든 퀘스트 리스트 보기",
	["Listing all watched quests"] = "모든 퀘스트 리스트의 보기/숨기기를 바꿉니다.",
	["New quests"] = "새로운 퀘스트 보기",
	["Quest"] = "퀘스트",
	["Show quest progress"] = "퀘스트 진행상황 표시",
	["%s items total"] = "%s 아이템 획득",
	["Watched quests"] = "퀘스트 보기",
	["When looting quest item"] = "퀘스트 아이템 수집시 보기",
	
	--Quest objectives related:
	["Default quest objective tracking"] = "퀘스트 목표 기록을 기본값으로 돌립니다.",
	hideObjs = "퀘스트 목표 숨기기",
	hideObjsDesc = "모든 퀘스트 목표를 숨깁니다.",
	hideCompletedObjs = "퀘스트의 완료된 목표는 숨깁니다",
	hideCompletedObjsDesc = "모든 완료된 퀘스트의 목표를 숨깁니다.",
	["Quest objectives"] = "퀘스트 목표",
	["Reset manually watched objectives"] = "선택한 퀘스트 목표 보기를 초기화 합니다",
	showDescNoObjs = "목표 없는 퀘스트 설명표시",
	showDescNoObjsDesc = "퀘스트의 목표의 진행상황이 없는 경우 퀘스트 설명을 표시합니다.",
	["Show/Hide objectives"] = "퀘스트 목표 보기/숨기기",
	
	--Item related:
	["<not yet cached>"] = "<아이템 캐쉬에 없음>",
	--Unsafe item tooltip, copied from AtlasLoot
	["Unsafe Item"] = "불안전 아이템",
	["ItemID:"] = "아이템ID:",
	["unsafeItemWarning"] = "불안전 아이템.  서버 연결종료의 위험 없이 아이템을 보려면 먼저 게임에서 해당 아이템을 보셔야 합니다. 이는 1.10 패치후 블리자드가 채택한 사항입니다.",
	["queryItemWarning"] = "좌 클릭으로 서버에 아이템 정보를 요청할 수 있습니다.  서버연결이 종료될 수도 있습니다.",
	
	--nQuestLogFuBar:
	["FuBarPlugin options"] = "푸바 설정",
	["FuBarPlugin options desc"] = "Standard plugin options, plus text and tooltip options.", --Need translation
	["Text options"] = "글자 설정",
	["Tooltip options"] = "툴팁 설정",
	["Show minion status"] = "알림창 상태 보기",
	["showFuMinionStatus"] = "알림창의 보기 설정 및 프레임 고정을 표시합니다.",
	["Show hint"] = "힌트 보기",
	["showFuHint"] = "툴팁 힌트를 표시합니다.",
	["Standard options"] = "기본 설정",
	["waterfallError"] = "설정창을 불러오려면 Waterfall-1.0이 설치되어 있어야합니다.",
	["Quest status"] = "퀘스트 상태",
	["Completed"] = "완료됨",
	["Active"] = "진행중",
	["%s for options."] = "푸바 설정 : %s",
	["%s to configure."] = "설정창 열기 : %s",
	["%s to expand/collapse."] = "확장/축소 : %s",
	["%s to lock/unlock."] = "프레임 잠금/풀림 : %s",
	["%s to show/hide."] = "알림창 보기/숨기기 : %s",
} end)
