﻿--Caution:  This file must remain encoded in UTF-8 format when saving!

local L = AceLibrary("AceLocale-2.2"):new("nQuestLog")

L:RegisterTranslations("frFR", function() return {
	--Generic:
	["Auto fade"] = "Auto fade", --Need translation
	["Auto show"] = "Montrer automatiquement",
	["Configure"] = "Configurer",
	["decrease"] = "decrease", --Need translation
	["Default : "] = "Standard : ",
	[" (done)"] = " (terminée)",
	["Enabled"] = "Enabled", --Need translation
	["Fade-in"] = "Fade-in", --Need translation
	["Fade-out"] = "Fade-out", --Need translation
	[" (failed)"] = " (échoué)",
	["Font outline"] = "Font esquisse",
	["Font size"] = "Taille de police",
	[" (goto)"] = " (voyage)",
	["Grow upwards"] = "Vers le haut",
	["Hidden"] = "Caché",
	[" hidden)"] = " caché)",
	["Hide completed"] = "Cacher accompli",
	["increase"] = "increase", --Need translation
	["Locked"] = "Fermé",
	["Main settings"] = "Réglages globaux",
	["Module settings"] = "Module réglages",
	["Open configuration frame"] = "Ouvrez le cadre de configuration",
	["Padding"] = "Ecart",
	["Set width of frame"] = "Définit la largueur",
	["settings"] = "Arrangements",
	["Shown"] = "Montré",
	["Smart"] = "Futé",
	["Toggle showing"] = "Bascule l'affichage",
	["Unlocked"] = "Déverrouillé",
	[" visible)"] = " visible)",
	["Visible"] = "Visible",
	["Width"] = "Largeur",
	
	--Object points:
	["BOTTOMLEFT"] = "BOTTOMLEFT", --Need translation
	["BOTTOMRIGHT"] = "BOTTOMRIGHT", --Need translation
	["TOPLEFT"] = "TOPLEFT", --Need translation
	["TOPRIGHT"] = "TOPRIGHT", --Need translation
	
	--Mouse clicks:
	["Alt-Click"] = "Alt clic",
	["Click"] = "Cliquez",
	["Ctrl-Click"] = "Ctrl clic",
	["Right-Click"] = "Clic droit",
	["Shift-Click"] = "Maj clic",
	
	--Minion related:
	["Add outline to minion font"] = "Add outline to minion font", -- Need translation
	["Change font size for minion header"] = "Change font size for minion header", --Need translation
	["Expand/Collapse minion"] = "Expand/Collapse minion", --Need translation
	["Grow minion up"] = "Agrandit l'assitant vers le haut.",
	["Header"] = "Header", --Need translation
	["Lock minion"] = "Verrouille l'assistant",
	["Lock/Unlock minion"] = "Verrouille/Déverrouille l'assistant",
	["Minion"] = "Assistant",
	["Minion locked"] = "Minion locked", --Need translation
	["Minion must be locked for proper functionality!"] = "Minion must be locked for proper functionality!", --Need translation
	["Minion status"] = "Minion status", --Need translation
	["Minion visible"] = "Assistant visible",
	["Note that minion will not show if you are not tracking any quests."] = 
		"Note: l'assistant ne sera pas affiché si vous ne suivez aucune quête.",
	["Reset minion position"] = "R-à-z position de l'assistant",
	["Resets the position of the minion to the center of the screen"] = "Resets the position of the minion to the center of the screen", --Need translation
	["Show/Hide minion"] = "Affiche/cache l'assistant",
	["Title text"] = "Title text", --Need translation
	expandCollapseDesc = "Expand current zone if collapsed, otherwise expand all zones.  Collapse all zones if already expanded.", --Need translation
	minionHeader = "Show header at the top of the minion.", --Need translation
	minionHeaderTitle = "Text to display as a title in the minion header.  Set to nothing to hide the title.", --Need translation
	minionAnchor = "Frame anchor", --Need translation
	minionAnchorDesc = "Used as a reference point when resizing the minion.", --Need translation
	minionAutoWidth = "Auto-resize width", --Need translation
	minionAutoWidthDesc = "Automatically resize the minion's width according to the longest zone/quest/objective name currently displayed.", --Need translation
	minionFade = "%s alpha", --%s = "Fade-in" OR "Fade-out" --Need translation
	minionFadeDesc = "When the mouse %s the minion, %s the frame opacity until it reaches this value.", --%s = minionFadeIsOver OR minionFadeLeaves, %s = "increase" OR "decrease" --Need translation
	minionFadeTime = "%s time", --%s = "Fade-in" OR "Fade-out" --Need translation
	minionFadeTimeDesc = "Gradually %s the frame opacity to the %s value over XX seconds.", --%s = "increase" OR "decrease", %s = "Fade-in" OR "Fade-out" --Need translation
	minionFadeDelay = "%s delay", --%s = "Fade-in" OR "Fade-out" --Need translation
	minionFadeDelayDesc = "Delay frame fade-out for XX seconds after the mouse leaves the minion.", --Need translation
	minionFadeIsOver = "is over", --First %s in minionFadeDesc --Need translation
	minionFadeLeaves = "leaves", --First %s in minionFadeDesc --Need translation
	minionResetConfirm = "Are you sure you want to reset the minion position?", --Need translation
	
	--Zone related:
	["Change font size for zone"] = "Change font size for zone", --Need translation
	["Change padding between zones"] = "Change padding between zones", --Need translation
	["Hide zone"] = "Hide Zone", --Need translation
	["Show empty zones"] = "Show empty zones", --Need translation
	["Show hidden zones where you are not tracking any quests"] = "Show hidden zones where you are not tracking any quests", --Need translation
	["Show visible/total quests for a zone"] = "Show Visible/Total quests for a zone", --Need translation
	["Show zone"] = "Show Zone", --Need translation
	["Show zone level"] = "Show zone level", --Need translation
	["Shows <Zone> with X/X visible"] = "Shows <Zone> with X/X Visible", --Need translation
	["Toggle zone visibility"] = "Bascule la visibilité de zone",
	["Zone"] = "Zone",
	["Zone visibility:"] = "Visibilité de zone:",
	
	--Quest related:
	["Show completed quests"] = "Show completed quests", --Need translation
	showQuestsDone = "Show count of active quests for which all objectives are complete.", --Need translation
	["Show hidden quests"] = "Show hidden quests", --Need translation
	showQuestsHidden = "Show count of active quests that are hidden.", --Need translation
	["Show active quests"] = "Show active quests", --Need translation
	showQuestsActive = "Show count of currently active quests.", --Need translation
	["Show max quests"] = "Show max quests", --Need translation
	showQuestsMax = "Show maximum number of active quests.", --Need translation
	["Auto show hidden quests when you loot a quest item for it"] = "Auto show hidden quests when you loot a quest item for it", --Need translation
	["Auto show new quests in minion"] = "Auto show new quests in minion", --Need translation
	["Change font size for quests"] = "Change font size for quests", --Need translation
	["Change padding between quests"] = "Change padding between quests", --Need translation
	["no quests to track"] = "no quests to track", --Need translation
	["Listing all quests"] = "Énumérant toutes quêtes",
	["Listing all watched quests"] = "Énumérant toutes quêtes observé",
	["New quests"] = "New quests", --Need translation
	["Quest"] = "Quest", --Need translation
	["Show quest progress"] = "Show Quest Progress", --Need translation
	["%s items total"] = "%s items total", --Need translation
	["Watched quests"] = "Quêtes observé",
	["When looting quest item"] = "When looting quest item", --Need translation
	
	--Quest objectives related:
	["Default quest objective tracking"] = "Observation standard d'objectif de quête",
	hideObjs = "Hide objectives by default", --Need translation
	hideObjsDesc = "Hide all quest objectives by default.", --Need translation
	hideCompletedObjs = "Hide completed objectives", --Need translation
	hideCompletedObjsDesc = "Hide all completed quest objectives.  This overrides other visibility options.", --Need translation
	["Quest objectives"] = "Quest objectives", --Need translation
	["Reset manually watched objectives"] = "Remettre à zéro les objectifs manuellement observé",
	showDescNoObjs = "Show description if no objectives", --Need translation
	showDescNoObjsDesc = "Show brief quest description if no progress is available.", --Need translation
	["Show/Hide objectives"] = "Montrer/Cacher les objectifs",
	
	--Item related:
	["<not yet cached>"] = "<not yet cached>", --Need translation
	--Unsafe item tooltip, copied from AtlasLoot
	["Unsafe Item"] = "Unsafe Item", --Need translation
	["ItemID:"] = "ItemID:", --Need translation
	["unsafeItemWarning"] = "This item is unsafe.  To view this item without the risk of disconnection, "..
		"you need to have first seen it in the game world.  This is a restriction enforced by Blizzard since Patch 1.10.",  --Need translation
	["queryItemWarning"] = "You can left-click to attempt to query the server.  You may be disconnected.",  --Need translation
	
	--nQuestLogFuBar:
	["FuBarPlugin options"] = "FuBarPlugin options", --Need translation
	["FuBarPlugin options desc"] = "Standard plugin options, plus text and tooltip options.", --Need translation
	["Text options"] = "Text options", --Need translation
	["Tooltip options"] = "Tooltip options", --Need translation
	["Show minion status"] = "Show minion status", --Need translation
	["showFuMinionStatus"] = "Show whether minion is hidden or visible and locked or unlocked.", --Need translation
	["Show hint"] = "Show hint", --Need translation
	["showFuHint"] = "Show tooltip hint.", --Need translation
	["Standard options"] = "Standard options", --Need translation
	["waterfallError"] = "Waterfall-1.0 is required to access the configuration frame.", --Need translation
	["Quest status"] = "Quest status", --Need translation
	["Completed"] = "Completed", --Need translation
	["Active"] = "Active", --Need translation
	["%s for options."] = "%s for options.", -- %s is a mouse click --Need translation
	["%s to configure."] = "%s to configure.", -- %s is a mouse click --Need translation
	["%s to expand/collapse."] = "%s to expand/collapse.", -- %s is a mouse click --Need translation
	["%s to lock/unlock."] = "%s to lock/unlock.", -- %s is a mouse click --Need translation
	["%s to show/hide."] = "%s to show/hide.", -- %s is a mouse click --Need translation
} end)
