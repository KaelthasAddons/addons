﻿local L = AceLibrary("AceLocale-2.2"):new("SmartVisibility")

L:RegisterTranslations("zhCN", function() return {
	["SmartVisibility"] = "智能显示",
	["Description"] = "自动显示/隐藏任务等",
	
	["Zone"] = "区域",
	zoneAutoCollapse = "自动折起区域",
	zoneAutoCollapseDesc = "自动将除了当前区域外的所有区域标题折起。",
	zoneAutoExpand = "自动展开区域",
	zoneAutoExpandDesc = "自动将当前区域的标题展开。",
	
	["Quests"] = "任务",
	questHideDone = "隐藏已完成任务", --Need translation
	questHideDoneDesc = "自动隐藏全部目标都已达成的任务。要想显示一个隐藏的任务，右键点击任务区域名称或者使用菜单选项。",
	
	["Objectives"] = "任务目标",
	objShowZone = "显示当前区域的任务目标",
	objShowZoneDesc = "\"一直显示\" - 为当前区域显示所有的任务目标（包括那些手动设定不监视的）。"..
		"\n\n\"按照默认方式\" - 任何手动设定为监视或者不监视的任务都不会受到此选项影响"..
		" (通过菜单的重置手动目标监视选项可以取消此设定)。",
	["option disabled"] = "不做任何选择",
	["Always"] = "一直显示",
	["By default"] = "按照默认方式",
	objShowActive = "只显示活跃的任务目标",
	objShowActiveDesc = "只显示在制定的分钟内有更新的任务目标。设为\"0\"则禁用该功能。",
	objShowNew = "显示新接任务的目标",
	objShowNewDesc = "把新接的任务当作是正活跃的任务，并使用上面设定的时间来管理。",
} end)
