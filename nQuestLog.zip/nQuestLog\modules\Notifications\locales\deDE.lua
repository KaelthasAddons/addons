﻿--Caution:  This file must remain encoded in UTF-8 format when saving!
--harl windwolf (harldephin@freenode), November 26, 2007

local L = AceLibrary("AceLocale-2.2"):new("Notifications")

L:RegisterTranslations("deDE", function() return {
	Notifications = "Meldungen",
	Description = "Zeigt Quest-Fortschritts-Meldungen an.",
	
	["%s notifications"] = "%s notifications", --%s = "Text" OR "Sound" --Need translation
	["Text"] = "Text", --Need translation
	["Sound"] = "Sound", --Need translation
	
	testOutput = "Test-Ausgabe",
	testOutputDesc = "Generiert eine Pseudo-Meldung zu Testzwecken.",
	fakeQuest = "Hurra, Ihr habt eine Quest-Attrappe abgeschlossen!",
	
	questDone = "Quest abgeschlossen", --also used in notifications
	questDoneDesc = "Benachrichtige, wenn Quests abgeschlossen werden.",
	
	objDone = "Questziel abgeschlossen", --also used in notifications
	objDoneDesc = "Benachrichtige, wenn Questziele erreicht sind.",
	objDoneSoundDesc = "Notify when an objective is completed but at least one incomplete objective remains.", --Need translation
	objProgress = "Questfortschritte",
	objProgressDesc = "Benachrichtige, wenn ein Fortschritt bei einzelnen Questzielen stattfindet..",
	objProgressHidden = "nur wenn Quest versteckt ist.",
	objProgressHiddenDesc = "Benachrichtige bei einem Fortschritt nur, wenn das betroffene Quest versteckt ist.",
	objQuestName = "Zeige Questnamen an",
	objQuestNameDesc = "Zeige den Namen der betroffenen Quest mit an, wenn ein Questfortschritt stattfindet.",
	hideBlizz = "Verstecke Blizzard-eigene Meldungen",
	hideBlizzDesc = "Unterdrückt die Ausgabe der Questfortschritts-Meldungen durch das vorgegebene UI.",
	
	multiToggle = "Hint:  Select more than one option for automatic randomization of the options selected.", --Need translation
	["%s \"Job's done!\""] = "%s \"Job's done!\"", --Need translation
	["%s \"More work?\""] = "%s \"More work?\"", --Need translation
	["%s \"Ready to work!\""] = "%s \"Ready to work!\"", --Need translation
	["%s \"Something need doing?\""] = "%s \"Something need doing?\"", --Need translation
	["%s \"Work complete!\""] = "%s \"Work complete!\"", --Need translation
	["Flag captured"] = "Flag captured", --Need translation
	["Peasant"] = "Peasant", --Need translation
	["Peon"] = "Peon", --Need translation
	["Ready check"] = "Ready check", --Need translation
	
	blizzProgressPattern = "^.+: ?%d+/%d+$", -- pattern to suppress Blizzard objective progress messages
} end)
