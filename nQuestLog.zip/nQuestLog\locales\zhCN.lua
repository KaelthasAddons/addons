﻿local L = AceLibrary("AceLocale-2.2"):new("nQuestLog")

L:RegisterTranslations("zhCN", function() return {
	--Generic:
	["Auto fade"] = "自动消失",
	["Auto show"] = "自动显示",
	["Configure"] = "设置",
	["decrease"] = "减少",
	["Default : "] = "默认:",
	[" (done)"] = " (完成)",
	["Enabled"] = "启用",
	["Fade-in"] = "淡入",
	["Fade-out"] = "淡出",
	[" (failed)"] = " (失败)",
	["Font outline"] = "字体描边",
	["Font size"] = "文字大小",
	[" (goto)"] = " (导向)",
	["Grow upwards"] = "向上扩展",
	["Hidden"] = "隐藏",
	[" hidden)"] = "隐藏)",
	["Hide completed"] = "隐藏已完成的",
	["increase"] = "增加",
	["Locked"] = "已锁定",
	["Main settings"] = "主要设置",
	["Module settings"] = "模块设置",
	["Open configuration frame"] = "打开配置面板",
	["Padding"] = "间距",
	["Set width of frame"] = "设置窗体宽度",
	["settings"] = "选项",
	["Shown"] = "显示",
	["Smart"] = "智能",
	["Toggle showing"] = "切换显示",
	["Unlocked"] = "解锁",
	[" visible)"] = "可见)",
	["Visible"] = "可见",
	["Width"] = "宽度",
	
	--Object points:
	["BOTTOMLEFT"] = "左下",
	["BOTTOMRIGHT"] = "右下",
	["TOPLEFT"] = "左上",
	["TOPRIGHT"] = "右上",
	
	--Mouse clicks:
	["Alt-Click"] = "Alt+左键",
	["Click"] = "左键",
	["Ctrl-Click"] = "Ctrl+左键",
	["Right-Click"] = "点击右键",
	["Shift-Click"] = "Shift+左键",
	
	--Minion related:
	["Add outline to minion font"] = "为面板中的文字描边",
	["Change font size for minion header"] = "更改跟踪面板标题字体大小",
	["Expand/Collapse minion"] = "展开/收起跟踪面板",
	["Grow minion up"] = "向上扩展追踪面板",
	["Header"] = "标题",
	["Lock minion"] = "锁定追踪面板",
	["Lock/Unlock minion"] = "锁定/解锁追踪面板",
	["Minion"] = "追踪面板",
	["Minion locked"] = "面板已锁",
	["Minion must be locked for proper functionality!"] = "追踪面板必须被锁至合适的位置！",
	["Minion status"] = "面板状态",
	["Minion visible"] = "显示追踪面板",
	["Note that minion will not show if you are not tracking any quests."] = "注意:当没有追踪任务时，面板会隐藏。",
	["Reset minion position"] = "重置追踪面板位置",
	["Resets the position of the minion to the center of the screen"] = "重置追踪面板至屏幕正中",
	["Show/Hide minion"] = "显示/隐藏追踪面板",
	["Title text"] = "标题文字",
	expandCollapseDesc = "如果当前区域是收起状态则展开，否则展开全部区域。如果全部区域都已展开则会收起。",
	minionHeader = "在追踪窗口上方显示标题",
	minionHeaderTitle = "要在标题上显示的文字，什么都不写的话就会隐藏标题。",
	minionAnchor = "框架锚点",
	minionAnchorDesc = "当更改跟踪面板的大小时作为一个参考点。",
	minionAutoWidth = "自动更改宽度",
	minionAutoWidthDesc = "自动更改跟踪面板的宽度以符合当前显示的最长的区域/任务/目标名称。",
	minionFade = "%s透明度",
	minionFadeDesc = "当鼠标%s跟踪面板时，逐渐%s框架的透明度，直到达到这个值。", --%s = minionFadeIsOver OR minionFadeLeaves, %s = "increase" OR "decrease"
	minionFadeTime = "%s过渡时间", --%s = "Fade-in" OR "Fade-out"
	minionFadeTimeDesc = "在指定的时间内逐渐的%s框架透明度达到%s的透明度。", --%s = "increase" OR "decrease", %s = "Fade-in" OR "Fade-out"
	minionFadeDelay = "%s延迟", --%s = "Fade-in" OR "Fade-out"
	minionFadeDelayDesc = "在鼠标离开追踪面板后XX秒才淡出面板。",
	minionFadeIsOver = "移动到", --First %s in minionFadeDesc
	minionFadeLeaves = "离开", --First %s in minionFadeDesc
	minionResetConfirm = "你确定要重置追踪面板的位置么？",
	
	--Zone related:
	["Change font size for zone"] = "更改当前区域的文字大小",
	["Change padding between zones"] = "更改两个区域间的间隔距离",
	["Hide zone"] = "隐藏区域",
	["Show empty zones"] = "显示空白区域",
	["Show hidden zones where you are not tracking any quests"] = "显示/隐藏没有追踪任务的区域",
	["Show visible/total quests for a zone"] = "显示任务情况",
	["Show zone"] = "显示区域",
	["Show zone level"] = "显示区域等级",
	["Shows <Zone> with X/X visible"] = "显示某区域有多少任务被追踪以及该区域的任务总数",
	["Toggle zone visibility"] = "更改区域显示特性",
	["Zone"] = "区域",
	["Zone visibility:"] = "区域可见性：",
	
	--Quest related:
	["Show completed quests"] = "显示已完成的任务",
	showQuestsDone = "显示已完成的任务的总数",
	["Show hidden quests"] = "显示隐藏的任务",
	showQuestsHidden = "显示隐藏的任务的总数",
	["Show active quests"] = "显示进行中的任务",
	showQuestsActive = "显示但前正在完成的任务的总数",
	["Show max quests"] = "显示最大任务数",
	showQuestsMax = "显示进行中的任务的最大值",
	["Auto show hidden quests when you loot a quest item for it"] = "当拾取某任务物品时，自动显示/隐藏与该物品相关的任务",
	["Auto show new quests in minion"] = "自动显示新任务",
	["Change font size for quests"] = "改变任务字体",
	["Change padding between quests"] = "更改每个任务之间的间隔距离",
	["no quests to track"] = "没有追踪任务时",
	["Listing all quests"] = "列出所有任务",
	["Listing all watched quests"] = "列出所有已追踪任务",
	["New quests"] = "新任务",
	["Quest"] = "任务",
	["Show quest progress"] = "显示任务进度",
	["%s items total"] = "%s 总计",
	["Watched quests"] = "已追踪的任务",
	["When looting quest item"] = "当拾取任务物品时",
	
	--Quest objectives related:
	["Default quest objective tracking"] = "默认追踪任务目标",
	hideObjs = "默认隐藏目标",
	hideObjsDesc = "默认隐藏所有任务目标。",
	hideCompletedObjs = "隐藏已达成的目标",
	hideCompletedObjsDesc = "隐藏所有已经达成的目标，本选项覆盖其他可见性选项。",
	["Quest objectives"] = "任务目标",
	["Reset manually watched objectives"] = "重置任务目标显示设置",
	showDescNoObjs = "当没有任务目标时,显示任务描述",
	showDescNoObjsDesc = "在没有任务进度可用时，显示一个简略的任务描述。",
	["Show/Hide objectives"] = "显示/隐藏任务目标",
	
	--Item related:
	["<not yet cached>"] = "<尚未缓存>",
	--Unsafe item tooltip, copied from AtlasLoot
	["Unsafe Item"] = "不安全物品",
	["ItemID:"] = "物品ID：",
	["unsafeItemWarning"] = "该物品不安全，查看该物品将有从服务器断开连接的可能。"..
		"你必须在游戏中见过该物品一次，这是暴雪在1.10补丁中加入的一个限定", 
	["queryItemWarning"] = "你可以用左击该物品向服务器查询它，但是该行为可能导致失去连接。", 
	
	--nQuestLogFuBar:
	["FuBarPlugin options"] = "FuBar选项",
	["FuBarPlugin options desc"] = "标准的选项，外加文本和提示信息选项。",
	["Text options"] = "文本选项",
	["Tooltip options"] = "工具条选项",
	["Show minion status"] = "显示面板状态",
	["showFuMinionStatus"] = "显示所有的面板.",
	["Show hint"] = "显示注意事项",
	["showFuHint"] = "显示工具条注意事项.",
	["Standard options"] = "标准选项",
	["waterfallError"] = "需要库Waterfall-1.0才能使用配置窗口.",
	["Quest status"] = "任务状态",
	["Completed"] = "已完成",
	["Active"] = "进行中",
	["%s for options."] = "选项：%s", -- %s is a mouse click
	["%s to configure."] = "配置：%s", -- %s is a mouse click
	["%s to expand/collapse."] = "展开/收起：%s", -- %s is a mouse click
	["%s to lock/unlock."] = "锁定/解锁：%s", -- %s is a mouse click
	["%s to show/hide."] = "显示/隐藏：%s", -- %s is a mouse click
} end)
