﻿local L = AceLibrary("AceLocale-2.2"):new("Coloring")

L:RegisterTranslations("zhTW", function() return {
	["Coloring"] = "顏色選項",
	["Description"] = "對各個部分進行詳細的文字顏色設置",
	
	["level"] = "等級",
	["progress"] = "進度",
	colorBy = "按%s著色",
	colorByDesc = "自定義當按%s著色時所使用的顏色。",
	customColor = "使用自定義%s顏色",
	customColorDesc = "按照以下自定義的顏色給%s著色。",
	
	["Impossible"] = "超級困難",
	["red"] = "紅色",
	["Very difficult"] = "非常困難",
	["orange"] = "橙色",
	["Difficult"] = "困難",
	["yellow"] = "黃色",
	["Standard"] = "標準",
	["green"] = "綠色",
	["Trivial"] = "無挑戰",
	["gray"] = "灰色",
	colorFor = "\"%s\"級別的顏色。",
	colorDefault = "默認為%s。",
	
	["Start"] = "剛開始",
	["Halfway"] = "完成一半",
	["End"] = "全部完成",
	showProgress = "定義%s時的顏色",
	showProgressDesc = "為%s時的任務進度定義顏色，以控制整個從0%%到100%%的顏色漸變過程。",
	progressDesc = "進度為%s時所使用的顏色。",
	
	["Change color settings for"] = "更改",
	
	["trackerBorderColor"] = "追蹤面板邊框顏色",
	["trackerBackgroundColor"] = "追蹤面板背景顏色",
	
	["zoneHeader"] = "地區名稱",
	["zoneLevel"] = "地區等級",
	
	["questHeader"] = "任務名稱",
	["questHighlight"] = "任務高亮",
	["questProgress"] = "任務進度",
	["questFailed"] = "失敗任務",
	["questGoto"] = "轉到任務",
	["questDone"] = "已完成任務",
	
	["objectiveHeader"] = "任務目標",
	["objectiveProgress"] = "目標進展",
	["objectiveText"] = "目標文本",
	
	["notificationColor"] = "通知顏色",
} end)
