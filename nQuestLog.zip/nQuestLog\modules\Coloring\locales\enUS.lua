﻿local L = AceLibrary("AceLocale-2.2"):new("Coloring")

L:RegisterTranslations("enUS", function() return {
	["Coloring"] = true,
	["Description"] = "Deals with coloring everything properly",
	
	["level"] = true,
	["progress"] = true,
	colorBy = "Color by %s",
	colorByDesc = "Define custom colors to use when coloring by %s.",
	customColor = "Use custom %s colors",
	customColorDesc = "Uses the custom colors defined below when coloring by %s.",
	
	["Impossible"] = true,
	["red"] = true,
	["Very difficult"] = true,
	["orange"] = true,
	["Difficult"] = true,
	["yellow"] = true,
	["Standard"] = true,
	["green"] = true,
	["Trivial"] = true,
	["gray"] = true,
	colorFor = "Color for \"%s\".",
	colorDefault = "Default is %s.",
	
	["Start"] = true,
	["Halfway"] = true,
	["End"] = true,
	showProgress = "Define color for %s",
	showProgressDesc = "Define color for %s progress for further control over the color progression from 0%% to 100%%.",
	progressDesc = "Color to use for %s progress.",
	
	["Change color settings for"] = true,
	
	["trackerBorderColor"] = "Minion border color",
	["trackerBackgroundColor"] = "Minion background color",
	
	["zoneHeader"] = "Zone header",
	["zoneLevel"] = "Zone level",
	
	["questHeader"] = "Quest header",
	["questHighlight"] = "Quest highlight",
	["questProgress"] = "Quest progress",
	["questFailed"] = "Quest Failed text",
	["questGoto"] = "Quest Goto text",
	["questDone"] = "Quest Done text",
	
	["objectiveHeader"] = "Objective header",
	["objectiveProgress"] = "Objective progress",
	["objectiveText"] = "Objective text",
	
	["notificationColor"] = "Notification color",
} end)
