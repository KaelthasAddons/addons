﻿local L = AceLibrary("AceLocale-2.2"):new("Comments")

L:RegisterTranslations("zhCN", function() return {
	["Comments"] = "论坛讨论",
	["Description"] = "来自于Wowhead.com的任务论坛讨论（无中文版）。",
	["Minimum width"] = "最小宽度",
	["Set the minimum width of the Comments frame"] = "设置评论窗口的最小宽度",
	["Maximum height"] = "最大高度",
	["Set the maximum height of the Comments frame"] = "设置评论窗口的最大高度",
	
	["%s Comments"] = "%s的讨论", --%s is "Lightheaded"
	["%s ID"] = "%sID", --%s is "Quest"
	["%s Info"] = "%s的信息", --%s is "Lightheaded" or "MobMap"
	["%s-only"] = "仅限%s", --%s is "Horde" or "Alliance"
	["%s Rewards"] = "%s的奖励信息", --%s is "Lightheaded" or "MobMap"
	["%s %s Series"] = "%s的系列%s", --%s is "Lightheaded", "Quest"
	["%s Type"] = "%s类型", --%s is "Quest"
	
	["<not yet cached>"] = "<尚未缓存>",
	["Always receive"] = "获得",
	["Choose from"] = "从以下物品中选择",
	["Coordinates"] = "坐标",
	["Ends"] = "结束", --as in "The quest *ends* at..."
	["Quest"] = "任务",
	["Rep"] = "声望", --abbreviation for "Reputation"
	["Req Lvl"] = "需要等级", --abbreviation for "Required Level"
	["Sharable"] = "可共享",
	["Source"] = "来源", --as in "The *source* of the quest"
	["Starts"] = "起始", --as in "The quest *starts* at..."
	["No comments found"] = "没有任何讨论",
	["%s data is from %s"] = "%s的数据来自于%s", --%s is "Lightheaded", "Wowhead"
} end)
