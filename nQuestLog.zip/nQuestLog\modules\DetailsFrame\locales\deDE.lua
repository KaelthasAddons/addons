﻿--Caution:  This file must remain encoded in UTF-8 format when saving!
--harl windwolf (harldephin@freenode), November 26, 2007

local L = AceLibrary("AceLocale-2.2"):new("DetailsFrame")

L:RegisterTranslations("deDE", function() return {
	["DetailsFrame"] = "Quest-Beschreibung",
	["Description"] = "Ein schöneres und informativeres Quest-Beschreibungs-Fenster.",
	["Minimum width"] = "Mindestbreite",
	["Set the minimum width of the Details frame"] = "Legt die Mindestbreite des Beschreibungs-Fensters fest.",
	["Maximum height"] = "Maximalhöhe",
	["Set the maximum height of the Details frame"] = "Legt die maximale Höhe des Beschreibungs-Fensters fest",
	
	["(done)"] = "(erledigt)",
	["(failed)"] = "(fehlgeschlagen)",
	["Given by"] = "Erhalten von",
	["Required money: "] = "Erforderliches Geld: ", --might be wrong
	["Text"] = "Text", --might be unfitting
	["%s in %s (%d,%d)"] = "%s in %s (%d,%d)", --Needs translation
	
	["Description"] = "Beschreibung",
	["Rewards"] = "Belohnungen",
	["Choose from:"] = "Wählt eines aus:",
	["Always receive:"] = "Ihr bekommt immer:",
	["Spell:"] = "Zauber:", --might be unfitting
	["Money: "] = "Geld: ",
	["Nothing."] = "Nichts.",
	["Options"] = "Auswahl", --might be wrong
	["- Share"] = "- Quest Teilen",
	["- Abandon"] = "- Quest Abbrechen",
	["[ Close ]"] = "[ Schließen ]",
	
	["<not yet cached>"] = "<bisher nicht gespeichert>", --might be wrong
	--the following directions might all be wrong
	["bunch-of-directions"] = {
		"([^%a%d])(Norden)([^%a%d])", --Needs translation (north)
		"([^%a%d])(nördlich)([^%a%d])", --Needs translation (northern)
		"([^%a%d])(Westen)([^%a%d])", --Needs translation (west)
		"([^%a%d])(westlich)([^%a%d])", --Needs translation (western)
		"([^%a%d])(Osten)([^%a%d])", --Needs translation (east)
		"([^%a%d])(östlich)([^%a%d])", --Needs translation (eastern)
		"([^%a%d])(Süden)([^%a%d])", --Needs translation (south)
		"([^%a%d])(südlich)([^%a%d])", --Needs translation (southern)
		"([^%a%d])(Nordwesten)([^%a%d])", --Needs translation (northwest)
		"([^%a%d])(nordwestlich)([^%a%d])", --Needs translation (northwestern)
		"([^%a%d])(Nordosten)([^%a%d])", --Needs translation (northeast)
		"([^%a%d])(nordöstlich)([^%a%d])", --Needs translation (northeastern)
		"([^%a%d])(Südwesten)([^%a%d])", --Needs translation (southwest)
		"([^%a%d])(südwestlich)([^%a%d])", --Needs translation (southwestern)
		"([^%a%d])(Südosten)([^%a%d])", --Needs translation (southeast)
		"([^%a%d])(südöstlich)([^%a%d])", --Needs translation (southeastern)
	}
} end)
