﻿local L = AceLibrary("AceLocale-2.2"):new("SmartVisibility")

L:RegisterTranslations("zhTW", function() return {
	["SmartVisibility"] = "智慧顯示",
	["Description"] = "自動顯示/隱藏任務等",
	
	["Zone"] = "區域",
	zoneAutoCollapse = "自動折起區域",
	zoneAutoCollapseDesc = "自動將除了當前區域外的所有區域標題折起。",
	zoneAutoExpand = "自動展開區域",
	zoneAutoExpandDesc = "自動將當前區域的標題展開。",
	
	["Quests"] = "任務",
	questHideDone = "隱藏已完成任務", --Need translation
	questHideDoneDesc = "自動隱藏全部目標都已達成的任務。要想顯示一個隱藏的任務，右鍵點擊任務區域名稱或者使用功能表選項。",
	
	["Objectives"] = "任務目標",
	objShowZone = "顯示當前區域的任務目標",
	objShowZoneDesc = "\"一直顯示\" - 為當前區域顯示所有的任務目標（包括那些手動設定不監視的）。"..
		"\n\n\"按照默認方式\" - 任何手動設定為監視或者不監視的任務都不會受到此選項影響"..
		" (通過功能表的重置手動目標監視選項可以取消此設定)。",
	["option disabled"] = "不做任何選擇",
	["Always"] = "一直顯示",
	["By default"] = "按照默認方式",
	objShowActive = "只顯示活躍的任務目標",
	objShowActiveDesc = "只顯示在制定的分鐘內有更新的任務目標。設為\"0\"則禁用該功能。",
	objShowNew = "顯示新接任務的目標",
	objShowNewDesc = "把新接的任務當作是正活躍的任務，並使用上面設定的時間來管理。",
} end)
