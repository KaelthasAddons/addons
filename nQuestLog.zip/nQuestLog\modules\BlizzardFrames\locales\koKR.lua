﻿local L = AceLibrary("AceLocale-2.2"):new("BlizzardFrames")

L:RegisterTranslations("koKR", function() return {
	["BlizzardFrames"] = "블리자드 프레임",
	["Description"] = "퀘스트의 레벨을 표시해주는 모듈입니다.",
	hideTracker = "알림창 숨김",
	hideTrackerDesc = "블리자드 기본 알림창을 숨깁니다.",
	["Quest log"] = "퀘스트 로그",
	["Add quest levels"] = "퀘스트 레벨을 추가",
	["addLogQuestLevels"] = "퀘스트 로그에 레벨을 표시합니다.",
	["Add quest givers"] = "퀘스트 제공자 추가",
	["addLogQuestGivers"] = "퀘스트 상세 정보에 퀘스트 제공자를 표시합니다.",
	logMove = "이동 가능",
	logMoveDesc = "퀘스트 로그 프레임을 이동할 수 있습니다.",
	logScale = "크기",
	logScaleDesc = "퀘스트 로그 프레임의 크기를 변경합니다. (현재 UI 크기에 비례합니다.)",
	["Dialog"] = "대화",
	["addDialogQuestLevels"] = "퀘스트 NPC를 만날 경우 로그에 퀘스트 레벨을 표시합니다.",
	["Grey incomplete quest icons"] = "미완료 퀘스트 표시",
	["greyIncompleteQuestIcons"] = "퀘스트 NPC를 만날때 미완료 퀘스트가 있을 경우 회색 아이콘을 표시합니다.",
	["Given by"] = "제공자",
	["Location"] = "위치",
	["yd"] = "미터",
} end)
