﻿local L = AceLibrary("AceLocale-2.2"):new("Highlight")

L:RegisterTranslations("koKR", function() return {
	["Highlight"] = "퀘스트 강조",
	["Description"] = "현재 지역에서 수행할 수 있는 퀘스트의 배경을 강조해주는 모듈입니다.",
} end)
