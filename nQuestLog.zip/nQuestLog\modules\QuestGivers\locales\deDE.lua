﻿--Caution:  This file must remain encoded in UTF-8 format when saving!
--harl windwolf (harldephin@freenode), November 26, 2007

local L = AceLibrary("AceLocale-2.2"):new("QuestGivers")

L:RegisterTranslations("deDE", function() return {
	["QuestGivers"] = "Questgeber",
	["Description"] = "Hält die Positionen der Questgeber fest.",
	["%s in %s (%d,%d)"] = "%s in %s (%d,%d)",
	["%s in %s (%d,%d) (%d yd)"] = "%s in %s (%d,%d) (%d m)",
} end)
