﻿local L = AceLibrary("AceLocale-2.2"):new("BlizzardFrames")

L:RegisterTranslations("enUS", function() return {
	["BlizzardFrames"] = true,
	["Description"] = "This module hooks blizzard frames and displays quest levels",
	hideTracker = "Hide tracker",
	hideTrackerDesc = "Hide the default Blizzard quest tracking frame",
	["Quest log"] = true,
	["Add quest levels"] = true,
	["addLogQuestLevels"] = "Display quest levels in the Blizzard quest log.",
	["Add quest givers"] = true,
	["addLogQuestGivers"] = "Display quest givers in the Blizzard quest log details pane.",
	logMove = "Make moveable",
	logMoveDesc = "Allow dragging and repositioning of the Blizzard quest log frame.",
	logScale = "Scale",
	logScaleDesc = "Set the scale of the Blizzard quest log (relative to current UI scale).",
	["Dialog"] = true,
	["addDialogQuestLevels"] = "Display quest levels in NPC gossip and quest greeting frames.",
	["Grey incomplete quest icons"] = true,
	["greyIncompleteQuestIcons"] = "Grey icons next to active incomplete quests in the NPC gossip and quest greeting frames.",
	["Given by"] = true,
	["Location"] = true,
	["yd"] = true, --abbreviation for yard, a measure of distance
} end)
