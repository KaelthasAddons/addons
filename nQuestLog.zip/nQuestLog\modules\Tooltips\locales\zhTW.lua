﻿local L = AceLibrary("AceLocale-2.2"):new("Tooltips")

L:RegisterTranslations("zhTW", function() return {
	["Tooltips"] = "資訊提示",
	["Description"] = "設置資訊提示的詳細選項",
	["Enabled"] = "開啟",
	
	--Tooltip anchor
	tooltipAnchor = "資訊提示錨定位置",
	tooltipAnchorDesc = "設置資訊提示相對於追蹤面板錨定點的位置",
	["DEFAULT"] = "默認",
	["TOPRIGHT"] = "右上",
	["RIGHT"] = "右",
	["BOTTOMRIGHT"] = "右下",
	["TOPLEFT"] = "左上",
	["LEFT"] = "左",
	["BOTTOMLEFT"] = "左下",
	
	--Item tooltip
	itemToolTip = "物品提示",
	itemToolTipDesc = "在物品提示中顯示任務資訊",
	
	--Mob tooltip
	mobToolTip = "怪物提示",
	mobToolTipDesc = "在怪物提示中顯示任務資訊",
	mobToolTipTrigger = "添加信息於……",
	mobToolTipTriggerDesc = "選擇何時向資訊提示中添加內容。",
	mobToolTipTriggerBoth = "滑鼠停在怪物身上和頭像上時",
	mobToolTipTriggerMob = "只有滑鼠停在怪物身上時",
	disableInRaidInstance = "在團隊中關閉",
	disableInRaidInstanceDesc = "在團隊中時將禁用怪物提示，以節約資源。",
	useMobMap = "使用MobMap",
	useMobMapDesc = "將使用MobMap的掉落資料",
	MobMapDropRateFilter = "設置最小物品掉落等級",
	MobMapDropRateFilterDesc = "過濾資料，未到達設定等級的物品將不顯示。",
	addMobMapDropRates = "顯示掉落物品等級",
	addMobMapDropRatesDesc = "在怪物提示中顯示MobMap的掉落物品等級",
	addKillsNeeded = "顯示擊殺數量提示",
	addKillsNeededDesc = "根據MobMap的資料,在怪物資訊提示中顯示需要擊殺的大概數量",
	killsNeeded = "擊殺數量",
	
	trimToolTip = "截斷提示資訊",
	trimToolTipDesc = "將提示資訊中的文字截斷為指定的字元數。設置為0則禁用。",
	
	--Minion unlocked
	["MinionUnlocked"] = "追蹤面板未鎖定",
	["PlaceMinion"] = "配置追蹤面板並鎖定.\n右鍵點擊Fubar或者小地圖上的圖示可鎖定面板.",
	
	--Zone tooltips
	["ZoneHidden"] = "區域隱藏",
	["TrackedQuests"] = "已顯示任務",
	["HiddenQuests"] = "已隱藏任務",
	["ZoneTips"] = "提示 :\n右鍵點擊:顯示/隱藏 任務\nAlt + 右鍵可展開所有地區",
	
	--Quest tooltips
	["Total"] = "總共",
	["QuestTips"] = "提示 : Alt+左鍵 顯示/隱藏 任務目標",
} end)
