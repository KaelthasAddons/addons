﻿--Caution:  This file must remain encoded in UTF-8 format when saving!

local L = AceLibrary("AceLocale-2.2"):new("Highlight")

L:RegisterTranslations("esES", function() return {
	["Highlight"] = "Resaltar",
	["Description"] = "Resaltar misiones",
} end)
