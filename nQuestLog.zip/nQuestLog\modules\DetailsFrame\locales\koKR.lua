﻿local L = AceLibrary("AceLocale-2.2"):new("DetailsFrame")

L:RegisterTranslations("koKR", function() return {
	["DetailsFrame"] = "상세 프레임",
	["Description"] = "퀘스트 알림창의 퀘스트를 선택하면 상세 내용을 표시해주는 모듈입니다.",
	["Minimum width"] = "최소 가로 길이",
	["Set the minimum width of the Details frame"] = "설명 창의 최소 가로 길이를 설정합니다.",
	["Maximum height"] = "최소 세로 길이",
	["Set the maximum height of the Details frame"] = "설명 창의 최소 세로 길이를 설정합니다.",
	
	["(done)"] = "(완료)",
	["(failed)"] = "(실패)",
	["Given by"] = "퀘스트 제공자",
	["Required money: "] = "요구 금액: ",
	["Text"] = "텍스트",
	["%s in %s (%d,%d)"] = "%s (%s) 좌표: %d, %d",
	
	["Description"] = "내용",
	["Rewards"] = "보상",
	["Choose from:"] = "아래의 보상 중 선택",
	["Always receive:"] = "받게 될 보상",
	["Spell:"] = "기술:",
	["Money: "] = "금액: ",
	["Nothing."] = "없음",
	["Options"] = "추가 설정",
	["- Share"] = "- 퀘스트 공유",
	["- Abandon"] = "- 퀘스트 포기",
	["[ Close ]"] = "[ 닫기 ]",
	
	["<not yet cached>"] = "<캐쉬에 없음>",
	
	["bunch-of-directions"] = {
		"(%s?)(북서쪽)([^%a%d])",
		"(%s?)(북동쪽)([^%a%d])",
		"(%s?)(남서쪽)([^%a%d])",
		"(%s?)(남동쪽)([^%a%d])",
		"(%s?)(북쪽)([^%a%d])",
		"(%s?)(서쪽)([^%a%d])",
		"(%s?)(동쪽)([^%a%d])",
		"(%s?)(남쪽)([^%a%d])",
	}
} end)
