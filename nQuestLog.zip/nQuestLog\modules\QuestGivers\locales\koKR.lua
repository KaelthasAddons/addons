﻿local L = AceLibrary("AceLocale-2.2"):new("QuestGivers")

L:RegisterTranslations("koKR", function() return {
	["QuestGivers"] = "퀘스트 제공자",
	["Description"] = "퀘스트 제공자의 위치를 기록/표시해주는 모듈입니다.",
	["%s in %s (%d,%d)"] = "%s (%s) 좌표: %d, %d",
	["%s in %s (%d,%d) (%d yd)"] = "%s (%s) 좌표: %d, %d (%d 미터)",
} end)
