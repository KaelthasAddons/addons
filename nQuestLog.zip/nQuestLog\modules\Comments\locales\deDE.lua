﻿--Caution:  This file must remain encoded in UTF-8 format when saving!
--harl windwolf (harldephin@freenode), November 26, 2007

local L = AceLibrary("AceLocale-2.2"):new("Comments")

L:RegisterTranslations("deDE", function() return {
	["Comments"] = "Kommentare",
	["Description"] = "Kommentare zu Questdetails von wowhead.com.",
	["Minimum width"] = "Mindestbreite",
	["Set the minimum width of the Comments frame"] = "Legt die mindestbreite des Kommentarfensters fest",
	["Maximum height"] = "Maximale Höhe",
	["Set the maximum height of the Comments frame"] = "Legt die maximale Höhe des Kommentarfensters fest",
	
	["%s Comments"] = "%s Kommentare", --%s is "Lightheaded"
	["%s ID"] = "%s ID", --%s is "Quest" --Need translation
	["%s Info"] = "%s-Info", --%s is "Lightheaded" or "MobMap"
	["%s-only"] = "Nur für %s", --%s is "Horde" or "Alliance"
	["%s Rewards"] = "%s Belohnungen", --%s is "Lightheaded" or "MobMap"
	["%s %s Series"] = "%s %s-Reihe", --%s is "Lightheaded", "Quest"
	["%s Type"] = "%s-Art", --%s is "Quest"
	
	["<not yet cached>"] = "<bisher nicht gespeichert>", --might be wrong
	["Always receive"] = "Ihr bekommt immer", --might be wrong
	["Choose from"] = "Wählt eines aus", --might be wrong
	["Coordinates"] = "Koordinaten",
	["Ends"] = "Endet", --as in "The quest *ends* at..." --might be wrong
	["Quest"] = "Quest",
	["Rep"] = "Ruf", --"Ruf"="Reputation"
	["Req Lvl"] = "Min Lvl", --abbreviation for "Required Level" --might be wrong
	["Sharable"] = "Teilbar",
	["Source"] = "Ursprung", --as in "The *source* of the quest" --might be wrong
	["Starts"] = "Beginnt", --as in "The quest *starts* at..."
	["No comments found"] = "Keine Kommentare gefunden",
	["%s data is from %s"] = "%s-Daten kommen von %s", --%s is "Lightheaded", "Wowhead" --might be wrong
} end)
