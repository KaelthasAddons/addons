﻿--Caution:  This file must remain encoded in UTF-8 format when saving!
--harl windwolf (harldephin@freenode), November 26, 2007

local L = AceLibrary("AceLocale-2.2"):new("Highlight")

L:RegisterTranslations("deDE", function() return {
	["Highlight"] = "Hervorhebung",
	["Description"] = "Hebt Quests hervor",
} end)
