﻿local L = AceLibrary("AceLocale-2.2"):new("Coloring")

L:RegisterTranslations("zhCN", function() return {
	["Coloring"] = "颜色选项",
	["Description"] = "对各个部分进行详细的文字颜色设置",
	
	["level"] = "等级",
	["progress"] = "进度",
	colorBy = "按%s着色",
	colorByDesc = "自定义当按%s着色时所使用的颜色。",
	customColor = "使用自定义%s颜色",
	customColorDesc = "按照以下自定义的颜色给%s着色。",
	
	["Impossible"] = "超级困难",
	["red"] = "红色",
	["Very difficult"] = "非常困难",
	["orange"] = "橙色",
	["Difficult"] = "困难",
	["yellow"] = "黄色",
	["Standard"] = "标准",
	["green"] = "绿色",
	["Trivial"] = "无挑战",
	["gray"] = "灰色",
	colorFor = "\"%s\"级别的颜色。",
	colorDefault = "默认为%s。",
	
	["Start"] = "刚开始",
	["Halfway"] = "完成一半",
	["End"] = "全部完成",
	showProgress = "定义%s时的颜色",
	showProgressDesc = "为%s时的任务进度定义颜色，以控制整个从0%%到100%%的颜色渐变过程。",
	progressDesc = "进度为%s时所使用的颜色。",
	
	["Change color settings for"] = "更改",
	
	["trackerBorderColor"] = "追踪面板边框颜色",
	["trackerBackgroundColor"] = "追踪面板背景颜色",
	
	["zoneHeader"] = "地区名称",
	["zoneLevel"] = "地区等级",
	
	["questHeader"] = "任务名称",
	["questHighlight"] = "任务高亮",
	["questProgress"] = "任务进度",
	["questFailed"] = "失败任务",
	["questGoto"] = "转到任务",
	["questDone"] = "已完成任务",
	
	["objectiveHeader"] = "任务目标",
	["objectiveProgress"] = "目标进展",
	["objectiveText"] = "目标文本",
	
	["notificationColor"] = "通知颜色",
} end)