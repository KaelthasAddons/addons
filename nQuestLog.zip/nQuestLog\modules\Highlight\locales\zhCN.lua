﻿local L = AceLibrary("AceLocale-2.2"):new("Highlight")

L:RegisterTranslations("zhCN", function() return {
	["Highlight"] = "高亮任务",
	["Description"] = "高亮任务",
} end)
