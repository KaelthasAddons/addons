﻿local L = AceLibrary("AceLocale-2.2"):new("nQuestLog")

L:RegisterTranslations("enUS", function() return {
	--Generic:
	["Auto fade"] = true,
	["Auto show"] = true,
	["Configure"] = true,
	["decrease"] = true,
	["Default : "] = true,
	[" (done)"] = true, -- as in quest completed
	["Enabled"] = true,
	["Fade-in"] = true,
	["Fade-out"] = true,
	[" (failed)"] = true, -- as in quest failed
	["Font outline"] = true,
	["Font size"] = true,
	[" (goto)"] = true,
	["Grow upwards"] = true,
	["Hidden"] = true,
	[" hidden)"] = true,
	["Hide completed"] = true,
	["increase"] = true,
	["Locked"] = true,
	["Main settings"] = true,
	["Module settings"] = true,
	["Open configuration frame"] = true,
	["Padding"] = true,
	["Set width of frame"] = true,
	["settings"] = true,
	["Shown"] = true,
	["Smart"] = true,
	["Toggle showing"] = true,
	["Unlocked"] = true,
	[" visible)"] = true,
	["Visible"] = true,
	["Width"] = true,
	
	--Object points:
	["BOTTOMLEFT"] = true,
	["BOTTOMRIGHT"] = true,
	["TOPLEFT"] = true,
	["TOPRIGHT"] = true,
	
	--Mouse clicks:
	["Alt-Click"] = true,
	["Click"] = true,
	["Ctrl-Click"] = true,
	["Right-Click"] = true,
	["Shift-Click"] = true,
	
	--Minion related:
	["Add outline to minion font"] = true,
	["Change font size for minion header"] = true,
	["Expand/Collapse minion"] = true,
	["Grow minion up"] = true,
	["Header"] = true,
	["Lock minion"] = true,
	["Lock/Unlock minion"] = true,
	["Minion"] = true,
	["Minion locked"] = true,
	["Minion must be locked for proper functionality!"] = true,
	["Minion status"] = true,
	["Minion visible"] = true,
	["Note that minion will not show if you are not tracking any quests."] = true,
	["Reset minion position"] = true,
	["Resets the position of the minion to the center of the screen"] = true,
	["Show/Hide minion"] = true,
	["Title text"] = true,
	expandCollapseDesc = "Expand current zone if collapsed, otherwise expand all zones.  Collapse all zones if already expanded.",
	minionHeader = "Show header at the top of the minion.",
	minionHeaderTitle = "Text to display as a title in the minion header.  Set to nothing to hide the title.",
	minionAnchor = "Frame anchor",
	minionAnchorDesc = "Used as a reference point when resizing the minion.",
	minionAutoWidth = "Auto-resize width",
	minionAutoWidthDesc = "Automatically resize the minion's width according to the longest zone/quest/objective name currently displayed.",
	minionFade = "%s alpha", --%s = "Fade-in" OR "Fade-out"
	minionFadeDesc = "When the mouse %s the minion, %s the frame opacity until it reaches this value.", --%s = minionFadeIsOver OR minionFadeLeaves, %s = "increase" OR "decrease"
	minionFadeTime = "%s time", --%s = "Fade-in" OR "Fade-out"
	minionFadeTimeDesc = "Gradually %s the frame opacity to the %s value over XX seconds.", --%s = "increase" OR "decrease", %s = "Fade-in" OR "Fade-out"
	minionFadeDelay = "%s delay", --%s = "Fade-in" OR "Fade-out"
	minionFadeDelayDesc = "Delay frame fade-out for XX seconds after the mouse leaves the minion.",
	minionFadeIsOver = "is over", --First %s in minionFadeDesc
	minionFadeLeaves = "leaves", --First %s in minionFadeDesc
	minionResetConfirm = "Are you sure you want to reset the minion position?",
	
	--Zone related:
	["Change font size for zone"] = true,
	["Change padding between zones"] = true,
	["Hide zone"] = true,
	["Show empty zones"] = true,
	["Show hidden zones where you are not tracking any quests"] = true,
	["Show visible/total quests for a zone"] = true,
	["Show zone"] = true,
	["Show zone level"] = true,
	["Shows <Zone> with X/X visible"] = true,
	["Toggle zone visibility"] = true,
	["Zone"] = true,
	["Zone visibility:"] = true,
	
	--Quest related:
	["Show completed quests"] = true,
	showQuestsDone = "Show count of active quests for which all objectives are complete.",
	["Show hidden quests"] = true,
	showQuestsHidden = "Show count of active quests that are hidden.",
	["Show active quests"] = true,
	showQuestsActive = "Show count of currently active quests.",
	["Show max quests"] = true,
	showQuestsMax = "Show maximum number of active quests.",
	["Auto show hidden quests when you loot a quest item for it"] = true,
	["Auto show new quests in minion"] = true,
	["Change font size for quests"] = true,
	["Change padding between quests"] = true,
	["no quests to track"] = true,
	["Listing all quests"] = true,
	["Listing all watched quests"] = true,
	["New quests"] = true,
	["Quest"] = true,
	["Show quest progress"] = true,
	["%s items total"] = true,
	["Watched quests"] = true,
	["When looting quest item"] = true,
	
	--Quest objectives related:
	["Default quest objective tracking"] = true,
	hideObjs = "Hide objectives by default",
	hideObjsDesc = "Hide all quest objectives by default.",
	hideCompletedObjs = "Hide completed objectives",
	hideCompletedObjsDesc = "Hide all completed quest objectives.  This overrides other visibility options.",
	["Quest objectives"] = true,
	["Reset manually watched objectives"] = true,
	showDescNoObjs = "Show description if no objectives",
	showDescNoObjsDesc = "Show brief quest description if no progress is available.",
	["Show/Hide objectives"] = true,
	
	--Item related:
	["<not yet cached>"] = true,
	--Unsafe item tooltip, copied from AtlasLoot
	["Unsafe Item"] = true,
	["ItemID:"] = true,
	["unsafeItemWarning"] = "This item is unsafe.  To view this item without the risk of disconnection, "..
		"you need to have first seen it in the game world.  This is a restriction enforced by Blizzard since Patch 1.10.",
	["queryItemWarning"] = "You can left-click to attempt to query the server.  You may be disconnected.",
	
	--nQuestLogFuBar:
	["FuBarPlugin options"] = true,
	["FuBarPlugin options desc"] = "Standard plugin options, plus text and tooltip options.",
	["Text options"] = true,
	["Tooltip options"] = true,
	["Show minion status"] = true,
	["showFuMinionStatus"] = "Show whether minion is hidden or visible and locked or unlocked.",
	["Show hint"] = true,
	["showFuHint"] = "Show tooltip hint.",
	["Standard options"] = true,
	["waterfallError"] = "Waterfall-1.0 is required to access the configuration frame.",
	["Quest status"] = true,
	["Completed"] = true,
	["Active"] = true,
	["%s for options."] = true, -- %s is a mouse click
	["%s to configure."] = true, -- %s is a mouse click
	["%s to expand/collapse."] = true, -- %s is a mouse click
	["%s to lock/unlock."] = true, -- %s is a mouse click
	["%s to show/hide."] = true, -- %s is a mouse click
} end)
