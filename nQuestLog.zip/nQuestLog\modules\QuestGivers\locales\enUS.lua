﻿local L = AceLibrary("AceLocale-2.2"):new("QuestGivers")

L:RegisterTranslations("enUS", function() return {
	["QuestGivers"] = true,
	["Description"] = "Tracks quest giver locations",
	["%s in %s (%d,%d)"] = true,
	["%s in %s (%d,%d) (%d yd)"] = true,
} end)
