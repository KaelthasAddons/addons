﻿local L = AceLibrary("AceLocale-2.2"):new("Notifications")

L:RegisterTranslations("esES", function() return {
	Notifications = "Notificaciones",
	Description = "Notificaciones del progreso de misi\195\179n",

	["%s notifications"] = "Notificaciones %s", --%s = "Text" OR "Sound"
	["Text"] = "Texto",
	["Sound"] = "Sonido",

	testOutput = "Salida de Prueba",
	testOutputDesc = "Generate a fake notification for testing purposes.",
	fakeQuest = "Bien, \194\161has completado una misi\195\179n false!",

	questDone = "Misi\195\179n completa", --also used in notifications
	questDoneDesc = "Notifica cuando una misi\195\179n est\195\161 completa.",

	objDone = "Objectivo completo", --also used in notifications
	objDoneDesc = "Notify when an objective is completed.",
	objDoneSoundDesc = "Notify when an objective is completed but at least one incomplete objective remains.",
	objProgress = "Progreso del Objectivo",
	objProgressDesc = "Notify when progess is made on an objective.",
	objProgressHidden = "Solo cuando la misi\195\179n est\195\161 oculta",
	objProgressHiddenDesc = "Notify on objective progress only when the quest is hidden.",
	objQuestName = "A\195\177adir nombre de misi\195\179n",
	objQuestNameDesc = "Display quest names in objective notifications.",
	hideBlizz = "Hide Blizzard objective notifications",
	hideBlizzDesc = "Hide the default Blizzard quest objective notifications displayed near the top of the screen.",

	multiToggle = "Hint:  Select more than one option for automatic randomization of the options selected.",
	["%s \"Job's done!\""] = "%s \"\194\161Trabajo hecho!\"",
	["%s \"More work?\""] = "%s \"\194\191M\195\161s trabajo?\"",
	["%s \"Ready to work!\""] = "%s \"\194\161Listo para trabajar!\"",
	["%s \"Something need doing?\""] = "%s \"\194\191Necesitas que haga algo?\"",
	["%s \"Work complete!\""] = "%s \"\194\161Trabajo completado!\"",
	["Flag captured"] = "Bandera capturada",
	["Peasant"] = "Campesino",
	["Peon"] = "Peon",
	["Ready check"] = "Listo comprobaci\195\179n",
	
	blizzProgressPattern = "^.+: ?%d+/%d+$", -- pattern to suppress Blizzard objective progress messages
} end)
