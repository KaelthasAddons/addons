﻿local L = AceLibrary("AceLocale-2.2"):new("Highlight")

L:RegisterTranslations("zhTW", function() return {
	["Highlight"] = "高亮任務",
	["Description"] = "高亮任務",
} end)
