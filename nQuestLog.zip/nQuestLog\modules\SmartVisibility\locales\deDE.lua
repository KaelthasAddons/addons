﻿--Caution:  This file must remain encoded in UTF-8 format when saving!
--harl windwolf (harldephin@freenode), November 26, 2007

local L = AceLibrary("AceLocale-2.2"):new("SmartVisibility")

L:RegisterTranslations("deDE", function() return {
	["SmartVisibility"] = "Sichtbarkeit",
	["Description"] = "Zeigt/versteckt manche Dinge automatisch.",
	
	["Zone"] = "Gebiet",
	zoneAutoCollapse = "Auto-collapse zones", --Need translation
	zoneAutoCollapseDesc = "Automatically collapse zone headers for all zones except the current one.", --Need translation
	zoneAutoExpand = "Auto-expand zones", --Need translation
	zoneAutoExpandDesc = "Automatically expand the zone header for the current zone.", --Need translation
	
	["Quests"] = "Quests", --Need translation
	questHideDone = "Hide completed quests", --Need translation
	questHideDoneDesc = "Automatically hide quests when all objectives have been completed.  To show a hidden quest, right-click the quest's zone or use the menu.", --Need translation
	
	["Objectives"] = "Questziele",
	objShowZone = "Show objectives for current zone", --Need translation
	objShowZoneDesc = "\"Always\" - Show all quest objectives (including those manually unwatched) for the current zone."..
		"\n\n\"By Default\" - Any quests that have been manually watched or unwatched are not affected by this option"..
		" (reset manually watched objectives via the menu to fix this).", --Need translation
	["option disabled"] = "option disabled", --Need translation
	["Always"] = "Always", --Need translation
	["By default"] = "By default", --Need translation
	objShowActive = "Show active quest objectives", --Need translation
	objShowActiveDesc = "Show quest objectives that have been updated within X minutes.  Set to \"0\" to disable.", --Need translation
	objShowNew = "Show objectives for new quests", --Need translation
	objShowNewDesc = "Consider new quest objectives to be active and use the timer for showing active quest objectives.", --Need translation
} end)
