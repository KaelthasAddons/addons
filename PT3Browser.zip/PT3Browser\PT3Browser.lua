--[[
	Copyright (C) 2007 Nymbia

	This program is free software; you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation; either version 2 of the License, or
	(at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License along
	with this program; if not, write to the Free Software Foundation, Inc.,
	51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
]]
local tablet = AceLibrary("Tablet-2.0")
local dewdrop = AceLibrary("Dewdrop-2.0")
local PT = LibStub("LibPeriodicTable-3.1")
local L = AceLibrary("AceLocale-2.2"):new("PT3Browser")
local aot
local expandedmultis = {}
PT3Browser = AceLibrary("AceAddon-2.0"):new("FuBarPlugin-2.0", "AceDB-2.0", "AceEvent-2.0")
PT3Browser.hasIcon = true
PT3Browser:RegisterDB("PT3BrowserDB")
local qualitycolors = {
	[-1] = "|cff71d5ff",
	[0] = "|cff9d9d9d",
	[1] = "|cffffffff",
	[2] = "|cff1eff00",
	[3] = "|cff0070dd",
	[4] = "|cffa335ee",
	[5] = "|cffff8000" }
function PT3Browser:OnInitialize()
	CreateFrame("GameTooltip","PT3BrowserTooltip",UIParent,"GameTooltipTemplate")
end
function PT3Browser:OnEnable()
	self:RegisterEvent("PT3BRefresh")
end
function PT3Browser:OnTextUpdate()
	if self:IsTextShown() then
		self:SetText(L["PT3"])
	end
	if self:IsIconShown() then
		self:SetIcon("Interface\\Icons\\INV_Potion_98")
	else
		self:HideIcon()
	end
end
function PT3Browser:OnTooltipUpdate()
	local count = 0
	for _,_ in pairs(PT.sets) do
		count = count + 1
	end
	local cat = tablet:AddCategory()
	cat:AddLine('text', L["PT has %s sets"]:format(count))
end
function PT3Browser:BuildTable()
	aot = {
		type = 'group',
		args = {}
	}
	local sets = PT.sets
	for setname, _ in pairs(sets) do
		local workinglvl = aot.args
		local oldlvl
		local oldparent
		local allowflag
		for parent in setname:gmatch("([^%.]+)") do
			if not workinglvl[parent] then
				workinglvl[parent] = {
					type = 'group',
					name = parent,
					desc = parent,
					args = {}
				}
				allowflag = true
			else
				allowflag = false
			end
			for k,v in pairs(workinglvl) do
				local kname = k:match("0077ff([^%*]+)")
				if kname == parent then
					workinglvl[k] = nil
				end
			end
			oldlvl = workinglvl
			oldparent = parent
			workinglvl = workinglvl[parent].args
		end
		if allowflag and not expandedmultis[setname] then
			oldlvl[oldparent].name = "|cff0077ff"..oldlvl[oldparent].name
			oldlvl[oldparent].type = 'execute'
			oldlvl["|cff0077ff"..oldparent.."***"..setname] = oldlvl[oldparent]
			oldlvl[oldparent] = nil
			oldlvl["|cff0077ff"..oldparent.."***"..setname].func = function() PT3Browser:Expand(setname, oldlvl["|cff0077ff"..oldparent.."***"..setname]) end
		elseif expandedmultis[setname] == 2 then
			oldlvl[oldparent].name = "|cff0077ff"..oldlvl[oldparent].name
			oldlvl[oldparent].type = 'group'
			oldlvl["|cff0077ff"..oldparent.."***"..setname] = oldlvl[oldparent]
			oldlvl[oldparent] = nil
		end
	end
	for i = 1, GetNumAddOns() do
		local metadata = GetAddOnMetadata(i, "X-PeriodicTable-3.0-Module")
		if metadata then
			local name, _, _, enabled = GetAddOnInfo(i)
			if enabled and not aot.args[metadata] then
				aot.args[metadata] = {
					type = 'group',
					name = metadata,
					desc = metadata,
					args = {
						load = {
							type = 'execute',
							name = L["Load"],
							desc = L["Load"],
							func = function()
								LoadAddOn(name)
								PT3Browser:BuildTable()
							end,
						}
					},
				}
			end
		end
	end
	collectgarbage()
end
function PT3Browser:OnClick(button)
	if button ~= "LeftButton" then return end
	if not aot then PT3Browser:BuildTable() end
	local frame
	if PT3Browser:IsMinimapAttached() then
		frame = FuBarPluginPT3BrowserFrameMinimapButton
	else
		frame = FuBarPluginPT3BrowserFrame
	end
	dewdrop:Open(frame, 'children', function(level, val1, val2, val3)
		dewdrop:FeedAceOptionsTable(aot)
		if level == 1 then
			dewdrop:AddLine(
				'text', "Item Search",
				'hasArrow', true,
				'hasEditBox', true,
				'editBoxFunc', function(text)
					local link
					if tonumber(text) then
						link = text
					else
						local _
						_, link = GetItemInfo(text)
					end
					if link then
						--[[!! re-add this
						local sets = PT:ItemSearch(link)
						if not sets then
							ChatFrame1:AddMessage(L["No results found"])
							return
						end
						for k,v in pairs(sets) do
							ChatFrame1:AddMessage(link..L[" found in '"]..v)
						end
						collectgarbage()
						]]
					else
						ChatFrame1:AddMessage(L["Not a valid item: "]..text)
					end
				end
			)
		end
		if val1 and val1:sub(1,2) == "|c" then
			local setstring = val1:match("%*%*%*(.+)$")
			for k,v in PT:IterateSet(setstring) do
				local name, link, rarity, _,_,_,_,_,_, texture = GetItemInfo(k)
				if k < 0 then
					if GetSpellLink then
						link = GetSpellLink(-1 * k)
						name, _, texture = GetSpellInfo(-1 * k)
						rarity = -1
					else
						--!! 2.3 compat, remove as of 2.4
						PT3BrowserTooltip:SetOwner(this, "ANCHOR_PRESERVE")
						link = "|cffffd000|Henchant:"..(-1 * k).."|h[lol who knows]|h|r"
						PT3BrowserTooltip:SetHyperlink(link)
						PT3BrowserTooltip:Show()
						name = PT3BrowserTooltipTextLeft1:GetText()
						PT3BrowserTooltip:Hide()
						if name then
							link = "|cffffd000|Henchant:"..(-1 * k).."|h["..name.."]|h|r"
						end
						texture = "Interface\\Icons\\Spell_Holy_GreaterHeal"
						rarity = -1
					end
				end
				local append
				if tonumber(v) then
					append = "  "..v
				else
					append = ""
				end
				if not link or not name then
					dewdrop:AddLine(
						'text', "|cFFFF2222["..k.."]|r"..append,
						'func', PT3Browser.ItemClick,
						'arg1', self, 'arg2', k,
						'tooltipTitle', "|cFFFF2222"..k,
						'tooltipText', L["Query_Warning"]
					)
				else
					dewdrop:AddLine(
						'text', qualitycolors[rarity].."["..name.."]|r"..append,
						'func', PT3Browser.ItemClick,
						'arg1', self, 'arg2', link,
						'tooltipFunc', PT3Browser.SetTooltip,
						'tooltipArg1', GameTooltip, 'tooltipArg2', link,
						'icon', texture
					)
				end
			end
		end
	end)
end
function PT3Browser:Expand(setname, reft)
	local setstring = PT:GetSetString(setname)
	if setstring:sub(1,2) == "m," or setstring:sub(1,2) == "c[" then
		PT:GetSetTable(setname)
		local add = true
		if setstring:sub(1,2) == "m," then
			local parent = setname:match("(.+)[^%.]$")
			for child in setstring:sub(3):gmatch("([^,]+)") do
				local thisparent = child:sub(1,parent:len())
				if thisparent ~= parent then
					add = false
				end
			end
		end
		if add then
			expandedmultis[setname] = 1
		else
			expandedmultis[setname] = 2
		end
		PT3Browser:BuildTable()
	end
	reft.type = 'group'
end
function PT3Browser:SetTooltip(arg1)
	GameTooltip_SetDefaultAnchor(GameTooltip, this)
	GameTooltip:SetHyperlink(arg1)
end
function PT3Browser:ItemClick(arg)
	if tonumber(arg) then
		PT3Browser:GetItemData(arg)
		PT3Browser:ScheduleEvent("PT3BRefresh", 1)
		return
	end
	if IsControlKeyDown() then
		DressUpItemLink(arg:match("(item:%d+)"))
	else
		if not ChatFrameEditBox:IsVisible() then
			ChatFrameEditBox:Show()
		end
		ChatFrameEditBox:Insert(arg)
	end
end
function PT3Browser:PT3BRefresh()
	dewdrop:Refresh(1)
	dewdrop:Refresh(2)
	dewdrop:Refresh(3)
	dewdrop:Refresh(4)
	dewdrop:Refresh(5)
	dewdrop:Refresh(6)
	dewdrop:Refresh(7)
end
function PT3Browser:GetItemData(id)
	PT3BrowserTooltip:SetOwner(this, "ANCHOR_PRESERVE")
	PT3BrowserTooltip:SetHyperlink("item:" .. id)
	PT3BrowserTooltip:Hide()
end