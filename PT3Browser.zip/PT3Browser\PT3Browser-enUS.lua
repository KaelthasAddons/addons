local L = AceLibrary("AceLocale-2.2"):new("PT3Browser")

L:RegisterTranslations("enUS", function() return {
	["PT3"] = true,
	["Query_Warning"] = "Item not found, click to query server. |cFFFF2222WARNING: This WILL disconnect you if the server has not seen the item.",
	["PT has %s sets"] = true,
	["Not a valid item: "] = true,
	[" found in '"] = true,
	["No results found"] = true,
	["Load"] = true,
} end)