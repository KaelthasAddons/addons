local L = AceLibrary("AceLocale-2.2"):new("PT3Browser")

L:RegisterTranslations("deDE", function() return {
--~ 	["PT3"] = true,
	["Query_Warning"] = "Item nicht gefunden, Klicken um beim Server nachzufragen. |cFFFF2222WARNUNG: Das WIRD die Verbindung trennen wenn das Item dem Server nicht bekannt ist.",
	["PT has %s sets"] = "PT hat %s Sets",
	["Not a valid item: "] = "Ung\195\188ltiges Item: ",
	[" found in '"] = " gefunden in '",
	["No results found"] = "Kein Ergebnis",
	["Load"] = "Laden",
} end)
