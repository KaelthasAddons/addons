MonkeySpeed:

/monkeyspeedcalibrate
/mscalibrate
Use it while running at 100% to calibrate

/monkeyspeed
/mspeed
Toggle the display of the speedometer

/monkeyspeedpercent
/mspercent
Toggle the percentage display on the speedometer

/monkeyspeedbar
/msbar
Toggle the colour bar display on the speedometer

/monkeyspeeddebug
/msdebug
Toggle debug mode

/monkeyspeedlock
/mslock
Toggle lock
