SimpleCalc - Copyright (c) 2008 GuildWorks.co.uk

--[ Description ]--

SimpleCalc is a simple mathematical calculator addon for World of Warcraft.
It's a slash-based utility which allows you to do maths!

Example usage and response:

/calc 10415 - 9843 + 12
[SimpleCalc] 10415 - 9843 + 12 = 584

Variable support has been added in version 0.2 to make life easier when doing
certain calculations. You can now use key variable names in place of numbers
for the following values:

* Honour points
* Arena points
* Maximum Health points
* Maximum Mana points
* Gold
* Silver
* Copper

For example:

/calc 14500 + 10500 - honour
[SimpleCalc] 14500 + 10500 - honour = 8372

SimpleCalc works on equations left to right, so '10 * 3 + 2' would be broken
down into two sums: '10 * 3', then '30 + 2'. Support for brackets is not yet
in place, but this shouldn't affect every day calculations.

Comments, suggestions and bug reports are most welcome!


--[ License ]--

SimpleCalc is provided under the MIT license. In essence, do what you will
with this software, but please give credit to the original author.
