local AceLocale = LibStub:GetLibrary("AceLocale-3.0")
local L = AceLocale:NewLocale("Chatter", "esES")
if not L then return end

L["Warlock"] = "Brujo"
L["Warrior"] = "Guerrero"
L["Hunter"] = "Cazador"
L["Mage"] = "Mago"
L["Priest"] = "Sacerdote"
L["Druid"] = "Druida"
L["Paladin"] = "Palad\195\173n"
L["Shaman"] = "Cham\195\161n"
L["Rogue"] = "P\195\173caro"