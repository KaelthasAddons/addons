local L = AceLibrary("AceLocale-2.2"):new("GlowFoSho")

L:RegisterTranslations("deDE", function() return {
		--commands
		["/gfs"] = "/gfs",
		["standby"] = "standby",
		["Enable/disable the addon"] = "Addon aktivieren/deaktivieren",
		["Active"] = "aktiv",
		["Suspended"] = "inaktiv",
		
		--dewdrop menu
		["Show Weapon Link"] = "Waffenlink",
		["Displays the link of the enchanted weapon in the chat frame."] = "Zeige die verzauberte Waffe als Itemlink im Chat",
		["Show Enchant Link"] = "Verzauberungslink",
		["Displays the link of the enchant currently on the weapon in the chat frame."] = "Zeige die momentane Verzauberung als Link im Chat",		--changed to not warn about disconnects
		["Show Glowless Enchants"] = "nicht-leuchtende",
		["Allows you to preview enchants which do not add glow to a weapon."] = "Zeigt auch Vezauberungen die der Waffe keinen Leuchteffekt verleihen",
		["Show Only Compatible Enchants"] = "nur kompatible",
		["Filters out enchants that cannot be applied to the currently previewed weapon."] = "Zeigt nur Verzauberungen die auf die momentane Waffe angewendet werden k\195\182nnen",
		["Enchants"] = "Verzauberungen",
		["List of weapon enchants you can preview."] = "Verzauberungen ausw\195\164hlen",
		["Clear"] = "Entfernen",
		["Removes enchant from the weapon in the dressing room."] = "Entfernt die momentane Verzauberung der Waffe",
		
		--messages
		["There is no enchant on the weapon or enchant unknown."] = "Keine oder unbekannte Verzauberung auf der Waffe",
		
		--whisper enchant
		["!glow"] = "!glow",		--string to request enchant
		["glow>"] = "glow>",		--reply string
		["Unknown enchant."] = "unbekannte Verzauberung",		--enchant name was not found in the database
		["No weapon enchant link specified."] = "kein Verzauberungslink gefunden",		--enchant link was not found in the query
		["No weapon link specified."] = "kein Waffenlink gefunden",			--weapon link was not found in the query
		["Syntax: !glow <weapon link> <enchant link>"] = "Syntax: !glow <weapon link> <enchant link>",	--syntax message displayed when querried with !glow only
		
		--enchants as they appear in the list
		["Agility (2H)"] = "Beweglichkeit (2H)",
		["Agility"] = "Beweglichkeit",
		["Battlemaster"] = "Meister des Kampfes",
		["Crusader"] = "Kreuzfahrer",
		["Deathfrost"] = "Todesk\195\164lte",
		["Demonslaying"] = "D\195\164monent\195\182ten",
		["Executioner"] = "Scharfrichter",
		["Fiery Weapon"] = "Feurige Waffe",
		["Greater Agility"] = "Gro\195\159e Beweglichkeit",
		["Greater Impact (2H)"] = "Gro\195\159er Einschlag (2H)",
		["Greater Striking"] = "Gro\195\159es Schlagen",
		["Healing Power"] = "Heilkraft",
		["Icy Chill"] = "Eisiger Hauch",
		["Impact (2H)"] = "Einschlag (2H)",
		["Lesser Beastslayer"] = "Geringer Wildtiert\195\182ter",
		["Lesser Elemental Slayer"] = "Geringer Elementart\195\182ter",
		["Lesser Impact (2H)"] = "Geringer Einschlag (2H)",
		["Lesser Intellect (2H)"] = "Geringe Intelligenz (2H)",
		["Lesser Spirit (2H)"] = "Geringe Willenskraft (2H)",
		["Lesser Striking"] = "Geringes Schlagen",
		["Lifestealing"] = "Lebensdiebstahl",
		["Major Agility (2H)"] = "Erhebliche Beweglichkeit (2H)",
		["Major Healing"] = "Erhebliche Heilung",
		["Major Intellect (2H)"] = "Erhebliche Intelligenz (2H)",
		["Major Intellect"] = "Erhebliche Intelligenz",
		["Major Spellpower"] = "Erhebliche Zaubermacht",
		["Major Spirit (2H)"] = "Erhebliche Willenskraft (2H)",
		["Major Striking"] = "Erhebliches Schlagen",
		["Mighty Intellect"] = "M\195\164chtige Intelligenz",
		["Mighty Spirit"] = "M\195\164chtige Willenskraft",
		["Minor Beastslayer"] = "Schwacher Wildtiert\195\182ter",
		["Minor Impact (2H)"] = "Schwacher Einschlag (2H)",
		["Minor Striking"] = "Schwaches Schlagen",
		["Mongoose"] = "Mungo",
		["Potency"] = "Potenz",
		["Savagery (2H)"] = "Unb\195\164ndigkeit (2H)",
		["Soulfrost"] = "Seelenfrost",
		["Spell Power"] = "Zauberkraft",
		["Spellsurge"] = "Zauberflut",
		["Strength"] = "St\195\164rke",
		["Striking"] = "Schlagen",
		["Sunfire"] = "Sonnenfeuer",
		["Superior Impact (2H)"] = "\195\156berragender Einschlag (2H)",
		["Superior Striking"] = "\195\156berragendes Schlagen",
		["Unholy Weapon"] = "Unheilige Waffe",
		["Winter's Might"] = "Wintermacht",
	} end)
