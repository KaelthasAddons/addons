local L = AceLibrary("AceLocale-2.2"):new("GlowFoSho")

L:RegisterTranslations("enUS", function() return {
		--commands
		["/gfs"] = true,
		["standby"] = true,
		["Enable/disable the addon"] = true,
		["Active"] = true,
		["Suspended"] = true,
		
		--dewdrop menu
		["Show Weapon Link"] = "Weapon Link",
		["Displays the link of the enchanted weapon in the chat frame."] = true,
		["Show Enchant Link"] = "Enchant Link",
		["Displays the link of the enchant currently on the weapon in the chat frame."] = true,		--changed to not warn about disconnects
		["Show Glowless Enchants"] = "Glowless Enchants",
		["Allows you to preview enchants which do not add glow to a weapon."] = true,
		["Show Only Compatible Enchants"] = "Only Compatible",
		["Filters out enchants that cannot be applied to the currently previewed weapon."] = true,
		["Enchants"] = true,
		["List of weapon enchants you can preview."] = true,
		["Clear"] = true,
		["Removes enchant from the weapon in the dressing room."] = true,
		
		--messages
		["There is no enchant on the weapon or enchant unknown."] = true,
		
		--whisper enchant
		["!glow"] = true,		--string to request enchant
		["glow>"] = true,		--reply string
		["Unknown enchant."] = true,		--enchant name was not found in the database
		["No weapon enchant link specified."] = true,		--enchant link was not found in the query
		["No weapon link specified."] = true,			--weapon link was not found in the query
		["Syntax: !glow <weapon link> <enchant link>"] = true,	--syntax message displayed when querried with !glow only
		
		--enchants as they appear in the list
		["Agility (2H)"] = true,
		["Agility"] = true,
		["Battlemaster"] = true,
		["Crusader"] = true,
		["Deathfrost"] = true,
		["Demonslaying"] = true,
		["Executioner"] = true,
		["Fiery Weapon"] = true,
		["Greater Agility"] = true,
		["Greater Impact (2H)"] = true,
		["Greater Striking"] = true,
		["Healing Power"] = true,
		["Icy Chill"] = true,
		["Impact (2H)"] = true,
		["Lesser Beastslayer"] = true,
		["Lesser Elemental Slayer"] = true,
		["Lesser Impact (2H)"] = true,
		["Lesser Intellect (2H)"] = true,
		["Lesser Spirit (2H)"] = true,
		["Lesser Striking"] = true,
		["Lifestealing"] = true,
		["Major Agility (2H)"] = true,
		["Major Healing"] = true,
		["Major Intellect (2H)"] = true,
		["Major Intellect"] = true,
		["Major Spellpower"] = true,
		["Major Spirit (2H)"] = true,
		["Major Striking"] = true,
		["Mighty Intellect"] = true,
		["Mighty Spirit"] = true,
		["Minor Beastslayer"] = true,
		["Minor Impact (2H)"] = true,
		["Minor Striking"] = true,
		["Mongoose"] = true,
		["Potency"] = true,
		["Savagery (2H)"] = true,
		["Soulfrost"] = true,
		["Spell Power"] = true,
		["Spellsurge"] = true,
		["Strength"] = true,
		["Striking"] = true,
		["Sunfire"] = true,
		["Superior Impact (2H)"] = true,
		["Superior Striking"] = true,
		["Unholy Weapon"] = true,
		["Winter's Might"] = true,
	} end)
