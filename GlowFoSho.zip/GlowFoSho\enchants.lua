GlowFoSho_enchants = {
	["7786"] = {
		["enchantID"] = "249",
		["name"] = "Minor Beastslayer",
	},
	["7788"] = {
		["enchantID"] = "250",
		["glowless"] = true,
		["name"] = "Minor Striking",
	},
	["7793"] = {
		["enchantID"] = "723",
		["glowless"] = true,
		["name"] = "Lesser Intellect",
		["is2H"] = true,
	},
	["7745"] = {
		["enchantID"] = "241",
		["glowless"] = true,
		["name"] = "Minor Impact",
		["is2H"] = true,
	},
	["13380"] = {
		["enchantID"] = "255",
		["glowless"] = true,
		["name"] = "Lesser Spirit",
		["is2H"] = true,
	},
	["13503"] = {
		["enchantID"] = "241",
		["glowless"] = true,
		["name"] = "Lesser Striking",
	},
	["13529"] = {
		["enchantID"] = "943",
		["name"] = "Lesser Impact",
		["is2H"] = true,
	},
	["13653"] = {
		["enchantID"] = "853",
		["name"] = "Lesser Beastslayer",
	},
	["13655"] = {
		["enchantID"] = "854",
		["name"] = "Lesser Elemental Slayer",
	},
	["21931"] = {
		["enchantID"] = "2443",
		["glowless"] = true,
		["name"] = "Winter's Might",
	},
	["13693"] = {
		["enchantID"] = "943",
		["name"] = "Striking",
	},
	["13695"] = {
		["enchantID"] = "1897",
		["name"] = "Impact",
		["is2H"] = true,
	},
	["13915"] = {
		["enchantID"] = "912",
		["name"] = "Demonslaying",
	},
	["13937"] = {
		["enchantID"] = "963",
		["name"] = "Greater Impact",
		["is2H"] = true,
	},
	["13943"] = {
		["enchantID"] = "805",
		["name"] = "Greater Striking",
	},
	["13898"] = {
		["enchantID"] = "803",
		["name"] = "Fiery Weapon",
	},
	["20029"] = {
		["enchantID"] = "1894",
		["name"] = "Icy Chill",
	},
	["27837"] = {
		["enchantID"] = "2646",
		["name"] = "Agility",
		["is2H"] = true,
	},
	["23800"] = {
		["enchantID"] = "2564",
		["name"] = "Agility",
	},
	["23799"] = {
		["enchantID"] = "2563",
		["name"] = "Strength",
	},
	["20030"] = {
		["enchantID"] = "1896",
		["name"] = "Superior Impact",
		["is2H"] = true,
	},
	["20033"] = {
		["enchantID"] = "1899",
		["name"] = "Unholy Weapon",
	},
	["20036"] = {
		["enchantID"] = "1904",
		["name"] = "Major Intellect",
		["is2H"] = true,
	},
	["20035"] = {
		["enchantID"] = "1903",
		["name"] = "Major Spirit",
		["is2H"] = true,
	},
	["20034"] = {
		["enchantID"] = "1900",
		["name"] = "Crusader",
	},
	["22750"] = {
		["enchantID"] = "2505",
		["name"] = "Healing Power",
	},
	["20032"] = {
		["enchantID"] = "1898",
		["name"] = "Lifestealing",
	},
	["23804"] = {
		["enchantID"] = "2568",
		["name"] = "Mighty Intellect",
	},
	["23803"] = {
		["enchantID"] = "2567",
		["name"] = "Mighty Spirit",
	},
	["22749"] = {
		["enchantID"] = "2504",
		["name"] = "Spell Power",
	},
	["20031"] = {
		["enchantID"] = "1897",
		["name"] = "Superior Striking",
	},
	["27968"] = {
		["lvl"] = 35,
		["enchantID"] = "2666",
		["name"] = "Major Intellect",
	},
	["27967"] = {
		["lvl"] = 35,
		["enchantID"] = "963",
		["name"] = "Major Striking",
	},
	["27971"] = {
		["lvl"] = 35,
		["enchantID"] = "2667",
		["name"] = "Savagery",
		["is2H"] = true,
	},
	["42620"] = {
		["lvl"] = 35,
		["enchantID"] = "3222",
		["name"] = "Greater Agility",
	},
	["34010"] = {
		["lvl"] = 35,
		["enchantID"] = "2343",
		["name"] = "Major Healing",
	},
	["27975"] = {
		["lvl"] = 35,
		["enchantID"] = "2669",
		["name"] = "Major Spellpower",
	},
	["27972"] = {
		["lvl"] = 35,
		["enchantID"] = "2668",
		["name"] = "Potency",
	},
	["27977"] = {
		["lvl"] = 35,
		["enchantID"] = "2670",
		["name"] = "Major Agility",
		["is2H"] = true,
	},
	["28004"] = {
		["lvl"] = 35,
		["enchantID"] = "2675",
		["name"] = "Battlemaster",
	},
	["28003"] = {
		["lvl"] = 35,
		["enchantID"] = "2674",
		["name"] = "Spellsurge",
	},
	["42974"] = {
		["lvl"] = 60,
		["enchantID"] = "3225",
		["name"] = "Executioner",
	},
	["27984"] = {
		["lvl"] = 35,
		["enchantID"] = "2673",
		["name"] = "Mongoose",
	},
	["27982"] = {
		["lvl"] = 35,
		["enchantID"] = "2672",
		["name"] = "Soulfrost",
	},
	["27981"] = {
		["lvl"] = 35,
		["enchantID"] = "2671",
		["name"] = "Sunfire",
	},
	["46578"] = {
		["lvl"] = 60,
		["enchantID"] = "3273",
		["name"] = "Deathfrost",
	},
}