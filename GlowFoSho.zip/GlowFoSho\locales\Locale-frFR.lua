﻿local L = AceLibrary("AceLocale-2.2"):new("GlowFoSho")

L:RegisterTranslations("frFR", function() return {
		--commands
		["/gfs"] = "/gfs",
		["standby"] = "veille",
		["Enable/disable the addon"] = "Active/désactive GlowFoSho",
		["Active"] = "Activé",
		["Suspended"] = "Désactivé",
		
		--dewdrop menu
		["Show Weapon Link"] = "Afficher le lien de l'arme",
		["Displays the link of the enchanted weapon in the chat frame."] = "Affiche le lien de l'arme enchantée dans la fenêtre de discussion.",
		["Show Enchant Link"] = "Afficher le lien de l'enchantement",
		["Displays the link of the enchant currently on the weapon in the chat frame."] = "Affiche le lien de l'enchantement présent sur l'arme dans la fenêtre de discussion.",		--changed to not warn about disconnects
		["Show Glowless Enchants"] = "Afficher les enchantements sans effet lumineux",
		["Allows you to preview enchants which do not add glow to a weapon."] = "Vous permet de prévisualiser les enchantements qui n'ajoutent pas d'effet lumineux aux armes.",
		["Show Only Compatible Enchants"] = "Montrer seulement les enchantements compatibles",
		["Filters out enchants that cannot be applied to the currently previewed weapon."] = "Filtre les enchantements qui ne peuvent pas être appliqués à l'arme en cours.",
		["Enchants"] = "Enchantements",
		["List of weapon enchants you can preview."] = "Liste des enchantements d'armes que vous pouvez prévisualiser.",
		["Clear"] = "Enlever l'enchantement",
		["Removes enchant from the weapon in the dressing room."] = "Enlève l'enchantement sur l'arme dans la cabine d'essayage.",
		
		--messages
		["There is no enchant on the weapon or enchant unknown."] = "Il n'y a pas d'enchantement sur l'arme ou enchantement inconnu.",
		
		--whisper enchant
		["!glow"] = "!glow",		--string to request enchant
		["glow>"] = "glow>",		--reply string
		["Unknown enchant."] = "Enchantement inconnu.",		--enchant name was not found in the database
		["No weapon enchant link specified."] = "Lien inconnu pour cet enchantement.",		--enchant link was not found in the query
		["No weapon link specified."] = "Lien inconnu pour cette arme.",			--weapon link was not found in the query
		["Syntax: !glow <weapon link> <enchant link>"] = "Syntaxe: !glow <lien arme> <lien enchantement>",	--syntax message displayed when querried with !glow only
		
		--enchants as they appear in the list
		["Agility (2H)"] = "Agilité (2M)",
		["Agility"] = "Agilité",
		["Battlemaster"] = "Maître de guerre",
		["Crusader"] = "Croisé",
		["Demonslaying"] = "Tueur de démon",
		["Executioner"] = "Bourreau",
		["Fiery Weapon"] = "Arme flamboyante",
		["Greater Agility"] = "Agilité supérieure",
		["Greater Impact (2H)"] = "Impact supérieur (2M)",
		["Greater Striking"] = "Frappe supérieure",
		["Healing Power"] = "Pouvoir de guérison",
		["Icy Chill"] = "Frisson glacial",
		["Impact (2H)"] = "Impact (2M)",
		["Lesser Beastslayer"] = "Tueur de bête inférieur",
		["Lesser Elemental Slayer"] = "Tueur d'élémentaire inférieur",
		["Lesser Impact (2H)"] = "Impact inférieur (2M)",
		["Lesser Intellect (2H)"] = "Intelligence inférieure (2M)",
		["Lesser Spirit (2H)"] = "Esprit inférieur (2M)",
		["Lesser Striking"] = "Frappe inférieure",
		["Lifestealing"] = "Vol de vie",
		["Major Agility (2H)"] = "Agilité majeure (2M)",
		["Major Healing"] = "Soins majeurs",
		["Major Intellect (2H)"] = "Intelligence majeure (2M)",
		["Major Intellect"] = "Intelligence majeure",
		["Major Spellpower"] = "Puissance des sorts majeure",
		["Major Spirit (2H)"] = "Esprit majeur (2M)",
		["Major Striking"] = "Frappe majeure",
		["Mighty Intellect"] = "Intelligence renforcée",
		["Mighty Spirit"] = "Esprit renforcé",
		["Minor Beastslayer"] = "Tueur de bête mineur",
		["Minor Impact (2H)"] = "Impact mineur (2M)",
		["Minor Striking"] = "Frappe mineure",
		["Mongoose"] = "Mangouste",
		["Potency"] = "Toute-puissance",
		["Savagery (2H)"] = "Sauvagerie (2M)",
		["Soulfrost"] = "Âme de givre",
		["Spell Power"] = "Puissance des sorts",
		["Spellsurge"] = "Eruption de sort",
		["Strength"] = "Force",
		["Striking"] = "Frappe",
		["Sunfire"] = "Feu solaire",
		["Superior Impact (2H)"] = "Impact excellent (2M)",
		["Superior Striking"] = "Frappe supérieure",
		["Unholy Weapon"] = "Arme impie",
		["Winter's Might"] = "Puissance de l'hiver",
	} end)
