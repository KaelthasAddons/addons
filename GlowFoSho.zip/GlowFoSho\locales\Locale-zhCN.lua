﻿local L = AceLibrary("AceLocale-2.2"):new("GlowFoSho")

L:RegisterTranslations("zhCN", function() return {
		--commands
		["/gfs"] = "/gfs",
		["standby"] = "暂挂",
		["Enable/disable the addon"] = "启用/禁用 插件",
		["Active"] = "激活",
		["Suspended"] = "停用",
		
		--dewdrop menu
		["Show Weapon Link"] = "显示武器链接",
		["Displays the link of the enchanted weapon in the chat frame."] = "在聊天窗口显示附魔后武器链接。",
		["Show Enchant Link"] = "显示附魔链接",
		["Displays the link of the enchant currently on the weapon in the chat frame."] = "在聊天窗口显示目前武器附魔链接。>注意<：有些附魔链接可能造成与服务器断开连接！",		--changed to not warn about disconnects
		["Show Glowless Enchants"] = "显示附魔效果",
		["Allows you to preview enchants which do not add glow to a weapon."] = "允许您预览未附魔武器的附魔效果。",
		["Show Only Compatible Enchants"] = "只显示相对应附魔",
		["Filters out enchants that cannot be applied to the currently previewed weapon."] = "过滤附魔使其不能用于不正确的预览武器。",
		["Enchants"] = "附魔",
		["List of weapon enchants you can preview."] = "您可以预览的武器附魔。",
		["Clear"] = "清除",
		["Removes enchant from the weapon in the dressing room."] = "在试衣间清除武器附魔效果。",
		
		--messages
		["There is no enchant on the weapon or enchant unknown."] = "没有发现武器附魔或附魔未知。",
		
		--whisper enchant
		["!glow"] = "!附魔效果",		--string to request enchant
		["glow>"] = "附魔效果>",		--reply string
		["Unknown enchant."] = "未知附魔。",		--enchant name was not found in the database
		["No weapon enchant link specified."] = "未指定武器附魔链接。",			--enchant link was not found in the query
		["No weapon link specified."] = "未指定武器链接。",				--weapon link was not found in the query
		["Syntax: !glow <weapon link> <enchant link>"] = "句式：!附魔效果 <武器链接> <附魔链接>",		--syntax message displayed when querried with !glow only
		
		--enchants as they appear in the list
		["Agility (2H)"] = "敏捷（双手）",
		["Agility"] = "敏捷",
		["Battlemaster"] = "作战专家",
		["Crusader"] = "十字军",
		["Deathfrost"] = "死亡霜冻",
		["Demonslaying"] = "屠魔",
		["Executioner"] = "斩杀",
		["Fiery Weapon"] = "烈焰",
		["Greater Agility"] = "强效敏捷",
		["Greater Impact (2H)"] = "强效冲击（双手）",
		["Greater Striking"] = "强效攻击",
		["Healing Power"] = "治疗能量",
		["Icy Chill"] = "冰寒",
		["Impact (2H)"] = "冲击（双手）",
		["Lesser Beastslayer"] = "次级屠兽",
		["Lesser Elemental Slayer"] = "次级元素杀手",
		["Lesser Impact (2H)"] = "次级冲击（双手）",
		["Lesser Intellect (2H)"] = "次级智力（双手）",
		["Lesser Spirit (2H)"] = "次级精神（双手）",
		["Lesser Striking"] = "次级攻击",
		["Lifestealing"] = "生命偷取",
		["Major Agility (2H)"] = "特效敏捷（双手）",
		["Major Healing"] = "特效治疗",
		["Major Intellect (2H)"] = "特效智力（双手）",
		["Major Intellect"] = "特效智力",
		["Major Spellpower"] = "特效法术能量",
		["Major Spirit (2H)"] = "特效精神（双手）",
		["Major Striking"] = "特效打击",
		["Mighty Intellect"] = "强效智力",
		["Mighty Spirit"] = "强效精神",
		["Minor Beastslayer"] = "初级屠兽",
		["Minor Impact (2H)"] = "初级冲击（双手）",
		["Minor Striking"] = "初级攻击",
		["Mongoose"] = "猫鼬",
		["Potency"] = "力量",
		["Savagery (2H)"] = "野蛮（双手）",
		["Soulfrost"] = "魂霜",
		["Spell Power"] = "法术能量",
		["Spellsurge"] = "魔法激荡",
		["Strength"] = "力量",
		["Striking"] = "攻击",
		["Sunfire"] = "阳炎",
		["Superior Impact (2H)"] = "超强冲击（双手）",
		["Superior Striking"] = "超强打击",
		["Unholy Weapon"] = "邪恶武器",
		["Winter's Might"] = "寒冬之力",
	} end)
