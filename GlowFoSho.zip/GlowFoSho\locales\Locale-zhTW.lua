﻿local L = AceLibrary("AceLocale-2.2"):new("GlowFoSho")

L:RegisterTranslations("zhTW", function() return {
		--commands
		["/gfs"] = "/gfs",
		["standby"] = "準備",
		["Enable/disable the addon"] = "開啟/關閉 插件",
		["Active"] = "啟動",
		["Suspended"] = "停用",
		
		--dewdrop menu
		["Show Weapon Link"] = "顯示武器連結",
		["Displays the link of the enchanted weapon in the chat frame."] = "在聊天視窗顯示附魔後的武器連結",
		["Show Enchant Link"] = "顯示附魔連結",
		["Displays the link of the enchant currently on the weapon in the chat frame."] = "聊天視窗顯示目前武器連結 (注意!有些連結會造成與伺服器斷線!)",	--changed to not warn about disconnects
		["Show Glowless Enchants"] = "顯示附魔效果",
		["Allows you to preview enchants which do not add glow to a weapon."] = "允許您預覽未附魔武器的附魔效果",
		["Show Only Compatible Enchants"] = "只顯示相容的附魔",
		["Filters out enchants that cannot be applied to the currently previewed weapon."] = "過濾附魔使其不能應用於不正確的武器預覽",
		["Enchants"] = "附魔",
		["List of weapon enchants you can preview."] = "您可以預覽的武器附魔清單",
		["Clear"] = "清除",
		["Removes enchant from the weapon in the dressing room."] = "在試衣間清除武器附魔效果",
		
		--messages
		["There is no enchant on the weapon or enchant unknown."] = "没有發現武器附魔或附魔未知",
		
		--whisper enchant
		["!glow"] = "!glow",						--string to request enchant
		["glow>"] = "glow>",						--reply string
		["Unknown enchant."] = "未知附魔",				--enchant name was not found in the database
		["No weapon enchant link specified."] = "未指定武器附魔連結",	--enchant link was not found in the query
		["No weapon link specified."] = "未指定武器連結",		--weapon link was not found in the query
		["Syntax: !glow <weapon link> <enchant link>"] = "語法: !glow <武器連結> <附魔連結>",		--syntax message displayed when querried with !glow only
		
		--enchants as they appear in the list
		["Agility (2H)"] = "敏捷（双手）",
		["Agility"] = "敏捷",
		["Battlemaster"] = "戰鬥大師",
		["Crusader"] = "十字軍",
		["Deathfrost"] = "死亡冰霜",
		["Demonslaying"] = "屠魔",
		["Executioner"] = "處決者",
		["Fiery Weapon"] = "灼熱武器",
		["Greater Agility"] = "強效敏捷",
		["Greater Impact (2H)"] = "强效衝擊（双手）",
		["Greater Striking"] = "强效打擊",
		["Healing Power"] = "治療能量",
		["Icy Chill"] = "冰寒",
		["Impact (2H)"] = "衝擊（双手）",
		["Lesser Beastslayer"] = "次级屠獸",
		["Lesser Elemental Slayer"] = "次级元素殺手",
		["Lesser Impact (2H)"] = "次级衝擊（双手）",
		["Lesser Intellect (2H)"] = "次级智力（双手）",
		["Lesser Spirit (2H)"] = "次级精神（双手）",
		["Lesser Striking"] = "次级打擊",
		["Lifestealing"] = "生命偷取",
		["Major Agility (2H)"] = "極效敏捷（双手）",
		["Major Healing"] = "極效治療",
		["Major Intellect (2H)"] = "極效智力（双手）",
		["Major Intellect"] = "極效智力",
		["Major Spellpower"] = "極效法術能量",
		["Major Spirit (2H)"] = "極效精神（双手）",
		["Major Striking"] = "極效打擊",
		["Mighty Intellect"] = "極效智力",
		["Mighty Spirit"] = "極效精神",
		["Minor Beastslayer"] = "初级屠獸",
		["Minor Impact (2H)"] = "初级衝擊（双手）",
		["Minor Striking"] = "初级打擊",
		["Mongoose"] = "貓鼬",
		["Potency"] = "潛能",
		["Savagery (2H)"] = "兇蠻（雙手）",
		["Soulfrost"] = "靈魂冰霜",
		["Spell Power"] = "法術能量",
		["Spellsurge"] = "法力回流",
		["Strength"] = "力量",
		["Striking"] = "打擊",
		["Sunfire"] = "烈日火焰",
		["Superior Impact (2H)"] = "超强衝擊（双手）",
		["Superior Striking"] = "超强打擊",
		["Unholy Weapon"] = "邪能",
		["Winter's Might"] = "寒冬之力",
	} end)
