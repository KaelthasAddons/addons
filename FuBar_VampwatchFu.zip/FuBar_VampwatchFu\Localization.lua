local L = AceLibrary("AceLocale-2.2"):new("FuBar_VampwatchFu")

L:RegisterTranslations("enUS", function() return {
	["addonname"] = "|cffffffffVampwatch|r|cff00ff00Fu|r",
	["VampwatchFu"] = "VampwatchFu",
	["author"] = "Jayrox - Bleeing Hollow[US]",
	["consolecommands"] = { "/vwfu" },
	
	["show_title"] = "Show Title",
	["show_title_desc"] = "Show the VampwatchFu Title",
	
	["vamp_touch"] = "Show Vampiric Touch on Button",
	["vamp_touch_text"] = "Vampiric Touch",
	["vamp_touch_desc"] = "Toggles whether to show Vampiric Touch on the Button",
	["vt_title"] = " VT: ",
	["vt_opt"] = "Vampiric Touch Options",
	["vt_enabled"] = "Enable Vampiric Touch Tracking.",

	["vamp_touch_mp5"] = "Show MP/5 on Button",
	["vamp_touch_mp5_desc"] = "Toggles whether to show MP/5 on the Button",
    ["mp5_title"] = " MP5: ",
    
	
	["vamp_embrace"] = "Show Vampiric Embrace on Button",
	["vamp_embrace_text"] = "Vampiric Embrace",
	["vamp_embrace_desc"] = "Toggles whether to show Vampiric Embrace on the Button",
	["ve_title"] = " VE: ",
	["ve_opt"] = "Vampiric Embrace Options",
	["ve_enabled"] = "Enable Vampiric Embrace Tracking.",
	
	["sf_timer"] = "Shadowfiend Timer",
	["sf_timer_desc"] = "Show Shadowfiend Timer.",
	["sf_toggle"] = "Show Shadowfiend on Button",
	["sf_toggle_desc"] = "Toggles whether to show Shadowfiend on the Button",
	["sf_title"] = " SF: ",
	["sf_opt"] = "Shadowfiend Options",
	["sf_enabled"] = "Enable Shadowfiend Tracking",
	
	["Amount"] = true,
	
	["monitoroverheal"] = "Monitor Overhealing",
	["monitoroverheal_desc"] = "Monitor Vampiric Embrace Overhealing",
	["nothing monitored."] = true,
	["perfight"] = "Avg. Per Fight",
	
	["say"] = "Say",
	["party"] = "Party",
	["raid"] = "Raid",
	["guild"] = "Guild",
	["editbox"] = "Edit box",
	["send_to_say"] = "Send to Say",
	["send_to_party"] = "Send to Party",
	["send_to_raid"] = "Send to Raid",
	["send_to_guild"] = "Send to Guild",
	["send_to_editbox"] = "Send to an open editbox",
	
	["spam_opt"] = "Spam Options",
	["spam_opt_desc"] = "Spam Options",
	
	["send_custom"] = "Custom: ",
	["send_custom_channel"] = "Send to custom channel.",

	["total"] = "Total",
	["last"] = "Last Fight",
	["etotal"] = "Effective Total",
	["elast"] = "Effective Last Fight",
	["high"] = "Highest Tick",
	["avg"] = "Average Tick",
	["ticks"] = "Number of Ticks",
	["enabled"] = "Enabled",

	["reset_totals"] = "Reset Totals",
	["reset_totals_desc"] = "Reset Totals - Does not reset tick stats.",
	["reset_all"] = "Reset All",
	["reset_all_desc"] = "Reset All - Resets ALL stats back to zero.",
	["Reset_confirm"] = "Do you really want to Reset your stats?\n\nAll stats will be lost!",
	["Reset_confirm_totals"] = "Do you really want to Reset your stats?\n\nAll totals will be lost!",
	["reset_opt"] = "Reset Options",
	["reset_opt_desc"] = "Options for Reseting.",
	["reset_conf"] = "Confirm Reset",
	["reset_conf_desc"] = "Confirm reseting of stats.",
	
	["broadcast_opt"] = "Broadcasting Options",
	["multiline"] = "Multiline",
	["spam_on_click"] = "Enable Button Spam",
	["spam_on_click_desc"] = "Enable sending stats to chat on click",

	["Show Anchor"] = true,
	["Shows the dragable anchor."] = true,

	["Yes"] = true,
	["No"] = true,
	
	["Menu"] = true,
	["Menu options."] = true,

	
	["title_last"] = "Show last fight stats on the button.",
	["title_total"] = "Show overall stats on the button.",
	["title_text"] = "Button Text Options",
	["title_text_desc"] = "Button text display options.",

	["mana"] = true,
	["health"] = true,
	["effective health"] = true,
	
	-- Spam Strings
	[" ## VampwatchFu Stats:"] = true,
	[" ## Vampiric Touch - Last Fight: "] = true,
	[" ## Vampiric Touch - All Fights: "] = true,
	[" ## Vampiric Embrace - Last Fight: "] = true,
	[" ## Vampiric Embrace - All Fights: "] = true,
	["vwFu:: Vampiric Touch Total: "] = true,
	[" Vampiric Embrace Total: "] = true,
	["vwFu: Vampiric Embrace Ticks: "] = true,
	[" Average Tick: "] = true,
	[" Highest Tick: "] = true,
	["vwFu: Vampiric Touch Ticks: "] = true,
	["vwFu: Vampiric Embrace Total: "] = true,
	["vwFu: Vampiric Touch Total: "] = true,
	["vwFu: Vampiric Touch Last: "] = true,
	["vwFu: Vampiric Embrace Last: "] = true,
	["vwFu: Shadowfiend Ticks: "] = true,
	["vwFu: Shadowfiend Last: "] = true,
	["vwFu: Shadowfiend Total: "] = true,
	
	["vwFu: Shadowfiend Avg. Per Fight: "] = true,
	["vwFu: Vampiric Touch Avg. Per Fight: "] = true,
	["vwFu: Vampiric Embrace Avg. Per Fight: "] = true,
	
	["FuBarHint"] = "\n|cffeda55fClick|r to send to chat.\n|cffeda55fClick|r tooltip stat to send to chat.\n|cffeda55fAlt-Click|r to reset total stats.\n|cffeda55fCtrl-Click|r to reset all stats.",
	
} end)


L:RegisterTranslations("deDE", function() return {
	["addonname"] = "|cffffffffVampwatch|r|cff00ff00Fu|r",
	["VampwatchFu"] = "VampwatchFu",
	["author"] = "Jayrox - Bleeing Hollow[US]",
	["consolecommands"] = { "/vwfu" },
   
	["show_title"] = "Titel anzeigen",
	["show_title_desc"] = "VampwatchFu Titel anzeigen",
	
	["vamp_touch_mp5"] = "Show MP/5 on Button",
	["vamp_touch_mp5_desc"] = "Toggles whether to show MP/5 on the Button",
    ["mp5_title"] = " MP5: ",

	["vamp_touch"] = "Vampirber\195\188hrung anzeigen",
	["vamp_touch_text"] = "Vampirber\195\188hrung",
	["vamp_touch_desc"] = "Vampirber\195\188hrung anzeigen",
	["vt_title"] = " VT: ",
	["vt_opt"] = "Vampiric Touch Options",
	["vt_enabled"] = "Enable Vampiric Touch tracking.",

	["vamp_embrace"] = "Vampirumarmung anzeigen",
	["vamp_embrace_text"] = "Vampirumarmung",
	["vamp_embrace_desc"] = "Vampirumarmung anzeigen",
	["ve_title"] = " VE: ",
	["ve_opt"] = "Vampiric Embrace Options",
	["ve_enabled"] = "Enable Vampiric Embrace tracking.",
	
	["sf_timer"] = "Zeitanzeige: Schattengeist",
	["sf_timer_desc"] = "Zeitanzeige f?r Schattengeist",
	["sf_toggle"] = "Schattengeist anzeigen",
	["sf_toggle_desc"] = "Schattengeist anzeigen",
	["sf_title"] = " SF: ",
	["sf_opt"] = "Shadowfiend Options",
	["sf_enabled"] = "Enable Shadowfiend Tracking",

	["Amount"] = "Menge:",
	
	["monitoroverheal"] = "Overheal aufzeichnen",
	["monitoroverheal_desc"] = "Overheal durch Vampirumarmung aufzeichnen",
	["nothing monitored."] = "Nichts aufzeichnen",
	["perfight"] = "Avg. Per Fight",

	["say"] = "Sagen",
	["party"] = "Gruppe",
	["raid"] = "Schlachtzug",
	["guild"] = "Gilde",
	["editbox"] = "Open edit box",
	["send_to_say"] = "Ausgabe: Sagen",
	["send_to_party"] = "Ausgabe: Gruppe",
	["send_to_raid"] = "Ausgabe: Schlachtzug",
	["send_to_guild"] = "Ausgabe: Gilde",
	["send_to_editbox"] = "Send to an open editbox",

	["spam_opt"] = "Spam Options",
	["spam_opt_desc"] = "Spam Options",
	
	["send_custom"] = "Ausgabe: Selbstdefiniert",
	["send_custom_channel"] = "An einen selbstdefinierten Channel senden.",

	["total"] = "Gesamt",
	["last"] = "Letzter Kampf",
	["etotal"] = "Gesamt (effektiv)",
	["elast"] = "Letzter Kampf (effektiv)",
	["high"] = "H\195\182chster Tick",
	["avg"] = "Durchschnittlicher Tick",
	["ticks"] = "Anzahl an Ticks",
	["enabled"] = "Enabled",

	["reset_totals"] = "Summe zur\195\188cksetzen",
	["reset_totals_desc"] = "Summe zur\195\188cksetzen - setzt die Ticks NICHT zur?ck",
	["reset_all"] = "Alles zur\195\188cksetzen",
	["reset_all_desc"] = "Alles zur\195\188cksetzen - setzt ALLE Summen zur?ck",
	["Reset_confirm"] = "Wirklich alle Daten zur\195\188cksetzen??\n\nAlle Daten gehen verloren!",
	["Reset_confirm_totals"] = "Wirklich alle Summen zur\195\188cksetzen??\n\nAlle Summen gehen verloren!",
	["reset_opt"] = "Reset Options",
	["reset_opt_desc"] = "Options for Reseting.",
	["reset_conf"] = "Confirm Reset",
	["reset_conf_desc"] = "Confirm reseting of stats.",

	["broadcast_opt"] = "Ausgabeeinstellungen",
	["multiline"] = "Ausgabe in mehreren Linien",
	["spam_on_click"] = "Button Spam einschalten",
	["spam_on_click_desc"] = "Alle Werte werden beim Klicken in den Chat gespammt",

	["Show Anchor"] = "Anker anzeigen",
	["Shows the dragable anchor."] = "Zeigt einen Anker zum verschieben an.",

	["Yes"] = "Ja",
	["No"] = "Nein",
	
	["Menu"] = "Menu",
	["Menu options."] = "Men\195\188-Optionen",
   

 	["title_last"] = "Zeige den letzen Kampf beim Button an",
	["title_total"] = "Zeige die Gesamtwerte beim Button an",
	["title_text"] = "Button Textoptionen",
	["title_text_desc"] = "Button Textoptionen",

	["mana"] = "Mana",
	["health"] = "Gesundheit",
	["effective health"] = "Gesundheit (effektiv)",

	-- Spam Strings
	[" ## VampwatchFu Stats:"] = " ## VampwatchFu Werte:",
	[" ## Vampiric Touch - Last Fight: "] = " ## Vampirber\195\188hrung - Letzter Kampf: ",
	[" ## Vampiric Touch - All Fights: "] = " ## Vampirber\195\188hrung - Alle K\195\164mpfe: ",
	[" ## Vampiric Embrace - Last Fight: "] = " ## Vampirumarmung - Letzter Kampf: ",
	[" ## Vampiric Embrace - All Fights: "] = " ## Vampirumarmung - Alle K\195\164mpfe: ",
	["vwFu:: Vampiric Touch Total: "] = "vwFu:: Summe Vampirber\195\188hrung: ",
	[" Vampiric Embrace Total: "] = " Vampirumarmung - Summe: ",
	["vwFu: Vampiric Embrace Ticks: "] = "vwFu: Vampirumarmung Ticks: ",
	[" Average Tick: "] = " Durchschnittlicher Tick: ",
	[" Highest Tick: "] = " H\195\182chster Tick: ",
	["vwFu: Vampiric Touch Ticks: "] = "vwFu: Vampirber\195\188hrung Ticks: ",
	["vwFu: Vampiric Embrace Total: "] = "vwFu: Vampirumamrung - Summe: ",
	["vwFu: Vampiric Touch Total: "] = "vwFu: Vampirber\195\188hrung - Summe: ",
	["vwFu: Vampiric Touch Last: "] = "vwFu: Vampirber\195\188hrung - letzter Wert: ",
	["vwFu: Vampiric Embrace Last: "] = "vwFu: Vampirumarmung - letzter Wert: ",
	["vwFu: Shadowfiend Ticks: "] = "vwFu: Schattengeist Ticks: ",
	["vwFu: Shadowfiend Last: "] = "vwFu: Schattengeist - letzter Wert: ",
	["vwFu: Shadowfiend Total: "] = "vwFu: Schattengeist - Summe: ",

	["vwFu: Shadowfiend Avg. Per Fight: "] = "vwFu: Shadowfiend Avg. Per Fight: ",
	["vwFu: Vampiric Touch Avg. Per Fight: "] = "vwFu: Vampiric Touch Avg. Per Fight: ",
	["vwFu: Vampiric Embrace Avg. Per Fight: "] = "vwFu: Vampiric Embrace Avg. Per Fight: ",
	["FuBarHint"] = "Klicken um Daten an den Chat zu schicken.\nEinzelne Daten im Tooltip anklicken um Details an den Chat zu schicken.\n|cffeda55fAlt-Click|r to reset total stats.\n|cffeda55fCtrl-Click|r to reset all stats.", 
} end)

L:RegisterTranslations("frFR", function() return {
       ["addonname"] = "|cffffffffVampwatch|r|cff00ff00Fu|r",
       ["VampwatchFu"] = "VampwatchFu",
       ["author"] = "Jayrox - Bleeing Hollow[US]",
       ["consolecommands"] = { "/vwfu" },

       ["show_title"] = "Afficher Titre",
       ["show_title_desc"] = "Afficher le titre VampwatchFu",

       ["vamp_touch_mp5"] = "Show MP/5 on Button",
       ["vamp_touch_mp5_desc"] = "Toggles whether to show MP/5 on the Button",
       ["mp5_title"] = " MP5: ",

       ["vamp_touch"] = "Afficher Toucher vampirique",
       ["vamp_touch_text"] = "Toucher vampirique",
       ["vamp_touch_desc"] = "Afficher/Cacher le bouton Toucher vampirique",
       ["vt_title"] = " VT: ",
       ["vt_opt"] = "Options Toucher vampirique",
       ["vt_enabled"] = "Activer le Suivi.",

       ["vamp_embrace"] = "Afficher Etreinte vampirique",
       ["vamp_embrace_text"] = "Etreinte vampirique",
       ["vamp_embrace_desc"] = "Afficher/Cacher le bouton Etreinte vampirique",
       ["ve_title"] = " VE: ",
       ["ve_opt"] = "Options Etreinte vampirique",
       ["ve_enabled"] = "Activer le Suivi.",

       ["sf_timer"] = "Timer Ombrefiel",
       ["sf_timer_desc"] = "Afficher le timer Ombrefiel.",
       ["sf_toggle"] = "Afficher Ombrefiel",
       ["sf_toggle_desc"] = "Afficher/Cacher le bouton Ombrefiel",
       ["sf_title"] = " SF: ",
       ["sf_opt"] = "Options Ombrefiel",
       ["sf_enabled"] = "Activer le Suivi.",

       ["Amount"] = "Valeur",

       ["monitoroverheal"] = "Suivi Overheal",
       ["monitoroverheal_desc"] = "Activer le suivi Overheal",
       ["nothing monitored."] = "aucun Suivi",
       ["perfight"] = "Moyenne par combat",

       ["say"] = "Dire",
       ["party"] = "Groupe",
       ["raid"] = "Raid",
       ["guild"] = "Guilde",
       ["editbox"] = "Edit box",
       ["send_to_say"] = "Vers canal Dire",
       ["send_to_party"] = "Vers canal Groupe",
       ["send_to_raid"] = "Vers canal Raid",
       ["send_to_guild"] = "Vers canal Guilde",
       ["send_to_editbox"] = "Vers editbox",

       ["spam_opt"] = "Options de Reporting",
       ["spam_opt_desc"] = "Options de Reporting",

       ["send_custom"] = "Custom: ",
       ["send_custom_channel"] = "Vers canal Custom.",

       ["total"] = "Total",
       ["last"] = "Dernier combat",
       ["etotal"] = "Total (Effectif)",
       ["elast"] = "Dernier Combat (Effectif)",
       ["high"] = "Tick Max",
       ["avg"] = "Tick Moyen",
       ["ticks"] = "Nombre de Ticks",
       ["enabled"] = "Actif",

       ["reset_totals"] = "Reset Totaux",
       ["reset_totals_desc"] = "Reset Totaux - Ne Supprime pas les stats individuelles.",
       ["reset_all"] = "Reset Tout",
       ["reset_all_desc"] = "Reset Tout - Supprime toutes les stats.",
       ["Reset_confirm"] = "Souhaitez vous reellement supprimer les stats?\n\nToutes les valeurs seront perdues !",
       ["Reset_confirm_totals"] = "Souhaitez vous reellement supprimer les stats?\n\nToutes les valeurs seront perdues !",
       ["reset_opt"] = "Option Reset Stats",
       ["reset_opt_desc"] = "Suppression des stats.",
       ["reset_conf"] = "Confirmer la suppression",
       ["reset_conf_desc"] = "Confirmer la suppression des stats.",

       ["broadcast_opt"] = "Selection du Canal",
       ["multiline"] = "Multiligne",
       ["spam_on_click"] = "Activer Envoi sur Clic gauche",
       ["spam_on_click_desc"] = "Activer l'envoi des stats sur le canal au clic souris",

       ["Show Anchor"] = "Montrer Ancre",
       ["Shows the dragable anchor."] = "Montrer Ancre deplacable",

       ["Yes"] = "Oui",
       ["No"] = "Non",

       ["Menu"] = "Menu",
       ["Menu options."] = "Options Menu",


       ["title_last"] = "Afficher les stats du dernier combat dans FuBar.",
       ["title_total"] = "Afficher toutes les stats dans FuBar.",
       ["title_text"] = "Bouton d'options texte de FuBar",
       ["title_text_desc"] = "Afficher bouton d'options texte de FuBar.",

       ["mana"] = "Points Mana",
       ["health"] = "Points Vie",
       ["effective health"] = "Points Vie (Effectif)",

       -- Spam Strings
       [" ## VampwatchFu Stats:"] = " ## Statistiques VampwatchFu :",
       [" ## Vampiric Touch - Last Fight: "] = " ##  Toucher Vampirique - Dernier combat : ",
       [" ## Vampiric Touch - All Fights: "] = " ## Toucher Vampirique - Tous les combats : ",
       [" ## Vampiric Embrace - Last Fight: "] = " ##  Etreinte Vampirique - Dernier combat : ",
       [" ## Vampiric Embrace - All Fights: "] = " ## Etreinte Vampirique - Tous les combats : ",
       ["vwFu:: Vampiric Touch Total: "] = "vwFu:: Total Toucher Vampirique : ",
       [" Vampiric Embrace Total: "] = " Total Etreinte Vampirique : ",
       ["vwFu: Vampiric Embrace Ticks: "] ="vwFu: Ticks Etreinte Vampirique : ",
       [" Average Tick: "] = " Tick Moyen : ",
       [" Highest Tick: "] = " Tick Max : ",
       ["vwFu: Vampiric Touch Ticks: "] = "vwFu: Ticks Toucher Vampirique : ",
       ["vwFu: Vampiric Embrace Total: "] = "vwFu: Total Etreinte Vampirique : ",
       ["vwFu: Vampiric Touch Total: "] = "vwFu: Total Toucher Vampirique : ",
       ["vwFu: Vampiric Touch Last: "] = "vwFu: Dernier Toucher Vampirique : ",
       ["vwFu: Vampiric Embrace Last: "] = "vwFu: Dernier Etreinte Vampirique : ",
       ["vwFu: Shadowfiend Ticks: "] = "vwFu: Ticks Ombrefiel : ",
       ["vwFu: Shadowfiend Last: "] = "vwFu: Dernier Ombrefiel : ",
       ["vwFu: Shadowfiend Total: "] = "vwFu: Total Ombrefiel : ",

       ["vwFu: Shadowfiend Avg. Per Fight: "] = "vwFu: Moyenne par Combat Ombrefiel : ",
       ["vwFu: Vampiric Touch Avg. Per Fight: "] = "vwFu: Moyenne par Combat Toucher Vampirique : ",
       ["vwFu: Vampiric Embrace Avg. Per Fight: "] = "vwFu: Moyenne par Combat Etreinte Vampirique : ",

       ["FuBarHint"] = "\n|cffeda55fClic Gauche|r pour tout envoyer sur le canal.\n|cffeda55fClic gauche|r sur une stat pour envoyer sur le canal.\n|cffeda55fAlt-Clic gauche|r pour reset les totaux.\n|cffeda55fCtrl-Clic gauche|r pour reset toutes les stats.",

} end)