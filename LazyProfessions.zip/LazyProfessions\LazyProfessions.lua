-- Addon: LazyProfessions
-- Game Version: World of Warcraft 4.3.4 (Cataclysm)

local addonName, addonTable = ...
local LazyProfessions = CreateFrame("Frame", addonName)
LazyProfessions:RegisterEvent("PLAYER_LOGIN")
LazyProfessions:RegisterEvent("BAG_UPDATE")  -- Register BAG_UPDATE to monitor inventory changes

-- Function to check if an item has the "Prospectable" tag in its tooltip
local function IsOreProspectable(bag, slot)
    -- Create a tooltip frame
    local tooltip = CreateFrame("GameTooltip", "ProspectableTooltip", nil, "GameTooltipTemplate")
    tooltip:SetOwner(UIParent, "ANCHOR_NONE")
    tooltip:SetBagItem(bag, slot)

    -- Loop through the tooltip lines to find "Prospectable"
    for i = 1, tooltip:NumLines() do
        local line = _G["ProspectableTooltipTextLeft" .. i]:GetText()
        if line and string.find(line, "Prospectable") then
            return true  -- If "Prospectable" is found in the tooltip, the ore can be prospected
        end
    end
    return false
end

-- Function to scan inventory for prospectable ores with at least 5 in the stack
local function FindProspectableOres()
    for bag = 0, 4 do  -- Iterate over all bags
        for slot = 1, GetContainerNumSlots(bag) do
            local itemID = GetContainerItemID(bag, slot)
            local _, itemCount = GetContainerItemInfo(bag, slot)  -- Get stack count

            if itemID and itemCount >= 5 and IsOreProspectable(bag, slot) then
                return bag, slot  -- Return the bag and slot of the prospectable ore
            end
        end
    end
    return nil, nil  -- No ores found with sufficient stack size
end

-- Creating the main frame for LazyProfessions
local myFrame = CreateFrame("Frame", "LazyProfessionsFrame", UIParent, "BasicFrameTemplateWithInset")
myFrame:SetSize(700, 350)
myFrame:SetPoint("CENTER")
myFrame:EnableMouse(true)
myFrame:SetMovable(true)
myFrame:RegisterForDrag("LeftButton")
myFrame:SetScript("OnDragStart", myFrame.StartMoving)
myFrame:SetScript("OnDragStop", myFrame.StopMovingOrSizing)
myFrame:Hide()

myFrame.title = myFrame:CreateFontString(nil, "OVERLAY")
myFrame.title:SetFontObject("GameFontNormalLarge")
myFrame.title:SetPoint("TOPLEFT", myFrame, "TOPLEFT", 30, -30)
myFrame.title:SetText("Professions")

-- Creating a list for professions on the left side
local content = CreateFrame("Frame", nil, myFrame)
content:SetSize(150, 250)
content:SetPoint("TOPLEFT", myFrame, "TOPLEFT", 10, -60)

local professions = { "Mining", "Herbalism" }
local professionButtons = {}

for i, profession in ipairs(professions) do
    local button = CreateFrame("Button", nil, content)
    button:SetSize(130, 30)
    button:SetPoint("TOPLEFT", content, "TOPLEFT", 0, -((i - 1) * 35))
    button:SetText(profession)
    button:SetNormalFontObject("GameFontNormal")
    button:SetHighlightFontObject("GameFontHighlight")
    
    button:SetScript("OnClick", function()
        -- Reset all buttons to normal font color
        for _, btn in ipairs(professionButtons) do
            btn:SetNormalFontObject("GameFontNormal")
        end
        -- Highlight the selected button
        button:SetNormalFontObject("GameFontHighlight")
    
        -- Show the appropriate menu based on the selected profession
        if profession == "Mining" then
            LazyProfessions:ShowMiningMenu()
            LazyProfessions:HideHerbalismMenu()
            LazyProfessions:ShowAvailableOre()
        elseif profession == "Herbalism" then
            LazyProfessions:ShowHerbalismMenu()
            LazyProfessions:HideMiningMenu()
            LazyProfessions:ShowMillableHerbs()
        end
    
        -- Hide ore and herb lists when switching professions
        LazyProfessions:HideAllOre()
        LazyProfessions:HideAllHerbs()
    end)
    
    
    table.insert(professionButtons, button)
end

-- Creating the top menu for Mining
local miningMenu = CreateFrame("Frame", "MiningMenu", myFrame)
miningMenu:SetSize(400, 30)
miningMenu:SetPoint("TOPLEFT", content, "TOPRIGHT", 20, 5)
miningMenu:Hide()

-- Create the Prospect Ores button in the Mining tab
local prospectingSpellID = 31252  -- Prospecting spell ID
local oresAvailable = true   -- Track if ores are available for prospecting
local prospectingInProgress = false -- Track if prospecting is in progress

-- **Available Ore Button** (First button)
local availableOreButton = CreateFrame("Button", nil, miningMenu)
availableOreButton:SetPoint("LEFT", miningMenu, "LEFT", 10, 0)
availableOreButton:SetSize(140, 25)
availableOreButton:SetText("Prospectable Ore")
availableOreButton:SetNormalFontObject("GameFontNormal")
availableOreButton:SetHighlightFontObject("GameFontHighlight")

availableOreButton:SetScript("OnClick", function()
    LazyProfessions:HideAllOre()
    LazyProfessions:ShowAvailableOre()
end)

-- **View All Ore Button** (Second button, placed to the right of the Prospectable Ore button)
local viewAllOreButton = CreateFrame("Button", nil, miningMenu)
viewAllOreButton:SetPoint("LEFT", availableOreButton, "RIGHT", 10, 0)
viewAllOreButton:SetSize(140, 25)
viewAllOreButton:SetText("View All Ore")
viewAllOreButton:SetNormalFontObject("GameFontNormal")
viewAllOreButton:SetHighlightFontObject("GameFontHighlight")

viewAllOreButton:SetScript("OnClick", function()
    LazyProfessions:HideAllOre()
    LazyProfessions:ShowAllOre()
end)

-- **Prospect Ores Button** (Third button, placed to the right of the View All Ore button)
local prospectingButton = CreateFrame("Button", "SmartProspectingButton", miningMenu, "SecureActionButtonTemplate,UIPanelButtonTemplate")
prospectingButton:SetSize(120, 40)
prospectingButton:SetText("Prospect Ores")
prospectingButton:SetPoint("LEFT", viewAllOreButton, "RIGHT", 10, 0)  -- Placed to the right of the View All Ore button
prospectingButton:EnableMouse(true)

-- **Hotkey Button** (A small button next to Prospect Ores)
local hotkeyButton = CreateFrame("Button", nil, miningMenu, "UIPanelButtonTemplate")
hotkeyButton:SetSize(30, 30)  -- Small button size
hotkeyButton:SetText("KB")  -- Just "K" to indicate hotkey setup
hotkeyButton:SetPoint("LEFT", prospectingButton, "RIGHT", 10, 0)  -- Placed to the right of the "Prospect Ores" button

-- Show a popup when the Hotkey Button is clicked
hotkeyButton:SetScript("OnClick", function()
    LazyProfessions:ShowHotkeyAssignmentWindow()
end)

-- Function to show the Hotkey Assignment Window
function LazyProfessions:ShowHotkeyAssignmentWindow()
    if not self.hotkeyFrame then
        -- Create the frame for hotkey assignment
        self.hotkeyFrame = CreateFrame("Frame", "HotkeyAssignmentFrame", UIParent, "BasicFrameTemplateWithInset")
        self.hotkeyFrame:SetSize(300, 125)
        self.hotkeyFrame:SetPoint("CENTER")
        
        -- Set the highest strata and level for the popup window to overlay everything
        self.hotkeyFrame:SetFrameStrata("TOOLTIP")  -- Highest UI strata
        self.hotkeyFrame:SetFrameLevel(100)  -- Highest frame level to ensure priority
        
        -- Title for the window (adjusted Y offset for vertical centering)
        self.hotkeyFrame.title = self.hotkeyFrame:CreateFontString(nil, "OVERLAY")
        self.hotkeyFrame.title:SetFontObject("GameFontHighlight")
        self.hotkeyFrame.title:SetPoint("TOP", 0, -5)  -- Adjusted Y offset for better vertical centering
        self.hotkeyFrame.title:SetText("Set Hotkey for Prospecting")
        
        -- Instructional text below the title
        self.hotkeyFrame.instructions = self.hotkeyFrame:CreateFontString(nil, "OVERLAY")
        self.hotkeyFrame.instructions:SetFontObject("GameFontNormal")
        self.hotkeyFrame.instructions:SetPoint("TOP", 0, -40)  -- Position below the title
        self.hotkeyFrame.instructions:SetText("Press a key to assign it as a hotkey.")

        -- "Clear Hotkey" button to clear the current hotkey
        local clearHotkeyButton = CreateFrame("Button", nil, self.hotkeyFrame, "UIPanelButtonTemplate")
        clearHotkeyButton:SetSize(100, 25)
        clearHotkeyButton:SetPoint("CENTER", 0, -10)
        clearHotkeyButton:SetText("Clear Hotkey")
        clearHotkeyButton:SetScript("OnClick", function()
            LazyProfessions:ClearProspectingHotkey()  -- Call the function to clear the hotkey
            print("|cff00ff00[LazyProfessions]: Prospecting hotkey has been cleared.")
        end)

        -- Capture key presses for hotkey assignment
        self.hotkeyFrame:SetScript("OnKeyDown", function(self, key)
            LazyProfessions:SetProspectingHotkey(key)  -- Assign the key as hotkey
            print("|cff00ff00[LazyProfessions]: Hotkey assigned to: |cffffff00[" .. key .. "]|r")  -- Feedback in chat
            self:Hide()  -- Hide the window after assigning
        end)

        -- Ensure the frame captures input
        self.hotkeyFrame:SetPropagateKeyboardInput(false)
    end
    
    -- Show the hotkey assignment window
    self.hotkeyFrame:Show()
    print("|cff00ff00[LazyProfessions]: Please press a key to assign it as the hotkey for Prospecting or click 'Clear Hotkey' to remove. (This will prospect all ore regardless of type)")
end

-- Variable to store the assigned hotkey
local prospectingHotkey = nil

-- Function to set and store the hotkey (overwrites if already set)
function LazyProfessions:SetProspectingHotkey(key)
    if prospectingHotkey then
        print("|cffff0000[LazyProfessions]: Overwriting previous hotkey: |cffffff00[" .. prospectingHotkey .. "]|r")
    end
    prospectingHotkey = key
    -- Bind the key to the Prospect Ores button
    SetBinding(key, "CLICK SmartProspectingButton:LeftButton")
    SaveBindings(GetCurrentBindingSet())  -- Save the binding
    print("|cff00ff00[LazyProfessions]: New hotkey for Prospecting set to: |cffffff00[" .. key .. "]|r")
    -- Close the hotkey frame after setting the hotkey
    if LazyProfessions.hotkeyFrame then
        LazyProfessions.hotkeyFrame:Hide()
    end
end

-- Function to clear the hotkey if needed
function LazyProfessions:ClearProspectingHotkey()
    if prospectingHotkey then
        SetBinding(prospectingHotkey, nil)  -- Clear the hotkey binding
        SaveBindings(GetCurrentBindingSet())
        print("|cff00ff00[LazyProfessions]: Prospecting hotkey cleared.")
        prospectingHotkey = nil
    else
        print("|cffff0000[LazyProfessions]: No hotkey is currently assigned.")
    end
end

-- Remove moving functionality for the button
prospectingButton:EnableMouse(true)

-- Configure the button to use Prospecting and target the appropriate ore
prospectingButton:SetAttribute("type", "macro")

-- Function to update the button with the macro to prospect the ore
local function UpdateProspectingMacro()
    local bag, slot = FindProspectableOres()
    if bag and slot then
        -- Create a macro to prospect the specific ore in the found bag and slot
        local macroText = string.format("/cast Prospecting\n/use %d %d", bag, slot)
        prospectingButton:SetAttribute("macrotext", macroText)
        prospectingInProgress = true  -- Set flag to indicate prospecting is in progress
    else
        -- No prospectable ores found
        prospectingButton:SetAttribute("macrotext", "")
        print("No prospectable ores found.")
        oresAvailable = false  -- Set to false to stop checking for ores
        prospectingInProgress = false  -- No more prospecting is happening
    end
end

-- Function to keep triggering prospecting every second
local function ContinueProspectingProcess()
    C_Timer.After(1, function()
        if oresAvailable and prospectingInProgress then
            UpdateProspectingMacro()  -- Re-check and update macro every second
            prospectingButton:Click() -- Simulate the button click for the next action
        end
    end)
end

-- Ensure Auto Loot is enabled when prospecting
SetCVar("autoLootDefault", 1)

-- Update the button's macro when clicked, and start the automated process
prospectingButton:SetScript("PreClick", function()
    if oresAvailable then
        UpdateProspectingMacro()  -- Update the macro if ores are still available
        ContinueProspectingProcess()  -- Start the process
    end
end)

-- Ensure the button is visible when the UI loads
prospectingButton:Show()


function LazyProfessions:ShowMiningMenu()
    miningMenu:Show()  -- Ensure the mining menu is shown when selected
end

function LazyProfessions:HideMiningMenu()
    miningMenu:Hide()
    LazyProfessions:HideAllOre()
end

function LazyProfessions:ShowAvailableOre()
    -- Create a scrollable frame to display available ores in the player's inventory
    if not self.availableOreFrame then
        self.availableOreFrame = CreateFrame("ScrollFrame", "AvailableOreFrame", myFrame, "UIPanelScrollFrameTemplate")
        self.availableOreFrame:SetPoint("TOPLEFT", miningMenu, "BOTTOMLEFT", -20, -10)
        self.availableOreFrame:SetSize(500, 200)
        
        local availableOreContent = CreateFrame("Frame", nil, self.availableOreFrame)
        availableOreContent:SetSize(520, 800) -- Set a large height to allow scrolling
        self.availableOreFrame:SetScrollChild(availableOreContent)

        self.availableOreContent = availableOreContent
    end

    self:UpdateAvailableOreList()
    self.availableOreFrame:Show()
end

function LazyProfessions:UpdateAvailableOreList()
    if not self.availableOreContent then return end

    -- Clear existing ore buttons
    for _, child in ipairs({self.availableOreContent:GetChildren()}) do
        child:Hide()
    end

    local oreCounts = {}
    for bag = 0, 4 do
        for slot = 1, GetContainerNumSlots(bag) do
            local itemID = GetContainerItemID(bag, slot)
            local _, itemCount = GetContainerItemInfo(bag, slot)  -- Get stack count
            if itemID and itemCount >= 5 and self:IsItemProspectable(bag, slot) then
                local itemName, _, _, _, _, _, _, _, _, itemIcon = GetItemInfo(itemID)
                if itemName then
                    if not oreCounts[itemName] then
                        oreCounts[itemName] = { count = 0, icon = itemIcon, bag = bag, slot = slot }
                    end
                    oreCounts[itemName].count = oreCounts[itemName].count + itemCount
                end
            end
        end
    end

    local yOffset = -10
    for itemName, oreData in pairs(oreCounts) do
        local oreButton = CreateFrame("Button", nil, self.availableOreContent)
        oreButton:SetSize(460, 30)
        oreButton:SetPoint("TOPLEFT", self.availableOreContent, "TOPLEFT", 10, yOffset)
        
        local oreIcon = oreButton:CreateTexture(nil, "ARTWORK")
        oreIcon:SetSize(25, 25)
        oreIcon:SetPoint("LEFT", oreButton, "LEFT", 5, 0)
        oreIcon:SetTexture(oreData.icon)
        
        local oreLabel = oreButton:CreateFontString(nil, "OVERLAY")
        oreLabel:SetFontObject("GameFontNormal")
        oreLabel:SetPoint("LEFT", oreIcon, "RIGHT", 10, 0)
        oreLabel:SetText(itemName .. " x" .. oreData.count)

        -- Create a Prospect button next to each ore
        local prospectButton = CreateFrame("Button", "SmartProspectingButton" .. itemName, oreButton, "SecureActionButtonTemplate,UIPanelButtonTemplate")
        prospectButton:SetSize(80, 25)
        prospectButton:SetPoint("RIGHT", oreButton, "RIGHT", -10, 0)
        prospectButton:SetText("Prospect")

        -- Configure the button to use Prospecting and target the appropriate ore
        prospectButton:SetAttribute("type", "macro")

        -- Update the button's macro to prospect the selected ore
        local macroText = string.format("/cast Prospecting\n/use %d %d", oreData.bag, oreData.slot)
        prospectButton:SetAttribute("macrotext", macroText)

        -- Update the ore list after prospecting
        prospectButton:SetScript("PostClick", function()
            C_Timer.After(1, function()
                LazyProfessions:UpdateAvailableOreList()
            end)
        end)

        yOffset = yOffset - 35
    end
end

function LazyProfessions:IsItemProspectable(bag, slot)
    -- Create a tooltip frame to check if the item is prospectable
    local tooltip = CreateFrame("GameTooltip", "ProspectableTooltip", nil, "GameTooltipTemplate")
    tooltip:SetOwner(UIParent, "ANCHOR_NONE")
    tooltip:SetBagItem(bag, slot)

    -- Loop through the tooltip lines to find "Prospectable"
    for i = 1, tooltip:NumLines() do
        local line = _G["ProspectableTooltipTextLeft" .. i]:GetText()
        if line and string.find(line, "Prospectable") then
            return true  -- If "Prospectable" is found in the tooltip, the ore can be prospected
        end
    end
    return false
end

function LazyProfessions:ShowAllOre()
    -- Create a scrollable frame to display all ores
    if not self.oreListFrame then
        self.oreListFrame = CreateFrame("ScrollFrame", "OreListFrame", myFrame, "UIPanelScrollFrameTemplate")
        self.oreListFrame:SetPoint("TOPLEFT", miningMenu, "BOTTOMLEFT", -20, -10)
        self.oreListFrame:SetSize(500, 200)
        
        local oreContent = CreateFrame("Frame", nil, self.oreListFrame)
        oreContent:SetSize(520, 800) -- Set a large height to allow scrolling
        self.oreListFrame:SetScrollChild(oreContent)

        local ores = {
            { name = "Copper Ore", icon = "Interface/Icons/INV_Ore_Copper_01", level = 1, locations = "Durotar, Elwynn Forest" },
            { name = "Tin Ore", icon = "Interface/Icons/inv_ore_tin_01", level = 65, locations = "Hillsbrad Foothills, Westfall" },
            { name = "Silver Ore", icon = "Interface/Icons/item_pyriumore", level = 75, locations = "The Barrens, Ashenvale" },
            { name = "Gold Ore", icon = "Interface/Icons/inv_ore_gold_01", level = 115, locations = "Stranglethorn Vale, Arathi Highlands" },
            { name = "Iron Ore", icon = "Interface/Icons/inv_ore_iron_01", level = 125, locations = "Feralas, Alterac Mountains" },
            { name = "Mithril Ore", icon = "Interface/Icons/inv_ore_mithril_01", level = 175, locations = "Badlands, Hinterlands" },
            { name = "Truesilver Ore", icon = "Interface/Icons/inv_ore_truesilver_01", level = 230, locations = "Winterspring, Tanaris" },
            { name = "Thorium Ore", icon = "Interface/Icons/inv_ore_thorium_01", level = 250, locations = "Un'Goro Crater, Burning Steppes" },
            { name = "Fel Iron Ore", icon = "Interface/Icons/inv_ore_feliron", level = 275, locations = "Hellfire Peninsula, Zangarmarsh" },
            { name = "Adamantite Ore", icon = "Interface/Icons/INV_Ore_Adamantium_01", level = 325, locations = "Nagrand, Blade's Edge Mountains" },
            { name = "Khorium Ore", icon = "Interface/Icons/inv_ore_khorium", level = 375, locations = "Netherstorm, Shadowmoon Valley" },
            { name = "Eternium Ore", icon = "Interface/Icons/inv_ore_eternium", level = 350, locations = "Outland Zones" },
            { name = "Cobalt Ore", icon = "Interface/Icons/inv_ore_cobalt", level = 350, locations = "Howling Fjord, Borean Tundra" },
            { name = "Saronite Ore", icon = "Interface/Icons/inv_ore_saronite_01", level = 400, locations = "Icecrown, Sholazar Basin" },
            { name = "Titanium Ore", icon = "Interface/Icons/inv_ore_platinum_01", level = 450, locations = "Icecrown, Storm Peaks" },
            { name = "Obsidium Ore", icon = "Interface/Icons/inv_misc_pyriumore", level = 425, locations = "Mount Hyjal, Vashj'ir" },
            { name = "Elementium Ore", icon = "Interface/Icons/item_pyriumore", level = 475, locations = "Twilight Highlands, Deepholm" },
            { name = "Pyrite Ore", icon = "Interface/Icons/inv_ore_arcanite_01", level = 525, locations = "Uldum, Twilight Highlands" }
        }

        local yOffset = -10
        for _, ore in ipairs(ores) do
            local oreButton = CreateFrame("Button", nil, oreContent)
            oreButton:SetSize(460, 30)
            oreButton:SetPoint("TOPLEFT", oreContent, "TOPLEFT", 10, yOffset)
            
            local oreIcon = oreButton:CreateTexture(nil, "ARTWORK")
            oreIcon:SetSize(25, 25)
            oreIcon:SetPoint("LEFT", oreButton, "LEFT", 5, 0)
            oreIcon:SetTexture(ore.icon)
            
            local oreLabel = oreButton:CreateFontString(nil, "OVERLAY")
            oreLabel:SetFontObject("GameFontNormal")
            oreLabel:SetPoint("LEFT", oreIcon, "RIGHT", 10, 0)
            oreLabel:SetText(ore.name .. " (Level " .. ore.level .. ") - " .. ore.locations)

            yOffset = yOffset - 35
        end
    end
    self.oreListFrame:Show()
end

function LazyProfessions:HideAllOre()
    if self.oreListFrame then
        self.oreListFrame:Hide()
    end
    if self.availableOreFrame then
        self.availableOreFrame:Hide()
    end
end

--END MINING

--START HERBALISM

--Milling Spell ID
local millingSpellID = 51005  -- Milling spell ID
local herbsAvailable = true   -- Track if herbs are available for milling
local millingInProgress = false -- Track if milling is in progress


-- Add Herbalism to the professions list
local professions = { "Mining", "Herbalism" }
-- You can keep the Mining logic as is, and now we start focusing on Herbalism

-- Creating the top menu for Herbalism
local herbalismMenu = CreateFrame("Frame", "HerbalismMenu", myFrame)
herbalismMenu:SetSize(400, 30)
herbalismMenu:SetPoint("TOPLEFT", content, "TOPRIGHT", 20, 5)
herbalismMenu:Hide()

-- **Millable Herbs Button** (First button in Herbalism)
local millableHerbsButton = CreateFrame("Button", nil, herbalismMenu)
millableHerbsButton:SetPoint("LEFT", herbalismMenu, "LEFT", 10, 0)
millableHerbsButton:SetSize(140, 25)
millableHerbsButton:SetText("Millable Herbs")
millableHerbsButton:SetNormalFontObject("GameFontNormal")
millableHerbsButton:SetHighlightFontObject("GameFontHighlight")

millableHerbsButton:SetScript("OnClick", function()
    LazyProfessions:HideAllHerbs()
    LazyProfessions:ShowMillableHerbs()

end)

-- **View All Herbs Button** (Second button in Herbalism)
local viewAllHerbsButton = CreateFrame("Button", nil, herbalismMenu)
viewAllHerbsButton:SetPoint("LEFT", millableHerbsButton, "RIGHT", 10, 0)
viewAllHerbsButton:SetSize(140, 25)
viewAllHerbsButton:SetText("View All Herbs")
viewAllHerbsButton:SetNormalFontObject("GameFontNormal")
viewAllHerbsButton:SetHighlightFontObject("GameFontHighlight")

viewAllHerbsButton:SetScript("OnClick", function()
    LazyProfessions:HideAllHerbs()
    LazyProfessions:ShowAllHerbs()
end)

-- **Mill Herbs Button** (Similar to the Prospect Ores button)
local millHerbsButton = CreateFrame("Button", "SmartMillingButton", herbalismMenu, "SecureActionButtonTemplate,UIPanelButtonTemplate")
millHerbsButton:SetSize(120, 40)
millHerbsButton:SetText("Mill Herbs")
millHerbsButton:SetPoint("LEFT", viewAllHerbsButton, "RIGHT", 10, 0)
millHerbsButton:EnableMouse(true)

-- Set the button to cast Milling and use herbs
millHerbsButton:SetAttribute("type", "macro")

-- Function to update the button with the macro to mill the herbs
local function UpdateMillingMacro()
    local bag, slot = FindMillableHerbs()
    if bag and slot then
        -- Create a macro to mill the specific herb in the found bag and slot
        local macroText = string.format("/cast Milling\n/use %d %d", bag, slot)
        millHerbsButton:SetAttribute("macrotext", macroText)
        millingInProgress = true  -- Set flag to indicate milling is in progress
    else
        -- No millable herbs found
        millHerbsButton:SetAttribute("macrotext", "")
        print("No millable herbs found.")
        herbsAvailable = false  -- Set to false to stop checking for herbs
        millingInProgress = false  -- No more milling is happening
    end
end

-- Function to keep triggering milling every second
local function ContinueMillingProcess()
    C_Timer.After(1, function()
        if herbsAvailable and millingInProgress then
            UpdateMillingMacro()  -- Re-check and update macro every second
            millHerbsButton:Click()  -- Simulate the button click for the next action
        end
    end)
end

--- Update the button's macro when clicked, and start the automated milling process
millHerbsButton:SetScript("PreClick", function()
    if herbsAvailable then
        UpdateMillingMacro()  -- Update the macro if herbs are still available
        ContinueMillingProcess()  -- Start the process
    end
end)

-- Add the function to update the herb list after milling
millHerbsButton:SetScript("PostClick", function()
    C_Timer.After(1, function()  -- Use a small delay to let milling complete
        LazyProfessions:UpdateMillableHerbList()  -- Refresh the herb list after milling
    end)
end)


-- Ensure Auto Loot is enabled when milling
SetCVar("autoLootDefault", 1)


-- Show/Hide Herbalism Menu Functions
function LazyProfessions:ShowHerbalismMenu()
    herbalismMenu:Show()
end

function LazyProfessions:HideHerbalismMenu()
    herbalismMenu:Hide()
    LazyProfessions:HideAllHerbs()
end

-- Function to scan inventory for millable herbs with at least 5 in the stack
local function FindMillableHerbs()
    for bag = 0, 4 do  -- Iterate over all bags
        for slot = 1, GetContainerNumSlots(bag) do
            local itemID = GetContainerItemID(bag, slot)
            local _, itemCount = GetContainerItemInfo(bag, slot)  -- Get stack count

            -- Check if item is millable and if the stack size is enough
            if itemID and itemCount >= 5 and LazyProfessions:IsItemMillable(bag, slot) then
                return bag, slot  -- Return the bag and slot of the millable herb
            end
        end
    end
    return nil, nil  -- No millable herbs found
end

local function UpdateMillingMacro()
    local bag, slot = FindMillableHerbs()
    if bag and slot then
        -- Create a macro to mill the specific herb in the found bag and slot
        local macroText = string.format("/cast Milling\n/use %d %d", bag, slot)
        millHerbsButton:SetAttribute("macrotext", macroText)
        millingInProgress = true  -- Set flag to indicate milling is in progress
    else
        -- No millable herbs found
        millHerbsButton:SetAttribute("macrotext", "")
        print("No millable herbs found.")
        herbsAvailable = false  -- Set to false to stop checking for herbs
        millingInProgress = false  -- No more milling is happening
    end
end


local function ContinueMillingProcess()
    C_Timer.After(1, function()
        if herbsAvailable and millingInProgress then
            UpdateMillingMacro()  -- Re-check and update macro every second
            millHerbsButton:Click()  -- Simulate the button click for the next action
        end
    end)
end


-- Update the button's macro when clicked, and start the automated milling process
millHerbsButton:SetScript("PreClick", function()
    if herbsAvailable then
        UpdateMillingMacro()  -- Update the macro if herbs are still available
        ContinueMillingProcess()  -- Start the process
    end
end)

-- Add the function to update the herb list after milling
millHerbsButton:SetScript("PostClick", function()
    C_Timer.After(1, function()  -- Use a small delay to allow the milling process to complete
        LazyProfessions:UpdateMillableHerbList()  -- Refresh the herb list
    end)
end)



-- Functions to Show Available and Millable Herbs

function LazyProfessions:ShowMillableHerbs()
    -- Create a scrollable frame to display millable herbs in the player's inventory
    if not self.millableHerbFrame then
        self.millableHerbFrame = CreateFrame("ScrollFrame", "MillableHerbFrame", myFrame, "UIPanelScrollFrameTemplate")
        self.millableHerbFrame:SetPoint("TOPLEFT", herbalismMenu, "BOTTOMLEFT", -20, -10)
        self.millableHerbFrame:SetSize(500, 200)

        local herbContent = CreateFrame("Frame", nil, self.millableHerbFrame)
        herbContent:SetSize(520, 800) -- Set a large height to allow scrolling
        self.millableHerbFrame:SetScrollChild(herbContent)

        self.millableHerbContent = herbContent
    end

    self:UpdateMillableHerbList()
    self.millableHerbFrame:Show()
end

function LazyProfessions:UpdateMillableHerbList()
    if not self.millableHerbContent then return end

    -- Clear existing herb buttons
    for _, child in ipairs({self.millableHerbContent:GetChildren()}) do
        child:Hide()
    end

    local herbCounts = {}
    for bag = 0, 4 do
        for slot = 1, GetContainerNumSlots(bag) do
            local itemID = GetContainerItemID(bag, slot)
            local _, itemCount = GetContainerItemInfo(bag, slot)
            if itemID and itemCount >= 5 and self:IsItemMillable(bag, slot) then
                local itemName, _, _, _, _, _, _, _, _, itemIcon = GetItemInfo(itemID)
                if itemName then
                    if not herbCounts[itemName] then
                        herbCounts[itemName] = { count = 0, icon = itemIcon, bag = bag, slot = slot }
                    end
                    herbCounts[itemName].count = herbCounts[itemName].count + itemCount
                end
            end
        end
    end

    local yOffset = -10
    for itemName, herbData in pairs(herbCounts) do
        local herbButton = CreateFrame("Button", nil, self.millableHerbContent)
        herbButton:SetSize(460, 30)
        herbButton:SetPoint("TOPLEFT", self.millableHerbContent, "TOPLEFT", 10, yOffset)

        local herbIcon = herbButton:CreateTexture(nil, "ARTWORK")
        herbIcon:SetSize(25, 25)
        herbIcon:SetPoint("LEFT", herbButton, "LEFT", 5, 0)
        herbIcon:SetTexture(herbData.icon)

        local herbLabel = herbButton:CreateFontString(nil, "OVERLAY")
        herbLabel:SetFontObject("GameFontNormal")
        herbLabel:SetPoint("LEFT", herbIcon, "RIGHT", 10, 0)
        herbLabel:SetText(itemName .. " x" .. herbData.count)

        -- Create a Mill button next to each herb
local millButton = CreateFrame("Button", "SmartMillingButton" .. itemName, herbButton, "SecureActionButtonTemplate,UIPanelButtonTemplate")
millButton:SetSize(80, 25)
millButton:SetPoint("RIGHT", herbButton, "RIGHT", -10, 0)
millButton:SetText("Mill")

-- Configure the button to use Milling and target the appropriate herb
millButton:SetAttribute("type", "macro")
local macroText = string.format("/cast Milling\n/use %d %d", herbData.bag, herbData.slot)
millButton:SetAttribute("macrotext", macroText)

-- Update the herb list after milling
millButton:SetScript("PostClick", function()
    C_Timer.After(1, function()  -- Use a small delay to let milling complete
        LazyProfessions:UpdateMillableHerbList()  -- Refresh the herb list after milling
    end)
end)



        yOffset = yOffset - 35
    end
end

-- Herb data similar to ore data
local herbs = {
    { name = "Peacebloom", icon = "Interface/Icons/inv_misc_flower_02", level = 1, locations = "Elwynn Forest, Durotar" },
    { name = "Silverleaf", icon = "Interface/Icons/inv_misc_herb_10", level = 1, locations = "Teldrassil, Mulgore" },
    { name = "Earthroot", icon = "Interface/Icons/inv_misc_herb_07", level = 15, locations = "Elwynn Forest, Dun Morogh" },
    { name = "Mageroyal", icon = "Interface/Icons/inv_jewelry_talisman_03", level = 50, locations = "Westfall, Barrens" },
    { name = "Briarthorn", icon = "Interface/Icons/inv_misc_root_01", level = 70, locations = "Silverpine Forest, Hillsbrad" },
    { name = "Bruiseweed", icon = "Interface/Icons/inv_misc_herb_01", level = 100, locations = "Ashenvale, Stonetalon" },
    { name = "Wild Steelbloom", icon = "Interface/Icons/inv_misc_flower_01", level = 115, locations = "Stranglethorn Vale, Arathi Highlands" },
    { name = "Kingsblood", icon = "Interface/Icons/inv_misc_herb_03", level = 125, locations = "Alterac Mountains, Wetlands" },
    { name = "Liferoot", icon = "Interface/Icons/inv_misc_root_02", level = 150, locations = "Swamp of Sorrows, Wetlands" },
    { name = "Fadeleaf", icon = "Interface/Icons/inv_misc_herb_12", level = 160, locations = "Stranglethorn Vale, Swamp of Sorrows" },
    { name = "Goldthorn", icon = "Interface/Icons/inv_misc_herb_15", level = 170, locations = "Hinterlands, Arathi Highlands" },
    { name = "Khadgar's Whisker", icon = "Interface/Icons/inv_misc_herb_08", level = 185, locations = "Feralas, Hinterlands" },
    { name = "Firebloom", icon = "Interface/Icons/inv_misc_herb_19", level = 205, locations = "Searing Gorge, Badlands" },
    { name = "Purple Lotus", icon = "Interface/Icons/inv_misc_herb_17", level = 210, locations = "Felwood, Burning Steppes" },
    { name = "Sungrass", icon = "Interface/Icons/inv_misc_herb_18", level = 230, locations = "Eastern Plaguelands, Feralas" },
    { name = "Gromsblood", icon = "Interface/Icons/inv_misc_herb_16", level = 250, locations = "Blasted Lands, Felwood" },
    { name = "Dreamfoil", icon = "Interface/Icons/INV_Misc_Herb_Dreamfoil", level = 270, locations = "Silithus, Un'Goro Crater" },
    { name = "Plaguebloom", icon = "Interface/Icons/INV_Misc_Herb_Plaguebloom", level = 285, locations = "Eastern Plaguelands, Western Plaguelands" },
    { name = "Icecap", icon = "Interface/Icons/INV_Misc_Herb_IceCap", level = 290, locations = "Winterspring" },
    { name = "Black Lotus", icon = "Interface/Icons/INV_Misc_Herb_BlackLotus", level = 300, locations = "Eastern Plaguelands, Winterspring" },
    { name = "Felweed", icon = "Interface/Icons/INV_Misc_Herb_Felweed", level = 300, locations = "Hellfire Peninsula, Zangarmarsh" },
    { name = "Dreaming Glory", icon = "Interface/Icons/INV_Misc_Herb_DreamingGlory", level = 315, locations = "Nagrand, Terokkar Forest" },
    { name = "Terocone", icon = "Interface/Icons/inv_misc_herb_terrocone", level = 325, locations = "Terokkar Forest" },
    { name = "Netherbloom", icon = "Interface/Icons/INV_Misc_Herb_Netherbloom", level = 350, locations = "Netherstorm, Blade's Edge Mountains" },
    { name = "Goldclover", icon = "Interface/Icons/INV_Misc_Herb_Goldclover", level = 375, locations = "Howling Fjord, Borean Tundra" },
    { name = "Tiger Lily", icon = "Interface/Icons/INV_Misc_Herb_Tigerlily", level = 400, locations = "Sholazar Basin, Grizzly Hills" },
    { name = "Adder's Tongue", icon = "Interface/Icons/inv_misc_herb_evergreenmoss", level = 415, locations = "Sholazar Basin" },
    { name = "Lichbloom", icon = "Interface/Icons/inv_misc_herb_whispervine", level = 425, locations = "Icecrown" },
    { name = "Twilight Jasmine", icon = "Interface/Icons/INV_Misc_Herb_TwilightJasmine", level = 475, locations = "Twilight Highlands, Deepholm" },
    { name = "Azshara's Veil", icon = "Interface/Icons/INV_Misc_Herb_AzsharasVeil", level = 425, locations = "Vashj'ir" },
    { name = "Cinderbloom", icon = "Interface/Icons/INV_Misc_Herb_Cinderbloom", level = 425, locations = "Mount Hyjal, Deepholm" },
    { name = "Stormvine", icon = "Interface/Icons/INV_Misc_Herb_Stormvine", level = 425, locations = "Mount Hyjal, Twilight Highlands" },
    { name = "Heartblossom", icon = "Interface/Icons/INV_Misc_Herb_Heartblossom", level = 475, locations = "Deepholm" },
    { name = "Whiptail", icon = "Interface/Icons/INV_Misc_Herb_Whiptail", level = 500, locations = "Uldum, Tol Barad" }
}


-- Function to show all available herbs in the herbalism tab
function LazyProfessions:ShowAllHerbs()
    -- Create a scrollable frame to display all herbs
    if not self.herbListFrame then
        self.herbListFrame = CreateFrame("ScrollFrame", "HerbListFrame", myFrame, "UIPanelScrollFrameTemplate")
        self.herbListFrame:SetPoint("TOPLEFT", herbalismMenu, "BOTTOMLEFT", -20, -10)
        self.herbListFrame:SetSize(500, 200)

        local herbContent = CreateFrame("Frame", nil, self.herbListFrame)
        herbContent:SetSize(520, 800) -- Set a large height to allow scrolling
        self.herbListFrame:SetScrollChild(herbContent)

        self.herbContent = herbContent
    end

    self:UpdateHerbList()
    self.herbListFrame:Show()
end

-- Function to update the herb list
function LazyProfessions:UpdateHerbList()
    if not self.herbContent then return end

    -- Clear existing herb buttons
    for _, child in ipairs({self.herbContent:GetChildren()}) do
        child:Hide()
    end

    local yOffset = -10
    for _, herb in ipairs(herbs) do
        local herbButton = CreateFrame("Button", nil, self.herbContent)
        herbButton:SetSize(460, 30)
        herbButton:SetPoint("TOPLEFT", self.herbContent, "TOPLEFT", 10, yOffset)

        local herbIcon = herbButton:CreateTexture(nil, "ARTWORK")
        herbIcon:SetSize(25, 25)
        herbIcon:SetPoint("LEFT", herbButton, "LEFT", 5, 0)
        herbIcon:SetTexture(herb.icon)

        local herbLabel = herbButton:CreateFontString(nil, "OVERLAY")
        herbLabel:SetFontObject("GameFontNormal")
        herbLabel:SetPoint("LEFT", herbIcon, "RIGHT", 10, 0)
        herbLabel:SetText(herb.name .. " (Level " .. herb.level .. ") - " .. herb.locations)

        yOffset = yOffset - 35
    end
end

-- Hide the herb list when switching tabs
function LazyProfessions:HideAllHerbs()
    if self.herbListFrame then
        self.herbListFrame:Hide()
    end
    if self.millableHerbFrame then
        self.millableHerbFrame:Hide()
    end
end


function LazyProfessions:HideAllHerbs()
    if self.herbListFrame then
        self.herbListFrame:Hide()
    end
    if self.millableHerbFrame then
        self.millableHerbFrame:Hide()
    end
end

-- IsItemMillable Function (similar to IsOreProspectable)
function LazyProfessions:IsItemMillable(bag, slot)
    -- Create a tooltip frame to check if the item is millable
    local tooltip = CreateFrame("GameTooltip", "MillableTooltip", nil, "GameTooltipTemplate")
    tooltip:SetOwner(UIParent, "ANCHOR_NONE")
    tooltip:SetBagItem(bag, slot)

    -- Loop through the tooltip lines to find "Millable"
    for i = 1, tooltip:NumLines() do
        local line = _G["MillableTooltipTextLeft" .. i]:GetText()
        if line and string.find(line, "Millable") then
            return true  -- If "Millable" is found in the tooltip, the herb can be milled
        end
    end
    return false
end


-- Create the Mill Herbs Keybind Button (Next to the Mill Herbs button)
local millHerbsHotkeyButton = CreateFrame("Button", nil, herbalismMenu, "UIPanelButtonTemplate")
millHerbsHotkeyButton:SetSize(30, 30)  -- Small button size
millHerbsHotkeyButton:SetText("KB")  -- Just "K" to indicate hotkey setup
millHerbsHotkeyButton:SetPoint("LEFT", millHerbsButton, "RIGHT", 10, 0)  -- Placed to the right of the "Mill Herbs" button

-- Show a popup when the Mill Herbs Hotkey Button is clicked
millHerbsHotkeyButton:SetScript("OnClick", function()
    LazyProfessions:ShowMillingHotkeyAssignmentWindow()
end)

-- Function to show the Hotkey Assignment Window for Milling
function LazyProfessions:ShowMillingHotkeyAssignmentWindow()
    if not self.millingHotkeyFrame then
        -- Create the frame for hotkey assignment
        self.millingHotkeyFrame = CreateFrame("Frame", "MillingHotkeyAssignmentFrame", UIParent, "BasicFrameTemplateWithInset")
        self.millingHotkeyFrame:SetSize(300, 125)
        self.millingHotkeyFrame:SetPoint("CENTER")
        
        -- Set the highest strata and level for the popup window to overlay everything
        self.millingHotkeyFrame:SetFrameStrata("TOOLTIP")  -- Highest UI strata
        self.millingHotkeyFrame:SetFrameLevel(100)  -- Highest frame level to ensure priority
        
        -- Title for the window (adjusted Y offset for vertical centering)
        self.millingHotkeyFrame.title = self.millingHotkeyFrame:CreateFontString(nil, "OVERLAY")
        self.millingHotkeyFrame.title:SetFontObject("GameFontHighlight")
        self.millingHotkeyFrame.title:SetPoint("TOP", 0, -5)  -- Adjusted Y offset for better vertical centering
        self.millingHotkeyFrame.title:SetText("Set Hotkey for Milling")
        
        -- Instructional text below the title
        self.millingHotkeyFrame.instructions = self.millingHotkeyFrame:CreateFontString(nil, "OVERLAY")
        self.millingHotkeyFrame.instructions:SetFontObject("GameFontNormal")
        self.millingHotkeyFrame.instructions:SetPoint("TOP", 0, -40)  -- Position below the title
        self.millingHotkeyFrame.instructions:SetText("Press a key to assign it as a hotkey.")

        -- "Clear Hotkey" button to clear the current hotkey
        local clearMillingHotkeyButton = CreateFrame("Button", nil, self.millingHotkeyFrame, "UIPanelButtonTemplate")
        clearMillingHotkeyButton:SetSize(100, 25)
        clearMillingHotkeyButton:SetPoint("CENTER", 0, -10)
        clearMillingHotkeyButton:SetText("Clear Hotkey")
        clearMillingHotkeyButton:SetScript("OnClick", function()
            LazyProfessions:ClearMillingHotkey()  -- Call the function to clear the milling hotkey
            print("|cff00ff00[LazyProfessions]: Milling hotkey has been cleared.")
        end)

        -- Capture key presses for milling hotkey assignment
        self.millingHotkeyFrame:SetScript("OnKeyDown", function(self, key)
            LazyProfessions:SetMillingHotkey(key)  -- Assign the key as hotkey for Milling
            print("|cff00ff00[LazyProfessions]: Hotkey assigned to: |cffffff00[" .. key .. "]|r")  -- Feedback in chat
            self:Hide()  -- Hide the window after assigning
        end)

        -- Ensure the frame captures input
        self.millingHotkeyFrame:SetPropagateKeyboardInput(false)
    end
    
    -- Show the hotkey assignment window for Milling
    self.millingHotkeyFrame:Show()
    print("|cff00ff00[LazyProfessions]: Please press a key to assign it as the hotkey for Milling or click 'Clear Hotkey' to remove. (This will mill all herbs regardless of type)")
end

-- Variable to store the assigned milling hotkey
local millingHotkey = nil

-- Function to set and store the hotkey for Milling (overwrites if already set)
function LazyProfessions:SetMillingHotkey(key)
    if millingHotkey then
        print("|cffff0000[LazyProfessions]: Overwriting previous milling hotkey: |cffffff00[" .. millingHotkey .. "]|r")
    end
    millingHotkey = key
    -- Bind the key to the Mill Herbs button
    SetBinding(key, "CLICK SmartMillingButton:LeftButton")
    SaveBindings(GetCurrentBindingSet())  -- Save the binding
    print("|cff00ff00[LazyProfessions]: New hotkey for Milling set to: |cffffff00[" .. key .. "]|r")
    -- Close the hotkey frame after setting the hotkey
    if LazyProfessions.millingHotkeyFrame then
        LazyProfessions.millingHotkeyFrame:Hide()
    end
end

-- Function to clear the hotkey for Milling if needed
function LazyProfessions:ClearMillingHotkey()
    if millingHotkey then
        SetBinding(millingHotkey, nil)  -- Clear the milling hotkey binding
        SaveBindings(GetCurrentBindingSet())
        print("|cff00ff00[LazyProfessions]: Milling hotkey cleared.")
        millingHotkey = nil
    else
        print("|cffff0000[LazyProfessions]: No hotkey is currently assigned for Milling.")
    end
end



-- Event handler function for player login and bag updates
LazyProfessions:SetScript("OnEvent", function(self, event, ...)
    if event == "PLAYER_LOGIN" then
        self:OnPlayerLogin()
    elseif event == "BAG_UPDATE" then
        -- Update prospectable ores if the mining frame is shown
        if myFrame:IsShown() and self.availableOreFrame and self.availableOreFrame:IsShown() then
            self:UpdateAvailableOreList()
        end

        -- Update millable herbs if the herbalism frame is shown
        if myFrame:IsShown() and self.millableHerbFrame and self.millableHerbFrame:IsShown() then
            self:UpdateMillableHerbList()
        end
    end
end)


function LazyProfessions:OnPlayerLogin()
    -- Example of creating a simple slash command
    SLASH_LAZYPROFESSIONS1 = "/lazyprof"
    SlashCmdList["LAZYPROFESSIONS"] = function(msg)
        LazyProfessions:ToggleFrame()
    end
end

function LazyProfessions:ToggleFrame()
    if myFrame:IsShown() then
        myFrame:Hide()
    else
        myFrame:Show()
    end
end
