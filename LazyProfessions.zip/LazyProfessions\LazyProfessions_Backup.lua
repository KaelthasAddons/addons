-- Addon: LazyProfessions
-- Game Version: World of Warcraft 4.3.4 (Cataclysm)

local addonName, addonTable = ...
local LazyProfessions = CreateFrame("Frame", addonName)
LazyProfessions:RegisterEvent("PLAYER_LOGIN")
LazyProfessions:RegisterEvent("BAG_UPDATE")  -- Register BAG_UPDATE to monitor inventory changes

-- Function to check if an item has the "Prospectable" tag in its tooltip
local function IsOreProspectable(bag, slot)
    -- Create a tooltip frame
    local tooltip = CreateFrame("GameTooltip", "ProspectableTooltip", nil, "GameTooltipTemplate")
    tooltip:SetOwner(UIParent, "ANCHOR_NONE")
    tooltip:SetBagItem(bag, slot)

    -- Loop through the tooltip lines to find "Prospectable"
    for i = 1, tooltip:NumLines() do
        local line = _G["ProspectableTooltipTextLeft" .. i]:GetText()
        if line and string.find(line, "Prospectable") then
            return true  -- If "Prospectable" is found in the tooltip, the ore can be prospected
        end
    end
    return false
end

-- Function to scan inventory for prospectable ores with at least 5 in the stack
local function FindProspectableOres()
    for bag = 0, 4 do  -- Iterate over all bags
        for slot = 1, GetContainerNumSlots(bag) do
            local itemID = GetContainerItemID(bag, slot)
            local _, itemCount = GetContainerItemInfo(bag, slot)  -- Get stack count

            if itemID and itemCount >= 5 and IsOreProspectable(bag, slot) then
                return bag, slot  -- Return the bag and slot of the prospectable ore
            end
        end
    end
    return nil, nil  -- No ores found with sufficient stack size
end

-- Creating the main frame for LazyProfessions
local myFrame = CreateFrame("Frame", "LazyProfessionsFrame", UIParent, "BasicFrameTemplateWithInset")
myFrame:SetSize(700, 400)
myFrame:SetPoint("CENTER")
myFrame:EnableMouse(true)
myFrame:SetMovable(true)
myFrame:RegisterForDrag("LeftButton")
myFrame:SetScript("OnDragStart", myFrame.StartMoving)
myFrame:SetScript("OnDragStop", myFrame.StopMovingOrSizing)
myFrame:Hide()

myFrame.title = myFrame:CreateFontString(nil, "OVERLAY")
myFrame.title:SetFontObject("GameFontNormalLarge")
myFrame.title:SetPoint("TOPLEFT", myFrame, "TOPLEFT", 30, -30)
myFrame.title:SetText("Professions")

-- Creating a list for professions on the left side
local content = CreateFrame("Frame", nil, myFrame)
content:SetSize(150, 250)
content:SetPoint("TOPLEFT", myFrame, "TOPLEFT", 10, -60)

local professions = { "Mining", "Herbalism" }
local professionButtons = {}

for i, profession in ipairs(professions) do
    local button = CreateFrame("Button", nil, content)
    button:SetSize(130, 30)
    button:SetPoint("TOPLEFT", content, "TOPLEFT", 0, -((i - 1) * 35))
    button:SetText(profession)
    button:SetNormalFontObject("GameFontNormal")
    button:SetHighlightFontObject("GameFontHighlight")
    
    button:SetScript("OnClick", function()
        -- Reset all buttons to normal font color
        for _, btn in ipairs(professionButtons) do
            btn:SetNormalFontObject("GameFontNormal")
        end
        -- Highlight the selected button
        button:SetNormalFontObject("GameFontHighlight")
        print(profession .. " selected!")

        -- Show top menu if Mining is selected, hide otherwise
        if profession == "Mining" then
            LazyProfessions:ShowMiningMenu()
            LazyProfessions:ShowAvailableOre()
        else
            LazyProfessions:HideMiningMenu()
        end

        -- Hide ore list when switching professions
        LazyProfessions:HideAllOre()
    end)
    
    table.insert(professionButtons, button)
end

-- Creating the top menu for Mining
local miningMenu = CreateFrame("Frame", "MiningMenu", myFrame)
miningMenu:SetSize(400, 30)
miningMenu:SetPoint("TOPLEFT", content, "TOPRIGHT", 20, 5)
miningMenu:Hide()

-- Create the Prospect Ores button in the Mining tab
local prospectingSpellID = 31252  -- Prospecting spell ID
local oresAvailable = true   -- Track if ores are available for prospecting
local prospectingInProgress = false -- Track if prospecting is in progress

-- **Available Ore Button** (First button)
local availableOreButton = CreateFrame("Button", nil, miningMenu)
availableOreButton:SetPoint("LEFT", miningMenu, "LEFT", 10, 0)
availableOreButton:SetSize(140, 25)
availableOreButton:SetText("Prospectable Ore")
availableOreButton:SetNormalFontObject("GameFontNormal")
availableOreButton:SetHighlightFontObject("GameFontHighlight")

availableOreButton:SetScript("OnClick", function()
    LazyProfessions:HideAllOre()
    LazyProfessions:ShowAvailableOre()
    print("Prospectable Ore selected!")
end)

-- **View All Ore Button** (Second button, placed to the right of the Prospectable Ore button)
local viewAllOreButton = CreateFrame("Button", nil, miningMenu)
viewAllOreButton:SetPoint("LEFT", availableOreButton, "RIGHT", 10, 0)
viewAllOreButton:SetSize(140, 25)
viewAllOreButton:SetText("View All Ore")
viewAllOreButton:SetNormalFontObject("GameFontNormal")
viewAllOreButton:SetHighlightFontObject("GameFontHighlight")

viewAllOreButton:SetScript("OnClick", function()
    LazyProfessions:HideAllOre()
    LazyProfessions:ShowAllOre()
    print("View All Ore selected!")
end)

-- **Prospect Ores Button** (Third button, placed to the right of the View All Ore button)
local prospectingButton = CreateFrame("Button", "SmartProspectingButton", miningMenu, "UIPanelButtonTemplate")
prospectingButton:SetSize(120, 40)
prospectingButton:SetText("Prospect Ores")
prospectingButton:SetPoint("LEFT", viewAllOreButton, "RIGHT", 10, 0)  -- Placed to the right of the View All Ore button
prospectingButton:Show()  -- Make sure the button is shown

-- **Hotkey Button** (Added to the right of the Prospect Ores button)
local hotkeyButton = CreateFrame("Button", nil, miningMenu, "UIPanelButtonTemplate")
hotkeyButton:SetSize(60, 40)  -- Small button size to fit next to Prospect Ores
hotkeyButton:SetText("Hotkey")  -- Button label
hotkeyButton:SetPoint("LEFT", prospectingButton, "RIGHT", 10, 0)  -- Placed to the right of the "Prospect Ores" button
hotkeyButton:Show()  -- Make sure the button is shown

-- Show a popup when the Hotkey Button is clicked
hotkeyButton:SetScript("OnClick", function()
    LazyProfessions:ShowHotkeyAssignmentWindow()
end)


-- Function to show the Hotkey Assignment Window
function LazyProfessions:ShowHotkeyAssignmentWindow()
    if not self.hotkeyFrame then
        -- Create the frame for hotkey assignment
        self.hotkeyFrame = CreateFrame("Frame", "HotkeyAssignmentFrame", UIParent, "BasicFrameTemplateWithInset")
        self.hotkeyFrame:SetSize(300, 150)
        self.hotkeyFrame:SetPoint("CENTER")
        
        -- Title for the window
        self.hotkeyFrame.title = self.hotkeyFrame:CreateFontString(nil, "OVERLAY")
        self.hotkeyFrame.title:SetFontObject("GameFontHighlight")
        self.hotkeyFrame.title:SetPoint("TOP", 0, -10)
        self.hotkeyFrame.title:SetText("Set Hotkey for Prospecting")

        -- Instructions text
        local instructions = self.hotkeyFrame:CreateFontString(nil, "OVERLAY")
        instructions:SetFontObject("GameFontNormal")
        instructions:SetPoint("TOP", 0, -40)
        instructions:SetText("Press a key to assign it as a hotkey.")

        -- Capture key presses for hotkey assignment
        self.hotkeyFrame:SetScript("OnKeyDown", function(self, key)
            LazyProfessions:SetProspectingHotkey(key)  -- Assign the key as hotkey
            self:Hide()  -- Hide the window after assigning
            print("Assigned hotkey:", key)
        end)

        -- Ensure the frame captures input
        self.hotkeyFrame:SetPropagateKeyboardInput(false)
    end

    self.hotkeyFrame:Show()
end

-- Variable to store the assigned hotkey
local prospectingHotkey = nil

-- Function to set and store the hotkey
function LazyProfessions:SetProspectingHotkey(key)
    prospectingHotkey = key
    -- Bind the key to the Prospect Ores button
    SetBinding(key, "CLICK SmartProspectingButton:LeftButton")
    SaveBindings(GetCurrentBindingSet())  -- Save the binding
    print("Prospecting hotkey set to:", key)
end



-- Remove moving functionality for the button
prospectingButton:EnableMouse(true)

-- Configure the button to use Prospecting and target the appropriate ore
prospectingButton:SetAttribute("type", "macro")

-- Function to update the button with the macro to prospect the ore
local function UpdateProspectingMacro()
    local bag, slot = FindProspectableOres()
    if bag and slot then
        -- Create a macro to prospect the specific ore in the found bag and slot
        local macroText = string.format("/cast Prospecting\n/use %d %d", bag, slot)
        prospectingButton:SetAttribute("macrotext", macroText)
        prospectingInProgress = true  -- Set flag to indicate prospecting is in progress
    else
        -- No prospectable ores found
        prospectingButton:SetAttribute("macrotext", "")
        print("No prospectable ores found.")
        oresAvailable = false  -- Set to false to stop checking for ores
        prospectingInProgress = false  -- No more prospecting is happening
    end
end

-- Function to keep triggering prospecting every second
local function ContinueProspectingProcess()
    C_Timer.After(1, function()
        if oresAvailable and prospectingInProgress then
            UpdateProspectingMacro()  -- Re-check and update macro every second
            prospectingButton:Click() -- Simulate the button click for the next action
        end
    end)
end

-- Ensure Auto Loot is enabled when prospecting
SetCVar("autoLootDefault", 1)

-- Update the button's macro when clicked, and start the automated process
prospectingButton:SetScript("PreClick", function()
    if oresAvailable then
        UpdateProspectingMacro()  -- Update the macro if ores are still available
        ContinueProspectingProcess()  -- Start the process
    end
end)

-- Ensure the button is visible when the UI loads
prospectingButton:Show()


function LazyProfessions:ShowMiningMenu()
    miningMenu:Show()  -- Ensure the mining menu is shown when selected
end

function LazyProfessions:HideMiningMenu()
    miningMenu:Hide()
    LazyProfessions:HideAllOre()
end

function LazyProfessions:ShowAvailableOre()
    -- Create a scrollable frame to display available ores in the player's inventory
    if not self.availableOreFrame then
        self.availableOreFrame = CreateFrame("ScrollFrame", "AvailableOreFrame", myFrame, "UIPanelScrollFrameTemplate")
        self.availableOreFrame:SetPoint("TOPLEFT", miningMenu, "BOTTOMLEFT", -20, -10)
        self.availableOreFrame:SetSize(500, 200)
        
        local availableOreContent = CreateFrame("Frame", nil, self.availableOreFrame)
        availableOreContent:SetSize(520, 800) -- Set a large height to allow scrolling
        self.availableOreFrame:SetScrollChild(availableOreContent)

        self.availableOreContent = availableOreContent
    end

    self:UpdateAvailableOreList()
    self.availableOreFrame:Show()
end

function LazyProfessions:UpdateAvailableOreList()
    if not self.availableOreContent then return end

    -- Clear existing ore buttons
    for _, child in ipairs({self.availableOreContent:GetChildren()}) do
        child:Hide()
    end

    local oreCounts = {}
    for bag = 0, 4 do
        for slot = 1, GetContainerNumSlots(bag) do
            local itemID = GetContainerItemID(bag, slot)
            local _, itemCount = GetContainerItemInfo(bag, slot)  -- Get stack count
            if itemID and itemCount >= 5 and self:IsItemProspectable(bag, slot) then
                local itemName, _, _, _, _, _, _, _, _, itemIcon = GetItemInfo(itemID)
                if itemName then
                    if not oreCounts[itemName] then
                        oreCounts[itemName] = { count = 0, icon = itemIcon, bag = bag, slot = slot }
                    end
                    oreCounts[itemName].count = oreCounts[itemName].count + itemCount
                end
            end
        end
    end

    local yOffset = -10
    for itemName, oreData in pairs(oreCounts) do
        local oreButton = CreateFrame("Button", nil, self.availableOreContent)
        oreButton:SetSize(460, 30)
        oreButton:SetPoint("TOPLEFT", self.availableOreContent, "TOPLEFT", 10, yOffset)
        
        local oreIcon = oreButton:CreateTexture(nil, "ARTWORK")
        oreIcon:SetSize(25, 25)
        oreIcon:SetPoint("LEFT", oreButton, "LEFT", 5, 0)
        oreIcon:SetTexture(oreData.icon)
        
        local oreLabel = oreButton:CreateFontString(nil, "OVERLAY")
        oreLabel:SetFontObject("GameFontNormal")
        oreLabel:SetPoint("LEFT", oreIcon, "RIGHT", 10, 0)
        oreLabel:SetText(itemName .. " x" .. oreData.count)

        -- Create a Prospect button next to each ore
        local prospectButton = CreateFrame("Button", "SmartProspectingButton" .. itemName, oreButton, "SecureActionButtonTemplate,UIPanelButtonTemplate")
        prospectButton:SetSize(80, 25)
        prospectButton:SetPoint("RIGHT", oreButton, "RIGHT", -10, 0)
        prospectButton:SetText("Prospect")

        -- Configure the button to use Prospecting and target the appropriate ore
        prospectButton:SetAttribute("type", "macro")

        -- Update the button's macro to prospect the selected ore
        local macroText = string.format("/cast Prospecting\n/use %d %d", oreData.bag, oreData.slot)
        prospectButton:SetAttribute("macrotext", macroText)

        -- Update the ore list after prospecting
        prospectButton:SetScript("PostClick", function()
            C_Timer.After(1, function()
                LazyProfessions:UpdateAvailableOreList()
            end)
        end)

        yOffset = yOffset - 35
    end
end

function LazyProfessions:IsItemProspectable(bag, slot)
    -- Create a tooltip frame to check if the item is prospectable
    local tooltip = CreateFrame("GameTooltip", "ProspectableTooltip", nil, "GameTooltipTemplate")
    tooltip:SetOwner(UIParent, "ANCHOR_NONE")
    tooltip:SetBagItem(bag, slot)

    -- Loop through the tooltip lines to find "Prospectable"
    for i = 1, tooltip:NumLines() do
        local line = _G["ProspectableTooltipTextLeft" .. i]:GetText()
        if line and string.find(line, "Prospectable") then
            return true  -- If "Prospectable" is found in the tooltip, the ore can be prospected
        end
    end
    return false
end


function LazyProfessions:ShowAllOre()
    -- Create a scrollable frame to display all ores
    if not self.oreListFrame then
        self.oreListFrame = CreateFrame("ScrollFrame", "OreListFrame", myFrame, "UIPanelScrollFrameTemplate")
        self.oreListFrame:SetPoint("TOPLEFT", miningMenu, "BOTTOMLEFT", -20, -10)
        self.oreListFrame:SetSize(500, 200)
        
        local oreContent = CreateFrame("Frame", nil, self.oreListFrame)
        oreContent:SetSize(520, 800) -- Set a large height to allow scrolling
        self.oreListFrame:SetScrollChild(oreContent)

        local ores = {
            { name = "Copper Ore", icon = "Interface/Icons/INV_Ore_Copper_01", level = 1, locations = "Durotar, Elwynn Forest" },
            { name = "Tin Ore", icon = "Interface/Icons/inv_ore_tin_01", level = 65, locations = "Hillsbrad Foothills, Westfall" },
            { name = "Silver Ore", icon = "Interface/Icons/item_pyriumore", level = 75, locations = "The Barrens, Ashenvale" },
            { name = "Gold Ore", icon = "Interface/Icons/inv_ore_gold_01", level = 115, locations = "Stranglethorn Vale, Arathi Highlands" },
            { name = "Iron Ore", icon = "Interface/Icons/inv_ore_iron_01", level = 125, locations = "Feralas, Alterac Mountains" },
            { name = "Mithril Ore", icon = "Interface/Icons/inv_ore_mithril_01", level = 175, locations = "Badlands, Hinterlands" },
            { name = "Truesilver Ore", icon = "Interface/Icons/inv_ore_truesilver_01", level = 230, locations = "Winterspring, Tanaris" },
            { name = "Thorium Ore", icon = "Interface/Icons/inv_ore_thorium_01", level = 250, locations = "Un'Goro Crater, Burning Steppes" },
            { name = "Fel Iron Ore", icon = "Interface/Icons/inv_ore_feliron", level = 275, locations = "Hellfire Peninsula, Zangarmarsh" },
            { name = "Adamantite Ore", icon = "Interface/Icons/INV_Ore_Adamantium_01", level = 325, locations = "Nagrand, Blade's Edge Mountains" },
            { name = "Khorium Ore", icon = "Interface/Icons/inv_ore_khorium", level = 375, locations = "Netherstorm, Shadowmoon Valley" },
            { name = "Eternium Ore", icon = "Interface/Icons/inv_ore_eternium", level = 350, locations = "Outland Zones" },
            { name = "Cobalt Ore", icon = "Interface/Icons/inv_ore_cobalt", level = 350, locations = "Howling Fjord, Borean Tundra" },
            { name = "Saronite Ore", icon = "Interface/Icons/inv_ore_saronite_01", level = 400, locations = "Icecrown, Sholazar Basin" },
            { name = "Titanium Ore", icon = "Interface/Icons/inv_ore_platinum_01", level = 450, locations = "Icecrown, Storm Peaks" },
            { name = "Obsidium Ore", icon = "Interface/Icons/inv_misc_pyriumore", level = 425, locations = "Mount Hyjal, Vashj'ir" },
            { name = "Elementium Ore", icon = "Interface/Icons/item_pyriumore", level = 475, locations = "Twilight Highlands, Deepholm" },
            { name = "Pyrite Ore", icon = "Interface/Icons/inv_ore_arcanite_01", level = 525, locations = "Uldum, Twilight Highlands" }
        }

        local yOffset = -10
        for _, ore in ipairs(ores) do
            local oreButton = CreateFrame("Button", nil, oreContent)
            oreButton:SetSize(460, 30)
            oreButton:SetPoint("TOPLEFT", oreContent, "TOPLEFT", 10, yOffset)
            
            local oreIcon = oreButton:CreateTexture(nil, "ARTWORK")
            oreIcon:SetSize(25, 25)
            oreIcon:SetPoint("LEFT", oreButton, "LEFT", 5, 0)
            oreIcon:SetTexture(ore.icon)
            
            local oreLabel = oreButton:CreateFontString(nil, "OVERLAY")
            oreLabel:SetFontObject("GameFontNormal")
            oreLabel:SetPoint("LEFT", oreIcon, "RIGHT", 10, 0)
            oreLabel:SetText(ore.name .. " (Level " .. ore.level .. ") - " .. ore.locations)

            yOffset = yOffset - 35
        end
    end
    self.oreListFrame:Show()
end

function LazyProfessions:HideAllOre()
    if self.oreListFrame then
        self.oreListFrame:Hide()
    end
    if self.availableOreFrame then
        self.availableOreFrame:Hide()
    end
end

-- Create a Hotkey Assignment Window
function LazyProfessions:ShowHotkeyAssignmentWindow()
    if not self.hotkeyFrame then
        -- Create the frame for hotkey assignment
        self.hotkeyFrame = CreateFrame("Frame", "HotkeyAssignmentFrame", UIParent, "BasicFrameTemplateWithInset")
        self.hotkeyFrame:SetSize(300, 150)
        self.hotkeyFrame:SetPoint("CENTER")
        
        -- Title for the window
        self.hotkeyFrame.title = self.hotkeyFrame:CreateFontString(nil, "OVERLAY")
        self.hotkeyFrame.title:SetFontObject("GameFontHighlight")
        self.hotkeyFrame.title:SetPoint("TOP", 0, -10)
        self.hotkeyFrame.title:SetText("Set Hotkey for Prospecting")

        -- Instructions text
        local instructions = self.hotkeyFrame:CreateFontString(nil, "OVERLAY")
        instructions:SetFontObject("GameFontNormal")
        instructions:SetPoint("TOP", 0, -40)
        instructions:SetText("Press a key to assign it as a hotkey.")

        -- Capture key presses
        self.hotkeyFrame:SetScript("OnKeyDown", function(self, key)
            LazyProfessions:SetProspectingHotkey(key)  -- Assign the key as hotkey
            self:Hide()  -- Hide the window after assigning
            print("Assigned hotkey:", key)
        end)

        -- Ensure the frame captures input
        self.hotkeyFrame:SetPropagateKeyboardInput(false)
    end

    self.hotkeyFrame:Show()
end

-- Variable to store the assigned hotkey
local prospectingHotkey = nil

-- Function to set and store the hotkey
function LazyProfessions:SetProspectingHotkey(key)
    prospectingHotkey = key
    -- You can store the hotkey in SavedVariables for persistence across sessions
    SetBinding(key, "CLICK SmartProspectingButton:LeftButton")  -- Bind the key to the Prospect Ores button
    SaveBindings(GetCurrentBindingSet())  -- Save the binding
    print("Prospecting hotkey set to:", key)
end

-- Function to remove the hotkey when not needed (optional)
function LazyProfessions:ClearProspectingHotkey()
    if prospectingHotkey then
        SetBinding(prospectingHotkey)  -- Clear the hotkey binding
        prospectingHotkey = nil
        SaveBindings(GetCurrentBindingSet())  -- Save the cleared binding
        print("Prospecting hotkey cleared.")
    end
end




-- Event handler function for player login and bag updates
LazyProfessions:SetScript("OnEvent", function(self, event, ...)
    if event == "PLAYER_LOGIN" then
        self:OnPlayerLogin()
    elseif event == "BAG_UPDATE" then
        if myFrame:IsShown() and self.availableOreFrame and self.availableOreFrame:IsShown() then
            self:UpdateAvailableOreList()
        end
    end
end)

function LazyProfessions:OnPlayerLogin()
    -- Code to run when the player logs in
    print("Welcome to LazyProfessions!")
    
    -- Example of creating a simple slash command
    SLASH_LAZYPROFESSIONS1 = "/lazyprof"
    SlashCmdList["LAZYPROFESSIONS"] = function(msg)
        LazyProfessions:ToggleFrame()
    end
end

function LazyProfessions:ToggleFrame()
    if myFrame:IsShown() then
        myFrame:Hide()
    else
        myFrame:Show()
    end
end
