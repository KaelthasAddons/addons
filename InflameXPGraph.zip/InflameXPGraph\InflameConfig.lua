local _, ns = ...

ns.InflameGlobalDefaultConfig = {
--[[     boxList = {},
    cantidad = 1000, ]]
}

ns.InflameCharDefaultConfig = {
    MainWindow={
        startPoint="CENTER",
        relativePoint="CENTER",
        xOffs=0,
        yOffs=0,
    },
    data ={},
    dataStarted = nil,
    isVisible = true,
}

Inflame_CharSettings = Inflame_CharSettings or ns.InflameCharDefaultConfig -- inicialización prematura
Inflame_GlobalSettings = Inflame_GlobalSettings or ns.InflameGlobalDefaultConfig
-- tener en cuenta que la variable global no se carga con el script, si no después de un tiempo y hay que esperar el evento.
-- la primera vez aunque la variable sea nil también se lanza el evento.

local function fakeData()
    Inflame_CharSettings.data = {}
    for i =1, 120 do 
        table.insert(Inflame_CharSettings.data, 1, {time = GetServerTime(), value = math.random(1,3) ==1 and math.random(550,2000) or 0, level = 60 })
    end
end

ns.variablesCargadas= function (...)
    if Inflame_CharSettings == nil then
        Inflame_CharSettings = ns.InflameCharDefaultConfig
    else
        for k, v in pairs(ns.InflameCharDefaultConfig) do
            if Inflame_CharSettings[k] == nil then
                Inflame_CharSettings[k] = v
            end
        end
    end
    if Inflame_GlobalSettings == nil then
        Inflame_GlobalSettings = ns.InflameGlobalDefaultConfig
    else
        for k, v in pairs(ns.InflameGlobalDefaultConfig) do
            if Inflame_GlobalSettings[k] == nil then
                Inflame_GlobalSettings[k] = v
            end
        end
    end
    --fakeData()
    --launch some events after loading here.
    --ns.changeItemClass("Consumables",not AutoScrap_CharSettings.protectedConsumables)
    ns.setVisible(Inflame_CharSettings.isVisible)
    ns.loadPositionMainW()
end