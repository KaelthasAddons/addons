local _, ns = ...
local L = ns.L

local selectHiddenFrame = CreateFrame ("Frame", nil, ns.getGraphWFrame())

local horizontalSize, topChartHSize, barW = ns.getWindowSizes()
selectHiddenFrame:SetSize(horizontalSize, topChartHSize)
selectHiddenFrame:SetPoint("TOPRIGHT")
-- selectHiddenFrame.bgHiddenFrame = selectHiddenFrame:CreateTexture(nil, "BACKGROUND")
-- selectHiddenFrame.bgHiddenFrame:SetAllPoints(selectHiddenFrame)
-- selectHiddenFrame.bgHiddenFrame:SetColorTexture(1, 0.5, 0.8, 0.6)
selectHiddenFrame:Hide()

selectHiddenFrame.highlight = selectHiddenFrame:CreateTexture(nil, "OVERLAY")
--selectHiddenFrame.highlight:SetColorTexture(0.5, 0, 0, 0.3)
selectHiddenFrame.highlight:SetColorTexture(255/255, 150/255, 0/255 , 0.3)
selectHiddenFrame.highlight:Hide()

local selectStartX,selectEndX
local barritaSelectIz, barritaSelectDer = 120,1
local isRangeSelected = false

function ns.isRangeSelected()
    return isRangeSelected
end

function ns.barritaSelectIz()
    return barritaSelectIz
end

function ns.barritaSelectDer()
    return barritaSelectDer
end

local selectRange, selectRangeSelected -- estos botones se crean más abajo, pero necesito las variables para las funciones del código
local seleccionando = false

local function activarSeleccion()
    seleccionando = true
    isRangeSelected = false
    selectRange:Hide()
    selectRangeSelected:Show()
    selectHiddenFrame:Show()
    -- decidí que la etiqueta no la pinta ns.seleccionandoRango ahora lo hace ns.updateUi
    -- ns.seleccionadoRango()
end

local function finalizarSeleccion()
    if seleccionando then
        seleccionando = false
        isRangeSelected = true
        selectRange:Hide()
        selectRangeSelected:Show()
        selectHiddenFrame:Hide()
        ns.setTextureColors()
    end
    selectHiddenFrame:SetScript("OnUpdate", nil)
end

local function cancelarSeleccion()
    seleccionando = false
    isRangeSelected = false
    barritaSelectIz, barritaSelectDer = 120, 1
    selectRangeSelected:Hide()
    selectRange:Show()
    selectHiddenFrame.highlight:Hide()
    selectHiddenFrame:Hide()
    ns.setTextureColors()
    selectHiddenFrame:SetScript("OnUpdate", nil)
end

--el padre tiene que ser resetGraph porque si se oculta para que se oculte tb
local resetGraph = ns.getResetGraph()
selectRange = ns.crearBoton3Fases(resetGraph,"Interface\\AddOns\\InflameXPGraph\\Images\\mix",0,27,117+36,145+36,function ()
    activarSeleccion()
    --antes no actualizaba la ui, pero ahora sí porque pongo un texto del mensaje del tiempo seleccionado
    ns.updateUI()
end)
selectRange:SetPoint("LEFT",resetGraph,"RIGHT",3,0)

--el padre tiene que ser resetGraph porque si se oculta para que se oculte tb
selectRangeSelected = ns.crearBoton3Fases(resetGraph,"Interface\\AddOns\\InflameXPGraph\\Images\\mix",0,27,117+71,145+71,function ()
    cancelarSeleccion()
    ns.updateUI()
    --ns.updateUI()
end)
selectRangeSelected:SetPoint("LEFT",resetGraph,"RIGHT",3,0)
selectRangeSelected:Hide()

local function actualizarHighlight(self)
    --print("...",GetServerTime())
    if seleccionando then
        local x = GetCursorPosition() / UIParent:GetEffectiveScale()
        local left = self:GetLeft()
        selectEndX = x - left

        local startX = math.min(selectStartX, selectEndX)
        local endX = math.max(selectStartX, selectEndX)
        --respetar límites
        startX = math.max(0,startX)
        endX = math.min(0,endX-horizontalSize)

        --print(startX, endX)
        
        barritaSelectIz = 120 - math.floor(startX / barW)
        barritaSelectDer = 1 + math.floor(math.abs(endX) / barW)

        -- esto matemáticamente no pasará nunca, pero me asusta algún fallo al pixel entre barras
        if barritaSelectIz < barritaSelectDer then
            barritaSelectIz, barritaSelectDer = barritaSelectDer, barritaSelectIz
        end
        --print("iz", barritaSelectIz, "der", barritaSelectDer)

        ns.escribirTime(barritaSelectIz,barritaSelectDer)

        self.highlight:SetPoint("TOPLEFT", self, "TOPLEFT", startX, 0)
        self.highlight:SetPoint("BOTTOMRIGHT", self, "BOTTOMRIGHT", endX, 0)
    end
end
selectHiddenFrame:SetScript("OnMouseDown", function(self, button)
    if button == "LeftButton" then
        local x = GetCursorPosition() / UIParent:GetEffectiveScale()
        local left = self:GetLeft()
        selectStartX = x - left
        selectEndX = selectStartX
        self.highlight:SetPoint("TOPLEFT", self, "TOPLEFT", selectStartX, 0)
        self.highlight:SetPoint("BOTTOMRIGHT", self, "BOTTOMLEFT", selectEndX, 0)
        self.highlight:Show()
        self:SetScript("OnUpdate", actualizarHighlight)
    end
end)
selectHiddenFrame:SetScript("OnMouseUp", function(self, button)
    if button == "LeftButton" then
        -- local startX = math.min(selectStartX, selectEndX)
        -- local endX = math.max(selectStartX, selectEndX)
        -- print(string.format("Selección desde %.1f hasta %.1f", startX, endX))
        --print("Selección final:", "iz", barritaSelectIz, "der", barritaSelectDer)
        --self.highlight:Hide()
        --isRangeSelected = true
        finalizarSeleccion()
        ns.updateUI()
        self:SetScript("OnUpdate", nil)
    end
end)


-- en las funciones globales no refrescar ui, por si se llama desde el propio refresco de ui no hacer bucle infinito
function ns.cancelarSeleccionSiActiva()
    if isRangeSelected or seleccionando then
        cancelarSeleccion()
    end
end

function ns.seleccionandoYNoSeleccionado()
    if seleccionando and not isRangeSelected then
        return true
    end
    return false
end

--en principio no se usa porque el boton al esconderse el padre es oculta. el resto de frames si se está seleccionando, el rango etc se cancela con ns.cancelarSeleccionSiActiva()
function ns.ocultarTodo()
    cancelarSeleccion()
    --ns.updateUI()
    selectRange:Hide()
    selectRangeSelected:Hide()
    selectHiddenFrame:Hide()
end

ns.setTooltip(selectRange,L["Select a range"])
ns.setTooltip(selectRangeSelected,L["Remove a range"])