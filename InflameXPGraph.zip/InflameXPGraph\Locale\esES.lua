local _,ns = ...
local L=ns.L

if not LOCALE_esES then
    return
end

L["Hello World"] = "Hola Mundo"
L["No data, kill something."] = "No hay datos hasta que ganes XP."
L["Reset all Data in the Graph"] = "Reinicar todos los datos del gráfico"
L["Not Displayed if you are level 70"] = "No se muestra si ya eres nivel 60"
L["Select a range"] = "Selecciona un rango específico.\nHaz clic y arrastra sobre el gráfico"
L["Remove a range"] = "Quitar la seleccion de rango"
L["Time: "] = "Tiempo: "