local _,ns = ...
local L = ns.L

local disable = false
function ns.disableMapIcon()
    disable = true
end

function ns.miniMapLoad()

    local function MapClick (button)
        if button == "LeftButton" then
            ns.toogleOutterFrame()
        elseif button == "RightButton" then
        end
    end

    -- Primero creando con LibDataBroker
    local miniIcon = LibStub("LibDataBroker-1.1"):NewDataObject("Inflame", {
        type = "data source",
        text = "Inflame",
        icon = "Interface\\AddOns\\InflameXPGraph\\Images\\Icons\\InflameMap.blp",
        OnClick = function(self, button)
            MapClick(button)
        end,
        OnTooltipShow = function(tooltip)
            if not tooltip or not tooltip.AddLine then return end
            if not disable then
                tooltip:AddLine("Inflame XP Graph")
            else
                tooltip:AddLine("Inflame XP Graph")
                tooltip:AddLine(L["Not Displayed if you are level 70"],1,1,1)
            end
            --tooltip:AddLine(L["Left Click: Toggle AutoScrap"],1,1,1)
            --tooltip:AddLine(L["Right Click: Toggle Combat Statistics"],1,1,1)
        end
    })

    -- Repetir con LibDBIcon
    local icon = LibStub("LibDBIcon-1.0", true)
    icon:Register("Inflame", miniIcon, Inflame_GlobalSettings)

    -- Function to toggle LibDBIcon
    --local function LibDBIconToggle()
    --if  AutoScrap_GlobalSettings.hide then
        --icon:Hide("AutoScrap")
    --else
        icon:Show("Inflame")
    --end
    --end
    --LibDBIconToggle()
end
--ns.miniMapLoad = miniMapLoad