local _, ns = ... --... devuelve el nombre del addon, namespace: una global que se comparte en todos los ficheros para compartir las variables local de cada fichero.
local L = {}
ns.L = setmetatable(L,{__index=function(table,key) --pone la metatabla y devuelve la tabla en uno, con el error __index ejecuta la función
	local value = tostring(key)
	rawset(table,key,value) --añade value a la tabla con la misma clave sin ejecutar la metatabla
	return key
end});
----------------------------------------------------------------------
--El código encima de esto se puede ignorar para buscar la traducción.
----------------------------------------------------------------------

L["Hello World"] = "Hello World"
L["No data, kill something."] = "No data untill you gain XP."
L["Reset all Data in the Graph"] = "Reset all Data in the Graph"
L["Not Displayed if you are level 70"] = "Not Displayed if you are level 60"
L["Select a range"] = "Select a specific range.\nClick and drag on the graph"
L["Remove a range"] = "Clear the range"
L["Time: "] = "Time: "