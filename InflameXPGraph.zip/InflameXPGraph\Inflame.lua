local name,ns = ...
local L=ns.L

local Inflame = CreateFrame("Frame")  --se puede crear como global para compartirlo con otros addons. el tipo frame puede recibir ciertas señales, por eso se crea genérico.
-- global char variable: AutoScrap_CharSettings
--print("desde core: "..AutoScrap_CharSettings.cantidad)
ns.PLAYER_ENTERING_WORLD = false
ns.PLAYER_LOGIN = false

Inflame:RegisterEvent("PLAYER_ENTERING_WORLD")
Inflame:RegisterEvent("ADDON_LOADED")
Inflame:RegisterEvent("PLAYER_LOGIN")
Inflame:RegisterEvent("PLAYER_LEAVING_WORLD")
Inflame:RegisterEvent("PLAYER_LEVEL_UP")

local function eventHandler (self, event, ...)
    --local time = GetTimePreciseSec()
    --print (event, ...)
    if event == "PLAYER_ENTERING_WORLD" then
                --[[ if IsAddOnLoaded("OtherAddonName") then
            --ns.otroAddonDetectado()
        end ]]
        --[[ local inInstance, instanceType = IsInInstance()
        local nameInstance, typeInstance, difficultyIndex, difficultyName, maxPlayers, dynamicDifficulty, isDynamic, instanceMapId, lfgID = GetInstanceInfo()
        print (GetInstanceInfo())
        print (IsInInstance()) ]]

        ns.PLAYER_ENTERING_WORLD = true
    elseif event == "ADDON_LOADED" then
        if name == ... then
            ns.variablesCargadas(...)
        end
    elseif event == "PLAYER_LOGIN" then
        local player, serverShortName = UnitFullName("player")
        ns.miniMapLoad()
        ns.loadWindowSetup()
        ns.PLAYER_LOGIN = true
    elseif event == "PLAYER_LEAVING_WORLD" then
        ns.PLAYER_ENTERING_WORLD = false
    elseif event == "PLAYER_LEVEL_UP" then
        ns.playerLevelUp()
    end
    --print("total exec time: ",(GetTimePreciseSec()-time)*1000)
end
Inflame:SetScript("OnEvent", eventHandler)

local function handle_commands(msg)
    --print("Recibido el comando: " .. msg)
    local separarPalabras = {}
    for substring in msg:gmatch("%S+") do
        table.insert(separarPalabras, substring)
    end
    --msg = {msg}
    if separarPalabras[1] == nil then --puesto /scrap o /autoscrap
        ns.toogleOutterFrame()
    elseif separarPalabras[1] == "hello" then --puesto /scrap clear o /autoscrap clear
        print(L["Hello World"])
    else
        --mensaje de ayuda
    end
end

SlashCmdList["INFLAME"] = function(msg) handle_commands(msg) end
SLASH_INFLAME1 = "/inflame"
SLASH_INFLAME2 = "/xp"