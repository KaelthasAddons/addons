local _,ns = ...
ns.Utils = {}

--importado de mi AutoScrap, cambiar rutas

function ns.Utils.crearFrameConTextura (parentFrame, left, right, top, bottom, alfa, file)
    local frame = CreateFrame("Frame",nil, parentFrame)
    frame:SetSize(right-left,bottom-top)
    frame.tex = frame:CreateTexture()
    frame.tex:SetAllPoints(frame)
    frame.tex:SetTexture(file)
    frame.tex:SetTexCoord(left/512, right/512, top/512 , bottom/512);
    if alfa ~= 1 then
        frame.tex:SetVertexColor(1, 1, 1 , alfa);
    end
    return frame
end

function ns.Utils.horaBonita(time)
    local dias = math.floor(time / 86400) --3600*24=86400
    local horas = math.floor(time / 3600) % 24
    if dias > 0 and horas > 0 then
        return dias .. " d " .. horas .. " hr"
    end
    local minutos = math.floor(time / 60) % 60
    if minutos > 0 then
        if horas > 0 then
            return horas .. " h " .. minutos .. " min"
        elseif dias > 0 then
            return dias .. " d " .. minutos .. " min"
        end
    end
    local segundos = time % 60
    if segundos > 0 then
        if minutos > 0 then
            return minutos .. " min " .. segundos .. " s"
        elseif horas >0 then
            return horas .. " h " .. segundos .. " sec"
        elseif dias >0 then
            return dias .. " d " .. segundos .. " s"
        end
    end

    if dias > 0 then
        return dias .. " d"
    elseif horas>0 then
        return horas .. " hr"
    elseif minutos>0 then
        return minutos .. " min"
    end
    return segundos .. " sec"
end

--esta función si el marco no es simétrico el frame del medio está desplazado, arreglar.
function ns.Utils.crear9SliceFrame(parentFrame,left, right, top, bottom, barLeft, barRight, barTop, barBottom, width, height, file, fileW, fileH)

    local izquierda, derecha, arriba, abajo, horizontal, vertical = barLeft-left,right-barRight, barTop-top, bottom-barBottom, right-left, bottom- top
    local pulsadoIZ, pulsandoDE, pulsadoAR, pulsadoAB = left, right, top, bottom

--[[     print (izquierda, derecha, derecha-width, width)
    print (arriba, abajo, abajo-height, height) ]]

    local boton = CreateFrame("Frame",nil,parentFrame)
    boton:SetSize(width,height)

    local frame9Slice = boton:CreateTexture(nil, "BACKGROUND")
    frame9Slice:SetSize(width-izquierda-(horizontal-derecha),height-arriba-(vertical-abajo))
    frame9Slice:SetTexture(file)
    frame9Slice:SetTexCoord((pulsadoIZ+izquierda)/fileW,(pulsadoIZ+derecha)/fileW,(pulsadoAR+arriba)/fileH,(pulsadoAR+abajo)/fileH)
    frame9Slice:SetPoint("CENTER",boton,"CENTER")--, izquierda-derecha, (-1)* (arriba-abajo))

    frame9Slice.texARIZ = boton:CreateTexture(nil, "BACKGROUND")
    frame9Slice.texARIZ:SetSize(izquierda,arriba)
    frame9Slice.texARIZ:SetTexture(file)
    frame9Slice.texARIZ:SetTexCoord(pulsadoIZ/fileW,(pulsadoIZ+izquierda)/fileW,pulsadoAR/fileH,(pulsadoAR+arriba)/fileH)
    frame9Slice.texARIZ:SetPoint("BOTTOMRIGHT",frame9Slice,"TOPLEFT")
    frame9Slice.texARDE = boton:CreateTexture(nil, "BACKGROUND")
    frame9Slice.texARDE:SetSize(horizontal-derecha,arriba)
    frame9Slice.texARDE:SetTexture(file)
    frame9Slice.texARDE:SetTexCoord((pulsadoIZ+derecha)/fileW,(pulsandoDE)/fileW,pulsadoAR/fileH,(pulsadoAR+arriba)/fileH)
    frame9Slice.texARDE:SetPoint("BOTTOMLEFT",frame9Slice,"TOPRIGHT")
    frame9Slice.texABIZ = boton:CreateTexture(nil, "BACKGROUND")
    frame9Slice.texABIZ:SetSize(izquierda,vertical-abajo)
    frame9Slice.texABIZ:SetTexture(file)
    frame9Slice.texABIZ:SetTexCoord(pulsadoIZ/fileW,(pulsadoIZ+izquierda)/fileW,(pulsadoAR+abajo)/fileH,(pulsadoAB)/fileH)
    frame9Slice.texABIZ:SetPoint("TOPRIGHT",frame9Slice,"BOTTOMLEFT")
    frame9Slice.texABDE = boton:CreateTexture(nil, "BACKGROUND")
    frame9Slice.texABDE:SetSize(horizontal-derecha,vertical-abajo)
    frame9Slice.texABDE:SetTexture(file)
    frame9Slice.texABDE:SetTexCoord((pulsadoIZ+derecha)/fileW,(pulsandoDE)/fileW,(pulsadoAR+abajo)/fileH,(pulsadoAB)/fileH)
    frame9Slice.texABDE:SetPoint("TOPLEFT",frame9Slice,"BOTTOMRIGHT")
    frame9Slice.texIZ = boton:CreateTexture(nil, "BACKGROUND")
    frame9Slice.texIZ:SetSize(izquierda,height-arriba-(vertical-abajo))
    frame9Slice.texIZ:SetTexture(file)
    frame9Slice.texIZ:SetTexCoord((pulsadoIZ)/fileW,(pulsadoIZ+izquierda)/fileW,(pulsadoAR+arriba)/fileH,(pulsadoAR+abajo)/fileH)
    frame9Slice.texIZ:SetPoint("RIGHT",frame9Slice,"LEFT")
    frame9Slice.texDE = boton:CreateTexture(nil, "BACKGROUND")
    frame9Slice.texDE:SetSize(horizontal-derecha,height-arriba-(vertical-abajo))
    frame9Slice.texDE:SetTexture(file)
    frame9Slice.texDE:SetTexCoord((pulsadoIZ+derecha)/fileW,(pulsandoDE)/fileW,(pulsadoAR+arriba)/fileH,(pulsadoAR+abajo)/fileH)
    frame9Slice.texDE:SetPoint("LEFT",frame9Slice,"RIGHT")
    frame9Slice.texAR = boton:CreateTexture(nil, "BACKGROUND")
    frame9Slice.texAR:SetSize(width-izquierda-(horizontal-derecha),arriba)
    frame9Slice.texAR:SetTexture(file)
    frame9Slice.texAR:SetTexCoord((pulsadoIZ+izquierda)/fileW,(pulsadoIZ+derecha)/fileW,(pulsadoAR)/fileH,(pulsadoAR+arriba)/fileH)
    frame9Slice.texAR:SetPoint("BOTTOM",frame9Slice,"TOP")
    frame9Slice.texAB = boton:CreateTexture(nil, "BACKGROUND")
    frame9Slice.texAB:SetSize(width-izquierda-(horizontal-derecha),(vertical-abajo))
    frame9Slice.texAB:SetTexture(file)
    frame9Slice.texAB:SetTexCoord((pulsadoIZ+izquierda)/fileW,(pulsadoIZ+derecha)/fileW,(pulsadoAR+abajo)/fileH,(pulsadoAB)/fileH)
    frame9Slice.texAB:SetPoint("TOP",frame9Slice,"BOTTOM")
    
    return boton
end

function ns.Utils.crearBoton(parentFrame,width,height,text,funcionOnClick)
    --local botonPulsadoCentral = ns.Utils.crearFrameConTextura(parentFrame,0,175,493-27,493)
    local izquierda, derecha, arriba, abajo, horizontal, vertical = 5,167,8,21,175,27 --27,175 total.
    local pulsadoIZ, pulsandoDE, pulsadoAR, pulsadoAB = 0,175,493-27,493

    local boton = CreateFrame("Frame",nil,parentFrame)
    boton:SetSize(width,height)

    local botonPulsadoCentral = ns.Utils.crearFrameConTextura(boton,pulsadoIZ+izquierda,pulsadoIZ+derecha,pulsadoAR+arriba,pulsadoAR+abajo,1,"mailpanel")
    botonPulsadoCentral:SetSize(width-izquierda-(horizontal-derecha),height-arriba-(vertical-abajo))
    botonPulsadoCentral:SetPoint("CENTER",boton,"CENTER")
    botonPulsadoCentral.texARIZ = botonPulsadoCentral:CreateTexture()
    botonPulsadoCentral.texARIZ:SetSize(izquierda,arriba)
    botonPulsadoCentral.texARIZ:SetTexture("Interface\\AddOns\\AutoScrap\\images\\mailpanel")
    botonPulsadoCentral.texARIZ:SetTexCoord(pulsadoIZ/512,(pulsadoIZ+izquierda)/512,pulsadoAR/512,(pulsadoAR+arriba)/512)
    botonPulsadoCentral.texARIZ:SetPoint("BOTTOMRIGHT",botonPulsadoCentral,"TOPLEFT")
    botonPulsadoCentral.texARDE = botonPulsadoCentral:CreateTexture()
    botonPulsadoCentral.texARDE:SetSize(horizontal-derecha,arriba)
    botonPulsadoCentral.texARDE:SetTexture("Interface\\AddOns\\AutoScrap\\images\\mailpanel")
    botonPulsadoCentral.texARDE:SetTexCoord((pulsadoIZ+derecha)/512,(pulsandoDE)/512,pulsadoAR/512,(pulsadoAR+arriba)/512)
    botonPulsadoCentral.texARDE:SetPoint("BOTTOMLEFT",botonPulsadoCentral,"TOPRIGHT")
    botonPulsadoCentral.texABIZ = botonPulsadoCentral:CreateTexture()
    botonPulsadoCentral.texABIZ:SetSize(izquierda,vertical-abajo)
    botonPulsadoCentral.texABIZ:SetTexture("Interface\\AddOns\\AutoScrap\\images\\mailpanel")
    botonPulsadoCentral.texABIZ:SetTexCoord(pulsadoIZ/512,(pulsadoIZ+izquierda)/512,(pulsadoAR+abajo)/512,(pulsadoAB)/512)
    botonPulsadoCentral.texABIZ:SetPoint("TOPRIGHT",botonPulsadoCentral,"BOTTOMLEFT")
    botonPulsadoCentral.texABDE = botonPulsadoCentral:CreateTexture()
    botonPulsadoCentral.texABDE:SetSize(horizontal-derecha,vertical-abajo)
    botonPulsadoCentral.texABDE:SetTexture("Interface\\AddOns\\AutoScrap\\images\\mailpanel")
    botonPulsadoCentral.texABDE:SetTexCoord((pulsadoIZ+derecha)/512,(pulsandoDE)/512,(pulsadoAR+abajo)/512,(pulsadoAB)/512)
    botonPulsadoCentral.texABDE:SetPoint("TOPLEFT",botonPulsadoCentral,"BOTTOMRIGHT")
    botonPulsadoCentral.texIZ = botonPulsadoCentral:CreateTexture()
    botonPulsadoCentral.texIZ:SetSize(izquierda,height-arriba-(vertical-abajo))
    botonPulsadoCentral.texIZ:SetTexture("Interface\\AddOns\\AutoScrap\\images\\mailpanel")
    botonPulsadoCentral.texIZ:SetTexCoord((pulsadoIZ)/512,(pulsadoIZ+izquierda)/512,(pulsadoAR+arriba)/512,(pulsadoAR+abajo)/512)
    botonPulsadoCentral.texIZ:SetPoint("RIGHT",botonPulsadoCentral,"LEFT")
    botonPulsadoCentral.texDE = botonPulsadoCentral:CreateTexture()
    botonPulsadoCentral.texDE:SetSize(horizontal-derecha,height-arriba-(vertical-abajo))
    botonPulsadoCentral.texDE:SetTexture("Interface\\AddOns\\AutoScrap\\images\\mailpanel")
    botonPulsadoCentral.texDE:SetTexCoord((pulsadoIZ+derecha)/512,(pulsandoDE)/512,(pulsadoAR+arriba)/512,(pulsadoAR+abajo)/512)
    botonPulsadoCentral.texDE:SetPoint("LEFT",botonPulsadoCentral,"RIGHT")
    botonPulsadoCentral.texAR = botonPulsadoCentral:CreateTexture()
    botonPulsadoCentral.texAR:SetSize(width-izquierda-(horizontal-derecha),arriba)
    botonPulsadoCentral.texAR:SetTexture("Interface\\AddOns\\AutoScrap\\images\\mailpanel")
    botonPulsadoCentral.texAR:SetTexCoord((pulsadoIZ+izquierda)/512,(pulsadoIZ+derecha)/512,(pulsadoAR)/512,(pulsadoAR+arriba)/512)
    botonPulsadoCentral.texAR:SetPoint("BOTTOM",botonPulsadoCentral,"TOP")
    botonPulsadoCentral.texAB = botonPulsadoCentral:CreateTexture()
    botonPulsadoCentral.texAB:SetSize(width-izquierda-(horizontal-derecha),(vertical-abajo))
    botonPulsadoCentral.texAB:SetTexture("Interface\\AddOns\\AutoScrap\\images\\mailpanel")
    botonPulsadoCentral.texAB:SetTexCoord((pulsadoIZ+izquierda)/512,(pulsadoIZ+derecha)/512,(pulsadoAR+abajo)/512,(pulsadoAB)/512)
    botonPulsadoCentral.texAB:SetPoint("TOP",botonPulsadoCentral,"BOTTOM")

    pulsadoIZ, pulsandoDE, pulsadoAR, pulsadoAB = 0,175,493-(27*2),493-27
    local botonNormalCentral = ns.Utils.crearFrameConTextura(boton,pulsadoIZ+izquierda,pulsadoIZ+derecha,pulsadoAR+arriba,pulsadoAR+abajo,1,"mailpanel")
    botonNormalCentral:SetSize(width-izquierda-(horizontal-derecha),height-arriba-(vertical-abajo))
    botonNormalCentral:SetPoint("CENTER",boton,"CENTER")
    botonNormalCentral.texARIZ = botonNormalCentral:CreateTexture()
    botonNormalCentral.texARIZ:SetSize(izquierda,arriba)
    botonNormalCentral.texARIZ:SetTexture("Interface\\AddOns\\AutoScrap\\images\\mailpanel")
    botonNormalCentral.texARIZ:SetTexCoord(pulsadoIZ/512,(pulsadoIZ+izquierda)/512,pulsadoAR/512,(pulsadoAR+arriba)/512)
    botonNormalCentral.texARIZ:SetPoint("BOTTOMRIGHT",botonNormalCentral,"TOPLEFT")
    botonNormalCentral.texARDE = botonNormalCentral:CreateTexture()
    botonNormalCentral.texARDE:SetSize(horizontal-derecha,arriba)
    botonNormalCentral.texARDE:SetTexture("Interface\\AddOns\\AutoScrap\\images\\mailpanel")
    botonNormalCentral.texARDE:SetTexCoord((pulsadoIZ+derecha)/512,(pulsandoDE)/512,pulsadoAR/512,(pulsadoAR+arriba)/512)
    botonNormalCentral.texARDE:SetPoint("BOTTOMLEFT",botonNormalCentral,"TOPRIGHT")
    botonNormalCentral.texABIZ = botonNormalCentral:CreateTexture()
    botonNormalCentral.texABIZ:SetSize(izquierda,vertical-abajo)
    botonNormalCentral.texABIZ:SetTexture("Interface\\AddOns\\AutoScrap\\images\\mailpanel")
    botonNormalCentral.texABIZ:SetTexCoord(pulsadoIZ/512,(pulsadoIZ+izquierda)/512,(pulsadoAR+abajo)/512,(pulsadoAB)/512)
    botonNormalCentral.texABIZ:SetPoint("TOPRIGHT",botonNormalCentral,"BOTTOMLEFT")
    botonNormalCentral.texABDE = botonNormalCentral:CreateTexture()
    botonNormalCentral.texABDE:SetSize(horizontal-derecha,vertical-abajo)
    botonNormalCentral.texABDE:SetTexture("Interface\\AddOns\\AutoScrap\\images\\mailpanel")
    botonNormalCentral.texABDE:SetTexCoord((pulsadoIZ+derecha)/512,(pulsandoDE)/512,(pulsadoAR+abajo)/512,(pulsadoAB)/512)
    botonNormalCentral.texABDE:SetPoint("TOPLEFT",botonNormalCentral,"BOTTOMRIGHT")
    botonNormalCentral.texIZ = botonNormalCentral:CreateTexture()
    botonNormalCentral.texIZ:SetSize(izquierda,height-arriba-(vertical-abajo))
    botonNormalCentral.texIZ:SetTexture("Interface\\AddOns\\AutoScrap\\images\\mailpanel")
    botonNormalCentral.texIZ:SetTexCoord((pulsadoIZ)/512,(pulsadoIZ+izquierda)/512,(pulsadoAR+arriba)/512,(pulsadoAR+abajo)/512)
    botonNormalCentral.texIZ:SetPoint("RIGHT",botonNormalCentral,"LEFT")
    botonNormalCentral.texDE = botonNormalCentral:CreateTexture()
    botonNormalCentral.texDE:SetSize(horizontal-derecha,height-arriba-(vertical-abajo))
    botonNormalCentral.texDE:SetTexture("Interface\\AddOns\\AutoScrap\\images\\mailpanel")
    botonNormalCentral.texDE:SetTexCoord((pulsadoIZ+derecha)/512,(pulsandoDE)/512,(pulsadoAR+arriba)/512,(pulsadoAR+abajo)/512)
    botonNormalCentral.texDE:SetPoint("LEFT",botonNormalCentral,"RIGHT")
    botonNormalCentral.texAR = botonNormalCentral:CreateTexture()
    botonNormalCentral.texAR:SetSize(width-izquierda-(horizontal-derecha),arriba)
    botonNormalCentral.texAR:SetTexture("Interface\\AddOns\\AutoScrap\\images\\mailpanel")
    botonNormalCentral.texAR:SetTexCoord((pulsadoIZ+izquierda)/512,(pulsadoIZ+derecha)/512,(pulsadoAR)/512,(pulsadoAR+arriba)/512)
    botonNormalCentral.texAR:SetPoint("BOTTOM",botonNormalCentral,"TOP")
    botonNormalCentral.texAB = botonNormalCentral:CreateTexture()
    botonNormalCentral.texAB:SetSize(width-izquierda-(horizontal-derecha),(vertical-abajo))
    botonNormalCentral.texAB:SetTexture("Interface\\AddOns\\AutoScrap\\images\\mailpanel")
    botonNormalCentral.texAB:SetTexCoord((pulsadoIZ+izquierda)/512,(pulsadoIZ+derecha)/512,(pulsadoAR+abajo)/512,(pulsadoAB)/512)
    botonNormalCentral.texAB:SetPoint("TOP",botonNormalCentral,"BOTTOM")

    pulsadoIZ, pulsandoDE, pulsadoAR, pulsadoAB = 0,175,493-(27*3),493-(27*2)
    local botonDesabilitadoCentral = ns.Utils.crearFrameConTextura(boton,pulsadoIZ+izquierda,pulsadoIZ+derecha,pulsadoAR+arriba,pulsadoAR+abajo,1,"mailpanel")
    botonDesabilitadoCentral:SetSize(width-izquierda-(horizontal-derecha),height-arriba-(vertical-abajo))
    botonDesabilitadoCentral:SetPoint("CENTER",boton,"CENTER")
    botonDesabilitadoCentral.texARIZ = botonDesabilitadoCentral:CreateTexture()
    botonDesabilitadoCentral.texARIZ:SetSize(izquierda,arriba)
    botonDesabilitadoCentral.texARIZ:SetTexture("Interface\\AddOns\\AutoScrap\\images\\mailpanel")
    botonDesabilitadoCentral.texARIZ:SetTexCoord(pulsadoIZ/512,(pulsadoIZ+izquierda)/512,pulsadoAR/512,(pulsadoAR+arriba)/512)
    botonDesabilitadoCentral.texARIZ:SetPoint("BOTTOMRIGHT",botonDesabilitadoCentral,"TOPLEFT")
    botonDesabilitadoCentral.texARDE = botonDesabilitadoCentral:CreateTexture()
    botonDesabilitadoCentral.texARDE:SetSize(horizontal-derecha,arriba)
    botonDesabilitadoCentral.texARDE:SetTexture("Interface\\AddOns\\AutoScrap\\images\\mailpanel")
    botonDesabilitadoCentral.texARDE:SetTexCoord((pulsadoIZ+derecha)/512,(pulsandoDE)/512,pulsadoAR/512,(pulsadoAR+arriba)/512)
    botonDesabilitadoCentral.texARDE:SetPoint("BOTTOMLEFT",botonDesabilitadoCentral,"TOPRIGHT")
    botonDesabilitadoCentral.texABIZ = botonDesabilitadoCentral:CreateTexture()
    botonDesabilitadoCentral.texABIZ:SetSize(izquierda,vertical-abajo)
    botonDesabilitadoCentral.texABIZ:SetTexture("Interface\\AddOns\\AutoScrap\\images\\mailpanel")
    botonDesabilitadoCentral.texABIZ:SetTexCoord(pulsadoIZ/512,(pulsadoIZ+izquierda)/512,(pulsadoAR+abajo)/512,(pulsadoAB)/512)
    botonDesabilitadoCentral.texABIZ:SetPoint("TOPRIGHT",botonDesabilitadoCentral,"BOTTOMLEFT")
    botonDesabilitadoCentral.texABDE = botonDesabilitadoCentral:CreateTexture()
    botonDesabilitadoCentral.texABDE:SetSize(horizontal-derecha,vertical-abajo)
    botonDesabilitadoCentral.texABDE:SetTexture("Interface\\AddOns\\AutoScrap\\images\\mailpanel")
    botonDesabilitadoCentral.texABDE:SetTexCoord((pulsadoIZ+derecha)/512,(pulsandoDE)/512,(pulsadoAR+abajo)/512,(pulsadoAB)/512)
    botonDesabilitadoCentral.texABDE:SetPoint("TOPLEFT",botonDesabilitadoCentral,"BOTTOMRIGHT")
    botonDesabilitadoCentral.texIZ = botonDesabilitadoCentral:CreateTexture()
    botonDesabilitadoCentral.texIZ:SetSize(izquierda,height-arriba-(vertical-abajo))
    botonDesabilitadoCentral.texIZ:SetTexture("Interface\\AddOns\\AutoScrap\\images\\mailpanel")
    botonDesabilitadoCentral.texIZ:SetTexCoord((pulsadoIZ)/512,(pulsadoIZ+izquierda)/512,(pulsadoAR+arriba)/512,(pulsadoAR+abajo)/512)
    botonDesabilitadoCentral.texIZ:SetPoint("RIGHT",botonDesabilitadoCentral,"LEFT")
    botonDesabilitadoCentral.texDE = botonDesabilitadoCentral:CreateTexture()
    botonDesabilitadoCentral.texDE:SetSize(horizontal-derecha,height-arriba-(vertical-abajo))
    botonDesabilitadoCentral.texDE:SetTexture("Interface\\AddOns\\AutoScrap\\images\\mailpanel")
    botonDesabilitadoCentral.texDE:SetTexCoord((pulsadoIZ+derecha)/512,(pulsandoDE)/512,(pulsadoAR+arriba)/512,(pulsadoAR+abajo)/512)
    botonDesabilitadoCentral.texDE:SetPoint("LEFT",botonDesabilitadoCentral,"RIGHT")
    botonDesabilitadoCentral.texAR = botonDesabilitadoCentral:CreateTexture()
    botonDesabilitadoCentral.texAR:SetSize(width-izquierda-(horizontal-derecha),arriba)
    botonDesabilitadoCentral.texAR:SetTexture("Interface\\AddOns\\AutoScrap\\images\\mailpanel")
    botonDesabilitadoCentral.texAR:SetTexCoord((pulsadoIZ+izquierda)/512,(pulsadoIZ+derecha)/512,(pulsadoAR)/512,(pulsadoAR+arriba)/512)
    botonDesabilitadoCentral.texAR:SetPoint("BOTTOM",botonDesabilitadoCentral,"TOP")
    botonDesabilitadoCentral.texAB = botonDesabilitadoCentral:CreateTexture()
    botonDesabilitadoCentral.texAB:SetSize(width-izquierda-(horizontal-derecha),(vertical-abajo))
    botonDesabilitadoCentral.texAB:SetTexture("Interface\\AddOns\\AutoScrap\\images\\mailpanel")
    botonDesabilitadoCentral.texAB:SetTexCoord((pulsadoIZ+izquierda)/512,(pulsadoIZ+derecha)/512,(pulsadoAR+abajo)/512,(pulsadoAB)/512)
    botonDesabilitadoCentral.texAB:SetPoint("TOP",botonDesabilitadoCentral,"BOTTOM")


    boton.texto = CreateFrame("Frame",nil,boton)
    boton.texto:SetSize(width,height)
    boton.texto:SetPoint("CENTER",boton,"CENTER",0,2)
    boton.texto.text = boton.texto:CreateFontString(boton.texto,"OVERLAY","GameFontNormal")
    boton.texto.textoGuardado = text
    boton.texto.text:SetFont("Fonts\\FRIZQT_.TTF" ,12, "")
    boton.texto.text:SetText("|cFF99bec6"..boton.texto.textoGuardado.."|r")
    boton.texto.text:SetPoint("CENTER",boton.texto,"CENTER")
    boton.texto.textH = boton.texto:CreateFontString(boton.texto,"OVERLAY","GameFontHighlight")
    boton.texto.textH:SetText(text)
    boton.texto.textH:SetPoint("CENTER",boton.texto,"CENTER")
    boton.texto.textH:Hide()

    pulsadoIZ, pulsandoDE, pulsadoAR, pulsadoAB = 0,175,493-(27*4),493-(27*3)
    local botonHightlightCentral = ns.Utils.crearFrameConTextura(boton.texto,pulsadoIZ+izquierda,pulsadoIZ+derecha,pulsadoAR+arriba,pulsadoAR+abajo,1,"mailpanel")
    botonHightlightCentral:SetSize(width-izquierda-(horizontal-derecha),height-arriba-(vertical-abajo))
    botonHightlightCentral:SetPoint("CENTER",boton.texto,"CENTER")
    botonHightlightCentral.texARIZ = botonHightlightCentral:CreateTexture()
    botonHightlightCentral.texARIZ:SetSize(izquierda,arriba)
    botonHightlightCentral.texARIZ:SetTexture("Interface\\AddOns\\AutoScrap\\images\\mailpanel")
    botonHightlightCentral.texARIZ:SetTexCoord(pulsadoIZ/512,(pulsadoIZ+izquierda)/512,pulsadoAR/512,(pulsadoAR+arriba)/512)
    botonHightlightCentral.texARIZ:SetPoint("BOTTOMRIGHT",botonHightlightCentral,"TOPLEFT")
    botonHightlightCentral.texARDE = botonHightlightCentral:CreateTexture()
    botonHightlightCentral.texARDE:SetSize(horizontal-derecha,arriba)
    botonHightlightCentral.texARDE:SetTexture("Interface\\AddOns\\AutoScrap\\images\\mailpanel")
    botonHightlightCentral.texARDE:SetTexCoord((pulsadoIZ+derecha)/512,(pulsandoDE)/512,pulsadoAR/512,(pulsadoAR+arriba)/512)
    botonHightlightCentral.texARDE:SetPoint("BOTTOMLEFT",botonHightlightCentral,"TOPRIGHT")
    botonHightlightCentral.texABIZ = botonHightlightCentral:CreateTexture()
    botonHightlightCentral.texABIZ:SetSize(izquierda,vertical-abajo)
    botonHightlightCentral.texABIZ:SetTexture("Interface\\AddOns\\AutoScrap\\images\\mailpanel")
    botonHightlightCentral.texABIZ:SetTexCoord(pulsadoIZ/512,(pulsadoIZ+izquierda)/512,(pulsadoAR+abajo)/512,(pulsadoAB)/512)
    botonHightlightCentral.texABIZ:SetPoint("TOPRIGHT",botonHightlightCentral,"BOTTOMLEFT")
    botonHightlightCentral.texABDE = botonHightlightCentral:CreateTexture()
    botonHightlightCentral.texABDE:SetSize(horizontal-derecha,vertical-abajo)
    botonHightlightCentral.texABDE:SetTexture("Interface\\AddOns\\AutoScrap\\images\\mailpanel")
    botonHightlightCentral.texABDE:SetTexCoord((pulsadoIZ+derecha)/512,(pulsandoDE)/512,(pulsadoAR+abajo)/512,(pulsadoAB)/512)
    botonHightlightCentral.texABDE:SetPoint("TOPLEFT",botonHightlightCentral,"BOTTOMRIGHT")
    botonHightlightCentral.texIZ = botonHightlightCentral:CreateTexture()
    botonHightlightCentral.texIZ:SetSize(izquierda,height-arriba-(vertical-abajo))
    botonHightlightCentral.texIZ:SetTexture("Interface\\AddOns\\AutoScrap\\images\\mailpanel")
    botonHightlightCentral.texIZ:SetTexCoord((pulsadoIZ)/512,(pulsadoIZ+izquierda)/512,(pulsadoAR+arriba)/512,(pulsadoAR+abajo)/512)
    botonHightlightCentral.texIZ:SetPoint("RIGHT",botonHightlightCentral,"LEFT")
    botonHightlightCentral.texDE = botonHightlightCentral:CreateTexture()
    botonHightlightCentral.texDE:SetSize(horizontal-derecha,height-arriba-(vertical-abajo))
    botonHightlightCentral.texDE:SetTexture("Interface\\AddOns\\AutoScrap\\images\\mailpanel")
    botonHightlightCentral.texDE:SetTexCoord((pulsadoIZ+derecha)/512,(pulsandoDE)/512,(pulsadoAR+arriba)/512,(pulsadoAR+abajo)/512)
    botonHightlightCentral.texDE:SetPoint("LEFT",botonHightlightCentral,"RIGHT")
    botonHightlightCentral.texAR = botonHightlightCentral:CreateTexture()
    botonHightlightCentral.texAR:SetSize(width-izquierda-(horizontal-derecha),arriba)
    botonHightlightCentral.texAR:SetTexture("Interface\\AddOns\\AutoScrap\\images\\mailpanel")
    botonHightlightCentral.texAR:SetTexCoord((pulsadoIZ+izquierda)/512,(pulsadoIZ+derecha)/512,(pulsadoAR)/512,(pulsadoAR+arriba)/512)
    botonHightlightCentral.texAR:SetPoint("BOTTOM",botonHightlightCentral,"TOP")
    botonHightlightCentral.texAB = botonHightlightCentral:CreateTexture()
    botonHightlightCentral.texAB:SetSize(width-izquierda-(horizontal-derecha),(vertical-abajo))
    botonHightlightCentral.texAB:SetTexture("Interface\\AddOns\\AutoScrap\\images\\mailpanel")
    botonHightlightCentral.texAB:SetTexCoord((pulsadoIZ+izquierda)/512,(pulsadoIZ+derecha)/512,(pulsadoAR+abajo)/512,(pulsadoAB)/512)
    botonHightlightCentral.texAB:SetPoint("TOP",botonHightlightCentral,"BOTTOM")
    



    local buttonPressed=false

    local function OnEnterScript(self, motion)
            --if motion then
            botonHightlightCentral:Show()
            boton.texto.textH:Show()
            boton.texto.text:Hide()
        --end
    end
    local function OnLeaveScript(self, motion)
            --if motion then
                botonHightlightCentral:Hide()
                boton.texto.textH:Hide()
                boton.texto.text:Show()
            --end
    end
    local function OnHideScript(self, ...)
        botonHightlightCentral:Hide()
        boton.texto.textH:Hide()
        boton.texto.text:Show()

    end

    local function OnMouseDownScript(self, button)
        if button=="LeftButton" then
            botonPulsadoCentral:Show()
            botonNormalCentral:Hide()
            botonDesabilitadoCentral:Hide()
            boton.texto.text:SetPoint("CENTER",boton.texto,"CENTER",2,-2)
            boton.texto.textH:SetPoint("CENTER",boton.texto,"CENTER",2,-2)
        end
    end

    local function OnMouseUpScript(self, button)
        if button=="LeftButton" then
            botonPulsadoCentral:Hide()
            botonNormalCentral:Show()
            botonDesabilitadoCentral:Hide()
            boton.texto.text:SetPoint("CENTER",boton.texto,"CENTER",0,0)
            boton.texto.textH:SetPoint("CENTER",boton.texto,"CENTER",0,0)
            if funcionOnClick and type(funcionOnClick) == "function" and GetMouseFocus()==self then
                funcionOnClick()
            end
        end
    end

    boton:SetScript("OnEnter",function (self, motion) OnEnterScript(self, motion) end)
    boton:SetScript("OnLeave",function (self,motion) OnLeaveScript(self, motion) end)
    boton:SetScript("OnHide",function (self,...) OnHideScript (self, ...)end)
    boton:SetScript('OnMouseDown', function (self,button) OnMouseDownScript (self, button) end)
    boton:SetScript('OnMouseUp', function (self,button) OnMouseUpScript (self, button) end)

    function boton:GrayedOut()
        botonPulsadoCentral:Hide()
        botonNormalCentral:Hide()
        botonDesabilitadoCentral:Show()
        botonHightlightCentral:Hide()
        self.texto.textH:Hide()
        self.texto.text:Show()
        self.texto.text:SetPoint("CENTER",boton.texto,"CENTER",0,0)
        self.texto.textH:SetPoint("CENTER",boton.texto,"CENTER",0,0)
        self.texto.text:SetText("|cFF646464"..self.texto.textoGuardado.."|r")
        self:SetScript("OnEnter",nil)
        self:SetScript("OnLeave",nil)
        self:SetScript("OnHide",nil)
        self:SetScript('OnMouseDown',nil)
        self:SetScript('OnMouseUp', nil)
    end

    local function setScriptsAgain(buttonFrame)
        buttonFrame:SetScript("OnEnter",function (self, motion) OnEnterScript(self, motion) end)
        buttonFrame:SetScript("OnLeave",function (self,motion) OnLeaveScript(self, motion) end)
        buttonFrame:SetScript("OnHide",function (self,...) OnHideScript (self, ...)end)
        buttonFrame:SetScript('OnMouseDown', function (self,button) OnMouseDownScript (self, button) end)
        buttonFrame:SetScript('OnMouseUp', function (self,button) OnMouseUpScript (self, button) end)
    end

    function boton:EnableAgain()
        botonPulsadoCentral:Hide()
        botonNormalCentral:Show()
        botonDesabilitadoCentral:Hide()
        botonHightlightCentral:Hide()
        self.texto.textH:Hide()
        self.texto.text:Show()
        self.texto.text:SetPoint("CENTER",boton.texto,"CENTER",0,0)
        self.texto.textH:SetPoint("CENTER",boton.texto,"CENTER",0,0)
        self.texto.text:SetText("|cFF99bec6"..self.texto.textoGuardado.."|r")
        setScriptsAgain(self)
    end
    

    botonPulsadoCentral:Hide()
    botonNormalCentral:Show()
    botonDesabilitadoCentral:Hide()
    botonHightlightCentral:Hide()
    return boton
end


function ns.crearBoton3Fases(parent,source,r,l,t,b,func) --ASMailBoxFrame, "Interface\\AddOns\\AutoScrap\\images\\mailpanel", 0,26,122,158, function () print ("hey") end
    local frame = CreateFrame ("Frame", nil, parent)
    local w,h = l-r, b-t
    frame:SetSize(w,h)
    frame.tex = frame:CreateTexture()
    frame.tex:SetTexture(source)
    frame.tex:SetTexCoord(r/512,l/512,t/512,b/512)
    frame.tex:SetAllPoints(frame)

    frame.enterTex = frame:CreateTexture()
    frame.enterTex:SetTexture(source)
    frame.enterTex:SetTexCoord((r+w)/512,(r+(w*2))/512,t/512,b/512)
    frame.enterTex:SetAllPoints(frame)
    frame.enterTex:Hide()

    frame.pressedTex = frame:CreateTexture()
    frame.pressedTex:SetTexture(source)
    frame.pressedTex:SetTexCoord((r+(w*2))/512,(r+(w*3))/512,t/512,b/512)
    frame.pressedTex:SetAllPoints(frame)
    frame.pressedTex:Hide()

    local pressed = false
    frame:SetScript("OnEnter",function (self,motion)
        --if motion then
            if pressed then
                frame.pressedTex:Show()
                frame.enterTex:Hide()
                frame.tex:Hide()
            else
                frame.enterTex:Show()
                frame.pressedTex:Hide()
                frame.tex:Hide()
            end
        --end
    end)
    frame:SetScript("OnLeave",function (self,motion)
        --if motion then
            frame.pressedTex:Hide()
            frame.enterTex:Hide()
            frame.tex:Show()
        --end
    end)
    frame:SetScript("OnHide",function (self,...)
        frame.pressedTex:Hide()
        frame.enterTex:Hide()
        frame.tex:Show()
        pressed = false
    end)
    frame:SetScript('OnMouseDown', function (self,button)
        if button=="LeftButton" then
            frame.pressedTex:Show()
            frame.enterTex:Hide()
            frame.tex:Hide()
            pressed = true
        end
    end)
    frame:SetScript('OnMouseUp', function (self,button)
        if button=="LeftButton" then
            frame.pressedTex:Hide()
            if self:IsMouseOver() then
                frame.enterTex:Show()
                frame.tex:Hide()
                func()
            else
                frame.enterTex:Hide()
                frame.tex:Show()
            end
            pressed = false
        end
    end)

    return frame
end