local _, ns = ...
local L = ns.L

local outterFrame = CreateFrame ("Frame", nil, UIParent)
local textSize = 50
local topChartHSize = 50
local barW = 2
--[[ local spacing = 5
local resetHSize = 22 ]]
local spacing = 0
local resetHSize = 0
local horizontalSize = 240

function ns.getWindowSizes()
    return horizontalSize,topChartHSize,barW
end

outterFrame:SetSize(horizontalSize+textSize, topChartHSize+spacing+resetHSize)
outterFrame:SetPoint("CENTER")
outterFrame:SetClampedToScreen(true)
outterFrame:SetMovable(true)
outterFrame:SetResizable(false)
outterFrame:EnableMouse(true)
outterFrame:SetToplevel(true)
outterFrame:SetFrameStrata("HIGH")

local function savePosition(frame)
    Inflame_CharSettings.MainWindow.startPoint, _ , Inflame_CharSettings.MainWindow.relativePoint, Inflame_CharSettings.MainWindow.xOffs, Inflame_CharSettings.MainWindow.yOffs = frame:GetPoint()
end
function ns.loadPositionMainW()
    outterFrame:ClearAllPoints()
    outterFrame:SetPoint(Inflame_CharSettings.MainWindow.startPoint,UIParent,Inflame_CharSettings.MainWindow.relativePoint,Inflame_CharSettings.MainWindow.xOffs,Inflame_CharSettings.MainWindow.yOffs)
end

outterFrame:SetScript("OnMouseDown",function (self,button) if button=="LeftButton" then outterFrame:StartMoving() end end) --StartSizing()
outterFrame:SetScript("OnMouseUp",function (self,button) if button=="LeftButton" then outterFrame:StopMovingOrSizing() savePosition(self) end end)

outterFrame.tex = outterFrame:CreateTexture(nil, "BACKGROUND")
outterFrame.tex:SetAllPoints(outterFrame)
outterFrame.tex:SetColorTexture(0/255, 0/255, 0/255 , 0.25); --rgb

outterFrame.bg = ns.Utils.crear9SliceFrame(outterFrame,477, 512, 0, 26, 488, 502, 9, 20, horizontalSize+textSize, topChartHSize, "Interface\\AddOns\\InflameXPGraph\\Images\\mix", 512, 512)
outterFrame.bg:SetPoint("CENTER",-7,5)


local graphW = CreateFrame ("Frame", nil, outterFrame)
graphW:SetSize(horizontalSize+textSize, topChartHSize)
graphW:SetPoint("TOPLEFT")

function ns.getGraphWFrame()
    return graphW
end

--[[ graphW.tex = graphW:CreateTexture(nil, "BACKGROUND")
graphW.tex:SetAllPoints(graphW)
graphW.tex:SetColorTexture(25/255, 80/255, 247/255 , 0.2); --rgb ]]
graphW.max = graphW:CreateFontString (nil, "OVERLAY", "GameFontHighlight")
graphW.max:SetFont("Fonts\\FRIZQT__.TTF", 10, "OUTLINE")
graphW.max:SetJustifyH("RIGHT")
graphW.max:SetText("0")
graphW.max:SetPoint("TOPRIGHT",graphW,"TOPLEFT",textSize,0)

graphW.cero = graphW:CreateFontString (nil, "OVERLAY", "GameFontHighlight")
graphW.cero:SetFont("Fonts\\FRIZQT__.TTF", 10, "OUTLINE")
graphW.cero:SetJustifyH("RIGHT")
graphW.cero:SetText("0")
graphW.cero:SetPoint("BOTTOMRIGHT",graphW,"BOTTOMLEFT",textSize,3)

graphW.totalXP = graphW:CreateFontString (nil, "OVERLAY", "GameFontHighlight")
graphW.totalXP:SetFont("Fonts\\FRIZQT__.TTF", 10, "OUTLINE")
graphW.totalXP:SetJustifyH("CENTER")
graphW.totalXP:SetText("0 XP/H")
graphW.totalXP:SetPoint("CENTER",graphW,"CENTER",0,3)

graphW.timeRangeMessage = graphW:CreateFontString (nil, "OVERLAY", "GameFontHighlight")
graphW.timeRangeMessage:SetFont("Fonts\\FRIZQT__.TTF", 10, "OUTLINE")
graphW.timeRangeMessage:SetJustifyH("CENTER")
graphW.timeRangeMessage:SetText(L["Time:"])
graphW.timeRangeMessage:SetPoint("TOP",graphW.totalXP,"BOTTOM",0,-3)
graphW.timeRangeMessage:Hide()


graphW.texturaRangoSeleccionado = graphW:CreateTexture(nil, "BACKGROUND")
graphW.texturaRangoSeleccionado:SetSize(horizontalSize, 1)
graphW.texturaRangoSeleccionado:SetPoint("TOPRIGHT")
graphW.texturaRangoSeleccionado:SetColorTexture(255/255, 150/255, 0/255 , 1) -- naranja
graphW.texturaRangoSeleccionado:Hide()

graphW.top = ns.Utils.crearFrameConTextura (graphW, 212, 512, 465, 512, 1, "Interface\\AddOns\\InflameXPGraph\\Images\\mix")
graphW.top:SetSize(horizontalSize+textSize, topChartHSize)
graphW.top:SetPoint("CENTER",0,-3)

--[[ graphW.nextLevel = graphW:CreateFontString (nil, "OVERLAY", "GameFontHighlight")
graphW.nextLevel:SetFont("Fonts\\FRIZQT__.TTF", 10, "OUTLINE")
graphW.nextLevel:SetJustifyH("CENTER")
graphW.nextLevel:SetText("Level in: 4h 2s")
graphW.nextLevel:SetPoint("TOP",graphW.totalXP,"BOTTOM",0,-3) ]]

--[[ local resetW = CreateFrame ("Frame", nil, outterFrame) --MIRAR EL disableGraph
resetW:SetSize(horizontalSize+textSize, resetHSize)
resetW:SetPoint("BOTTOMLEFT")
resetW.tex = resetW:CreateTexture(nil, "BACKGROUND")
resetW.tex:SetAllPoints(resetW)
resetW.tex:SetColorTexture(125/255, 180/255, 47/255 , 0.2); --rgb ]]


local resetGraph = ns.crearBoton3Fases(graphW,"Interface\\AddOns\\InflameXPGraph\\Images\\mix",0,27,117,145,function ()
    Inflame_CharSettings.data = {}
    ns.updateUI()
end)
resetGraph:SetScale(0.6)
resetGraph:SetPoint("LEFT",graphW,"LEFT",14,2)

function ns.getResetGraph()
    return resetGraph
end

function ns.setTooltip(parentFrame,...)
    local text1,text2,text3,text4=...
    parentFrame:HookScript("OnEnter", function(self)
        GameTooltip:SetOwner( parentFrame, "ANCHOR_NONE" );
        GameTooltip:SetPoint("TOP", resetGraph, "BOTTOM", 0, -5)
        if text1 then
        --print(HIGHLIGHT_FONT_COLOR_CODE..text1..FONT_COLOR_CODE_CLOSE)
            GameTooltip:AddLine(NORMAL_FONT_COLOR_CODE..text1..FONT_COLOR_CODE_CLOSE,1,0,0,true)
        end
        if text2 then
            GameTooltip:AddLine(HIGHLIGHT_FONT_COLOR_CODE..text2..FONT_COLOR_CODE_CLOSE,1,0,0,true)
        end
        if text3 then
            GameTooltip:AddLine(HIGHLIGHT_FONT_COLOR_CODE..text3..FONT_COLOR_CODE_CLOSE,1,0,0,true)
        end
        if text4 then
            GameTooltip:AddLine(HIGHLIGHT_FONT_COLOR_CODE..text4..FONT_COLOR_CODE_CLOSE,1,0,0,true)
        end
        --AutoScrapTooltip:AddDoubleLine("prob", "lala")
        GameTooltip:Show()
    end)
    parentFrame:HookScript("OnLeave", function(self)
        GameTooltip:Hide()
    end)
end

local isGraph, isInstance = true, true
graphW.top:Hide()
outterFrame.bg:Hide()
local neverShow = false
local function disableGraph()
    isGraph = false
    graphW:Hide()
    outterFrame.bg:Hide()
    graphW.top:Hide()
--[[     resetW:ClearAllPoints()
    resetW:SetPoint("TOPLEFT") ]]
    outterFrame:SetSize(horizontalSize+textSize, resetHSize)
    outterFrame.tex:Hide()
    outterFrame:Hide()
    ns.finishGraphFrameCode()
    ns.finishTimer()
    ns.disableMapIcon()
    neverShow = true
end
ns.disableTheAddon = disableGraph

function ns.loadWindowSetup()
    --if MAX_PLAYER_LEVEL_TABLE[GetAccountExpansionLevel()] == UnitLevel("player") then --not working on burning ??  it says 60.
    if GetMaxPlayerLevel() == UnitLevel("player") then -- también añadido en al funcion de newdata por si sube de nivel al 70 mientas juega
        disableGraph()
    else
        ns.startInitGraphFrameCode()
    end
end

outterFrame:Hide()
local isVisible = false
local function setVisible()
    if neverShow then
        return
    end
    outterFrame:Show()
    isVisible = true
    Inflame_CharSettings.isVisible = true
    ns.updateUI()
end
local function setEscondido()
    outterFrame:Hide()
    isVisible = false
    Inflame_CharSettings.isVisible = false
    ns.cancelarSeleccionSiActiva() -- si se escondepara la selección de rango
end

function ns.toogleOutterFrame()
    if isVisible then
        setEscondido()
    else
        setVisible()
    end
end

function ns.setVisible(flag)
    if flag then
        setVisible()
    else
        setEscondido()
    end
    
end

local textureData

textureData={}
for i=1,120 do
    textureData[i] = graphW:CreateTexture(nil, "BACKGROUND")
    textureData[i]:SetSize(barW,10)
    --textureData[i]:SetColorTexture(255/255, 150/255, 0/255 , 1) --naranja
    textureData[i]:SetColorTexture(13/255, 44/255, 214/255 , 1) -- azul electrico
    if i == 1 then
        textureData[i]:SetPoint("BOTTOMRIGHT",graphW,"BOTTOMRIGHT",0,0)
    else
        textureData[i]:SetPoint("BOTTOMRIGHT",textureData[i-1],"BOTTOMLEFT",0,0)
    end
    textureData[i]:Hide()
end

function ns.setTextureColors()
    for i=1,120 do
        if ns.isRangeSelected() then
            if (i<=ns.barritaSelectIz() and i>= ns.barritaSelectDer()) then
                textureData[i]:SetColorTexture(255/255, 150/255, 0/255 , 1) --naranja
            else
                textureData[i]:SetColorTexture(50/255, 50/255, 50/255 , 1) --gris
            end
        else
            textureData[i]:SetColorTexture(13/255, 44/255, 214/255 , 1) -- azul electrico
        end
    end
end

local function numberBeauty(n)
    if n >= 10^6 then
        return string.format("%.2fM", n / 10^6)
    elseif n >= 10^3 then
        return string.format("%.2fK", n / 10^3)
    else
        return tostring(n)
    end
end

function escribirSeleccionadoData()
    graphW.totalXP:SetText(L["Select range here.."])
end

function ns.escribirTime(barritaIz, barritaDer)
    local tiempoEntreBarras = (barritaIz-barritaDer+1) * 30
    -- print("llamando", barritaIz,barritaDer, tiempoEntreBarras)
    graphW.timeRangeMessage:Show()
    graphW.timeRangeMessage:SetText(L["Time: "]..ns.Utils.horaBonita(tiempoEntreBarras))
end

function   ns.updateUI()
    if isVisible then
        local lastI = 1
        if isGraph then
            local maxRange = 1
            local any = false
            local totalXP,count  = 0,0
            local anyInsideRange = false
            local maxKselected = 0
            for k,v in ipairs(Inflame_CharSettings.data) do
                if ns.isRangeSelected() then
                    if (k<=ns.barritaSelectIz() and k>= ns.barritaSelectDer()) then
                        totalXP = totalXP + v.value
                        count = count + 1
                    end
                    if k > maxKselected and k<=ns.barritaSelectIz() then
                        maxKselected = k
                    end
                else
                    totalXP = totalXP + v.value
                    count = count + 1
                end
                if v.value > maxRange then
                    maxRange = v.value
                end
                if v.value > 0 then
                    any = true
                end
            end
            if any then
                graphW.max:SetText(numberBeauty(maxRange))
                if count > 0 then
                    graphW.totalXP:SetText(numberBeauty((math.floor((totalXP/count)*(3600/30)))).." XP/H")
                else
                    graphW.totalXP:SetText("0 XP/H")
                end
                --graphW.totalXP:Show()
                graphW.max:Show()
                graphW.cero:Show()
                resetGraph:Show()
                --esto casi nunca se ejecuta, solo si se genera una barra mientras se selecciona, para que mantenga el texto
                --usar codigo de show de partes extras en ns.seleccionadoRango()
                if ns.seleccionandoYNoSeleccionado() then
                    escribirSeleccionadoData()
                else
                    graphW.timeRangeMessage:Hide()
                    graphW.texturaRangoSeleccionado:Hide()
                end
                if ns.isRangeSelected() then
                    graphW.texturaRangoSeleccionado:ClearAllPoints()

                    --nota, la iz en realidad es mide desde la primera barrita. solo por la derecha se miden las barras en 0
                    graphW.texturaRangoSeleccionado:SetSize(((maxKselected - ns.barritaSelectDer()+1)*barW),1)
                    graphW.texturaRangoSeleccionado:SetPoint("TOPRIGHT",(1-ns.barritaSelectDer())*barW,0)
                    -- print(ns.barritaSelectIz(),horizontalSize, ((120-ns.barritaSelectIz())*barW))
                    graphW.texturaRangoSeleccionado:Show()
                else
                    graphW.texturaRangoSeleccionado:Hide()
                end

            else
                graphW.max:SetText(0)
                graphW.totalXP:SetText(L["No data, kill something."])
                --graphW.totalXP:Hide()
                graphW.max:Hide()
                graphW.cero:Hide()
                ns.cancelarSeleccionSiActiva()
                graphW.timeRangeMessage:Hide()
                graphW.texturaRangoSeleccionado:Hide()
                resetGraph:Hide()
            end
            for k,v in pairs (textureData) do
                if Inflame_CharSettings.data[k] then
                    local alto = (((Inflame_CharSettings.data[k].value*100)/maxRange)/100) * topChartHSize
                    if math.floor(alto) > 0 then
                        textureData[k]:SetSize(barW,alto)

                        -- -- --barritas seleccionadas nuevo sistema
                        -- if ns.isRangeSelected() and (k<=ns.barritaSelectIz() and k>= ns.barritaSelectDer())then
                        --     textureData[k]:SetColorTexture(255/255, 150/255, 0/255 , 1) --naranja
                        -- end

                        textureData[k]:Show()
                    else
                        textureData[k]:Hide()
                    end
                else
                    textureData[k]:Hide()
                end
            end
        end
    end
end

ns.setTooltip(resetGraph,L["Reset all Data in the Graph"])