
local TIER_ARMOR_TOKEN_ZONES = [[
24544 Magtheridon's Lair
24545 Karazhan
24546 Gruul's Lair
24547 Gruul's Lair
24549 Karazhan
24552 Magtheridon's Lair
24553 Karazhan
24554 Gruul's Lair
24555 Gruul's Lair
24556 Karazhan
25830 Karazhan
25831 Magtheridon's Lair
25832 Gruul's Lair
25833 Gruul's Lair
25834 Karazhan
25854 Gruul's Lair
25855 Karazhan
25856 Magtheridon's Lair
25857 Karazhan
25858 Gruul's Lair
25997 Magtheridon's Lair
25998 Karazhan
25999 Gruul's Lair
26000 Karazhan
26001 Gruul's Lair
27469 Magtheridon's Lair
27470 Karazhan
27471 Karazhan
27472 Gruul's Lair
27473 Gruul's Lair
27702 Magtheridon's Lair
27703 Karazhan
27704 Karazhan
27705 Gruul's Lair
27706 Gruul's Lair
27707 Karazhan
27708 Karazhan
27709 Gruul's Lair
27710 Gruul's Lair
27711 Magtheridon's Lair
27879 Magtheridon's Lair
27880 Karazhan
27881 Karazhan
27882 Gruul's Lair
27883 Gruul's Lair
28126 Karazhan
28127 Karazhan
28128 Gruul's Lair
28129 Gruul's Lair
28130 Magtheridon's Lair
28136 Karazhan
28137 Karazhan
28138 Gruul's Lair
28139 Gruul's Lair
28140 Magtheridon's Lair
28331 Karazhan
28332 Gruul's Lair
28333 Gruul's Lair
28334 Magtheridon's Lair
28335 Karazhan
28963 Karazhan
28964 Magtheridon's Lair
28966 Gruul's Lair
28967 Gruul's Lair
28968 Karazhan
29011 Karazhan
29012 Magtheridon's Lair
29015 Gruul's Lair
29016 Gruul's Lair
29017 Karazhan
29019 Magtheridon's Lair
29020 Karazhan
29021 Karazhan
29022 Gruul's Lair
29023 Gruul's Lair
29028 Karazhan
29029 Magtheridon's Lair
29030 Gruul's Lair
29031 Gruul's Lair
29032 Karazhan
29033 Magtheridon's Lair
29034 Karazhan
29035 Karazhan
29036 Gruul's Lair
29037 Gruul's Lair
29038 Magtheridon's Lair
29039 Karazhan
29040 Karazhan
29042 Gruul's Lair
29043 Gruul's Lair
29044 Karazhan
29045 Magtheridon's Lair
29046 Gruul's Lair
29047 Gruul's Lair
29048 Karazhan
29049 Karazhan
29050 Magtheridon's Lair
29053 Gruul's Lair
29054 Gruul's Lair
29055 Karazhan
29056 Magtheridon's Lair
29057 Karazhan
29058 Karazhan
29059 Gruul's Lair
29060 Gruul's Lair
29061 Karazhan
29062 Magtheridon's Lair
29063 Gruul's Lair
29064 Gruul's Lair
29065 Karazhan
29066 Magtheridon's Lair
29067 Karazhan
29068 Karazhan
29069 Gruul's Lair
29070 Gruul's Lair
29071 Magtheridon's Lair
29072 Karazhan
29073 Karazhan
29074 Gruul's Lair
29075 Gruul's Lair
29076 Karazhan
29077 Magtheridon's Lair
29078 Gruul's Lair
29079 Gruul's Lair
29080 Karazhan
29081 Karazhan
29082 Magtheridon's Lair
29083 Gruul's Lair
29084 Gruul's Lair
29085 Karazhan
29086 Karazhan
29087 Magtheridon's Lair
29088 Gruul's Lair
29089 Gruul's Lair
29090 Karazhan
29091 Magtheridon's Lair
29092 Karazhan
29093 Karazhan
29094 Gruul's Lair
29095 Gruul's Lair
29096 Magtheridon's Lair
29097 Karazhan
29098 Karazhan
29099 Gruul's Lair
29100 Gruul's Lair
30113 The Eye
30114 Serpentshrine Cavern
30115 Serpentshrine Cavern
30116 Serpentshrine Cavern
30117 The Eye
30118 The Eye
30119 Serpentshrine Cavern
30120 Serpentshrine Cavern
30121 Serpentshrine Cavern
30122 The Eye
30123 The Eye
30124 Serpentshrine Cavern
30125 Serpentshrine Cavern
30126 Serpentshrine Cavern
30127 The Eye
30129 The Eye
30130 Serpentshrine Cavern
30131 Serpentshrine Cavern
30132 Serpentshrine Cavern
30133 The Eye
30134 The Eye
30135 Serpentshrine Cavern
30136 Serpentshrine Cavern
30137 Serpentshrine Cavern
30138 The Eye
30139 The Eye
30140 Serpentshrine Cavern
30141 Serpentshrine Cavern
30142 Serpentshrine Cavern
30143 The Eye
30144 The Eye
30145 Serpentshrine Cavern
30146 Serpentshrine Cavern
30148 Serpentshrine Cavern
30149 The Eye
30150 The Eye
30151 Serpentshrine Cavern
30152 Serpentshrine Cavern
30153 Serpentshrine Cavern
30154 The Eye
30159 The Eye
30160 Serpentshrine Cavern
30161 Serpentshrine Cavern
30162 Serpentshrine Cavern
30163 The Eye
30164 The Eye
30165 Serpentshrine Cavern
30166 Serpentshrine Cavern
30167 Serpentshrine Cavern
30168 The Eye
30169 The Eye
30170 Serpentshrine Cavern
30171 Serpentshrine Cavern
30172 Serpentshrine Cavern
30173 The Eye
30185 The Eye
30186 Gruul's Lair
30187 Karazhan
30188 Karazhan
30189 Serpentshrine Cavern
30190 Serpentshrine Cavern
30192 Serpentshrine Cavern
30194 The Eye
30196 The Eye
30200 Magtheridon's Lair
30201 Gruul's Lair
30205 Serpentshrine Cavern
30206 Serpentshrine Cavern
30207 Serpentshrine Cavern
30210 The Eye
30211 Serpentshrine Cavern
30212 Serpentshrine Cavern
30213 Serpentshrine Cavern
30214 The Eye
30215 The Eye
30216 The Eye
30217 Serpentshrine Cavern
30219 Serpentshrine Cavern
30220 Serpentshrine Cavern
30221 The Eye
30222 The Eye
30223 Serpentshrine Cavern
30228 Serpentshrine Cavern
30229 Serpentshrine Cavern
30230 The Eye
30231 The Eye
30232 Serpentshrine Cavern
30233 Serpentshrine Cavern
30234 Serpentshrine Cavern
30235 The Eye
30486 The Eye
30487 Serpentshrine Cavern
30488 Serpentshrine Cavern
30489 Serpentshrine Cavern
30490 The Eye
30969 Hyjal Summit
30970 Hyjal Summit
30972 Hyjal Summit
30974 Hyjal Summit
30975 Black Temple
30976 Black Temple
30977 Black Temple
30978 Black Temple
30979 Black Temple
30980 Black Temple
30982 Hyjal Summit
30983 Hyjal Summit
30985 Hyjal Summit
30987 Hyjal Summit
30988 Hyjal Summit
30989 Hyjal Summit
30990 Black Temple
30991 Black Temple
30992 Black Temple
30993 Black Temple
30994 Black Temple
30995 Black Temple
30996 Black Temple
30997 Black Temple
30998 Black Temple
31001 Hyjal Summit
31003 Hyjal Summit
31004 Black Temple
31005 Black Temple
31006 Black Temple
31007 Hyjal Summit
31008 Hyjal Summit
31011 Hyjal Summit
31012 Hyjal Summit
31014 Hyjal Summit
31015 Hyjal Summit
31016 Black Temple
31017 Black Temple
31018 Black Temple
31019 Black Temple
31020 Black Temple
31021 Black Temple
31022 Black Temple
31023 Black Temple
31024 Black Temple
31026 Hyjal Summit
31027 Hyjal Summit
31028 Black Temple
31029 Black Temple
31030 Black Temple
31032 Hyjal Summit
31034 Hyjal Summit
31035 Hyjal Summit
31037 Hyjal Summit
31039 Hyjal Summit
31040 Hyjal Summit
31041 Black Temple
31042 Black Temple
31043 Black Temple
31044 Black Temple
31045 Black Temple
31046 Black Temple
31047 Black Temple
31048 Black Temple
31049 Black Temple
31050 Hyjal Summit
31051 Hyjal Summit
31052 Black Temple
31053 Black Temple
31054 Black Temple
31055 Hyjal Summit
31056 Hyjal Summit
31057 Black Temple
31058 Black Temple
31059 Black Temple
31060 Hyjal Summit
31061 Hyjal Summit
31063 Hyjal Summit
31064 Hyjal Summit
31065 Black Temple
31066 Black Temple
31067 Black Temple
31068 Black Temple
31069 Black Temple
31070 Black Temple
31375 Karazhan
31376 Karazhan
31377 Gruul's Lair
31378 Gruul's Lair
31379 Magtheridon's Lair
31396 Magtheridon's Lair
31397 Karazhan
31400 Karazhan
31406 Gruul's Lair
31407 Gruul's Lair
31409 Karazhan
31410 Karazhan
31411 Gruul's Lair
31412 Gruul's Lair
31413 Magtheridon's Lair
31613 Magtheridon's Lair
31614 Karazhan
31616 Karazhan
31618 Gruul's Lair
31619 Gruul's Lair
31960 The Eye
31961 Serpentshrine Cavern
31962 Serpentshrine Cavern
31963 Serpentshrine Cavern
31964 The Eye
31967 Serpentshrine Cavern
31968 Serpentshrine Cavern
31969 Serpentshrine Cavern
31971 The Eye
31972 The Eye
31973 Serpentshrine Cavern
31974 Serpentshrine Cavern
31975 Serpentshrine Cavern
31976 The Eye
31977 The Eye
31979 The Eye
31980 Serpentshrine Cavern
31981 Serpentshrine Cavern
31982 The Eye
31983 Serpentshrine Cavern
31987 Serpentshrine Cavern
31988 Serpentshrine Cavern
31989 Serpentshrine Cavern
31990 The Eye
31991 The Eye
31992 The Eye
31993 Serpentshrine Cavern
31995 Serpentshrine Cavern
31996 The Eye
31997 Serpentshrine Cavern
31998 Serpentshrine Cavern
31999 Serpentshrine Cavern
32000 Serpentshrine Cavern
32001 The Eye
32002 The Eye
32004 The Eye
32005 Serpentshrine Cavern
32006 Serpentshrine Cavern
32007 Serpentshrine Cavern
32008 The Eye
32009 The Eye
32010 Serpentshrine Cavern
32011 Serpentshrine Cavern
32012 Serpentshrine Cavern
32013 The Eye
32015 Serpentshrine Cavern
32016 Serpentshrine Cavern
32017 Serpentshrine Cavern
32018 The Eye
32019 The Eye
32020 The Eye
32021 Serpentshrine Cavern
32022 Serpentshrine Cavern
32023 Serpentshrine Cavern
32024 The Eye
32029 The Eye
32030 Serpentshrine Cavern
32031 Serpentshrine Cavern
32032 Serpentshrine Cavern
32033 The Eye
32034 Serpentshrine Cavern
32035 Serpentshrine Cavern
32036 Serpentshrine Cavern
32037 The Eye
32038 The Eye
32039 The Eye
32040 Serpentshrine Cavern
32041 Serpentshrine Cavern
32042 Serpentshrine Cavern
32043 The Eye
32047 The Eye
32048 Serpentshrine Cavern
32049 Serpentshrine Cavern
32050 The Eye
32051 Serpentshrine Cavern
32056 Serpentshrine Cavern
32057 Serpentshrine Cavern
32058 Serpentshrine Cavern
32059 The Eye
32060 The Eye
33811 Sunwell Plateau
33812 Sunwell Plateau
33813 Sunwell Plateau
33876 Sunwell Plateau
33877 Sunwell Plateau
33878 Sunwell Plateau
33879 Sunwell Plateau
33880 Sunwell Plateau
33881 Sunwell Plateau
33882 Sunwell Plateau
33883 Sunwell Plateau
33884 Sunwell Plateau
33885 Sunwell Plateau
33886 Sunwell Plateau
33887 Sunwell Plateau
33888 Sunwell Plateau
33889 Sunwell Plateau
33890 Sunwell Plateau
33891 Sunwell Plateau
33892 Sunwell Plateau
33893 Sunwell Plateau
33894 Sunwell Plateau
33895 Sunwell Plateau
33896 Sunwell Plateau
33897 Sunwell Plateau
33898 Sunwell Plateau
33899 Sunwell Plateau
33900 Sunwell Plateau
33901 Sunwell Plateau
33902 Sunwell Plateau
33903 Sunwell Plateau
33904 Sunwell Plateau
33905 Sunwell Plateau
33906 Sunwell Plateau
33907 Sunwell Plateau
33908 Sunwell Plateau
33909 Sunwell Plateau
33910 Sunwell Plateau
33911 Sunwell Plateau
33912 Sunwell Plateau
33913 Sunwell Plateau
33914 Sunwell Plateau
33915 Sunwell Plateau
33916 Sunwell Plateau
33917 Sunwell Plateau
34431 Sunwell Plateau
34432 Sunwell Plateau
34433 Sunwell Plateau
34434 Sunwell Plateau
34435 Sunwell Plateau
34436 Sunwell Plateau
34437 Sunwell Plateau
34438 Sunwell Plateau
34439 Sunwell Plateau
34441 Sunwell Plateau
34442 Sunwell Plateau
34443 Sunwell Plateau
34444 Sunwell Plateau
34445 Sunwell Plateau
34446 Sunwell Plateau
34447 Sunwell Plateau
34448 Sunwell Plateau
34485 Sunwell Plateau
34487 Sunwell Plateau
34488 Sunwell Plateau
34527 Sunwell Plateau
34528 Sunwell Plateau
34541 Sunwell Plateau
34542 Sunwell Plateau
34543 Sunwell Plateau
34545 Sunwell Plateau
34546 Sunwell Plateau
34547 Sunwell Plateau
34549 Sunwell Plateau
34554 Sunwell Plateau
34555 Sunwell Plateau
34556 Sunwell Plateau
34557 Sunwell Plateau
34558 Sunwell Plateau
34559 Sunwell Plateau
34560 Sunwell Plateau
34561 Sunwell Plateau
34562 Sunwell Plateau
34563 Sunwell Plateau
34564 Sunwell Plateau
34565 Sunwell Plateau
34566 Sunwell Plateau
34567 Sunwell Plateau
34568 Sunwell Plateau
34569 Sunwell Plateau
34570 Sunwell Plateau
34571 Sunwell Plateau
34572 Sunwell Plateau
34573 Sunwell Plateau
34574 Sunwell Plateau
34575 Sunwell Plateau
]]

Engravings["Token dropped in:"] = setmetatable({}, {
	__index = function(t,i)
		local v = TIER_ARMOR_TOKEN_ZONES:match("\n"..i.." ([^\n]+)\n")
		if v then t[i] = v; return v
		else t[i] = false; return end
	end
})
