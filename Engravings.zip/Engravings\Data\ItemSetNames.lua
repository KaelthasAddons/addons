
local ITEM_SET_NAMES = [[
24544 Season 1
24545 Season 1
24546 Season 1
24547 Season 1
24549 Season 1
24550 Season 1
24552 Season 1
24553 Season 1
24554 Season 1
24555 Season 1
24556 Season 1
24557 Season 1
25830 Season 1
25831 Season 1
25832 Season 1
25833 Season 1
25834 Season 1
25854 Season 1
25855 Season 1
25856 Season 1
25857 Season 1
25858 Season 1
25997 Season 1
25998 Season 1
25999 Season 1
26000 Season 1
26001 Season 1
27469 Season 1
27470 Season 1
27471 Season 1
27472 Season 1
27473 Season 1
27702 Season 1
27703 Season 1
27704 Season 1
27705 Season 1
27706 Season 1
27707 Season 1
27708 Season 1
27709 Season 1
27710 Season 1
27711 Season 1
27879 Season 1
27880 Season 1
27881 Season 1
27882 Season 1
27883 Season 1
28126 Season 1
28127 Season 1
28128 Season 1
28129 Season 1
28130 Season 1
28136 Season 1
28137 Season 1
28138 Season 1
28139 Season 1
28140 Season 1
28294 Season 1
28295 Season 1
28297 Season 1
28298 Season 1
28299 Season 1
28300 Season 1
28302 Season 1
28305 Season 1
28307 Season 1
28308 Season 1
28309 Season 1
28310 Season 1
28312 Season 1
28313 Season 1
28314 Season 1
28319 Season 1
28320 Season 1
28331 Season 1
28332 Season 1
28333 Season 1
28334 Season 1
28335 Season 1
28346 Season 1
28355 Season 1
28356 Season 1
28357 Season 1
28358 Season 1
28476 Season 1
28963 Tier 4
28964 Tier 4
28966 Tier 4
28967 Tier 4
28968 Tier 4
29011 Tier 4
29012 Tier 4
29015 Tier 4
29016 Tier 4
29017 Tier 4
29019 Tier 4
29020 Tier 4
29021 Tier 4
29022 Tier 4
29023 Tier 4
29028 Tier 4
29029 Tier 4
29030 Tier 4
29031 Tier 4
29032 Tier 4
29033 Tier 4
29034 Tier 4
29035 Tier 4
29036 Tier 4
29037 Tier 4
29038 Tier 4
29039 Tier 4
29040 Tier 4
29042 Tier 4
29043 Tier 4
29044 Tier 4
29045 Tier 4
29046 Tier 4
29047 Tier 4
29048 Tier 4
29049 Tier 4
29050 Tier 4
29053 Tier 4
29054 Tier 4
29055 Tier 4
29056 Tier 4
29057 Tier 4
29058 Tier 4
29059 Tier 4
29060 Tier 4
29061 Tier 4
29062 Tier 4
29063 Tier 4
29064 Tier 4
29065 Tier 4
29066 Tier 4
29067 Tier 4
29068 Tier 4
29069 Tier 4
29070 Tier 4
29071 Tier 4
29072 Tier 4
29073 Tier 4
29074 Tier 4
29075 Tier 4
29076 Tier 4
29077 Tier 4
29078 Tier 4
29079 Tier 4
29080 Tier 4
29081 Tier 4
29082 Tier 4
29083 Tier 4
29084 Tier 4
29085 Tier 4
29086 Tier 4
29087 Tier 4
29088 Tier 4
29089 Tier 4
29090 Tier 4
29091 Tier 4
29092 Tier 4
29093 Tier 4
29094 Tier 4
29095 Tier 4
29096 Tier 4
29097 Tier 4
29098 Tier 4
29099 Tier 4
29100 Tier 4
30113 Tier 5
30114 Tier 5
30115 Tier 5
30116 Tier 5
30117 Tier 5
30118 Tier 5
30119 Tier 5
30120 Tier 5
30121 Tier 5
30122 Tier 5
30123 Tier 5
30124 Tier 5
30125 Tier 5
30126 Tier 5
30127 Tier 5
30129 Tier 5
30130 Tier 5
30131 Tier 5
30132 Tier 5
30133 Tier 5
30134 Tier 5
30135 Tier 5
30136 Tier 5
30137 Tier 5
30138 Tier 5
30139 Tier 5
30140 Tier 5
30141 Tier 5
30142 Tier 5
30143 Tier 5
30144 Tier 5
30145 Tier 5
30146 Tier 5
30148 Tier 5
30149 Tier 5
30150 Tier 5
30151 Tier 5
30152 Tier 5
30153 Tier 5
30154 Tier 5
30159 Tier 5
30160 Tier 5
30161 Tier 5
30162 Tier 5
30163 Tier 5
30164 Tier 5
30165 Tier 5
30166 Tier 5
30167 Tier 5
30168 Tier 5
30169 Tier 5
30170 Tier 5
30171 Tier 5
30172 Tier 5
30173 Tier 5
30185 Tier 5
30186 Season 1
30187 Season 1
30188 Season 1
30189 Tier 5
30190 Tier 5
30192 Tier 5
30194 Tier 5
30196 Tier 5
30200 Season 1
30201 Season 1
30205 Tier 5
30206 Tier 5
30207 Tier 5
30210 Tier 5
30211 Tier 5
30212 Tier 5
30213 Tier 5
30214 Tier 5
30215 Tier 5
30216 Tier 5
30217 Tier 5
30219 Tier 5
30220 Tier 5
30221 Tier 5
30222 Tier 5
30223 Tier 5
30228 Tier 5
30229 Tier 5
30230 Tier 5
30231 Tier 5
30232 Tier 5
30233 Tier 5
30234 Tier 5
30235 Tier 5
30486 Season 2
30487 Season 2
30488 Season 2
30489 Season 2
30490 Season 2
30969 Tier 6
30970 Tier 6
30972 Tier 6
30974 Tier 6
30975 Tier 6
30976 Tier 6
30977 Tier 6
30978 Tier 6
30979 Tier 6
30980 Tier 6
30982 Tier 6
30983 Tier 6
30985 Tier 6
30987 Tier 6
30988 Tier 6
30989 Tier 6
30990 Tier 6
30991 Tier 6
30992 Tier 6
30993 Tier 6
30994 Tier 6
30995 Tier 6
30996 Tier 6
30997 Tier 6
30998 Tier 6
31001 Tier 6
31003 Tier 6
31004 Tier 6
31005 Tier 6
31006 Tier 6
31007 Tier 6
31008 Tier 6
31011 Tier 6
31012 Tier 6
31014 Tier 6
31015 Tier 6
31016 Tier 6
31017 Tier 6
31018 Tier 6
31019 Tier 6
31020 Tier 6
31021 Tier 6
31022 Tier 6
31023 Tier 6
31024 Tier 6
31026 Tier 6
31027 Tier 6
31028 Tier 6
31029 Tier 6
31030 Tier 6
31032 Tier 6
31034 Tier 6
31035 Tier 6
31037 Tier 6
31039 Tier 6
31040 Tier 6
31041 Tier 6
31042 Tier 6
31043 Tier 6
31044 Tier 6
31045 Tier 6
31046 Tier 6
31047 Tier 6
31048 Tier 6
31049 Tier 6
31050 Tier 6
31051 Tier 6
31052 Tier 6
31053 Tier 6
31054 Tier 6
31055 Tier 6
31056 Tier 6
31057 Tier 6
31058 Tier 6
31059 Tier 6
31060 Tier 6
31061 Tier 6
31063 Tier 6
31064 Tier 6
31065 Tier 6
31066 Tier 6
31067 Tier 6
31068 Tier 6
31069 Tier 6
31070 Tier 6
31375 Season 1
31376 Season 1
31377 Season 1
31378 Season 1
31379 Season 1
31396 Season 1
31397 Season 1
31400 Season 1
31406 Season 1
31407 Season 1
31409 Season 1
31410 Season 1
31411 Season 1
31412 Season 1
31413 Season 1
31613 Season 1
31614 Season 1
31616 Season 1
31618 Season 1
31619 Season 1
31958 Season 2
31959 Season 2
31960 Season 2
31961 Season 2
31962 Season 2
31963 Season 2
31964 Season 2
31965 Season 2
31966 Season 2
31967 Season 2
31968 Season 2
31969 Season 2
31971 Season 2
31972 Season 2
31973 Season 2
31974 Season 2
31975 Season 2
31976 Season 2
31977 Season 2
31978 Season 2
31979 Season 2
31980 Season 2
31981 Season 2
31982 Season 2
31983 Season 2
31984 Season 2
31985 Season 2
31986 Season 2
31987 Season 2
31988 Season 2
31989 Season 2
31990 Season 2
31991 Season 2
31992 Season 2
31993 Season 2
31995 Season 2
31996 Season 2
31997 Season 2
31998 Season 2
31999 Season 2
32000 Season 2
32001 Season 2
32002 Season 2
32003 Season 2
32004 Season 2
32005 Season 2
32006 Season 2
32007 Season 2
32008 Season 2
32009 Season 2
32010 Season 2
32011 Season 2
32012 Season 2
32013 Season 2
32014 Season 2
32015 Season 2
32016 Season 2
32017 Season 2
32018 Season 2
32019 Season 2
32020 Season 2
32021 Season 2
32022 Season 2
32023 Season 2
32024 Season 2
32025 Season 2
32026 Season 2
32027 Season 2
32028 Season 2
32029 Season 2
32030 Season 2
32031 Season 2
32032 Season 2
32033 Season 2
32034 Season 2
32035 Season 2
32036 Season 2
32037 Season 2
32038 Season 2
32039 Season 2
32040 Season 2
32041 Season 2
32042 Season 2
32043 Season 2
32044 Season 2
32045 Season 2
32046 Season 2
32047 Season 2
32048 Season 2
32049 Season 2
32050 Season 2
32051 Season 2
32052 Season 2
32053 Season 2
32054 Season 2
32055 Season 2
32056 Season 2
32057 Season 2
32058 Season 2
32059 Season 2
32060 Season 2
32450 Season 1
32451 Season 1
32452 Season 1
32785 Season 2 Non-set
32786 Season 2 Non-set
32787 Season 2 Non-set
32788 Season 2 Non-set
32789 Season 2 Non-set
32790 Season 2 Non-set
32791 Season 2 Non-set
32792 Season 2 Non-set
32793 Season 2 Non-set
32794 Season 2 Non-set
32795 Season 2 Non-set
32796 Season 2 Non-set
32797 Season 2 Non-set
32798 Season 2 Non-set
32799 Season 2 Non-set
32800 Season 2 Non-set
32801 Season 2 Non-set
32802 Season 2 Non-set
32803 Season 2 Non-set
32804 Season 2 Non-set
32805 Season 2 Non-set
32806 Season 2 Non-set
32807 Season 2 Non-set
32808 Season 2 Non-set
32809 Season 2 Non-set
32810 Season 2 Non-set
32811 Season 2 Non-set
32812 Season 2 Non-set
32813 Season 2 Non-set
32814 Season 2 Non-set
32816 Season 2 Non-set
32817 Season 2 Non-set
32818 Season 2 Non-set
32819 Season 2 Non-set
32820 Season 2 Non-set
32821 Season 2 Non-set
32961 Season 2
32962 Season 2
32963 Season 2
32964 Season 2
32979 Season 2 Non-set
32980 Season 2 Non-set
32981 Season 2 Non-set
32988 Season 2 Non-set
32989 Season 2 Non-set
32990 Season 2 Non-set
32997 Season 2 Non-set
32998 Season 2 Non-set
32999 Season 2 Non-set
33006 Season 3
33056 Season 2 Non-set
33057 Season 2 Non-set
33064 Season 2 Non-set
33065 Season 2 Non-set
33066 Season 2 Non-set
33067 Season 2 Non-set
33068 Season 2 Non-set
33076 Season 2
33077 Season 2
33078 Season 2
33309 Season 2
33313 Season 2
33661 Season 3
33662 Season 3
33663 Season 3
33664 Season 3
33665 Season 3
33666 Season 3
33667 Season 3
33668 Season 3
33669 Season 3
33670 Season 3
33671 Season 3
33672 Season 3
33673 Season 3
33674 Season 3
33675 Season 3
33676 Season 3
33677 Season 3
33678 Season 3
33679 Season 3
33680 Season 3
33681 Season 3
33682 Season 3
33683 Season 3
33684 Season 3
33685 Season 3
33686 Season 3
33687 Season 3
33688 Season 3
33689 Season 3
33690 Season 3
33691 Season 3
33692 Season 3
33693 Season 3
33694 Season 3
33695 Season 3
33696 Season 3
33697 Season 3
33698 Season 3
33699 Season 3
33700 Season 3
33701 Season 3
33702 Season 3
33703 Season 3
33704 Season 3
33705 Season 3
33706 Season 3
33707 Season 3
33708 Season 3
33709 Season 3
33710 Season 3
33711 Season 3
33712 Season 3
33713 Season 3
33714 Season 3
33715 Season 3
33716 Season 3
33717 Season 3
33718 Season 3
33719 Season 3
33720 Season 3
33721 Season 3
33722 Season 3
33723 Season 3
33724 Season 3
33725 Season 3
33726 Season 3
33727 Season 3
33728 Season 3
33729 Season 3
33730 Season 3
33731 Season 3
33732 Season 3
33733 Season 3
33734 Season 3
33735 Season 3
33736 Season 3
33737 Season 3
33738 Season 3
33739 Season 3
33740 Season 3
33741 Season 3
33742 Season 3
33743 Season 3
33744 Season 3
33745 Season 3
33746 Season 3
33747 Season 3
33748 Season 3
33749 Season 3
33750 Season 3
33751 Season 3
33752 Season 3
33753 Season 3
33754 Season 3
33755 Season 3
33756 Season 3
33757 Season 3
33758 Season 3
33759 Season 3
33760 Season 3
33761 Season 3
33762 Season 3
33763 Season 3
33764 Season 3
33765 Season 3
33766 Season 3
33767 Season 3
33768 Season 3
33769 Season 3
33770 Season 3
33771 Season 3
33801 Season 3
33811 Season 3 Non-set
33812 Season 3 Non-set
33813 Season 3 Non-set
33841 Season 3
33842 Season 3
33843 Season 3
33853 Season 3 Non-set
33876 Season 3 Non-set
33877 Season 3 Non-set
33878 Season 3 Non-set
33879 Season 3 Non-set
33880 Season 3 Non-set
33881 Season 3 Non-set
33882 Season 3 Non-set
33883 Season 3 Non-set
33884 Season 3 Non-set
33885 Season 3 Non-set
33886 Season 3 Non-set
33887 Season 3 Non-set
33888 Season 3 Non-set
33889 Season 3 Non-set
33890 Season 3 Non-set
33891 Season 3 Non-set
33892 Season 3 Non-set
33893 Season 3 Non-set
33894 Season 3 Non-set
33895 Season 3 Non-set
33896 Season 3 Non-set
33897 Season 3 Non-set
33898 Season 3 Non-set
33899 Season 3 Non-set
33900 Season 3 Non-set
33901 Season 3 Non-set
33902 Season 3 Non-set
33903 Season 3 Non-set
33904 Season 3 Non-set
33905 Season 3 Non-set
33906 Season 3 Non-set
33907 Season 3 Non-set
33908 Season 3 Non-set
33909 Season 3 Non-set
33910 Season 3 Non-set
33911 Season 3 Non-set
33912 Season 3 Non-set
33913 Season 3 Non-set
33914 Season 3 Non-set
33915 Season 3 Non-set
33916 Season 3 Non-set
33917 Season 3 Non-set
33918 Season 3 Non-set
33919 Season 3 Non-set
33920 Season 3 Non-set
33921 Season 3 Non-set
33922 Season 3 Non-set
33923 Season 3 Non-set
33936 Season 1
33937 Season 2
33938 Season 3
33939 Season 1
33940 Season 2
33941 Season 3
33942 Season 1
33943 Season 2
33944 Season 3
33945 Season 1
33946 Season 2
33947 Season 3
33948 Season 1
33949 Season 2
33950 Season 3
33951 Season 1
33952 Season 2
33953 Season 3
34014 Season 3
34015 Season 3
34016 Season 3
34033 Season 3
34059 Season 3
34066 Season 3
34529 Season 3
34530 Season 3
34540 Season 3
35317 Season 3 Non-set
35319 Season 3 Non-set
35320 Season 3 Non-set
]]

Engravings["Item set:"] = setmetatable({}, {
	__index = function(t,i)
		local v = ITEM_SET_NAMES:match("\n"..i.." ([^\n]+)\n")
		if v then t[i] = v; return v
		else t[i] = false; return end
	end
})
