
local PVP_GEAR = [[
16345 Honor Points
17348 Warsong Gulch
17349 Warsong Gulch
17351 Warsong Gulch
17352 Warsong Gulch
18825 Honor Points
18826 Honor Points
18827 Honor Points
18830 Honor Points
18831 Honor Points
18833 Honor Points
18835 Honor Points
18836 Honor Points
18837 Honor Points
18838 Honor Points
18840 Honor Points
18847 Honor Points
18848 Honor Points
18855 Honor Points
18873 Honor Points
18876 Honor Points
19029 Alterac Valley
19030 Alterac Valley
19031 Alterac Valley
19032 Alterac Valley
19045 Alterac Valley
19046 Alterac Valley
19060 Warsong Gulch
19061 Warsong Gulch
19062 Warsong Gulch
19066 Warsong Gulch
19067 Warsong Gulch
19068 Warsong Gulch
19083 Alterac Valley
19084 Alterac Valley
19085 Alterac Valley
19086 Alterac Valley
19087 Alterac Valley
19088 Alterac Valley
19089 Alterac Valley
19090 Alterac Valley
19091 Alterac Valley
19092 Alterac Valley
19093 Alterac Valley
19094 Alterac Valley
19095 Alterac Valley
19096 Alterac Valley
19097 Alterac Valley
19098 Alterac Valley
19099 Alterac Valley
19100 Alterac Valley
19101 Alterac Valley
19102 Alterac Valley
19103 Alterac Valley
19104 Alterac Valley
19301 Alterac Valley
19307 Alterac Valley
19308 Alterac Valley
19309 Alterac Valley
19310 Alterac Valley
19311 Alterac Valley
19312 Alterac Valley
19315 Alterac Valley
19316 Alterac Valley
19317 Alterac Valley
19318 Alterac Valley
19319 Alterac Valley
19320 Alterac Valley
19321 Alterac Valley
19323 Alterac Valley
19324 Alterac Valley
19325 Alterac Valley
19483 Alterac Valley
19484 Alterac Valley
19505 Warsong Gulch
19506 Warsong Gulch
19510 Warsong Gulch
19511 Warsong Gulch
19512 Warsong Gulch
19513 Warsong Gulch
19514 Warsong Gulch
19515 Warsong Gulch
19516 Warsong Gulch
19517 Warsong Gulch
19518 Warsong Gulch
19519 Warsong Gulch
19520 Warsong Gulch
19521 Warsong Gulch
19522 Warsong Gulch
19523 Warsong Gulch
19524 Warsong Gulch
19525 Warsong Gulch
19526 Warsong Gulch
19527 Warsong Gulch
19528 Warsong Gulch
19529 Warsong Gulch
19530 Warsong Gulch
19531 Warsong Gulch
19532 Warsong Gulch
19533 Warsong Gulch
19534 Warsong Gulch
19535 Warsong Gulch
19536 Warsong Gulch
19537 Warsong Gulch
19538 Warsong Gulch
19539 Warsong Gulch
19540 Warsong Gulch
19541 Warsong Gulch
19542 Warsong Gulch
19543 Warsong Gulch
19544 Warsong Gulch
19545 Warsong Gulch
19546 Warsong Gulch
19547 Warsong Gulch
19548 Warsong Gulch
19549 Warsong Gulch
19550 Warsong Gulch
19551 Warsong Gulch
19552 Warsong Gulch
19553 Warsong Gulch
19554 Warsong Gulch
19555 Warsong Gulch
19556 Warsong Gulch
19557 Warsong Gulch
19558 Warsong Gulch
19559 Warsong Gulch
19560 Warsong Gulch
19561 Warsong Gulch
19562 Warsong Gulch
19563 Warsong Gulch
19564 Warsong Gulch
19565 Warsong Gulch
19566 Warsong Gulch
19567 Warsong Gulch
19568 Warsong Gulch
19569 Warsong Gulch
19570 Warsong Gulch
19571 Warsong Gulch
19572 Warsong Gulch
19573 Warsong Gulch
19578 Warsong Gulch
19580 Warsong Gulch
19581 Warsong Gulch
19582 Warsong Gulch
19583 Warsong Gulch
19584 Warsong Gulch
19587 Warsong Gulch
19589 Warsong Gulch
19590 Warsong Gulch
19595 Warsong Gulch
19596 Warsong Gulch
19597 Warsong Gulch
20041 Arathi Basin
20042 Arathi Basin
20043 Arathi Basin
20044 Arathi Basin
20045 Arathi Basin
20046 Arathi Basin
20047 Arathi Basin
20048 Arathi Basin
20049 Arathi Basin
20050 Arathi Basin
20051 Arathi Basin
20052 Arathi Basin
20053 Arathi Basin
20054 Arathi Basin
20055 Arathi Basin
20056 Arathi Basin
20057 Arathi Basin
20058 Arathi Basin
20059 Arathi Basin
20060 Arathi Basin
20061 Arathi Basin
20068 Arathi Basin
20069 Arathi Basin
20070 Arathi Basin
20071 Arathi Basin
20072 Arathi Basin
20073 Arathi Basin
20088 Arathi Basin
20089 Arathi Basin
20090 Arathi Basin
20091 Arathi Basin
20092 Arathi Basin
20093 Arathi Basin
20094 Arathi Basin
20095 Arathi Basin
20096 Arathi Basin
20097 Arathi Basin
20098 Arathi Basin
20099 Arathi Basin
20100 Arathi Basin
20101 Arathi Basin
20102 Arathi Basin
20103 Arathi Basin
20104 Arathi Basin
20105 Arathi Basin
20106 Arathi Basin
20107 Arathi Basin
20108 Arathi Basin
20109 Arathi Basin
20110 Arathi Basin
20111 Arathi Basin
20112 Arathi Basin
20113 Arathi Basin
20114 Arathi Basin
20115 Arathi Basin
20116 Arathi Basin
20117 Arathi Basin
20118 Arathi Basin
20119 Arathi Basin
20120 Arathi Basin
20121 Arathi Basin
20122 Arathi Basin
20123 Arathi Basin
20124 Arathi Basin
20125 Arathi Basin
20126 Arathi Basin
20127 Arathi Basin
20128 Arathi Basin
20129 Arathi Basin
20150 Arathi Basin
20151 Arathi Basin
20152 Arathi Basin
20153 Arathi Basin
20154 Arathi Basin
20155 Arathi Basin
20156 Arathi Basin
20157 Arathi Basin
20158 Arathi Basin
20159 Arathi Basin
20160 Arathi Basin
20161 Arathi Basin
20162 Arathi Basin
20163 Arathi Basin
20164 Arathi Basin
20165 Arathi Basin
20166 Arathi Basin
20167 Arathi Basin
20168 Arathi Basin
20169 Arathi Basin
20170 Arathi Basin
20171 Arathi Basin
20172 Arathi Basin
20173 Arathi Basin
20174 Arathi Basin
20175 Arathi Basin
20176 Arathi Basin
20177 Arathi Basin
20178 Arathi Basin
20179 Arathi Basin
20180 Arathi Basin
20181 Arathi Basin
20182 Arathi Basin
20183 Arathi Basin
20184 Arathi Basin
20185 Arathi Basin
20186 Arathi Basin
20187 Arathi Basin
20188 Arathi Basin
20189 Arathi Basin
20190 Arathi Basin
20191 Arathi Basin
20192 Arathi Basin
20193 Arathi Basin
20194 Arathi Basin
20195 Arathi Basin
20196 Arathi Basin
20197 Arathi Basin
20198 Arathi Basin
20199 Arathi Basin
20200 Arathi Basin
20201 Arathi Basin
20202 Arathi Basin
20203 Arathi Basin
20204 Arathi Basin
20205 Arathi Basin
20206 Arathi Basin
20207 Arathi Basin
20208 Arathi Basin
20209 Arathi Basin
20210 Arathi Basin
20211 Arathi Basin
20212 Arathi Basin
20214 Arathi Basin
20220 Arathi Basin
20222 Arathi Basin
20223 Arathi Basin
20224 Arathi Basin
20225 Arathi Basin
20226 Arathi Basin
20227 Arathi Basin
20232 Arathi Basin
20234 Arathi Basin
20235 Arathi Basin
20237 Arathi Basin
20243 Arathi Basin
20244 Arathi Basin
20425 Warsong Gulch
20426 Warsong Gulch
20427 Warsong Gulch
20428 Warsong Gulch
20429 Warsong Gulch
20430 Warsong Gulch
20431 Warsong Gulch
20434 Warsong Gulch
20437 Warsong Gulch
20438 Warsong Gulch
20439 Warsong Gulch
20440 Warsong Gulch
20441 Warsong Gulch
20442 Warsong Gulch
20443 Warsong Gulch
20444 Warsong Gulch
21115 Arathi Basin
21116 Arathi Basin
21117 Arathi Basin
21118 Arathi Basin
21119 Arathi Basin
21120 Arathi Basin
21563 Alterac Valley
21565 Warsong Gulch
21566 Warsong Gulch
21567 Warsong Gulch
21568 Warsong Gulch
22651 Warsong Gulch
22672 Warsong Gulch
22673 Warsong Gulch
22676 Warsong Gulch
22740 Warsong Gulch
22741 Warsong Gulch
22747 Warsong Gulch
22748 Warsong Gulch
22749 Warsong Gulch
22750 Warsong Gulch
22752 Warsong Gulch
22753 Warsong Gulch
23451 Honor Points
23452 Honor Points
23465 Honor Points
23466 Honor Points
23467 Honor Points
23468 Honor Points
23469 Honor Points
24544 Honor Points
24545 Honor Points
24546 Honor Points
24547 Honor Points
24549 Honor Points
24550 Honor Points
24551 Honor Points
24552 Honor Points
24553 Honor Points
24554 Honor Points
24555 Honor Points
24556 Honor Points
24557 Honor Points
25829 Honor Points
25830 Honor Points
25831 Honor Points
25832 Honor Points
25833 Honor Points
25834 Honor Points
25854 Honor Points
25855 Honor Points
25856 Honor Points
25857 Honor Points
25858 Honor Points
25997 Honor Points
25998 Honor Points
25999 Honor Points
26000 Honor Points
26001 Honor Points
27469 Honor Points
27470 Honor Points
27471 Honor Points
27472 Honor Points
27473 Honor Points
27637 Halaa
27638 Halaa
27639 Halaa
27643 Halaa
27644 Halaa
27645 Halaa
27646 Halaa
27647 Halaa
27648 Halaa
27649 Halaa
27650 Halaa
27652 Halaa
27653 Halaa
27654 Halaa
27679 Halaa
27680 Halaa
27702 Honor Points
27703 Honor Points
27704 Honor Points
27705 Honor Points
27706 Honor Points
27707 Honor Points
27708 Honor Points
27709 Honor Points
27710 Honor Points
27711 Honor Points
27777 Thrallmar
27785 Thrallmar
27786 Thrallmar
27809 Honor Hold
27812 Honor Hold
27820 Honor Hold
27830 Thrallmar
27832 Thrallmar
27833 Honor Hold
27834 Honor Hold
27879 Honor Points
27880 Honor Points
27881 Honor Points
27882 Honor Points
27883 Honor Points
27920 Zangarmarsh
27921 Zangarmarsh
27922 Zangarmarsh
27924 Zangarmarsh
27926 Zangarmarsh
27927 Zangarmarsh
27928 Zangarmarsh
27929 Zangarmarsh
27930 Zangarmarsh
27931 Zangarmarsh
27939 Zangarmarsh
27942 Zangarmarsh
27949 Zangarmarsh
27983 Zangarmarsh
27984 Zangarmarsh
27989 Zangarmarsh
27990 Zangarmarsh
28126 Honor Points
28127 Honor Points
28128 Honor Points
28129 Honor Points
28130 Honor Points
28136 Honor Points
28137 Honor Points
28138 Honor Points
28139 Honor Points
28140 Honor Points
28234 Honor Points
28235 Honor Points
28236 Honor Points
28237 Honor Points
28238 Honor Points
28239 Honor Points
28240 Honor Points
28241 Honor Points
28242 Honor Points
28243 Honor Points
28246 Honor Points
28247 Honor Points
28294 Honor Points
28295 Honor Points
28297 Honor Points
28298 Honor Points
28299 Honor Points
28300 Honor Points
28302 Honor Points
28305 Honor Points
28307 Honor Points
28308 Honor Points
28309 Honor Points
28310 Honor Points
28312 Honor Points
28313 Honor Points
28314 Honor Points
28319 Honor Points
28320 Honor Points
28331 Honor Points
28332 Honor Points
28333 Honor Points
28334 Honor Points
28335 Honor Points
28346 Honor Points
28355 Arena Season 1
28356 Arena Season 1
28357 Arena Season 1
28358 Honor Points
28360 Thrallmar
28361 Honor Hold
28377 Honor Points
28378 Honor Points
28379 Honor Points
28380 Honor Points
28476 Honor Points
30186 Honor Points
30187 Honor Points
30188 Honor Points
30200 Honor Points
30201 Honor Points
30343 Honor Points
30344 Honor Points
30345 Honor Points
30346 Honor Points
30348 Honor Points
30349 Honor Points
30350 Honor Points
30351 Honor Points
30486 Arena Season 2
30487 Arena Season 2
30488 Arena Season 2
30489 Arena Season 2
30490 Arena Season 2
30497 Warsong Gulch
30498 Warsong Gulch
31375 Honor Points
31376 Honor Points
31377 Honor Points
31378 Honor Points
31379 Honor Points
31396 Honor Points
31397 Honor Points
31400 Honor Points
31406 Honor Points
31407 Honor Points
31409 Honor Points
31410 Honor Points
31411 Honor Points
31412 Honor Points
31413 Honor Points
31613 Honor Points
31614 Honor Points
31616 Honor Points
31618 Honor Points
31619 Honor Points
31799 Honor Hold
31958 Arena Season 2
31959 Arena Season 2
31960 Arena Season 2
31961 Arena Season 2
31962 Arena Season 2
31963 Arena Season 2
31964 Arena Season 2
31965 Arena Season 2
31966 Arena Season 2
31967 Arena Season 2
31968 Arena Season 2
31969 Arena Season 2
31971 Arena Season 2
31972 Arena Season 2
31973 Arena Season 2
31974 Arena Season 2
31975 Arena Season 2
31976 Arena Season 2
31977 Arena Season 2
31978 Arena Season 2
31979 Arena Season 2
31980 Arena Season 2
31981 Arena Season 2
31982 Arena Season 2
31983 Arena Season 2
31984 Arena Season 2
31985 Arena Season 2
31986 Arena Season 2
31987 Arena Season 2
31988 Arena Season 2
31989 Arena Season 2
31990 Arena Season 2
31991 Arena Season 2
31992 Arena Season 2
31993 Arena Season 2
31995 Arena Season 2
31996 Arena Season 2
31997 Arena Season 2
31998 Arena Season 2
31999 Arena Season 2
32000 Arena Season 2
32001 Arena Season 2
32002 Arena Season 2
32003 Arena Season 2
32004 Arena Season 2
32005 Arena Season 2
32006 Arena Season 2
32007 Arena Season 2
32008 Arena Season 2
32009 Arena Season 2
32010 Arena Season 2
32011 Arena Season 2
32012 Arena Season 2
32013 Arena Season 2
32014 Arena Season 2
32015 Arena Season 2
32016 Arena Season 2
32017 Arena Season 2
32018 Arena Season 2
32019 Arena Season 2
32020 Arena Season 2
32021 Arena Season 2
32022 Arena Season 2
32023 Arena Season 2
32024 Arena Season 2
32025 Arena Season 2
32026 Arena Season 2
32027 Arena Season 2
32028 Arena Season 2
32029 Arena Season 2
32030 Arena Season 2
32031 Arena Season 2
32032 Arena Season 2
32033 Arena Season 2
32034 Arena Season 2
32035 Arena Season 2
32036 Arena Season 2
32037 Arena Season 2
32038 Arena Season 2
32039 Arena Season 2
32040 Arena Season 2
32041 Arena Season 2
32042 Arena Season 2
32043 Arena Season 2
32044 Arena Season 2
32045 Arena Season 2
32046 Arena Season 2
32047 Arena Season 2
32048 Arena Season 2
32049 Arena Season 2
32050 Arena Season 2
32051 Arena Season 2
32052 Arena Season 2
32053 Arena Season 2
32054 Arena Season 2
32055 Arena Season 2
32056 Arena Season 2
32057 Arena Season 2
32058 Arena Season 2
32059 Arena Season 2
32060 Arena Season 2
32071 Halaa
32450 Honor Points
32451 Honor Points
32452 Honor Points
32961 Arena Season 2
32962 Arena Season 2
32963 Arena Season 2
32964 Arena Season 2
33006 Arena Season 3
33056 Honor Points
33057 Honor Points
33064 Honor Points
33076 Arena Season 2
33077 Arena Season 2
33078 Arena Season 2
33309 Arena Season 2
33313 Arena Season 2
33661 Arena Season 3
33662 Arena Season 3
33663 Arena Season 3
33664 Arena Season 3
33665 Arena Season 3
33666 Arena Season 3
33667 Arena Season 3
33668 Arena Season 3
33669 Arena Season 3
33670 Arena Season 3
33671 Arena Season 3
33672 Arena Season 3
33673 Arena Season 3
33674 Arena Season 3
33675 Arena Season 3
33676 Arena Season 3
33677 Arena Season 3
33678 Arena Season 3
33679 Arena Season 3
33680 Arena Season 3
33681 Arena Season 3
33682 Arena Season 3
33683 Arena Season 3
33684 Arena Season 3
33685 Arena Season 3
33686 Arena Season 3
33687 Arena Season 3
33688 Arena Season 3
33689 Arena Season 3
33690 Arena Season 3
33691 Arena Season 3
33692 Arena Season 3
33693 Arena Season 3
33694 Arena Season 3
33695 Arena Season 3
33696 Arena Season 3
33697 Arena Season 3
33698 Arena Season 3
33699 Arena Season 3
33700 Arena Season 3
33701 Arena Season 3
33702 Arena Season 3
33703 Arena Season 3
33704 Arena Season 3
33705 Arena Season 3
33706 Arena Season 3
33707 Arena Season 3
33708 Arena Season 3
33709 Arena Season 3
33710 Arena Season 3
33711 Arena Season 3
33712 Arena Season 3
33713 Arena Season 3
33714 Arena Season 3
33715 Arena Season 3
33716 Arena Season 3
33717 Arena Season 3
33718 Arena Season 3
33719 Arena Season 3
33720 Arena Season 3
33721 Arena Season 3
33722 Arena Season 3
33723 Arena Season 3
33724 Arena Season 3
33725 Arena Season 3
33726 Arena Season 3
33727 Arena Season 3
33728 Arena Season 3
33729 Arena Season 3
33730 Arena Season 3
33731 Arena Season 3
33732 Arena Season 3
33733 Arena Season 3
33734 Arena Season 3
33735 Arena Season 3
33736 Arena Season 3
33737 Arena Season 3
33738 Arena Season 3
33739 Arena Season 3
33740 Arena Season 3
33741 Arena Season 3
33742 Arena Season 3
33743 Arena Season 3
33744 Arena Season 3
33745 Arena Season 3
33746 Arena Season 3
33747 Arena Season 3
33748 Arena Season 3
33749 Arena Season 3
33750 Arena Season 3
33751 Arena Season 3
33752 Arena Season 3
33753 Arena Season 3
33754 Arena Season 3
33755 Arena Season 3
33756 Arena Season 3
33757 Arena Season 3
33758 Arena Season 3
33759 Arena Season 3
33760 Arena Season 3
33761 Arena Season 3
33762 Arena Season 3
33763 Arena Season 3
33764 Arena Season 3
33765 Arena Season 3
33766 Arena Season 3
33767 Arena Season 3
33768 Arena Season 3
33769 Arena Season 3
33770 Arena Season 3
33771 Arena Season 3
33783 Halaa
33801 Arena Season 3
33811 Honor Points
33812 Honor Points
33813 Honor Points
33841 Arena Season 3
33842 Arena Season 3
33843 Arena Season 3
33853 Honor Points
33876 Honor Points
33877 Honor Points
33878 Honor Points
33879 Honor Points
33880 Honor Points
33881 Honor Points
33882 Honor Points
33883 Honor Points
33884 Honor Points
33885 Honor Points
33886 Honor Points
33887 Honor Points
33888 Honor Points
33889 Honor Points
33890 Honor Points
33891 Honor Points
33892 Honor Points
33893 Honor Points
33894 Honor Points
33895 Honor Points
33896 Honor Points
33897 Honor Points
33898 Honor Points
33899 Honor Points
33900 Honor Points
33901 Honor Points
33902 Honor Points
33903 Honor Points
33904 Honor Points
33905 Honor Points
33906 Honor Points
33907 Honor Points
33908 Honor Points
33909 Honor Points
33910 Honor Points
33911 Honor Points
33912 Honor Points
33913 Honor Points
33914 Honor Points
33915 Honor Points
33916 Honor Points
33917 Honor Points
33918 Honor Points
33919 Honor Points
33920 Honor Points
33921 Honor Points
33922 Honor Points
33923 Honor Points
33936 Arena Season 1
33937 Arena Season 2
33938 Arena Season 3
33939 Arena Season 1
33940 Arena Season 2
33941 Arena Season 3
33942 Arena Season 1
33943 Arena Season 2
33944 Arena Season 3
33945 Arena Season 1
33946 Arena Season 2
33947 Arena Season 3
33948 Arena Season 1
33949 Arena Season 2
33950 Arena Season 3
33951 Arena Season 1
33952 Arena Season 2
33953 Arena Season 3
34014 Arena Season 3
34015 Arena Season 3
34016 Arena Season 3
34033 Arena Season 3
34059 Arena Season 3
34066 Arena Season 3
34529 Arena Season 3
34530 Arena Season 3
34540 Arena Season 3
34576 Honor Points
34577 Honor Points
34578 Honor Points
34579 Honor Points
34580 Honor Points
35317 Honor Points
35319 Honor Points
35320 Honor Points
35327 Honor Points
]]

Engravings["Source (PvP):"] = setmetatable({}, {
	__index = function(t,i)
		local v = PVP_GEAR:match("\n"..i.." ([^\n]+)\n")
		if v then t[i] = v; return v
		else t[i] = false; return end
	end
})
