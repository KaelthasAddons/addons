
local TIER_ARMOR_TOKEN_NPCS = [[
24544 Magtheridon
24545 Prince Malchezaar
24546 High King Maulgar
24547 Gruul the Dragonkiller
24549 The Curator
24552 Magtheridon
24553 Prince Malchezaar
24554 High King Maulgar
24555 Gruul the Dragonkiller
24556 The Curator
25830 Prince Malchezaar
25831 Magtheridon
25832 High King Maulgar
25833 Gruul the Dragonkiller
25834 The Curator
25854 High King Maulgar
25855 Prince Malchezaar
25856 Magtheridon
25857 The Curator
25858 Gruul the Dragonkiller
25997 Magtheridon
25998 Prince Malchezaar
25999 High King Maulgar
26000 The Curator
26001 Gruul the Dragonkiller
27469 Magtheridon
27470 The Curator
27471 Prince Malchezaar
27472 Gruul the Dragonkiller
27473 High King Maulgar
27702 Magtheridon
27703 The Curator
27704 Prince Malchezaar
27705 Gruul the Dragonkiller
27706 High King Maulgar
27707 The Curator
27708 Prince Malchezaar
27709 Gruul the Dragonkiller
27710 High King Maulgar
27711 Magtheridon
27879 Magtheridon
27880 The Curator
27881 Prince Malchezaar
27882 Gruul the Dragonkiller
27883 High King Maulgar
28126 The Curator
28127 Prince Malchezaar
28128 Gruul the Dragonkiller
28129 High King Maulgar
28130 Magtheridon
28136 The Curator
28137 Prince Malchezaar
28138 Gruul the Dragonkiller
28139 High King Maulgar
28140 Magtheridon
28331 Prince Malchezaar
28332 Gruul the Dragonkiller
28333 High King Maulgar
28334 Magtheridon
28335 The Curator
28963 Prince Malchezaar
28964 Magtheridon
28966 Gruul the Dragonkiller
28967 High King Maulgar
28968 The Curator
29011 Prince Malchezaar
29012 Magtheridon
29015 Gruul the Dragonkiller
29016 High King Maulgar
29017 The Curator
29019 Magtheridon
29020 The Curator
29021 Prince Malchezaar
29022 Gruul the Dragonkiller
29023 High King Maulgar
29028 Prince Malchezaar
29029 Magtheridon
29030 Gruul the Dragonkiller
29031 High King Maulgar
29032 The Curator
29033 Magtheridon
29034 The Curator
29035 Prince Malchezaar
29036 Gruul the Dragonkiller
29037 High King Maulgar
29038 Magtheridon
29039 The Curator
29040 Prince Malchezaar
29042 Gruul the Dragonkiller
29043 High King Maulgar
29044 Prince Malchezaar
29045 Magtheridon
29046 Gruul the Dragonkiller
29047 High King Maulgar
29048 The Curator
29049 Prince Malchezaar
29050 Magtheridon
29053 Gruul the Dragonkiller
29054 High King Maulgar
29055 The Curator
29056 Magtheridon
29057 The Curator
29058 Prince Malchezaar
29059 Gruul the Dragonkiller
29060 High King Maulgar
29061 Prince Malchezaar
29062 Magtheridon
29063 Gruul the Dragonkiller
29064 High King Maulgar
29065 The Curator
29066 Magtheridon
29067 The Curator
29068 Prince Malchezaar
29069 Gruul the Dragonkiller
29070 High King Maulgar
29071 Magtheridon
29072 The Curator
29073 Prince Malchezaar
29074 Gruul the Dragonkiller
29075 High King Maulgar
29076 Prince Malchezaar
29077 Magtheridon
29078 Gruul the Dragonkiller
29079 High King Maulgar
29080 The Curator
29081 Prince Malchezaar
29082 Magtheridon
29083 Gruul the Dragonkiller
29084 High King Maulgar
29085 The Curator
29086 Prince Malchezaar
29087 Magtheridon
29088 Gruul the Dragonkiller
29089 High King Maulgar
29090 The Curator
29091 Magtheridon
29092 The Curator
29093 Prince Malchezaar
29094 Gruul the Dragonkiller
29095 High King Maulgar
29096 Magtheridon
29097 The Curator
29098 Prince Malchezaar
29099 Gruul the Dragonkiller
29100 High King Maulgar
30113 Kael'thas Sunstrider
30114 Leotheras the Blind
30115 Lady Vashj
30116 Fathom-Lord Karathress
30117 Void Reaver
30118 Kael'thas Sunstrider
30119 Leotheras the Blind
30120 Lady Vashj
30121 Fathom-Lord Karathress
30122 Void Reaver
30123 Kael'thas Sunstrider
30124 Leotheras the Blind
30125 Lady Vashj
30126 Fathom-Lord Karathress
30127 Void Reaver
30129 Kael'thas Sunstrider
30130 Leotheras the Blind
30131 Lady Vashj
30132 Fathom-Lord Karathress
30133 Void Reaver
30134 Kael'thas Sunstrider
30135 Leotheras the Blind
30136 Lady Vashj
30137 Fathom-Lord Karathress
30138 Void Reaver
30139 Kael'thas Sunstrider
30140 Leotheras the Blind
30141 Lady Vashj
30142 Fathom-Lord Karathress
30143 Void Reaver
30144 Kael'thas Sunstrider
30145 Leotheras the Blind
30146 Lady Vashj
30148 Fathom-Lord Karathress
30149 Void Reaver
30150 Kael'thas Sunstrider
30151 Leotheras the Blind
30152 Lady Vashj
30153 Fathom-Lord Karathress
30154 Void Reaver
30159 Kael'thas Sunstrider
30160 Leotheras the Blind
30161 Lady Vashj
30162 Fathom-Lord Karathress
30163 Void Reaver
30164 Kael'thas Sunstrider
30165 Leotheras the Blind
30166 Lady Vashj
30167 Fathom-Lord Karathress
30168 Void Reaver
30169 Kael'thas Sunstrider
30170 Leotheras the Blind
30171 Lady Vashj
30172 Fathom-Lord Karathress
30173 Void Reaver
30185 Kael'thas Sunstrider
30186 High King Maulgar
30187 Prince Malchezaar
30188 The Curator
30189 Leotheras the Blind
30190 Lady Vashj
30192 Fathom-Lord Karathress
30194 Void Reaver
30196 Kael'thas Sunstrider
30200 Magtheridon
30201 Gruul the Dragonkiller
30205 Leotheras the Blind
30206 Lady Vashj
30207 Fathom-Lord Karathress
30210 Void Reaver
30211 Leotheras the Blind
30212 Lady Vashj
30213 Fathom-Lord Karathress
30214 Kael'thas Sunstrider
30215 Void Reaver
30216 Kael'thas Sunstrider
30217 Leotheras the Blind
30219 Lady Vashj
30220 Fathom-Lord Karathress
30221 Void Reaver
30222 Kael'thas Sunstrider
30223 Leotheras the Blind
30228 Lady Vashj
30229 Fathom-Lord Karathress
30230 Void Reaver
30231 Kael'thas Sunstrider
30232 Leotheras the Blind
30233 Lady Vashj
30234 Fathom-Lord Karathress
30235 Void Reaver
30486 Kael'thas Sunstrider
30487 Leotheras the Blind
30488 Lady Vashj
30489 Fathom-Lord Karathress
30490 Void Reaver
30969 Azgalor
30970 Azgalor
30972 Archimonde
30974 Archimonde
30975 Illidan Stormrage
30976 Illidan Stormrage
30977 Illidari Council
30978 Illidari Council
30979 Mother Shahraz
30980 Mother Shahraz
30982 Azgalor
30983 Azgalor
30985 Azgalor
30987 Archimonde
30988 Archimonde
30989 Archimonde
30990 Illidan Stormrage
30991 Illidan Stormrage
30992 Illidan Stormrage
30993 Illidari Council
30994 Illidari Council
30995 Illidari Council
30996 Mother Shahraz
30997 Mother Shahraz
30998 Mother Shahraz
31001 Azgalor
31003 Archimonde
31004 Illidan Stormrage
31005 Illidari Council
31006 Mother Shahraz
31007 Azgalor
31008 Azgalor
31011 Azgalor
31012 Archimonde
31014 Archimonde
31015 Archimonde
31016 Illidan Stormrage
31017 Illidan Stormrage
31018 Illidan Stormrage
31019 Illidari Council
31020 Illidari Council
31021 Illidari Council
31022 Mother Shahraz
31023 Mother Shahraz
31024 Mother Shahraz
31026 Azgalor
31027 Archimonde
31028 Illidan Stormrage
31029 Illidari Council
31030 Mother Shahraz
31032 Azgalor
31034 Azgalor
31035 Azgalor
31037 Archimonde
31039 Archimonde
31040 Archimonde
31041 Illidan Stormrage
31042 Illidan Stormrage
31043 Illidan Stormrage
31044 Illidari Council
31045 Illidari Council
31046 Illidari Council
31047 Mother Shahraz
31048 Mother Shahraz
31049 Mother Shahraz
31050 Azgalor
31051 Archimonde
31052 Illidan Stormrage
31053 Illidari Council
31054 Mother Shahraz
31055 Azgalor
31056 Archimonde
31057 Illidan Stormrage
31058 Illidari Council
31059 Mother Shahraz
31060 Azgalor
31061 Azgalor
31063 Archimonde
31064 Archimonde
31065 Illidan Stormrage
31066 Illidan Stormrage
31067 Illidari Council
31068 Illidari Council
31069 Mother Shahraz
31070 Mother Shahraz
31375 The Curator
31376 Prince Malchezaar
31377 Gruul the Dragonkiller
31378 High King Maulgar
31379 Magtheridon
31396 Magtheridon
31397 The Curator
31400 Prince Malchezaar
31406 Gruul the Dragonkiller
31407 High King Maulgar
31409 The Curator
31410 Prince Malchezaar
31411 Gruul the Dragonkiller
31412 High King Maulgar
31413 Magtheridon
31613 Magtheridon
31614 The Curator
31616 Prince Malchezaar
31618 Gruul the Dragonkiller
31619 High King Maulgar
31960 Kael'thas Sunstrider
31961 Leotheras the Blind
31962 Lady Vashj
31963 Fathom-Lord Karathress
31964 Void Reaver
31967 Leotheras the Blind
31968 Lady Vashj
31969 Fathom-Lord Karathress
31971 Void Reaver
31972 Kael'thas Sunstrider
31973 Leotheras the Blind
31974 Lady Vashj
31975 Fathom-Lord Karathress
31976 Void Reaver
31977 Kael'thas Sunstrider
31979 Void Reaver
31980 Lady Vashj
31981 Leotheras the Blind
31982 Kael'thas Sunstrider
31983 Fathom-Lord Karathress
31987 Leotheras the Blind
31988 Lady Vashj
31989 Fathom-Lord Karathress
31990 Void Reaver
31991 Kael'thas Sunstrider
31992 Kael'thas Sunstrider
31993 Leotheras the Blind
31995 Fathom-Lord Karathress
31996 Void Reaver
31997 Lady Vashj
31998 Leotheras the Blind
31999 Lady Vashj
32000 Fathom-Lord Karathress
32001 Void Reaver
32002 Kael'thas Sunstrider
32004 Kael'thas Sunstrider
32005 Leotheras the Blind
32006 Lady Vashj
32007 Fathom-Lord Karathress
32008 Void Reaver
32009 Kael'thas Sunstrider
32010 Leotheras the Blind
32011 Lady Vashj
32012 Fathom-Lord Karathress
32013 Void Reaver
32015 Leotheras the Blind
32016 Lady Vashj
32017 Fathom-Lord Karathress
32018 Void Reaver
32019 Kael'thas Sunstrider
32020 Kael'thas Sunstrider
32021 Leotheras the Blind
32022 Lady Vashj
32023 Fathom-Lord Karathress
32024 Void Reaver
32029 Kael'thas Sunstrider
32030 Leotheras the Blind
32031 Lady Vashj
32032 Fathom-Lord Karathress
32033 Void Reaver
32034 Leotheras the Blind
32035 Lady Vashj
32036 Fathom-Lord Karathress
32037 Void Reaver
32038 Kael'thas Sunstrider
32039 Kael'thas Sunstrider
32040 Leotheras the Blind
32041 Lady Vashj
32042 Fathom-Lord Karathress
32043 Void Reaver
32047 Void Reaver
32048 Lady Vashj
32049 Leotheras the Blind
32050 Kael'thas Sunstrider
32051 Fathom-Lord Karathress
32056 Leotheras the Blind
32057 Lady Vashj
32058 Fathom-Lord Karathress
32059 Void Reaver
32060 Kael'thas Sunstrider
33811 Brutallus
33812 Felmyst
33813 Sathrovarr the Corruptor
33876 Sathrovarr the Corruptor
33877 Brutallus
33878 Felmyst
33879 Brutallus
33880 Felmyst
33881 Sathrovarr the Corruptor
33882 Brutallus
33883 Sathrovarr the Corruptor
33884 Felmyst
33885 Brutallus
33886 Felmyst
33887 Sathrovarr the Corruptor
33888 Brutallus
33889 Sathrovarr the Corruptor
33890 Felmyst
33891 Brutallus
33892 Felmyst
33893 Sathrovarr the Corruptor
33894 Sathrovarr the Corruptor
33895 Brutallus
33896 Felmyst
33897 Sathrovarr the Corruptor
33898 Brutallus
33899 Felmyst
33900 Brutallus
33901 Sathrovarr the Corruptor
33902 Felmyst
33903 Brutallus
33904 Sathrovarr the Corruptor
33905 Felmyst
33906 Sathrovarr the Corruptor
33907 Brutallus
33908 Felmyst
33909 Brutallus
33910 Sathrovarr the Corruptor
33911 Felmyst
33912 Brutallus
33913 Sathrovarr the Corruptor
33914 Felmyst
33915 Brutallus
33916 Felmyst
33917 Sathrovarr the Corruptor
34431 Sathrovarr the Corruptor
34432 Sathrovarr the Corruptor
34433 Sathrovarr the Corruptor
34434 Sathrovarr the Corruptor
34435 Sathrovarr the Corruptor
34436 Sathrovarr the Corruptor
34437 Sathrovarr the Corruptor
34438 Sathrovarr the Corruptor
34439 Sathrovarr the Corruptor
34441 Sathrovarr the Corruptor
34442 Sathrovarr the Corruptor
34443 Sathrovarr the Corruptor
34444 Sathrovarr the Corruptor
34445 Sathrovarr the Corruptor
34446 Sathrovarr the Corruptor
34447 Sathrovarr the Corruptor
34448 Sathrovarr the Corruptor
34485 Brutallus
34487 Brutallus
34488 Brutallus
34527 Brutallus
34528 Brutallus
34541 Brutallus
34542 Brutallus
34543 Brutallus
34545 Brutallus
34546 Brutallus
34547 Brutallus
34549 Brutallus
34554 Brutallus
34555 Brutallus
34556 Brutallus
34557 Brutallus
34558 Brutallus
34559 Felmyst
34560 Felmyst
34561 Felmyst
34562 Felmyst
34563 Felmyst
34564 Felmyst
34565 Felmyst
34566 Felmyst
34567 Felmyst
34568 Felmyst
34569 Felmyst
34570 Felmyst
34571 Felmyst
34572 Felmyst
34573 Felmyst
34574 Felmyst
34575 Felmyst
]]

Engravings["Token dropped by:"] = setmetatable({}, {
	__index = function(t,i)
		local v = TIER_ARMOR_TOKEN_NPCS:match("\n"..i.." ([^\n]+)\n")
		if v then t[i] = v; return v
		else t[i] = false; return end
	end
})
