﻿--[[Written by: David - Zalra @ Hyjal (Alliance)
Contact:
	In Game: Zalra @ Hyjal (Alliance)
	Email: Davieboy53@yahoo.com
	XFire: Dawnseclipse	
	Curse Username: Davie3
]]

WhoPinged = AceLibrary("AceAddon-2.0"):new("AceEvent-2.0", "AceConsole-2.0")

function WhoPinged:OnInitialize() 
	self:RegisterEvent("MINIMAP_PING", "Pinged")	
	--self:RegisterChatCommand("/whopinged", options)
end

function WhoPinged:Pinged()
	PlayerWhoPinged = UnitName(arg1);
	local hour,minute = GetGameTime();
	if (hour >= 13) then
		hour = hour - 12;
	end
	
	WhoPinged:GetClassColor(arg1);

	if (minute < 10) then
		self:Print("|c"..ClassColor.."".. PlayerWhoPinged .."|r |c00CCCCCCpinged the minimap at " .. hour .. ":0" .. minute .. " server time.|r");
	else
		self:Print("|c"..ClassColor.."".. PlayerWhoPinged .."|r |c00CCCCCCpinged the minimap at " .. hour .. ":" .. minute .. " server time.|r");
	end
end

function WhoPinged:GetClassColor(PlayerName)
	localizedclass = UnitClass(PlayerName);
	if (localizedclass == "Druid") then
	  ClassColor = "00FF7D0A";
	elseif (localizedclass == "Hunter") then
	  ClassColor = "00ABD473";
	elseif (localizedclass == "Mage") then
	  ClassColor = "0069CCF0";
	elseif (localizedclass == "Paladin") then
	  ClassColor = "00F58CBA";
	elseif (localizedclass == "Priest") then
	  ClassColor = "00FFFFFF";
	elseif (localizedclass == "Rogue") then
	  ClassColor = "00FFF569";
	elseif (localizedclass == "Shaman") then
	  ClassColor = "002459FF";
	elseif (localizedclass == "Warlock") then
	  ClassColor = "009482CA";
	elseif (localizedclass == "Warrior") then
	  ClassColor = "00C79C6E";
	end
end



