﻿--[[ $Id: frFRlua 18597 2006-12-02 06:24:04Z fenlis $ ]]--

local L = LibStub("AceLocale-3.0"):NewLocale("ClosetGnome", "frFR")
if not L then return end
L["Keybindings"] = "Raccourcis clavier"

L["closetgnome_description"] = "La définition officielle du ClosetGnome se trouve dans l'O.E.D. (Orgrimmar English Dictionary). Elle est traduite dans le petit Gobelin illustré comme suit : 'nom (1) une créature ressemblant à un nabot supposée garder les habits de son possesseur, (2) un petit ornement ressemblant à un homme barbu et portant des habits sexy habituellement trouvé dans les placards.'\n\nPersonnellement, je dirai qu'il s'agit là de petites créatures amusantes. La plupart d'entre eux sont fiables et font bien leur boulot, non pas parce qu'ils vous sont fidèles, mais parce qu'ils sont fidèles aux habits qu'ils protègent.\n\nUn ClosetGnome peut être beaucoup plus efficace à sa tâche si vous l'habituez à utiliser les raccourcis clavier.\n\n"
L["keybinding_description"] = "L'association de raccourcis clavier pour vos ensembles ClosetGnome permet de changer d'équipement rapidement et facilement, sans passer par le menu.\n\n"

L["|cffeda55fLeft-Click|r a slot to toggle it for this set. Green slots are |cff00ff00enabled|r, red are |cffff0000disabled|r, yellow are |cffffff00missing items|r.\n\nIf you want to assign an |cff0000fficon|r to this set, you can |cffeda55fCtrl-Click|r a slot to use that slots item as the icon.\n\nType the desired set name below and click Add when you are done."] = "|cffeda55fClic-gauche|r sur un emplacement pour l'ajouter à cet ensemble. Les emplacements en vert sont |cff00ff00activés|r, ceux en rouge |cffff0000désactivés|r, ceux en jaunes sont |cffffff00manquant|r.\n\nSi vous voulez assigner une |cff0000ffic\195\180ne|r à cet ensemble, vous pouvez faire la combinaison |cffeda55fCtrl-clic|r sur un emplacement pour utiliser l'objet de cet emplacement comme ic\195\180ne.\n\nTapez le nom que vous souhaitez donner à cet ensemble ci-dessous et cliquez sur Ajouter une fois que vous avez terminé."
L["|cff00ff00Green slots|r are active, and any item currently in a green slot will be saved as part of the item set."] = "|cff00ff00Les emplacements verts|r sont actifs, et n'importe quel objet actuellement dans un emplacement vert sera enregistré comme faisant partie de l'ensemble."
L["|cffff0000Red slots|r are disabled, and will be ignored by the item set."] = "|cffff0000Les emplacements rouges|r sont désactivés et seront ignorés par votre ensemble."
L["A |cffffff00yellow slot|r means the item is missing from your inventory, and when you update the set, the item stored in the set will be used, and not the currently equipped one."] = "Un |cffffff00emplacement jaune|r signifie que l'objet est absent de votre inventaire. Quand l'ensemble est mis à jour, l'objet enregistré dans l'ensemble sera utilisé, et non pas celui que vous portez actuellement."
L["A |cff0000ffblue slot|r tells your ClosetGnome to use the item in that slot as the set icon. If a slot is toggled to an icon slot, it is also activated immediately."] = "Un |cff0000ffemplacement bleu|r demande à ClosetGnome d'utiliser l'icône de l'objet de cet emplacement comme icône de l'ensemble. Si un emplacement est modifié en tant qu'icône de l'ensemble, il est activé immédiatement."

L["Add"] = "Ajouter"
L["Creates a new set, or updates an existing one."] = "Créée un nouvel ensemble, ou met à jour un existant."
L["Wear"] = "Porter"
L["Change equipment set."] = "Change l'ensemble."
L["Delete"] = "Supprimer"
L["Cancel"] = "Annuler"
L["Always equip weapons"] = "Tj équiper les armes"
L["Equip weapons in sets even if you are in combat."] = "Équipe les armes des ensembles même si vous êtes en combat."
L["Quips"] = "Citations"
L["Toggle outputting random quips when equipping sets."] = "Affiche ou non des phrases rigolotes lorsque vous équiper un ensemble (en anglais pour le moment)."
L["Are you sure you want to delete the set %s?"] = "Êtes-vous sûr de vouloir supprimer l'ensemble %s ?"
L["<set name>"] = "<nom de l'ensemble>"
L["Couldn't find %s in your inventory."] = "Impossible de trouver %s dans votre inventaire."
L["Keybinding"] = "Raccourci"
L["Assign a keybinding to %s."] = "Assigne un raccourci clavier à %s."
L["Registering keybinding %s to set %s."] = "Assignement du raccourci %s à l'ensemble %s."
L["%s is already registered to %s."] = "%s est déjà assigné à l'ensemble %s."
L["Removing keybinding %s from set %s."] = "Suppression du raccourci %s de l'ensemble %s."

L["In combat: %s queued for swap."] = "En combat : %s placé en file d'attente."
L["Added set: %s."] = "Ensemble ajouté : %s."
L["Deleted set: %s."] = "Ensemble supprimé : %s."
L["Updating set: %s."] = "Ensemble mis à jour : %s."
L["Please use a proper name for your set."] = "Veuillez utiliser un nom correct pour votre ensemble."

-- This is what a normal bag is called, as returned from GetItemInfo's
-- subType
L["Bag"] = "Conteneur"

