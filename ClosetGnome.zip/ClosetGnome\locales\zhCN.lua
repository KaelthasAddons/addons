-------------------------------------------------------------------------------
-- Localization                                                              --
-------------------------------------------------------------------------------
--[[ $Id: zhCN.lua 1001 2007-06-26 15:52:29Z thomasmo $ ]]--
	--Chinese Local : CWDG Translation Team 冰之魅影 & 昏睡墨鱼 (Thomas Mo) & Isler
	--CWDG site: http://Cwowaddon.com
	--$Rev: 1001 $
	--$Date: 2007-06-26 23:52:29 +0800 (星期二, 26 六月 2007) $

local L = LibStub("AceLocale-3.0"):NewLocale("ClosetGnome", "zhCN")
if not L then return end

L["ClosetGnome"] = "ClosetGnome"
L["ClosetGnome options."] = "ClosetGnome 设置."
L["|cffeda55fLeft-Click|r a slot to toggle it for this set. Green slots are |cff00ff00enabled|r, red are |cffff0000disabled|r, yellow are |cffffff00missing items|r.\n\nIf you want to assign an |cff0000fficon|r to this set, you can |cffeda55fCtrl-Click|r a slot to use that slots item as the icon.\n\nType the desired set name below and click Add when you are done."] = "在角色窗口上|cffeda55f点击|r图标, 绿色边框为|cff00ff00启用|r, 红色边框为|cffff0000禁用|r, 黄色边框为|cffffff00缺失|r.\n\n如果你想为套装指派一个|cff0000ff图标|r, 那么用|cffeda55f<Ctrl>+左键|r选中一件装备, 则使用该装备的图标作为套装图标.\n\n输入套装名称并点击|cffffff00添加|r来完成操作."

L["|cff00ff00Green slots|r are active, and any item currently in a green slot will be saved as part of the item set."] = "|cff00ff00绿色标记|r表示有效的装备，任何绿色标记的装备都会被设定成套装的一部分"
L["|cffff0000Red slots|r are disabled, and will be ignored by the item set."] = "|cffff0000红色标记|r表示无效的装备，并且会在套装设定过程中被忽略掉"
L["A |cffffff00yellow slot|r means the item is missing from your inventory, and when you update the set, the item stored in the set will be used, and not the currently equipped one."] = "|cffffff00黄色标记|r表示该装备不在你的包裹里，当你更新套装设定时，不会被当前的装备替换掉"
L["A |cff0000ffblue slot|r tells your ClosetGnome to use the item in that slot as the set icon. If a slot is toggled to an icon slot, it is also activated immediately."] = "|cff0000ff蓝色标记|r表示使用该装备图标被设定为套装图标，点击图标时，图标会立即生效"

L["Add"] = "添加"
L["Creates a new set, or updates an existing one."] = "创建新套装, 或更新一个现有的套装"
L["Wear"] = "穿上"
L["Change equipment set."] = "换装"
L["Cancel"] = "取消"
L["Always equip weapons"] = "一直装备武器"
L["Equip weapons in sets even if you are in combat."] = "进入战斗状态时, 仍使用套装设置中的武器."
L["Equip %s, or hold down Shift to edit this set."] = "装备 %s, 或按下 <Shift> 编辑此套装."
L["Quips"] = "讽剌"
L["Toggle outputting random quips when equipping sets."] = "当更换套装时, 随机说出讽剌的话."
L["Delete"] = "删除"
L["Deletes the equipment set %s."] = "删除套装 %s"
L["Delete a set."] = "删除一个套装"
L["Are you sure you want to delete the set %s?"] = "你确定想删除套装 %s 吗?"
L["<set name>"] = "<套装名称>"
L["Couldn't find %s in your inventory."] = "在你的物品中无法找到 %s."
L["Enter the set name to delete it."] = "输入套装名称来删除它"
L["Keybinding"] = "按键绑定"
L["Assign a keybinding to a set."] = "给套装分配一个按键"
L["Assign a keybinding to %s."] = "分配一个按键给 %s (或清空)."
L["<key binding>"] = "<按键绑定>"
L["%s is not a valid keybinding."] = "%s 是一个无效的按键绑定"
L["Registering keybinding %s to set %s."] = "保存按键 %s 给套装 %s"
L["%s is already registered to %s."] = "%s 已经绑定给 %s "
L["Removing keybinding %s from set %s."] = "从套装 %s 中移除按键绑定 %s"

L["In combat: %s queued for swap."] = "进入战斗: %s 交换队列."
L["Added set: %s."] = "添加套装: %s."
L["Deleted set: %s."] = "删除套装: %s."
L["Updating set: %s."] = "更新套装: %s."
L["Please use a proper name for your set."] = "请为你的套装设置一个有效的名字"

-- This is what a normal bag is called, as returned from GetItemInfo's
-- subType
L["Bag"] = "容器"

-- 当你配备一个设置时, 随机说出讽剌的话.
L[1] = "ClosetGnome 给你迅速的穿上 %s 就跑掉了."
L[2] = "虽然 ClosetGnome 做出劣质产品, 但你还是要穿上 %s."
L[3] = "ClosetGnomes 还是很整洁的, 虽然他总是从角落里翻出 %s."
L[4] = "ClosetGnome 总是迈着丑陋的舞步给你穿上 %s."
L[5] = "今天你没有给 ClosetGnome 小费, 他反穿 %s 来抗议."
L[6] = "千万不要让 ClosetGnome 对 %s 有更进一步要求."
L[7] = "%s 今天看你至少比 ClosetGnome 好多了."
L[8] = "ClosetGnome 配备之 %s."
L[9] = "不知为何, ClosetGnome 穿上 %s 时显得又憎又厌. 呃, 这是什么气味..."
L[10] = "这是一阵风?! 不, ClosetGnome 给你套上了 %s!"
L[11] = "最近传闻, ClosetGnome 对于你身上的 %s 总是唠叨个没完."
L[12] = "谁都不知道 ClosetGnomes 的派对, 但是你知道, 这是你上次派对之后的模样."
L[13] = "满 %s 尽戴黄金甲."
L[14] = "尽管洗衣机上清楚的标有 'ClosetGnomes, Inc.' 认证, 但显然 %s 并没有被洗干净."
L[15] = "%s 和你上一套装是同一货色, 和上上一个, 还有上上上一个."
L[16] = "与 %s 不同, ClosetGnome 总是钻空子给你难堪. 最好扔下他自生自灭."
L[17] = "从没怀疑过你有 ClosetGnome. 实际上他们大部分穿上 %s 就好."
L[18] = "你竟然那么频繁的穿上 %s? ClosetGnome 很生气, 后果很严重."
L[19] = "ClosetGnome 饿狠了, 正在抢 %s 的棒棒糖, 要教训教训他么?"
L[20] = "ClosetGnome 第一守则, 不要谈论 %s."
L[21] = "%s 看起来不一样了."
L[22] = "%s 不在."
L[23] = "我要 - 我要 %s!"
L[24] = "ClosetGnome 穿上了 %s. 迷迷糊糊的摇晃着."
L[25] = "ClosetGnome 将 %s 扔到垃圾堆, 又回头穿上了."
L[26] = "哦 %s, 再见."
L[27] = "%s 很性感耶, 但 ClosetGnome 这电灯泡...."
L[28] = "%s 的 ClosetGnome, 人人都喜欢."
L[29] = "每天早晨, 最喜欢闻到 %s 的气味."
L[30] = "带上你的 ClosetGnome. %s 也会陪嫁."
L[31] = "轮都轮到 ClosetGnome 作贡献了, 他无法拒绝, 因此穿上了 %s."
L[32] = "穿上漂亮的 %s, 将 ClosetGnome 勾引出来."
L[33] = "ClosetGnome 穿上了 %s 炫耀他的大尺寸."
L[34] = "在 '爱的小船之承诺' 中, ClosetGnome 忠实的守护着 %s."
L[35] = "近来, ClosetGnome 开始对交换魔法的装备叫嚷, 说是要给 %s 点颜色看看."

