﻿-------------------------------------------------------------------------------
-- Localization                                                              --
-------------------------------------------------------------------------------
--[[ $Id: koKR.lua 18597 2006-12-02 06:24:04Z fenlis $ ]]--

local L = LibStub("AceLocale-3.0"):NewLocale("ClosetGnome", "koKR")
if not L then return end

L["ClosetGnome"] = "ClosetGnome"
L["ClosetGnome options."] = "ClosetGnome 옵션"
L["|cffeda55fLeft-Click|r a slot to toggle it for this set. Green slots are |cff00ff00enabled|r, red are |cffff0000disabled|r, yellow are |cffffff00missing items|r.\n\nIf you want to assign an |cff0000fficon|r to this set, you can |cffeda55fCtrl-Click|r a slot to use that slots item as the icon.\n\nType the desired set name below and click Add when you are done."] = "이 세트를 위해 그것을 전환하려면 슬롯에 |cffeda55f좌-클릭|r하시오. 녹색 슬롯은 |cff00ff00활성화|r, 붉은색은 |cffff0000비활성화|r, 노란색은 |cffffff00사라진 아이템|r\n\n이 세트를 위한 |cff0000ff아이콘|r을 할당하고자 한다면, 아이콘으로 아이템 슬롯에 사용할 슬롯에 |cffeda55fCtrl-클릭|r하시오.\n\n원하는 세트 이름을 아래에 입력하고 완료하려면 추가를 클릭하시오."

L["|cff00ff00Green slots|r are active, and any item currently in a green slot will be saved as part of the item set."] = "|cff00ff00녹색 슬롯|r이 사용되며, 현재 녹색 슬롯의 모든 아이템이 아이템 세트의 일부로서 저장됩니다."
L["|cffff0000Red slots|r are disabled, and will be ignored by the item set."] = "|cffff0000붉은색 슬롯|r은 사용되지 않으며, 아이템 세트에 의해 무시합니다."
L["A |cffffff00yellow slot|r means the item is missing from your inventory, and when you update the set, the item stored in the set will be used, and not the currently equipped one."] = "|cffffff00노란색 슬롯|r은 아이템이 당신의 가방에 없는것을 의미하며, 당신이 세트를 업데이트할때, 세트에 저장된 해당 아이템을 사용할 수 없습니다."
L["A |cff0000ffblue slot|r tells your ClosetGnome to use the item in that slot as the set icon. If a slot is toggled to an icon slot, it is also activated immediately."] = "|cff0000ff푸른색 슬롯|r은 ClosetGnome에게 세트 아이콘으로서 그 슬롯의 아이템 사용을 명령합니다. 만약 아이콘 슬롯이 토글 된다면, 즉시 사용합니다."

L["Add"] = "추가"
L["Creates a new set, or updates an existing one."] = "새로운 세트를 생성하거나 기존의 세트를 갱신합니다."
L["Wear"] = "착용"
L["Change equipment set."] = "착용 장비 세트를 변경합니다."
L["Cancel"] = "취소"
L["Always equip weapons"] = "항상 무기 착용"
L["Equip weapons in sets even if you are in combat."] = "전투중에도 항상 세트로 무기를 착용합니다."
L["Equip %s, or hold down Shift to edit this set."] = "%s 세트를 착용하거나, 이 세트를 편집하려면 Shift를 누르시오."
L["Quips"] = "메세지"
L["Toggle outputting random quips when equipping sets."] = "세트를 착용할 때 랜덤으로 메세지 출력 기능을 전환합니다."
L["Delete"] = "삭제"
L["Deletes the equipment set %s."] = "%s 착용 세트를 삭제합니다."
L["Delete a set."] = "세트 삭제"
L["Are you sure you want to delete the set %s?"] = "정말로 %s 세트를 삭제하길 원하십니까?"
L["<set name>"] = "<세트 이름>"
L["Couldn't find %s in your inventory."] = "소지품에서 %s|1을;를; 찾을 수 없습니다."
L["Enter the set name to delete it."] = "삭제할 세트 이름을 입력하시오."
L["Keybinding"] = "단축키"
L["Assign a keybinding to a set."] = "세트에 단축키를 할당합니다."
L["Assign a keybinding to %s."] = "%s 세트에 단축키를 할당합니다(혹은 삭제하려면 비워두시오)."
L["<key binding>"] = "<단축키>"
L["%s is not a valid keybinding."] = "%s|1은;는; 유효한 단축키가 아닙니다."
L["Registering keybinding %s to set %s."] = "%s 세트를 위한 단축키 %s|1을;를; 등록합니다."
L["%s is already registered to %s."] = "%s 세트를 위한 단축키 %s|1은;는; 이미 등록되어있습니다."
L["Removing keybinding %s from set %s."] = "%s 세트에서 단축키 %s|1을;를; 제거합니다."

L["In combat: %s queued for swap."] = "전투중: 교체하기 위해 %s|1을;를; 대기시킵니다."
L["Added set: %s."] = "세트 추가: %s."
L["Deleted set: %s."] = "세트 삭제: %s."
L["Updating set: %s."] = "세트 갱신: %s."
L["Please use a proper name for your set."] = "세트의 이름은 고유의 이름을 사용하시오."

-- This is what a normal bag is called, as returned from GetItemInfo's
-- subType
L["Bag"] = "가방"

-- Random quips when you equip a set.
L[1] = "그가 다른 신발을 신고 도망치기 전에 ClosetGnome 은 %s 세트를 신속히 착용합니다."
L[8] = "ClosetGnome이 %s 세트를 착용합니다."
L[18] = "%s 세트를 자주 입는 당신은 뭐하는 사람이에요? 당신의 ClosetGnome이 당신을 위아래로 훌터봅니다. 그는 굶주린것 같습니다..."
L[19] = "당신의 ClosetGnome이 굶주려 %s 세트를 뒤지지만 아무것도 찾지 못했습니다. 그에게 먹을것 좀 주시겠습니까?"

