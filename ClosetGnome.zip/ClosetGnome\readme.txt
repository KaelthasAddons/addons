
	ClosetGnome

A gnome helper that keeps your wardrobe organized. At least tries to.
rabbit.magtheridon@gmail.com


	Notice

Although ClosetGnome is released as a "1.0" now, there are some known bugs.
Hopefully I'll have them fixed for an eventual "2.0", but don't get your hopes
up.


	Description

ClosetGnome was written because I was tired of AceWardrobe and its "I will never
be Ace2" status. It is, as you might have guessed, a wardrobe addon.

ClosetGnome tries to be small and efficient and does not do any processing
outside of when you actually add/delete or switch sets. There are some tradeoffs
for this, like you won't have advanced features like what sets you're wearing
currently in a list and stuff, it just shows you the set you last equipped in
the tooltip.


	Sets

There are no autosets in the ClosetGnome addon, but there's nothing stopping you
from making one. ClosetGnome_BigWigs can be used to equip sets per boss.

When you add a set, the character frame will pop up and all the slots will be
green. Clicking a slot will make it red, which means that slot will be *ignored*
for that set. If you want a slot to be empty, make sure it's empty when creating
the set and keep it enabled (green). Control+Clicking a slot will snatch the
icon of the current item there and use as the set icon, which makes the tooltip
list a bit nicer.

To edit a set, hold down Shift when clicking it in the Wear menu or when writing
the command /cg wear <set>.

Equipping a set in combat is obviously not possible, so the set will be queued
automatically and switched to when you get out of combat. If the set contains
any weapons, the weapons will be switched immediately if that option is on.

You can wear a mixed set by doing /script ClosetGnome:WearSet("Set1", "Set2",
...). This way, items from Set1 will be used as the base and items from Set2
will get priority, and they'll be equipped as one set. Any number of sets can be
specified this way.


	Editing Sets

When editing a set your item slots can be labeled with three different colors:

Red-	Slot is inactive and any item currently equipped in the slot WILL NOT be
		saved or equipped.
Green-	Slot is active and any item currently equipped in the slot WILL be saved
		for equipping in the future.
Yellow-	Slot is active BUT the item for that slot is missing.  When the set is
		saved the missing item will be saved for that slot, NOT the currently
		equipped item.

To change a slot's status simply click on it.  Clicking a red(inactive) slot
will change it to green(active).  Clicking a yellow(missing item) slot will
change it to green(active).  Clicking a green(active) slot will change it to
red(inactive).

To set or update an icon to be associated with a set simply ctrl-click on a
slot.  This will make the slot appear blue and force the slot to be active.
Empty slots can not be used for icons.


	Macro

You can easily equip a ClosetGnome set in a macro like so:
/script ClosetGnome:WearSet(MySetName)


	Etc

ClosetGnome fires some Ace2 events when it creates, deletes or equips sets, if
that's interesting to you.

 - Rabbit

