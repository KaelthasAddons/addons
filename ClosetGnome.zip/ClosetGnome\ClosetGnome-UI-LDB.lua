﻿--[[
ClosetGnome, a World of Warcraft addon to manage item sets.
Copyright (C) 2007 Rabbit.

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
]]

local ClosetGnome = ClosetGnome
assert(ClosetGnome, "ClosetGnome-UI-LDB requires ClosetGnome to run.")

if not LibStub then return end
local ldb = LibStub:GetLibrary("LibDataBroker-1.1", true)
if not ldb then return end

local al = LibStub("AceLocale-3.0")

-----------------------------------------------------------------------
-- Localization
do
	do
		local L = al:NewLocale("ClosetGnome-UI-LDB", "enUS", true)
		L["Use the menu (|cffeda55fRight-Click|r) to equip, edit or delete item sets. |cffeda55fClick|r to create a new set."] = true
		L["|cffeda55fClick|r to equip, |cffeda55fShift-Click|r to edit and |cffeda55fCtrl-Click|r to delete %s."] = true
	end
	do
		local L = al:NewLocale("ClosetGnome-UI-LDB", "frFR")
		if L then
			L["Use the menu (|cffeda55fRight-Click|r) to equip, edit or delete item sets. |cffeda55fClick|r to create a new set."] = "Utilisez le menu (|cffeda55fclic droit|r) pour équiper, éditer ou supprimer des ensembles. |cffeda55fClic gauche|r pour créer un nouvel ensemble."
			L["|cffeda55fClick|r to equip, |cffeda55fShift-Click|r to edit and |cffeda55fCtrl-Click|r to delete %s."] = "|cffeda55fClic gauche|r pour équiper, |cffeda55fShift-clic gauche|r pour éditer et |cffeda55fCtrl-clic gauche|r pour supprimer %s."
		end
	end
end

local L = al:GetLocale("ClosetGnome-UI-LDB")

-----------------------------------------------------------------------
-- FuBar UI for ClosetGnome

local defaultIcon = "Interface\\Icons\\INV_Chest_Cloth_17"

CGLDB = ldb:NewDataObject("ClosetGnome", {
	type = "data source",
	text = "ClosetGnome",
	icon = defaultIcon,
})

local menu = nil
local menuNeedsUpdate = true

local CGLDB = CGLDB
local lastEquippedSet = nil

local function menuSorter(a, b)
	return a.text > b.text
end

local function updateMenu()
	menuNeedsUpdate = nil
	menu = {}
	for k in pairs(ClosetGnome.db.char.set) do
		local name = k
		if ClosetGnome.db.char.keybindings[k] then
			name = name .. " |cff999999(" .. ClosetGnome.db.char.keybindings[k] .. ")|r"
		end
		local x = {
			text = name,
			tooltipTitle = k,
			tooltipText = L["|cffeda55fClick|r to equip, |cffeda55fShift-Click|r to edit and |cffeda55fCtrl-Click|r to delete %s."]:format(k),
			func = function()
				if IsShiftKeyDown() then
					ClosetGnome:CreateOrUpdateSet(k)
				elseif IsControlKeyDown() then
					ClosetGnome:DeleteSet(k)
				else
					ClosetGnome:WearSet(k)
				end
			end,
			icon = ClosetGnome.db.char.icons[k],
		}
		table.insert(menu, x)
	end
	table.sort(menu, menuSorter)
end

local popupFrame = CreateFrame("Frame", "ClosetGnomeMenu", UIParent, "UIDropDownMenuTemplate")
function CGLDB.OnClick(self, button)
	if button == "RightButton" then
		if menuNeedsUpdate then updateMenu() end
		EasyMenu(menu, popupFrame, this, 20, 4, "MENU")
	else
		if IsShiftKeyDown() then
			ClosetGnome:CreateOrUpdateSet(lastEquippedSet)
		else
			ClosetGnome:CreateOrUpdateSet()
		end
	end
end

function CGLDB.OnTooltipShow(tt)
	tt:AddLine("ClosetGnome")
	tt:AddLine(L["Use the menu (|cffeda55fRight-Click|r) to equip, edit or delete item sets. |cffeda55fClick|r to create a new set."], 0.2, 1, 0.2, 1)
end

local function updateDisplay()
	if lastEquippedSet then
		CGLDB.text = ClosetGnome:GetSetDisplayName(lastEquippedSet)
	else
		CGLDB.text = "ClosetGnome"
	end
	if ClosetGnome.db.char.icons[lastEquippedSet] then
		CGLDB.icon = ClosetGnome.db.char.icons[lastEquippedSet]
	else
		CGLDB.icon = defaultIcon
	end
	menuNeedsUpdate = true
end

local function updateLatest(event, set)
	lastEquippedSet = set
	updateDisplay()
end
local function removeLatest(event, set)
	if lastEquippedSet == set then
		lastEquippedSet = nil
		updateDisplay()
	end
end
local function init()
	for k in pairs(ClosetGnome.db.char.set) do
		if ClosetGnome:IsSetFullyEquipped(k) then
			updateLatest(nil, k)
			break
		end
	end
end

ClosetGnome.RegisterCallback(CGLDB, "UpdateSet", updateLatest)
ClosetGnome.RegisterCallback(CGLDB, "AddSet", updateLatest)
ClosetGnome.RegisterCallback(CGLDB, "WearSet", updateLatest)
ClosetGnome.RegisterCallback(CGLDB, "DeleteSet", removeLatest)
ClosetGnome.RegisterCallback(CGLDB, "Initialized", init)

