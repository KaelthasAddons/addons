﻿-------------------------------------------------------------------------------
-- Localization                                                              --
-------------------------------------------------------------------------------
--[[ $Id: zhTW.lua 561 2008-10-09 11:00:59Z rabbit $ ]]--

local L = LibStub("AceLocale-3.0"):NewLocale("ClosetGnome", "zhTW")
if not L then return end

L["ClosetGnome"] = "ClosetGnome"
L["ClosetGnome options."] = "ClosetGnome 選項。"
L["|cffeda55fLeft-Click|r a slot to toggle it for this set. Green slots are |cff00ff00enabled|r, red are |cffff0000disabled|r, yellow are |cffffff00missing items|r.\n\nIf you want to assign an |cff0000fficon|r to this set, you can |cffeda55fCtrl-Click|r a slot to use that slots item as the icon.\n\nType the desired set name below and click Add when you are done."] = "在欄位上|cffeda55f左擊|r決定是否在此套裝使用這裝備，綠色表示|cff00ff00使用|r，紅色|cffff0000不使用|r，黃色|cffffff00找不到|r。\n\n若你想要指定裝備的|cff0000ff圖示|r，可以使用|cffeda55fCtrl-點擊|r。\n\n選好後在下面欄內輸入套裝名，並點擊「新增」。"

L["|cff00ff00Green slots|r are active, and any item currently in a green slot will be saved as part of the item set."] = "|cff00ff00綠色欄位|r表示使用，在此欄位的裝備會被保存在套裝中。"
L["|cffff0000Red slots|r are disabled, and will be ignored by the item set."] = "|cffff0000紅色欄位|r表示不使用，在此欄位的裝備不會被保存在套裝中。"
L["A |cffffff00yellow slot|r means the item is missing from your inventory, and when you update the set, the item stored in the set will be used, and not the currently equipped one."] = "|cffffff00黃色欄位|r表示該裝備並不在你的庫存中，當你更新套裝時，套裝中該欄位的裝備會被保存，而不是你現在在該欄位穿著的裝備。"
L["A |cff0000ffblue slot|r tells your ClosetGnome to use the item in that slot as the set icon. If a slot is toggled to an icon slot, it is also activated immediately."] = "|cff0000ff藍色欄位|r使 ClosetGnome 使用該欄位的裝備圖示為套裝圖示。假如該欄位被選擇為套裝圖示，該欄位會被保存在套裝中。"

L["Add"] = "新增"
L["Creates a new set, or updates an existing one."] = "創建新套裝，或更新一個現有的套裝。"
L["Wear"] = "穿上"
L["Change equipment set."] = "裝備套裝。"
L["Cancel"] = "取消"
L["Always equip weapons"] = "一直裝備武器"
L["Equip weapons in sets even if you are in combat."] = "進入戰鬥狀態時，仍使用套裝中的武器。"
L["Equip %s, or hold down Shift to edit this set."] = "裝備%s，或按住Shift鍵來編輯套裝。"
L["Quips"] = "廢話"
L["Toggle outputting random quips when equipping sets."] = "當你換裝時隨機發出廢話。"
L["Delete"] = "刪除"
L["Deletes the equipment set %s."] = "刪除套裝%s。"
L["Delete a set."] = "刪除一個套裝。"
L["Are you sure you want to delete the set %s?"] = "你確定想刪除套裝%s嗎?"
L["<set name>"] = "<套裝名稱>"
L["Couldn't find %s in your inventory."] = "在你的物品中無法找到%s。"
L["Enter the set name to delete it."] = "輸入套裝名稱以刪除它。"
L["Keybinding"] = "快捷鍵"
L["Assign a keybinding to a set."] = "給套裝設定一個快捷鍵。"
L["Assign a keybinding to %s."] = "分配一個快捷鍵給%s (或清空)。"
L["<key binding>"] = "<快捷鍵>"
L["%s is not a valid keybinding."] = "%s是一個無效的快捷鍵。"
L["Registering keybinding %s to set %s."] = "將快捷鍵%s註冊給套裝%s。"
L["%s is already registered to %s."] = "%s已經註冊給%s。"
L["Removing keybinding %s from set %s."] = "從套裝%2$s中移除快捷鍵%1$s。"

L["In combat: %s queued for swap."] = "進入戰鬥: %s在佇列等候中。"
L["Added set: %s."] = "新增套裝: %s。"
L["Deleted set: %s."] = "刪除套裝: %s。"
L["Updating set: %s."] = "更新套裝: %s。"
L["Please use a proper name for your set."] = "請為你的套裝使用正確的名字。"

-- This is what a normal bag is called, as returned from GetItemInfo's
-- subType
L["Bag"] = "容器"

-- Random quips when you equip a set.
L[1] = "ClosetGnome 已幫你穿上套裝: %s。"
L[2] = "終有一天，ClosetGnome 會幫你裝備一件神器的。現在，ClosetGnome 只能幫你裝備套裝: %s。"
L[3] = "這是不是旋風?! 不! 只是 ClosetGnome 幫你穿上套裝: %s!"

