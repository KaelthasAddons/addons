
local L = LibStub("AceLocale-3.0"):NewLocale("ClosetGnome", "ruRU")
if not L then return end

L["ClosetGnome"] = "ClosetGnome"
L["ClosetGnome options."] = "Опции ClosetGnome."
L["|cffeda55fLeft-Click|r a slot to toggle it for this set. Green slots are |cff00ff00enabled|r, red are |cffff0000disabled|r, yellow are |cffffff00missing items|r.\n\nIf you want to assign an |cff0000fficon|r to this set, you can |cffeda55fCtrl-Click|r a slot to use that slots item as the icon.\n\nType the desired set name below and click Add when you are done."] = "|cffeda55fЛКМ|r по слоту для включения-исключения его из сета. Зеленые слоты |cff00ff00включены|r, крысные - |cffff0000исключены|r, желтые - |cffffff00вещь не найдена|r.\n\nЕсли Вы хотите назначить |cff0000ffиконку|r для этого сета, сделайте |cffeda55fCtrl-клик|r по слоту, стобы использовать иконку вещи в том слоте.\n\nВведите название сета и нажмите Добавить, когда закончите."

L["|cff00ff00Green slots|r are active, and any item currently in a green slot will be saved as part of the item set."] = "|cff00ff00Зеленые слоты|r - активные, любая вещь в зеленом слоте будет сохранена как чать сета."
L["|cffff0000Red slots|r are disabled, and will be ignored by the item set."] = "|cffff0000Красные слоты|r - не активные и будут игнорированы сетом."
L["A |cffffff00yellow slot|r means the item is missing from your inventory, and when you update the set, the item stored in the set will be used, and not the currently equipped one."] = "|cffffff00Желтый слот|r означает, что вещь не найдена в вашем инвентаре. Если вы обновите сет, то будет использована вещь, сохраненная в сете, а не та, что сейчас одета вместо нее."
L["A |cff0000ffblue slot|r tells your ClosetGnome to use the item in that slot as the set icon. If a slot is toggled to an icon slot, it is also activated immediately."] = "|cff0000ffГолубой слот|r сообщает ClosetGnome использовать иконку вещи в этом слоте как иконку сета. Также синий слот активирует слот."

L["Add"] = "Добавить"
L["Creates a new set, or updates an existing one."] = "Создает новый сет или обновляет старый."
L["Wear"] = "Одеть"
L["Change equipment set."] = "Сменить сет."
L["Cancel"] = "Отмена"
L["Always equip weapons"] = "Всегда одевать оружие"
L["Equip weapons in sets even if you are in combat."] = "Одевать оружие сета, даже если вы в бою."
L["Equip %s, or hold down Shift to edit this set."] = "Одеть сет %s или зажмите Shift для его редактирования."
L["Quips"] = "Приколы"
L["Toggle outputting random quips when equipping sets."] = "Вкл-выкл вывод случайных фраз-приколов при смене сетов."
L["Delete"] = "Удалить"
L["Deletes the equipment set %s."] = "Удаляет сет %s."
L["Delete a set."] = "Удалить сет."
L["Are you sure you want to delete the set %s?"] = "Вы уверены, что хотите удалить сет %s?"
L["<set name>"] = "<Название сета>"
L["Couldn't find %s in your inventory."] = "Не удалось найти %s в Вашем инвентаре."
L["Enter the set name to delete it."] = "Введите название сета для его удаления."
L["Keybinding"] = "Назн. клавиш"
L["Assign a keybinding to a set."] = "Назначить клавишу сету."
L["Assign a keybinding to %s."] = "Назначить клавишу для %s (оставьте пустым для отмены)."
L["<key binding>"] = "<Клавиша>"
L["%s is not a valid keybinding."] = "%s не является допустимой клавишей."
L["Registering keybinding %s to set %s."] = "Регистрирую клавишу %s для сета %s."
L["%s is already registered to %s."] = "%s уже зарегистрирована для %s."
L["Removing keybinding %s from set %s."] = "Убираем клавишу %s у сета %s."

L["In combat: %s queued for swap."] = "В бою: %s на очереди для смены."
L["Added set: %s."] = "Сет добавлен: %s."
L["Deleted set: %s."] = "Сет удален: %s."
L["Updating set: %s."] = "Сет обновлен: %s."
L["Please use a proper name for your set."] = "Используйте правильное название для сета, пожалуйста."

-- This is what a normal bag is called, as returned from GetItemInfo's
-- subType
L["Bag"] = "Сумка"

-- Random quips when you equip a set.
L[1] = "Ваш КлозетГном быстро облачает Вас в %s и убегает за вторым носком."
L[2] = "Единожды за цикл Голубой Луны, КлозетГном одевает на Вас Артефакт... Не сегодня к сожалению. Сегодня для Вас %s."
L[3] = "КлозетГномы очень опрятны. Но не Ваши... Одев %s, старые одеяния он просто бросает в угол."
L[4] = "Практически танцуя КлозетГном надевает на Вас %s. Хотя это был очень безобразный танец."
L[5] = "Поскольку сегодня Вы забыли покормить своего КлозетГнома, он выражает свою злость, одев %s на Вас задом на перед."
L[6] = "Не позволяйте КлозетГному тяготеть ни к чему, кроме %s."
L[7] = "%s отлично смотрится на Вас, по крайней мере лучше, чем смотрелось на КлозетГноме когда Вы поймали его."
L[8] = "КлозетГном одевает %s."
L[9] = "Ваш КлозетГном с отвращением отворачивается, одевая %s. Вы не уверены почему, но что это за вонь?.."
L[10] = "Это Вихрь?! Не, это КлозетГном одевает вас в %s!"
L[11] = "Недавно вернувшись со съезда КлозетГномов, он находит о чем поговоить, пока надевает на Вас %s."
L[12] = "'Getting Jiggy With It' никогда не была Вашей любимым клипом, но Вы вынуждены признать, он смотрится несравненно круче с %s."
L[13] = "Даже учитывая, что на Вашем моющем средстве написано 'Certified by ClosetGnomes, Inc.', совершенно ясно, что %s не чистили уже долго."
L[14] = "У носков сета %s тот же цвет... и такой же был у сета до него, и у того, что до этого..."
L[15] = "Вместо того, чтобы одеть на Вас %s, КлозетГном начинает грызть Вашу ногу. Вы стряхиваете его проч и одеваетесь сами."
L[16] = "Никогда никогда не подозревал, что вы используете КлозетГнома. Большинство из них довольно хороши в напяливании вещей, типа %s."
L[17] = "Ваш КлозетГном голоден, поэтому он выворачивает карманы %s в поисках еды, но ничего не находит. Вы вообще кормите его?"
L[18] = "Главное правило КолзетГномов - не говорить о %s."
L[19] = "%s почему-то выглядит по-другому."
L[20] = "Нету тут никаких %s."
L[21] = "Вы чувствуете жажду - жажду %s!"
L[22] = "КлозетГном кладет %s в угол. Затем возвращается и одевает его."
L[23] = "Hasta la vista, %s."
L[24] = "Держите %s рядом, а вашего КлозетГнома ещё ближе."
L[25] = "Лучший друг настоящих пацанов - КлозетГном с %s."
L[26] = "Вам нравится запах %s по утрам."
L[27] = "Да будет с Вами КлозетГном. Да принесет он %s."

-- Total number of quips
L["num_quips"] = 27

