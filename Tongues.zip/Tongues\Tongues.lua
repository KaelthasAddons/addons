----------------------------------------------------------------------------------------------------------
	Tongues.Version = "1.0.4.4"									--
--	Note: This is completely inspired by the Lore 7.5.7 AddOn					--
--	I decided to take a different approach, and as I got more into it I started having		--
--	problems doing further modification (mostly with the XML,) it just seemed better to		--
--	start over!											--
----------------------------------------------------------------------------------------------------------
--  I prefer to use the table structure form for the functions so that we can instantiate the whole     --
--  thing 												--
----------------------------------------------------------------------------------------------------------
TONGUES_MAX_MSG_LEN = 247;
--===============================================MAIN===================================================--
Tongues = Class:inherits(Tongues,{
	Hooks = {
		Send = SendChatMessage;
		Receive = ChatFrame_OnEvent;
	};
	PreviousSentMsg = "";
	Colors = {};
	Settings = {
		Character = {					-- Player settings get applied only the the current player
			Language = nil;
			Fluency = {};

			Dialect  = "<None>";

			Affect	 = "<None>";
			AffectFrequency = 100;

			Filter   = "<None>";

			Faction = "";
			Race    = "";
			Class   = "";

			Debugging 		= false;
			DialectDrift		= false;
			LanguageLearning	= true;
			ShapeshiftLanguage	= true;
			LoreCompatibility	= true;

			Translations = {
				Self = false;
				Targetted = false;
				Party = false;
				Guild = false;
				Officer = false;
				Raid = false;
				RaidAlert = false;
				Battleground = false;
			};

			Translators = {};

			Screen = {
				Self = false;
				Targetted = false;
				Party = true;
				Guild = true;
				Officer = true;
				Raid = true;
				RaidAlert = true;
				Battleground = true;
			};
			UI = {
				MainMenu = {
					point = "CENTER", 
					relativeTo = UIParent, 
					relativePoint = "CENTER",
					xOfs = 0;
					yOfs = 0;
				};
				MiniMenu = {
					point = "CENTER", 
					relativeTo = UIParent, 
					relativePoint = "CENTER",
					xOfs = 0;
					yOfs = 0;
				};
			}
		};
	};
	---------------------------------------------------------------------------------------
	Command = function(msg)
		local param = {};
		msg = string.gsub(msg,"([%a0-9]+)", function(a)
				table.insert(param,#param + 1,a);
		end);

		local i,k,v
		if param ~= nil then
			if param[1] ~= nil and string.lower(param[1]) == "help" then
				for i=1,NUM_CHAT_WINDOWS do
					getglobal("ChatFrame" .. i ):AddMessage("Tongues Commands: "			,1,1,0)
					getglobal("ChatFrame" .. i ):AddMessage("   <language>"				,1,1,0)
					--getglobal("ChatFrame" .. i ):AddMessage("   Language <language>"		,1,1,0)
					--getglobal("ChatFrame" .. i ):AddMessage("   Dialect <dialect>"			,1,1,0)
					--getglobal("ChatFrame" .. i ):AddMessage("   Affect <affect>"			,1,1,0)
					--getglobal("ChatFrame" .. i ):AddMessage("   Filter <filter>"			,1,1,0)
					--getglobal("ChatFrame" .. i ):AddMessage("   LoreCompatible <true|false>"	,1,1,0)
					--getglobal("ChatFrame" .. i ):AddMessage("   DialectDrift <true|false>"		,1,1,0)
					--getglobal("ChatFrame" .. i ):AddMessage("   Shapeshift <true|false>"		,1,1,0)
					getglobal("ChatFrame" .. i ):AddMessage("   Help"				,1,1,0)
				end;
			elseif param[1] ~= nil and string.lower(param[1]) == "language" then
				if param[2] ~= nil then
					Tongues:SetLanguage(param[2]);
				end;
			elseif param[1] ~= nil and string.lower(param[1]) == "dialect" then

			elseif param[1] ~= nil and string.lower(param[1]) == "filter" then

			elseif param[1] ~= nil and string.lower(param[1]) == "lorecompatible" then

			elseif param[1] ~= nil and string.lower(param[1]) == "dialectdrift" then

			elseif param[1] ~= nil and string.lower(param[1]) == "shapeshift" then

			elseif param[1] ~= nil then
				Tongues:SetLanguage(param[1]);
			end;
		end;
	end;
	---------------------------------------------------------------------------------------
	OnLoad = function()
	end;
	---------------------------------------------------------------------------------------
	OnEvent = function(self, event)
		self = Tongues;
		--local e = event;

		if	(event=="ADDON_LOADED") then
			self.Settings.Character.Faction = UnitFactionGroup("player");
			self.Settings.Character.Class   = UnitClass("player");
			self.Settings.Character.Race	= UnitRace("player");
		elseif	(event=="VARIABLES_LOADED") then
			---BETTER TO HEAL TOTALLY PROGRAMMATICALLY
			local tempUI = self.Settings.Character.UI;
			local tempTranslations = self.Settings.Character.Translations;
			local tempLanguage = self.Settings.Character.Language;
			local tempLanguageLearning = self.Settings.Character.LanguageLearning

			local tempScreen = self.Settings.Character.Screen;
			local tempFluency = self.Settings.Character.Fluency;
			local tempAffectFrequency = self.Settings.Character.AffectFrequency;
			local tempTranslators = self.Settings.Character.Translators;

			self.Settings.Character = Tongues_Character

			--- HEAL VARIABLES FROM OLD VERSIONS OR MALFORMED VARIABLES
			if self.Settings.Character.UI == nil then
				self.Settings.Character.UI = tempUI;
			end;
			if self.Settings.Character.Translations == nil then
				self.Settings.Character.Translations = tempTranslations;
			end;
			if self.Settings.Character.Screen == nil then
				self.Settings.Character.Screen = tempScreen;
			end;
			if self.Settings.Character.Fluency == nil then
				self.Settings.Character.Fluency = tempFluency;
			end;
			if self.Settings.Character.AffectFrequency == nil then
				self.Settings.Character.AffectFrequency = tempAffectFrequency;
			end;
			if self.Settings.Character.Translators == nil then
				self.Settings.Character.Translators = tempTranslators;
			end;
			if self.Settings.Character.Language == nil or self.Language[self.Settings.Character.Language] == nil then
				self.Settings.Character.Language = tempLanguage;
			end;
			if self.Settings.Character.LanguageLearning == nil then
				self.Settings.Character.LanguageLearning = tempLanguageLearning;
			end;

			if self.Dialect[self.Settings.Character.Dialect] == nil then
				self.Settings.Character.Dialect = "<None>";
			end;
			if self.Affect[self.Settings.Character.Affect] == nil then
				self.Settings.Character.Affect = "<None>";
			end;
			if self.Filter[self.Settings.Character.Filter] == nil then
				self.Settings.Character.Filter = "<None>";
			end;

			if self.Settings.Character.Language == nil then
				if UnitRace("player") == "Human" then
					self.Settings.Character.Language = "Common"
				elseif UnitRace("player") == "Orc" then
					self.Settings.Character.Language = "Orcish"
				elseif UnitRace("player") == "Blood Elf" then
					self.Settings.Character.Language = "Thalassian"
				elseif UnitRace("player") == "Night Elf" then
					self.Settings.Character.Language = "Darnassian"
				elseif UnitRace("player") == "Draenei" then
					self.Settings.Character.Language = "Draenei"
				elseif UnitRace("player") == "Tauren" then
					self.Settings.Character.Language = "Taurahe"
				elseif UnitRace("player") == "Dwarf" then
					self.Settings.Character.Language = "Dwarvish"
				elseif UnitRace("player") == "Undead" then
					self.Settings.Character.Language = "Gutterspeak"
				elseif UnitRace("player") == "Gnome" then
					self.Settings.Character.Language = "Gnomish"
				elseif UnitRace("player") == "Troll" then
					self.Settings.Character.Language = "Troll"
				end;
				self.Settings.Character.Fluency[self.Settings.Character.Language] = Tongues_Character.Fluency[self.Settings.Character.Language] or 100

				if UnitFactionGroup("player") == "Alliance" then
					self.Settings.Character.Fluency["Common"] = Tongues_Character.Fluency["Common"] or 100
				elseif UnitFactionGroup("player") == "Horde" then
					self.Settings.Character.Fluency["Orcish"] = Tongues_Character.Fluency["Orcish"] or 100
				end;

				if UnitClass("player") == "Druid" then
					self.Settings.Character.Fluency["Bear"] = self.Settings.Character.Fluency["Bear"] or 100;
					self.Settings.Character.Fluency["Cat"] = self.Settings.Character.Fluency["Cat"] or 100;
					self.Settings.Character.Fluency["Bird"] = self.Settings.Character.Fluency["Bird"] or 100;
					self.Settings.Character.Fluency["Moonkin"] = self.Settings.Character.Fluency["Moonkin"] or 100;
					self.Settings.Character.Fluency["Trentish"] = self.Settings.Character.Fluency["Trentish"] or 100;
					self.Settings.Character.Fluency["Seal"] = self.Settings.Character.Fluency["Seal"] or 100;
				elseif UnitClass("player") == "Shaman" then
					self.Settings.Character.Fluency["Wolf"] = self.Settings.Character.Fluency["Wolf"] or 100;
					self.Settings.Character.Fluency["Kalimag"] = self.Settings.Character.Fluency["Kalimag"] or 100;
				elseif UnitClass("player") == "Warlock" then
					self.Settings.Character.Fluency["Eredun"] = self.Settings.Character.Fluency["Eredun"] or 100;
					self.Settings.Character.Fluency["Demonic"] = self.Settings.Character.Fluency["Demonic"] or 100;
				end;
			end;
			UIDropDownMenu_Initialize(Tongues.UI.MainMenu.Speak.LanguageDropDown.Frame, Tongues.UpdateLanguageDropDown);	
			self:SetLanguage(self.Settings.Character.Language);

			self.Settings.Global = Tongues_Global;
			self.UI:LoadDefaults();

		elseif event == "UPDATE_CHAT_COLOR" and (
			arg1 == "SAY" or 
			arg1 == "WHISPER" or
			arg1 == "YELL" or
			arg1 == "PARTY" or
			arg1 == "GUILD" or
			arg1 == "OFFICER" or
			arg1 == "RAID" or
			arg1 == "RAID_WARNING" or
			arg1 == "RAID_LEADER" or
			arg1 == "BATTLEGROUND" or
			arg1 == "BATTLEGROUND_LEADER" or
			arg1 == "CHANNEL"
			) then
				Tongues.Colors[arg1] = {arg2, arg3, arg4}	
		elseif (event=="CHAT_MSG_ADDON") and (arg1 == "Tongues") then

			local TP = "<Tongues>"
			local TPLen = string.len(TP)
			--REQUEST TRANSLATION------------------------------------------------------------------
			if ( string.sub( arg2, 1, TPLen + 4) == TP .. ":RT:" ) then

				--REMOVE TAG--
				arg2 = string.sub(arg2, TPLen + 5 )

				--REMOVE FLUENCY INFO AFTER SAVING IN VARIABLE FLUENCY
				local fluency = string.gsub(arg2, "^fluency=([0-9]+):([%a%A]+)", "%1")
				arg2 = string.gsub(arg2, "fluency=" .. fluency .. "[:]+", "");
				fluency = tonumber(fluency);

				--REMOVE CHANNEL AFTER CAPTURING IT (WILL HAVE TO BE ADDED TO OUTBOUND AS WELL)
				local channel = string.gsub(arg2, "^channel=([%a_]+):([%a%A]+)", "%1")
				arg2 = string.gsub(arg2, "channel=" .. channel .. "[:]+", "");

				local frame = string.gsub(arg2, "^frame=([0-9]+):([%a%A]+)", "%1")
				arg2 = string.gsub(arg2, "frame=" .. frame .. "[:]+", "");

				local language = string.gsub(arg2, "^language=([%a%A]+)", "%1")
				arg2 = string.gsub(arg2, "language=" .. language .. "[:]+", "")

				if language == nil then
					language = "Upgrade"
				end;

				--OLD CODE KEPT JUST IN CASE :)
				--local prepstring = TP .. ":TR:channel=" .. channel .. ":frame=" .. frame .. ":" .. self:UnderstandPartial(fluency, language) 

				local prepstring = TP .. ":TR:channel=" .. channel .. ":frame=" .. frame .. ":" .. "[" .. language .. "] " .. self.PreviousSentMsg
				prepstring = string.sub(prepstring, 1, TONGUES_MAX_MSG_LEN)
				SendAddonMessage("Tongues", prepstring, "WHISPER",  arg4)

			--TRANSLATION RESPONSE RECEIVED--------------------------------------------------------
			elseif ( string.sub( arg2, 1, TPLen + 4) == TP .. ":TR:" ) then

				arg2 = string.sub(arg2, TPLen + 5)

				local channel = string.gsub(arg2, "^channel=([%a_]+):([%a%A]+)", "%1")
				arg2 = string.gsub(arg2, "channel=" .. channel .. "[:]+", "");

				local frame = string.gsub(arg2, "^frame=([0-9]+):([%a%A]*)", "%1")
				arg2 = string.gsub(arg2, "frame=" .. frame .. "[:]+", "");

				local colortable = {};
				local prefix = "";
				local postfix = "";
				if 	channel == "CHAT_MSG_SAY" then
					postfix = " says"
					colortable = self.Colors.SAY;
				elseif 	channel == "CHAT_MSG_YELL" then
					postfix = " yells"
					colortable = self.Colors.YELL;
				elseif	channel == "CHAT_MSG_PARTY" then
					prefix = "[Party] ";
					colortable = self.Colors.PARTY;
				elseif 	channel == "CHAT_MSG_GUILD" then
					prefix = "[Guild] ";
					colortable = self.Colors.GUILD;
				elseif 	channel == "CHAT_MSG_OFFICER" then
					prefix = "[Officer] ";
					colortable = self.Colors.OFFICER;
				elseif 	channel == "CHAT_MSG_RAID" then
					prefix = "[Raid] ";
					colortable = self.Colors.RAID;
				elseif 	channel == "CHAT_MSG_RAID_WARNING" then
					colortable = self.Colors.RAID_WARNING;
				elseif 	channel == "CHAT_MSG_BATTLEGROUND" then
					prefix = "[Battleground] ";
					colortable = self.Colors.BATTLEGROUND;
				end;

				local prepstring = prefix .. "[" ..arg4.. "]" .. postfix .. ": " .. arg2
				prepstring = string.sub(prepstring, 1, TONGUES_MAX_MSG_LEN)
				
				getglobal("ChatFrame".. frame):AddMessage(prepstring, (colortable[1] + 1)/2, (colortable[2] + 1)/2, (colortable[3] + 0)/2)
			-- REQUEST VERSION
			elseif ( string.sub( arg2, 1, TPLen + 4) == TP .. ":RV:" ) then
				local prepstring = TP .. ":VR:version=" .. self.Version .. ":"
				prepstring = string.sub(prepstring, 1, TONGUES_MAX_MSG_LEN)
				SendAddonMessage("Tongues", prepstring, "WHISPER",  arg4)
			-- VERSION RECEIVED
			elseif ( string.sub( arg2, 1, TPLen + 4) == TP .. ":VR:" ) then
				arg2 = string.sub(arg2, TPLen + 5)
				local version = string.gsub(arg2, "^version=([0-9%.%s%a]+):", "%1")
				SELECTED_CHAT_FRAME:AddMessage("(My Tongues version is v" .. version .. ")",1,1,0);
			-- REQUEST LEARN
			elseif ( string.sub( arg2, 1, TPLen + 4) == TP .. ":RL:" ) then
				arg2 = string.sub(arg2, TPLen + 5)
				local language = string.gsub(arg2, "^language=([%a'%s%-]+):[%a%A]+", "%1")
				arg2 = string.gsub(arg2, "language=" .. language .. "[:]+", "");
				local faction = string.gsub(arg2, "^faction=([%a]+):[%a%A]+", "%1")
				arg2 = string.gsub(arg2, "faction=" .. faction .. "[:]+", "");
				local race = string.gsub(arg2, "^race=([%a%s]+):[%a%A]+", "%1")
				arg2 = string.gsub(arg2, "race=" .. race .. "[:]+", "");
				local class = string.gsub(arg2, "^class=([%a'%s]+):[%a%A]+", "%1")
				arg2 = string.gsub(arg2, "class=" .. class .. "[:]+", "");
				local frame = string.gsub(arg2, "^frame=([0-9]+):[%a%A]+", "%1")
				arg2 = string.gsub(arg2, "frame=" .. frame .. "[:]+", "");
				local fluency = string.gsub(arg2, "^fluency=([0-9]+)[%a%A]*", "%1")
				arg2 = string.gsub(arg2, "fluency=" .. fluency .. "[:]*", "");
				fluency =tonumber(fluency)

				local learn = 1;
				if self.Language[language] ~= nil and self.Language[language].Difficulty ~= nil and 
				(self.Settings.Character.Fluency[language] == nil or self.Settings.Character.Fluency[language] >= fluency) 
				and arg4 ~= UnitName("player") then
					local d = self.Language[language].Difficulty["default"] or 0
					local f = self.Language[language].Difficulty[faction] 	or 0
					local r = self.Language[language].Difficulty[race] 	or 0
					local c = self.Language[language].Difficulty[class] 	or 0
					local result = d + f + r + c

					math.randomseed(math.random(0,2147483647)+(GetTime()*1000));

					if math.random(1, result+1) == 1 then
						local prepstring = TP .. ":LR:language=" .. language .. ":" .. "learn=" .. learn
						prepstring = string.sub(prepstring, 1, TONGUES_MAX_MSG_LEN)

						SendAddonMessage("Tongues", prepstring, "WHISPER",  arg4)
					end
				end;
			-- LEARN RECEIVED
			elseif ( string.sub( arg2, 1, TPLen + 4) == TP .. ":LR:" ) then
				arg2 = string.sub(arg2, TPLen + 5)
				local language = string.gsub(arg2, "^language=([^:]+):[%a%A]+", "%1")
				arg2 = string.gsub(arg2, "language=" .. language .. "[:]+", "");
				local learn = string.gsub(arg2, "^learn=([0-9]+):?", "%1")
				arg2 = string.gsub(arg2, "learn=" .. learn , "");

				learn = tonumber(learn) or 0

				if self.Settings.Character.Fluency[language] == nil then
					self.Settings.Character.Fluency[language] = 0;
				end;
				
				self.Settings.Character.Fluency[language] = self.Settings.Character.Fluency[language] + learn;

				if self.Settings.Character.Fluency[language] > 100 then
					self.Settings.Character.Fluency[language] = 100
				elseif self.Settings.Character.Fluency[language] < 0 then
					self.Settings.Character.Fluency[lanaguage] = 0
				end;
				UIDropDownMenu_Initialize(Tongues.UI.MainMenu.Speak.LanguageDropDown.Frame, Tongues.UpdateLanguageDropDown);	
				SELECTED_CHAT_FRAME:AddMessage(language .. " skill up +" .. learn,0.5,0.5,1);
			end;
		end;

	end;
	---------------------------------------------------------------------------------------
	Initialize = function(self) 
		table.insert(self,self.UI);
	
		SLASH_TONGUES1 = "/tongues";
		SlashCmdList["TONGUES"] = self.Command;
	
		Tongues_Global = self.Settings.Global;
		Tongues_Character = self.Settings.Character;
	
		self.Filter = merge({
			self.Filter,
			self.Custom.Filter
		});
	
		self.Dialect = merge({
			self.Dialect,
			self.Custom.Dialect
		});
		self.Language = merge({
			self.Language,
			self.Custom.Language
		});
		self.Affect = merge({
			self.Affect,
			self.Custom.Affect
		});
		self.Frame = CreateFrame("Frame",nil,UIParent);
		self.Frame:RegisterEvent("ADDON_LOADED");
		self.Frame:RegisterEvent("VARIABLES_LOADED");
		self.Frame:RegisterEvent("CHAT_MSG_ADDON");
		self.Frame:RegisterEvent("UPDATE_CHAT_COLOR");
		self.Frame:SetScript("OnEvent", Tongues.OnEvent);
		self.UI:Configure()
	end;
	--==========================================================================================================
	HandleSend = function(self, msg, chatType, language, channel)
		--- NEVER PARSE CHANNEL EMOTE AFK DND etc,
		if (chatType=="CHANNEL" or chatType=="EMOTE" or chatType=="AFK" or chatType=="DND" or chatType=="BATTLEGROUND_LEADER" or chatType == "RAID_LEADER") then
		 	self.Hooks.Send( msg, chatType, language, channel );
			return
		end

		local languagename = "";
		local translatelanguage = "";

		--- GET THE RIGHT LANGUAGE AND TAG
		if self.Settings.Character.ShapeshiftLanguage == true and GetShapeshiftForm(true) ~= 0 and UnitClass("player") == "Druid" then
			languagename = "[" .. self:ReturnForm() .."] ";
			translatelanguage = self:ReturnForm()
		elseif	UnitFactionGroup("player") == "Alliance" and self.Settings.Character.Language == "Common" then
		elseif  UnitFactionGroup("player") == "Horde" and self.Settings.Character.Language == "Orcish" then
		elseif self.Settings.Character.Language == self:ReturnSpecialLanguage() then
			language = self.Settings.Character.Language;
			translatelanguage = language;
		else
			languagename = "[" ..  self.Settings.Character.Language .."] ";
			translatelanguage = self.Settings.Character.Language
		end;

		--- APPLY BASIC ROLEPLAYING FULL SENTANCE FILTERS (SHOULDNT EFFECT LINKS)
		msg = self:Substitute(msg, self.Filter[self.Settings.Character.Filter]["filters"]);
		msg = self:ApplyEffect(msg, self.Filter[self.Settings.Character.Filter]["affects"]);

		self.PreviousSentMsg = self:ApplySpeech(msg, false);

		--- OUTBOUND OOC NOT YET FUNCTIONING
		--if string.match(msg , "^%(%([%a%A]+%)%)%A?$" ) ~= nil then
		--	if UnitFactionGroup("player") == "Alliance" then
		--		language = "Common";
		--		languagename = "";
		--		translatelanguage = "";
		--	elseif UnitFactionGroup("player") == "Alliance" then
		--		language = "Orcish";
		--		languagename = "";
		--		translatelanguage = "";
		--	end;
		--	v = msg;
		--else 
			-- PROCESSES PARTS OF MESSAGE THAT ARE NOT LINKS
			v = self:ParseLink(msg, language);
		--end;

		--- Lots of settings have to be handled here
		-----TRANSLATIONS to SELF
		if (self.Settings.Character.Translations.Self == true and chatType~="WHISPER" and chatType~="CHANNEL") then
			SELECTED_CHAT_FRAME:AddMessage("(" .. UnitName("player") .. ": " ..msg .. ")",1,1,0);
		end
		-----PROCESS for SAY or YELL
		if (chatType == "SAY" or chatType == "YELL") then
			self.Hooks.Send( languagename .. v , chatType, language, channel);
		end;
		----TRANSLATE TO TARGETTED
		if (self.Settings.Character.Translations.Targetted == true) and (UnitIsPlayer("target") ~= nil) and (chatType == "SAY" or chatType == "YELL") and UnitFactionGroup("target") == UnitFactionGroup("player") and languagename ~= "" then
			self.Hooks.Send("[Translation - " .. translatelanguage .. "] " .. self:ApplySpeech(msg, false), "WHISPER", nil, UnitName("target"));
		end
		----TRANSLATE TO TRANSLATORS IF THEY ARE VISIBLE
		for kname,vname in pairs(self.Settings.Character.Translators) do
			self.Hooks.Send("[Translation - " .. translatelanguage .. "] " .. self:ApplySpeech(msg, false), "WHISPER", nil, vname);
		end;
		-----DONT DO TRANSLATION IF WHISPER IS SENT
		if (chatType=="WHISPER") then
			self.Hooks.Send(msg , chatType, language, channel);
		else
			-----TRANSLATIONS and PROCESS for PARTY 
			if     (self.Settings.Character.Screen.Party == true and chatType == "PARTY") then
				self.Hooks.Send(msg , chatType, language, channel);
			elseif (self.Settings.Character.Translations.Party == true and chatType == "PARTY") then
				self.Hooks.Send(self:ApplySpeech(msg, false), "PARTY", nil, channel);
			elseif (self.Settings.Character.Translations.Party == true and chatType ~= "PARTY" and GetNumPartyMembers() ~= 0) then
				self.Hooks.Send(self:ApplySpeech(msg, false), "PARTY", nil, channel);
			elseif (self.Settings.Character.Translations.Party == false and chatType == "PARTY") then
				self.Hooks.Send(languagename .. v , chatType, language, channel);
			end

			-----TRANSLATIONS and PROCESS for GUILD 
			if     (self.Settings.Character.Screen.Guild == true and chatType == "GUILD") then
				self.Hooks.Send(msg , "GUILD", language, channel);
			elseif (self.Settings.Character.Translations.Guild == true and chatType == "GUILD") then
				self.Hooks.Send(self:ApplySpeech(msg, false), "GUILD", nil, channel);
			elseif (self.Settings.Character.Translations.Guild == true and chatType ~= "GUILD" and IsInGuild()) then
				self.Hooks.Send(self:ApplySpeech(msg, false), "GUILD", nil, channel);
			elseif (self.Settings.Character.Translations.Guild == false and chatType == "GUILD") then
				self.Hooks.Send(languagename .. v , chatType, language, channel);
			end
			-----TRANSLATIONS and PROCESS for OFFICER
			if     (self.Settings.Character.Screen.Officer == true and chatType == "OFFICER") then
				self.Hooks.Send(msg , "OFFICER", language, channel);
			elseif (self.Settings.Character.Translations.Officer == true and chatType == "OFFICER") then
				self.Hooks.Send(self:ApplySpeech(msg, false), "OFFICER", nil, channel);
			elseif (self.Settings.Character.Translations.Officer == true and chatType ~= "OFFICER" and IsInGuild()) then
				self.Hooks.Send(self:ApplySpeech(msg, false), "OFFICER", nil, channel);
			elseif (self.Settings.Character.Translations.Officer == false and chatType == "OFFICER") then
				self.Hooks.Send(languagename .. v , chatType, language, channel);
			end
			-----TRANSLATIONS and PROCESS for RAID
			if     (self.Settings.Character.Screen.Raid == true and chatType == "RAID") then
				self.Hooks.Send(msg ,"RAID", language, channel);
			elseif (self.Settings.Character.Translations.Raid == true and chatType == "RAID") then
				self.Hooks.Send(self:ApplySpeech(msg, false), "RAID", nil, channel);
			elseif (self.Settings.Character.Translations.Raid == true and chatType ~= "RAID" and UnitInRaid("player")) then
				self.Hooks.Send(self:ApplySpeech(msg, false), "RAID", nil, channel);
			elseif (self.Settings.Character.Translations.Raid == false and chatType == "RAID") then
				self.Hooks.Send(languagename .. v , chatType, language, channel);
			end
			-----TRANSLATIONS and PROCESS for RAIDALERT
			if     (self.Settings.Character.Screen.RaidAlert == true and chatType == "RAID_WARNING") then
				self.Hooks.Send(msg ,"RAID_WARNING", language, channel);
			elseif (self.Settings.Character.Translations.RaidAlert == true and chatType == "RAID_WARNING") then
				self.Hooks.Send(self:ApplySpeech(msg, false), "RAID_WARNING", nil, channel);
			elseif (self.Settings.Character.Translations.RaidAlert == true and chatType ~= "RAID_WARNING" and UnitInRaid("player")) then
				self.Hooks.Send(self:ApplySpeech(msg, false), "RAID_WARNING", nil, channel);
			elseif (self.Settings.Character.Translations.RaidAlert == false and chatType == "RAID_WARNING") then
				self.Hooks.Send(languagename .. v , chatType, language, channel);
			end
			-----TRANSLATIONS and PROCESS for BATTLEGROUND
			if     (self.Settings.Character.Screen.Battleground == true and chatType == "BATTLEGROUND") then
				self.Hooks.Send(msg , "BATTLEGROUND", language, channel);
			elseif (self.Settings.Character.Translations.Battleground == true and chatType == "BATTLEGROUND") then
				self.Hooks.Send(self:ApplySpeech(msg, false), "BATTLEGROUND", nil, channel);
			elseif (self.Settings.Character.Translations.Battleground == true and chatType ~= "BATTLEGROUND") then
				self.Hooks.Send(self:ApplySpeech(msg, false), "BATTLEGROUND", nil, channel);
			elseif (self.Settings.Character.Translations.Battleground == false and chatType == "BATTLEGROUND") then
				self.Hooks.Send(languagename .. v , chatType, language, channel);
			end
		end;
	end;
	---------------------------------------------------------------------------------------
	HandleReceive = function(self, this, event)
		--FOR NOW DOING DIRECT REQUESTS FROM THE USER WHO SENDS THE 'LANGUAGE'	--
		local TP = "<Tongues>"
		local TPLen = string.len(TP)
		dontprint = 1;

		if	(event=="CHAT_MSG_SAY") 	or 
			(event=="CHAT_MSG_YELL") 	or 
			(event=="CHAT_MSG_GUILD") 	or 
			(event=="CHAT_MSG_PARTY") 	or 
			(event=="CHAT_MSG_RAID") 	or 
			(event=="CHAT_MSG_RAID_WARNING")or 
			(event=="CHAT_MSG_OFFICER") 	or
			(event=="CHAT_MSG_BATTLEGROUND")then

			arg1 = self:Substitute(arg1, self.Filter[self.Settings.Character.Filter]["filters"]);
			arg1 = self:ApplyEffect(arg1, self.Filter[self.Settings.Character.Filter]["affects"]);

			math.randomseed(math.random(0,2147483647)+(GetTime()*1000));
			if ((arg3 == "Common") and (UnitFactionGroup("player") == "Alliance") ) or 
			   ((arg3 == "Orcish") and (UnitFactionGroup("player") == "Horde"   ) ) then

					--- Check if a player knows a [<Language>] spoken in Blizzard Common/Orcish
					if string.match(arg1 , "^%[[%a%s'%-]+%][%a%A]+") then
						local language = string.gsub(arg1, "^%[([%a%s'%-]+)%]([%a%A]+)", "%1")
						language = self:GetRealLanguage(language)
						local fluency = self.Settings.Character.Fluency[language] or 0

						local prepstring = TP .. ":RT:fluency=" .. fluency .. ":channel=".. event ..":frame=" .. this:GetID() .. ":language=" .. language .. "" 
						prepstring = string.sub(prepstring, 1, TONGUES_MAX_MSG_LEN)

						--- Only request if the user knows the language
						if (math.random(1,100)<= fluency) then
							SendAddonMessage("Tongues", prepstring, "WHISPER", arg2 );
							if self.Settings.Character.LoreCompatibility == true then
								self.Hooks.Send("LORE::TR::" .. arg2, "CHANNEL", nil, GetChannelName("xtensionxtooltip2"))
							end;
							dontprint = 0;
						else
							self:LearnRequest(language,UnitFactionGroup("player"),UnitRace("player"),UnitClass("player"),this:GetID(),fluency,arg2)
						end;
					--- If player 'doesnt know' Common/Orcish, hash it here
					elseif self.Settings.Character.Fluency[arg3] == nil or self.Settings.Character.Fluency[arg3] < 100 then	
						arg3 = self:GetRealLanguage(arg3)
						local fluency = self.Settings.Character.Fluency[arg3] or 0
						if (math.random(1,100)<= fluency) then
						else
							self:LearnRequest(arg3,UnitFactionGroup("player"),UnitRace("player"),UnitClass("player"),this:GetID(), fluency, arg2)
							arg1 = self:ParseLink2(arg1,arg3);
							arg1 = "[" .. arg3 .. "] " .. arg1
						end;
					end;		
			else
				--- If player does know other Blizzard Languages (ie blood elf with Thalassian), but the character /shouldn't/ know it (for RP reasons,) hash it here 
				if self:ReturnSpecialLanguage() == arg3 then
					if self.Settings.Character.Fluency[arg3] == nil or self.Settings.Character.Fluency[arg3] < 100 then	
						arg3 = self:GetRealLanguage(arg3)
						local fluency = self.Settings.Character.Fluency[arg3] or 0
						if (math.random(1,100)<= fluency) then
						else
							self:LearnRequest(arg3,UnitFactionGroup("player"),UnitRace("player"),UnitClass("player"),this:GetID(), fluency, arg2)
							arg1 = self:ParseLink2(arg1,arg3);
						end;
					end;

				--- If player doen't know other Blizzard Languages (ie human with gnomish), but the character /should/ know if (for RP reasons), send request
				--- Not sure if Cross Faction can be done this way, but it will be disabled here if it can to meet EULA
				else
					arg3 = self:GetRealLanguage(arg3)
					if self:IsMyFactionLanguage(arg3) == true then
						local fluency = self.Settings.Character.Fluency[arg3] or 0
						local prepstring = TP .. ":RT:fluency=" .. fluency .. ":channel=".. event ..":frame=" .. this:GetID() .. ":language=" .. arg3 .. "" 
						prepstring = string.sub(prepstring, 1, TONGUES_MAX_MSG_LEN)

							if (math.random(1,100) <= fluency) then
								SendAddonMessage("Tongues", prepstring, "WHISPER", arg2 );
								if self.Settings.Character.LoreCompatibility == true then
									self.Hooks.Send("LORE::TR::" .. arg2, "CHANNEL", nil, GetChannelName("xtensionxtooltip2"))
								end;
							else
								self:LearnRequest(arg3,UnitFactionGroup("player"),UnitRace("player"),UnitClass("player"),this:GetID(), fluency, arg2)
							end;
					end;
					dontprint = 1;
				end;
			end;

		--------------------------------FOR LORE COMPATIBILITY----------------------------------------------------
		elseif (event=="CHAT_MSG_CHANNEL") and (arg9 == "xtensionxtooltip2") and this:GetID() == 1 then
			if ( arg1 == "LORE::ST::" .. UnitName("player") and arg2 == UnitName("player")) then
				self.Hooks.Send("<LoRe5> Self-test executed. Auto-translation works properly.", "WHISPER", nil, arg2 )
			elseif ( arg1 == "LORE::TR::" .. UnitName("player") and arg2 ~= UnitName("player")) then
				self.Hooks.Send("<LoRe5>" .. self.PreviousSentMsg, "WHISPER", GetDefaultLanguage(), arg2 )				
			elseif ( arg1 == "LORE::LR::" .. string.lower(UnitName("player")) and arg2 ~= UnitName("player")) then
				local str = "I understand";
				for k,v in pairs(self.Settings.Character.Fluency) do
					if v > 0 then
						str = str .. " " .. k
					end
				end
				self.Hooks.Send("<LoRe5> " .. str, "WHISPER", GetDefaultLanguage(), arg2 )
			elseif ( arg1 == "LORE::VER::" .. string.lower(UnitName("player")) and arg2 ~= UnitName("player")) then
				self.Hooks.Send("<LoRe5> My Tongues version is v" .. self.Version, "WHISPER", GetDefaultLanguage(), arg2 )
			end;
		elseif (event=="CHAT_MSG_WHISPER") and this:GetID() == 1 then
			if string.sub( arg1, 1, 7 ) =="<LoRe5>" then
				getglobal("ChatFrame" .. this:GetID() ):AddMessage( "(" .. arg2 .. ": " .. string.sub( arg1, 8, string.len(arg1) ) .. ")", 1.0, 1.0, 0.0 );
				dontprint = 0;
			end;
		elseif (event=="CHAT_MSG_WHISPER_INFORM") and this:GetID() == 1 then
			if string.sub( arg1, 1, 7 ) =="<LoRe5>" or string.sub( arg1, 1, 14) == "[Translation -" then
				dontprint = 0;
			end;
		end;
		--------------------------------END LORE COMPATIBILITY----------------------------------------------------
		if dontprint == 1 then
			self.Hooks.Receive(event)
		end;	

	end;
	---------------------------------------------------------------------------------------
	LearnRequest = function(self,language,faction,race,class, frame, fluency, toperson)
		if self.Settings.Character.LanguageLearning == true then
			SendAddonMessage("Tongues","<Tongues>:RL:language=" .. language .. ":faction=" .. faction .. ":race=".. race .. ":class=" .. class .. ":frame=" .. frame .. ":fluency=" .. fluency, "WHISPER", toperson)
		end;
		--DEFAULT_CHAT_FRAME:AddMessage(language .. " " .. faction ..  " " .. race .. " " .. class .. " " .. frame .. " " .. fluency)
	end;
	---------------------------------------------------------------------------------------
	ProcessMessage = function(self , msg)	
		msg = self:ApplySpeech(msg, true);
		return msg
	end;
	---------------------------------------------------------------------------------------
	ApplySpeech = function( self, msg, languageflag)
		-- For Filters
		local type = "Filter";
		local s = self.Settings.Character[type];
		if (self[type] ~= nil ) and (self[type][s] ~= nil ) then
			msg = self:Substitute(msg, self[type][s]["filters"]);
			msg = self:Substitute(msg, self[type][s]["affects"]);
		end;
		-- End Filters

		-- For Dialects
		type = "Dialect";
		s = self.Settings.Character[type];

		if (self[type] ~= nil ) and (self[type][s] ~= nil ) then
			-- Dialect Filters
			msg = self:Substitute(msg, self[type][s]["filters"]);
			-- End Dialect Filters
			msg = self:Substitute(msg, self[type][s]["substitute"]);

				-- Dialect Phonetics  (ones that adjust phonemes)
				msg = self:Substitute(msg,  self[type][s]["exceptions"]);
				msg = self:ApplyEffect(msg, self[type][s]["rules"]);
				msg = self:ApplyEffect(msg, self[type][s]["mutation"], true);
				msg = self:ApplyEffect(msg, self[type][s]["remap"], true);
				-- End Dialect Phonetics


			-- For Languages
			if languageflag == true then
				if self.Settings.Character.ShapeshiftLanguage == true and GetShapeshiftForm(true) ~= 0 and UnitClass("player") == "Druid" then
					msg = self:ApplyLanguage("Language",msg);
				elseif 	((self.Settings.Character.Language == "Common") and (self.Settings.Character.Faction == "Alliance") ) or
					((self.Settings.Character.Language == "Orcish") and (self.Settings.Character.Faction == "Horde") ) or 
					(self.Settings.Character.Language == self:ReturnSpecialLanguage() ) then
				else
					msg = self:ApplyLanguage("Language",msg);
				end;
			end;
			-- End Languages

			-- Dialect Affects
			msg = self:ApplyEffect(msg, self[type][s]["affects"]);
			-- End Dialect Affects
		end	
		-- End Dialects

		-- For Affects
		local type = "Affect";
		local s = self.Settings.Character[type];

		math.randomseed(math.random(0,2147483647)+(GetTime() * 1000));
		if (self[type] ~= nil ) and (self[type][s] ~= nil ) and (math.random(1,100) < self.Settings.Character.AffectFrequency) then
			msg = self:ApplyEffect(msg, self[type][s]["substitute"]);
		end;
		-- End Affects

		return msg
	end;
	---------------------------------------------------------------------------------------
	ApplyEffect = function (self , msg, t)
		if (t ~= nil) then
			local a = {};
			local k;
			local i;
			local ilevel,klevel;

			for ilevel, klevel in ipairs(t) do
				
				-- insert into indexed table
				for k,v in pairs(klevel) do 
					table.insert(a, k)
				end
					-- sort by key length
				for i=1,#a do
					for k,v in ipairs(a) do 
						if a[k+1] ~= nil then
							if string.len(a[k]) < string.len(a[k+1]) then
								a[k], a[k+1] = a[k+1], a[k] 
							end
						end
					end
				end
	
				-- perform substitutions
				for i,k in ipairs(a) do
					msg = string.gsub(msg, k, klevel[k]);
				end
			end;
		end
			
		return msg
	end;
	---------------------------------------------------------------------------------------
	ApplyLanguage = function (self, type, msg)
		local s = self.Settings.Character[type];

		if self.Settings.Character.ShapeshiftLanguage == true and GetShapeshiftForm(true) ~= 0 and UnitClass("player") == "Druid" then
			s = self:ReturnForm();
		end;
		
		msg = Tongues:TranslateWord(msg,s)

		return msg
	end;
	---------------------------------------------------------------------------------------
	Substitute = function(self, text, t, phone)
		--- Link parsing suppression still needs to be added.
		if (t ~= nil) then
			if (text ~= nil) then
				for ilevel, klevel in ipairs(t) do
					local a = {};
					local b = {};
					local k;
					local i;

					-- insert into indexed table
					for k,v in pairs(klevel) do 
						table.insert(a, k) 
					end
	
					-- sort by key length
					for i=1,#a do
						for k,v in ipairs(a) do 
							if a[k+1] ~= nil then
								if string.len(a[k]) < string.len(a[k+1]) then
									a[k], a[k+1] = a[k+1], a[k] 
								end
							end
						end
					end

					-- perform substitutions
					for i,k in ipairs(a) do 

						-----------------------------------------------------------------
						if phone ~= true then 
							local originaltext = text;
							
							for w in string.gmatch(string.lower(text), "%f[%a0-9'](" .. string.lower(k) .. ")%f[^%a0-9']") do
								local starter, stopper, texter = string.find(string.lower(text), "%f[%a0-9'](" .. string.lower(w) .. ")%f[^%a0-9']")
								if texter ~= nil then
									local texter = string.sub(text, starter,stopper)
									if texter ~= nil then
										text = string.gsub(text, "%f[%a0-9']" .. texter .. "%f[^%a0-9']", 
										function(a) 
											return self.casematch(a,w,klevel) 
										end);
									end;
								end;
							end;
						else
						-----------------------------------------------------------------
							text = string.gsub(string.lower(text), "%f[%a0-9']" .. k .. "%f[^%a0-9']", t[k])	
						-----------------------------------------------------------------
						end;
					end
				end;
			end;
		end;
		return text;
	end;
	------------------------------------------------------------------------------------------------------------------
	ReturnForm = function(self)
		if Tongues.Settings.Character.ShapeshiftLanguage == true and GetShapeshiftForm(true) ~=0 and UnitClass("player") == "Druid" then
			local icon, name, active, castable;
			for i=1, GetNumShapeshiftForms() do
				icon, name, active, castable = GetShapeshiftFormInfo(i);

				if active == 1 and UnitClass("player") == "Druid" then
					if (name == "Dire Cat Form" or name=="Cat Form") then
						s = "Cat";
					elseif name == "Aquatic Form" then
						s = "Seal";
					elseif (name == "Dire Bear Form" or name=="Bear Form") then
						s = "Bear";
					elseif name == "Travel Form" then
						s = "Cat";
					elseif name == "Moonkin Form" then
						s = "Moonkin";
					elseif name == "Flight Form" then
						s = "Bird";
					elseif name == "Tree of Life" then
						s = "Trentish";
					end;
				end;
			end;
		end;
		return s
	end;
	---------------------------------------------------------------------------------------
	TranslateWord = function(self,word,s)
		word = string.gsub( word, "[%a']+", 
			function(word)
				local newword = "";
				local newnewword = "";
				local ignorewordflag = false;
				local substituteflag = false;
				local realLanguage = s;
				
				if self.Language[s] ~= nil then
					if self.Language[s]["alias"] ~= nil then
						realLanguage = self.Language[s]["alias"];
					end;

					--- IGNORE KEYWORDS
					if self.Language[realLanguage]["ignore"] ~= nil then
						for i,v in ipairs(self.Language[realLanguage]["ignore"]) do
							if string.lower(v) == string.lower(word) and ignorewordflag == false then
								ignorewordflag = true;
								newnewword = v
							end;
						end;
					end;
	
					--- SUBSTITUTE THE SUBSTITUTE WORDS
					if self.Language[realLanguage]["substitute"] ~= nil and ignorewordflag == false then
						for k,v in pairs(self.Language[realLanguage]["substitute"]) do
							if string.lower(k) == string.lower(word) and substituteflag == false then
								substituteflag = true;
								newnewword = v
							end;
						end;
					end;
	
					--- HASH ANYTHING ELSE
					if ignorewordflag == false and substituteflag == false then
						-- HASH THE NEW WORD
						
						local i = string.len(word);
						local h = self.Hash(string.lower(word));
						if (i > #self.Language[realLanguage]) then 
							i = #self.Language[realLanguage];
						end;
						j = mod(h,#self.Language[realLanguage][i])+1;
						newword = self.Language[realLanguage][i][j];
						
						-- GET THE RIGHT CAPTIALS BACK
						for n=1,string.len(newword) do
							if string.match(string.sub(word,n,n),"%u") then
								newnewword = newnewword .. string.upper(string.sub(newword,n,n))
							else
								newnewword = newnewword .. string.sub(newword,n,n)
							end;
						end;
					end;
				else
					newnewword = word;
			 	end;
				return newnewword
			end
		);
		return word
	end;
	---------------------------------------------------------------------------------------
	ParseLink = function(self, msg, language)
		--msg = string.gsub(msg,"|","X")
		---- DO STUFF BEFORE LINKS (WHEN THEY ARE NOT LINKS)
		if string.find(msg,"(.-)(|c[0-9a-f]+|H[%a%A]-|h|r)") ~= nil then
			msg = string.gsub(msg,"(.-)(|c[0-9a-f]+|H[%a%A]-|h|r)", 
				function(a,link)
					a = self:ProcessMessage(a)
					return a .. link
				end
			);
		end;
		---- DO THE LAST PART OF THE MESSAGE IF NOT A LINK
		if string.find(msg,"(.*)(|c[0-9a-f]+|H[%a%A]-|h|r)(.-)$") ~= nil then
			msg = string.gsub(msg,"(.*)(|c[0-9a-f]+|H[%a%A]-|h|r)(.-)$", 
				function(a,link,c) 
					c = self:ProcessMessage(c)
					return a .. link .. c
				end
			);
		else
		---- IF NO LINK THEN DO ANYWAY
			msg = self:ProcessMessage(msg)
		end;

		return msg
	end;
	---------------------------------------------------------------------------------------
	ParseLink2 = function(self, msg, language)
		--msg = string.gsub(msg,"|","X")
		---- DO STUFF BEFORE LINKS (WHEN THEY ARE NOT LINKS)
		if string.find(msg,"(.-)(|c[0-9a-f]+|H[%a%A]-|h|r)") ~= nil then
			msg = string.gsub(msg,"(.-)(|c[0-9a-f]+|H[%a%A]-|h|r)", 
				function(a,link)
					a = self:TranslateWord(a, language)
					return a .. link
				end
			);
		end;
		---- DO THE LAST PART OF THE MESSAGE IF NOT A LINK
		if string.find(msg,"(.*)(|c[0-9a-f]+|H[%a%A]-|h|r)(.-)$") ~= nil then
			msg = string.gsub(msg,"(.*)(|c[0-9a-f]+|H[%a%A]-|h|r)(.-)$", 
				function(a,link,c) 
					c = self:TranslateWord(c, language)
					return a .. link .. c
				end
			);
		else
		---- IF NO LINK THEN DO ANYWAY
			msg =  self:TranslateWord(msg, language)
		end;

		return msg
	end;
	---------------------------------------------------------------------------------------
	UnderstandPartial = function(self, fluency, lang)
		math.randomseed(math.random(0,2147483647)+(GetTime() * 1000));

		msg = self.PreviousSentMsg	

		---- DO STUFF BEFORE LINKS (WHEN THEY ARE NOT LINKS)
		if string.find(msg,"(.-)(|c[0-9a-f]+|H[%a%A]-|h|r)") ~= nil then
			msg = string.gsub(msg,"(.-)(|c[0-9a-f]+|H[%a%A]-|h|r)", 
				function(a,link)

					if math.random(1,100) > fluency then 
						a = self:TranslateWord(a, lang)
					end
					return a .. link
				end
			);
		end;
		---- DO THE LAST PART OF THE MESSAGE IF NOT A LINK
		if string.find(msg,"(.*)(|c[0-9a-f]+|H[%a%A]-|h|r)(.-)$") ~= nil then
			msg = string.gsub(msg,"(.*)(|c[0-9a-f]+|H[%a%A]-|h|r)(.-)$", 
				function(a,link,c) 
					if math.random(1,100) > fluency then 
						c = self:TranslateWord(c, lang)
					end
					return a .. link .. c
				end
			);
		else
		---- IF NO LINK THEN DO ANYWAY
			if math.random(1,100) > fluency then
				if math.random(1,100) > fluency then 
					msg = self:TranslateWord(msg, lang)
				end
			end;
		end;

		return "[" .. lang .. "] " .. msg
	end;
	---------------------------------------------------------------------------------------
	SetLanguage = function(self, language)
		UIDropDownMenu_ClearAll(self.UI.MainMenu.Speak.LanguageDropDown.Frame);
		UIDropDownMenu_SetSelectedValue(self.UI.MainMenu.Speak.LanguageDropDown.Frame, language); 
		self.Settings.Character.Language = language;
		self.UI.MiniMenu.Frame:SetText("Tongues\10" .. Tongues.Settings.Character.Language);
	end;
	---------------------------------------------------------------------------------------
	CycleLanguage = function(self)
		local t = {};
		local i = 1;
		local matchnumber = 1;
		local k,v;
		for k,v in self.PairsByKeys(self.Settings.Character.Fluency) do
			if v > 0 and self.Language[k] ~= nil then
				table.insert(t,#t + 1,k)
				if self.Settings.Character.Language == k then
					matchnumber = #t
				end;
			end;
		end;
		local d = ""
		if UnitFactionGroup("player") == "Alliance" then
			d = "Common"
		elseif UnitFactionGroup("player") == "Horde" then
			d = "Orcish"
		end;

		self:SetLanguage((t[((matchnumber) % #t) + 1]) or d) 
	end;
	---------------------------------------------------------------------------------------
	IsMyFactionLanguage = function(self, language)
		if UnitFactionGroup("player") == "Alliance" then
			if language == "Common" or
			language == "Gnomish" or
			language == "Dwarvish" or
			language == "Darnassian" or
			language == "Draenei" then
				return true
			end;
		elseif UnitFactionGroup("player") == "Horde" then
			if language == "Orcish" or
			language == "Troll" or
			language == "Gutterspeak" or
			language == "Taurahe" or
			language == "Thalassian" then
				return true
			end;
		end;
		return false
	end;


	---------------------------------------------------------------------------------------

});
Tongues:Initialize();

--================================================================================================================
-----------------------------------------------------------HOOKS--------------------------------------------------
function SendChatMessage(  msg, chatType, language, channel)
	Tongues:HandleSend(msg, chatType, language, channel)
end

ChatFrame_OnEvent = function(event)
	if (	event == "CHAT_MSG_SAY" or 
		event == "CHAT_MSG_YELL" or
		event == "CHAT_MSG_PARTY" or
		event == "CHAT_MSG_GUILD" or
		event == "CHAT_MSG_WHISPER" or
		event == "CHAT_MSG_WHISPER_INFORM" or
		event == "CHAT_MSG_OFFICER" or
		event == "CHAT_MSG_RAID" or
		event == "CHAT_MSG_RAID_WARNING" or
		event == "CHAT_MSG_RAID_LEADER" or
		event == "CHAT_MSG_BATTLEGROUND" or
		event == "CHAT_MSG_BATTLEGROUND_LEADER" or
		event == "CHAT_MSG_CHANNEL" 
		)  then
			Tongues:HandleReceive(this,event);
	else
		Tongues.Hooks.Receive(event);
	end;
end;
--================================================================================================================


