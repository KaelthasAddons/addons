local L = AceLibrary("AceLocale-2.2"):new("ClassLoot")

L:RegisterTranslations("zhTW", function() return {
	-- Slash Commands
	["Check an item (Local)"] = "在本地檢查物品",
	["Check an item (Guild)"] = "在公會內檢查物品",
	["Check an item (Raid)"] = "在團隊內檢查物品",
	["Display ClassLoot for an item locally"] = "在自身聊天框中顯示ClassLoot物品資訊",
	["Display ClassLoot for an item in guild chat"] = "在公會頻道中顯示ClassLoot物品資訊",
	["Display ClassLoot for an item in raid chat"] = "在團隊頻道中顯示ClassLoot物品資訊",
	["<item link>"] = "<物品連結>",
	
	-- Info Messages
	["Version"] = "版本",
	["Last updated"] = "最後更新",
	
	-- Error Messages
	["could not be found"] = "未找到",
	["Not in a guild!"] = "你不在一個公會中",
	["Not in a raid!"] = "你不在一個團隊中",
	
	-- Output Messages
	["ClassLoot info for"] = "ClassLoot信息",
	["Dropped in"] = "掉落於",
	["by"] = ">>",
	
	-- Tooltip Stuff
	["Boss"] = "首領",
	["Instance"] = "副本",
	
	-- Interface Options
	["Enable ClassLoot Tooltips"] = "啟用ClassLoot提示資訊",
	["Display Boss Name"] = "顯示BOSS名字",
	["Display Instance Name"] = "顯示副本名字",
	
	-- Misc Translations
	["Trash Mobs"] = "雜兵掉落",
	--["World Bosses"] = true,
	--["Chest1"] = "Timed Chest 1",
	--["Chest2"] = "Timed Chest 2",
	--["Chest3"] = "Timed Chest 3",
	--["Chest4"] = "Timed Chest 4"
} end)
