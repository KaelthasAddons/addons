--[[ Set the module up ]]--
ClassLoot = AceLibrary("AceAddon-2.0"):new("AceConsole-2.0", "AceDB-2.0", "AceHook-2.1")

local L = AceLibrary("AceLocale-2.2"):new("ClassLoot")
local CD = ClassLoot_Data
local CC = ClassLoot_Constants
local ttLine = { 
	["GameTooltip"] = {},
	["ItemRefTooltip"] = {},
	["AtlasLootTooltip"] = {}
}

ClassLoot_Data = nil
ClassLoot_Constants = nil

--[[ Run when ClassLoot is initialized ]]--
function ClassLoot:OnInitialize()
	-- Register slash command
	local opts = {
		type='group',
		args = {
			check = {
				type = 'text',
				name = L["Check an item (Local)"],
				desc = L["Display ClassLoot for an item locally"],
				usage = L["<item link>"],
				get = false,
				set = "ShowItemStars",
				passValue = "LOCAL"
			},
			gcheck = {
				type = 'text',
				name = L["Check an item (Guild)"],
				desc = L["Display ClassLoot for an item in guild chat"],
				usage = L["<item link>"],
				get = false,
				set = "ShowItemStars",
				passValue = "GUILD"
			},
			rcheck = {
				type = 'text',
				name = L["Check an item (Raid)"],
				desc = L["Display ClassLoot for an item in raid chat"],
				usage = L["<item link>"],
				get = false,
				set = "ShowItemStars",
				passValue = "RAID"
			}
		}
	}
	ClassLoot:RegisterChatCommand(CC["Slash-Commands"], opts)
	
	-- Register Saved Variables
	ClassLoot:RegisterDB("ClassLootDB")
	ClassLoot:RegisterDefaults("profile", {
		showTooltip = true,
		showBoss = true,
		showInstance = true
	} )
end

--[[ Run when ClassLoot is enabled ]]--
function ClassLoot:OnEnable()
	-- Hook tooltips if needed
	if ClassLoot.db.profile.showTooltip then
		self:HookTooltips()
	end
	-- Build Interface Options window
	self:CreateInterfaceOptions()
end

--[[ Hook Tooltips ]]--
function ClassLoot:HookTooltips()
	self:HookScript(GameTooltip, "OnTooltipSetItem")
	self:HookScript(GameTooltip, "OnTooltipSetSpell")
	self:HookScript(ItemRefTooltip, "OnTooltipSetItem")
	if AtlasLootTooltip then
		self:HookScript(AtlasLootTooltip, "OnTooltipSetItem")
	end
end

--[[ Unhook Tooltips ]]--
function ClassLoot:UnhookTooltips()
	self:Unhook(GameTooltip, "OnTooltipSetItem")
	self:Unhook(GameTooltip, "OnTooltipSetSpell")
	self:Unhook(ItemRefTooltip, "OnTooltipSetItem")
	if AtlasLootTooltip then
		self:Unhook(AtlasLootTooltip, "OnTooltipSetItem")
	end
end

-- Get Item Info
--	link - The item link
function ClassLoot:GetItemInfoFromLink(link)
	if type(link) == "string" then
		return CD[tonumber(link:match('item:(%d+)'))]
	end
end

-- Make Star Table
--  itemInfo - Table of class/stars
function ClassLoot:MakeStarTable(itemInfo)
	-- Build starTable, index = number of stars, value = string of classes
	local starTable = { [3] = nil; [4] = nil; [5] = nil; }
	for class, stars in pairs(itemInfo) do
		-- We are skipping all 0, 1 and 2 star items as theres no point showing them
		-- After all, they shouldn't have made it into the Data file anyway!
		if stars > 2 then
			if not starTable[stars] then
				starTable[stars] = CC[class]
			else
				starTable[stars] = starTable[stars]..', '..CC[class]
			end
		end
	end
	return starTable
end

-- Make Stars
--	count - Number of stars to return
function ClassLoot:MakeStars(count)
	local stars = ''
	for i = 1, 6, 1 do
		if i <= count then
			stars = stars..ICON_LIST[1]..'0|t'
		else
			stars = stars..'|T:0|t'
		end
	end
	return stars
end

-- Show Item Stars
--	target   - The chat target (LOCAL, RAID or GUILD)
--	itemLink - The link for the item
function ClassLoot:ShowItemStars(target, itemLink)
	-- Validate Target
	if target == "RAID" and GetNumRaidMembers() == 0 then
		self:Print(L["Not in a raid!"])
		return
	elseif target == "GUILD" and not IsInGuild() then
		self:Print(L["Not in a guild!"])
		return
	end
	
	-- Get the info table
	local itemInfo = self:GetItemInfoFromLink(itemLink)
	if not itemInfo then
		-- Not in ClassLoot_Data
		self:Print(itemLink..' '..L["could not be found"])
		return
	end
	
	local res = AceLibrary("LibPeriodicTable-3.1"):ItemSearch(itemLink)
	local BB = LibStub("LibBabble-Boss-3.0"):GetUnstrictLookupTable()
	local BZ = LibStub("LibBabble-Zone-3.0"):GetUnstrictLookupTable()
	local output = {}
	
	-- Header
	table.insert(output, L["ClassLoot info for"]..' '..itemLink)
	
	-- Who drops it where
	if res then
		-- k = index, v = table name [InstanceLoot.InstanceName.BossName]
		for _, v in pairs(res) do
			local set, instance, boss = strsplit(".", v)
			if set == "InstanceLoot" then
				-- Special cases where the "boss" is not the Boss!
				boss = CC[boss] or boss
				-- Localise "boss" and "instance" first, as it could be in 2 different places
				boss = BB[boss] or L[boss]
				instance = BZ[instance] or L[instance]
				table.insert(output, L["Dropped in"]..' '..instance..' '..L["by"]..' '..boss)
			end
		end
	end
	
	-- Build the star table
	local starTable = self:MakeStarTable(itemInfo)
	
	-- Go backwards through the table from 5 stars down to 3 and build the output
	for i = 5, 3, -1 do
		if starTable[i] then
			table.insert(output, self:MakeStars(i)..starTable[i])
		end
	end
	
	-- Ouptput the Item Info!
	for _, v in pairs(output) do
		if target == "LOCAL" then
			self:Print(v)
		else
			SendChatMessage(v, target)
		end
	end
end

--[[ Tooltip Handler to add ClassLoot info to items ]]--
function ClassLoot:OnTooltipSetItem(tooltip, ...)
	local ttName = tooltip:GetName()
	
	-- Reset the 'right text' anchor points on this tooltip
	for n, _ in pairs(ttLine[ttName]) do
		getglobal(ttName.."TextRight"..n):ClearAllPoints()
		ttLine[ttName][n] = nil
	end
	
	local item = select(2, tooltip:GetItem())
	local itemInfo = ClassLoot:GetItemInfoFromLink(item)
	if itemInfo and self.db.profile.showTooltip then
		local firstLine = tooltip:NumLines() + 2
		-- Header
		tooltip:AddLine("|cffff0000ClassLoot:|r")
		
		-- Build the star table
		local starTable = self:MakeStarTable(itemInfo)
		
		-- Go backwards through the table from 5 stars down to 3 and build the output
		for i = 5, 3, -1 do
			if starTable[i] then
				tooltip:AddDoubleLine(ClassLoot:MakeStars(i), "|cff0099ff"..starTable[i].."|r")
			end
		end
		
		if (ClassLoot.db.profile.showBoss or ClassLoot.db.profile.showInstance) and tooltip ~= AtlasLootTooltip then
			local res = AceLibrary("LibPeriodicTable-3.1"):ItemSearch(item)
			local BB = LibStub("LibBabble-Boss-3.0"):GetUnstrictLookupTable()
			local BZ = LibStub("LibBabble-Zone-3.0"):GetUnstrictLookupTable()
			local instances, bosses = {}, {}
			
			-- Who drops it where
			if res then
				-- k = index, v = table name [InstanceLoot.InstanceName.BossName]
				for _, v in pairs(res) do
					local set, instance, boss = strsplit(".", v)
					if set == "InstanceLoot" then
						-- Special cases where the "boss" is not the Boss!
						boss = CC[boss] or boss
						-- Localize and insert into output tables
						table.insert(bosses, BB[boss] or L[boss])
						instances[BZ[instance] or L[instance]] = true
					end
				end
				-- Insert duplicates of all instance keys, so we can table.concat()
				for k, _ in pairs(instances) do
					table.insert(instances, k)
				end
			end
			-- Finally, append to the tooltip
			if ClassLoot.db.profile.showBoss and bosses then
				tooltip:AddDoubleLine("|cfff0e68c"..L["Boss"].."|r", "|cfff0e68c"..table.concat(bosses, ", ").."|r")
			end
			if ClassLoot.db.profile.showInstance and instances then
				tooltip:AddDoubleLine("|cfff0e68c"..L["Instance"].."|r", "|cfff0e68c"..table.concat(instances, ", ").."|r")
			end
		end
		
		local maxLeft = 0
		local lastLine = tooltip:NumLines()
		
		-- Check our new lines for the longest 'left text' (To cope with long localised strings)
		for i = firstLine, lastLine, 1 do
			maxLeft = max(getglobal(ttName.."TextLeft"..i):GetWidth(), maxLeft)
		end
		
		-- Now adjust our 'right text' to sit left-aligned, making a note of what we've changed
		for i = firstLine, lastLine, 1 do
			ttLine[ttName][i] = true
			getglobal(ttName.."TextRight"..i):SetPoint("LEFT", getglobal(ttName.."TextLeft"..i), "LEFT", maxLeft+10, 0)
		end
	end
	return self.hooks[tooltip].OnTooltipSetItem(tooltip, ...)
end

--[[ Tooltip Handler to fix 'right text' anchor points on spell tooltips ]]--
function ClassLoot:OnTooltipSetSpell(tooltip, ...)
	local ttName = tooltip:GetName()
	for n, _ in pairs(ttLine[ttName]) do
		getglobal(ttName.."TextRight"..n):ClearAllPoints()
		ttLine[ttName][n] = nil
	end
end

--[[ Interface Options Window ]]--
function ClassLoot:CreateInterfaceOptions()
	local cfgFrame = CreateFrame("FRAME", nil, UIParent)
	cfgFrame.name = "ClassLoot"
	
	local cfgFrameHeader = cfgFrame:CreateFontString("OVERLAY", nil, "GameFontNormalLarge")
	cfgFrameHeader:SetPoint("TOPLEFT", 15, -15)
	cfgFrameHeader:SetText("ClassLoot")
	
	local cfgShowTooltip = CreateFrame("CHECKBUTTON", "ClassLoot_cfgShowTooltip", cfgFrame, "InterfaceOptionsCheckButtonTemplate")
	ClassLoot_cfgShowTooltip:SetPoint("TOPLEFT", 20, -40)
	ClassLoot_cfgShowTooltipText:SetText(L["Enable ClassLoot Tooltips"])
	ClassLoot_cfgShowTooltip:SetChecked(ClassLoot.db.profile.showTooltip)
	ClassLoot_cfgShowTooltip:SetScript("OnClick", function(self)
		ClassLoot.db.profile.showTooltip = not ClassLoot.db.profile.showTooltip
		-- Toggle the sub-options
		if ClassLoot.db.profile.showTooltip then
			-- Enable Sub-Options
			ClassLoot_cfgShowBossTooltip:Enable()
			ClassLoot_cfgShowInstanceTooltip:Enable()
			-- Hook the tooltips
			ClassLoot:HookTooltips()
		else
			-- Disable Sub-Options
			ClassLoot_cfgShowBossTooltip:Disable()
			ClassLoot_cfgShowInstanceTooltip:Disable()
			-- Unhook the tooltips
			ClassLoot:UnhookTooltips()
		end
	end)
	
	local cfgShowBossTooltip = CreateFrame("CHECKBUTTON", "ClassLoot_cfgShowBossTooltip", cfgFrame, "InterfaceOptionsCheckButtonTemplate")
	ClassLoot_cfgShowBossTooltip:SetPoint("TOPLEFT", 40, -64)
	ClassLoot_cfgShowBossTooltipText:SetText(L["Display Boss Name"])
	ClassLoot_cfgShowBossTooltip:SetChecked(ClassLoot.db.profile.showBoss)
	ClassLoot_cfgShowBossTooltip:SetScript("OnClick", function(self)
		ClassLoot.db.profile.showBoss = not ClassLoot.db.profile.showBoss
	end)
	
	local cfgShowInstanceTooltip = CreateFrame("CHECKBUTTON", "ClassLoot_cfgShowInstanceTooltip", cfgFrame, "InterfaceOptionsCheckButtonTemplate")
	ClassLoot_cfgShowInstanceTooltip:SetPoint("TOPLEFT", 40, -88)
	ClassLoot_cfgShowInstanceTooltipText:SetText(L["Display Instance Name"])
	ClassLoot_cfgShowInstanceTooltip:SetChecked(ClassLoot.db.profile.showInstance)
	ClassLoot_cfgShowInstanceTooltip:SetScript("OnClick", function(self)
		ClassLoot.db.profile.showInstance = not ClassLoot.db.profile.showInstance
	end)
	
	-- Check for disabled tooltips on startup
	if not ClassLoot.db.profile.showTooltip then
		ClassLoot_cfgShowBossTooltip:Disable()
		ClassLoot_cfgShowInstanceTooltip:Disable()
	end
	
	InterfaceOptions_AddCategory(cfgFrame)
end
