local L = AceLibrary("AceLocale-2.2"):new("ClassLoot")

L:RegisterTranslations("deDE", function() return {
	-- Slash Commands
	["Check an item (Local)"] = "Einen Gegenstand pr\195\188fen (Lokal)",
	["Check an item (Guild)"] = "Einen Gegenstand pr\195\188fen (Gilde)",
	["Check an item (Raid)"] = "Einen Gegenstand pr\195\188fen (Schlachtzug)",
	["Display ClassLoot for an item locally"] = "ClassLoot f\195\188r einen Gegenstand lokal anzeigen",
	["Display ClassLoot for an item in guild chat"] = "ClassLoot f\195\188r einen Gegenstand im Gildenchat anzeigen",
	["Display ClassLoot for an item in raid chat"] = "ClassLoot f\195\188r einen Gegenstand Schlachtzugchat anzeigen",
	["<item link>"] = "<item link>",
	
	-- Info Messages
	["Version"] = "Version",
	["Last updated"] = "Zuletzt aktualisiert",
	
	-- Error Messages
	["could not be found"] = "konnte nicht gefunden werden",
	["Not in a guild!"] = "In keiner Gilde!",
	["Not in a raid!"] = "In keinem Schlachtzug!",
	
	-- Output Messages
	["ClassLoot info for"] = "ClassLoot-Info f\195\188r",
	["Dropped in"] = "Dropped in",
	["by"] = "von",
	
	-- Tooltip Stuff
	--["Boss"] = true,
	--["Instance"] = true,
	
	-- Interface Options
	--["Enable ClassLoot Tooltips"] = true,
	--["Display Boss Name"] = true,
	--["Display Instance Name"] = true,
	
	-- Misc Translations
	--["Trash Mobs"] = true,
	--["World Bosses"] = true,
	--["Chest1"] = "Timed Chest 1",
	--["Chest2"] = "Timed Chest 2",
	--["Chest3"] = "Timed Chest 3",
	--["Chest4"] = "Timed Chest 4"
} end)
