local L = AceLibrary("AceLocale-2.2"):new("ClassLoot")

L:RegisterTranslations("zhCN", function() return {
	-- Slash Commands
	["Check an item (Local)"] = "在本地检查物品",
	["Check an item (Guild)"] = "在公会内检查物品",
	["Check an item (Raid)"] = "在团队内检查物品",
	["Display ClassLoot for an item locally"] = "在自身聊天框中显示ClassLoot物品信息",
	["Display ClassLoot for an item in guild chat"] = "在公会频道中显示ClassLoot物品信息",
	["Display ClassLoot for an item in raid chat"] = "在团队频道中显示ClassLoot物品信息",
	["<item link>"] = "<物品链接>",
	
	-- Info Messages
	["Version"] = "版本",
	["Last updated"] = "最后更新",
	
	-- Error Messages
	["could not be found"] = "未找到",
	["Not in a guild!"] = "你不在一个公会中",
	["Not in a raid!"] = "你不在一个团队中",
	
	-- Output Messages
	["ClassLoot info for"] = "ClassLoot信息",
	["Dropped in"] = "掉落于",
	["by"] = ">>",
	
	-- Tooltip Stuff
	["Boss"] = "首领",
	["Instance"] = "副本",
	
	-- Interface Options
	["Enable ClassLoot Tooltips"] = "启用ClassLoot提示信息",
	["Display Boss Name"] = "显示BOSS名字",
	["Display Instance Name"] = "显示副本名字",
	
	-- Misc Translations
	["Trash Mobs"] = "小怪掉落",
	--["World Bosses"] = true,
	--["Chest1"] = "Timed Chest 1",
	--["Chest2"] = "Timed Chest 2",
	--["Chest3"] = "Timed Chest 3",
	--["Chest4"] = "Timed Chest 4"
} end)
