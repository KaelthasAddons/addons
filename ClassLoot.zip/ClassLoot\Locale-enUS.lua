local L = AceLibrary("AceLocale-2.2"):new("ClassLoot")

L:RegisterTranslations("enUS", function() return {
	-- Slash Commands
	["Check an item (Local)"] = true,
	["Check an item (Guild)"] = true,
	["Check an item (Raid)"] = true,
	["Display ClassLoot for an item locally"] = true,
	["Display ClassLoot for an item in guild chat"] = true,
	["Display ClassLoot for an item in raid chat"] = true,
	["<item link>"] = true,
	
	-- Info Messages
	["Version"] = true,
	["Last updated"] = true,
	
	-- Error Messages
	["could not be found"] = true,
	["Not in a guild!"] = true,
	["Not in a raid!"] = true,
	
	-- Output Messages
	["ClassLoot info for"] = true,
	["Dropped in"] = true,
	["by"] = true,
	
	-- Tooltip Stuff
	["Boss"] = true,
	["Instance"] = true,
	
	-- Interface Options
	["Enable ClassLoot Tooltips"] = true,
	["Display Boss Name"] = true,
	["Display Instance Name"] = true,
	
	-- Misc Translations
	["Trash Mobs"] = true,
	["World Bosses"] = true,
	["Chest1"] = "Timed Chest 1",
	["Chest2"] = "Timed Chest 2",
	["Chest3"] = "Timed Chest 3",
	["Chest4"] = "Timed Chest 4"
} end)
