enhbl_version = "1.5.1"
enhbl_combatstart = 0
enhbl_defaultshoutmessage = "Storm, Earth and Fire, heed my call!";

function EnhBloodlust_OnLoad()
	this:RegisterEvent("VARIABLES_LOADED");
	this:RegisterEvent("COMBAT_LOG_EVENT");
	this:RegisterEvent("PLAYER_REGEN_ENABLED");
	this:RegisterEvent("PLAYER_ENTERING_WORLD");
end

function EnhBloodlust_OnEvent()
	if (event == "VARIABLES_LOADED") then 
		EnhBloodlust_initialize();
	end
	if (event == "COMBAT_LOG_EVENT") and (arg2 == "SPELL_AURA_APPLIED") and (arg7 == enhbl_playername) and (arg10 == enhbl_name) then
		EnhBloodlust_BLOODLUST();
	end
	if (event == "COMBAT_LOG_EVENT") and (arg2 == "SPELL_AURA_REMOVED") and (arg7 == enhbl_playername) and (arg10 == enhbl_name) and (enhbl_limit == 1) then
		StopMusic();
	end
	if (event == "COMBAT_LOG_EVENT") and (arg2 == "SPELL_CAST_SUCCESS") and (arg4 == enhbl_playername) and (arg10 == enhbl_name) and (enhbl_shout == 1) then
		SendChatMessage(enhbl_shoutmessage, enhbl_shoutchannel);
	end
	if (event == "PLAYER_REGEN_ENABLED") and (enhbl_combatstart == 1) and (enhbl_combat == 1) then
		StopMusic();
		enhbl_combatstart = 0
	end
	if (event == "PLAYER_ENTERING_WORLD") then
		if UnitFactionGroup("player") == "Horde" then
			enhbl_name = "Bloodlust";
		end
		if UnitFactionGroup("player") == "Alliance" then
			enhbl_name = "Heroism";
		end
		enhbl_playername = UnitName("player")	
	end
end

function EnhBloodlust_initialize()	
	SlashCmdList["ENHBL"] = EnhBloodlust_command;
	SLASH_ENHBL1 = "/enhbl";
	SLASH_ENHBL2 = "/enhancedbloodlust";
	SlashCmdList["ENHBLSHOUT"] = EnhBloodlust_shoutcommand;
	SLASH_ENHBLSHOUT1 = "/enhblshout";
	SLASH_ENHBLSHOUT2 = "/enhancedbloodlustshout";
	SlashCmdList["ENHBLCHANNEL"] = EnhBloodlust_channelcommand;
	SLASH_ENHBLCHANNEL1 = "/enhblchannel";
	SLASH_ENHBLCHANNEL2 = "/enhancedbloodlustchannel";
	if (not enhbl_shout) then
		enhbl_shout = 0
	end
	if (not enhbl_shoutchannel) then
		enhbl_shoutchannel = YELL
	end
	if (not enhbl_music) then
		enhbl_music = 1
	end
	if (not enhbl_limit) then
		enhbl_limit = 1
	end
	if (not enhbl_combat) then
		enhbl_combat = 1
	end
	if (not enhbl_shoutmessage) then
		enhbl_shoutmessage = "Storm, Earth and Fire, heed my call!";
	end
	if (not enhbl_sct) then
		enhbl_sct = 1
	end
	if (not enhbl_fct) then
		enhbl_fct = 1
	end
	if (not enhbl_short) then
		enhbl_short = 0
	end
end

function EnhBloodlust_BLOODLUST()
	if (enhbl_music == 1) then
		if (enhbl_short == 1) then
			PlaySoundFile("Interface\\AddOns\\EnhBloodlust\\bloodlust.mp3")
		else
			PlayMusic("Sound\\Music\\ZoneMusic\\DMF_L70ETC01.mp3")
		end
	end
	enhbl_combatstart = 1
	if (SCT_Display_Message or (SCT and SCT.DisplayMessage)) and (enhbl_sct == 1) then
		SCT_MSG_FRAME:AddMessage(enhbl_name .. "!", 256, 0, 0, 1 )
	end
	if (CombatText_AddMessage) and (enhbl_fct == 1) then
		CombatText_AddMessage(enhbl_name .. "!", CombatText_StandardScroll, 256, 0, 0, "crit", nil);
	end
end

function EnhBloodlust_commandlist()
	DEFAULT_CHAT_FRAME:AddMessage("|cffff0000Enhanced Bloodlust " .. enhbl_version .. " by Gamaron @ EU-Bloodscalp|r");
	DEFAULT_CHAT_FRAME:AddMessage("|cff00ff00Use |r|cffffffff/enhbl <command>|r|cff00ff00 or |cffffffff/enhancedbloodlust <command>|r|cff00ff00 to preform the following commands:|r");
	DEFAULT_CHAT_FRAME:AddMessage("|cffffffffshout|r|cff00ff00: Enables or disables shout when you cast " .. enhbl_name .. ".|r");
	DEFAULT_CHAT_FRAME:AddMessage("|cffffffffmusic|r|cff00ff00: Enables or disables music when you gain " .. enhbl_name .. ".|r");
	DEFAULT_CHAT_FRAME:AddMessage("|cfffffffflimit|r|cff00ff00: Toggles stopping the music when Bloodlust fades on or off.|r");
	DEFAULT_CHAT_FRAME:AddMessage("|cfffffffflenght|r|cff00ff00: Toggles between the long and the short version.|r");
	DEFAULT_CHAT_FRAME:AddMessage("|cffffffffcombat|r|cff00ff00: Enables or disables automatically stopping the music when you leave combat if the music was started automatically by you gaining " .. enhbl_name .. ".|r");
	if (SCT_Display_Message or (SCT and SCT.DisplayMessage)) then
		DEFAULT_CHAT_FRAME:AddMessage("|cffffffffsct|r|cff00ff00: Enables or disables Scrolling Combat Text " .. enhbl_name .. " message.|r");
	end
	if (CombatText_AddMessage) then
		DEFAULT_CHAT_FRAME:AddMessage("|cfffffffffct|r|cff00ff00: Enables or disables Floating Combat Text " .. enhbl_name .. " message.|r");
	end
	DEFAULT_CHAT_FRAME:AddMessage("|cffffffffplay|r|cff00ff00: Plays the music.|r");
	DEFAULT_CHAT_FRAME:AddMessage("|cffffffffstop|r|cff00ff00: Stops the music.|r");
	DEFAULT_CHAT_FRAME:AddMessage("|cfffffffftest|r|cff00ff00: Simulates you casting " .. enhbl_name .. ".|r");
	DEFAULT_CHAT_FRAME:AddMessage("|cff00ff00Use |r|cffffffff/enhblshout <message>|r|cff00ff00 or |cffffffff/enhancedbloodlustshout <message>|r|cff00ff00 to change the shout message, or use |r|cffffffff/enhblshout reset|r|cff00ff00 or |cffffffff/enhancedbloodlustshout reset|r|cff00ff00 to reset the message to the default one.|r");
	DEFAULT_CHAT_FRAME:AddMessage("|cff00ff00Use |r|cffffffff/enhblchannel <channel>|r|cff00ff00 or |cffffffff/enhancedbloodlustchannel <channel>|r|cff00ff00 to change the shout channel. Valid options are |r|cffffffffSAY|r|cff00ff00, |r|cffffffffEMOTE|r|cff00ff00, |r|cffffffffPARTY|r|cff00ff00, |r|cffffffffYELL|r|cff00ff00 and |r|cffffffffRAID|r");	
	DEFAULT_CHAT_FRAME:AddMessage("|cff00ff00Current shout is |r|cffffffff" .. enhbl_shoutmessage .. "|r|cff00ff00, and it sends to |r|cffffffff" .. enhbl_shoutchannel .. "|r");
end

function EnhBloodlust_command(enhbl_arg)
	if enhbl_arg == "" then
		EnhBloodlust_commandlist()
	end
	if enhbl_arg == "shout" then
		if enhbl_shout == 1 then
			enhbl_shout = 0
			DEFAULT_CHAT_FRAME:AddMessage("|cff00ff00Shout disabled.|r");
		else
			enhbl_shout = 1
			DEFAULT_CHAT_FRAME:AddMessage("|cff00ff00Shout enabled.|r");
		end
	end
	if enhbl_arg == "music" then
		if enhbl_music == 1 then
			enhbl_music = 0
			DEFAULT_CHAT_FRAME:AddMessage("|cff00ff00Music disabled.|r");
		else
			enhbl_music = 1
			DEFAULT_CHAT_FRAME:AddMessage("|cff00ff00Music enabled.|r");
		end
	end
	if enhbl_arg == "limit" then
		if enhbl_limit == 1 then
			enhbl_limit = 0
			DEFAULT_CHAT_FRAME:AddMessage("|cff00ff00Time limit disabled.|r");
		else
			enhbl_limit = 1
			DEFAULT_CHAT_FRAME:AddMessage("|cff00ff00Time limit enabled.|r");
		end
	end
	if enhbl_arg == "lenght" then
		if enhbl_short == 1 then
			enhbl_short = 0
			DEFAULT_CHAT_FRAME:AddMessage("|cff00ff00Long version selected.|r");
		else
			enhbl_short = 1
			DEFAULT_CHAT_FRAME:AddMessage("|cff00ff00Short version selected.|r");
		end
	end
	if enhbl_arg == "combat" then
		if enhbl_combat == 1 then
			enhbl_combat = 0
			DEFAULT_CHAT_FRAME:AddMessage("|cff00ff00Automatic stop disabled.|r");
		else
			enhbl_combat = 1
			DEFAULT_CHAT_FRAME:AddMessage("|cff00ff00Automatic stop enabled.|r");
		end
	end
	if enhbl_arg == "play" then
		PlayMusic("Sound\\Music\\ZoneMusic\\DMF_L70ETC01.mp3")
	end
	if enhbl_arg == "stop" then
		StopMusic();
	end
	if enhbl_arg == "sct" then
		if enhbl_sct == 1 then
			enhbl_sct = 0
			DEFAULT_CHAT_FRAME:AddMessage("|cff00ff00SCT message disabled.|r");
		else
			enhbl_sct = 1
			DEFAULT_CHAT_FRAME:AddMessage("|cff00ff00SCT message enabled.|r");
		end
	end
	if enhbl_arg == "fct" then
		if enhbl_fct == 1 then
			enhbl_fct = 0
			DEFAULT_CHAT_FRAME:AddMessage("|cff00ff00FCT message disabled.|r");
		else
			enhbl_fct = 1
			DEFAULT_CHAT_FRAME:AddMessage("|cff00ff00FCT message enabled.|r");
		end
	end
	if enhbl_arg == "test" then
		if (enhbl_shout == 1) then
			SendChatMessage(enhbl_shoutmessage, enhbl_shoutchannel);
		end
		EnhBloodlust_BLOODLUST()
	end
end

function EnhBloodlust_shoutcommand(enhbl_shoutarg)
	if enhbl_shoutarg == "" then
		EnhBloodlust_commandlist()
	end
	if enhbl_shoutarg == "reset" then
		enhbl_shoutmessage = enhbl_defaultshoutmessage
		DEFAULT_CHAT_FRAME:AddMessage("|cff00ff00Message reset.|r");
	end
	if (enhbl_shoutarg ~= "reset") and (enhbl_shoutarg ~= "") then
		enhbl_shoutmessage = enhbl_shoutarg
		DEFAULT_CHAT_FRAME:AddMessage("|cff00ff00Message changed to |r|cffffffff" .. enhbl_shoutmessage .. "|r");
	end
end

function EnhBloodlust_channelcommand(enhbl_chanarg)
	if enhbl_chanarg == "" then
		EnhBloodlust_commandlist()
	end
	if enhbl_chanarg ~= "" then
		if enhbl_chanarg == (("SAY" or  "EMOTE" or "PARTY" or "YELL" or "RAID") or ("say" or  "emote" or "party" or "yell" or "raid") or ("Say" or  "Emote" or "Party" or "Yell" or "Raid")) then
			enhbl_shoutchannel = enhbl_chanarg
			DEFAULT_CHAT_FRAME:AddMessage("|cff00ff00Channel changed to |r|cffffffff" .. enhbl_chanarg .. "|r");
		else
			DEFAULT_CHAT_FRAME:AddMessage("|cff00ff00Invalid channel. Valid channels are |r|cffffffffSAY|r|cff00ff00, |r|cffffffffEMOTE|r|cff00ff00, |r|cffffffffPARTY|r|cff00ff00, |r|cffffffffYELL|r|cff00ff00 and |r|cffffffffRAID|r");
		end
	end
end 