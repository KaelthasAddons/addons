﻿local L = LibStub("AceLocale-3.0"):NewLocale("VisualHeal", "frFR");

if not L then return end

-- Menu name --
L["Dump Guild Versions"] = "Versions de la guilde";
L["Dump Group Versions"] = "Versions du groupe/raid";
L["Config"] = "Config";
L["Show HealBar"] = "Afficher la HealBar";
L["Show PlayerBar"] = "Afficher la PlayerBar";
L["Sticky HealBar"] = "HealBar collante";
L["Scale of the HealBar"] = "Echelle HealBar";
L["Scale of the PlayerBar"] = "Echelle PlayerBar";
L["Reset Bars"] = "Réinit. barres";
L["Show Bars"] = "Afficher barres";

-- Menu description --
L["Print the versions of LibHealComm-3.0 used by guild members"] = "Affiche les versions de LibHealComm-3.0 utilisées par les membres de la guilde";
L["Print the versions of LibHealComm-3.0 used by group members"] = "Affiche les versions de LibHealComm-3.0 utilisées par les membres du groupe/raid";
L["Configuration"] = "Configuration";
L["Toggles display of the HealBar when you are healing"] = "Affiche/Masque la HealBar lorsque vous soignez";
L["Toggles display of the PlayerBar when heals are incoming to you"] = "Affiche/Masque la PlayerBar lorsque des soins vous sont destinés";
L["If enabled the HealBar will stay on screen when your heal completes"] = "Si activé, la HealBar restera à l'écran à la fin de votre soin";
L["Set the scale of the HealBar"] = "Définit l'échelle de la HealBar";
L["Set the scale of the PlayerBar"] = "Définit l'échelle de la PlayerBar";
L["Reset the HealBar and PlayerBar to default positions and scales"] = "Réinitialise la HealBar et la PlayerBar aux positions et échelles par défaut";
L["Show the HealBar and PlayerBar to allow moving them around"] = "Affiche la HealBar et la PlayerBar afin de les déplacer";

-- Interface --
L["HealBar: Shows your healing to others"] = "HealBar : Affiche vos soins sur les autres";
L["PlayerBar: Shows incoming heals to you"] = "PlayerBar : Affiche les soins vous étant destinés";
L["|cFFCCCCCCLeft-click to drag."] = "Clic-gauche pour déplacer";
L["Shift-left-click to re-attach to Casting Bar."] = "Shift-Clic-gauche pour réattacher à la barre d'incantation";
L["Right-click to hide."] = "Clic-droit pour masquer";
