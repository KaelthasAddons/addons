﻿local L = LibStub("AceLocale-3.0"):NewLocale("HandyNotes_Vendors", "koKR")
if not L then return end

L["Stable Master"] = true
L["Icon Scale"] = "아이콘 크기"
L["The scale of the icons"] = "아이콘의 크기를 변경합니다."
L["Icon Alpha"] = "아이콘 투명도"
L["The alpha transparency of the icons"] = "아이콘 투명도를 변경합니다."
L["Create waypoint"] = "웨이포인트 추가"
L["Close"] = "닫기"

L["These settings control the look and feel of the Vendors icons."] = "이 설정은 상인 아이콘에만 적용됩니다."
L["Vendor"] = "상인"
L["Delete vendor"] = "상인 삭제"
L["HandyNotes - Vendors"] = "HandyNotes - 상인"
