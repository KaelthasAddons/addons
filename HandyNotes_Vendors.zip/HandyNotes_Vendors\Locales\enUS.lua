﻿local L = LibStub("AceLocale-3.0"):NewLocale("HandyNotes_Vendors", "enUS", true)

L["Stable Master"] = true
L["Icon Scale"] = true
L["The scale of the icons"] = true
L["Icon Alpha"] = true
L["The alpha transparency of the icons"] = true
L["Create waypoint"] = true
L["Close"] = true

L["These settings control the look and feel of the Vendors icons."] = true
L["Vendor"] = true
L["Delete vendor"] = true
L["HandyNotes - Vendors"] = true
