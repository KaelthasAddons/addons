if select(2, UnitClass('player')) ~= "HUNTER" then
	return
end
local L = LibStub("AceLocale-3.0"):GetLocale("FeedMachine")

function FeedMachine:FMUI_CreateOptions(parent, width, height)
	local frame = CreateFrame("Frame", nil, parent)
	frame:SetPoint("TOPLEFT")
	frame:SetWidth(width)
	frame:SetHeight(height)
--[[
--	TOGGLE FEED PET BUTTON
 	local checkbutton1 = FL:CreateCheckButton({parent = frame, tt = L["Show feed pet button when pet is hungry."],
 									setpoint = { point = FL.ANCHOR.TOPLEFT, frame = frame, relpoint = FL.ANCHOR.TOPLEFT, x = 28, y = -80},
 									value = { checked = FeedMachine.db.profile.warnPetHungry }})

 	checkbutton1:SetScript("OnClick", function()
 		FeedMachine.db.profile.warnPetHungry = checkbutton1:GetChecked()
 	end)

 	checkbutton1.Text1 = FL:CreateFontString({parent = checkbutton1, layer = "ARTWORK", inherits = "GameFontNormal", text = L["Feed Button"], justify = "LEFT",
 									setpoint = {point = FL.ANCHOR.RIGHT, frame = checkbutton1, relpoint = FL.ANCHOR.RIGHT, x = "font", y = 0}})
--	WARNING INTERVALS
 	local editbox1 = {}

 	editbox1.Text1 = FL:CreateFontString({parent = frame, layer = "ARTWORK", inherits = "GameFontNormal", text = L["Warning Interval"], justify = "LEFT",
 									setpoint = {point = FL.ANCHOR.TOPLEFT, frame = frame, relpoint = FL.ANCHOR.TOPLEFT, x = 28, y = -120}})

 	editbox1 = FL:CreateEditBox({parent = frame, tt = L["Sets interval in seconds at which warnings occur."], width = 50, height = 20,
 									setpoint = {point = FL.ANCHOR.RIGHT, frame = editbox1.Text1, relpoint = FL.ANCHOR.RIGHT, x = editbox1.Text1:GetStringWidth(), y = 0},
 									value = {numeric = true, value = FeedMachine.db.profile.msgInterval}})

 	editbox1:SetScript("OnEnterPressed", function()
 		if  tonumber(editbox1:GetText()) then
 			FeedMachine.db.profile.msgInterval = tonumber(editbox1:GetText())
 		else
 			FeedMachine.db.profile.msgInterval = 0
 			editbox1:SetText(0)
 		end
 	end)

--	BUTTON POPUP THRESHOLD
 	local slider = FL:CreateSlider({parent = frame, name = "FMOptionsSliderHappiness", tt = L["Show Feed Button at Happiness Level"],
 									setpoint = {point = FL.ANCHOR.TOPLEFT, frame = frame, relpoint = FL.ANCHOR.TOPLEFT, x = 28, y = -160},
 									value = {min = 1, max = 3, step = 1, mintext = L["Unhappy"], maxtext = L["Happy"],
 										value = self.db.profile.petHappinessLevel, valuetext = ({L["Unhappy"],L["Content"],L["Happy"]})[self.db.profile.petHappinessLevel]}})

 	slider:SetScript("OnValueChanged", function()
 		local hap = {L["Unhappy"],L["Content"],L["Happy"]}
 		getglobal(slider:GetName() .. "Text"):SetText(hap[slider:GetValue()])
 		self.db.profile.petHappinessLevel = slider:GetValue()
 	end)

--	POPUP GROWTH DIRECTION
 	local text = FL:CreateFontString({parent = frame, layer = "ARTWORK", inherits = "GameFontNormal", text = "Popup Direction", justify = "LEFT",
 									setpoint = {point = FL.ANCHOR.TOPLEFT, frame = frame, relpoint = FL.ANCHOR.TOPLEFT, x = 28, y = -200}})
 	local ddb1 = FL:CreateFrame({frame = FL.UIOBJECT.FRAME, name = "FMPopupButtonGrowthDir", parent = frame, inherits = "UIDropDownMenuTemplate",
 									setpoint = {point = FL.ANCHOR.LEFT, frame = text, relpoint = FL.ANCHOR.RIGHT, x = 10, y = 0}})
 	ddb1:SetScript("OnShow", function()
 		UIDropDownMenu_SetWidth(110,this)
 		UIDropDownMenu_Initialize(this, FMUI_OptionsGrowthDir_DropDownMenu_OnLoad)
 		UIDropDownMenu_SetSelectedName(FMPopupButtonGrowthDir, FeedMachine.db.profile.popupGrowthDir)
 	end)

 	ddb1:Show()
]]
	return frame
end
--[[
function FMUI_OptionsGrowthDir_DropDownMenu_OnLoad()
	for i,v in pairs({FL.ANCHOR.TOP,FL.ANCHOR.BOTTOM,FL.ANCHOR.LEFT,FL.ANCHOR.RIGHT}) do
		info            = UIDropDownMenu_CreateInfo()
		info.text       = v
		info.func       = FMUI_OptionsGrowthDir_DropDownMenu_OnClick
		info.checked    = nil
		UIDropDownMenu_AddButton(info)
	end
end

function FMUI_OptionsGrowthDir_DropDownMenu_OnClick()
	UIDropDownMenu_SetSelectedID(FMPopupButtonGrowthDir,this:GetID())
	FeedMachine.db.profile.popupGrowthDir = tostring(this:GetText())
	FeedMachine:Print("Setting popup direction to : " .. tostring(this:GetText()) .. " (/console reloadui needed for change)")
end
]]