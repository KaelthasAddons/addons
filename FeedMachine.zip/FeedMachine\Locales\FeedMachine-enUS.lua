local L = LibStub("AceLocale-3.0"):NewLocale("FeedMachine", "enUS", true)

L["Feed Machine"] = true

-- Menu Options
L["Show Config"] = true
L["Shows Config Screen"] = true
L["Reset Food"] = true
L["Reset Food Database"] = true
L["Show Feed Button at Happiness Level"] = true
L["Lock food list"] = true	

-- Info Messages
L["The Food DB updated, please resetdb to get new food data (/fm resetdb)"] = true
L["Resetting Food DB."] = true

-- UI Tabs		
L["Options"]	= true
L["Diets"]	= true
L["Foods"] = true

-- UI Tab Options
L["Feed Button"] = true
L["Show feed pet button when pet is hungry."] = true
L["Warning Interval"] = true
L["Sets interval in seconds at which warnings occur."] = true
L["Feed Pet Growth Direction"] = true
L["Sets the growth direction of the feed pet popup buttons"] = true
L["Button Scale"] = true
L["Control the size of the button"] = true

-- UI Error Messages (Must match in game error messages)
L["You fail to perform Feed Pet: You are mounted."] = true
L["You fail to perform Feed Pet: You must be standing to do that."] = true
L["You fail to perform Feed Pet: Out of range."] = true
L["You fail to perform Feed Pet: That food's level is not high enough for your pet."] = true
L["You fail to perform Feed Pet: Can't do that while stunned."] = true

-- Pet feeding messages
L["%s loves %s mjummie."] = true
L["%s looks in your bags and sees no food in there."] = true
L["%s thinks you should unmount before feeding him."] = true
L["%s likes to get closer with you before getting fed."] = true
L["%s wants food of a more appropriate level."] = true
L["%s looks at you wondering how you will feed him when you are stunned."] = true

-- FM Error Messages
L["No food available for your pet."] = true		
L["Unknown Item ID"] = true
L["Nothing"] = true

-- Pet Diets
L["Raw Meat"] = true
L["Raw Fish"] = true
L["Meat"] = true
L["Fish"] = true
L["Fruit"] = true
L["Fungus"] = true
L["Cheese"] = true
L["Bread"] = true
L["Food - Meat Raw"] = true
L["Food - Meat Basic"] = true
L["Food - Meat Bonus"] = true
L["Food - Meat Combo"] = true
L["Food - Bread Basic"] = true
L["Food - Bread Bonus"] = true
L["Food - Bread Combo"] = true
L["Food - Bread Conjured"] = true
L["Food - Cheese Basic"] = true
L["Food - Cheese Bonus"] = true
L["Food - Fish Raw"] = true
L["Food - Fish Basic"] = true
L["Food - Fish Bonus"] = true
L["Food - Fish Combo"] = true
L["Food - Fruit Basic"] = true
L["Food - Fruit Bonus"] = true
L["Food - Fruit Combo"] = true
L["Food - Fungus Basic"] = true
L["Food - Fungus Bonus"] = true
L["Food - Fungus Combo"] = true

-- Happiness Levels
L["Unhappy"] = true
L["Content"] = true
L["Happy"] = true

-- Buff Textures/Names