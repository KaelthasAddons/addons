﻿
LIFEBLOOMER_None = "None";
LIFEBLOOMER_Target = "Target";

if (GetLocale() == "deDE") then
	LIFEBLOOMER_Lifebloom = "Blühendes Leben";
	LIFEBLOOMER_Rejuvenation = "Verjüngung";
	LIFEBLOOMER_Regrowth = "Nachwachsen";
	LIFEBLOOMER_Healing_Touch = "Heilende Berührung";
	LIFEBLOOMER_Swiftmend = "Rasche Heilung";
	LIFEBLOOMER_Cure_Poison = "Vergiftung heilen";
	LIFEBLOOMER_Abolish_Poison = "Vergiftung aufheben";
	LIFEBLOOMER_Remove_Curse = "Fluch aufheben";
	LIFEBLOOMER_Rebirth = "Wiedergeburt";
	LIFEBLOOMER_Mark_of_the_Wild = "Mal der Wildnis";
	LIFEBLOOMER_Thorns = "Dornen";
	LIFEBLOOMER_Natures_Swiftness = "Schnelligkeit der Natur";
	
elseif (GetLocale() == "frFR") then 
	LIFEBLOOMER_Lifebloom = "Fleur de vie";
	LIFEBLOOMER_Rejuvenation = "Récupération";
	LIFEBLOOMER_Regrowth = "Rétablissement";
	LIFEBLOOMER_Healing_Touch = "Toucher guérisseur";
	LIFEBLOOMER_Swiftmend = "Prompte guérison";
	LIFEBLOOMER_Cure_Poison = "Guérison du poison";
	LIFEBLOOMER_Abolish_Poison = "Abolir le poison";
	LIFEBLOOMER_Remove_Curse = "Délivrance de la malédiction";
	LIFEBLOOMER_Rebirth = "Renaissance";
	LIFEBLOOMER_Mark_of_the_Wild = "Marque du fauve";
	LIFEBLOOMER_Thorns = "Epines";
	LIFEBLOOMER_Natures_Swiftness = "Rapidité de la nature";
	
elseif (GetLocale() == "zhTW") then 
	LIFEBLOOMER_Lifebloom = "生命之花";
	LIFEBLOOMER_Rejuvenation = "回春術";
	LIFEBLOOMER_Regrowth = "癒合";
	LIFEBLOOMER_Healing_Touch = "治療之觸";
	LIFEBLOOMER_Swiftmend = "迅癒";
	LIFEBLOOMER_Cure_Poison = "驅毒術";
	LIFEBLOOMER_Abolish_Poison = "消毒術";
	LIFEBLOOMER_Remove_Curse = "解除詛咒";
	LIFEBLOOMER_Rebirth = "復生";
	LIFEBLOOMER_Mark_of_the_Wild = "野性印記";
	LIFEBLOOMER_Thorns = "荊棘術";
	LIFEBLOOMER_Natures_Swiftness = "自然迅捷";
	
else
	LIFEBLOOMER_Lifebloom = "Lifebloom";
	LIFEBLOOMER_Rejuvenation = "Rejuvenation";
	LIFEBLOOMER_Regrowth = "Regrowth";
	LIFEBLOOMER_Healing_Touch = "Healing Touch";
	LIFEBLOOMER_Swiftmend = "Swiftmend";
	LIFEBLOOMER_Cure_Poison = "Cure Poison";
	LIFEBLOOMER_Abolish_Poison = "Abolish Poison";
	LIFEBLOOMER_Remove_Curse = "Remove Curse";
	LIFEBLOOMER_Rebirth = "Rebirth";
	LIFEBLOOMER_Mark_of_the_Wild = "Mark of the Wild";
	LIFEBLOOMER_Thorns = "Thorns";
	LIFEBLOOMER_Natures_Swiftness = "Nature's Swiftness";
end