local L = LibStub("AceLocale-3.0"):NewLocale("ManaPerc", "zhTW")
if not L then return end
--
L["Show Total"] = "總法力值"
L["Show Current"] = "現有法力值"
L["Enable Colour"] = "著色"
L["TOTAL_DESC"] = "根據總法力值顯示施放法術法力值百分比"
L["CURRENT_DESC"] = "根據現有法力值顯示施放法術法力值百分比"
L["COLOUR_DESC"] = "提示訊息資訊著色 (綠色=現有法力值，黃色=總法力值)"
