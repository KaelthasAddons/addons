local L = LibStub("AceLocale-3.0"):NewLocale("ManaPerc", "zhCN")
if not L then return end
--
L["Show Total"] = "总法力值"
L["Show Current"] = "当前法力值"
L["Enable Colour"] = "提示信息着色"
L["TOTAL_DESC"] = "根据总法力值计算百分比"
L["CURRENT_DESC"] = "根据现有法力值计算百分比"
L["COLOUR_DESC"] = "提示信息颜色 (绿色=现有法力值，黃色=总法力值)"
