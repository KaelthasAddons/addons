local L = LibStub("AceLocale-3.0"):NewLocale("ManaPerc", "enUS", true)
if not L then return end
--
L["Show Total"] = true
L["Show Current"] = true
L["Enable Colour"] = true
L["TOTAL_DESC"] = "Displays % mana cost based on total mana"
L["CURRENT_DESC"] = "Displays % mana cost based on current mana"
L["COLOUR_DESC"] = "Colour code tooltip info (Green=Current, Yellow=Total)"
