local function moneyFormat(amount)
    if (type(amount) == "number") then
        if ((amount >= 10000) or (amount <= -10000)) then
            return format("|cffffffff%0.1f|r|cffffd700g|r", amount / 10000);
        elseif ((amount >= 100) or (amount <= -100)) then
            return format("|cffffffff%.0f|r|cffc7c7cfs|r", amount / 100);
        else
            return format("|cffffffff%d|r|cffeda55fc|r", amount);
        end
    else
        return "";
    end
end

local AuctionFrameBrowse_Update_Old = AuctionFrameBrowse_Update;

local function AuctionFrameBrowse_Update_Hooked()
    AuctionFrameBrowse_Update_Old();

	local offset = FauxScrollFrame_GetOffset(BrowseScrollFrame);
	
	for i = 1, NUM_BROWSE_TO_DISPLAY do
		local name, _, count, _, _, _, min, inc, buy, bid =  GetAuctionItemInfo("list", offset + i);
		if (name) then
			local _, _, id = strfind(GetAuctionItemLink("list", offset + i) or "", "item:(%d+):");
			local stack = select(8, GetItemInfo(id));
			if (stack > 1) then
				bid = (bid > 0 and (bid + inc) or min);
				local item = getglobal("BrowseButton" .. i .. "Name");
				local text = moneyFormat(floor(bid / count));
				if (buy > 0) then
				 	text = text .. "/" .. moneyFormat(floor(buy / count));
				end
				item:SetText(item:GetText() .. "\n" .. "(" .. text .. ")")
			end
		end
	end
end

AuctionFrameBrowse_Update = AuctionFrameBrowse_Update_Hooked;
