SpazureMod v 0.0.0001 - a mod that plays sound effects within World of Warcraft version 2.4.3
Copyright (C) 2008 Spazure 

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.

If Killing Blow Announcer had been updated for WoW 2.4.3, this addon would not exist. Being too impatient to wait for someone else to either fix it or make another killing blow addon (without 50 million other features I /don't/ want), I decided to make my own from scratch. On the bright side, this means that the PvP kill feature will be based on whether or not the thing killed was a player, regardless of whether there's honor involved or not. This mod is also designed to compliment ShaderMod, which means I have no intention of including features that already exist within ShaderMod, unless I want to do it differently. 

If you want to contact me, I'm on curse as Spazure. I don't distribute my email address because I'm obnoxiously anti-spam. If for any reason curse no longer exists and you still somehow came across this addon, you can also reach me through my blog at:

http://www.ihatethebus.com

Thanks to:
- Merenwen for not maintaining KillingBlow Announcer, thus inspiring me to start this project to begin with
- Mr. Snazz for assistance with testing, bit checking, and moral support (mrsnazz.com)
- SkyDexter for letting me play around with his ShaderMod to practice LUA before starting this project
- All the wonderful people at wowwiki.com for the amazingly easy to follow WoW-related LUA documentation
- Zealous 1 for awesome music to write code by (zealous1.com)
- Geoff Lapaire and everybody at Pure Pwnage for making a show so freakishly awesome that I want to experience parts of it even when Im playing WoW. (purepwnage.com)