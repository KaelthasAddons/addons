--    SpazureMod [ v 0.0.0001 ]- a mod that plays sound effects within World of Warcraft version 2.4.3
--    Copyright (C) 2008 Spazure

--    This program is free software: you can redistribute it and/or modify
--    it under the terms of the GNU General Public License as published by
--    the Free Software Foundation, either version 3 of the License, or
--    (at your option) any later version.

--    This program is distributed in the hope that it will be useful,
--    but WITHOUT ANY WARRANTY; without even the implied warranty of
--    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
--    GNU General Public License for more details.

--    You should have received a copy of the GNU General Public License
--    along with this program.  If not, see <http://www.gnu.org/licenses/>.

SPAZUREMOD_VERSION = "|cFF00FFFFSp|cFF0000FFazure|cFF00FFFFMod v0.0.0002|r";

function SpaziMod_OnLoad()
	this:RegisterEvent("COMBAT_LOG_EVENT_UNFILTERED");
	this:RegisterEvent("PARTY_KILL");
	-- I'm using PARTY_KILL for now
	--	this:RegisterEvent("PLAYER_PVP_KILLS_CHANGED");
		-- I may or may not use these to seed the random play in a future release
		--math.randomseed( os.time() ); 
		--local random_headshot = math.random(1,3);
	local playerName = UnitName("player");

	SlashCmdList["SPAZUREMOD"] = SpaziCommand;
	SLASH_SPAZUREMOD1 = "/spazuremod";
	SLASH_SPAZUREMOD2 = "/spazi";
	
		-- this part is only here b/c i'm not sure if it matters if i use default_chat_frame or chatframe1 yet
		--DEFAULT_CHAT_FRAME:AddMessage(playerName ..' is a noob!');

	ChatFrame1:AddMessage(playerName .." is a noob! [" .. SPAZUREMOD_VERSION .. " Loaded] Type /spazi for options");
end

function SpaziMod_OnEvent(event,...)
	if (event=="COMBAT_LOG_EVENT_UNFILTERED") then
		
		local timestamp, eventType, srcGUID, srcName, srcFlags, dstGUID, dstName, dstFlags = select(1, ...);		
				
		if(arg2=="PARTY_KILL") then
		
			--ChatFrame1:AddMessage('eventType'..eventType);
			--ChatFrame1:AddMessage('srcGUID'..srcGUID);
			--ChatFrame1:AddMessage('srcName'..srcName);
			--ChatFrame1:AddMessage('srcFlags'..srcFlags);
			--ChatFrame1:AddMessage('dstGUID'..dstGUID);
			--ChatFrame1:AddMessage('dstName'..dstName);
			--ChatFrame1:AddMessage('dstFlags'..dstFlags); 
		
		-- This is the code for determining whether what you killed is a player or NPC. Feature not implimented yet, this code is just here for testing purposes.
			-- SRC is us...
			-- if (bit.band(srcFlags,0x00000400)==0x00000400) then
			--	ChatFrame1:AddMessage('src PLAYER') 
			-- else 
			--	ChatFrame1:AddMessage('src NOT PLAYER')
			-- end
		
			-- DST is the thing that got killed
			-- if (bit.band(dstFlags,0x00000400)==0x00000400) then
			--	ChatFrame1:AddMessage('dst PLAYER') 
			-- else 
			--	ChatFrame1:AddMessage('dst NOT PLAYER')
			-- end
			PlaySoundFile("Interface\\AddOns\\SpazureMod\\doug-boomheadshot"..math.random(4)..".wav");
			
			DEFAULT_CHAT_FRAME:AddMessage("|cFFFF0000BOOM HEADSHOT!");
		end
	else
		return;
	end
end

function SpaziCommand(msg)
	-- For the record, I'm annoyed that I have to initialize this AGAIN because I can't seem to call it from OnLoad
	local playerName = UnitName("player");
	
	DEFAULT_CHAT_FRAME:AddMessage("[" .. SPAZUREMOD_VERSION .. "]");

	if (string.lower(msg) == "help") then
		DEFAULT_CHAT_FRAME:AddMessage(playerName .."|cFF00FFFF is a noob! (Er, I mean, there is no help file yet, because no options have been implemented.)|r");
		return;
	end
	if (string.lower(msg) == "?") then
		DEFAULT_CHAT_FRAME:AddMessage(playerName .."|cFF00FFFF is a noob! (Er, I mean, there is no help file yet, because no options have been implemented.)|r");
		return;
	end
	DEFAULT_CHAT_FRAME:AddMessage("|cFF00FFFFSlash commands work, sweet! Now perhaps |cFF00FFFFSp|cFF0000FFazure|cFF00FFFF should think about making them, liek, do something.|r");
end

