MonkeyClock:

/monkeyclock
/mclock
Toggle the display of the clock

/monkeyclockhour <offset>
/mchour <offset>
Set the server hour offset

/monkeyclockminute <offset>
/mcminute <offset>
Set the server minute offset

/monkeyclocktoggle24
/mctoggle24
Toggle 24 hour display

/monkeyclocktoggleborder
/mctoggleborder
Toggle the border

/monkeyclocktogglelock
/mctogglelock
Toggle locking the frame
