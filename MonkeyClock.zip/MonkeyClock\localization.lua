--[[

	MonkeyClock:
	Simple no-frills clock.
	
	Website:	http://www.toctastic.net/
	Author:		Trentin (monkeymods@gmail.com)
	
	
	Contributors:

	Jim Bim
		- German translation

--]]


-- English
MONKEYCLOCK_TITLE			= "MonkeyClock";
MONKEYCLOCK_VERSION		= "2.8";
MONKEYCLOCK_TITLE_VERSION	= MONKEYCLOCK_TITLE .. " v" .. MONKEYCLOCK_VERSION;
MONKEYCLOCK_DESCRIPTION		= "A simple movable clock.";
MONKEYCLOCK_LOADED		= "|cffffff00" .. MONKEYCLOCK_TITLE .. " v" .. MONKEYCLOCK_VERSION .. " loaded";
MONKEYCLOCK_OPTIONS1		= "Please install MonkeyBuddy to configure your MonkeyClock easily.";
MONKEYCLOCK_OPTIONS2		= "\124TInterface\\Icons\\Trade_Engineering:0\124t MonkeyBuddy is currently not installed.";

MONKEYCLOCK_CHAT_COLOUR	= "|cff00ff00";
MONKEYCLOCK_RESET_MSG		= MONKEYCLOCK_CHAT_COLOUR .. MONKEYCLOCK_TITLE .. ": Settings reset.";

MONKEYCLOCK_CONFIRM_RESET	= "Okay to reset " .. MONKEYCLOCK_TITLE .. " settings to default values?";
MONKEYCLOCK_CONFIRM_ALARM	= "The " .. MONKEYCLOCK_TITLE .. " alarm has gone off.";

MONKEYCLOCK_SNOOZE		= "5 More Mins";


if (GetLocale() == "deDE") then

	MONKEYCLOCK_DESCRIPTION		= "Eine bewegliche Uhr.";
	MONKEYCLOCK_LOADED		= "|cffffff00" .. MONKEYCLOCK_TITLE .. " v" .. MONKEYCLOCK_VERSION .. " geladen";
	MONKEYCLOCK_OPTIONS1		= "Bitte installiere MonkeyBuddy um dein MonkeyClock einzustellen.";
	MONKEYCLOCK_OPTIONS2		= "\124TInterface\\Icons\\Trade_Engineering:0\124t MonkeyBuddy ist derzeit nicht installiert.";
	
	MONKEYCLOCK_RESET_MSG		= MONKEYCLOCK_CHAT_COLOUR .. MONKEYCLOCK_TITLE .. ": Einstellungen zur\195\188ckgesetzt.";
	
	MONKEYCLOCK_CONFIRM_RESET	= "Die Einstellungen von " .. MONKEYCLOCK_TITLE .. " wirklich zur\195\188cksetzen?";
	MONKEYCLOCK_CONFIRM_ALARM	= "Der " .. MONKEYCLOCK_TITLE .. " Alarm ist erreicht!";
	
	MONKEYCLOCK_SNOOZE		= "5 weitere Min";

end