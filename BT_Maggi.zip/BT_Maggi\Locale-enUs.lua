local L = LibStub("AceLocale-3.0"):NewLocale("BT_Maggi", "enUS", true)
if not L then return end

--infos
L["Module resetted"] = "Module resetted" --dont change this line!

L["info"] = "|cff91069ETactics by|r rpguides\n|cff91069EImages by|r Vonswan, rpguides\n|cff91069EModule by|r Sorontur\n\n|cffC0C0C0[http://www.kdh-wow.de]\n[http://www.rpguides.de]|r"

--add here localized tactic texts

L["tactic Maggi"] = [[
not yet available

]]

--texts for trash

L["trash Maggi"] = [[

]]


--ra text messages every line separated by \n
L["ra Maggi"] = "line1\nline2\nlin3"

--button captions