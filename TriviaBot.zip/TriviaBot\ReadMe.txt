 _______   _       _       ____        _   
|__   __| (_)     (_)     |  _ \      | |  
   | |_ __ ___   ___  __ _| |_) | ___ | |_ 
   | | '__| \ \ / / |/ _` |  _ < / _ \| __|
   | | |  | |\ V /| | (_| | |_) | (_) | |_ 
   |_|_|  |_| \_/ |_|\__,_|____/ \___/ \__|
	Version: 2.4.4

Introduction:
	Welcome to the long awaited release of TriviaBot 2.4.4, this new version includes a lot of features and bug fixes, along with a new efficient and clean coded GUI.

New Features:
	- GUI including an array of settings.
	- Score reporting now limited by setting.
	- Score reporting types are seperate (all time/game reports).
	- TriviaBot will now join your game channel if you are not in it.
	- TriviaBot now supports loading custom questions without xml file edits (up to 17 additional question files).
	- TriviaBot will not start questions if you cannot join the channel.

Bug Fixes:
	- Score count limiter allows for score reports without spam.
	- TriviaBot correctly talks to custom channels.
	- TriviaBot will no longer spam the channel when no game scores are in the database.
	
Code Changes:
	- Most of the GUI implementation is handled via LUA, allowing changes and parameters to be read and written programatically, this has cut down vastly on the code (XML format seems to just about tripple the file size due to unnessicary structure), and allows for very easy to read code to be written with little effort.
	- Removed last remaining unused functions from old TriviaBot 2.3.x days.
	
Known (possible) issues:
	- TriviaBot allows players from other channels to answer to questions being talked about on another channel as long as the Trivia Master is listening to both channels, I believe this has always been the case, and is an extreme improbability, while code can be added to do channel checking, this could conflict with whsiper games, so unless the community specifically needs this feature, it's being left out.

Settings:
	Question List - List of questions to be used in trivia game.
	Channel Type - The channel type to be used, such as "Guild", "Yell", "Say", "Whisper", "Custom", etc.
	Channel - When on "custom" this is the channel to be playing the game in, when in "Whisper" this is the player to whisper the game to, when in any other channel this does nothing.
	Question Interval - The time between when a question is answered, and the next question comes up, in seconds.
	Question TimeOut - The time the players are given to answer a question, in seconds.
	Question Warning - The time that players are warned they have left, in seconds.
	Score Reporting Count - How many players are printed on a score board, keep between 5-15, setting this to too high a value could spam the channel and get you kicked.
	Score Report Frequency - How frequently you want the scores to auto-report, in questions asked.
	Show Answers - Show the answer(s) to the question after the question has timed out.
	Show Reports - Show auto-reports.
	
Console:
	The console is still supported for those power users, which allow access to all settings (including those dangerous to tweak), be careful when modifying these as you do have direct access to them with only limited blocks in place.
	
	Use "/trivia help" for console commands.
	Use "/trivia setting" for setting listings.
	If a bad setting is messing up the game use: "/trivia resetconfig".

Adding your own questions:
	Create a file called questionX.lua, X being a number between 4-20 (ex: question4.lua), use the format defined in questions1.lua to construct your questions and answers.
	
Upgrading questions from 2.3.x to 2.4.x:
	As soon as 2.4.4 is stable and any final wrinkles are smoothed out, I will write a script to convert these questions over in less than a second. Keep tuned on curse.com
	
Comments? Feature Requests?:
	Contact the development team on Curse Gaming, or contact StrangeWill (contact info below).
	http://www.curse.com/downloads/details/8643/

Support:
	Use the ticket system on CurseForge:
	http://wow.curseforge.com/projects/trivia-bot/

About:
	TriviaBot 2.4.0 and above were developed by William Roush(StrangeWill) william@wolframstudios.com in an attempt to re-write TriviaBot to be up to date with less code, written more efficiently, easier to read, and a better question database structure, this is my first project in LUA, but I have had many years experience in many other languages.