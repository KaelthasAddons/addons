if not SimpleUnitFrames or not SimpleUnitFrames:HasModule("PortraitDamage") then return end

local core = SimpleUnitFrames
local PortraitDamage = core:GetModule("PortraitDamage")

core.CopyTable(PortraitDamage.unitMap, {
	party1 = "party",
	party2 = "party",
	party3 = "party",
	party4 = "party",

	partypet1 = "partypet",
	partypet2 = "partypet",
	partypet3 = "partypet",
	partypet4 = "partypet",
} )


