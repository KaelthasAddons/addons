if not SimpleUnitFrames or not SimpleUnitFrames:HasModule("PortraitDamage") then return end

local PortraitDamage = SimpleUnitFrames:GetModule("PortraitDamage")

PortraitDamage.frameSettings.target = {
	parent = TargetFrame,
	font = "NumberFontNormalHuge",
	point = { "Center", TargetPortrait, "CENTER" },
	size = 30,
}


