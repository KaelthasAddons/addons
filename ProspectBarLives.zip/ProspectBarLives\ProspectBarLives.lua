-- This line added to force the Curse Client and Curse website to use the correct version.
local addonName, addonTable = ...
--[[
Filedate: 2014-12-07T07:24:48Z@
Author: CKlausi
I wish to thank CKlaus1 for figuring out the fishing.  I have added it to my version of PBar
and i appreciate his efforts.

I also give credit to Prospectbar author egingell for this fine work.
I hope to keep it maintained and updated for future patches and expansions.
http://wow.curseforge.com/licenses/176-written-or-edited-by-eric-gingell/
]]--
local tt = GameTooltip

local wait = .5
local waitLonger = 1
local spellAttribute = "*spell1"
local typeAttribute = "*type1"
local itemAttribute = "*item1"

local localeStrings = {
	["enUS"] = {
		ARMOR = "Armor";
		WEAPON = "Weapon";
	},
	["deDE"] = {
		ARMOR = "Rüstung";
		WEAPON = "Waffe";
	},
	["esES"] = {
		ARMOR = "Armadura";
		WEAPON = "Arma";
	},
	["frFR"] = {
		ARMOR = "Armure";
		WEAPON = "Arme";
	},
	["zhCN"] = {
		ARMOR = "护甲";
		WEAPON = "武器";
	},
	["enGB"] = {
		ARMOR = "Armor";
		WEAPON = "Weapon";
	},
	["ruRU"] = {
		ARMOR = "Доспехи";
		WEAPON = "Оружие";
	},
}

local localeInfo = localeStrings[GetLocale()] or localeStrings["enUS"]
local localeArmorCheck, localeWeaponCheck

local ARMOR = localeInfo.ARMOR
local WEAPON = localeInfo.WEAPON

local eventScan = function(self, ...)
	self.scan = 1
	self.timer = wait
end

local function ValidateLocale(...)
	local localeArmorCheck, localeWeaponCheck
	for i = 1, select("#", ...) do
		local test = select(i, ...)
		if ARMOR == test then
			localeArmorCheck = true
		end
		if WEAPON == test then
			localeWeaponCheck = true
		end
	end
	return localeArmorCheck, localeWeaponCheck
end

--localeArmorCheck, localeWeaponCheck = ValidateLocale(GetAuctionItemClasses())

GutNClean = {};
GutNClean.WoD = {};

GutNClean.WoD.Small = {};
GutNClean.WoD.Small = { 
	111589,
	111650,
	111651,
	111652,
	111656,
	111658,
	111659,
	111662,
	118564,
};

GutNClean.WoD.Normal = {};
GutNClean.WoD.Normal = { 
	111595,
	111663,
	111664,
	111665,
	111666,
	111667,
	111668,
	111669,
	118565,
};

GutNClean.WoD.Enormous = {};
GutNClean.WoD.Enormous = { 
	111601,
	111670,
	111671,
	111672,
	111673,
	111674,
	111675,
	111676,
	118566,
};

addonTable.PROSPECT_ID = 31252
addonTable.MILLING_ID = 51005
addonTable.DE_ID = 13262
addonTable.PROSPECT = GetSpellInfo(addonTable.PROSPECT_ID) -- "Prospecting"
addonTable.PROSPECTABLE = ITEM_PROSPECTABLE -- "Prospectable"
addonTable.MILLING = GetSpellInfo(addonTable.MILLING_ID) -- "Milling"
addonTable.MILLABLE = ITEM_MILLABLE -- "Millable"
addonTable.LOCKED = LOCKED -- "Locked"
addonTable.ITEM_OPENABLE1 = ITEM_OPENABLE -- "<Right Click to Open>";
addonTable.ITEM_OPENABLE2 = USE_COLON .. " Open the (.*)" -- "Use: Open the *"; Only works on US clients
addonTable.ITEM_OPENABLE3 = USE_COLON .. " Turn a(.*)" -- "Use: Turn a*"; Only works on US clients
addonTable.ITEM_OPENABLE4 = USE_COLON .. " Combine ten (.*)" -- "Use: Combine ten *"; Only works on US clients
addonTable.ITEM_OPENABLE5 = USE_COLON .. " Turn ten (.*)" -- "Use: Turn ten *"; Only works on US clients
addonTable.ITEM_OPENABLE6 = USE_COLON .. " Turn 10 (.*)" -- "Use: Turn 10 *"; Only works on US clients
addonTable.ITEM_OPENABLE7 = USE_COLON .. " Turn three (.*)" -- "Use: Turn three *"; Only works on US clients
addonTable.ITEM_OPENABLE8 = USE_COLON .. " Grants (.*)"
addonTable.ITEM_OPENABLE9 = USE_COLON .. " Gain (.*)"
addonTable.ITEM_OPENABLEa = USE_COLON .. " Create (.*)"
addonTable.OPEN = "Open"
addonTable.LOCKPICKING = GetSpellInfo(1804) -- "Pick Lock"
addonTable.DE = GetSpellInfo(addonTable.DE_ID) -- "Disenchant"
addonTable.SKINNER = GetSpellInfo(158756) -- "Draenor Skinning"
addonTable.version = GetAddOnMetadata(addonName, "Version")

addonTable.COPPER = COPPER_AMOUNT:gsub("%%d", "%%s"):format("(.*)")
addonTable.SILVER = SILVER_AMOUNT:gsub("%%d", "%%s"):format("(.*)")
addonTable.GOLD = GOLD_AMOUNT:gsub("%%d", "%%s"):format("(.*)")

addonTable.toggle = CreateFrame("Button", "ProspectBarLivesToggle", UIParent, "UIPanelButtonTemplate")
addonTable.toggle:SetWidth(20)
addonTable.toggle:SetHeight(20)
addonTable.frame = CreateFrame("Frame", "ProspectBarLives", addonTable.toggle)
addonTable.toggle:SetPoint("CENTER", UIParent, "CENTER")
addonTable.frame:SetPoint("TOPLEFT", addonTable.toggle, "TOPLEFT", 22, 36)
addonTable.toggle:SetText("-")
addonTable.frame.tooltip = CreateFrame("GameTooltip", "ProspectBarLivesTooltip", nil, "GameTooltipTemplate")
addonTable.frame:SetHeight(1)
addonTable.frame:SetWidth(1)
addonTable.frame.buttons = {}
addonTable.frame.sides = {"Left", "Right"}

addonTable.toggle:SetMovable(true)
addonTable.toggle:SetScript("OnEnter", function(self, ...)
	local lbar
	if ProspectBarLivesOptions.lockMovement == 1 then
		lbar = "locked. To override, either hold down [Ctrl] or type '/pbl lock'."
	else
		lbar = "unlocked. Move button by holding Right mouse button and dragging."
	end
	GameTooltip_SetDefaultAnchor(tt, self)
	tt:AddLine("Toggle Button with left mouse button.")
	tt:AddLine("Movement is currently " .. lbar)
	tt:AddLine("Click to toggle visible item buttons.")
	tt:Show()
end)
addonTable.toggle:SetScript("OnLeave", function(self, ...)
	tt:Hide()
end)
addonTable.toggle:SetScript("OnMouseDown", function(self, button)
	if ProspectBarLivesOptions.lockMovement == 0 or IsControlKeyDown() then
		self:StartMoving()
	end
end)
addonTable.toggle:SetScript("OnMouseUp", function(self, button)
	self:StopMovingOrSizing()
end)

addonTable.frame:SetScript("OnEvent", function(self, event, ...)
	if event == "PLAYER_ENTERING_WORLD" then
		self:UnregisterEvent(event)
	end
	if self[event] then
		self[event](self, ...)
	end
end)

local dElevelCheck = function(link)
	if not Enchantrix then
		return true
	end
	return Enchantrix.Util.GetUserEnchantingSkill() >= Enchantrix.Util.DisenchantSkillRequiredForItem(link)
end

local function rawhide(bag,slot)
	if not GetSpellInfo(addonTable.SKINNER) then
		return false
	end
	if GetContainerItemLink(bag, slot) then
		local itemID = GetContainerItemID(bag, slot)
		local rhide = 10
		local ruin = 3
		local light = 5
		if (itemID == 2934 and select(2, GetContainerItemInfo(bag, slot)) >= ruin) then
			return true
		end
		if ((itemID == 110610 or (itemID >=112155 and itemID <= 112158) or (itemID >=112177 and itemID <=112185)) and select(2, GetContainerItemInfo(bag, slot)) >= rhide) then
			return true
		end
		if ((itemID == 25649 or itemID == 52977 or itemID == 33567 or itemID == 72162) and select(2, GetContainerItemInfo(bag, slot)) >= light) then
			return true
		end
	end
end

local function fractemp(bag, slot)
	if GetContainerItemInfo(bag, slot) then
		local itemID = GetContainerItemID(bag, slot)
		local littledust = 3
		local pcrystal = 10
		if ((itemID == 115504 or itemID == 115502) and select(2, GetContainerItemInfo(bag, slot)) >= pcrystal) then
			return true
		end
		if ((itemID == 74252 or itemID == 105718 or itemID == 52720 or itemID == 52718 or itemID == 34053 or itemID == 34056 or itemID == 22447 or itemID == 16202 or itemID == 11174 or itemID == 11134 or itemID == 10998 or itemID == 10938) and select(2, GetContainerItemInfo(bag,slot)) >= littledust) then
			return true
		end
	end
end
	
local function deAble(link)
	if not GetSpellInfo(addonTable.DE) or not link then -- if Disenchant is not in the spellbook, GetSpellInfo returns nil
		return false
	end
	local name,sclink,quality,iLevel,reqLevel,class,subclass,maxStack,equipSlot,texture,vendorPrice,cid,scid  = GetItemInfo(link)	
	if (dElevelCheck(link) and ((class == ARMOR) or (class == WEAPON ) or (cid==3 and scid==11)) and quality > 0 and quality < 5)  then
		return true
	else	
		return false
	end
end


local function haveten(bag, slot)
	local itemID = GetContainerItemID(bag, slot)
	if select(2, GetContainerItemInfo(bag, slot)) >=10 then
		return true
	else
		return false
	end
end

local function havethree(bag, slot)
	local itemID = GetContainerItemID(bag, slot)
	if select(2, GetContainerItemInfo(bag, slot)) >=3 then
		return true
	else
		return false
	end
end

local OnLeave = function(self, ...)
	if tt:IsOwned(self) and tt:GetOwner() == self then
		tt:Hide()
	end
end

local SetPoint = function(f, column)
	if f then
		return "BOTTOMLEFT", f, "TOPLEFT", 0, 0
	else
		return "TOPLEFT", addonTable.frame, "TOPLEFT", column * 36, 0
	end
end
local function getFish(bag, slot)
	if GetContainerItemLink(bag, slot) then
		local itemID = GetContainerItemID(bag, slot);
		local fish = GutNClean.WoD;
		local gutCount = 5;
		
		for index, _ in pairs(fish) do
			
			for i = 1, #fish[index] do
				if( itemID == fish[index][i] and select(2, GetContainerItemInfo(bag, slot)) >= gutCount) then
					return true;
				end
			end
		end
		return false;
	end
end

local OnEnter = function(self, ...)
	local bag, slot, info = self.bag, self.slot, self.info
	GameTooltip_SetDefaultAnchor(tt, self)
	local itemLink = GetContainerItemLink(bag, slot)
	if not itemLink then
		return
	end
	tt:SetBagItem(bag, slot)
	tt:AddLine("Click to use " .. (GetSpellLink(info.proftype) or info.proftype) .. " on " .. info.item .. ".")
	local itemName = GetItemInfo(itemLink)
	tt:AddLine("Control right-click to hide this item.")
	tt:Show()
end

local MakeBar = function(self)
	local prevButton, column, row, mstack
	column, row = 0, 0
	mstack = 0
	for bag, data in pairs(self.buttons) do
		for slot, info in pairs(data) do
			info.button:Hide()
			if info.item and info.proftype and (GetSpellInfo(info.proftype) or info.proftype == addonTable.OPEN) then
				local texture, itemCount, locked, qlty, readable = GetContainerItemInfo(bag, slot)
				local link = GetContainerItemLink(bag, slot)
				local name,sclink,quality,iLevel,reqLevel,class,subclass,maxStack,equipSlot,texture,vendorPrice,cid,scid,bindtype,expacid,itemsetid,icr  = GetItemInfo(link)
				local isInSet, setName = GetContainerItemEquipmentSetInfo(bag, slot)
				local plevel=UnitLevel("player")
				if link and not dnde[link] and not ProspectBarLivesOptions.ignored[link] and plevel>=reqLevel and not isInSet then
					if (GetSpellInfo(addonTable.SKINNER) and (GetContainerItemID(bag, slot)) == 2934) or info.proftype == addonTable.OPEN then
						mstack = 3
					else	
						mstack = 5
					end
					if (itemCount >= mstack and (info.proftype == addonTable.MILLING or info.proftype == addonTable.PROSPECT or fractemp(bag, slot) or haveten(bag,slot) or havethree(bag, slot) or getFish(bag, slot) or rawhide(bag,slot))) or not (info.proftype == addonTable.MILLING or info.proftype == addonTable.PROSPECT or fractemp(bag, slot) or haveten(bag,slot) or havethree(bag, slot) or getFish(bag, slot) or rawhide(bag,slot)) then
						if row > 5 then
							column = column + 1
							row = 0
							prevButton = nil
						end
						row = row + 1
						info.button.bag, info.button.slot, info.button.info = bag, slot, info
						info.button:SetScript("OnEnter", OnEnter)
						info.button.UpdateTooltip = OnEnter
						info.button.texture:SetTexture(texture)
						info.button:SetAttribute(typeAttribute, ATTRIBUTE_NOOP)
						info.button:SetAttribute(itemAttribute, ATTRIBUTE_NOOP)
						info.button:SetAttribute(spellAttribute, ATTRIBUTE_NOOP)
						info.button:SetAttribute("target-bag", ATTRIBUTE_NOOP)
						info.button:SetAttribute("target-slot", ATTRIBUTE_NOOP)
						if info.proftype == addonTable.OPEN then
							info.button:SetAttribute(typeAttribute, "item")
							info.button:SetAttribute(itemAttribute, bag .. " " .. slot)
							info.button:SetAttribute(spellAttribute, ATTRIBUTE_NOOP)
							info.button:SetAttribute("target-bag", ATTRIBUTE_NOOP)
							info.button:SetAttribute("target-slot", ATTRIBUTE_NOOP)
						else
							info.button:SetAttribute(typeAttribute, "spell")
							info.button:SetAttribute(itemAttribute, ATTRIBUTE_NOOP)
							info.button:SetAttribute(spellAttribute, info.proftype)
							info.button:SetAttribute("target-bag", bag)
							info.button:SetAttribute("target-slot", slot)
						end
						info.button.proftype = info.proftype
						info.button:SetPoint(SetPoint(prevButton, column))
						SetItemButtonCount(info.button, itemCount)
						info.button:Show()
						prevButton = info.button
					end
				end
			end
		end
	end
end

addonTable.toggle:SetScript("OnClick", function(self, button, ...)
	if (ProspectBarLivesOptions.hideWhenInCombat == 1 and not InCombatLockdown()) or button ~= "LeftButton" then
		if addonTable.frame:IsShown() then	
			addonTable.frame:Hide()
			ProspectBarLivesOptions.hidden = 1
			self:SetText("+")
		else
			addonTable.frame:Show()
			ProspectBarLivesOptions.hidden = nil
			self:SetText("-")
		end
	end
end)

local EventRegistry = function(self, un)
	self[(un and "Unr" or "R") .. "egisterEvent"](self, "LOOT_OPENED")
	self[(un and "Unr" or "R") .. "egisterEvent"](self, "LOOT_CLOSED")
	self[(un and "Unr" or "R") .. "egisterEvent"](self, "LOOT_SLOT_CLEARED")
	self[(un and "Unr" or "R") .. "egisterEvent"](self, "UNIT_SPELLCAST_STOP")
	self[(un and "Unr" or "R") .. "egisterEvent"](self, "UNIT_SPELLCAST_INTERRUPTED")
	self[(un and "Unr" or "R") .. "egisterEvent"](self, "UNIT_SPELLCAST_SUCCESS")
end

local StartMoving = function(self, button, ...)
	if button == "RightButton" then
		self:GetParent():GetParent():StartMoving()
	end
end

local StopMovingOrSizing = function(self, button, ...)
	self:GetParent():GetParent():StopMovingOrSizing()
	if button == "RightButton" and IsControlKeyDown() and not IsShiftKeyDown() and not IsAltKeyDown() then
		local link = GetContainerItemLink(self.bag, self.slot)
		if link then
			ProspectBarLivesOptions.ignored[link] = 1
			dnde[link]=1
		end
		self:GetParent().scan = 1
	end
end

local SetMovable = function(self)
	self:SetScript("OnMouseDown", StartMoving)
	self:SetScript("OnMouseUp", StopMovingOrSizing)
end

local spellDone = function(self, unit, spellName, ...)
	if unit == "player" and spellName == self.proftype then
		self:GetParent().scan = 1
		self:GetParent().timer = waitLonger
	end
end

local LootSlotIsCoin = LootSlotIsCoin
if not LootSlotIsCoin then
	function LootSlotIsCoin(lootSlot)
		if LootSlotIsItem then
			return LootSlotIsItem(lootSlot)
		else
			return LootSlotHasItem(lootSlot)
		end
	end
end

local tempData = {}
local eventFunctions = {
	LOOT_OPENED = function(self, autoloot)
		if tt:IsOwned(self) and tt:GetOwner() == self then
			tt:Hide()
		end
		wipe(tempData)
		local bag, slot = self.bag or self:GetAttribute("target-bag"), self.slot or self:GetAttribute("target-slot")
		if not (bag and slot) and not (bag == "" and slot == "") then
			return
		end
		local itemLink = GetContainerItemLink(bag, slot)
		local itemName = itemLink and GetItemInfo(itemLink)
		self.tempItemName = itemName
		for lootSlot = 1, GetNumLootItems() do
			tempData[lootSlot] = tempData[lootSlot] or {}
			local lootIcon, lootName, lootQuantity, rarity, locked, isQuestItem, questId, isActive = GetLootSlotInfo(lootSlot)
			if LootSlotIsCoin(lootSlot) then
				local cash = 0
				(lootName .. "\n"):gsub("(.*)\n",function(line)
					local c = tonumber(line:match(addonTable.COPPER))
					local s = tonumber(line:match(addonTable.SILVER))
					local g = tonumber(line:match(addonTable.GOLD))
					cash = (c or 0) + ((s or 0) * 100) + ((g or 0) * 1000)
				end)
				tempData[lootSlot]["Money"] = tempData[lootSlot]["Money"] or {}
				tempData[lootSlot]["Money"]["cash"] = cash
				tempData[lootSlot]["Money"]["looted"] = 1
			elseif lootName then
				tempData[lootSlot]["Items"] = tempData[lootSlot]["Items"] or {}
				tempData[lootSlot]["Items"][lootName] = {}
				tempData[lootSlot]["Items"][lootName]["looted"] = 1
				tempData[lootSlot]["Items"][lootName]["count"] = lootQuantity
			end
		end
	end,
	LOOT_CLOSED = function(self)
		self.tempItemName = nil
		EventRegistry(self, 1)
	end,
	LOOT_SLOT_CLEARED = function(self, lootSlot)
		if tempData[lootSlot] and self.tempItemName then
			local itemName = self.tempItemName
			ProspectBarLivesLoots[self.proftype] = ProspectBarLivesLoots[self.proftype] or {}
			ProspectBarLivesLoots[self.proftype][itemName] = ProspectBarLivesLoots[self.proftype][itemName] or {}
			for lootType, info in pairs(tempData[lootSlot]) do
				if lootType == "Money" then
					ProspectBarLivesLoots[self.proftype][itemName][lootType] = ProspectBarLivesLoots[self.proftype][itemName][lootType] or {
						max = info["cash"],
						min = info["cash"],
						total = 0,
						looted = 0,
					}
					ProspectBarLivesLoots[self.proftype][itemName][lootType]["min"] = min(ProspectBarLivesLoots[self.proftype][itemName][lootType]["min"], info["cash"])
					ProspectBarLivesLoots[self.proftype][itemName][lootType]["max"] = max(ProspectBarLivesLoots[self.proftype][itemName][lootType]["max"], info["cash"])
					ProspectBarLivesLoots[self.proftype][itemName][lootType]["total"] = ProspectBarLivesLoots[self.proftype][itemName][lootType]["total"] + info["cash"]
					ProspectBarLivesLoots[self.proftype][itemName][lootType]["looted"] = ProspectBarLivesLoots[self.proftype][itemName][lootType]["looted"] + info["looted"]
				elseif lootType == "Items" then
					for lootName in pairs(info) do
						ProspectBarLivesLoots[self.proftype][itemName][lootType] = ProspectBarLivesLoots[self.proftype][itemName][lootType] or {}
						ProspectBarLivesLoots[self.proftype][itemName][lootType][lootName] = ProspectBarLivesLoots[self.proftype][itemName][lootType][lootName] or {
							looted = 0,
							count = 0,
						}
						ProspectBarLivesLoots[self.proftype][itemName][lootType][lootName]["looted"] = ProspectBarLivesLoots[self.proftype][itemName][lootType][lootName]["looted"] + info[lootName]["looted"]
						ProspectBarLivesLoots[self.proftype][itemName][lootType][lootName]["count"] = ProspectBarLivesLoots[self.proftype][itemName][lootType][lootName]["count"] + info[lootName]["count"]
					end
				end
			end
		end
	end,
	UNIT_SPELLCAST_SUCCESS = spellDone,
	UNIT_SPELLCAST_STOP = spellDone,
	UNIT_SPELLCAST_INTERRUPTED = function(self, unit, spellName, ...)
		if unit == "player" and spellName == self.proftype then
			self.tempItemName = nil
			EventRegistry(self, 1)
		end
	end}

local OnEvent = function(self, event, ...)
	if not self.proftype then
		return
	end
	if event ~= "LOOT_SLOT_CLEARED" then
		self:UnregisterEvent(event)
	end
	eventFunctions[event](self, ...)
end

local PreClick = function(self, button)
	EventRegistry(self)
	local _, _, _, _, _, _, castTime = GetSpellInfo(self.proftype or "")
	self:GetParent().scan = 1
	self:GetParent().timer = castTime and ((castTime / 1000) + waitLonger) or waitLonger
end

local ScanBags = function(self, event, ...)
	if InCombatLockdown() then
		return
	end
	for bag = 0, NUM_BAG_FRAMES do
		self.buttons[bag] = self.buttons[bag] or {}
		for slot = 1, GetContainerNumSlots(bag) do
			self.buttons[bag][slot] = self.buttons[bag][slot] or {}
			local info = self.buttons[bag][slot]
			local link = GetContainerItemLink(bag, slot)
			local isInSet, setName = GetContainerItemEquipmentSetInfo(bag, slot)
			local proftype
			if link and not dnde[link] and not ProspectBarLivesOptions.ignored[link] and not isInSet then
				self.tooltip:SetOwner(WorldFrame)
				self.tooltip:SetBagItem(bag, slot)
				for i = 1, self.tooltip:NumLines() do
					for _, side in pairs(self.sides) do
						local itemID = GetContainerItemID(bag, slot);
						local tt = _G[self.tooltip:GetName() .. "Text" .. side .. i]:GetText()
						if tt == addonTable.PROSPECTABLE or itemID == 123918 or itemID == 123919 or itemID == 151564 then
							proftype = addonTable.PROSPECT
						elseif tt == addonTable.MILLABLE or ( tt and strmatch(tt, ".+Herbalism skill.+")) then
							proftype = addonTable.MILLING
						elseif tt == addonTable.LOCKED then
							proftype = addonTable.LOCKPICKING
						elseif tt == addonTable.ITEM_OPENABLE1 or (tt and tt:match(addonTable.ITEM_OPENABLE2)) or (tt and tt:match(addonTable.ITEM_OPENABLE3)) then
							proftype = addonTable.OPEN
						elseif getFish(bag, slot) or fractemp(bag, slot) or rawhide(bag, slot) or (tt and tt:match(addonTable.ITEM_OPENABLE4) and haveten(bag,slot)) then
							proftype = addonTable.OPEN
						elseif (tt and tt:match(addonTable.ITEM_OPENABLE5) and haveten(bag, slot)) then
							proftype = addonTable.OPEN
						elseif (tt and tt:match(addonTable.ITEM_OPENABLE6) and haveten(bag, slot)) then
							proftype = addonTable.OPEN
						elseif (tt and tt:match(addonTable.ITEM_OPENABLE7)) or (tt and tt:match(addonTable.ITEM_OPENABLE8)) or (tt and tt:match(addonTable.ITEM_OPENABLE9)) or (tt and tt:match(addonTable.ITEM_OPENABLEa)) then
							proftype = addonTable.OPEN
						elseif deAble(link) then
							proftype = addonTable.DE
						end
						if proftype then
							break
						end
					end
					if proftype then
						break
					end
				end
			end
			self.tooltip:Hide()
			local fname = self:GetName() .. "Bag" .. bag .. "Slot" .. slot
			info.proftype = proftype -- nil if there's no prof available
			info.item = link -- nil if there's no item in the slot
			info.button = _G[fname]
			if not info.button then
				info.button = CreateFrame("Button", fname, self, "SecureActionButtonTemplate,ItemButtonTemplate") -- make the button regardless
				info.button:SetHeight(36)
				info.button:SetWidth(36)
				info.button:EnableMouse(true)
				info.button:RegisterForClicks("LeftButtonUp")
				info.button.texture = _G[fname .. "IconTexture"]
				if not info.button.texture then
					info.button.texture = info.button:CreateTexture(fname .. "IconTexture")
				end
				info.button.texture:SetAllPoints(info.button)
				info.button:SetScript("PreClick", PreClick)
				info.button.bag = bag
				info.button.slot = slot
				info.button:HookScript("OnLeave", OnLeave)
				info.button:HookScript("OnEvent", OnEvent)
				SetMovable(info.button)
			end
			info.button:ClearAllPoints()
			info.button:Hide()
		end
	end
	MakeBar(self)
end

addonTable.frame.timer = wait
addonTable.frame:SetScript("OnUpdate", function(self, e)
	if self.scan then
		self.timer = self.timer - e
		if self.timer <= 0 then
			self.scan = nil
			self.timer = wait
			ScanBags(self)
		end
	end
end)

addonTable.frame.PLAYER_REGEN_ENABLED = function(self, ...)
	eventScan(self, ...)
	if not ProspectBarLivesOptions.hidden and ProspectBarLivesOptions.hideWhenInCombat == 1 then
		self:Show()
	end
end
addonTable.frame:RegisterEvent("PLAYER_REGEN_ENABLED")

addonTable.frame.PLAYER_REGEN_DISABLED = function(self, ...)
	if(ProspectBarLivesOptions.hideWhenInCombat == 1) then
		self:Hide()
	end
end
addonTable.frame:RegisterEvent("PLAYER_REGEN_DISABLED")

addonTable.frame.BAG_UPDATE = eventScan
addonTable.frame:RegisterEvent("BAG_UPDATE")

addonTable.frame.CHAT_MSG_SKILL = eventScan
addonTable.frame:RegisterEvent("CHAT_MSG_SKILL")
	
addonTable.frame.PLAYER_LEVEL_UP = eventScan
addonTable.frame:RegisterEvent("PLAYER_LEVEL_UP")
	
addonTable.frame.PLAYER_ENTERING_WORLD = function(self, ...)
	ProspectBarLivesOptions = ProspectBarLivesOptions or {}
	ProspectBarLivesLoots = ProspectBarLivesLoots or {}
	ProspectBarLivesOptions.lockMovement = ProspectBarLivesOptions.lockMovement or 0
	ProspectBarLivesOptions.hideWhenInCombat = ProspectBarLivesOptions.hideWhenInCombat or 1
	ProspectBarLivesOptions.scale = ProspectBarLivesOptions.scale or 1
	ProspectBarLivesOptions.smallScale = ProspectBarLivesOptions.smallScale ~= nil and ProspectBarLivesOptions.smallScale or 1
	ProspectBarLivesOptions.ignored = ProspectBarLivesOptions.ignored or {}
	dnde=ProspectBarLivesOptions.ignored
	eventScan(self, ...)
	self:GetParent():SetScale(ProspectBarLivesOptions.smallScale == 1 and UIParent:GetEffectiveScale() or ProspectBarLivesOptions.scale)
	self:GetParent():Show()
	if not ProspectBarLivesOptions.hidden then
		self:Show()
	end
end
addonTable.frame:RegisterEvent("PLAYER_ENTERING_WORLD")

_G["SLASH_" .. addonName .. "1"] = "/" .. addonName:lower()
_G["SLASH_" .. addonName .. "2"] = "/pbl"
SlashCmdList[addonName] = function(msg, chatEdit)
	local msgL, msgR = msg:match("(%S+)%s+(.*)")
	if msgL and msgR then
		msgL, msgR = msgL:trim(), msgR:trim()
	end
	if msg == "" then
		print("/" .. addonName:lower(), "lock - toggle movement", "[" .. (ProspectBarLivesOptions.lockMovement == 1 and "not movable" or "movable") .. "]")
		print("/" .. addonName:lower(), "combat - toggle hiding when in combat", "[" .. (ProspectBarLivesOptions.hideWhenInCombat == 0 and "unhidden" or "will hide") .. "]")
		print("/" .. addonName:lower(), "small - toggle use smallScale", "[" .. (ProspectBarLivesOptions.smallScale == 1 and "small" or "normal") .. "]")
		print("/" .. addonName:lower(), "scale - change the scale (use a number less than 2 unless you want it insanely big)", "[" .. ProspectBarLivesOptions.scale .. "]")
		print("/" .. addonName:lower(), "unhide all|itemlink - all: remove all hidden items. itemlink: remove the item (must be shift clicked or copied from the saved variables file).")
		print("/" .. addonName:lower(), "about - Shows current version number. [" .. addonTable.version .. "]")
		print("/" .. addonName:lower(), "ignored - Print a list of items that are on the ignore list. You can then use the /pbl unhide and scroll up the chat window, shift click the link, to restore the item(s)")		
		return
	elseif msg == "lock" then
		if ProspectBarLivesOptions.lockMovement == 1 then
			ProspectBarLivesOptions.lockMovement = 0
		else
			ProspectBarLivesOptions.lockMovement = 1
		end
		return
	elseif msg == "combat" then
		if ProspectBarLivesOptions.hideWhenInCombat == 1 then
			ProspectBarLivesOptions.hideWhenInCombat = 0
		else
			ProspectBarLivesOptions.hideWhenInCombat = 1
		end
		print(addonName .. (ProspectBarLivesOptions.hideWhenInCombat == 0 and " unhidden" or " will hide") .. " when in combat.")
		return
	elseif msg == "small" then
		if ProspectBarLivesOptions.smallScale == 1 then
			ProspectBarLivesOptions.smallScale = 0
		else
			ProspectBarLivesOptions.smallScale = 1
		end
		addonTable.toggle:SetScale(ProspectBarLivesOptions.smallScale == 1 and UIParent:GetEffectiveScale() or ProspectBarLivesOptions.scale)
		return
	elseif msgL == "unhide" then
		if msgR == "all" then
			wipe(ProspectBarLivesOptions.ignored)
			wipe(dnde)
		else
			ProspectBarLivesOptions.ignored[tostring(msgR)] = nil
			dnde[tostring(msgR)] = nil
		end
		addonTable.frame.scan = 1
		return
	elseif msgL == "scale" then
		local scale = tonumber(msgR)
		if scale and scale > 0 then
			ProspectBarLivesOptions.scale = scale
		end
		ProspectBarLivesOptions.smallScale = 0
		addonTable.toggle:SetScale(ProspectBarLivesOptions.smallScale == 1 and UIParent:GetEffectiveScale() or ProspectBarLivesOptions.scale)
		return
	elseif msg == "about" then
		print(addonName:lower() .. " Version " .. tostring(addonTable.version))
		return
	elseif msg == "ignored" then
		for key,value in next,dnde,nil do print(key,value) end
		return
	end
	-- if this gets executed then the user entered invalid data so help them out.
	SlashCmdList[addonName]("", chatEdit)
end
