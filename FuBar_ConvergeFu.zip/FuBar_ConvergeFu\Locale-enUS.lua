local L = AceLibrary("AceLocale-2.2"):new("ConvergeFu"); 

L:RegisterTranslations("enUS", function() return {

   ["labelName"]                               = "ConvergeFu",
   ["versionName"]                             = "Darkshore",
   ["versionNumber"]                           = "3.29",
   
   ["tablet-cat-01-title"]                     = "About This Addon",
   ["tablet-cat-01-line-01"]                   = "ConvergeFu is an addon for the officers",
   ["tablet-cat-01-line-02"]                   = "and members of the guild Converge, an",
   ["tablet-cat-01-line-03"]                   = "Alliance PVE raiding guild on the",
   ["tablet-cat-01-line-04"]                   = "Anachronos (EU) realm.",
   ["tablet-cat-01-line-05"]                   = " ",
   ["tablet-cat-01-line-06"]                   = "To access this addon's functions from",
   ["tablet-cat-01-line-07"]                   = "your chat window, simply enter /confu",
   ["tablet-cat-01-line-08"]                   = "to view all available options. This is",
   ["tablet-cat-01-line-09"]                   = "useful if you want to create your own.",
   ["tablet-cat-01-line-10"]                   = "macro buttons for specific functions",
   ["tablet-cat-01-line-11"]                   = "provided by ConvergeFu.",

   ["tablet-cat-02-title"]                     = "Guild Management",
   ["tablet-cat-02-line-01"]                   = "The guild is currently managed by the",
   ["tablet-cat-02-line-02"]                   = "following ",
   ["tablet-cat-02-line-03"]                   = " officers.",
   ["tablet-cat-02-line-04"]                   = " ",

   ["tablet-cat-03-title"]                     = "About You",
   ["tablet-cat-03-line-01"]                   = "Name : ",
   ["tablet-cat-03-line-02"]                   = "Guild: ",
   ["tablet-cat-03-line-03"]                   = "Rank : ",
   
   ["common-guildname-unguilded"]              = "Unguilded",
   ["common-rankname-unguilded"]               = "Unranked",
   
   ["tabletHint"]                              = "Click to toggle RBS dashboard, alt-click to run an RBS report, ctrl-click to toggle the BusyResponder on/off, right-click to view ConvergeFu menus.", 

   ["common-separator-dashed-line"]            = "---------------------------------------------------------",
   ["common-separator-empty-line"]             = " ",

   ["common-guildname"]                        = "Converge",
   ["common-guild-recruitment-advert-msg"]     = "Converge recruitment is open for experienced players who are interested in joining our push to complete 'TBC' before the release of 'WotLK.' Whisper 'guildinfo' for more information or visit our website at www.converge-dh.com for full details.",
   
   ["common-officer-name-banasea"]             = "Banasea",
   ["common-officer-name-broliant"]            = "Broliant",
   ["common-officer-name-jawa"]                = "Jawa",
   ["common-officer-name-letita"]              = "Letita",
   ["common-officer-name-lyamblade"]           = "Lyamblade",
   ["common-officer-name-paraply"]             = "Paraply",
   ["common-officer-name-vanhelgan"]           = "Vanhelgan",
   ["common-officer-name-zmall"]               = "Zmall",

   ["common-rankname-gm"]                      = "Guild Master",
   ["common-rankname-officer"]                 = "Officer",
   ["common-rankname-member-hero"]             = "Hero Member",
   ["common-rankname-member-normal"]           = "Normal Member",
   ["common-rankname-member-trial"]            = "Trial Member",
   ["common-rankname-alt-officer"]             = "Alt-Officer",
   ["common-rankname-alt-hero"]                = "Alt-Hero",
   ["common-rankname-alt-normal"]              = "Alt-Normal",
   ["common-rankname-alt-trial"]               = "Alt-Trial",
   ["common-rankname-benched"]                 = "Benched",

   ["common-motd-raidinvites-01"]              = "RAID INVITATION PERIOD: Whisper 'invite' to ",
   ["common-motd-raidinvites-02"]              = " for a place in the initial raid group.",
   
   ["common-motd-raidinprogress-01"]           = "RAID IN PROGRESS: Whisper 'wl add' to ",
   ["common-motd-raidinprogress-02"]           = " for a place in the raid queue.",
   
   ["common-motd-raidended-01"]                = "RAID ENDED: Many thanks everyone, see you at the next one!",

   ["common-setrank-msg-01"]                   = " ConvergeFu: Attempting to set rank of ",
   ["common-setrank-msg-02"]                   = " from ",
   ["common-setrank-msg-03"]                   = " to ",
   ["common-setrank-msg-04"]                   = "...",   
   
   ["common-rankchange-announce-01-msg"]       = "---------------------------------------------------------",
   ["common-rankchange-announce-02-msg"]       = " Hero Membership Update",
   ["common-rankchange-announce-03-msg"]       = "---------------------------------------------------------",
   ["common-rankchange-announce-04-msg"]       = " 1: All existing hero members will",
   ["common-rankchange-announce-05-msg"]       = "    shortly be demoted. This is normal.",
   ["common-rankchange-announce-06-msg"]       = " 2: The 'new' hero members will then be",
   ["common-rankchange-announce-07-msg"]       = "    promoted to the hero rank.",
   ["common-rankchange-announce-08-msg"]       = " 3: All alts of hero members will then",
   ["common-rankchange-announce-09-msg"]       = "    be promoted to the alt-hero rank.",
   ["common-rankchange-announce-10-msg"]       = " ",
   ["common-rankchange-announce-11-msg"]       = " Apologies for the unavoidable but",
   ["common-rankchange-announce-12-msg"]       = " necessary rank-change spam notices.",
   ["common-rankchange-announce-13-msg"]       = "---------------------------------------------------------",

   ["mainmenu-announce-title"]                 = "1 - Announcements",
   ["mainmenu-announce-descr"]                 = "Standardised Announcement Message Options.",
   
   ["mainmenu-chat-title"]                     = "2 - Custom Chat",
   ["mainmenu-chat-descr"]                     = "Converge Custom Chat Options.",
   
   ["mainmenu-addons-title"]                   = "3 - Other Addons",
   ["mainmenu-addons-descr"]                   = "Easy-Access Options for Other Addons.",
   
   ["mainmenu-macro-title"]                    = "4 - Macros",
   ["mainmenu-macro-descr"]                    = "Useful macros.",
   
   ["mainmenu-tools-title"]                    = "5 - Tools",
   ["mainmenu-tools-descr"]                    = "Useful tools and utilities.",
   
   ["ann-guild-title"]                         = "1 - Guild Announcements", 
   ["ann-guild-descr"]                         = "Make an announcement in the guild chat channel.", 

   ["ann-raid-title"]                          = "2 - Raid Announcements", 
   ["ann-raid-descr"]                          = "Make an announcement in the raid chat channel.", 

   ["ann-party-title"]                         = "3 - Party Announcements", 
   ["ann-party-descr"]                         = "Make an announcement in the party chat channel.", 

   ["ann-say-title"]                           = "4 - Say Announcements", 
   ["ann-say-descr"]                           = "Make an announcement in the say chat channel.", 

   ["ann-guild-raid-invite-title"]             = "1 - Raid Invitations Open", 
   ["ann-guild-raid-invite-descr"]             = "Announce that the raid invitation period has begun.",

   ["ann-guild-raid-invite-officer-descr"]     = "Members should whisper the named officer for an invitation.",
   
   ["ann-guild-raid-invite-01-msg"]            = "---------------------------------------------------------",
   ["ann-guild-raid-invite-02-msg"]            = " Raid Invitation Time:",
   ["ann-guild-raid-invite-03-msg"]            = "---------------------------------------------------------",
   ["ann-guild-raid-invite-04-msg"]            = " Raid invitations have begun. Please",
   ["ann-guild-raid-invite-05-msg"]            = " whisper the word 'invite' to...",
   ["ann-guild-raid-invite-06-msg"]            = " ",
   ["ann-guild-raid-invite-07-msg"]            = " ",
   ["ann-guild-raid-invite-08-msg"]            = " ...for an automated invitation",
   ["ann-guild-raid-invite-09-msg"]            = " into tonight's initial raid group.",
   ["ann-guild-raid-invite-10-msg"]            = "---------------------------------------------------------",

   ["ann-guild-wait-list-title"]               = "2 - Raid Queue Open",
   ["ann-guild-wait-list-descr"]               = "Announce that the raid queue is open.", 

   ["ann-guild-wait-list-officer-descr"]       = "Members should whisper the named officer to join the queue.",
      
   ["ann-guild-wait-list-01-msg"]              = "------------------------------------------------------------",
   ["ann-guild-wait-list-02-msg"]              = " Raid Queue / Wait List:",
   ["ann-guild-wait-list-03-msg"]              = "------------------------------------------------------------",
   ["ann-guild-wait-list-04-msg"]              = " The raid invitation period is now closed",
   ["ann-guild-wait-list-05-msg"]              = " ",
   ["ann-guild-wait-list-06-msg"]              = " To join the raid queue/wait-list, simply",
   ["ann-guild-wait-list-07-msg"]              = " whisper one of the following commands to",
   ["ann-guild-wait-list-08-msg"]              = " the raid queue officer.",
   ["ann-guild-wait-list-09-msg"]              = " ",
   ["ann-guild-wait-list-10-msg"]              = " 'wl add' - adds your name to the queue.",
   ["ann-guild-wait-list-11-msg"]              = " 'wl who' - see who else is queued.",
   ["ann-guild-wait-list-12-msg"]              = " ",
   ["ann-guild-wait-list-13-msg"]              = " Tonight's raid queue officer is...",
   ["ann-guild-wait-list-14-msg"]              = " ",
   ["ann-guild-wait-list-15-msg"]              = " ",
   ["ann-guild-wait-list-16-msg"]              = "------------------------------------------------------------",
   
   ["ann-guild-new-trial-title"]               = "3 - Welcome New Trial Member", 
   ["ann-guild-new-trial-descr"]               = "Warns guild members to prepare to welcome a new trial member.",
   ["ann-guild-new-trial-01-msg"]              = "---------------------------------------------------------",
   ["ann-guild-new-trial-02-msg"]              = " Guild Announcement:",
   ["ann-guild-new-trial-03-msg"]              = "---------------------------------------------------------",
   ["ann-guild-new-trial-04-msg"]              = " ",
   ["ann-guild-new-trial-05-msg"]              = " Ladies and Gentlemen. Please ready",
   ["ann-guild-new-trial-06-msg"]              = " yourselves to give a warm Converge",
   ["ann-guild-new-trial-07-msg"]              = " welcome to a new Trial Member who",
   ["ann-guild-new-trial-08-msg"]              = " will be joining the guild in just",
   ["ann-guild-new-trial-09-msg"]              = " a few moments.",
   ["ann-guild-new-trial-10-msg"]              = " ",
   ["ann-guild-new-trial-11-msg"]              = "---------------------------------------------------------",

   ["ann-guild-new-alt-title"]                 = "4 - Welcome New Alt Member", 
   ["ann-guild-new-alt-descr"]                 = "Warns guild members to prepare to welcome a new alt member.", 
   ["ann-guild-new-alt-01-msg"]                = "---------------------------------------------------------",
   ["ann-guild-new-alt-02-msg"]                = " Guild Announcement:",
   ["ann-guild-new-alt-03-msg"]                = "---------------------------------------------------------",
   ["ann-guild-new-alt-04-msg"]                = " ",
   ["ann-guild-new-alt-05-msg"]                = " Ladies and Gentlemen. Please ready",
   ["ann-guild-new-alt-06-msg"]                = " yourselves to give a warm Converge",
   ["ann-guild-new-alt-07-msg"]                = " welcome to a new Alt Member who",
   ["ann-guild-new-alt-08-msg"]                = " will be joining the guild in just",
   ["ann-guild-new-alt-09-msg"]                = " a few moments.",
   ["ann-guild-new-alt-10-msg"]                = " ",
   ["ann-guild-new-alt-11-msg"]                = "---------------------------------------------------------",   

   ["ann-guild-trial-ended-title"]             = "5 - Removing Failed Trial Member/s", 
   ["ann-guild-trial-ended-descr"]             = "Warns guild members that some guild removals are about to occur.", 
   ["ann-guild-trial-ended-01-msg"]            = "---------------------------------------------------------",
   ["ann-guild-trial-ended-02-msg"]            = " Guild Announcement:",
   ["ann-guild-trial-ended-03-msg"]            = "---------------------------------------------------------",
   ["ann-guild-trial-ended-04-msg"]            = " ",
   ["ann-guild-trial-ended-05-msg"]            = " One or more trial members that have",
   ["ann-guild-trial-ended-06-msg"]            = " failed their trial period will shortly",
   ["ann-guild-trial-ended-07-msg"]            = " be removed from the guild roster.",
   ["ann-guild-trial-ended-08-msg"]            = " ",
   ["ann-guild-trial-ended-09-msg"]            = " No drama, no fuss, nothing to see here.",
   ["ann-guild-trial-ended-10-msg"]            = " ",
   ["ann-guild-trial-ended-11-msg"]            = "---------------------------------------------------------",   

   ["ann-guild-promote-title"]                 = "6 - Congratulating Member Promotion", 
   ["ann-guild-promote-descr"]                 = "Warns guild members to prepare to congratulate an Initiate being promoted to full membership status.", 
   ["ann-guild-promote-01-msg"]                = "---------------------------------------------------------",
   ["ann-guild-promote-02-msg"]                = " Guild Announcement:",
   ["ann-guild-promote-03-msg"]                = "---------------------------------------------------------",
   ["ann-guild-promote-04-msg"]                = " ",
   ["ann-guild-promote-05-msg"]                = " Ladies and Gentlemen. Please ready",
   ["ann-guild-promote-06-msg"]                = " yourselves to congratulate the",
   ["ann-guild-promote-07-msg"]                = " latest member/s to have passed their",
   ["ann-guild-promote-08-msg"]                = " trial period and who are about to be",
   ["ann-guild-promote-09-msg"]                = " promoted to full Normal Member status.",
   ["ann-guild-promote-10-msg"]                = " ",
   ["ann-guild-promote-11-msg"]                = "---------------------------------------------------------",      

   ["ann-guild-reg-keyword-title"]             = "7 - Forum Registration Keyword", 
   ["ann-guild-reg-keyword-descr"]             = "Informs a new guild member about the special registration keyword required to create a new account on the forums.", 
   ["ann-guild-reg-keyword-01-msg"]            = "---------------------------------------------------------",
   ["ann-guild-reg-keyword-02-msg"]            = " On behalf of the officers and members of Converge",
   ["ann-guild-reg-keyword-03-msg"]            = " welcome to the guild! One of the first jobs you",
   ["ann-guild-reg-keyword-04-msg"]            = " will need to do is register on our forums.",
   ["ann-guild-reg-keyword-05-msg"]            = " ",
   ["ann-guild-reg-keyword-06-msg"]            = " Use your in-game name for your username and to",
   ["ann-guild-reg-keyword-07-msg"]            = " get past the anti-spam feature, use the keyword",
   ["ann-guild-reg-keyword-08-msg"]            = " 'Onyxia' in both boxes on the registration form.",
   ["ann-guild-reg-keyword-09-msg"]            = "---------------------------------------------------------",

   ["ann-common-kill-order-title"]             = "3 - Target Kill Order",
   ["ann-common-kill-order-descr"]             = "Announce the Target Kill Order",
   ["ann-common-kill-order-01-msg"]            = "---------------------------------------------------------",
   ["ann-common-kill-order-02-msg"]            = " Target Kill Order:",
   ["ann-common-kill-order-03-msg"]            = "---------------------------------------------------------",
   ["ann-common-kill-order-04-msg"]            = " 1 - {skull} - Skull",
   ["ann-common-kill-order-05-msg"]            = " 2 - {cross} - Cross",
   ["ann-common-kill-order-06-msg"]            = " 3 - {square} - Square. [Also: Ice Cube]",
   ["ann-common-kill-order-07-msg"]            = " 4 - {moon} - Moon",
   ["ann-common-kill-order-08-msg"]            = " 5 - {triangle} - Triangle. [Also: Toblerone]",
   ["ann-common-kill-order-09-msg"]            = " 6 - {diamond} - Diamond. [Also: Dildo]",
   ["ann-common-kill-order-10-msg"]            = " 7 - {circle} - Circle - [Also: Nipple]",
   ["ann-common-kill-order-11-msg"]            = " 8 - {star} - Star",
   ["ann-common-kill-order-12-msg"]            = "---------------------------------------------------------",

   ["ann-common-ventrilo-title"]               = "5 - Ventrilo Server Details",
   ["ann-common-ventrilo-descr"]               = "Announce the Guild's Ventrilo Server Details.",
   ["ann-common-ventrilo-01-msg"]              = "---------------------------------------------------------",
   ["ann-common-ventrilo-02-msg"]              = " Ventrilo Server Details:",
   ["ann-common-ventrilo-03-msg"]              = "---------------------------------------------------------",
   ["ann-common-ventrilo-04-msg"]              = " Please join our Ventrilo server",
   ["ann-common-ventrilo-05-msg"]              = " which you can access with the",
   ["ann-common-ventrilo-06-msg"]              = " following details:",
   ["ann-common-ventrilo-07-msg"]              = " ",
   ["ann-common-ventrilo-08-msg"]              = " Host: 82.195.158.141",
   ["ann-common-ventrilo-09-msg"]              = " Port: 3790",
   ["ann-common-ventrilo-10-msg"]              = " User: <not required>",
   ["ann-common-ventrilo-11-msg"]              = " Pass: password",
   ["ann-common-ventrilo-12-msg"]              = " ",
   ["ann-common-ventrilo-13-msg"]              = " Please ensure your ventrilo name",
   ["ann-common-ventrilo-14-msg"]              = " matches your in-game name so we",      
   ["ann-common-ventrilo-15-msg"]              = " can recognise you!",   
   ["ann-common-ventrilo-16-msg"]              = "---------------------------------------------------------",
   
   ["ann-raid-raid-begin-title"]               = "1 - Raid Start / Continue", 
   ["ann-raid-raid-begin-descr"]               = "Announce that the raid is starting/continuing, warn people to buff up.", 
   ["ann-raid-raid-begin-01-msg"]              = "---------------------------------------------------------",
   ["ann-raid-raid-begin-02-msg"]              = " Raid Proceeding.",
   ["ann-raid-raid-begin-03-msg"]              = "---------------------------------------------------------",
   ["ann-raid-raid-begin-04-msg"]              = " The raid is about to proceed.",
   ["ann-raid-raid-begin-05-msg"]              = " ",
   ["ann-raid-raid-begin-06-msg"]              = " Please ensure that you maintain the",
   ["ann-raid-raid-begin-07-msg"]              = " following buffs AT ALL TIMES during",
   ["ann-raid-raid-begin-08-msg"]              = " the raid.",
   ["ann-raid-raid-begin-09-msg"]              = " ",
   ["ann-raid-raid-begin-10-msg"]              = " 1x Flask OR 2x Elixirs",
   ["ann-raid-raid-begin-11-msg"]              = " 1x Food Buff",
   ["ann-raid-raid-begin-12-msg"]              = " ALL Weapons Buffed. (Oils/Stones)",
   ["ann-raid-raid-begin-13-msg"]              = "---------------------------------------------------------",
   ["ann-raid-raid-begin-14-msg"]              = "Buff up! - 1 Flask or 2 Elixirs, 1 Food Buff, All Weapons Buffed - AT ALL TIMES!",
   
   ["ann-raid-raid-end-title"]                 = "2 - Raid End - Thanks", 
   ["ann-raid-raid-end-descr"]                 = "Announce the end of today's raid, thanking all, in RAID_WARNING channel.", 
   ["ann-raid-raid-end-01-msg"]                = "---------------------------------------------------------",
   ["ann-raid-raid-end-02-msg"]                = " Raid End.",
   ["ann-raid-raid-end-03-msg"]                = "---------------------------------------------------------",
   ["ann-raid-raid-end-04-msg"]                = " Thank you all for coming tonight.",
   ["ann-raid-raid-end-05-msg"]                = " ",
   ["ann-raid-raid-end-06-msg"]                = " We look forward to seeing you all",
   ["ann-raid-raid-end-07-msg"]                = " again soon on the next raid. Don't",
   ["ann-raid-raid-end-08-msg"]                = " forget to sign-up!",
   ["ann-raid-raid-end-09-msg"]                = " ",
   ["ann-raid-raid-end-10-msg"]                = " And until next time...",
   ["ann-raid-raid-end-11-msg"]                = " ",
   ["ann-raid-raid-end-12-msg"]                = " GAME OVER MAN, GAME OVER!",
   ["ann-raid-raid-end-13-msg"]                = "---------------------------------------------------------",
   
   ["ann-common-looting-order-title"]          = "4 - Rank Based Priority Order",
   ["ann-common-looting-order-descr"]          = "Announce the rank based priority order.",
   ["ann-common-looting-order-01-msg"]         = "---------------------------------------------------------",
   ["ann-common-looting-order-02-msg"]         = " Rank Based Priority Order",
   ["ann-common-looting-order-03-msg"]         = "---------------------------------------------------------",
   ["ann-common-looting-order-04-msg"]         = " 1 - Guild Master/Officer/Hero Member",
   ["ann-common-looting-order-05-msg"]         = " 2 - * [Requested Alt-Officer/Alt-Hero]",
   ["ann-common-looting-order-06-msg"]         = " 3 - Normal Member",
   ["ann-common-looting-order-07-msg"]         = " 4 - * [Requested Alt-Normal]",
   ["ann-common-looting-order-08-msg"]         = " 5 - Trial Member",
   ["ann-common-looting-order-09-msg"]         = " 6 - * [Requested Alt-Trial]",
   ["ann-common-looting-order-10-msg"]         = " 7 - Alt-Officer/Alt-Hero",
   ["ann-common-looting-order-11-msg"]         = " 8 - Alt-Normal ",
   ["ann-common-looting-order-12-msg"]         = " 9 - Alt-Trial",
   ["ann-common-looting-order-13-msg"]         = "---------------------------------------------------------",
   ["ann-common-looting-order-14-msg"]         = " Bid Types: Main > Resist > Off",
   ["ann-common-looting-order-15-msg"]         = "---------------------------------------------------------",      

   ["ann-common-promotion-quest-txt-01-msg"]   = "---------------------------------------------------------",
   ["ann-common-promotion-quest-txt-02-msg"]   = " Trial Member Promotion Quest:",
   ["ann-common-promotion-quest-txt-03-msg"]   = "---------------------------------------------------------",
   ["ann-common-promotion-quest-txt-04-msg"]   = " ",
   ["ann-common-promotion-quest-txt-05-msg"]   = "---------------------------------------------------------",

   ["ann-raid-quest-title"]                    = "6 - Promotion Quests",
   ["ann-raid-quest-descr"]                    = "Get a trial member to /roll 20 and then give them the corresponding quest.",
   
   ["ann-common-promotion-quest-descr"]        = "Details of the selected trial member promotion quest.",

   ["ann-common-promotion-quest-01-title"]     = "01 - Cleanliness...",
   ["ann-common-promotion-quest-01-01-msg"]    = " Quest 1: 'Cleanliness is next to...'",
   ["ann-common-promotion-quest-01-02-msg"]    = " There's a nasty smell in the officer HQ.",
   ["ann-common-promotion-quest-01-03-msg"]    = " Go find a [Soap on a Rope] and present",
   ["ann-common-promotion-quest-01-04-msg"]    = " it to the smelliest officer you can find.",
   
   ["ann-common-promotion-quest-02-title"]     = "02 - Now, That's A Knife!",
   ["ann-common-promotion-quest-02-01-msg"]    = " Quest 2: 'Now, That's A Knife!'",
   ["ann-common-promotion-quest-02-02-msg"]    = " Locate a [Blacksteel Throwing Dagger]",
   ["ann-common-promotion-quest-02-03-msg"]    = " and go convince an officer to let you",
   ["ann-common-promotion-quest-02-04-msg"]    = " pass your trial. 'Now, That's A Knife!'",
   
   ["ann-common-promotion-quest-03-title"]     = "03 - Hello Thrall!",
   ["ann-common-promotion-quest-03-01-msg"]    = " Quest 03: 'Hello Thrall'",
   ["ann-common-promotion-quest-03-02-msg"]    = " Thrall has been talking smack about the",
   ["ann-common-promotion-quest-03-03-msg"]    = " guild. Give him what-for by taking a trip",
   ["ann-common-promotion-quest-03-04-msg"]    = " to Orgrimmar and go smack him back for us.",   
   
   ["ann-common-promotion-quest-04-title"]     = "04 - Officer Down",
   ["ann-common-promotion-quest-04-01-msg"]    = " Quest 4: 'Officer Down'",
   ["ann-common-promotion-quest-04-02-msg"]    = " Broliant has twisted his ankle just moments",
   ["ann-common-promotion-quest-04-03-msg"]    = " before the big Morris Dancing competition.",
   ["ann-common-promotion-quest-04-04-msg"]    = " Hurry, he needs a [Minor healing potion] now!",
      
   ["ann-common-promotion-quest-05-title"]     = "05 - Rabbit Foot",
   ["ann-common-promotion-quest-05-01-msg"]    = " Quest 5: 'Me Lucky Rabbit's Foot'",
   ["ann-common-promotion-quest-05-02-msg"]    = " Find a [Lucky Rabbit's Foot] for the",
   ["ann-common-promotion-quest-05-03-msg"]    = " officer whose luck you pity most.",
   ["ann-common-promotion-quest-05-04-msg"]    = " Go ahead, make their day.",
   
   ["ann-common-promotion-quest-06-title"]     = "06 - Cockroach",
   ["ann-common-promotion-quest-06-01-msg"]    = " Quest 6: 'A crunchy filling.'",
   ["ann-common-promotion-quest-06-02-msg"]    = " I'm looking for a crunchy filling for my",
   ["ann-common-promotion-quest-06-03-msg"]    = " sandwich. Fetch me a [Cockroach] please",
   ["ann-common-promotion-quest-06-04-msg"]    = " so I can have a proper meaty lunch!",
   
   ["ann-common-promotion-quest-07-title"]     = "07 - Crimson Snake",
   ["ann-common-promotion-quest-07-01-msg"]    = " Quest 7: 'Crimson snake'",
   ["ann-common-promotion-quest-07-02-msg"]    = " Granny 'Blade wants to make some soup.",
   ["ann-common-promotion-quest-07-03-msg"]    = " Find a fresh [Crimson Snake] and pass",
   ["ann-common-promotion-quest-07-04-msg"]    = " it to Lyam or another officer please.",
   
   ["ann-common-promotion-quest-08-title"]     = "08 - I Luvsh You I Do!",
   ["ann-common-promotion-quest-08-01-msg"]    = " Quest 8: 'I Luvsh You I Do!'",
   ["ann-common-promotion-quest-08-02-msg"]    = " Hey baby, hic! I luvsh you I do.",
   ["ann-common-promotion-quest-08-03-msg"]    = " Get me a [Bottle of Pinot Noir]",
   ["ann-common-promotion-quest-08-04-msg"]    = " and I'll show you how much, hic!",
   
   ["ann-common-promotion-quest-09-title"]     = "09 - All At Sea...",
   ["ann-common-promotion-quest-09-01-msg"]    = " Quest 9: 'All At Sea...'",
   ["ann-common-promotion-quest-09-02-msg"]    = " The navy are shipping me off to",
   ["ann-common-promotion-quest-09-03-msg"]    = " Ratchet. Grant an old sailor one",
   ["ann-common-promotion-quest-09-04-msg"]    = " last wish with a [Jug of Bourbon].",

   ["ann-common-promotion-quest-10-title"]     = "10 - Back To The Future...",
   ["ann-common-promotion-quest-10-01-msg"]    = " Quest 10: 'Back To The Future...'",
   ["ann-common-promotion-quest-10-02-msg"]    = " I need to get back to the future",
   ["ann-common-promotion-quest-10-03-msg"]    = " and the flux capacitor won't work",
   ["ann-common-promotion-quest-10-04-msg"]    = " until you get me a [Warp Burger]!",
   
   ["ann-common-promotion-quest-11-title"]     = "11 - HQ Needs Cleaning",
   ["ann-common-promotion-quest-11-01-msg"]    = " Quest 11: 'HQ Needs Cleaning'",
   ["ann-common-promotion-quest-11-02-msg"]    = " Officer HQ is a right mess. Go give",
   ["ann-common-promotion-quest-11-03-msg"]    = " it a really good clean. When you've",
   ["ann-common-promotion-quest-11-04-msg"]    = " finished, show us all the [Arcane Dust].",
   
   ["ann-common-promotion-quest-12-title"]     = "12 - Guild BBQ",
   ["ann-common-promotion-quest-12-01-msg"]    = " Quest 12: 'Guild BBQ'",
   ["ann-common-promotion-quest-12-02-msg"]    = " Our BBQ plans are in ruins. Somebody",
   ["ann-common-promotion-quest-12-03-msg"]    = " has burnt all the food. Quick, save the",
   ["ann-common-promotion-quest-12-04-msg"]    = " day, get us a [Blackened Basilisk]!",
   
   ["ann-common-promotion-quest-13-title"]     = "13 - Doctor In The House",
   ["ann-common-promotion-quest-13-01-msg"]    = " Quest 13: 'Doctor In The House'",
   ["ann-common-promotion-quest-13-02-msg"]    = " I know I shouldn't have juggled with",
   ["ann-common-promotion-quest-13-03-msg"]    = " my swords. To sew my arm back on, I'll",
   ["ann-common-promotion-quest-13-04-msg"]    = " need a copy of [Master First Aid]!",
   
   ["ann-common-promotion-quest-14-title"]     = "14 - Losing Their Marbles",
   ["ann-common-promotion-quest-14-01-msg"]    = " Quest 14: 'Losing Their Marbles'",
   ["ann-common-promotion-quest-14-02-msg"]    = " One of our officers is losing their",
   ["ann-common-promotion-quest-14-03-msg"]    = " marbles. Go find them in their",
   ["ann-common-promotion-quest-14-04-msg"]    = " wacked-out 'hidey' place. ",
   
   ["ann-common-promotion-quest-15-title"]     = "15 - Zircons Are Forever!",
   ["ann-common-promotion-quest-15-01-msg"]    = " Quest 15: 'Zircons Are Forever!'",
   ["ann-common-promotion-quest-15-02-msg"]    = " Before you propose, I need THE ring.",
   ["ann-common-promotion-quest-15-03-msg"]    = " Spare no expense, nothing less than",
   ["ann-common-promotion-quest-15-04-msg"]    = " a [Sparkling Zircon] will equal YES!",
   
   ["ann-common-promotion-quest-16-title"]     = "16 - Paraply It Forward...",
   ["ann-common-promotion-quest-16-01-msg"]    = " Quest 16: 'Paraply It Forward...'",
   ["ann-common-promotion-quest-16-02-msg"]    = " We can learn much from the loveable",
   ["ann-common-promotion-quest-16-03-msg"]    = " huggable dwarfs. Show how much you",
   ["ann-common-promotion-quest-16-04-msg"]    = " want in by giving your officer a hug.",
   
   ["ann-common-promotion-quest-17-title"]     = "17 - Share The Moment!",
   ["ann-common-promotion-quest-17-01-msg"]    = " Quest 17: 'Share The Moment!'",
   ["ann-common-promotion-quest-17-02-msg"]    = " Buy enough alcohol, then get the",
   ["ann-common-promotion-quest-17-03-msg"]    = " entire raid drunk. That way nobody",
   ["ann-common-promotion-quest-17-04-msg"]    = " will object if we promote you!",
   
   ["ann-common-promotion-quest-18-title"]     = "18 - The Mule",
   ["ann-common-promotion-quest-18-01-msg"]    = " Quest 18: 'The Mule'",
   ["ann-common-promotion-quest-18-02-msg"]    = " Take the 'package' from Banasea to",
   ["ann-common-promotion-quest-18-03-msg"]    = " Broliant. If either are not online,",
   ["ann-common-promotion-quest-18-04-msg"]    = " they've been arrested and you win!",
   
   ["ann-common-promotion-quest-19-title"]     = "19 - The Water Works",
   ["ann-common-promotion-quest-19-01-msg"]    = " Quest 19: 'The Water Works'",
   ["ann-common-promotion-quest-19-02-msg"]    = " Look, we're not letting you in no",
   ["ann-common-promotion-quest-19-03-msg"]    = " matter how much you beg. Well,",
   ["ann-common-promotion-quest-19-04-msg"]    = " maybe there's a small chance...",
   
   ["ann-common-promotion-quest-20-title"]     = "20 - Yo-Ho-Ho",
   ["ann-common-promotion-quest-20-01-msg"]    = " Quest 20: 'Yo-Ho-Ho!'",
   ["ann-common-promotion-quest-20-02-msg"]    = " Grab me a [Skin of Sweet Rum]",
   ["ann-common-promotion-quest-20-03-msg"]    = " and I'll create a diversion.",                                                   
   ["ann-common-promotion-quest-20-04-msg"]    = " so we can promote you!",
        
   ["ann-say-threat-title"]                    = "Winning on threat", 
   ["ann-say-threat-descr"]                    = "Say this message in the /say chat channel.", 
   ["ann-say-threat-msg"]                      = "I'm winning on threat!", 

   ["ann-say-evasion-title"]                   = "Evasion LoL", 
   ["ann-say-evasion-descr"]                   = "Say this message in the /say chat channel.", 
   ["ann-say-evasion-msg"]                     = "Evasion LoL!",
      
   ["ann-say-granny-title"]                    = "Lyam's Granny", 
   ["ann-say-granny-descr"]                    = "Say this message in the /say chat channel.", 
   ["ann-say-granny-msg"]                      = "Time to up the DPS, Lyam's granny is catching me!",
         
   ["ann-say-fireball-title"]                  = "Chargin' ma Fireball!", 
   ["ann-say-fireball-descr"]                  = "Say this message in the /say chat channel.", 
   ["ann-say-fireball-msg"]                    = "I'm a' chargin' ma fireball!",
         
   ["chat-join-title"]                         = "1 - Join a guild chat channel ",
   ["chat-join-descr"]                         = "Join one of the guild's custom chat channels.",
   
   ["chat-leave-title"]                        = "2 - Leave a guild chat channel",   
   ["chat-leave-descr"]                        = "Leave one of the guild's custom chat channels.",  

   ["chat-who-title"]                          = "3 - List members in a channel.",   
   ["chat-who-descr"]                          = "List who is currently in a guild custom chat channel.",  

   ["chat-condknight-title"]                   = "condknight", 
   ["chat-condknight-descr"]                   = "The dedicated guild chat channel for death knight characters.",
   
   ["chat-condruid-title"]                     = "condruid", 
   ["chat-condruid-descr"]                     = "The dedicated guild chat channel for druid characters.", 

   ["chat-conhunter-title"]                    = "conhunter", 
   ["chat-conhunter-descr"]                    = "The dedicated guild chat channel for hunter characters.", 

   ["chat-conmage-title"]                      = "conmage", 
   ["chat-conmage-descr"]                      = "The dedicated guild chat channel for mage characters.", 

   ["chat-conpaladin-title"]                   = "conpaladin", 
   ["chat-conpaladin-descr"]                   = "The dedicated guild chat channel for paladin characters.", 

   ["chat-conpriest-title"]                    = "conpriest", 
   ["chat-conpriest-descr"]                    = "The dedicated guild chat channel for priest characters.", 

   ["chat-conrogue-title"]                     = "conrogue", 
   ["chat-conrogue-descr"]                     = "The dedicated guild chat channel for rogue characters.", 

   ["chat-conshaman-title"]                    = "conshaman", 
   ["chat-conshaman-descr"]                    = "The dedicated guild chat channel for shaman characters.", 

   ["chat-contank-title"]                      = "contank", 
   ["chat-contank-descr"]                      = "The dedicated guild chat channel for tank characters.",
   
   ["chat-conlock-title"]                      = "conlock", 
   ["chat-conlock-descr"]                      = "The dedicated guild chat channel for warlock characters.", 

   ["chat-conwarrior-title"]                   = "conwarrior", 
   ["chat-conwarrior-descr"]                   = "The dedicated guild chat channel for warrior characters.", 

   ["chat-conhealer-title"]                    = "conhealer", 
   ["chat-conhealer-descr"]                    = "The dedicated guild chat channel for healer characters.", 

   ["chat-list-title"]                         = "4 - List Chat Channels",   
   ["chat-list-descr"]                         = "List the chat channels you are currently in.", 
       
   ["chat-announce-title"]                     = "5 - Announce Custom Channels",   
   ["chat-announce-descr"]                     = "Announce the guild's custom chat channels in raid-chat.", 
   
   ["chat-announce-01-msg"]                    = "---------------------------------------------------------",
   ["chat-announce-02-msg"]                    = " Converge Custom Channels:",
   ["chat-announce-03-msg"]                    = "---------------------------------------------------------",
   ["chat-announce-04-msg"]                    = " Please join one or more of our",
   ["chat-announce-05-msg"]                    = " custom chat channels as appropriate",
   ["chat-announce-06-msg"]                    = " to your class and role in the raid.",
   ["chat-announce-07-msg"]                    = " ",
   ["chat-announce-08-msg"]                    = " Channel List:",
   ["chat-announce-09-msg"]                    = " ",
   ["chat-announce-10-msg"]                    = " condruid, conhunter, conmage",
   ["chat-announce-11-msg"]                    = " conpaladin, conpriest, conrogue",
   ["chat-announce-12-msg"]                    = " conshaman, conlock, conwarrior",
   ["chat-announce-13-msg"]                    = " conhealer, contank, condknight",   
   ["chat-announce-14-msg"]                    = "---------------------------------------------------------",

   ["addon-ra-title"]                          = "Raid Assist (oRA2/CTRA)",
   ["addon-ra-descr"]                          = "Addon options for oRA2 and CTRA",

   ["addon-ra-ready-title"]                    = "1 - Ready Check",
   ["addon-ra-ready-descr"]                    = "Perform a ready check.",

   ["addon-ra-dura-title"]                     = "2 - Durability Check",
   ["addon-ra-dura-descr"]                     = "Perform a durability check.",
   
   ["addon-ra-resist-title"]                   = "3 - Resistance Check",
   ["addon-ra-resist-descr"]                   = "Perform a resistance check.",

   ["addon-ra-item-title"]                     = "4 - Item Check",
   ["addon-ra-item-descr"]                     = "How to perform an item check.",
   ["addon-ra-item-01-msg"]                    = "---------------------------------------------------------",
   ["addon-ra-item-02-msg"]                    = " Raid Item Checks.",
   ["addon-ra-item-03-msg"]                    = "---------------------------------------------------------",
   ["addon-ra-item-04-msg"]                    = " When in a raid, you can perform an",
   ["addon-ra-item-05-msg"]                    = " item check if you are promoted to",
   ["addon-ra-item-06-msg"]                    = " raid assistant/leader by doing one",
   ["addon-ra-item-07-msg"]                    = " of the following commands:",
   ["addon-ra-item-08-msg"]                    = " ",
   ["addon-ra-item-09-msg"]                    = " /raitem [item-link]",
   ["addon-ra-item-10-msg"]                    = " /raitem item-name",
   ["addon-ra-item-11-msg"]                    = "---------------------------------------------------------",

   ["addon-ra-version-title"]                  = "5 - Version Check",
   ["addon-ra-version-descr"]                  = "Perform a version check.",            

   ["addon-dbm-title"]                         = "Deadly Bossmods",
   ["addon-dbm-descr"]                         = "Addon options for Deadly Bossmods",

   ["addon-dbm-timer-bio-03m-title"]           = "1 - Bio-Break Timer - 3m", 
   ["addon-dbm-timer-bio-03m-descr"]           = "Countdown until end of bio-break.",
   ["addon-dbm-timer-bio-03m-msg"]             = "*** Bio-break: 3 Minutes. ***",
   
   ["addon-dbm-timer-bio-05m-title"]           = "2 - Bio-Break Timer - 5m", 
   ["addon-dbm-timer-bio-05m-descr"]           = "Countdown until end of bio-break.",
   ["addon-dbm-timer-bio-05m-msg"]             = "*** Bio-break: 5 Minutes. ***",
   
   ["addon-dbm-timer-raid-start-05m-title"]    = "3 - Raid Start Timer - 5m", 
   ["addon-dbm-timer-raid-start-05m-descr"]    = "Countdown to raid start time.",

   ["addon-dbm-timer-raid-start-10m-title"]    = "4 - Raid Start Timer - 10m", 
   ["addon-dbm-timer-raid-start-10m-descr"]    = "Countdown to raid start time.",

   ["addon-dbm-timer-raid-start-15m-title"]    = "5 - Raid Start Timer - 15m", 
   ["addon-dbm-timer-raid-start-15m-descr"]    = "Countdown to raid start time.",

   ["addon-dbm-timer-raid-start-msg"]          = "*** Raid begins in... ***",

   ["addon-dbm-timer-pull-quiet-05s-title"]    = "6 - Pull Timer - Quiet - 5s", 
   ["addon-dbm-timer-pull-quiet-05s-descr"]    = "Countdown to pull, quietly.",

   ["addon-dbm-timer-pull-quiet-10s-title"]    = "7 - Pull Timer - Quiet - 10s", 
   ["addon-dbm-timer-pull-quiet-10s-descr"]    = "Countdown to pull, quietly.",
   
   ["addon-dbm-timer-pull-loud-05s-title"]     = "8 - Pull Timer - Loud - 5s", 
   ["addon-dbm-timer-pull-loud-05s-descr"]     = "Countdown to pull, with sound and raid-warnings.",

   ["addon-dbm-timer-pull-loud-10s-title"]     = "9 - Pull Timer - Loud - 10s", 
   ["addon-dbm-timer-pull-loud-10s-descr"]     = "Countdown to pull, with sound and raid-warnings.",

   ["addon-dbm-timer-pull-msg"]                = "Incoming Pull",

   ["addon-dbm-unlock-title"]                  = "A - Unlock Bars", 
   ["addon-dbm-unlock-descr"]                  = "Unlock the DBM timer bars to move them around your screen.",

   ["addon-dbm-stop-title"]                    = "B - Stop All Timers",
   ["addon-dbm-stop-descr"]                    = "Stop all running timers and broadcast command to all raid members.", 
   
   ["addon-dbm-version-title"]                 = "C - Version Check",
   ["addon-dbm-version-descr"]                 = "Perform a version check.", 

   ["addon-omen-title"]                        = "Omen",
   ["addon-omen-descr"]                        = "Addon options for Omen",
   
   ["addon-omen-version-title"]                = "1 - Version Check",
   ["addon-omen-version-descr"]                = "Perform a version check.",
   
   ["addon-questhelper-title"]                 = "Questhelper",
   ["addon-questhelper-descr"]                 = "Addon options for Questhelper",       

   ["addon-questhelper-toggle-title"]          = "1 - Toggle Questhelper On/Off",
   ["addon-questhelper-toggle-descr"]          = "Toggle Questhelper on/off, useful when entering and exiting raids.",

   ["addon-raidbuffstatus-title"]              = "Raid Buff Status",
   ["addon-raidbuffstatus-descr"]              = "Addon options for Raid Buff Status",       

   ["addon-raidbuffstatus-toggle-title"]       = "1 - Show/Hide RBS Dashboard",
   ["addon-raidbuffstatus-toggle-descr"]       = "Show/Hide the RBS Dashboard window.",

   ["addon-raidbuffstatus-report-title"]       = "2 - Report Raid Buff Status",
   ["addon-raidbuffstatus-report-descr"]       = "Report the current raid buff status to the raid chat channel.",

   ["macro-karazhan-title"]                    = "1 - Karazhan",
   ["macro-karazhan-descr"]                    = "Macro/s for Karazhan.",
   
   ["macro-karazhan-curator-title"]            = "1 - The Curator",
   ["macro-karazhan-curator-descr"]            = "Macro to target the Astral Flare.",
   
   ["macro-karazhan-curator-link-title"]       = "1 - Link",
   ["macro-karazhan-curator-link-descr"]       = "Display the command to run this macro from the chat window.",

   ["macro-karazhan-curator-run-title"]        = "2 - Run",
   ["macro-karazhan-curator-run-descr"]        = "Run this macro.",

   ["macro-karazhan-curator-show-title"]       = "3 - Show",
   ["macro-karazhan-curator-show-descr"]       = "Show the code for this macro in the chat window.",

   ["macro-karazhan-curator-link-01-msg"]      = "---------------------------------------------------------",
   ["macro-karazhan-curator-link-02-msg"]      = " Macro - Karazhan - Curator.",
   ["macro-karazhan-curator-link-03-msg"]      = "---------------------------------------------------------",
   ["macro-karazhan-curator-link-04-msg"]      = " Use the following command to run",
   ["macro-karazhan-curator-link-05-msg"]      = " this macro from the chat window",
   ["macro-karazhan-curator-link-06-msg"]      = " or from your own macros:",
   ["macro-karazhan-curator-link-07-msg"]      = " ",
   ["macro-karazhan-curator-link-08-msg"]      = " /confu macro karazhan curator run",
   ["macro-karazhan-curator-link-09-msg"]      = " ",
   ["macro-karazhan-curator-link-10-msg"]      = "---------------------------------------------------------",
   
   ["macro-karazhan-curator-show-01-msg"]      = "---------------------------------------------------------",
   ["macro-karazhan-curator-show-02-msg"]      = " Macro - Karazhan - Curator.",
   ["macro-karazhan-curator-show-03-msg"]      = "---------------------------------------------------------",
   ["macro-karazhan-curator-show-04-msg"]      = " This macro consists of the following",
   ["macro-karazhan-curator-show-05-msg"]      = " script commands:",
   ["macro-karazhan-curator-show-06-msg"]      = " ",
   ["macro-karazhan-curator-show-07-msg"]      = " /target Astral Flare",
   ["macro-karazhan-curator-show-08-msg"]      = " ",   
   ["macro-karazhan-curator-show-09-msg"]      = "---------------------------------------------------------",
   
   ["macro-karazhan-illhoof-title"]            = "2 - Terestian Illhoof",
   ["macro-karazhan-illhoof-descr"]            = "Macro to target the Demon Chains.",
   
   ["macro-karazhan-illhoof-link-title"]       = "1 - Link",
   ["macro-karazhan-illhoof-link-descr"]       = "Display the command to run this macro from the chat window.",

   ["macro-karazhan-illhoof-run-title"]        = "2 - Run",
   ["macro-karazhan-illhoof-run-descr"]        = "Run this macro.",

   ["macro-karazhan-illhoof-show-title"]       = "3 - Show",
   ["macro-karazhan-illhoof-show-descr"]       = "Show the code for this macro in the chat window.",

   ["macro-karazhan-illhoof-link-01-msg"]      = "---------------------------------------------------------",
   ["macro-karazhan-illhoof-link-02-msg"]      = " Macro - Karazhan - Illhoof.",
   ["macro-karazhan-illhoof-link-03-msg"]      = "---------------------------------------------------------",
   ["macro-karazhan-illhoof-link-04-msg"]      = " Use the following command to run",
   ["macro-karazhan-illhoof-link-05-msg"]      = " this macro from the chat window",
   ["macro-karazhan-illhoof-link-06-msg"]      = " or from your own macros:",
   ["macro-karazhan-illhoof-link-07-msg"]      = " ",
   ["macro-karazhan-illhoof-link-08-msg"]      = " /confu macro karazhan illhoof run",
   ["macro-karazhan-illhoof-link-09-msg"]      = " ",
   ["macro-karazhan-illhoof-link-10-msg"]      = "---------------------------------------------------------",
   
   ["macro-karazhan-illhoof-show-01-msg"]      = "---------------------------------------------------------",
   ["macro-karazhan-illhoof-show-02-msg"]      = " Macro - Karazhan - Illhoof.",
   ["macro-karazhan-illhoof-show-03-msg"]      = "---------------------------------------------------------",
   ["macro-karazhan-illhoof-show-04-msg"]      = " This macro consists of the following",
   ["macro-karazhan-illhoof-show-05-msg"]      = " script commands:",
   ["macro-karazhan-illhoof-show-06-msg"]      = " ",
   ["macro-karazhan-illhoof-show-07-msg"]      = " /target Demon Chains",
   ["macro-karazhan-illhoof-show-08-msg"]      = " ",   
   ["macro-karazhan-illhoof-show-09-msg"]      = "---------------------------------------------------------",   

   ["macro-ssc-title"]                         = "2 - Serpentshrine Cavern",
   ["macro-ssc-descr"]                         = "Macro/s for Serpentshrine Cavern.",
   
   ["macro-ssc-karathress-title"]              = "1 - Fathomlord Karathress",
   ["macro-ssc-karathress-descr"]              = "Macro to target the Spitfire Totem.",
   
   ["macro-ssc-karathress-link-title"]         = "1 - Link",
   ["macro-ssc-karathress-link-descr"]         = "Display the command to run this macro from the chat window.",

   ["macro-ssc-karathress-run-title"]          = "2 - Run",
   ["macro-ssc-karathress-run-descr"]          = "Run this macro.",

   ["macro-ssc-karathress-show-title"]         = "3 - Show",
   ["macro-ssc-karathress-show-descr"]         = "Show the code for this macro in the chat window.",

   ["macro-ssc-karathress-link-01-msg"]        = "---------------------------------------------------------",
   ["macro-ssc-karathress-link-02-msg"]        = " Macro - SSC - Karathress.",
   ["macro-ssc-karathress-link-03-msg"]        = "---------------------------------------------------------",
   ["macro-ssc-karathress-link-04-msg"]        = " Use the following command to run",
   ["macro-ssc-karathress-link-05-msg"]        = " this macro from the chat window",
   ["macro-ssc-karathress-link-06-msg"]        = " or from your own macros:",
   ["macro-ssc-karathress-link-07-msg"]        = " ",
   ["macro-ssc-karathress-link-08-msg"]        = " /confu macro ssc karathress run",
   ["macro-ssc-karathress-link-09-msg"]        = " ",
   ["macro-ssc-karathress-link-10-msg"]        = "---------------------------------------------------------",
   
   ["macro-ssc-karathress-show-01-msg"]        = "---------------------------------------------------------",
   ["macro-ssc-karathress-show-02-msg"]        = " Macro - SSC - Karathress.",
   ["macro-ssc-karathress-show-03-msg"]        = "---------------------------------------------------------",
   ["macro-ssc-karathress-show-04-msg"]        = " This macro consists of the following",
   ["macro-ssc-karathress-show-05-msg"]        = " script commands:",
   ["macro-ssc-karathress-show-06-msg"]        = " ",
   ["macro-ssc-karathress-show-07-msg"]        = " /target Spitfire Totem",
   ["macro-ssc-karathress-show-08-msg"]        = " ",   
   ["macro-ssc-karathress-show-09-msg"]        = "---------------------------------------------------------",

   ["macro-ssc-vashj-title"]                   = "2 - Lady Vashj",
   ["macro-ssc-vashj-descr"]                   = "Macro to throw the Tainted Core and announce it.",
   
   ["macro-ssc-vashj-link-title"]              = "1 - Link",
   ["macro-ssc-vashj-link-descr"]              = "Display the command to run this macro from the chat window.",

   ["macro-ssc-vashj-run-title"]               = "2 - Run",
   ["macro-ssc-vashj-run-descr"]               = "Run this macro.",

   ["macro-ssc-vashj-show-title"]              = "3 - Show",
   ["macro-ssc-vashj-show-descr"]              = "Show the code for this macro in the chat window.",

   ["macro-ssc-vashj-link-01-msg"]             = "---------------------------------------------------------",
   ["macro-ssc-vashj-link-02-msg"]             = " Macro - SSC - Vashj.",
   ["macro-ssc-vashj-link-03-msg"]             = "---------------------------------------------------------",
   ["macro-ssc-vashj-link-04-msg"]             = " Use the following command to run",
   ["macro-ssc-vashj-link-05-msg"]             = " this macro from the chat window",
   ["macro-ssc-vashj-link-06-msg"]             = " or from your own macros:",
   ["macro-ssc-vashj-link-07-msg"]             = " ",
   ["macro-ssc-vashj-link-08-msg"]             = " /confu macro ssc vashj run",
   ["macro-ssc-vashj-link-09-msg"]             = " ",
   ["macro-ssc-vashj-link-10-msg"]             = "---------------------------------------------------------",
  
   ["macro-ssc-vashj-show-01-msg"]             = "---------------------------------------------------------",
   ["macro-ssc-vashj-show-02-msg"]             = " Macro - SSC - Vashj.",
   ["macro-ssc-vashj-show-03-msg"]             = "---------------------------------------------------------",
   ["macro-ssc-vashj-show-04-msg"]             = " This macro consists of the following",
   ["macro-ssc-vashj-show-05-msg"]             = " script commands:",
   ["macro-ssc-vashj-show-06-msg"]             = " ",
   ["macro-ssc-vashj-show-07-msg"]             = " /use Tainted Core",
   ["macro-ssc-vashj-show-08-msg"]             = " /y <------- TAINTED CORE TO: %t ! ! !",
   ["macro-ssc-vashj-show-09-msg"]             = " /s <------- TAINTED CORE TO: %t ! ! !",
   ["macro-ssc-vashj-show-10-msg"]             = " /script SendChatMessage(\"!!! YOU HAVE THE CORE !!!\", \"WHISPER\", nil, UnitName(\"target\"));",
   ["macro-ssc-vashj-show-11-msg"]             = " ",
   ["macro-ssc-vashj-show-12-msg"]             = "---------------------------------------------------------",

   ["macro-bt-title"]                          = "3 - Black Temple",
   ["macro-bt-descr"]                          = "Macro/s for Black Temple.",
   
   ["macro-bt-najentus-spine-title"]           = "1 - High Warlord Naj'entus - Spine",
   ["macro-bt-najentus-spine-descr"]           = "Macro to use a spine to burst Naj'entus' shield.",
   
   ["macro-bt-najentus-spine-link-title"]      = "1 - Link",
   ["macro-bt-najentus-spine-link-descr"]      = "Display the command to run this macro from the chat window.",

   ["macro-bt-najentus-spine-run-title"]       = "2 - Run",
   ["macro-bt-najentus-spine-run-descr"]       = "Run this macro.",

   ["macro-bt-najentus-spine-show-title"]      = "3 - Show",
   ["macro-bt-najentus-spine-show-descr"]      = "Show the code for this macro in the chat window.",

   ["macro-bt-najentus-spine-link-01-msg"]     = "---------------------------------------------------------",
   ["macro-bt-najentus-spine-link-02-msg"]     = " Macro - BT - Naj'entus.",
   ["macro-bt-najentus-spine-link-03-msg"]     = "---------------------------------------------------------",
   ["macro-bt-najentus-spine-link-04-msg"]     = " Use the following command to run",
   ["macro-bt-najentus-spine-link-05-msg"]     = " this macro from the chat window",
   ["macro-bt-najentus-spine-link-06-msg"]     = " or from your own macros:",
   ["macro-bt-najentus-spine-link-07-msg"]     = " ",
   ["macro-bt-najentus-spine-link-08-msg"]     = " /confu macro bt najentus_spine run",
   ["macro-bt-najentus-spine-link-09-msg"]     = " ",
   ["macro-bt-najentus-spine-link-10-msg"]     = "---------------------------------------------------------",
   
   ["macro-bt-najentus-spine-show-01-msg"]     = "---------------------------------------------------------",
   ["macro-bt-najentus-spine-show-02-msg"]     = " Macro - BT - Naj'entus.",
   ["macro-bt-najentus-spine-show-03-msg"]     = "---------------------------------------------------------",
   ["macro-bt-najentus-spine-show-04-msg"]     = " This macro consists of the following",
   ["macro-bt-najentus-spine-show-05-msg"]     = " script commands:",
   ["macro-bt-najentus-spine-show-06-msg"]     = " ",
   ["macro-bt-najentus-spine-show-07-msg"]     = " /use Naj'entus Spine",
   ["macro-bt-najentus-spine-show-08-msg"]     = " ",   
   ["macro-bt-najentus-spine-show-09-msg"]     = "---------------------------------------------------------",   

   ["macro-bt-najentus-hp-title"]              = "2 - High Warlord Naj'entus - HP",
   ["macro-bt-najentus-hp-descr"]              = "Macro to check for raid members with < 9500 HP before you fight.",
   
   ["macro-bt-najentus-hp-link-title"]         = "1 - Link",
   ["macro-bt-najentus-hp-link-descr"]         = "Display the command to run this macro from the chat window.",

   ["macro-bt-najentus-hp-run-title"]          = "2 - Run",
   ["macro-bt-najentus-hp-run-descr"]          = "Run this macro.",

   ["macro-bt-najentus-hp-show-title"]         = "3 - Show",
   ["macro-bt-najentus-hp-show-descr"]         = "Show the code for this macro in the chat window.",

   ["macro-bt-najentus-hp-link-01-msg"]        = "---------------------------------------------------------",
   ["macro-bt-najentus-hp-link-02-msg"]        = " Macro - BT - Naj'entus.",
   ["macro-bt-najentus-hp-link-03-msg"]        = "---------------------------------------------------------",
   ["macro-bt-najentus-hp-link-04-msg"]        = " Use the following command to run",
   ["macro-bt-najentus-hp-link-05-msg"]        = " this macro from the chat window",
   ["macro-bt-najentus-hp-link-06-msg"]        = " or from your own macros:",
   ["macro-bt-najentus-hp-link-07-msg"]        = " ",
   ["macro-bt-najentus-hp-link-08-msg"]        = " /confu macro bt najentus_hp run",
   ["macro-bt-najentus-hp-link-09-msg"]        = " ",
   ["macro-bt-najentus-hp-link-10-msg"]        = "---------------------------------------------------------",
   
   ["macro-bt-najentus-hp-show-01-msg"]        = "---------------------------------------------------------",
   ["macro-bt-najentus-hp-show-02-msg"]        = " Macro - BT - Naj'entus.",
   ["macro-bt-najentus-hp-show-03-msg"]        = "---------------------------------------------------------",
   ["macro-bt-najentus-hp-show-04-msg"]        = " This macro consists of the following",
   ["macro-bt-najentus-hp-show-05-msg"]        = " script commands:",
   ["macro-bt-najentus-hp-show-06-msg"]        = " ",
   ["macro-bt-najentus-hp-show-07-msg"]        = " /script",
   ["macro-bt-najentus-hp-show-08-msg"]        = " for i = 1, 40 do",
   ["macro-bt-najentus-hp-show-09-msg"]        = "   local u = \"raid\"..i;",
   ["macro-bt-najentus-hp-show-10-msg"]        = "   local hp = UnitHealthMax(u);",
   ["macro-bt-najentus-hp-show-11-msg"]        = "   local _, _, grp = GetRaidRosterInfo(i);",
   ["macro-bt-najentus-hp-show-12-msg"]        = "   if UnitExists(u) and hp < 9500 and grp <= 5 then",
   ["macro-bt-najentus-hp-show-13-msg"]        = "     ChatFrame1:AddMessage(UnitName(u)..\": \"..hp..\" HP\");",
   ["macro-bt-najentus-hp-show-14-msg"]        = "   end",
   ["macro-bt-najentus-hp-show-15-msg"]        = " end",
   ["macro-bt-najentus-hp-show-16-msg"]        = " ",   
   ["macro-bt-najentus-hp-show-17-msg"]        = "---------------------------------------------------------", 

   ["macro-bt-gorefiend-const-title"]          = "3 - Teron Gorefiend - Constructs",
   ["macro-bt-gorefiend-const-descr"]          = "Macros to use against the Shadowy Constructs.",
   
   ["macro-bt-gorefiend-const-link-title"]     = "1 - Link",
   ["macro-bt-gorefiend-const-link-descr"]     = "Display the command to run this macro from the chat window.",

   ["macro-bt-gorefiend-const-run-title"]      = "2 - Run",
   ["macro-bt-gorefiend-const-run-descr"]      = "Run this macro.",

   ["macro-bt-gorefiend-const-show-title"]     = "3 - Show",
   ["macro-bt-gorefiend-const-show-descr"]     = "Show the code for this macro in the chat window.",

   ["macro-bt-gorefiend-const-link-01-msg"]    = "---------------------------------------------------------",
   ["macro-bt-gorefiend-const-link-02-msg"]    = " Macro - BT - Gorefiend.",
   ["macro-bt-gorefiend-const-link-03-msg"]    = "---------------------------------------------------------",
   ["macro-bt-gorefiend-const-link-04-msg"]    = " These macros are not suitable to be",
   ["macro-bt-gorefiend-const-link-05-msg"]    = " run from ConvergeFu during combat.",
   ["macro-bt-gorefiend-const-link-06-msg"]    = "---------------------------------------------------------",

   ["macro-bt-gorefiend-const-run-01-msg"]     = "This macro is unsuitable for running from ConvergeFu.",

   ["macro-bt-gorefiend-const-show-01-msg"]    = "---------------------------------------------------------",
   ["macro-bt-gorefiend-const-show-02-msg"]    = " Macro - BT - Gorefiend.",
   ["macro-bt-gorefiend-const-show-03-msg"]    = "---------------------------------------------------------",
   ["macro-bt-gorefiend-const-show-04-msg"]    = " These 3 macros consist of the following",
   ["macro-bt-gorefiend-const-show-05-msg"]    = " script commands:",
   ["macro-bt-gorefiend-const-show-06-msg"]    = " ",
   ["macro-bt-gorefiend-const-show-07-msg"]    = " 1: /cast Spirit Volley",
   ["macro-bt-gorefiend-const-show-08-msg"]    = " 2: /cast Spirit Chains",
   ["macro-bt-gorefiend-const-show-09-msg"]    = " 3: /cast Spirit Lance",
   ["macro-bt-gorefiend-const-show-10-msg"]    = " ",
   ["macro-bt-gorefiend-const-show-11-msg"]    = "---------------------------------------------------------",

-- ============================================================================
-- == Tools - Main Menu =======================================================
-- ============================================================================

   ["tools-busy-responder-title"]              = "1 - Busy Responder",
   ["tools-busy-responder-descr"]              = "Auto-respond to whispers with a busy message with this tool.",

   ["tools-crowd-control-title"]               = "2 - Crowd Control",
   ["tools-crowd-control-descr"]               = "Setup targets for crowd-control responsibilities with this tool.",   

   ["tools-recruiter-title"]                   = "3 - Recruiter",
   ["tools-recruiter-descr"]                   = "Recruit new characters into the guild with these tools.",

   ["tools-searchtarget-title"]                = "4 - Character Search",
   ["tools-searchtarget-descr"]                = "Search for characters within the guild with these tools.",
   
   ["tools-rank-title"]                        = "5 - Rank Management",
   ["tools-rank-descr"]                        = "Manage the guild ranks with these tools. WARNING: These tools are under development and are therefore experimental. Use with extreme caution.",

   ["tools-misc-title"]                        = "6 - Miscellaneous",
   ["tools-misc-descr"]                        = "Perform miscellaneous tasks with these tools.",

   ["tools-versioncheck-title"]                = "7 - Version Check",
   ["tools-versioncheck-descr"]                = "Compare your version of ConvergeFu to that of your fellow guild-members with this tool.",

-- ============================================================================
-- == Tools - Busy Responder ==================================================
-- ============================================================================
   
   ["tools-busy-responder-status-title"]       = "1 - Enable/Disable Responder.",
   ["tools-busy-responder-status-descr"]       = "Switch the responder tool on or off.",
   ["tools-busy-responder-status-usage"]       = "Set to 'On' if you wish the responder to be active, or set to 'Off' otherwise.",
  
   ["tools-busy-responder-guild-title"]        = "2 - Respond to Guild Members.",
   ["tools-busy-responder-guild-descr"]        = "Choose whether the responder should respond to members of your guild.",
   ["tools-busy-responder-guild-usage"]        = "Set to 'On' if you wish the responder to be active for guild members, or set to 'Off' otherwise.",
  
   ["tools-busy-responder-officer-title"]      = "3 - Respond to Guild Officers.",
   ["tools-busy-responder-officer-descr"]      = "Choose whether the responder should respond to officers of your guild.",
   ["tools-busy-responder-officer-usage"]      = "Set to 'On' if you wish the responder to be active for guild officers, or set to 'Off' otherwise.",
  
   ["tools-busy-responder-party-title"]        = "4 - Respond to Party Members.",
   ["tools-busy-responder-party-descr"]        = "Choose whether the responder should respond to members of your party.",
   ["tools-busy-responder-party-usage"]        = "Set to 'On' if you wish the responder to be active for party members, or set to 'Off' otherwise.",
  
   ["tools-busy-responder-raid-title"]         = "5 - Respond to Raid Members.",
   ["tools-busy-responder-raid-descr"]         = "Choose whether the responder should respond to members of your raid.",
   ["tools-busy-responder-raid-usage"]         = "Set to 'On' if you wish the responder to be active for raid members, or set to 'Off' otherwise.",
      
   ["tools-busy-responder-friend-title"]       = "6 - Respond to Friends.",
   ["tools-busy-responder-friend-descr"]       = "Choose whether the responder should respond to members of your friends-list.",
   ["tools-busy-responder-friend-usage"]       = "Set to 'On' if you wish the responder to be active for friends-list members, or set to 'Off' otherwise.",
      
   ["tools-busy-responder-message-title"]      = "7 - Customise Message.",
   ["tools-busy-responder-message-descr"]      = "Customise the message sent by the responder.",
   ["tools-busy-responder-message-usage"]      = "Enter the new message and then press the return/enter key to save/confirm your changes.",
   ["tools-busy-responder-message-first"]      = "[BusyResponder] - ",
   ["tools-busy-responder-message-stdrd"]      = "Thank you for your message. Unfortunately, the recipient is unavailable to respond at this time but your message has been stored for later review. Whisper 'guildinfo' or visit www.converge-dh.com for more guild information.",

   ["tools-busy-responder-test-title"]         = "8 - Test Message.",
   ["tools-busy-responder-test-descr"]         = "Test the BusyResponder message by whispering it to yourself.",
   
   ["tools-busy-responder-reset-title"]        = "9 - Reset Message.",
   ["tools-busy-responder-reset-descr"]        = "Reset the message to the default message originally supplied with ConvergeFu.",
   
   ["tools-busy-responder-toggle-01-msg"]      = "BusyResponder is now: ",
   ["tools-busy-responder-toggle-02-msg"]      = "Exclusions: ",
   ["tools-busy-responder-toggle-03-msg"]      = "Guild: ",
   ["tools-busy-responder-toggle-04-msg"]      = ", Officer: ",
   ["tools-busy-responder-toggle-05-msg"]      = ", Party: ",
   ["tools-busy-responder-toggle-06-msg"]      = ", Raid: ",
   ["tools-busy-responder-toggle-07-msg"]      = ", Friend: ",
   
   ["tools-busy-responder-toggle-on"]          = "On",
   ["tools-busy-responder-toggle-off"]         = "Off",
   
-- ============================================================================
-- == Tools - Crowd Control ===================================================
-- ============================================================================

   ["tools-crowd-control-skull-title"]         = "1 - Skull",
   ["tools-crowd-control-skull-descr"]         = "Setup responsibilities for the Skull target.",
   
   ["tools-crowd-control-cross-title"]         = "2 - Cross",
   ["tools-crowd-control-cross-descr"]         = "Setup responsibilities for the Cross target.",
   
   ["tools-crowd-control-square-title"]        = "3 - Square",
   ["tools-crowd-control-square-descr"]        = "Setup responsibilities for the Square target.",
   
   ["tools-crowd-control-moon-title"]          = "4 - Moon",
   ["tools-crowd-control-moon-descr"]          = "Setup responsibilities for the Moon target.",
   
   ["tools-crowd-control-triangle-title"]      = "5 - Triangle",
   ["tools-crowd-control-triangle-descr"]      = "Setup responsibilities for the Triangle target.",
   
   ["tools-crowd-control-diamond-title"]       = "6 - Diamond",
   ["tools-crowd-control-diamond-descr"]       = "Setup responsibilities for the Diamond target.",
   
   ["tools-crowd-control-circle-title"]        = "7 - Circle",
   ["tools-crowd-control-circle-descr"]        = "Setup responsibilities for the Circle target.",
   
   ["tools-crowd-control-star-title"]          = "8 - Star",
   ["tools-crowd-control-star-descr"]          = "Setup responsibilities for the Star target.",   
   
   ["tools-crowd-control-announce-title"]      = "A - Announce",
   ["tools-crowd-control-announce-descr"]      = "Announce the crowd control targets to your current raid.",  
   
   ["tools-crowd-control-channel-title"]       = "E - Set Channel",
   ["tools-crowd-control-channel-descr"]       = "Set the output channel for the crowd control announcemnt.",
   ["tools-crowd-control-channel-usage"]       = "Choose the output channel by selecting one of the available options.",

   ["tools-crowd-control-test-title"]          = "B - Test Announce",
   ["tools-crowd-control-test-descr"]          = "Announce the crowd control targets to your chat window. IMPORTANT NOTE: The raid icons will not appear in this view but will appear in the proper announcement. This view will show {icon-name} in place of the icons.",
   
   ["tools-crowd-control-gui-title"]           = "D - Show FuBar Config GUI",
   ["tools-crowd-control-gui-descr"]           = "Show the FuBar GUI, if you prefer a GUI config. Then navigate (via top left selector) to the FuBar_ConvergeFu section, then Tools. Crowd Control Tool etc.",
   
   ["tools-crowd-control-clearall-title"]      = "C - Clear All",
   ["tools-crowd-control-clearall-descr"]      = "Clear all targets of their assigned character and crowd control type.",

   ["tools-crowd-control-common-type-title"]   = "2 - Set Type",
   ["tools-crowd-control-common-type-descr"]   = "Set the type of crowd control to be used on this target.",
   ["tools-crowd-control-common-type-usage"]   = "Choose the type of crowd control required for this target by selecting one of the available options or select 'None' if this target does not require crowd control.",

   ["tools-crowd-control-common-name-title"]   = "1 - Set Name",
   ["tools-crowd-control-common-name-descr"]   = "Set the name of the character responsible for this target.",
   ["tools-crowd-control-common-name-usage"]   = "To change the value of the character responsible for crowd controlling this target, simply type a new name into the box and then press return.",
   
   ["tools-crowd-control-common-clear-title"]  = "3 - Clear",
   ["tools-crowd-control-common-clear-descr"]  = "Clear this target of its assigned character and crowd control type.",
   
   ["tools-crowd-control-common-clear-type-default"] = "None",
   ["tools-crowd-control-common-clear-name-default"] = "",
   
   ["tools-crowd-control-announce-01-msg"]     = "---------------------------------------------------------",
   ["tools-crowd-control-announce-02-msg"]     = " Crowd Control Responsibilities:",
   ["tools-crowd-control-announce-03-msg"]     = "---------------------------------------------------------",
   ["tools-crowd-control-announce-04-msg"]     = " 1 - {skull} - ",
   ["tools-crowd-control-announce-05-msg"]     = " 2 - {cross} - ",
   ["tools-crowd-control-announce-06-msg"]     = " 3 - {square} - ",
   ["tools-crowd-control-announce-07-msg"]     = " 4 - {moon} - ",
   ["tools-crowd-control-announce-08-msg"]     = " 5 - {triangle} - ",
   ["tools-crowd-control-announce-09-msg"]     = " 6 - {diamond} - ",
   ["tools-crowd-control-announce-10-msg"]     = " 7 - {circle} - ",
   ["tools-crowd-control-announce-11-msg"]     = " 8 - {star} - ",
   ["tools-crowd-control-announce-12-msg"]     = " No targets setup, expect imminent chaos!",
   ["tools-crowd-control-announce-13-msg"]     = "---------------------------------------------------------",

-- ============================================================================
-- == Tools - Recruiter =======================================================
-- ============================================================================

   ["tools-recruiter-start-title"]             = "1 - Recruit Character",
   ["tools-recruiter-start-descr"]             = "Recruit a new character into the guild.",

   ["tools-recruiter-report-title"]            = "2 - Report Status",
   ["tools-recruiter-report-descr"]            = "Report the current status of the recruiter tool to your chat window.",
  
   ["tools-recruiter-reset-title"]             = "3 - Reset",
   ["tools-recruiter-reset-descr"]             = "Reset the recruiter tool to dormant status, clearing all properties in the process.",
     
   ["tools-recruiter-rank-main"]               = "Main",
   ["tools-recruiter-rank-alt"]                = "Alt",
   
   ["tools-recruiter-status-dormant"]          = "Dormant",
   ["tools-recruiter-status-getname"]          = "FetchingCharacterName",
   ["tools-recruiter-status-getrank"]          = "FetchingCharacterRank",
   ["tools-recruiter-status-getmain"]          = "FetchingCharacterMain",
   ["tools-recruiter-status-checkok"]          = "PendingConfirmation",
   ["tools-recruiter-status-confirm"]          = "FetchingConfirmation",
   ["tools-recruiter-status-recruit"]          = "RecruitingCharacter",
   
   ["tools-recruiter-window-getname"]          = "GET_RECRUIT_NAME",
   ["tools-recruiter-window-getrank"]          = "GET_RECRUIT_RANK",
   ["tools-recruiter-window-getmain"]          = "GET_RECRUIT_MAIN",
   ["tools-recruiter-window-getconf"]          = "GET_RECRUIT_CONF",
   ["tools-recruiter-window-getcont"]          = "GET_RECRUIT_CONT",
   ["tools-recruiter-window-waiting"]          = "GET_RECRUIT_WAIT",
   
   ["tools-recruiter-window-title-getname"]    = "Enter the name of the character to invite.",
   ["tools-recruiter-window-title-getrank"]    = "Select the rank-type for this recruit.",
   ["tools-recruiter-window-title-getmain"]    = "Enter the name of the recruit's main character.",

   ["tools-recruiter-window-title-getconf-01"] = "Confirmation: Invite ",
   ["tools-recruiter-window-title-getconf-02"] = " as a ",
   ["tools-recruiter-window-title-getconf-03"] = " as an ",
   ["tools-recruiter-window-title-getconf-04"] = " of ",
   
   ["tools-recruiter-window-title-getcont"]    = "Pausing 30 seconds before configuring new recruit to allow in-game roster tables to update.",
   ["tools-recruiter-window-title-waiting"]    = "Pausing briefly between each rank promotion, simulating human 'slowness'...",
   
   ["tools-recruiter-button-continue"]         = "Continue",
   ["tools-recruiter-button-cancel"]           = "Cancel",
   ["tools-recruiter-button-main"]             = "Main",
   ["tools-recruiter-button-alt"]              = "Alt",
   
   ["tools-recruiter-report-01-msg"]           = "The recruiter tool status is currently: ",
   ["tools-recruiter-report-02-msg"]           = "- Name: ",
   ["tools-recruiter-report-03-msg"]           = "- Rank: ",
   ["tools-recruiter-report-04-msg"]           = "- Main: ",
   ["tools-recruiter-report-05-msg"]           = "- Prom: ",
   
   ["tools-recruiter-tag"]                     = "[Recruiter]",
   ["tools-recruiter-commentary-01-msg"]       = "Sending a guild invitation to: ",
   
   ["tools-recruiter-getready-01-msg"]         = " ConvergeFu Recruiter",
   ["tools-recruiter-getready-02-msg"]         = " Please ready yourselves to give",
   ["tools-recruiter-getready-03-msg"]         = " a warm Converge welcome to",
   ["tools-recruiter-getready-04-msg"]         = " who will shortly be joining us as ",
   ["tools-recruiter-getready-05-msg"]         = " a new Trial Member.",
   ["tools-recruiter-getready-06-msg"]         = " an Alt of ",
   
   ["tools-recruiter-system-message"]          = " has joined the guild.",
   
   ["tools-recruiter-promoted-by-one"]         = "Recruit promoted by one rank.",
   ["tools-recruiter-num-promotions"]          = "Number of rank-promotions needed: ",
   
   ["tools-recruiter-set-note-officer-trial"]  = "Trial ",
   ["tools-recruiter-set-note-public"]         = "Setting public note field to: ",
   ["tools-recruiter-set-note-officer"]        = "Setting officer note field to: ",
   
   ["tools-recruiter-keyword-01-msg"]          = "[1 of 4] - Don't forget to register on our forums at www.converge-dh.com using your character-name as your user-name.",
   ["tools-recruiter-keyword-02-msg"]          = "[2 of 4] - To register, you'll need to enter our special keyword which is 'Onyxia' into two boxes on the registration form.",
   ["tools-recruiter-keyword-03-msg"]          = "[3 of 4] - Once registered, Broliant will activate it and then you can begin by reading all posts in the 'Reference Information' section.",
   ["tools-recruiter-keyword-04-msg"]          = "[4 of 4] - We hope you enjoy being a member of the guild. On behalf of the officer team, welcome to Converge!",
   
   ["tools-recruiter-all-done"]                = "New member recruitment process complete!",
   
-- ============================================================================
-- == Tools - Search ==========================================================
-- ============================================================================

   ["tools-searchtarget-set-title"]            = "1 - Search Target",
   ["tools-searchtarget-set-descr"]            = "Set the name of the character who will be the target for searches.",
   ["tools-searchtarget-set-usage"]            = "To change the value of the search target, simply type a new value into the box and then press return.",   

-- ============================================================================
   
   ["tools-searchtarget-findall-title"]        = "2 - Find All Associated Characters",
   ["tools-searchtarget-findall-descr"]        = "Find the 'main' and 'alt' characters associated with the current search target.",

-- ============================================================================   

   ["tools-searchtarget-findonline-title"]     = "3 - Find Online Status",
   ["tools-searchtarget-findonline-descr"]     = "Check to see if the search target is currently online and, if so, on which 'guilded' character.",
            
-- ============================================================================
-- == Tools - Rank Based ======================================================
-- ============================================================================
   
   ["tools-rank-officer-title"]                = "1 - Officer Rank Tools",
   ["tools-rank-officer-descr"]                = "Tools for managing various officer rank-based functions.",
   
   ["tools-rank-hero-title"]                   = "2 - Hero Rank Tools",
   ["tools-rank-hero-descr"]                   = "Tools for managing various hero rank-based functions.",
   
   ["tools-rank-normal-title"]                 = "3 - Normal Rank Tools",
   ["tools-rank-normal-descr"]                 = "Tools for managing various normal rank-based functions.",
   
   ["tools-rank-trial-title"]                  = "4 - Trial Rank Tools",
   ["tools-rank-trial-descr"]                  = "Tools for managing various trial rank-based functions.",
   
-- ============================================================================

   ["tools-rank-officer-listall-title"]        = "1 - List All Officers",
   ["tools-rank-officer-listall-descr"]        = "List all the officer-ranked 'main' characters.",
   
   ["tools-rank-officer-listall-01-msg"]       = " List of Officer Class Members:",
   
   ["tools-rank-officer-matchalts-title"]      = "2 - Match Alt-Ranks To Mains",
   ["tools-rank-officer-matchalts-descr"]      = "Run this tool ensure that all alt-ranked characters hold the alt-rank appropriate to their corresponding main character.",  
    
-- ============================================================================

   ["tools-rank-hero-listall-title"]           = "1 - List All Hero Members",
   ["tools-rank-hero-listall-descr"]           = "List all the hero-member-ranked 'main' characters.",
   
   ["tools-rank-hero-listall-01-msg"]          = " List of Hero Members:",
   
   ["tools-rank-hero-ann-changes-title"]       = "2 - Announce Changeover Start",
   ["tools-rank-hero-ann-changes-descr"]       = "Announce that the change-over process for hero/normal members is about to being. Message goes to the 'guild' chat channel.",  

   ["tools-rank-hero-demote-all-title"]        = "3 - Demote All Heroes",
   ["tools-rank-hero-demote-all-descr"]        = "Run this tool to demote all 'Hero Member' and 'Alt-Hero' characters to the 'Normal Member' and 'Alt-Normal' ranks respectively.",  

   ["tools-rank-hero-matchalts-title"]         = "4 - Match Alt-Ranks To Mains",
   ["tools-rank-hero-matchalts-descr"]         = "Run this tool ensure that all alt-ranked characters hold the alt-rank appropriate to their corresponding main character.",  

-- ============================================================================

   ["tools-rank-normal-listall-title"]         = "1 - List All Normal Members",
   ["tools-rank-normal-listall-descr"]         = "List all the normal-member-ranked 'main' characters.",
   
   ["tools-rank-normal-listall-01-msg"]        = " List of Normal Members:",
   
   ["tools-rank-normal-matchalts-title"]       = "2 - Match Alt-Ranks To Mains",
   ["tools-rank-normal-matchalts-descr"]       = "Run this tool ensure that all alt-ranked characters hold the alt-rank appropriate to their corresponding main character.",  

-- ============================================================================

   ["tools-rank-trial-listall-title"]          = "1 - List All Trial Members",
   ["tools-rank-trial-listall-descr"]          = "List all the trial-member-ranked 'main' characters.",
   
   ["tools-rank-trial-listall-01-msg"]         = " List of Trial Members:",
   
   ["tools-rank-trial-matchalts-title"]        = "2 - Match Alt-Ranks To Mains",
   ["tools-rank-trial-matchalts-descr"]        = "Run this tool ensure that all alt-ranked characters hold the alt-rank appropriate to their corresponding main character.",  

-- ============================================================================
-- == Tools - Miscellaneous ===================================================
-- ============================================================================
   
   ["tools-misc-rogueav-title"]                = "1 - Rogue Avoidance.",
   ["tools-misc-rogueav-descr"]                = "Output your current avoidance statistic to the default chat window. Suitable only for members of the rogue class.",   
   
   ["tools-misc-rogueav-01-msg"]               = "Need 101.8 combined avoidance. Currently at: ",

-- ============================================================================
-- == Tools - Version Check ===================================================
-- ============================================================================

   ["tools-versioncheck-run-title"]            = "1 - Perform the version check.",
   ["tools-versioncheck-run-descr"]            = "Perform the version check.",

   ["tools-versioncheck-chat-title"]           = "2 - Output to chat window.",
   ["tools-versioncheck-chat-descr"]           = "Set whether or not version check results are output to the default chat window.",
   ["tools-versioncheck-chat-usage"]           = "Select 'On' to have results output to the default chat window or select 'Off' otherwise.",
   
   ["tools-versioncheck-win-title"]            = "3 - Output to popup window.",
   ["tools-versioncheck-win-descr"]            = "Set whether or not version check results are output to a special popup window.",
   ["tools-versioncheck-win-usage"]            = "Select 'On' to have results output to a special popup window or select 'Off' otherwise.",
   
   ["tools-versioncheck-option-on"]            = "On",
   ["tools-versioncheck-option-off"]           = "Off",
   
   ["tools-versioncheck-msg-01"]               = " ConvergeFu: Version Check",
   
   ["tools-versioncheck-muted-01-msg"]         = "Version Check: All display modes disabled, aborting.",

-- ============================================================================
-- == Event Based Function Translations. ======================================
-- ============================================================================
   
   ["event-command-name-confu"]                = "confu",
   ["event-command-name-guildinfo"]            = "guildinfo",

   ["event-command-unknown-01-msg"]            = "ConvergeFu - Unrecognised command received.",
   ["event-command-unknown-02-msg"]            = "Whisper 'confu help' for a list of valid commands.",
   
   ["event-helpinfo-01-msg"]                   = "[Confu] - ConvergeFu Whisper Based Commands:",
   ["event-helpinfo-02-msg"]                   = "[Confu] - Whisper 'confu [option]' where option is one of...",
   ["event-helpinfo-03-msg"]                   = "[Confu] - [help] - displays this help.",
   ["event-helpinfo-04-msg"]                   = "[Confu] - [cctargets] - whispers you the current cc targets.",
   ["event-helpinfo-05-msg"]                   = "[Confu] - ",
   
   ["event-guildinfo-01-msg"]                  = "---------------------------------------------------------",
   ["event-guildinfo-02-msg"]                  = " Converge of Anachronos (EU).",
   ["event-guildinfo-03-msg"]                  = "---------------------------------------------------------",
   ["event-guildinfo-04-msg"]                  = " Guild Type:  PVE End-Game Raiding.",
   ["event-guildinfo-05-msg"]                  = " Established: September, 2006.",
   ["event-guildinfo-06-msg"]                  = " Progress:    SSC/TK/BT/MH.",
   ["event-guildinfo-07-msg"]                  = " Raiding:     20:30-23:30 on Wed/Thu/Sun/Mon/Tue.",
   ["event-guildinfo-08-msg"]                  = " Website:     www.converge-dh.com",
   ["event-guildinfo-09-msg"]                  = " Gear-Level:  Tier 5+ preferred.",
   ["event-guildinfo-10-msg"]                  = " Age-Limit:   18+ (occasional exceptions made)",
   ["event-guildinfo-10-msg"]                  = " Experience:  Good raiding experience preferred.",
   ["event-guildinfo-11-msg"]                  = " Language:    English. (Written and Spoken)",
   ["event-guildinfo-12-msg"]                  = "---------------------------------------------------------",
   
   ["event-guildinfo2-01-msg"]                 = "[1 of 5] Converge is a PVE end-game raiding guild on Anachronos (EU) that was established in September, 2006. We are currently progressing through the Tier 6 content (Black Temple and Mount Hyjal) with full progress info available from our website.",
   ["event-guildinfo2-02-msg"]                 = "[2 of 5] Official raids are run five nights per week (Wed/Thu/Sun/Mon/Tue) from 20:30-23:30 and additional 'off-time' raids to Karazhan, Zul'aman et-al are run on Fri/Sat evenings and at weekends.",
   ["event-guildinfo2-03-msg"]                 = "[3 of 5] Recruitment is open for players of all classes with a preference for applicants with previous raiding experience, good class knowledge, tier-5 gear or better and good availability. Our minimum age requirement is 18+ years old.",
   ["event-guildinfo2-04-msg"]                 = "[4 of 5] All applicants should have good English language skills, especially reading/listening. In addition, all applicants should be aware of the costs of raiding (gems/enchants/repairs/consumables) and be able to support those costs without issue.",
   ["event-guildinfo2-05-msg"]                 = "[5 of 5] For more information, see our website at www.converge-dh.com which details our latest progress and our application process. We hope you found the above information useful. Thanks for reading and good luck!",
      
   ["event-zone-changed-msg"]                  = "Zone change detected.",
   
-- ============================================================================

   ["event-addon-vc-query"]                    = "CFUVCQ",
   ["event-addon-vc-response"]                 = "CFUVCR",
   
   ["event-addon-vc-uptodate-title"]           = "Notice",
   ["event-addon-vc-uptodate-01-msg"]          = "A newer version of ConvergeFu has been detected.",
   ["event-addon-vc-uptodate-02-msg"]          = "Performing a version check for ConvergeFu.",
   
-- ============================================================================

   ["event-zone-change-instance-kara-name"]    = "Karazhan",
   ["event-zone-change-instance-kara-emote"]   = "/e enters Karazhan. In the darkest corners, scuttling noises can be heard.",

   ["event-zone-change-instance-gruul-name"]   = "Gruul's Lair",
   ["event-zone-change-instance-gruul-emote"]  = "/e wanders into the cave-mouth. Hello... ello...ello...elo...o",

   ["event-zone-change-instance-maggy-name"]   = "Magtheridon's Lair",
   ["event-zone-change-instance-maggy-emote"]  = "/e sneaks into the lair. You could cut the atmosphere inside with a knife!",   

   ["event-zone-change-instance-ssc-name"]     = "Serpentshrine Cavern",
   ["event-zone-change-instance-ssc-emote"]    = "/e pushes through the waterfall. Just up ahead, a faint scream... and a thump!",

   ["event-zone-change-instance-tk-name"]      = "Tempest Keep: The Eye",
   ["event-zone-change-instance-tk-emote"]     = "/e walks calmly inside and dons a pair of rose-tinted glasses. WOAH!",

   ["event-zone-change-instance-bt-name"]      = "Black Temple",
   ["event-zone-change-instance-bt-emote"]     = "/e enters the Black Temple. Somewhere a mouse coughs.",
   
   ["event-zone-change-instance-mh-name"]      = "Mount Hyjal",
   ["event-zone-change-instance-mh-emote"]     = "/e ascends Mount Hyjal. In the distance, a cow wheezes.",
   
-- ============================================================================

} end); 
