--[[
	Persistent Data for RaidTracker, Saved Variables	
]]


--***********************************************************************************
-- Saved Variables

KarmaCore { }
