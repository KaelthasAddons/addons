
-- Globals
KA_RaidTracker_LastPage = { };	-- ???

