WishlistData = WishlistData or { Predefined = {} }
local data = WishlistData
local L = AceLibrary('AceLocale-2.2'):new('Wishlist')

table.insert(data.Predefined, {
	Name = 'PvE',
	Args = {
		{
			Name = L['Sunwell  |cffcccccc(Badge of Justice)'],
			Args = {
				{
					Name = L['Two-Hand/Main Hand/Bow  |cffcccccc(150)'],
					Requirements = { { Type = 'Item', Name = L['Badge of Justice'], Required = 150 } },
				},
				{
					Name = L['One Hand  |cffcccccc(105)'],
					Requirements = { { Type = 'Item', Name = L['Badge of Justice'], Required = 105 } },
				},
				{
					Name = L['Chest/Legs  |cffcccccc(100)'],
					Requirements = { { Type = 'Item', Name = L['Badge of Justice'], Required = 100 } },
				},
				{
					Name = L['Hands/Waist/Feet  |cffcccccc(75)'],
					Requirements = { { Type = 'Item', Name = L['Badge of Justice'], Required = 75 } },
				},
				{
					Name = L['Hands/Waist/Feet  |cffcccccc(75)'],
					Requirements = { { Type = 'Item', Name = L['Badge of Justice'], Required = 75 } },
				},
				{
					Name = L['Ring  |cffcccccc(60)'],
					Requirements = { { Type = 'Item', Name = L['Badge of Justice'], Required = 60 } },
				},
				{
					Name = L['Off Hand  |cffcccccc(45)'],
					Requirements = { { Type = 'Item', Name = L['Badge of Justice'], Required = 45 } },
				},
			},
		},
		
		{
		  Name = L['Mounts'],
		  Args = {
		    {
		      Name = L['Riding Nether Ray  |cffcccccc(200g)'],
		      Requirements = {
		        { Type = 'Money', Money = 2000000 },
		        { Type = 'Faction', Faction = L["Sha'tari Skyguard"], Standing = 8 }
		      },
		    },
		    {
		      Name = L['Cenarion War Hippogryph  |cffcccccc(1600g)'],
		      Requirements = {
		        { Type = 'Money', Money = 16000000 },
		        { Type = 'Faction', Faction = L["Cenarion Expedition"], Standing = 8 }
		      },
		    },
		  },
		},
	},
})