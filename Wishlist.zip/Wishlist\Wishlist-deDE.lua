local L = AceLibrary("AceLocale-2.2"):new("Wishlist")

--�	\195\164	J�ger = J\195\164ger
--�	\195\132	�rger = \195\132rger
--�	\195\182	sch�n = sch\195\182n
--�	\195\150	�dipus = \195\150dipus
--�	\195\188	R�stung = R\195\188stung
--�	\195\156	�bung = \195\156bung
--�	\195\159	Stra�e = Stra\195\159e 

L:RegisterTranslations("deDE", function() return {
	["|cFFFF0000Loaded!"] = "|cFFFF0000Loaded!",
	
	['Factions'] = "Fraktionen",
	["Faction %s not found"] = "Fraktion %s unbekannt",
	
	['Money'] = "Geld",
	["Money: %s"] = "Geld: %s",
	['Honor'] = "Ehre",
	["Honor: %d"] = "Ehre: %d",
	["Items"] = "%s: %d",
	['Arena Points'] = "Arenapunkte",
	
	["Watched Items"] = "\195\188berwachte Gegenst\195\164nde",
	
	["You got item %s, congratulations!"] = "Gegenstand %s erhalten. Gratuliere!",
	
	-- Options
	
	["Options Settings"] = "Einstellungen",
	["Show Money Changes"] = "Benachrichtigung \195\188ber Geldver\195\164nderung",
	["Show Honor Changes"] = "Benachrichtigung \195\188ber Ehrever\195\164nderung",
	["Show Items Changes"] = "Benachrichtigung \195\188ber Gegenstandver\195\164nderungen", -- if you need long sentences; use german...
	['Show Needed'] = "Zeige ben\195\182tigte",
	
	["Options Text"] = "Text",
	["Show Money"] = "Zeige Geld",
	['Money (copper)'] = "Geld (Kupfer)",
	['Note'] = "Hinweis",
	
	["Options Items"] = "Gegenst\195\164nde",
	["Add Item"] = "Gegenstand hinzuf\195\188gen",
	["Add Custom"] = "Spezielle Bedingung",
	["Add Predefined"] = "Vordefinierte Bedingung",
	['PvP'] = "PvP",
	['PvE'] = "PvE",
	["Requirements"] = "Bedingungen",
	["Remove"] = "Entfernen",
	["Remove Item"] = "Entferne Gegenstand",
	['Move to Set'] = "Verschiebe zu Sammlung",
	['Import from AtlasLoot'] = "Von Atlasloot importieren",
	['Add Set'] = "Set hinzuf\195\188gen",
	['Remove Set'] = "Entferne Set",
	['Remove from %s'] = "Entferne von %s",
	
	["Added %s to watch list"] = "%s zur Beobachtungliste hinzugef\195\188gt",
	['Removed %s from watch list'] = "%s von Beobachtungsliste entfernt",
	
	-- Validate
	["%d honor"] = "%d Ehre",
	["%d Arena Point(s)"] = "%d Arenapunkt(e)",
	["%dx %s"] = "%dx %s",
	['%s|r with %s'] = "%s|r mit %s",
	
	-- Tooltip
	['|cffffffffAdd items first'] = "|cffffffffErst Gegenst\195\164nde hinzuf\195\188gen",
	['|cffffffffGot everything!'] = "|cffffffffAlles bekommen!",
	['Need'] = "Ben\195\182tigt",
	['Got'] = "Erhalten",
	['Done'] = "Erledigt",
	['|cffffffffTotal'] = "|cffffffffGesammt",
	['%s|r |cffffffff(%d)'] = "%s|r |cffffffff(%d)",
	['%s, you got everything!'] = "%s, du hast alles!",
	['%s, you need %s.'] = "%s, du brauchst %s.",

	['Not Found'] = "Nicht gefunden",

	-- PVE Presets from PVE.lua
	['Sunwell  |cffcccccc(Badge of Justice)'] = "Sonnenbrunnen  |cffcccccc(Abzeichen der Gerechtigkeit)",
	['Badge of Justice'] = "Abzeichen der Gerechtigkeit",
	['Two-Hand/Main Hand/Bow  |cffcccccc(150)'] = "Zweih\195\164nder/Haupthand/Bogen  |cffcccccc(150)",
	['One Hand  |cffcccccc(105)'] = "Einh\195\164nder  |cffcccccc(105)",
	['Chest/Legs  |cffcccccc(100)'] = "Brust/Beine  |cffcccccc(100)",
	['Hands/Waist/Feet  |cffcccccc(75)'] = "H\195\164nde/G\195\188rtel/F\195\188\195\159e  |cffcccccc(75)",
	['Hands/Waist/Feet  |cffcccccc(75)'] = "H\195\164nde/G\195\188rtel/F\195\188\195\159e  |cffcccccc(75)",
	['Ring  |cffcccccc(60)'] = "Ring  |cffcccccc(60)",
	['Off Hand  |cffcccccc(45)'] = "Nebenhand  |cffcccccc(45)",
	['Mounts'] = "Reittiere",
	['Riding Nether Ray  |cffcccccc(200g)'] = "Netherdrachen reiten  |cffcccccc(200g)",
	["Sha'tari Skyguard"] = "Himmelswache der Sha'tari",
	['Cenarion War Hippogryph  |cffcccccc(1600g)'] = "Cenarischer Kriegshippogryph |cffcccccc(1600g)",
	["Cenarion Expedition"] = "Expdition des Cenarius",
	--PVP Presets from PVP.lua
	['Arena S2'] = "Arena S2",

	['Alterac Valley Mark of Honor'] = "Ehrenabzeichen des Alteractals",
	['Warsong Gulch Mark of Honor'] = "Ehrenabzeichen der Kriegshymnenschlucht",
	['Arathi Basin Mark of Honor'] = "Ehrenabzeichen des Arathibeckens",
	['Head  |cffcccccc(14500H, 30AV)'] = "'Kopf  |cffcccccc(14500H, 30AV)'",
	['Shoulder  |cffcccccc(11250H, 20AB)'] = "Schulter  |cffcccccc(11250H, 20AB)",
	['Chest  |cffcccccc(14500H, 30AB)'] = "Brust  |cffcccccc(14500H, 30AB)",
	['Hands  |cffcccccc(10500H, 20AV)'] = "H\195\164nde  |cffcccccc(10500H, 20AV)",
	['Legs  |cffcccccc(14500H, 30WSG)'] = "Beine  |cffcccccc(14500H, 30WSG)",
	['Two Hand/Bow  |cffcccccc(17000H, 40AV)'] = "Zweih\195\164nder/Bogen  |cffcccccc(17000H, 40AV)",
	['Main Hand  |cffcccccc(25200H, 20EotS)'] = "Haupthand  |cffcccccc(25200H, 20EotS)",
	['Eye of the Storm Mark of Honor'] = "Ehrenabzeichen vom Auge des Sturms",
	['One-Hand  |cffcccccc(18000H, 20EotS)'] = "Einh\195\164nder |cffcccccc(18000H, 20EotS)",
	['Off Hand  |cffcccccc(9000H, 20EotS)'] = "Nebenhand |cffcccccc(9000H, 20EotS)",
	['Held In Off Hand  |cffcccccc(9000H, 20EotS)'] = "In Nebenhand getragen |cffcccccc(9000H, 20EotS)",
	['Wand/Relic  |cffcccccc(8000H, 10EotS)'] = "Zauberstab/Relikt |cffcccccc(8000H, 10EotS)",

	['Arena S3'] = "Arena S3",

	['Head/Chest/Legs  |cffcccccc(1630AP)'] = "Head/Chest/Legs  |cffcccccc(1630AP)",
	['Shoulders  |cffcccccc(1304AP)'] = "Shoulders  |cffcccccc(1304AP)",
	['Hands  |cffcccccc(978AP)'] = "Hands  |cffcccccc(978AP)",
	['Two Hand/Bow  |cffcccccc(3261AP)'] = "Two Hand/Bow  |cffcccccc(3261AP)",
	['Main Hand  |cffcccccc(2739AP)'] = "Main Hand  |cffcccccc(2739AP)",
	['One-Hand  |cffcccccc(2283AP)'] = "One-Hand  |cffcccccc(2283AP)",
	['Off Hand  |cffcccccc(1630AP)'] = "Off Hand  |cffcccccc(1630AP)",
	['Held In Off Hand  |cffcccccc(978AP)'] = "Held In Off Hand  |cffcccccc(978AP)",
	['Wand/Relic  |cffcccccc(870AP)'] = "Wand/Relic  |cffcccccc(870AP)",
	['Hunter Two-Handed Axe  |cffcccccc(870AP)'] = "Hunter Two-Handed Axe  |cffcccccc(870AP)",

	['Arena S4'] = "Arena S4",

	['Head/Chest/Legs  |cffcccccc(1875AP)'] = "Head/Chest/Legs  |cffcccccc(1875AP)",
	['Shoulders  |cffcccccc(1500AP)'] = "Shoulders  |cffcccccc(1500AP)",
	['Hands  |cffcccccc(1125AP)'] = "Hands  |cffcccccc(1125AP)",
	['Two Hand/Bow  |cffcccccc(3750AP)'] = "Two Hand/Bow  |cffcccccc(3750AP)",
	['Main Hand  |cffcccccc(3150AP)'] = "Main Hand  |cffcccccc(3150AP)",
	['One-Hand  |cffcccccc(2625AP)'] = "One-Hand  |cffcccccc(2625AP)",
	['Off Hand  |cffcccccc(1875AP)'] = "Off Hand  |cffcccccc(1875AP)",
	['Held In Off Hand  |cffcccccc(1125AP)'] = "Held In Off Hand  |cffcccccc(1125AP)",
	['Wand/Relic  |cffcccccc(1000AP)'] = "Wand/Relic  |cffcccccc(1000AP)",
	['Hunter Main Hand Axe  |cffcccccc(1000AP)'] = "Hunter Main Hand Axe  |cffcccccc(1000AP)",
	['Hunter Off Hand Axe  |cffcccccc(1000AP)'] = "Hunter Off Hand Axe  |cffcccccc(1000AP)",

	['S2/3 Non-Set Epics'] = "S2/3 Non-Set Epics",
	['Wrist  |cffcccccc(9199H, 20WSG)'] = "Wrist  |cffcccccc(9199H, 20WSG)",
	['Waist  |cffcccccc(13923H, 40AB)'] = "Waist  |cffcccccc(13923H, 40AB)",
	['Feet  |cffcccccc(13923H, 40EotS)'] = "Feet  |cffcccccc(13923H, 40EotS)",
	['Back  |cffcccccc(7548H, 20AB)'] = "Back  |cffcccccc(7548H, 20AB)",
	['Neck  |cffcccccc(11934H, 10EotS)'] = "Neck  |cffcccccc(11934H, 10EotS)",
	['Vindicator Ring  |cffcccccc(11934H, 10AV)'] = "Vindicator Ring  |cffcccccc(11934H, 10AV)",
	
	['S4 Non-Set Epics'] = "S4 Non-Set Epics",
	['Wrist  |cffcccccc(11794H, 20WSG)'] = "Wrist  |cffcccccc(11794H, 20WSG)",
	['Waist  |cffcccccc(17850H, 40AB)'] = "Waist  |cffcccccc(17850H, 40AB)",
	['Feet  |cffcccccc(17850H, 40EotS)'] = "Feet  |cffcccccc(17850H, 40EotS)",
	['Neck  |cffcccccc(15300H, 10EotS)'] = "Neck  |cffcccccc(15300H, 10EotS)",
	['Guardian Ring  |cffcccccc(15300H, 10AV)'] = "Guardian Ring  |cffcccccc(15300H, 10AV)",
	
	--Factions and tokens 
	['Halaa Battle Token'] = "Kampfmarke vo Halaa",
	['Halaa Research Token'] = "Forschermarke von Halaa",
	['WSG Mark(s)'] = "WSG Mark(s)",
	['AB Mark(s)'] = "AB Mark(s)",
	['AV Mark(s)'] = "AV Mark(s)",
	['EotS Mark(s)'] = "EotS Mark(s)",
	['Cenarion Expedition']  = "Expedition des Cenarius",
	['Lower City']  = "Unteres Viertel",
	["The Sha'tar"]  = "Die Sha'tar",
	['Keepers of Time']  = "H\195\188ter der Zeit",
	['The Aldor']  = "Die Aldor",
	['The Scryers']  = "Die Seher",
	['Ashtongue Deathsworn']  = "Die Todesh\195\182rigen",
	["Sha'tari Skyguard"]  = "Himmelswache der Sha'tari",
	['Shattered Sun Offensive'] = "Zerschmetterte Sonne",
	['Frostwolf Clan'] = "Frostwolfklan",
	['The Defilers'] = "Die Entweihten",
	['Warsong Outriders'] = "Kriegshymnenklan",

	['Thrallmar'] = "Thrallmar",
	["The Mag'har"] = "Die Mag'har",

	['Silverwing Sentinels'] = "Silberschwingen",
	['Stormpike Guard'] = "Sturmlanzengarde",
	['The League of Arathor'] = "Der Bund von Arathor",

	['Honor Hold'] = "Ehrenfeste",
	['Kurenai'] = "Kurenai",

	--AtlasLoot table data
	['Outland Reputation'] = "Scherbenwelt Ruf",
	['Arena S1 - '] = "Arena S1",
	['Arena S1 - Weapons 1'] = "Arena S1 - Waffen 1",
	['Arena S1 - Weapons 2'] = "Arena S1 - Waffen 2",
	['Arena S2 - '] = "Arena S2",
	['Arena S2 - Weapons 1'] = "Arena S2 - Waffen 1",
	['Arena S2 - Weapons 2'] = "Arena S2 - Waffen 2",
	['Arena S3 - '] = "Arena S3",
	['Arena S3 - Weapons 1'] = "Arena S3 - Waffen 1",
	['Arena S3 - Weapons 2'] = "Arena S3 - Waffen 2",
	['Arena S4 - '] = "Arena S4",
	['Arena S4 - Weapons 1'] = "Arena S4 - Waffen 1",
	['Arena S4 - Weapons 2'] = "Arena S4 - Waffen 2",
	['Lvl70 Non-Set Epics 1'] = "Lvl 70 NichtSet Epics 1",
	['Lvl70 Non-Set Epics 2'] = "Lvl 70 NichtSet Epics 2",
	['Lvl70 Non-Set Epics 3'] = "Lvl 70 NichtSet Epics 3",
	['Lvl70 Non-Set Epics 4'] = "Lvl 70 NichtSet Epics 4",
	['Lvl70 Non-Set Epics 5'] = "Lvl 70 NichtSet Epics 5",
	['Lvl 70 Instance Token Rewards - Accessories 1'] = "Level 70 Instanztokenbelohnung - Schmuck 1",
	['Lvl 70 Instance Token Rewards - Accessories 2'] = "Level 70 Instanztokenbelohnung - Schmuck 2",
	['Lvl 70 Instance Token Rewards - Veteran Armor 1'] = "Level 70 Instanztokenbelohnung - Veteranenr\195\188stung 1",
	['Lvl 70 Instance Token Rewards - Veteran Armor 2'] = "Level 70 Instanztokenbelohnung - Veteranenr\195\188stung 2",
	['Lvl 70 Instance Token Rewards - Cloaks'] = "Level 70 Instanztokenbelohnung - Umh\195\164nge",
	['Lvl 70 Instance Token Rewards - Cloth'] = "Level 70 Instanztokenbelohnung - Stoff",
	['Lvl 70 Instance Token Rewards - Leather 1'] = "Level 70 Instanztokenbelohnung - Leder 1",
	['Lvl 70 Instance Token Rewards - Leather 2'] = "Level 70 Instanztokenbelohnung - Leder 2",
	['Lvl 70 Instance Token Rewards - Mail'] = "Level 70 Instanztokenbelohnung - Kette",
	['Lvl 70 Instance Token Rewards - Plate 1'] = "Level 70 Instanztokenbelohnung - Platte 1",
	['Lvl 70 Instance Token Rewards - Plate 2'] = "Level 70 Instanztokenbelohnung - Platte 2",
	['Lvl 70 Instance Token Rewards - Relics'] = "Level 70 Instanztokenbelohnung - Relikte",
	['Lvl 70 Instance Token Rewards - Fire Prot. Gears'] = "Level 70 Instanztokenbelohnung - Feuerresi",
	['Lvl 70 Instance Token Rewards - Weapons'] = "Level 70 Instanztokenbelohnung - Waffen",
} end )