-- TODO: Other languages
-- TODO: Item reordering

Wishlist = AceLibrary('AceAddon-2.0'):new('AceConsole-2.0', 'AceEvent-2.0', 'AceDB-2.0', 'FuBarPlugin-2.0')
local self = Wishlist
WishlistData = WishlistData or { Factions = {}, Predefined = {} }
local data = WishlistData
local L = AceLibrary('AceLocale-2.2'):new('Wishlist')

-----------------------------
--- AceLibrary References ---
-----------------------------

local dewdrop = AceLibrary('Dewdrop-2.0')
local tablet = AceLibrary('Tablet-2.0')

-- FuBar Options
Wishlist.name = 'Wishlist'
Wishlist.title = 'Wishlist'
Wishlist.hasIcon = 'Interface/PvPRankBadges/PvPRank' .. UnitFactionGroup('player')
Wishlist.clickableTooltip = true

----------------------
--- FuBar Handlers ---
----------------------

function Wishlist:OnInitialize()
	-- Money formatting
	local abacus = LibStub:GetLibrary('LibAbacus-3.0', true)
	self.FormatMoney = abacus.FormatMoneyCondensed

	self.ShortNames = {
		[L['Warsong Gulch Mark of Honor']] = L['WSG Mark(s)'],
		[L['Arathi Basin Mark of Honor']] = L['AB Mark(s)'],
		[L['Alterac Valley Mark of Honor']] = L['AV Mark(s)'],
		[L['Eye of the Storm Mark of Honor']] = L['EotS Mark(s)'],
	}

	self.Textures = {
		Honor = 'Interface/PvPRankBadges/PvPRank' .. UnitFactionGroup('player'),
		Money = 'Interface/MoneyFrame/UI-MoneyIcons', -- TODO: Better icon
		ArenaPoints = 'Interface/PVPFrame/PVP-ArenaPoints-Icon',
		[L['Warsong Gulch Mark of Honor']] = 'Interface/Icons/INV_Misc_Rune_07',
		[L['Arathi Basin Mark of Honor']] = 'Interface/Icons/INV_Jewelry_Amulet_07',
		[L['Alterac Valley Mark of Honor']] = 'Interface/Icons/INV_Jewelry_Necklace_21',
		[L['Eye of the Storm Mark of Honor']] = 'Interface/Icons/Spell_Nature_EyeOfTheStorm',
		[L['Badge of Justice']] = 'Interface/Icons/Spell_Holy_ChampionsBond',
		[L['Halaa Battle Token']] = 'Interface/Icons/INV_Misc_Rune_08',
		[L['Halaa Research Token']] = 'Interface/Icons/INV_Misc_Rune_09',
	}
	
	-- Cache standing text
	self.StandingText = {}
	local s
  for s = 1, 8 do
		self.StandingText[s] = self:ColorToHex(FACTION_BAR_COLORS[s]) .. getglobal('FACTION_STANDING_LABEL' .. s)
	end
	
	self.Factions = { L['Cenarion Expedition'], L['Lower City'], L["The Sha'tar"], L['Keepers of Time'], L['The Aldor'], L['The Scryers'], L['Ashtongue Deathsworn'], L["Sha'tari Skyguard"], L['Shattered Sun Offensive'] }

	if UnitFactionGroup('player') == 'Horde' then
		-- Battleground Factions
		table.insert(self.Factions, L['Frostwolf Clan'])
		table.insert(self.Factions, L['The Defilers'])
		table.insert(self.Factions, L['Warsong Outriders'])

		-- BC Factions
		table.insert(self.Factions, L['Thrallmar'])
		table.insert(self.Factions, L["The Mag'har"])
	else
		-- Battleground Factions
		table.insert(self.Factions, L['Silverwing Sentinels'])
		table.insert(self.Factions, L['Stormpike Guard'])
		table.insert(self.Factions, L['The League of Arathor'])

		-- BC Factions
		table.insert(self.Factions, L['Honor Hold'])
		table.insert(self.Factions, L['Kurenai'])
	end

	-- Sort all factions
	table.sort(self.Factions)

	-- AtlasLoot Hook
	local atlasData = AtlasLoot_Data
	if atlasData then
		local pvp = atlasData.AtlasLootGeneralPvPItems
		local pve = atlasData.AtlasLootSetItems
		if not pvp or not pve then
			LoadAddOn("AtlasLoot_SetsandPvP")
			pvp = atlasData.AtlasLootGeneralPvPItems
			pve = atlasData.AtlasLootSetItems
		end

		if pvp and pve then
			self:BuildFromAtlasLoot(pvp, pve)
		end
	end
end

function Wishlist:OnEnable()
	-- Create data variables
	self.Data = {
		Factions = {},
		Honor = GetHonorCurrency(),
		ArenaPoints = GetArenaCurrency(),
		Items = {
			[L['Warsong Gulch Mark of Honor']] = 0,
			[L['Arathi Basin Mark of Honor']] = 0,
			[L['Alterac Valley Mark of Honor']] = 0,
			[L['Eye of the Storm Mark of Honor']] = 0,
			[L['Badge of Justice']] = 0,
			[L['Halaa Battle Token']] = 0,
			[L['Halaa Research Token']] = 0,
		},
		Money = GetMoney(),
	}

	-- Create database
	self:RegisterDB("WishlistDB", "WishlistCharDB")
	self:RegisterDefaults("profile", {
		Settings = {
			ShowMoneyChanges = false,
			ShowHonorChanges = false,
			ShowItemsChanges = false,
			ShowNeeded = true,
			ShowAll = false,
		},
		Text = {
			ShowMoney = true,
		},
	})
	self:RegisterDefaults("char", {
		Items = {},
		Sets = {},
	})

	self:UpdateItems()

	-- Keep honor up-to-date
	self:RegisterEvent("HONOR_CURRENCY_UPDATE")

	-- Keep reputation up-to-date
	self:RegisterEvent("UPDATE_FACTION")

	-- Keep money up-to-date
	self:RegisterEvent("PLAYER_MONEY")

	self:RegisterEvent("BAG_UPDATE")

	self:UpdateTotals()
	self:Update()

	self:RegisterMenu()
end

function Wishlist:OnDisable()
	self:UnregisterAllEvents()
end

function Wishlist:OnDataUpdate()
	self.Result, self.Failed = self:CheckItem(self.Totals)

	-- Reset results
	self.ItemResults = {}
	
	self:CheckItems(self.ItemResults, self.db.char.Items)
	local _, set
	for _, set in ipairs(self.db.char.Sets) do
		self:CheckItems(self.ItemResults, set.Items, set)
	end
end

function Wishlist:OnTextUpdate()
	local text = ''
	if self.db.profile.Text.ShowMoney then
		text = text .. self:GetMoneyText()
	end
	self:SetText(text)
end

function Wishlist:OnTooltipUpdate()
	local cat
	if self.Result then
		cat = tablet:AddCategory('columns', 1, 'showWithoutChildren', true)
		if not self:HasItems() then
			-- Got nothing
			cat:AddLine({ text = L['|cffffffffAdd items first'], justify = 'CENTER' })
		else
			-- Got everything!!
			self:AddItemsToTooltip(self.db.char.Items, cat)
			local index, set
			for index, set in ipairs(self.db.char.Sets) do
				cat:AddLine({ text = '|cffffffff' .. set.Name, justify = 'CENTER' })
				self:AddItemsToTooltip(set.Items, cat)
			end
			cat:AddLine({ text = L['|cffffffffGot everything!'], justify = 'CENTER' })
		end
	else
		-- Something is missing, show totals
		cat = tablet:AddCategory('columns', 3, 'showWithoutChildren', true)
		cat:AddLine({
			text = '', justify = 'CENTER',
			text2 = self.db.profile.Settings.ShowNeeded and L['Need'] or L['Got'], justify2 = 'CENTER',
			text3 = L['Done'],	justify3 = 'CENTER',
		})

		-- Show totals of requirements
		local index, req
		local total = 0
		for index, req in ipairs(self.Failed) do
			local txt, txt2, done = self:RequirementToTooltip(req)
			if done > 1 then
				done = 1
			end
			cat:AddLine({ text = txt, text2 = txt2, text3 = self:PercentageToColoredText(done) })
			total = total + done
		end
		total = total / #self.Failed

		cat:AddLine({ text = L['|cffffffffTotal'], justify = 'CENTER', text2 = '', text3 = self:PercentageToColoredText(total) })

		-- Show percentage for each item
		cat = tablet:AddCategory('text', L['Options Items'], 'columns', 2)
		local index, item
		for index, item in ipairs(self.ItemResults) do
			local name, link = GetItemInfo(item.ItemId)
			local text, set = link or L['Not Found'], item.Set
			if set then
				text = text .. ' |cffcccccc(' .. set .. ')'
			end
			
			local done
			local func
			if item.Result then
				done = self:PercentageToColoredText(1)
				func = function() self:Print((L['%s, you got everything!']):format(link)) end
			else
				local total = 0
				local count = item.Count
				local need = ''
				for index, req in ipairs(item.Failed) do
					local _, _, done = self:RequirementToTooltip(req)
					if done > 1 then
						done = 1
					end
					if strlen(need) > 0 then
					  need = need .. ', '
					end
					need = need .. self:RequirementToNeeded(req)
					total = total + done
				end
				total = (total + count - #item.Failed) / count
				if total == 1 then
				  total = 0.99 -- Just to never show 100%
				end
				done = self:PercentageToColoredText(total)
				func = function() self:Print((L['%s, you need %s.']):format(link, need)) end
			end
			
			cat:AddLine({ text = text, text2 = done, func = func })
		end
	end
end

------------------------
--- Validate Methods ---
------------------------

function Wishlist:CheckItem(item, onlyNeeded)
	local result = true
	local failed = {}

	local index, req
	for index, req in ipairs(item.Requirements) do
		if not self:ValidateRequirement(req, onlyNeeded) then
			table.insert(failed, req)
			result = false
		end
	end

	return result, failed
end

function Wishlist:ValidateRequirement(req, onlyNeeded)
	if req and (not self.db.profile.Settings.ShowAll or onlyNeeded) then
		if req.Type == 'Honor' then
			-- Check if we have enough honor
			return self.Data.Honor >= req.Honor
		elseif req.Type == 'Money' then
			-- Check if we have enough money
			return self.Data.Money >= req.Money
		elseif req.Type == 'Arena' then
			-- Check if we have enough arena points
			return self.Data.ArenaPoints >= req.ArenaPoints
		elseif req.Type == 'Faction' then
			-- Check if we have enough reputation
			return self:GetFactionStanding(req.Faction) >= req.Standing
		elseif req.Type == 'Item' then
			-- Check if we have enough of the needed item
			return self:GetItemCount(req.Name) >= req.Required
		end
	end
	return false
end

----------------------
--- Helper Methods ---
----------------------

function Wishlist:AddItem(item, items)
	local name, link = GetItemInfo(item)
	if not name then return end
	local _, _, item = string.find(link, "item:(%-?%d+):")
	item = tonumber(item)

	-- Add item to character's watched items with no requirements
	self:AddNewItem({ ItemId = item, Requirements = {} }, link, items)
end

function Wishlist:AddItemsToTooltip(items, cat)
	local index, item
	for index, item in ipairs(items) do
		local _, link = GetItemInfo(item.ItemId)
		link = link or L['Not Found']
		cat:AddLine({ text = link, justify = 'CENTER', func = function() self:Print((L['%s, you got everything!']):format(link)) end })
	end
end

function Wishlist:AddNewItem(item, link, items)
	items = items or self.db.char.Items
	table.insert(items, item)

	self:UpdateTotals()
	self:Update()
	self:UpdateItemsMenu()

	self:Print((L['Added %s to watch list']):format(link))
end

function Wishlist:AddRequirements(item, requirements)
  -- Combine new requirements with current ones
	self:CombineRequirements(item.Requirements, requirements)

	self:UpdateTotals()
	self:Update()
	self:UpdateItemsMenu()
end

function Wishlist:AddSet(name)
	table.insert(self.db.char.Sets, { Name = name, Items = {} })
	
	self:UpdateItemsMenu()
end

function Wishlist:CheckItems(results, items, set)
	local _, item
	for _, item in ipairs(items) do
		local result, failed = self:CheckItem(item, true)
		local itemResult = { ItemId = item.ItemId, Result = result, Failed = failed, Count = #item.Requirements }
		if set then
			itemResult.Set = set.Name
		end
		table.insert(results, itemResult)
	end
end

function Wishlist:CheckForItems(items)
	local isChanged = false
	
	local hasItems = {}
	local index
	for index, item in ipairs(items) do
		if GetItemCount(item.ItemId) > 0 then
			local _, itemLink = GetItemInfo(item.ItemId)
			self:Print((L["You got item %s, congratulations!"]):format(itemLink))

			table.insert(hasItems, 1, index)
			isChanged = true
		end
	end
	while #hasItems > 0 do self:RemoveItem(items, table.remove(hasItems), true) end
	
	return isChanged
end

function Wishlist:ColorToHex(color)
	return ("|cff%02x%02x%02x"):format(color.r * 255, color.g * 255, color.b * 255)
end

function Wishlist:CombineRequirements(original, extra)
	local index, req
	for index, req in ipairs(extra) do
		local existing = self:FindMatchingRequirement(original, req)
		if existing then
			if existing.Type == 'Honor' then
				existing.Honor = existing.Honor + req.Honor
			elseif existing.Type == 'Money' then
				existing.Money = existing.Money + req.Money
			elseif existing.Type == 'Arena' then
				existing.ArenaPoints = existing.ArenaPoints + req.ArenaPoints
			elseif existing.Type == 'Item' then
				existing.Required = existing.Required + req.Required
			elseif existing.Type == 'Faction' then
				existing.Standing = max(existing.Standing, req.Standing)
			end
		else
			-- Copy requirement
			local new = {}
			local key, value
			for key, value in pairs(req) do
				new[key] = value
			end
			table.insert(original, new)
		end
	end
end

function Wishlist:FindMatchingRequirement(requirements, match)
	local _, req
	for _, req in ipairs(requirements) do
		if (req.Type == match.Type) and ((req.Type ~= 'Item' and req.Type ~= 'Faction') or (req.Type == 'Item' and req.Name == match.Name) or (req.Type == 'Faction' and req.Faction == match.Faction)) then
			return req
		end
	end
	return nil -- Not found
end

function Wishlist:GetFaction(name)
	return self.Data.Factions[name] or { Standing = 4, EarnedValue = 0 } -- Default Neutral
end

-- 0 - Unknown
-- 1 - Hated
-- 2 - Hostile
-- 3 - Unfriendly
-- 4 - Neutral
-- 5 - Friendly
-- 6 - Honored
-- 7 - Revered
-- 8 - Exalted
function Wishlist:GetFactionStanding(name)
	local faction = self:GetFaction(name)
	return not faction and 0 or faction.Standing
end

function Wishlist:GetItemCount(name)
	return (self.Data.Items[name] or 0)
end

function Wishlist:GetMoneyText()
	return self:FormatMoney(self.Data.Money, true)
end

function Wishlist:GetShortName(txt)
	return self.ShortNames[txt] or txt
end

function Wishlist:HasItems()
	if #self.db.char.Items > 0 then
		return true
	end
	
	local index, set
	for index, set in ipairs(self.db.char.Sets) do
		if #set.Items > 0 then
			return true
		end
	end
	
	return false
end

function Wishlist:MoveItem(items, index, newItems)
	table.insert(newItems, table.remove(items, index))
	
	self:Update()
	self:UpdateItemsMenu()
end

-- Converts a percentage (0.00-1.00) to (red-green)
function Wishlist:PercentageToColoredText(value)
  local h, s, v = (value / 2.55) * 360, 1, 1

  local sectorPos = h / 60
  local sectorNumber = floor(sectorPos)
  local fractionalSector = sectorPos - sectorNumber

  local p = 0
  local q = 1 - fractionalSector
  local t = 1 - (1 - fractionalSector)

  local r, g, b
  if sectorNumber == 0 then
    r, g, b = v, t, p
  elseif sectorNumber == 1 then
    r, g, b = q, v, p
  elseif sectorNumber == 2 then
    r, g, b = p, v, t
  elseif sectorNumber == 3 then
    r, g, b = p, q, v
  elseif sectorNumber == 4 then
    r, g, b = t, p, v
  else
    r, g, b = v, p, q
  end

  return self:ColorToHex({ r = r, g = g, b = b }) .. ('%d'):format(value * 100) .. '%'
end

function Wishlist:PrintFaction(name)
	local standing = self:GetFactionStanding(name)

	if not standing then
		self:Print((L["Faction %s not found"]):format(name))
	else
		self:Print(name .. ' rep: ' .. self.StandingText[standing])
	end
end

function Wishlist:PrintHonor()
	if self.db.profile.Settings.ShowHonorChanges then
		self:Print((L["Honor: %d"]):format(self.Data.Honor))
	end
end

function Wishlist:PrintItems()
	if self.db.profile.Settings.ShowItemsChanges then
		local index, value
		for index, value in pairs(self.Data.Items) do
			self:Print((L["Items"]):format(index, value))
		end
	end
end

function Wishlist:PrintMoney()
	if self.db.profile.Settings.ShowMoneyChanges then
		self:Print((L["Money: %s"]):format(self:GetMoneyText()))
	end
end

function Wishlist:RemoveItem(items, index, hideMessage)
	local _, link = GetItemInfo(items[index].ItemId)
	table.remove(items, index)

	self:UpdateTotals()
	self:Update()
	self:UpdateItemsMenu()

	if not hideMessage then
	  self:Print((L['Removed %s from watch list']):format(link or L['Not Found']))
	end
end

function Wishlist:RemoveRequirement(item, reqIndex)
	table.remove(item.Requirements, reqIndex)

	self:UpdateTotals()
	self:Update()
	self:UpdateItemsMenu()
end

function Wishlist:RemoveSet(index)
	local set = self.db.char.Sets[index]
	
	-- Move all items back to root
	local _, item
	for _, item in ipairs(set.Items) do
		table.insert(self.db.char.Items, item)
	end
	
	-- Remove set
	table.remove(self.db.char.Sets, index)
	
	self:UpdateItemsMenu()
end

function Wishlist:RequirementToNeeded(req)
	if req then
		if req.Type == 'Honor' then
			return (L['%d honor']):format(req.Honor - self.Data.Honor)
		elseif req.Type == 'Money' then
			return self:FormatMoney(req.Money - self.Data.Money, true)
		elseif req.Type == 'Arena' then
			return (L['%d Arena Point(s)']):format(req.ArenaPoints - self.Data.ArenaPoints)
		elseif req.Type == 'Faction' then
			return (L['%s|r with %s']):format(self.StandingText[req.Standing], req.Faction)
		elseif req.Type == 'Item' then
			local count = self:GetItemCount(req.Name)
			return (L['%dx %s']):format(req.Required - count, self:GetShortName(req.Name))
		elseif req.Type == 'Note' then
			return req.Note
		end
	end
	return ''
end

function Wishlist:RequirementToString(req)
	if req then
		if req.Type == 'Honor' then
			return (L['%d honor']):format(req.Honor), self.Textures.Honor
		elseif req.Type == 'Money' then
			return self:FormatMoney(req.Money, true), self.Textures.Money
		elseif req.Type == 'Arena' then
			return (L['%d Arena Point(s)']):format(req.ArenaPoints), self.Textures.ArenaPoints
		elseif req.Type == 'Faction' then
			return (L['%s|r with %s']):format(self.StandingText[req.Standing], req.Faction)
		elseif req.Type == 'Item' then
			return (L['%dx %s']):format(req.Required, self:GetShortName(req.Name)), self.Textures[req.Name]
		elseif req.Type == 'Note' then
			return req.Note
		end
	end
	return ''
end

function Wishlist:RequirementToTooltip(req)
	if req then
		local showNeeded = self.db.profile.Settings.ShowNeeded
		if req.Type == 'Honor' then
			return L['Honor'], ('|cffffffff%d/%d'):format(showNeeded and req.Honor - self.Data.Honor or self.Data.Honor, req.Honor), self.Data.Honor / req.Honor
		elseif req.Type == 'Money' then
			return L['Money'], self:FormatMoney(showNeeded and req.Money - self.Data.Money or self.Data.Honor, true), self.Data.Money / req.Money
		elseif req.Type == 'Arena' then
			return L['Arena Points'], ('|cffffffff%d/%d'):format(showNeeded and req.ArenaPoints - self.Data.ArenaPoints or self.Data.ArenaPoints, req.ArenaPoints), self.Data.ArenaPoints / req.ArenaPoints
		elseif req.Type == 'Faction' then
			local faction = self:GetFaction(req.Faction)
			local earnedValue = faction.EarnedValue
			local needed = self:StandingToValue(req.Standing)
			local standing = showNeeded and req.Standing or faction.Standing
			return req.Faction, (L['%s|r |cffffffff(%d)']):format(self.StandingText[standing], needed - earnedValue), earnedValue / needed
		elseif req.Type == 'Item' then
			local count = self:GetItemCount(req.Name)
			return self:GetShortName(req.Name), ('|cffffffff%d/%d'):format(showNeeded and req.Required - count or count, req.Required), count / req.Required
		elseif req.Type == 'Note' then
			return L['Note'], '|cffffffff' .. req.Note, 0
		end
	end
	return '', '', 0
end

function Wishlist:StandingTextToValue(text)
  local s
  for s = 1, 8 do
    if text == self.StandingText[s] then
      return s
    end
  end
  return 0
end

function Wishlist:StandingToValue(standing)
  if standing <= 5 then
    return 3000
  elseif standing == 6 then
    return 9000
  elseif standing == 7 then
    return 21000
  else
    return 42000
  end
end

function Wishlist:UpdateItems()
	-- Check each item
	local isChanged = false
	local item, value
	for item, value in pairs(self.Data.Items) do
		local count = GetItemCount(item, true)

		if value ~= count then
			self.Data.Items[item] = count

			if self.db.profile.Settings.ShowItemsChanges then
				self:Print((L["Items"]):format(item, count))
			end

			isChanged = true
		end
	end

	-- Check wished items
	isChanged = isChanged or self:CheckForItems(self.db.char.Items)
	
	-- Check from sets
	local index, set
	for index, set in ipairs(self.db.char.Sets) do
		isChanged = isChanged or self:CheckForItems(set.Items)
	end

	return isChanged
end

function Wishlist:UpdateTotals()
	-- Reset totals
	self.Totals = { Requirements = {} }

	-- Combine them
	self:UpdateTotalsFromGroup(self.db.char.Items)
	
	-- Combine from different sets
	local index, set
	for index, set in ipairs(self.db.char.Sets) do
		self:UpdateTotalsFromGroup(set.Items)
	end
end

function Wishlist:UpdateTotalsFromGroup(items)
	local index, item
	for index, item in ipairs(items) do
		self:CombineRequirements(self.Totals.Requirements, item.Requirements)
	end
end

----------------------
--- Event Handlers ---
----------------------

function Wishlist:BAG_UPDATE()
	if self:UpdateItems() then
		self:Update()
	end
end

function Wishlist:HONOR_CURRENCY_UPDATE()
	-- Keep honor
	self.Data.Honor = GetHonorCurrency()
	self:PrintHonor()
	self:Update()
end

function Wishlist:PLAYER_MONEY()
	-- Keep money
	self.Data.Money = GetMoney()
	self:PrintMoney()
	self:Update()
end

function Wishlist:UPDATE_FACTION()
	-- Keep faction reputation
	for factionIndex = 1, GetNumFactions() do
		local name, _, standingId, _, _, earnedValue, _, _, isHeader = GetFactionInfo(factionIndex)
		if not isHeader then
			self.Data.Factions[name] = { Standing = standingId, EarnedValue = earnedValue }
		end
	end
	self:Update()
end

-------------------------
--- AtlasLoot Methods ---
-------------------------

function Wishlist:BuildFromAtlasLoot(atlasDataPVP, atlasDataPVE)
  local unitClass = select(2, UnitClass('player'))
  unitClass = string.sub(unitClass, 1, 1)..string.lower(string.sub(unitClass, 2))
  local LocalUnitClass = UnitClass('player')

  local pvp = {}
  local pve = {}

  self:ExtractAtlasLootItems(pvp, L['Outland Reputation'], atlasDataPVP['PVP70Rep' .. unitClass])
  self:ExtractAtlasLootItems(pvp, L['Arena S2 - '] .. LocalUnitClass, atlasDataPVP['Arena2' .. unitClass])
  self:ExtractAtlasLootItems(pvp, L['Arena S2 - Weapons 1'], atlasDataPVP.Arena2Weapons1)
  self:ExtractAtlasLootItems(pvp, L['Arena S2 - Weapons 2'], atlasDataPVP.Arena2Weapons2)
  self:ExtractAtlasLootItems(pvp, L['Arena S3 - '] .. LocalUnitClass, atlasDataPVP['Arena3' .. unitClass])
  self:ExtractAtlasLootItems(pvp, L['Arena S3 - Weapons 1'], atlasDataPVP.Arena3Weapons1)
  self:ExtractAtlasLootItems(pvp, L['Arena S3 - Weapons 2'], atlasDataPVP.Arena3Weapons2)
  self:ExtractAtlasLootItems(pvp, L['Arena S4 - '] .. LocalUnitClass, atlasDataPVP['Arena4' .. unitClass])
  self:ExtractAtlasLootItems(pvp, L['Arena S4 - Weapons 1'], atlasDataPVP.Arena4Weapons1)
  self:ExtractAtlasLootItems(pvp, L['Arena S4 - Weapons 2'], atlasDataPVP.Arena4Weapons2)
  self:ExtractAtlasLootItems(pvp, L['Lvl70 Non-Set Epics 1'], atlasDataPVP.PvP70NonSet1)
  self:ExtractAtlasLootItems(pvp, L['Lvl70 Non-Set Epics 2'], atlasDataPVP.PvP70NonSet2)
  self:ExtractAtlasLootItems(pvp, L['Lvl70 Non-Set Epics 3'], atlasDataPVP.PvP70NonSet3)
  self:ExtractAtlasLootItems(pvp, L['Lvl70 Non-Set Epics 4'], atlasDataPVP.PvP70NonSet4)
  self:ExtractAtlasLootItems(pvp, L['Lvl70 Non-Set Epics 5'], atlasDataPVP.PvP70NonSet5)
  
  self:ExtractAtlasLootItems(pve, L['Lvl 70 Instance Token Rewards - Accessories 1'], atlasDataPVE.HardModeAccessories)
  self:ExtractAtlasLootItems(pve, L['Lvl 70 Instance Token Rewards - Accessories 2'], atlasDataPVE.HardModeAccessories2)
  self:ExtractAtlasLootItems(pve, L['Lvl 70 Instance Token Rewards - Veteran Armor 1'], atlasDataPVE.HardModeArena)
  self:ExtractAtlasLootItems(pve, L['Lvl 70 Instance Token Rewards - Veteran Armor 2'], atlasDataPVE.HardModeArena2)
  self:ExtractAtlasLootItems(pve, L['Lvl 70 Instance Token Rewards - Cloaks'], atlasDataPVE.HardModeCloaks)
  self:ExtractAtlasLootItems(pve, L['Lvl 70 Instance Token Rewards - Cloth'], atlasDataPVE.HardModeCloth)
  self:ExtractAtlasLootItems(pve, L['Lvl 70 Instance Token Rewards - Leather 1'], atlasDataPVE.HardModeLeather)
  self:ExtractAtlasLootItems(pve, L['Lvl 70 Instance Token Rewards - Leather 2'], atlasDataPVE.HardModeLeather2)
  self:ExtractAtlasLootItems(pve, L['Lvl 70 Instance Token Rewards - Mail'], atlasDataPVE.HardModeMail)
  self:ExtractAtlasLootItems(pve, L['Lvl 70 Instance Token Rewards - Plate 1'], atlasDataPVE.HardModePlate)
  self:ExtractAtlasLootItems(pve, L['Lvl 70 Instance Token Rewards - Plate 2'], atlasDataPVE.HardModePlate2)
  self:ExtractAtlasLootItems(pve, L['Lvl 70 Instance Token Rewards - Relics'], atlasDataPVE.HardModeRelic)
  self:ExtractAtlasLootItems(pve, L['Lvl 70 Instance Token Rewards - Fire Prot. Gears'], atlasDataPVE.HardModeResist)
  self:ExtractAtlasLootItems(pve, L['Lvl 70 Instance Token Rewards - Weapons'], atlasDataPVE.HardModeWeapons)

  local atlasMenu = {
    { type = 'group', name = L['PvP'], desc = L['PvP'], order = 1, args = pvp },
    { type = 'group', name = L['PvE'], desc = L['PvE'], order = 2, args = pve },
  }

  self.AtlasMenu = { type = 'group', name = L['Import from AtlasLoot'], desc = L['Import from AtlasLoot'], order = 1000, args = atlasMenu }
end

function Wishlist:ExtractAtlasLootItems(menuArgs, name, atlasPart)
  local args = {}
  local index = 1
  local _, part
  for _, part in ipairs(atlasPart) do
    local id = part[1]
    if id ~= 0 then
	    local name, link, _, _, _, _, _, _, _, texture = GetItemInfo(id)
	    if name then
	      local requirements = {}
	      local atlasReq = part[5]
	      if atlasReq then
	        fields = {}
	        atlasReq:gsub("[^ ]+", function(c) table.insert(fields, c) end)
	        self:ExtractAtlasLootRequirements(requirements, fields[1], fields[2])
	        self:ExtractAtlasLootRequirements(requirements, fields[3], fields[4])
	      end
        -- TODO: Requirements in description
    	  table.insert(args, { type = 'execute', name = link, desc = name, order = index, icon = texture, func = function() self:AddNewItem({ ItemId = id, Requirements = requirements }, link) end })
    	  index = index + 1
      end
    end
  end

  if #args > 0 then
    table.insert(menuArgs, { type = 'group', name = name, desc = name, order = #menuArgs + 1, args = args })
  end
end

function Wishlist:ExtractAtlasLootRequirements(requirements, req1, req2)
  if req1 and req2 then
    if req2 == '#faction#' or req2 == '#' .. strlower(UnitFactionGroup('player')) .. '#' then
      table.insert(requirements, { Type = 'Honor', Honor = tonumber(req1) })
    elseif req2 == '#arena#' then
      table.insert(requirements, { Type = 'Arena', ArenaPoints = tonumber(req1) })
    elseif req2 == '#av#' then
      table.insert(requirements, { Type = 'Item', Name = L['Alterac Valley Mark of Honor'], Required = tonumber(req1) })
    elseif req2 == '#ab#' then
      table.insert(requirements, { Type = 'Item', Name = L['Arathi Basin Mark of Honor'], Required = tonumber(req1) })
    elseif req2 == '#wsg#' then
      table.insert(requirements, { Type = 'Item', Name = L['Warsong Gulch Mark of Honor'], Required = tonumber(req1) })
    elseif req2 == '#eos#' then
      table.insert(requirements, { Type = 'Item', Name = L['Eye of the Storm Mark of Honor'], Required = tonumber(req1) })
     elseif req2 == '#heroic#' then
      table.insert(requirements, { Type = 'Item', Name = L['Badge of Justice'], Required = tonumber(req1) })
    end
    -- TODO: Reputation...
  end
end

-----------------------
--- Options Methods ---
-----------------------

self.ItemsMenu = {}
self.Options = {
	type = 'group',
	args = {
		Items = { type = 'group', name = L['Options Items'], desc = L['Options Items'], order = 1, args = self.ItemsMenu },
		Settings = {
			type = 'group', name = L['Options Settings'], desc = L['Options Settings'], order = 2, args = {
				Text = {
					type = 'group', name = L['Options Text'], desc = L['Options Text'], order = 1, args = {
						ShowMoney = { type = 'toggle', name = L['Show Money'], desc = L['Show Money'], get = 'IsShowingMoney', set = 'ToggleShowMoney' },
					},
				},
				ShowMoneyChanges = { type = 'toggle', name = L['Show Money Changes'], desc = L['Show Money Changes'], get = 'IsShowingMoneyChanges', set = 'ToggleShowMoneyChanges' },
				ShowHonorChanges = { type = 'toggle', name = L['Show Honor Changes'], desc = L['Show Honor Changes'], get = 'IsShowingHonorChanges', set = 'ToggleShowHonorChanges' },
				ShowItemsChanges = { type = 'toggle', name = L['Show Items Changes'], desc = L['Show Items Changes'], get = 'IsShowingItemsChanges', set = 'ToggleShowItemsChanges' },
				ShowNeeded = { type = 'toggle', name = L['Show Needed'], desc = L['Show Needed'], get = 'IsShowingNeeded', set = 'ToggleShowNeeded' },
				ShowAll = { type = 'toggle', name = L['Show All'], desc = L['Show All'], get = 'IsShowingAll', set = 'ToggleShowAll' },
			},
		},
	}
}

function Wishlist:RegisterMenu()
	self:UpdateItemsMenu()

	self:RegisterChatCommand({'/wishlist', '/wl'}, self.Options)
	self.OnMenuRequest = self.Options
end

function Wishlist:BuildCustom(item)
	local items = {}
	local name, _
	local index = 1
	for name, _ in pairs(self.Data.Items) do
		local shortName = self:GetShortName(name)
		table.insert(items, {
			type = 'text',
			name = shortName,
			desc = name,
			usage = name,
			icon = self.Textures[name],
			order = index,
			get = false,
			set = function(v) self:AddRequirements(item, { { Type = 'Item', Name = name, Required = tonumber(v) } }) end,
		})

		index = index + 1
	end

	local factions = {}
	local factionValidate = { [0] = self.StandingText[5], [1] = self.StandingText[6], [2] = self.StandingText[7], [3] = self.StandingText[8] }
	for index, name in ipairs(self.Factions) do
		table.insert(factions, {
			type = 'text',
			name = name,
			desc = name,
			usage = name,
			validate = factionValidate,
			order = index,
			get = false,
			set = function(v) self:AddRequirements(item, { { Type = 'Faction', Faction = name, Standing = self:StandingTextToValue(v) } }) end,
		})
	end

	return {
		{
			type = 'text',
			name = L['Honor'],
			desc = L['Honor'],
			usage = L['Honor'],
			order = 1,
			icon = self.Textures.Honor,
			get = false,
			set = function(v) self:AddRequirements(item, { { Type = 'Honor', Honor = tonumber(v) } }) end,
		},
		{
			type = 'text',
			name = L['Arena Points'],
			desc = L['Arena Points'],
			usage = L['Arena Points'],
			order = 2,
			icon = self.Textures.ArenaPoints,
			get = false,
			set = function(v) self:AddRequirements(item, { { Type = 'Arena', ArenaPoints = tonumber(v) } }) end,
		},
		{
			type = 'text',
			name = L['Money (copper)'],
			desc = L['Money (copper)'],
			usage = L['Money (copper)'],
			order = 3,
			icon = self.Textures.Money,
			get = false,
			set = function(v) self:AddRequirements(item, { { Type = 'Money', Money = tonumber(v) } }) end,
		},
		{
			type = 'group',
			name = L['Options Items'],
			desc = L['Options Items'],
			order = 4,
			args = items,
		},
		{
			type = 'group',
			name = L['Factions'],
			desc = L['Factions'],
			order = 5,
			args = factions,
		},
		{
			type = 'text',
			name = L['Note'],
			desc = L['Note'],
			usage = L['Note'],
			order = 6,
			get = false,
			set = function(v) self:AddRequirements(item, { { Type = 'Note', Note = v } }) end,
		},
	}
end

function Wishlist:BuildPredefined(item, list)
	list = list or data.Predefined

	local result = {}
	local index, predefined
	for index, predefined in ipairs(list) do
		local args = predefined.Args
		if args then
			table.insert(result, { type = 'group', name = predefined.Name, desc = predefined.Name, order = index, icon = predefined.Icon, args = self:BuildPredefined(item, args) })
		else
			table.insert(result, { type = 'execute', name = predefined.Name, desc = predefined.Name, order = index, icon = predefined.Icon, func = function() self:AddRequirements(item, predefined.Requirements) end })
		end
	end

	return result
end

function Wishlist:UpdateAddToItemsMenu(items, menu, set)
	local index, item
	for index, item in ipairs(items) do
		local itemName, _, _, _, _, _, _, _, _, itemTexture = GetItemInfo(item.ItemId)
		itemName = itemName or L['Not Found']
		
		local itemMenu = {}
		local reqIndex, req
		for reqIndex, req in ipairs(item.Requirements) do
			local reqString, icon = self:RequirementToString(req)
			table.insert(itemMenu, {
				type = 'group',
				name = reqString,
				desc = reqString,
				icon = icon,
				order = reqIndex,
				args = {
					RemoveRequirement = {
						type = 'execute',
						name = L['Remove'],
						desc = L['Remove'],
						order = 2,
						func = function() self:RemoveRequirement(item, reqIndex) end,
					},
				},
			})
		end
		
		table.insert(itemMenu, {
			type = 'group',
			name = L['Add Custom'],
			desc = L['Add Custom'],
			order = 997,
			args = self:BuildCustom(item),
		})
		table.insert(itemMenu, {
			type = 'group',
			name = L['Add Predefined'],
			desc = L['Add Predefined'],
			order = 998,
			args = self:BuildPredefined(item),
		})
		table.insert(itemMenu, {
			type = 'execute',
			name = L['Remove Item'],
			desc = L['Remove Item'],
			order = 999,
			func = function() self:RemoveItem(items, index) end,
		})
		if set and #self.db.char.Sets > 1 or #self.db.char.Sets > 0 then
      local moveOptions = {}
 	    local setIndex, otherSet
	    for setIndex, otherSet in ipairs(self.db.char.Sets) do
	      if otherSet ~= set then
	        table.insert(moveOptions, {
	          type = 'execute',
	          name = otherSet.Name,
	          desc = otherSet.Name,
	          order = setIndex,
	          func = function() self:MoveItem(items, index, otherSet.Items) end,
	        })
	      end
	    end
	    if set then
	        table.insert(moveOptions, {
	          type = 'execute',
	          name = (L['Remove from %s']):format(set.Name),
	          desc = (L['Remove from %s']):format(set.Name),
	          order = 999,
	          func = function() self:MoveItem(items, index, self.db.char.Items) end,
	        })
	    end
     table.insert(itemMenu, { type = 'group', name = L['Move to Set'], desc = L['Move to Set'], order = 1000, args = moveOptions })
		end
		table.insert(menu, { type = 'group', name = itemName, desc = itemName, order = index, icon = itemTexture, args = itemMenu })
	end
end

function Wishlist:UpdateItemsMenu()
  -- Remove everything
	while #self.ItemsMenu > 0 do table.remove(self.ItemsMenu) end
	self.ItemsMenu = {} -- TEMP: Don't know how to remove Set menu items

	-- Add items not in set
	self:UpdateAddToItemsMenu(self.db.char.Items, self.ItemsMenu)
		
	-- Add sets with items
	local itemsCount = #self.db.char.Items
	local index, set
	for index, set in ipairs(self.db.char.Sets) do
	  local setMenu = {}
	  self:UpdateAddToItemsMenu(set.Items, setMenu, set)
	  
	  -- Add commands
	  setMenu.Add = { type = 'text', name = L['Add Item'], desc = L['Add Item'], usage = L['Add Item'], get = false, set = function(v) self:AddItem(v, set.Items) end, order = 999 }
	  setMenu.Remove = { type = 'execute', name = L['Remove Set'], desc = L['Remove Set'], func = function() self:RemoveSet(index) end, order = 1000 }
	  
	  -- Add to menu
	  self.ItemsMenu[set.Name] = { type = 'group', name = set.Name, desc = set.Name, order = index + itemsCount, args = setMenu }
	end

	-- Add New Item Menu
	self.ItemsMenu.Add = { type = 'text', name = L['Add Item'], desc = L['Add Item'], usage = L['Add Item'], get = false, set = 'AddItem', order = 999 }

	-- AtlasLoot hook
	if self.AtlasMenu then
	  table.insert(self.ItemsMenu, self.AtlasMenu)
	end
	
	self.ItemsMenu.AddSet = { type = 'text', name = L['Add Set'], desc = L['Add Set'], usage = L['Add Set'], get = false, set = 'AddSet', order = 1999 }
	
	self.Options.args.Items.args = self.ItemsMenu
end

function Wishlist:IsShowingAll()
	return self.db.profile.Settings.ShowAll
end
function Wishlist:IsShowingHonorChanges()
	return self.db.profile.Settings.ShowHonorChanges
end

function Wishlist:IsShowingItemsChanges()
	return self.db.profile.Settings.ShowItemsChanges
end

function Wishlist:IsShowingMoney()
	return self.db.profile.Text.ShowMoney
end

function Wishlist:IsShowingMoneyChanges()
	return self.db.profile.Settings.ShowMoneyChanges
end

function Wishlist:IsShowingNeeded()
	return self.db.profile.Settings.ShowNeeded
end

function Wishlist:ToggleShowAll()
	self.db.profile.Settings.ShowAll = not self.db.profile.Settings.ShowAll
	self:OnDataUpdate()
	return self.db.profile.Settings.ShowAll
end

function Wishlist:ToggleShowHonorChanges()
	self.db.profile.Settings.ShowHonorChanges = not self.db.profile.Settings.ShowHonorChanges
	self:PrintHonor()
	return self.db.profile.Settings.ShowHonorChanges
end

function Wishlist:ToggleShowItemsChanges()
	self.db.profile.Settings.ShowItemsChanges = not self.db.profile.Settings.ShowItemsChanges
	self:PrintItems()
	return self.db.profile.Settings.ShowItemsChanges
end
function Wishlist:ToggleShowMoney()
	self.db.profile.Text.ShowMoney = not self.db.profile.Text.ShowMoney
	self:OnTextUpdate()
	return self.db.profile.Text.ShowMoney
end

function Wishlist:ToggleShowMoneyChanges()
	self.db.profile.Settings.ShowMoneyChanges = not self.db.profile.Settings.ShowMoneyChanges
	self:PrintMoney()
	return self.db.profile.Settings.ShowMoneyChanges
end

function Wishlist:ToggleShowNeeded()
	self.db.profile.Settings.ShowNeeded = not self.db.profile.Settings.ShowNeeded
	return self.db.profile.Settings.ShowNeeded
end