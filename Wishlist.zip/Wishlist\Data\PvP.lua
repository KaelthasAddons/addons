WishlistData = WishlistData or { Predefined = {} }
local data = WishlistData
local L = AceLibrary('AceLocale-2.2'):new('Wishlist')

table.insert(data.Predefined, {
	Name = 'PvP',
	Args = {
		{
			Name = L['Arena S2'],
			Args = {
				{
					Name = L['Head  |cffcccccc(14500H, 30AV)'],
					Requirements = {
						{ Type = 'Honor', Honor = 14500 },
						{ Type = 'Item', Name = L['Alterac Valley Mark of Honor'], Required = 30 },
					},
				},
				{
					Name = L['Shoulder  |cffcccccc(11250H, 20AB)'],
					Requirements = {
						{ Type = 'Honor', Honor = 11250 },
						{ Type = 'Item', Name = L['Arathi Basin Mark of Honor'], Required = 20 },
					},
				},
				{
					Name = L['Chest  |cffcccccc(14500H, 30AB)'],
					Requirements = {
						{ Type = 'Honor', Honor = 14500 },
						{ Type = 'Item', Name = L['Arathi Basin Mark of Honor'], Required = 30 },
					},
				},
				{
					Name = L['Hands  |cffcccccc(10500H, 20AV)'],
					Requirements = {
						{ Type = 'Honor', Honor = 10500 },
						{ Type = 'Item', Name = L['Alterac Valley Mark of Honor'], Required = 20 },
					},
				},
				{
					Name = L['Legs  |cffcccccc(14500H, 30WSG)'],
					Requirements = {
						{ Type = 'Honor', Honor = 14500 },
						{ Type = 'Item', Name = L['Warsong Gulch Mark of Honor'], Required = 30 },
					},
				},
				{
					Name = L['Two Hand/Bow  |cffcccccc(17000H, 40AV)'],
					Requirements = {
						{ Type = 'Honor', Honor = 17000 },
						{ Type = 'Item', Name = L['Alterac Valley Mark of Honor'], Required = 40 },
					},
				},
				{
					Name = L['Main Hand  |cffcccccc(25200H, 20EotS)'],
					Requirements = {
						{ Type = 'Honor', Honor = 25200 },
						{ Type = 'Item', Name = L['Eye of the Storm Mark of Honor'], Required = 20 },
					},
				},
				{
					Name = L['One-Hand  |cffcccccc(18000H, 20EotS)'],
					Requirements = {
						{ Type = 'Honor', Honor = 18000 },
						{ Type = 'Item', Name = L['Eye of the Storm Mark of Honor'], Required = 20 },
					},
				},
				{
					Name = L['Off Hand  |cffcccccc(9000H, 20EotS)'],
					Requirements = {
						{ Type = 'Honor', Honor = 9000 },
						{ Type = 'Item', Name = L['Eye of the Storm Mark of Honor'], Required = 20 },
					},
				},
				{
					Name = L['Held In Off Hand  |cffcccccc(9000H, 20EotS)'],
					Requirements = {
						{ Type = 'Honor', Honor = 9000 },
						{ Type = 'Item', Name = L['Eye of the Storm Mark of Honor'], Required = 20 },
					},
				},
				{
					Name = L['Wand/Relic  |cffcccccc(8000H, 10EotS)'],
					Requirements = {
						{ Type = 'Honor', Honor = 8000 },
						{ Type = 'Item', Name = L['Eye of the Storm Mark of Honor'], Required = 10 },
					},
				},
			},
		},
		
		{
			Name = L['Arena S3'],
			Args = {
				{
					Name = L['Head/Chest/Legs  |cffcccccc(1630AP)'],
					Requirements = { { Type = 'Arena', ArenaPoints = 1630 } },
				},
				{
					Name = L['Shoulders  |cffcccccc(1304AP)'],
					Requirements = { { Type = 'Arena', ArenaPoints = 1304 } },
				},
				{
					Name = L['Hands  |cffcccccc(978AP)'],
					Requirements = { { Type = 'Arena', ArenaPoints = 978 } },
				},
				{
					Name = L['Two Hand/Bow  |cffcccccc(3261AP)'],
					Requirements = { { Type = 'Arena', ArenaPoints = 3261 } },
				},
				{
					Name = L['Main Hand  |cffcccccc(2739AP)'],
					Requirements = { { Type = 'Arena', ArenaPoints = 2739 } },
				},
				{
					Name = L['One-Hand  |cffcccccc(2283AP)'],
					Requirements = { { Type = 'Arena', ArenaPoints = 2283 } },
				},
				{
					Name = L['Off Hand  |cffcccccc(1630AP)'],
					Requirements = { { Type = 'Arena', ArenaPoints = 1630 } },
				},
				{
					Name = L['Held In Off Hand  |cffcccccc(978AP)'],
					Requirements = { { Type = 'Arena', ArenaPoints = 978 } },
				},
				{
					Name = L['Wand/Relic  |cffcccccc(870AP)'],
					Requirements = { { Type = 'Arena', ArenaPoints = 870 } },
				},
				{
					Name = L['Hunter Two-Handed Axe  |cffcccccc(870AP)'],
					Requirements = { { Type = 'Arena', ArenaPoints = 870 } },
				},
			},
		},
		
		{
			Name = L['Arena S4'],
			Args = {
				{
					Name = L['Head/Chest/Legs  |cffcccccc(1875AP)'],
					Requirements = { { Type = 'Arena', ArenaPoints = 1875 } },
				},
				{
					Name = L['Shoulders  |cffcccccc(1500AP)'],
					Requirements = { { Type = 'Arena', ArenaPoints = 1500 } },
				},
				{
					Name = L['Hands  |cffcccccc(1125AP)'],
					Requirements = { { Type = 'Arena', ArenaPoints = 1125 } },
				},
				{
					Name = L['Two Hand/Bow  |cffcccccc(3750AP)'],
					Requirements = { { Type = 'Arena', ArenaPoints = 3750 } },
				},
				{
					Name = L['Main Hand  |cffcccccc(3150AP)'],
					Requirements = { { Type = 'Arena', ArenaPoints = 3150 } },
				},
				{
					Name = L['One-Hand  |cffcccccc(2625AP)'],
					Requirements = { { Type = 'Arena', ArenaPoints = 2625 } },
				},
				{
					Name = L['Off Hand  |cffcccccc(1875AP)'],
					Requirements = { { Type = 'Arena', ArenaPoints = 1875 } },
				},
				{
					Name = L['Held In Off Hand  |cffcccccc(1125AP)'],
					Requirements = { { Type = 'Arena', ArenaPoints = 1125 } },
				},
				{
					Name = L['Wand/Relic  |cffcccccc(1000AP)'],
					Requirements = { { Type = 'Arena', ArenaPoints = 1000 } },
				},
				{
					Name = L['Hunter Main Hand Axe  |cffcccccc(1000AP)'],
					Requirements = { { Type = 'Arena', ArenaPoints = 1000 } },
				},
				{
					Name = L['Hunter Off Hand Axe  |cffcccccc(1000AP)'],
					Requirements = { { Type = 'Arena', ArenaPoints = 1000 } },
				},
			},
		},
		
		{
			Name = L['S2/3 Non-Set Epics'],
			Args = {
				{
					Name = L['Wrist  |cffcccccc(9199H, 20WSG)'],
					Requirements = {
						{ Type = 'Honor', Honor = 9199 },
						{ Type = 'Item', Name = L['Warsong Gulch Mark of Honor'], Required = 20 },
					},
				},
				{
					Name = L['Waist  |cffcccccc(13923H, 40AB)'],
					Requirements = {
						{ Type = 'Honor', Honor = 13923 },
						{ Type = 'Item', Name = L['Arathi Basin Mark of Honor'], Required = 40 },
					},
				},
				{
					Name = L['Feet  |cffcccccc(13923H, 40EotS)'],
					Requirements = {
						{ Type = 'Honor', Honor = 13923},
						{ Type = 'Item', Name = L['Eye of the Storm Mark of Honor'], Required = 40 },
					},
				},
				{
					Name = L['Back  |cffcccccc(7548H, 20AB)'],
					Requirements = {
						{ Type = 'Honor', Honor = 7548 },
						{ Type = 'Item', Name = L['Arathi Basin Mark of Honor'], Required = 20 },
					},
				},
				{
					Name = L['Neck  |cffcccccc(11934H, 10EotS)'],
					Requirements = {
						{ Type = 'Honor', Honor = 11934 },
						{ Type = 'Item', Name = L['Eye of the Storm Mark of Honor'], Required = 10 },
					},
				},
				{
					Name = L['Vindicator Ring  |cffcccccc(11934H, 10AV)'],
					Requirements = {
						{ Type = 'Honor', Honor = 11934 },
						{ Type = 'Item', Name = L['Alterac Valley Mark of Honor'], Required = 10 },
					},
				},
			},
		},

		{
			Name = L['S4 Non-Set Epics'],
			Args = {
				{
					Name = L['Wrist  |cffcccccc(11794H, 20WSG)'],
					Requirements = {
						{ Type = 'Honor', Honor = 11794 },
						{ Type = 'Item', Name = L['Warsong Gulch Mark of Honor'], Required = 20 },
					},
				},
				{
					Name = L['Waist  |cffcccccc(17850H, 40AB)'],
					Requirements = {
						{ Type = 'Honor', Honor = 17850 },
						{ Type = 'Item', Name = L['Arathi Basin Mark of Honor'], Required = 40 },
					},
				},
				{
					Name = L['Feet  |cffcccccc(17850H, 40EotS)'],
					Requirements = {
						{ Type = 'Honor', Honor = 17850 },
						{ Type = 'Item', Name = L['Eye of the Storm Mark of Honor'], Required = 40 },
					},
				},
				{
					Name = L['Neck  |cffcccccc(15300H, 10EotS)'],
					Requirements = {
						{ Type = 'Honor', Honor = 15300 },
						{ Type = 'Item', Name = L['Eye of the Storm Mark of Honor'], Required = 10 },
					},
				},
				{
					Name = L['Guardian Ring  |cffcccccc(15300H, 10AV)'],
					Requirements = {
						{ Type = 'Honor', Honor = 15300 },
						{ Type = 'Item', Name = L['Alterac Valley Mark of Honor'], Required = 10 },
					},
				},
			},
		},
	},
})