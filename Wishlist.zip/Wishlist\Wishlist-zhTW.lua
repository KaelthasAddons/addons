local L = AceLibrary("AceLocale-2.2"):new("Wishlist")

L:RegisterTranslations("zhTW", function() return {
	["|cFFFF0000Loaded!"] = "|cFFFF0000已載入！",
	
	['Factions'] = "陣營",
	["Faction %s not found"] = "未找到陣營%s",
	
	['Money'] = "金錢",
	["Money: %s"] = "金錢：%s",
	['Honor'] = "榮譽",
	["Honor: %d"] = "榮譽：%d",
	["Items"] = "%s: %d",
	['Arena Points'] = "競技場點數",
	
	["Watched Items"] = "已監視物品",
	
	["You got item %s, congratulations!"] = "你可以取得%s了，恭喜！",
	
	-- Options
	
	["Options Settings"] = "設定選項",
	["Show Money Changes"] = "顯示金錢變化",
	["Show Honor Changes"] = "顯示榮譽變化",
	["Show Items Changes"] = "顯示物品變化",
	['Show Needed'] = "顯示所需",
	
	["Options Text"] = "文字設定",
	["Show Money"] = "顯示金錢",
	['Money (copper)'] = "金錢 (銅幣)",
	['Note'] = "備註",
	
	["Options Items"] = "物品設定",
	["Add Item"] = "加入物品",
	["Add Custom"] = "加入自訂",
	["Add Predefined"] = "加入預定物品",
	['PvP'] = "PvP",
	['PvE'] = "PvE",
	["Requirements"] = "需求",
	["Remove"] = "移除",
	["Remove Item"] = "移除物品",
	['Move to Set'] = "移動到套裝",
	['Import from AtlasLoot'] = "從 AtlasLoot 匯入",
	['Add Set'] = "加入套裝",
	['Remove Set'] = "移除套裝",
	['Remove from %s'] = "從%s移除",
	
	["Added %s to watch list"] = "將%s加入到監視清單",
	['Removed %s from watch list'] = "將%s從監視清單移除",
	
	-- Validate
	["%d honor"] = "%d榮譽點數",
	["%d Arena Point(s)"] = "%d競技場點數",
	["%dx %s"] = "%dx%s",
	['%s|r with %s'] = "%s|r和%s",
	
	-- Tooltip
	['|cffffffffAdd items first'] = "|cffffffff請先新增物品",
	['|cffffffffGot everything!'] = "'|cffffffff一切就緒！",
	['Need'] = "需要",
	['Got'] = "已得到",
	['Done'] = "完成",
	['|cffffffffTotal'] = "|cffffffff全部",
	['%s|r |cffffffff(%d)'] = "%s|r |cffffffff(%d)",
	['%s, you got everything!'] = "%s，你全準備好了！",
	['%s, you need %s.'] = "%s，你還需要%s",

	['Not Found'] = "未找到",

	-- PVE Presets
	['Sunwell  |cffcccccc(Badge of Justice)'] = "太陽之井 |cffcccccc(正義徽章)",
	['Badge of Justice'] = "正義徽章",
	['Two-Hand/Main Hand/Bow  |cffcccccc(150)'] = "雙手/主手/遠程 |cffcccccc (150)",
	['One Hand  |cffcccccc(105)'] = "單手 |cffcccccc (105)",
	['Chest/Legs  |cffcccccc(100)'] = "胸部/腿部 |cffcccccc (100)",
	['Hands/Waist/Feet  |cffcccccc(75)'] = "手套/腰帶/鞋 |cffcccccc (75)",
	['Ring  |cffcccccc(60)'] = "戒指 |cffcccccc (60)",
	['Off Hand  |cffcccccc(45)'] = "副手 |cffcccccc (45)",
	['Mounts'] = "坐騎",
	['Riding Nether Ray  |cffcccccc(200g)'] = "虛空鰭刺坐騎 |cffcccccc (200G)",
	["Sha'tari Skyguard"] = "薩塔禦天者",
	['Cenarion War Hippogryph  |cffcccccc(1600g)'] = "塞納里奧戰爭角鷹獸 |cffcccccc (1600G)",
	["Cenarion Expedition"] = "塞納里奧遠征隊",

	--PVP Presets
	['Arena S2'] = "競技場第二季",

	['Alterac Valley Mark of Honor'] = "奧特蘭克山谷榮譽獎章",
	['Warsong Gulch Mark of Honor'] = "戰歌峽谷榮譽獎章",
	['Arathi Basin Mark of Honor'] = "阿拉希盆地榮譽獎章",
	['Eye of the Storm Mark of Honor'] = "暴風之眼榮譽獎章",
	['Head  |cffcccccc(14500H, 30AV)'] = "頭部 |cffcccccc (14500榮譽，30奧山)",
	['Shoulder  |cffcccccc(11250H, 20AB)'] = "肩部 |cffcccccc (11250榮譽，20阿拉希)",
	['Chest  |cffcccccc(14500H, 30AB)'] = "胸部 |cffcccccc (14500榮譽，30阿拉希)",
	['Hands  |cffcccccc(10500H, 20AV)'] = "手套 |cffcccccc (10500榮譽，20奧山)",
	['Legs  |cffcccccc(14500H, 30WSG)'] = "腿部 |cffcccccc (14500榮譽，30戰歌)",
	['Two Hand/Bow  |cffcccccc(17000H, 40AV)'] = "雙手/遠程 |cffcccccc (17000榮譽，40奧山)",
	['Main Hand  |cffcccccc(25200H, 20EotS)'] = "主手 |cffcccccc (25200榮譽，20暴風)",
	['One-Hand  |cffcccccc(18000H, 20EotS)'] = "單手 |cffcccccc (18000榮譽，20暴風)",
	['Off Hand  |cffcccccc(9000H, 20EotS)'] = "副手 |cffcccccc (9000榮譽，20暴風)",
	['Held In Off Hand  |cffcccccc(9000H, 20EotS)'] = "副手物品 |cffcccccc (9000榮譽，20暴風)",
	['Wand/Relic  |cffcccccc(8000H, 10EotS)'] = "魔杖/聖物 |cffcccccc (8000榮譽，10暴風)",

	['Arena S3'] = "競技場第三季",

	['Head/Chest/Legs  |cffcccccc(1630AP)'] = "頭部/胸部/腿部 |cffcccccc (1630點數)",
	['Shoulders  |cffcccccc(1304AP)'] = "肩部 |cffcccccc (1304點數)",
	['Hands  |cffcccccc(978AP)'] = "手套 |cffcccccc (978點數)",
	['Two Hand/Bow  |cffcccccc(3261AP)'] = "雙手/遠程 |cffcccccc (3261點數)",
	['Main Hand  |cffcccccc(2739AP)'] = "主手 |cffcccccc (2739點數)",
	['One-Hand  |cffcccccc(2283AP)'] = "單手 |cffcccccc (2283點數)",
	['Off Hand  |cffcccccc(1630AP)'] = "副手 |cffcccccc (1630點數)",
	['Held In Off Hand  |cffcccccc(978AP)'] = "副手物品 |cffcccccc (978點數)",
	['Wand/Relic  |cffcccccc(870AP)'] = "魔杖/聖物 |cffcccccc (870點數)",
	['Hunter Two-Handed Axe  |cffcccccc(870AP)'] = "獵人雙手斧 |cffcccccc (870點數)",

	['Arena S4'] = "競技場第四季",

	['Head/Chest/Legs  |cffcccccc(1875AP)'] = "頭部/胸部/腿部 |cffcccccc (1875點數)",
	['Shoulders  |cffcccccc(1500AP)'] = "肩部 |cffcccccc (1500點數)",
	['Hands  |cffcccccc(1125AP)'] = "手套 |cffcccccc (1125點數)",
	['Two Hand/Bow  |cffcccccc(3750AP)'] = "雙手/遠程 |cffcccccc (3750點數)",
	['Main Hand  |cffcccccc(3150AP)'] = "主手 |cffcccccc (3150點數)",
	['One-Hand  |cffcccccc(2625AP)'] = "單手 |cffcccccc (2625點數)",
	['Off Hand  |cffcccccc(1875AP)'] = "副手 |cffcccccc (1875點數)",
	['Held In Off Hand  |cffcccccc(1125AP)'] = "副手物品 |cffcccccc (1125點數)",
	['Wand/Relic  |cffcccccc(1000AP)'] = "魔杖/聖物 |cffcccccc (1000點數)",
	['Hunter Main Hand Axe  |cffcccccc(1000AP)'] = "獵人主手斧 |cffcccccc (1000點數)",
	['Hunter Off Hand Axe  |cffcccccc(1000AP)'] = "獵人副手斧 |cffcccccc (1000點數)",


	['S2/3 Non-Set Epics'] = "第二/三季非套裝史詩物品",

	['Wrist  |cffcccccc(9199H, 20WSG)'] = "手腕 |cffcccccc (9199榮譽，20戰歌)",
	['Waist  |cffcccccc(13923H, 40AB)'] = "腰帶 |cffcccccc (13923榮譽，40阿拉希)",
	['Feet  |cffcccccc(13923H, 40EotS)'] = "鞋 |cffcccccc (13923榮譽，40暴風)",
	['Back  |cffcccccc(7548H, 20AB)'] = "披風 |cffcccccc (7548榮譽，20阿拉希)",
	['Neck  |cffcccccc(11934H, 10EotS)'] = "頸部 |cffcccccc (11934榮譽，10暴風)",
	['Vindicator Ring  |cffcccccc(11934H, 10AV)'] = "復仇者戒指 |cffcccccc (11934榮譽，10奧山)",

	['S4 Non-Set Epics'] = "第四季非套裝史詩物品",

	['Wrist  |cffcccccc(11794H, 20WSG)'] = "手腕 |cffcccccc (11794榮譽，20戰歌)",
	['Waist  |cffcccccc(17850H, 40AB)'] = "腰帶 |cffcccccc (17850榮譽，40阿拉希)",
	['Feet  |cffcccccc(17850H, 40EotS)'] = "鞋 |cffcccccc (17850榮譽，40暴風)",
	['Neck  |cffcccccc(15300H, 10EotS)'] = "頸部 |cffcccccc (15300榮譽，10暴風)",
	['Guardian Ring  |cffcccccc(15300H, 10AV)'] = "守衛者戒指 |cffcccccc (15300榮譽，10奧山)",

	--Factions and tokens 
	['Halaa Battle Token'] = "哈剌戰鬥徽章",
	['Halaa Research Token'] = "哈剌研究徽章",
	['WSG Mark(s)'] = "戰歌獎章",
	['AB Mark(s)'] = "阿拉希獎章",
	['AV Mark(s)'] = "奧山獎章",
	['EotS Mark(s)'] = "暴風獎章",
	['Cenarion Expedition']  = "塞納里奧遠征隊",
	['Lower City']  = "陰鬱城",
	["The Sha'tar"]  = "薩塔",
	['Keepers of Time']  = "時光守望者",
	['The Aldor']  = "奧多爾",
	['The Scryers']  = "占卜者",
	['Ashtongue Deathsworn']  = "灰舌死亡誓言者",
	['Shattered Sun Offensive'] = "破碎之日進攻部隊",
	['Frostwolf Clan'] = "霜狼氏族",
	['The Defilers'] = "污染者",
	['Warsong Outriders'] = "戰歌偵察騎兵",

	['Thrallmar'] = "索爾瑪",
	["The Mag'har"] = "瑪格哈",

	['Silverwing Sentinels'] = "銀翼哨兵",
	['Stormpike Guard'] = "雷矛衛隊",
	['The League of Arathor'] = "阿拉索聯軍",

	['Honor Hold'] = "榮譽堡",
	['Kurenai'] = "卡爾奈",

	--AtlasLoot table data
	['Outland Reputation'] = "外域聲望",
	['Arena S2 - '] = "競技場第二季 - ",
	['Arena S2 - Weapons 1'] = "競技場第二季 - 武器1",
	['Arena S2 - Weapons 2'] = "競技場第二季 - 武器2",
	['Arena S3 - '] = "競技場第三季 - ",
	['Arena S3 - Weapons 1'] = "競技場第三季 - 武器1",
	['Arena S3 - Weapons 2'] = "競技場第三季 - 武器2",
	['Arena S4 - '] = "競技場第四季 - ",
	['Arena S4 - Weapons 1'] = "競技場第四季 - 武器1",
	['Arena S4 - Weapons 2'] = "競技場第四季 - 武器2",
	['Lvl70 Non-Set Epics 1'] = "等級70非套裝史詩物品1",
	['Lvl70 Non-Set Epics 2'] = "等級70非套裝史詩物品2",
	['Lvl70 Non-Set Epics 3'] = "等級70非套裝史詩物品3",
	['Lvl70 Non-Set Epics 4'] = "等級70非套裝史詩物品4",
	['Lvl70 Non-Set Epics 5'] = "等級70非套裝史詩物品5",
	['Lvl 70 Instance Token Rewards - Accessories 1'] = "70級副本徽章獎勵 - 配件1",
	['Lvl 70 Instance Token Rewards - Accessories 2'] = "70級副本徽章獎勵 - 配件2",
	['Lvl 70 Instance Token Rewards - Veteran Armor 1'] = "70級副本徽章獎勵 - 精兵裝備1",
	['Lvl 70 Instance Token Rewards - Veteran Armor 2'] = "70級副本徽章獎勵 - 精兵裝備2",
	['Lvl 70 Instance Token Rewards - Cloaks'] = "70級副本徽章獎勵 - 披風",
	['Lvl 70 Instance Token Rewards - Cloth'] = "70級副本徽章獎勵 - 布甲",
	['Lvl 70 Instance Token Rewards - Leather 1'] = "70級副本徽章獎勵 - 皮甲1",
	['Lvl 70 Instance Token Rewards - Leather 2'] = "70級副本徽章獎勵 - 皮甲2",
	['Lvl 70 Instance Token Rewards - Mail'] = "70級副本徽章獎勵 - 鎖甲",
	['Lvl 70 Instance Token Rewards - Plate 1'] = "70級副本徽章獎勵 - 鎧甲1",
	['Lvl 70 Instance Token Rewards - Plate 2'] = "70級副本徽章獎勵 - 鎧甲2",
	['Lvl 70 Instance Token Rewards - Relics'] = "70級副本徽章獎勵 - 聖物",
	['Lvl 70 Instance Token Rewards - Fire Prot. Gears'] = "70級副本徽章獎勵 - 火焰抗性裝備",
	['Lvl 70 Instance Token Rewards - Weapons'] = "70級副本徽章獎勵 - 武器",

} end )