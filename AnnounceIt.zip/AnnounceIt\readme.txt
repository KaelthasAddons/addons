//////////////////////////////////////////////
//            * AnnounceIt *                //
//     - A World of Warcrft Addon -         //
//                giant                     //
//////////////////////////////////////////////

This addon is now uses the Ace2 libraries. AnnounceIt supports Fubar and can as well operatate as a standalone addon.
To create your first message, open the menu by right clicking on the button and selecting "Add New Message". Be sure to remane the message to a title you will recognize. Titles must be unique.

To edit your message, open the menu by right clicking on the button and open the menu of the message you wish to edit. There you will see "Edit Message". 
To Broadcast your message, select one of the channels you chose to broadcast too.  If you are using the WHISPER, you will need to have a whisper window open to whom you want to send the message to in your chat box. 

When Editing or creating a new message, be sure to select the channels you would like to select from when sending the message. To send to raid or party, use the GROUP channel. Announce it will automatically put your message in raid chat if you are in a raid and party chat if you are in a party.

I have rewritten a lot of this code since my original version, but I still would like to give thanks to authors of AnnounceText and TitanPortMenu as I have used their code and ideas as a guideline for writing this addon, which would be my first.

