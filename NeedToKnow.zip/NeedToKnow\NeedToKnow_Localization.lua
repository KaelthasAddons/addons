
--[[ If you want to be super helpful, you can translate this stuff into whatever non-enUS language you happen to know.  Email them to me and I'll credit you.  ZOMG 15 minutes of fame.  Neph <lieandswell@yahoo.com> --]]

NEEDTOKNOW = {};

-- if ( GetLocale() == "lolwut" ) then
do
	NEEDTOKNOW.BAR_TOOLTIP1 = "NeedToKnow";
	NEEDTOKNOW.BAR_TOOLTIP2 = "Right click bars to configure. More options in the Blizzard interface options menu. Type /needtoknow to lock and enable.";
	NEEDTOKNOW.RESIZE_TOOLTIP = "Click and drag to change size";

	NEEDTOKNOW.BARMENU_ENABLE = "Enable bar";
	NEEDTOKNOW.BARMENU_CHOOSENAME = "Choose buff/debuff to time";
	NEEDTOKNOW.CHOOSENAME_DIALOG = "Enter the name of the buff or debuff to time with this bar"
	NEEDTOKNOW.BARMENU_CHOOSEUNIT = "Unit to monitor";
	NEEDTOKNOW.BARMENU_PLAYER = "Player";
	NEEDTOKNOW.BARMENU_TARGET = "Target";
	NEEDTOKNOW.BARMENU_FOCUS = "Focus";
	NEEDTOKNOW.BARMENU_PET = "Pet";
	NEEDTOKNOW.BARMENU_TARGETTARGET = "Target of Target";
	NEEDTOKNOW.BARMENU_BUFFORDEBUFF = "Buff or debuff?";
	NEEDTOKNOW.BARMENU_BUFF = "Buff";
	NEEDTOKNOW.BARMENU_DEBUFF = "Debuff";
	NEEDTOKNOW.BARMENU_BARCOLOR = "Bar color";
	NEEDTOKNOW.BARMENU_CLEARSETTINGS = "Clear settings";

	NEEDTOKNOW.UIPANEL_SUBTEXT1 = "These options allow you to change the number and grouping of timer bars.";
	NEEDTOKNOW.UIPANEL_SUBTEXT2 = "Bars work when locked. When unlocked, you can move/size bar groups and right click individual bars for more settings. You can also type '/needtoknow' or '/ntk' to lock/unlock.";
	NEEDTOKNOW.UIPANEL_BARGROUP = "Group ";
	NEEDTOKNOW.UIPANEL_NUMBERBARS = "Number of bars";
	NEEDTOKNOW.UIPANEL_BARTEXTURE = "Bar texture";
	NEEDTOKNOW.UIPANEL_LOCK = "Lock AddOn";
	NEEDTOKNOW.UIPANEL_UNLOCK = "Unlock AddOn";
	NEEDTOKNOW.UIPANEL_TOOLTIP_ENABLEGROUP = "Show and enable this group of bars";
	NEEDTOKNOW.UIPANEL_TOOLTIP_BARTEXTURE = "Choose the texture graphic for timer bars";

	NEEDTOKNOW.CMD_RESET = "reset";
end

