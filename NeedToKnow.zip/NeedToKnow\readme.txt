
--------------------------------------
NeedToKnow
by Nephthys <Drunken Monkeys> of Hyjal
--------------------------------------


NeedToKnow allows you to monitor specific buffs and debuffs of your choosing as timer bars that always appear in a consistent place on your screen in a consistent color.  It's especially useful for monitoring frequently used short-duration buffs and debuffs.  For example, a rogue could configure NeedToKnow to show timer bars for Slice and Dice, Rupture, and their own stack of Deadly Poison VII.  NeedToKnow also works with procs and on-use trinkets.  The number, size, position, and color of timer bars are all customizable.  


------------
Instructions
------------

General options are available in the Blizzard interface options menu.  You can type "/needtoknow" or "/ntk" to lock/unlock the addon.  To configure individual bars, right click them while unlocked.  Bars work while locked.  

When entering your settings, be careful with your spelling and capitalization.  Also remember that buffs sometimes have different names than the abilities or items that cause them.  For example, the buff from Bloodlust Brooch is called "Lust for Battle".  


----------
To do list
----------

Add more options for graphical customization: time display format, background color/alpha, bar spacing, and bar padding. 


------------
Known issues
------------

Bars not correctly picking up refreshed buffs/debuffs on target of target.  Expected to be fixed with WoW 3.0.  


----------
Change log
----------

Version 2.0
-  Added support for monitoring debuffs
-  Added support for variable numbers of bars
-  Added support for separate groups of bars
-  Added support for monitoring buffs/debuffs on target, focus, pet, or target of target
-  Bars are now click-through while locked
-  Reminder icons have been been greatly expanded in functionality and split off into their own addon: TellMeWhen
-  Cleaner bar graphics
-  Users of older versions will need to re-enter settings 

Version 1.2
-  Updated for WoW 2.4 API changes

Version 1.1.1
-  Icons should now work properly with item cooldowns.
-  Reset button should now work properly when you first use the AddOn.

Version 1.1
-  Icons will now show when reactive abilities (Riposte, Execute, etc.) are available.  
-  Added options for bar color and texture.  
-  Added graphical user interface.  Most slash commands gone.  
-  Added localization support.  Translations would be much appreciated.  
-  Users of older version will need to re-enter settings.  

Version 1.0
-  Hello world!

