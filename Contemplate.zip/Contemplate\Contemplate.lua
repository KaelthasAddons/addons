local p = CreateFrame("Frame")
p:SetScript("OnEvent", function(self, event) return self[event] (self) end)
p:RegisterEvent("PLAYER_REGEN_ENABLED")
p:RegisterEvent("PLAYER_REGEN_DISABLED")

function p:PLAYER_REGEN_ENABLED()
	HideNameplates()
end

function p:PLAYER_REGEN_DISABLED()
	ShowNameplates()
end