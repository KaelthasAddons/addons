local AceLocale = LibStub:GetLibrary("AceLocale-3.0")
local L = AceLocale:NewLocale("EpicMusicPlayerFu", "enUS", true)
if not L then return end

-- added emp 1.4
L["Click"] = true
L["Shift+Click"] = true
L["Middle Click"] = true
L["Alt+Click"] = true
L["Alt+Ctrl+Click"] = true
--

L['Show List/Song Numbers'] = true
L['Show playlist and song number'] = true
					
L['Show Title'] = true
L['Toggle show title in fubar'] = true

L["Show time"] = true
L["Toggle show time"] = true

L["Max song text length"] = true
L["The maximum text length of the song displayed in FuBar."] = true

L["Tooltip"] = true
L["Tooltip Settings"] = true

L["Options/Hints"] = true
L["Toggle show Options/Hints in tooltip"] = true

L["Playlists"] = true
L["Toggle show playlists in tooltip"] = true

L["Spam to chat"] = true
L["Toggle show spam to chat in tooltip"] = true

L["Short Tooltip"] = true
L["Show short tooltip only artist and songname"] = true

L["Hide minimap/FuBar icon"] = true
L["Attach to minimap"] = true
L["FuBar options"] = true
L["Position"] = true
L["Left"] = true
L["Center"] = true
L["Right"] = true
L["Show text"] = true
L["Show icon"] = true


L["Music volume: "] = true
L["Effects volume: "] = true
L["Stopped"] = true

L["Artist"] = true
L["Song"] = true
L["Album"] = true
L["Length"] = true
L["Playlist"] = true
				   
L["Play a list (alt+click move song)"] = true
L["Spam to Chat:"] = true
				   
L["[Guild]"] = true
L["[Party]"] = true
L["[Say]"] = true
L["To target"] = true
L["Whisper to"] = true
L["[Raid]"] = true

L["Next song. |cff00cc00(Click)|r"] = true
L["Last song. |cff00cc00(Shift+Click)|r"] = true
L["Toggle play/stop. |cff00cc00(Middleclick)|r"] = true
L["Show Playlist. |cff00cc00(Alt+Click)|r"] = true
L["Remove Song. |cff00cc00(Alt+Ctrl+Click)|r"] = true

L["Scroll over Fubar text to adjust music volume."] = true
L["Click to play next song. Middlelick to toggle play/stop."] = true