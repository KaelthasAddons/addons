local AceLocale = LibStub:GetLibrary("AceLocale-3.0")
local L = AceLocale:NewLocale("EpicMusicPlayerFu", "deDE")
if not L then return end

-- added emp 1.4
L["Click"] = "Klick"
L["Shift+Click"] = "Umschalt+Klick"
L["Middle Click"] = "Mittelklick"
L["Alt+Click"] = "Alt+Klick"
L["Alt+Ctrl+Click)"] = "Alt+Strg+Klick"
--

L['Show List/Song Numbers'] = "Liste/Tietel Nr."
L['Show playlist and song number'] = "Liste und Tietel Nummer anzeigen"
					
L['Show Title'] = "Titel anzeigen"
L['Toggle show title in fubar'] = "Titel anzeigen an/aus"

L["Show time"] = "Zeit zeigen"
L["Toggle show time"] = "Zeit zeigen an/aus"

L["Max song text length"] = "Max. Titel Länge"
L["The maximum text length of the song displayed in FuBar."] = "Maximale Länge des Song Titels in der Fubar leiste."

L["Tooltip"] = true
L["Tooltip Settings"] = "Tooltip Einstellungen"

L["Options/Hints"] = "Optionen/Tipps"
L["Toggle show Options/Hints in tooltip"] = "Optionen/Tipps anzeigen"

L["Playlists"] = "Listen zeigen"
L["Toggle show playlists in tooltip"] = "Widergabelisten im Tooltip"

L["Spam to chat"] = "Chat spam liste"
L["Toggle show spam to chat in tooltip"] = "Spam channels im Tooltip"

L["Short Tooltip"] = "Tooltip kurz"
L["Show short tooltip only artist and songname"] = "Nur interpret und titel anzeigen."

L["Hide minimap/FuBar icon"] = "Minimap/FuBar Icon verstecken"
L["Attach to minimap"] = "An der Minikarte anbringen"
L["FuBar options"] = "FuBar Optionen"
L["Position"] = "Position"
L["Left"] = "Links"
L["Center"] = "Mitte"
L["Right"] = "Rechts"
L["Show text"] = "Text anzeigen"
L["Show icon"] = "Icon anzeigen"


L["Music volume: "] = "Musik Lautst.: "
L["Effects volume: "] = "Sound Lautst.: "
L["Stopped"] = "Gestoppt"

L["Artist"] = "Interpret"
L["Song"] = "Titel"
L["Album"] = true
L["Length"] = "Länge"
L["Playlist"] = "Liste"
				   
L["Play a list (alt+click move song)"] = "Speile Liste (alt+klick song verschieben)"
L["Spam to Chat:"] = "Spam in den Chat:"
				   
L["[Guild]"] = "[Gilde]"
L["[Party]"] = "[Gruppe]"
L["[Say]"] = "[Sagen]"
L["To target"] = "Zu Ziel"
L["Whisper to"] = "Flüstern zu "
L["[Raid]"] = "[Schlachtzug]"

L["Scroll over Fubar text to adjust music volume."] = "Über Fubar-Text scrollen um die lautstärke anzupassen."
L["Click to play next song. Middlelick to toggle play/stop."] = "Klick für nächsten Titel. Mittelklick Wiedergabe/Stopp."