﻿if( GetLocale() == "zhCN" ) then

MBB_TOOLTIP1 = "Ctrl + 右键 选择将一个按钮重新依附到迷你地图。";
MBB_OPTIONS_HEADER = "选项";
MBB_OPTIONS_OKBUTTON = "确定";
MBB_OPTIONS_CANCELBUTTON = "取消";
MBB_OPTIONS_SLIDEROFF = "无";
MBB_OPTIONS_SLIDERSEK = "秒";
MBB_OPTIONS_SLIDERLABEL = "消失时间：";
MBB_OPTIONS_EXPANSIONLABEL = "扩展方向：";
MBB_OPTIONS_EXPANSIONLEFT = "左侧";
MBB_OPTIONS_EXPANSIONTOP = "向上";
MBB_OPTIONS_EXPANSIONRIGHT = "右侧";
MBB_OPTIONS_EXPANSIONBOTTOM = "向下";
MBB_OPTIONS_MAXBUTTONSLABEL = "最大按钮数/每行：";
MBB_OPTIONS_MAXBUTTONSINFO = "(0=无限制)";
MBB_OPTIONS_ALTEXPANSIONLABEL = "内部按钮扩展方向：";
MBB_HELP1 = "输入 \"/mbb <cmd>\" 以下 <cmd> 可以使用：";
MBB_HELP2 = "  |c00ffffffbuttons|r: 在 MBB 条上显示所有按钮";
MBB_HELP3 = "  |c00ffffffreset position|r: 重置 MBB 在迷你地图上的位置";
MBB_HELP4 = "  |c00ffffffreset all|r: 重置所有设置";
MBB_NOERRORS = "没有错误产生！";

end