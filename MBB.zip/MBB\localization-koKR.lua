﻿if( GetLocale() == "koKR" ) then

MBB_TOOLTIP1 = "Ctrl + 우클릭시 미니맵에서 분리하거나 묶을수 있습니다.";
MBB_OPTIONS_HEADER = "옵션";
MBB_OPTIONS_OKBUTTON = "확인";
MBB_OPTIONS_CANCELBUTTON = "취소";
MBB_OPTIONS_SLIDEROFF = "끔";
MBB_OPTIONS_SLIDERSEK = "초";
MBB_OPTIONS_SLIDERLABEL = "버튼 사라짐 시간:";
MBB_OPTIONS_EXPANSIONLABEL = "확장 방향:";
MBB_OPTIONS_EXPANSIONLEFT = "좌측";
MBB_OPTIONS_EXPANSIONTOP = "상단";
MBB_OPTIONS_EXPANSIONRIGHT = "우측";
MBB_OPTIONS_EXPANSIONBOTTOM = "하단";
MBB_OPTIONS_MAXBUTTONSLABEL = "최대 버튼/줄:";
MBB_OPTIONS_MAXBUTTONSINFO = "(0=무한)";
MBB_OPTIONS_ALTEXPANSIONLABEL = "줄수에 따른 확장 방향:";
MBB_HELP1 = "\"/mbb <cmd>\" 입력을 합니다. <cmd>명령어는 다음과 같습니다:";
MBB_HELP2 = "  |c00ffffffbuttons|r: 모든 MBB 버튼바 프레임 리스트로 보여줍니다.";
MBB_HELP3 = "  |c00ffffffreset position|r: MBB 미니맵 위치를 초기화 합니다.";
MBB_HELP4 = "  |c00ffffffreset all|r: 모두 기본설정으로 되돌립니다.";
MBB_NOERRORS = "오류를 찾을수 없습니다!";

end