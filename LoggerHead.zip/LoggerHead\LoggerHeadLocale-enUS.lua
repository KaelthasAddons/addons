local L = LibStub("AceLocale-3.0"):NewLocale("LoggerHead", "enUS", true)


L["LoggerHead"] = true
L["Toggle Logging"] = true
L["Instances"] = true
L["Instance log settings"] = true
L["Zones"] = true
L["Zone log settings"] = true    
L["Eastern Kingdoms"] = true
L["Kalimdor"] = true
L["Outland"] = true
L["You have entered |cffd9d919%s|r. Do you want to enable logging for this zone/instance?"] = true
L["Enable"] = true
L["Disable"] = true
L["Enabled"] = "|cff00ff00Enabled|r"
L["Disabled"] = "|cffff0000Disabled|r"
L["Combat Log"] = true
L["Shift-Click to open configuration"] = true
L["Click to toggle combat logging"] = true
L["Prompt on new zone?"] = true
L["Prompt when entering a new zone?"] = true
L["Combat Log Enabled"] = true
L["Combat Log Disabled"] = true
