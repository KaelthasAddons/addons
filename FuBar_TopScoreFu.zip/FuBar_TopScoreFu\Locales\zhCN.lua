--Chinese Local : CWDG Translation Team
--$Rev: 171 $
--$Date: 2008-05-08 16:27:17 +0100 (Thu, 08 May 2008) $

local L = AceLibrary("AceLocale-2.2"):new("TopScoreFu")

L:RegisterTranslations("zhCN", function()
	return {
		["NAME"] = "FuBar - Top ScoreFu",
		["DESCRIPTION"] = "监视记录你的伤害、治疗、爆击等纪录。",
		["COMMANDS"] = {"/topfu", "/tsfu", "/topscorefu"},

		["ARGUMENT_SHOWSPLASH"] = "显示跳跃文字",
		["ARGUMENT_PLAYNOISE"] = "声音提示",
		["ARGUMENT_SCREENSHOT"] = "抓图",
		["ARGUMENT_HEALING"] = "治疗量",
		["ARGUMENT_DAMAGE"] = "伤害",
		["ARGUMENT_ONLYPVP"] = "只纪录 PvP",
		["ARGUMENT_RESET"] = "重置",
		["ARGUMENT_POSITION"] = "位置",
		["ARGUMENT_SHOWTRIVIAL"] = "其它",

		["MENU_SHOW_SPLASH"] = "显示消息",
		["MENU_SHOW_SOAR"] = "在 SCT 类插件中显示通知",
		["MENU_PLAY_NOISE"] = "提示音",
		["MENU_TAKE_SCREENSHOTS"] = "自动抓图",
		["MENU_INCLUDE_HEALING"] = "包含治疗",
		["MENU_INCLUDE_DAMAGE"] = "包含伤害",
		["MENU_VS_MONSTERS"] = "记录对怪物战斗",
		["MENU_RESET_SCORES"] = "重置纪录",
		["MENU_SHOW_TRIVIAL"] = "显示次要纪录",
		["MENU_IGNORE_VULNERABLE"] = "屏蔽脆弱的怪物",
		["MENU_FILTER"] = "过滤",
		["MENU_PURGE"] = "合并",
	
		["TEXT_NORMAL"] = "普通",
		["TEXT_CRITICAL"] = "暴击",
		["PATTERN_NORMAL_SPELL"] = "%s",
		["PATTERN_CRITICAL_SPELL"] = "暴击 %s",
		["TEXT_SCORES_RESET"] = "纪录重置",
		["TEXT_SET_POSITION_ERROR"] = "必须用 x y 的格式设置位置，x 和 y 都是数字。",

		["HINT"] = "Shift-左键 在聊天框中插入你的最高纪录。",

		["PATTERN_NEW_CRITICAL_RECORD"] = "新 %s 暴击记录！\n|cffffffff%d|r",
		["PATTERN_NEW_NORMAL_RECORD"] = "新 %s 纪录！\n|cffffffff%d|r",
		["PATTERN_SET_POSITION"] = "位置设定为：%d, %d",

		-- Mobs with silly vulnerabilities
		["VULNERABLE_MOBS"] = {
			--[[ Instances ]]--
			-- Blackwing Lair
			"黑翼监工",
			"黑翼龙人护卫",
			-- Tempest Keep: The Eye
			"凤凰",
			"凤凰卵",
			-- Black Temple
			"狂乱祭司",
			-- Magisters' Terrace
			-- "Pure Energy",
			-- [[ Outlands ]]
			-- Netherstorm
			"索克雷萨",
			-- Terokkar: Skettis
			"泰罗克",
			-- Terokkar: Quest: The Hawk's Essence
			"山鹰守护者",
			-- Ogri'la: Shartuul Event
			"沙图尔之眼",
			"恐惧之喉",
			"沙图尔",
		},
	}
end)
