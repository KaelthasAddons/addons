﻿local L = AceLibrary("AceLocale-2.2"):new("TopScoreFu")

L:RegisterTranslations("deDE", function()
	return {
		["NAME"] = "FuBar - Top ScoreFu",
		["DESCRIPTION"] = "Protokolliert Eure h\195\182chsten Treffer, h\195\182chste Heilung, h\195\182chsten kritischen Treffer, etc.",
		["COMMANDS"] = {"/topfu", "/tsfu", "/topscorefu"},

		["ARGUMENT_SHOWSPLASH"] = "showSplash",
		["ARGUMENT_PLAYNOISE"] = "playNoise",
		["ARGUMENT_SCREENSHOT"] = "screenshot",
		["ARGUMENT_HEALING"] = "healing",
		["ARGUMENT_DAMAGE"] = "damage",
		["ARGUMENT_ONLYPVP"] = "onlyPvP",
		["ARGUMENT_RESET"] = "reset",
		["ARGUMENT_POSITION"] = "position",
		["ARGUMENT_SHOWTRIVIAL"] = "trivial",

		["MENU_SHOW_SPLASH"] = "Zeige Einblendung",
		["MENU_SHOW_SOAR"] = "Zeige als Benachrichtigung in SCT ähnlichen Addons",
		["MENU_PLAY_NOISE"] = "Sound abspielen",
		["MENU_TAKE_SCREENSHOTS"] = "Screenshot anfertigen",
		["MENU_INCLUDE_HEALING"] = "Heilung einbeziehen",
		["MENU_INCLUDE_DAMAGE"] = "Schaden einbeziehen",
		["MENU_VS_MONSTERS"] = "Treffer gegen Monster",
		["MENU_RESET_SCORES"] = "Werte zur\195\188cksetzen",
		["MENU_SHOW_TRIVIAL"] = "Ergebnisse bei grauen Zielen",
		["MENU_IGNORE_VULNERABLE"] = "Ignoriere verwundbare Mobs",
		["MENU_FILTER"] = "Filter", 
		["MENU_PURGE"] = "Entfernen", 

		["TEXT_NORMAL"] = "Normal",
		["TEXT_CRITICAL"] = "Kritisch",
		["PATTERN_NORMAL_SPELL"] = "%s",
		["PATTERN_CRITICAL_SPELL"] = "kritische/r %s",
		["TEXT_SCORES_RESET"] = "Werte zur\195\188ckgesetzt",
		["TEXT_SET_POSITION_ERROR"] = "Die Position muss in der Form `x y` angegeben werden, wobei x und y Zahlen sind.",

		["HINT"] = "Shift-Linksklick f\195\188gt Eure Rekorde in die Chat-Eingabezeile ein.",

		["PATTERN_NEW_CRITICAL_RECORD"] = "Neuer Crit-Rekord mit %s !\n|cffffffff%d|r",
		["PATTERN_NEW_NORMAL_RECORD"] = "Neuer Rekord mit %s !\n|cffffffff%d|r",
		["PATTERN_SET_POSITION"] = "Position auf %d, %d eingestellt",
	}
end)
