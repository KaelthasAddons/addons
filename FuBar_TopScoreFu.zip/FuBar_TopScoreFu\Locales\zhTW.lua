local L = AceLibrary("AceLocale-2.2"):new("TopScoreFu")

L:RegisterTranslations("zhTW", function()
	return {
		["NAME"] = "FuBar - 紀錄",
		["DESCRIPTION"] = "追蹤記錄你的傷害、治療、致命一擊等紀錄。",
		["COMMANDS"] = {"/topfu", "/tsfu", "/topscorefu"},

		["ARGUMENT_SHOWSPLASH"] = "顯示跳躍文字",
		["ARGUMENT_PLAYNOISE"] = "聲音提示",
		["ARGUMENT_SCREENSHOT"] = "抓圖",
		["ARGUMENT_HEALING"] = "治療量",
		["ARGUMENT_DAMAGE"] = "傷害",
		["ARGUMENT_ONLYPVP"] = "只紀錄PvP",
		["ARGUMENT_RESET"] = "重置",
		["ARGUMENT_POSITION"] = "位置",
		["ARGUMENT_SHOWTRIVIAL"] = "trivial",

		["MENU_SHOW_SPLASH"] = "顯示訊息",
		["MENU_PLAY_NOISE"] = "提示音",
		["MENU_TAKE_SCREENSHOTS"] = "自動抓圖",
		["MENU_INCLUDE_HEALING"] = "包含治療",
		["MENU_INCLUDE_DAMAGE"] = "包含傷害",
		["MENU_VS_MONSTERS"] = "只記錄對怪物戰鬥",
		["MENU_RESET_SCORES"] = "重置紀錄",
		["MENU_SHOW_TRIVIAL"] = "顯示次要紀錄",
		["MENU_FILTER"] = "過濾",
		["MENU_PURGE"] = "合併",
	
		["TEXT_NORMAL"] = "普通",
		["TEXT_CRITICAL"] = "致命",
		["PATTERN_NORMAL_SPELL"] = "%s",
		["PATTERN_CRITICAL_SPELL"] = "致命 %s",
		["TEXT_SCORES_RESET"] = "紀錄重置",
		["TEXT_SET_POSITION_ERROR"] = "必須用 x y 的格式設置位置，x和y都是數字。",

		["HINT"] = "Shift-Click在聊天輸入框中插入你的最高紀錄.",

		["PATTERN_NEW_CRITICAL_RECORD"] = "新 %s 爆擊記錄!\n|cffffffff%d|r",
		["PATTERN_NEW_NORMAL_RECORD"] = "新 %s 紀錄!\n|cffffffff%d|r",
		["PATTERN_SET_POSITION"] = "位置設定為：%d, %d",
	}
end)
