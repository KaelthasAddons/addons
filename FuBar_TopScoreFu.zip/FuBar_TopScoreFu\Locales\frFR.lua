﻿local L = AceLibrary("AceLocale-2.2"):new("TopScoreFu")

L:RegisterTranslations("frFR", function()
	return {
		["NAME"] = "FuBar - Top ScoreFu",
		["DESCRIPTION"] = "Garde une trace de vos records de vos soins, coups, etc.",
		["COMMANDS"] = {"/topfu", "/tsfu", "/topscorefu"},

		["ARGUMENT_SHOWSPLASH"] = "Montrer Splash",
		["ARGUMENT_PLAYNOISE"] = "Jouer Son",
		["ARGUMENT_SCREENSHOT"] = "Screenshot",
		["ARGUMENT_HEALING"] = "Soins",
		["ARGUMENT_DAMAGE"] = "Dommage",
		["ARGUMENT_ONLYPVP"] = "SeulementPvP",
		["ARGUMENT_RESET"] = "Reset",
		["ARGUMENT_POSITION"] = "Position",
		["ARGUMENT_SHOWTRIVIAL"] = "Trivial",

		["MENU_SHOW_SPLASH"] = "Splash Ecran",
		["MENU_PLAY_NOISE"] = "Jouer son",
		["MENU_TAKE_SCREENSHOTS"] = "Faire screenshots",
		["MENU_INCLUDE_HEALING"] = "Inclus Soins",
		["MENU_INCLUDE_DAMAGE"] = "Inclus dommage",
		["MENU_VS_MONSTERS"] = "vs. Monstres",
		["MENU_RESET_SCORES"] = "Remise \195\160 zero",
		["MENU_SHOW_TRIVIAL"] = "Trivial scores",
		["MENU_FILTER"] = "Filtre", -- CHECK
		["MENU_PURGE"] = "Purge", -- CHECK

		["TEXT_NORMAL"] = "Normal",
		["TEXT_CRITICAL"] = "Critique",
		["PATTERN_NORMAL_SPELL"] = "%s",
		["PATTERN_CRITICAL_SPELL"] = "Critique %s",
		["TEXT_SCORES_RESET"] = "Remise \195\160 zero",
		["TEXT_SET_POSITION_ERROR"] = "You must give the position in the form of `x y`, where x and y are numbers.",

		["HINT"] = "Shift-Click pour mettre votre meilleur score dans la boite de chat.",

		["PATTERN_NEW_CRITICAL_RECORD"] = "Nouveau record critique pour %s!\n|cffffffff%d|r",
		["PATTERN_NEW_NORMAL_RECORD"] = "Nouveau record pour %s!\n|cffffffff%d|r",
		["PATTERN_SET_POSITION"] = "Position actuelle %d, %d",
	}
end)
