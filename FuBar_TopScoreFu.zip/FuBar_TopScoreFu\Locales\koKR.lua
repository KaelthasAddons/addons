﻿local L = AceLibrary("AceLocale-2.2"):new("TopScoreFu")

L:RegisterTranslations("koKR", function()
	return {
		["NAME"] = "FuBar - Top ScoreFu",
		["DESCRIPTION"] = "타격, 치유, 치명타 등의 최고기록을 기록해줍니다.",
		["COMMANDS"] = {"/topfu", "/tsfu", "/topscorefu"},

		["ARGUMENT_SHOWSPLASH"] = "showSplash",
		["ARGUMENT_PLAYNOISE"] = "playNoise",
		["ARGUMENT_SCREENSHOT"] = "screenshot",
		["ARGUMENT_HEALING"] = "healing",
		["ARGUMENT_DAMAGE"] = "damage",
		["ARGUMENT_ONLYPVP"] = "onlyPvP",
		["ARGUMENT_RESET"] = "reset",
		["ARGUMENT_POSITION"] = "position",
		["ARGUMENT_SHOWTRIVIAL"] = "trivial",

		["MENU_SHOW_SPLASH"] = "화면에 표시",
		["MENU_SHOW_SOAR"] = "SCT등의 전투메시지 애드온으로 알림",
		["MENU_PLAY_NOISE"] = "효과음 듣기",
		["MENU_TAKE_SCREENSHOTS"] = "스크린샷 찍기",
		["MENU_INCLUDE_HEALING"] = "치유 포함",
		["MENU_INCLUDE_DAMAGE"] = "타격 포함",
		["MENU_VS_MONSTERS"] = "몹에 대한 타격 포함",
		["MENU_RESET_SCORES"] = "기록 초기화",
		["MENU_SHOW_TRIVIAL"] = "사소한 타격 표시",
		["MENU_IGNORE_VULNERABLE"] = "특정 몬스터 공격력 제외",
		["MENU_FILTER"] = "필터",
		["MENU_PURGE"] = "기록 삭제",
	
		["TEXT_NORMAL"] = "평타",
		["TEXT_CRITICAL"] = "치명타",
		["PATTERN_NORMAL_SPELL"] = "%s",
		["PATTERN_CRITICAL_SPELL"] = "%s 치명타",
		["TEXT_SCORES_RESET"] = "모든 기록 초기화",
		["TEXT_SET_POSITION_ERROR"] = "x, y 좌표를 입력해야합니다.",

		["HINT"] = "쉬프트-클릭시에 최고 기록을 채팅창에 표시합니다.",

		["PATTERN_NEW_CRITICAL_RECORD"] = "새 %s 치명타 기록!\n|cffffffff%d|r",
		["PATTERN_NEW_NORMAL_RECORD"] = "새 %s 기록!\n|cffffffff%d|r",
		["PATTERN_SET_POSITION"] = "현재 위치 %d, %d",

		-- Mobs with silly vulnerabilities
		["VULNERABLE_MOBS"] = {
			--[[ 던전 ]]--
			-- 검은날개 둥지
			"죽음의발톱 부대장",
			"죽음의발톱 고룡수호병",
			-- 폭풍우 요새
			"불사조",
			"불사조 알",
			-- 검은 사원
			"광기의 여사제",
			-- Magisters' Terrace
			-- "Pure Energy",
			-- [[ 아웃랜드 ]]
			-- 황천의 폭풍
			"소크레타르",
			-- 아웃랜드: 테로카르 숲: 스케티스
			"테로크",
			-- 테로카르 숲: 퀘스트: The Hawk's Essence
			"Guardian of the Hawk",
			-- 아웃랜드: 오그릴라: 샤툴 이벤트
			"샤툴의 눈",
			"Dreadmaw",
			"샤툴",
		},
	}
end)
