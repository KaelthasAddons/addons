local L = LibStub("AceLocale-3.0"):NewLocale("Barrel", "enGB", true)

if L then
	
	L["Hide minimap icon"] = true
	L["Radius"] = true
	L["Angle"] = true
	
end
