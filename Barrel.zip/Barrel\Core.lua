Barrel = LibStub("AceAddon-3.0"):NewAddon("Barrel", "AceConsole-3.0", "AceEvent-3.0")
local ldb = LibStub("LibDataBroker-1.1")
local L = LibStub("AceLocale-3.0"):GetLocale("Barrel")
local options = {}

local MinimapShapes = {
	-- quadrant booleans (same order as SetTexCoord)
	-- {upper-left, lower-left, upper-right, lower-right}
	-- true = rounded, false = squared
	["ROUND"] 			= {true, true, true, true},
	["SQUARE"] 			= {false, false, false, false},
	["CORNER-TOPLEFT"] 		= {true, false, false, false},
	["CORNER-TOPRIGHT"] 		= {false, false, true, false},
	["CORNER-BOTTOMLEFT"] 		= {false, true, false, false},
	["CORNER-BOTTOMRIGHT"]	 	= {false, false, false, true},
	["SIDE-LEFT"] 			= {true, true, false, false},
	["SIDE-RIGHT"] 			= {false, false, true, true},
	["SIDE-TOP"] 			= {true, false, true, false},
	["SIDE-BOTTOM"] 		= {false, true, false, true},
	["TRICORNER-TOPLEFT"] 		= {true, true, true, false},
	["TRICORNER-TOPRIGHT"] 		= {true, false, true, true},
	["TRICORNER-BOTTOMLEFT"] 	= {true, true, false, true},
	["TRICORNER-BOTTOMRIGHT"] 	= {false, true, true, true},
}


function Barrel:OnInitialize()

	-- Called when the addon is loaded
	self:Config()
	options = LibStub("AceConfigRegistry-3.0"):GetOptionsTable("Barrel", "dialog", "Barrel-0.1")
	self:RegisterChatCommand("br", "ChatCommand")
	self:RegisterChatCommand("barrel", "ChatCommand")

end

function Barrel:OnEnable()
	for name, dataobj in ldb:DataObjectIterator() do
		self:CreateFrame(nil, name, dataobj)
		self:UpdatePosition(name, dataobj)
		--self:CreateMenu(nil, name)
	end
	ldb.RegisterCallback(self, "LibDataBroker_AttributeChanged__icon", "AttributeChanged_icon")
	ldb.RegisterCallback(self, "LibDataBroker_DataObjectCreated", "DataObjectCreated")
end

function Barrel:DataObjectCreated(event, name, dataobj)
	
	self:CreateFrame(nil, name, dataobj)
	self:UpdatePosition(name, dataobj)
	--self:CreateMenu(nil, name, dataobj)
end

function Barrel:ChatCommand(input)

	if not input or input:trim() == "" then
	  LibStub("AceConfigDialog-3.0"):Open("Barrel")
	else
	  LibStub("AceConfigCmd-3.0").HandleCommand(Barrel, "br", "Barrel", input)
	end

end

function Barrel:CreateFrame(event, name, dataobj)
	local frame = "Barrel"..name
	if self.db.profile[frame] == nil then
		self.db.profile[frame] = {}
	end
	self.db.profile[frame].Minimap = CreateFrame('Button', frame, Minimap)
	local minimap = self.db.profile[frame].Minimap
	minimap:SetFrameStrata('MEDIUM')
	minimap:SetWidth(31); minimap:SetHeight(31)
	minimap:SetFrameLevel(8)
	minimap:RegisterForClicks('anyUp')
	minimap:RegisterForDrag('LeftButton')
	minimap:SetHighlightTexture('Interface\\Minimap\\UI-Minimap-ZoomButton-Highlight')

	local overlay = minimap:CreateTexture(nil, 'OVERLAY')
	overlay:SetWidth(53); overlay:SetHeight(53)
	overlay:SetTexture('Interface\\Minimap\\MiniMap-TrackingBorder')
	overlay:SetPoint('TOPLEFT')

	local icon = minimap:CreateTexture(nil, 'BACKGROUND')
	icon:SetWidth(20); icon:SetHeight(20)
	icon:SetTexture(dataobj.icon)
	icon:SetTexCoord(0.05, 0.95, 0.05, 0.95)
	icon:SetPoint('TOPLEFT', 7, -5)
	self.db.profile[frame].icon = icon

	local elap = 0
	local update = 15
	minimap:SetScript('OnEnter', function() self:OnEnter(minimap, dataobj) end)
	minimap:SetScript('OnLeave', function() self:OnLeave(minimap, dataobj) end)
	minimap:SetScript('OnClick', function(_, button) self:OnClick(dataobj, button) end)
	minimap:SetScript('OnDragStart', function() self:OnDragStart(name, dataobj) end)
	minimap:SetScript('OnDragStop', function() self:OnDragStop(name) end)
	minimap:SetScript('OnMouseDown', function() self:OnMouseDown(name) end)
	minimap:SetScript('OnMouseUp', function() self:OnMouseUp(name) end)
	minimap:SetScript('OnUpdate', 
		function(_, elapsed) 
			local elapsed = elapsed
			elap = elap + elapsed
			if elap <= update then 
				self:UpdatePosition(name, dataobj)
				minimap:SetScript('OnUpdate', nil)
			end
		end
	)
end

function Barrel:OnClick(dataobj, button)
	if dataobj.OnClick then
		dataobj.OnClick(this, button)
	end
end

function Barrel:OnMouseDown(name)
	local frame = "Barrel"..name
	self.db.profile[frame].icon:SetTexCoord(0, 1, 0, 1)
end

function Barrel:OnMouseUp(name)
	local frame = "Barrel"..name
	self.db.profile[frame].icon:SetTexCoord(0.05, 0.95, 0.05, 0.95)
end

-- Tooltip code ripped from Fortress, credits to Borlox

local function getAnchors(frame)
	local x, y = frame:GetCenter()
	local xFrom, xTo = "", ""
	local yFrom, yTo = "", ""
	if x < GetScreenWidth() / 3 then
		xFrom, xTo = "LEFT", "RIGHT"
	elseif x > GetScreenWidth() / 3 then
		xFrom, xTo = "RIGHT", "LEFT"
	end
	if y < GetScreenHeight() / 3 then
		yFrom, yTo = "BOTTOM", "TOP"
		return "BOTTOM"..xFrom, "TOP"..xTo
	elseif y > GetScreenWidth() / 3 then
		yFrom, yTo = "TOP", "BOTTOM"
	end
	local from = yFrom..xFrom
	local to = yTo..xTo
	return (from == "" and "CENTER" or from), (to == "" and "CENTER" or to)
end

local GameTooltip = GameTooltip
local function GT_OnLeave()
	GameTooltip:SetScript("OnLeave", GameTooltip.oldOnLeave)
	GameTooltip:Hide()
	GameTooltip:EnableMouse(false)
end

local function PrepareTooltip(frame, anchorFrame)
	if frame == GameTooltip then
		GameTooltip.oldOnLeave = GameTooltip:GetScript("OnLeave")
		GameTooltip:EnableMouse(true)
		GameTooltip:SetScript("OnLeave", GT_OnLeave)
	end
	frame:SetOwner(anchorFrame, "ANCHOR_NONE")
	frame:ClearAllPoints()
	local from, to = getAnchors(anchorFrame)
	frame:SetPoint(from, anchorFrame, to)	
end

function Barrel:OnEnter(frame, dataobj)
	if dataobj.tooltip then
		PrepareTooltip(dataobj.tooltip, frame)
		if dataobj.tooltiptext then
			dataobj.tooltip:SetText(dataobj.tooltiptext)
		end
		dataobj.tooltip:Show()
	elseif dataobj.OnTooltipShow then
		PrepareTooltip(GameTooltip, frame)
		dataobj.OnTooltipShow(GameTooltip)
		GameTooltip:Show()
	elseif dataobj.tooltiptext then
		PrepareTooltip(GameTooltip, frame)
		GameTooltip:SetText(dataobj.tooltiptext)
		GameTooltip:Show()
	end
	if dataobj.OnEnter then
		dataobj.OnEnter(frame)
	end
end

function Barrel:OnLeave(frame, dataobj)
	if MouseIsOver(GameTooltip) and (dataobj.tooltiptext or dataobj.OnTooltipShow) then return end	
	if dataobj.tooltiptext or dataobj.OnTooltipShow then
		GT_OnLeave(GameTooltip)
	end
	if dataobj.OnLeave then
		dataobj.OnLeave(frame)
	end
end

function Barrel:OnDragStart(name, dataobj)
	local frame = "Barrel"..name
	local minimap = self.db.profile[frame].Minimap
	local icon = self.db.profile[frame].icon
	self.dragging = true
	minimap:LockHighlight()
	icon:SetTexCoord(0, 1, 0, 1)
	minimap:SetScript('OnUpdate', function() self:OnUpdate(name, dataobj) end)
	GameTooltip:Hide()
end

function Barrel:OnDragStop(name)
	local frame = "Barrel"..name
	local minimap = self.db.profile[frame].Minimap
	local icon = self.db.profile[frame].icon
	self.dragging = nil
	minimap:SetScript('OnUpdate', nil)
	icon:SetTexCoord(0.05, 0.95, 0.05, 0.95)
	minimap:UnlockHighlight()
end

function Barrel:OnUpdate(name, dataobj)
	local mx, my = Minimap:GetCenter()
	local px, py = GetCursorPosition()
	local scale = Minimap:GetEffectiveScale()

	px, py = px / scale, py / scale

	self:SetMinimapButtonPosition(name, math.deg(math.atan2(py - my, px - mx)) % 360)
	self:UpdatePosition(name, dataobj)
end

function Barrel:UpdatePosition(name, dataobj)
	local frame = "Barrel"..name
	local launchersonly = self.db.profile.launchersonly
	local menuName = string.gsub(name, "FuBar(%s)\-(%s)", "")
	menuName = string.gsub(name, "%s", "")
	
	local minimap = self.db.profile[frame].Minimap
	local radius = self.db.profile[frame].radius or 80
	local rounding = self.db.profile[frame].rounding or 10
	local position = self:GetMinimapButtonPosition(name) or random(0, 360)
	self:SetMinimapButtonPosition(name, position)
	self.db.profile[frame].radius = radius
	angle = math.rad(position)
	local x = math.cos(angle)
	local y = math.sin(angle)
	local q = 1;
	if x < 0 then
		q = q + 1;
	end
	if y > 0 then
		q = q + 2;
	end
	local minimapShape = GetMinimapShape and GetMinimapShape() or "ROUND"
	local quadTable = MinimapShapes[minimapShape];
	if quadTable[q] then
		x = x*radius;
		y = y*radius;
	else
		local diagRadius = math.sqrt(2*(radius)^2)-rounding
		x = math.max(-radius, math.min(x*diagRadius, radius))
		y = math.max(-radius, math.min(y*diagRadius, radius))
	end
	minimap:SetPoint("CENTER", Minimap, "CENTER", x, y)
	
	if self:IsLauncher(dataobj) == false and launchersonly == true then
		self:Hide(name)
		options.args.Barrel.args[menuName] = nil
	else
		if self.db.profile[frame].Hidden == true then
			self:Hide(name)
		elseif self.db.profile[frame].Hidden ~= true then
			self:Show(name)
		end
		if options.args.Barrel.args[menuName] == nil then
			self:CreateMenu(nil, name)
		end
	end
	
end

function Barrel:SetMinimapButtonPosition(name, angle)
	frame = "Barrel"..name
	self.db.profile[frame].minimapPos = angle
end

function Barrel:GetMinimapButtonPosition(name)
	frame = "Barrel"..name
	return self.db.profile[frame].minimapPos
end

function Barrel:Show(name)
	local frame = "Barrel"..name
	self.db.profile[frame].Minimap:Show()
end

function Barrel:Hide(name)
	local frame = "Barrel"..name
	self.db.profile[frame].Minimap:Hide()
end

function Barrel:IsLocked()
	return --self.locked
end

function Barrel:IsLauncher(dataobj)
	return dataobj.type == 'launcher'
end

function Barrel:AttributeChanged_icon(event, name, key, value, dataobj)
	--name = string.gsub(name, "FuBar(%s)\-(%s)", "")
	local frame = "Barrel"..name
	if self.db.profile[frame].icon then
		self.db.profile[frame].icon:SetTexture(dataobj.icon)
	end
end


-- Copyright 2008 Copystring"
