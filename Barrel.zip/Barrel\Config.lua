local Barrel = LibStub("AceAddon-3.0"):GetAddon("Barrel")
local L = LibStub("AceLocale-3.0"):GetLocale("Barrel")
local ldb = LibStub("LibDataBroker-1.1")


local defaults = {
	profile = {
		launchersonly = false
	}
}

local options = {
	type = "group",
	name = "Barrel",
	childGroups = "tree",
	args = {
		Barrel = {
		type = "group",
		name = "Barrel",
		handler = Barrel,
			args = {
				launchersonly = {
					type = "toggle",
					name = "Show only launcher objects",
					get = function() return Barrel.db.profile.launchersonly end,
					set = function(info, value) 
						Barrel.db.profile.launchersonly = value
						for name, dataobj in ldb:DataObjectIterator() do
							Barrel:UpdatePosition(name, dataobj)
						end
					end,
				},
				
			},
		},
	},
}

function Barrel:CreateMenu(event, name)
	local menuName = string.gsub(name, "FuBar(%s)\-(%s)", "")
	menuName = string.gsub(name, "%s", "")
	local frame = "Barrel"..name
	options.args.Barrel.args[menuName] = {
		type = "group",
		name = menuName,
		args = {
			[menuName] = {
				type = "group",
				name = menuName,
				order = 1,
				inline = true,
				args = {
					hideIcon = {
						type = "toggle",
						name = L["Hide minimap icon"],
						desc = L["Hide minimap icon"],
						width = "full",
						order = 1,
						get = function(info)
							return self.db.profile[frame].Hidden
						end,
						set = function(info, value)
							self.db.profile[frame].Hidden = value
							if ( value == false ) then
								self:Show(name)
							elseif ( value == true ) then
								self:Hide(name)
							end
						end,
					},
					radius = {
						type = "range",
						name = L["Radius"],
						min = 0,
						max = 160,
						step = 1,
						order = 2,
						get = function() return self.db.profile[frame].radius end,
						set = function(info, value)
							self.db.profile[frame].radius = value
							self:UpdatePosition(name)
						end,
					},
					angle = {
						type = "range",
						name = L["Angle"],
						min = 0,
						max = 360,
						step = 1,
						order = 3,
						get = function() return self:GetMinimapButtonPosition(name) end,
						set = function(info, value)
							self:SetMinimapButtonPosition(name, value)
							self:UpdatePosition(name)
						end,
					},
				},
			},
		},
	}
end

function Barrel:Config()

	self.db = LibStub("AceDB-3.0"):New("BarrelDB", defaults, "Default")
	LibStub("AceConfig-3.0"):RegisterOptionsTable("Barrel", options)
	self.optionsFrame = LibStub("AceConfigDialog-3.0"):AddToBlizOptions("Barrel", "Barrel")
	options.args.profiles = LibStub("AceDBOptions-3.0"):GetOptionsTable(self.db)

end

