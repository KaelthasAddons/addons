﻿-- no druid stats if no calculations file loaded
if not DruidStats then
	return;
end

-- startup stuff that needs local variables
do -- some setup stuff
	
	local s = DruidStats;
	local BI = LibStub("LibBabble-Inventory-3.0"):GetLookupTable();
	-- Valid item sub-types
	s.validSubTypes = {
		[BI["Leather"]]          = true,
		[BI["Cloth"]]            = true,
		[BI["Daggers"]]          = true,
		[BI["Fist Weapons"]]     = true,
		[BI["One-Handed Maces"]] = true,
		[BI["Staves"]]           = true,
		[BI["Two-Handed Maces"]] = true,
		[BI["Miscellaneous"]]    = true,
		[BI["Other"]]            = true, -- yay for Alchemist's Stone
		
		-- Elixirs and Food effects
		[BI["Elixir"]]           = true,
		[BI["Flask"]]            = true,
		[BI["Food & Drink"]]     = true,
	};
	-- Valid item types (they will be valid no matter their subtype)
	s.validTypes = {
		[BI["Gem"]]              = true,
	};
	-- Items that proved to cause errors in specific locales
	-- TODO: implement this
	s.blacklist = {
		[28109] = "deDE",
	};
	
	-- Item ID's of special items
	s.specialItems = {
		-- Elixirs & Flasks
		[33208] = { -- Flask of Chromatic Wonder
			["STR"] = 18,
			["AGI"] = 18,
			["STA"] = 18,
			["INT"] = 18,
			["SPI"] = 18,
		},

		-- Food & Drink
		[27663] = { -- Blackened Sporefish
			["MANA_REG"] = 8,
			["STA"] = 20,
		},
		[27664] = { -- Grilled Mudfish
			["AGI"] = 20,
			["SPI"] = 20,
		},
		[33052] = { -- Fisherman's Feast
			["SPI"] = 20,
			["STA"] = 30,
		},
		[34411] = { -- Hot Apple Cider
			["SPI"] = 20,
			["STA"] = 20,
		},
		[33872] = { -- Spicy Hot Talbuk
			["SPI"] = 20,
			["MELEE_HIT_RATING"] = 20,
		},
		[33825] = { -- Skullfish Soup
			["SPI"] = 20,
			["SPELL_CRIT_RATING"] = 20,
		},
	};
	-- duplicate stats
	s.specialItems[27667] = s.specialItems[33052]; -- Spicy Crawdad
	-- Useless:
	-- Hot Buttered Trout
	-- Stewed Trout

	
	local BS = LibStub("LibBabble-Spell-3.0"):GetLookupTable();
	s.forms = {
		["No Form"]               = 1,
		[BS["Bear Form"]]         = 2,
		[BS["Dire Bear Form"]]    = 2,
		[BS["Cat Form"]]          = 3,
		[BS["Tree of Life"]]      = 4,
		[BS["Moonkin Form"]]      = 5,
		-- unused: default to caster form
		[BS["Travel Form"]]       = 1,
		[BS["Aquatic Form"]]      = 1,
		[BS["Flight Form"]]       = 1,
		[BS["Swift Flight Form"]] = 1,
	};
end

DruidStats.TooltipList = {
	-- Blizzard UI
	ItemRefTooltip,
	GameTooltip,
	ShoppingTooltip1,
	ShoppingTooltip2,
	
	--EquipCompare
	ComparisonTooltip1,
	ComparisonTooltip2,
	
	--EQCompare
	EQCompareTooltip1,
	EQCompareTooltip2,
	
	-- LinkWrangler
	IRR_ItemRefTooltip1,
	IRR_ItemCompTooltip1,
	IRR_ItemCompTool11,
	IRR_ItemRefTooltip2,
	IRR_ItemCompTooltip2,
	IRR_ItemCompTool12,
	IRR_ItemRefTooltip3,
	IRR_ItemCompTooltip3,
	IRR_ItemCompTool13,
	IRR_ItemRefTooltip4,
	IRR_ItemCompTooltip4,
	IRR_ItemCompTool14,
	IRR_ItemRefTooltip5,
	IRR_ItemCompTooltip5,
	IRR_ItemCompTool15,
	
	-- MultiTips
	ItemRefTooltip2,
	ItemRefTooltip3,
	ItemRefTooltip4,
	ItemRefTooltip5,
}

DruidStats.pd = {}; -- Player data
DruidStats.itemCache = {};

function DruidStats:updatePlayerData()
	local pd = self.pd;
	-- get the shapeshift form...
	pd.form = GetShapeshiftForm(true);
	
	if GetShapeshiftForm(true) > 0 then
		local _, name = GetShapeshiftFormInfo(GetShapeshiftForm(true));
		pd.realform = self.forms[name];
		pd.formname = name;
	else
		pd.realform = 1;
		pd.formname = "No Form";
	end

	if not self.itemCache[pd.realform] then
		self.itemCache[pd.realform] = {};
		setmetatable(self.itemCache[pd.realform], {__mode = "kv"});
	end
	-- /run do local _, n = GetShapeshiftFormInfo(1); DEFAULT_CHAT_FRAME:AddMessage(n); end
	-- /run DEFAULT_CHAT_FRAME:AddMessage(GetShapeshiftForm(true).." - ".. GetShapeshiftForm());
	
	_,_,_,_, pd.hotw      = GetTalentInfo(2, 15); -- Heart of the Wild
	_,_,_,_, pd.sotf      = GetTalentInfo(2, 16); -- Survival of the Fittest
	_,_,_,_, pd.moonkin   = GetTalentInfo(1, 18); -- Moonkin
	_,_,_,_, pd.lg        = GetTalentInfo(1, 12); -- Lunar Guidance
	_,_,_,_, pd.ds        = GetTalentInfo(1, 17); -- Dreamstate
	_,_,_,_, pd.th        = GetTalentInfo(2, 5 ); -- Thick Hide
	_,_,_,_, pd.ni        = GetTalentInfo(2, 14); -- Nurturing Instinct
	_,_,_,_, pd.intensity = GetTalentInfo(3, 6 ); -- Intensity
	_,_,_,_, pd.tol       = GetTalentInfo(3, 20); -- Tree of Life
	_,_,_,_, pd.ls        = GetTalentInfo(3, 16); -- Living Spirit (15% increase to spirit)
	pd.level = UnitLevel("player");
	
	self:calculateTalentFactors(pd);
end

function DruidStats:calculateTalentFactors(pd)
	-- intellect factor for Heart of the Wild
	pd.f_HOTW_INT = 1 + (pd.hotw * 0.04);
	-- stamina factor for Heart of the Wild in BEAR FORM
	pd.f_HOTW_STA = 1 + (pd.hotw * 0.04);
	-- attack power factor for Heart of the Wild in CAT FORM
	pd.f_HOTW_AP  = 1 + (pd.hotw * 0.02);
	-- survival of the fittest factor
	pd.f_SOTF     = 1 + (pd.sotf * 0.01);
	-- nurturing instinct factor
	pd.f_NI       = pd.ni * 0.50;
	-- lunar guidance factor
	pd.f_LG       = pd.lg * 0.08333333333;
	-- living spirit
	pd.f_LS       = 1 + (pd.ls * 0.05);
	-- dreamstate
	-- TODO
	-- Intensity
	-- TODO
	-- Thick hide
	if pd.th > 0 then
		pd.f_TH = 1.01 + 0.03*DruidStats.pd.th;
	else
		pd.f_TH = 1;
	end
end

function DruidStats.SetItem(tooltip)
	local self = DruidStats;
	if not DruidStats_Settings.enabled then
		return;
	end
	-- Get the item
	local _, link = tooltip:GetItem();
	if not link then
		return;
	end
	-- Check if the item is a usable type
	local _,_,_,_,_, Type, subType = GetItemInfo(link);
	if not self.validSubTypes[subType] and not self.validTypes[Type] then
		return;
	end
	-- Check the cache
--	debugprofilestart();
	local iText = "";
	if self.itemCache[self.pd.realform][link] then
		iText = self.itemCache[self.pd.realform][link];
	else
		-- Special items
		local bonuses;
		local itemid  = tonumber(strmatch(link, "Hitem:(%d+):"));
		if self.specialItems[itemid] ~= nil then
			bonuses = self.specialItems[itemid];
		else
			bonuses = StatLogic:GetSum(link) or {};
		end
		-- parse the data
		for stat, s in pairs(self.sstats[self.pd.realform]) do
			local val, v2, v3, v4 = s.f(bonuses); -- Call the function for the stat
			if val and val ~= 0 then
				iText = iText..string.format(s.p, val, v2, v3, v4);
			end
		end
		-- save to cache
		self.itemCache[self.pd.realform][link] = iText;
	end

	if iText ~= "" then
		tooltip:AddLine("|n<< Druid Stats - "..self.pd.formname.." >>");
		tooltip:AddLine(iText);
	end
--	DEFAULT_CHAT_FRAME:AddMessage("DS-new: "..debugprofilestop().."ms");
end

--[[ Slash Commands ]]--
DruidStats.SlashHandler = function(msg)
	if msg == "on" then
		DEFAULT_CHAT_FRAME:AddMessage("DruidStats: Enabled")
		DruidStats_Settings.enabled = true;
	elseif msg == "off" then
		DEFAULT_CHAT_FRAME:AddMessage("DruidStats: Disabled")
		DruidStats_Settings.enabled = false;
	elseif msg == "unfake" then
		DruidStats:updatePlayerData();
		DruidStats.itemCache = {};
	elseif string.match(msg, "^fake%s") then
		local pd = DruidStats.pd;
		for w in string.gmatch(msg, "[^%s]+") do
			if w == "new" then
				DruidStats:updatePlayerData();
			elseif w == "bear" then
				pd.realform = 2;
				pd.formname = "Fake BEAR";
			elseif w == "cat" then
				pd.realform = 3;
				pd.formname = "Fake CAT";
			elseif w == "tol" then
				pd.realform = 4;
				pd.formname = "Fake TOL";
			elseif w == "mk" or w == "moonkin" then
				pd.realform = 5;
				pd.formname = "Fake MK";
			elseif w == "hotw" then
				pd.hotw = 5;
			elseif w == "sotf" then
				pd.sotf = 3;
			elseif w == "int" then
				pd.intensity = 3;
			elseif w == "ni" then
				pd.ni = 2;
			elseif w == "ds" then
				pd.ds = 3;
			elseif w == "lg" then
				pd.lg = 3;
			elseif w == "ls" then
				pd.ls = 3;
			elseif w == "th" then
				pd.th = 3;
			end
		end
		DruidStats:calculateTalentFactors(DruidStats.pd);
		DruidStats.itemCache = {};
		setmetatable(DruidStats.itemCache, {__mode = "kv"}); -- weak table to enable garbage collection
	elseif msg == "bench" then
		-- DruidStats from global space vs. DruidStats from local space
		DEFAULT_CHAT_FRAME:AddMessage("Bench: Access table via global space VS reference it and access it via local space");
		do
			local m = 1;
			local limit = 10000;
			
			while m < 10 do
				local k = DruidStats;
				local l,g = 0;
				k.benchI = 0;
				debugprofilestart();
				while k.benchI < limit do
					local i = DruidStats;
					local j = 0;
					while i.benchI < limit and j < m do
						i.benchI = i.benchI+1;
						j = j + 1;
					end
				end
				l = debugprofilestop();
				
				k.benchI = 0;
				debugprofilestart();
				while DruidStats.benchI < limit do
					local j = 0;
					while DruidStats.benchI < limit and j < m do
						DruidStats.benchI = DruidStats.benchI+1;
						j = j + 1;
					end
				end
				g = debugprofilestop();

				DEFAULT_CHAT_FRAME:AddMessage("L/G: "..l/g);
				DEFAULT_CHAT_FRAME:AddMessage("Local: "..l.."ms - "..(3*m).." calls per localized loop");
				DEFAULT_CHAT_FRAME:AddMessage("Global: "..g.."ms - "..(3*m).." calls per loop");
				
				m = m+1;
			end
		end
	else
		DEFAULT_CHAT_FRAME:AddMessage("DruidStats: Invalid command, usage: /druidstats on, /druidstats off")
	end
end

SlashCmdList["DRUID_STATS"] = DruidStats.SlashHandler;
SLASH_DRUID_STATS1 = "/druidstats";
SLASH_DRUID_STATS2 = "/ds";

DruidStats_Settings = {};
DruidStats_Settings.debug = false;
DruidStats_Settings.enabled = true;

local updateForm = function()
	local pd = DruidStats.pd;
	-- get the shapeshift form...
	pd.form = GetShapeshiftForm(true);
	
	if GetShapeshiftForm(true) > 0 then
		local _, name = GetShapeshiftFormInfo(GetShapeshiftForm(true));
		pd.realform = DruidStats.forms[name];
		pd.formname = name;
	else
		pd.realform = 1;
		pd.formname = "No Form";
	end
	
	if not DruidStats.itemCache[pd.realform] then
		DruidStats.itemCache[pd.realform] = {};
		setmetatable(DruidStats.itemCache[pd.realform], {__mode = "kv"});
	end
end

local clearCache = function()
	-- Update the player data
	DruidStats:updatePlayerData();
	-- Reset the cache
	DruidStats.itemCache = {};
	DruidStats.itemCache[DruidStats.pd.realform] = {};
	setmetatable(DruidStats.itemCache[DruidStats.pd.realform], {__mode = "kv"});
end

local startup = function()
	--[[ Hook DruidStats into various tool tips ]]--
	for k, tooltip in pairs(DruidStats.TooltipList) do
		if tooltip and tooltip:HasScript("OnTooltipSetItem") then
			-- Hook this script
			if tooltip:GetScript("OnTooltipSetItem") then
				local oldScript = tooltip:GetScript("OnTooltipSetItem")
				tooltip:SetScript("OnTooltipSetItem", function(tooltip)
					oldScript(tooltip)
					DruidStats.SetItem(tooltip)
				end);
			else
				tooltip:SetScript("OnTooltipSetItem", DruidStats.SetItem);
			end
			
			-- remove the frame from the list so I won't hook it more than once
			tremove(DruidStats.TooltipList, k);
		end
	end
end

-- dynamically create an event catcher frame that hook into other druids
local DruidStatsFrame1 = CreateFrame("Frame", nil, UIParent);
DruidStatsFrame1:SetScript("OnEvent", startup);
DruidStatsFrame1:RegisterEvent("ADDON_LOADED");

-- frame to catch events that require new parsing of a tooltip
local DruidStatsFrame2 = CreateFrame("Frame", nil, UIParent);
DruidStatsFrame2:SetScript("OnEvent", clearCache);
DruidStatsFrame2:RegisterEvent("VARIABLES_LOADED");         -- Startup
DruidStatsFrame2:RegisterEvent("CHARACTER_POINTS_CHANGED"); -- Talents changed
DruidStatsFrame2:RegisterEvent("PLAYER_LEVEL_UP");          -- Leveling
DruidStatsFrame2:RegisterEvent("UPDATE_SHAPESHIFT_FORMS");  -- When changing the set of stances/forms
DruidStatsFrame2:RegisterEvent("UNIT_INVENTORY_CHANGED");   -- When (un)equipping items

-- frame to catch events that only change the form of the player
local DruidStatsFrame3 = CreateFrame("Frame", nil, UIParent);
DruidStatsFrame3:SetScript("OnEvent", updateForm);
DruidStatsFrame3:RegisterEvent("UPDATE_SHAPESHIFT_FORM");   -- When changing stances/forms

