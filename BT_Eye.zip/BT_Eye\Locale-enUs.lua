local L = LibStub("AceLocale-3.0"):NewLocale("BT_Eye", "enUS", true)
if not L then return end

--infos
L["Module resetted"] = "Module resetted" --dont change this line!

L["info"] = "|cff91069ETactics by|r rpguides\n|cff91069EImages by|r Vonswan, rpguides\n|cff91069EModule by|r Sorontur\n\n|cffC0C0C0[http://www.kdh-wow.de]\n[http://www.rpguides.de]|r"

--add here localized tactic texts

L["tactic Al'ar"] =  [[

not yet available

]]

L["tactic Void"] =  [[

not yet available

]]

L["tactic Solarian"] =  [[

not yet available

]]

L["tactic Kael"] =  [[

not yet available

]]

--texts for trash

L["trash Al'ar"] = [[

not yet available

]]

L["trash Void"] = [[

not yet available

]]

L["trash Solarian"] = [[

not yet available

]]

L["trash Kael"] = [[

not yet available

]]


--ra text messages every line separated by \n
L["ra Al'ar"] = ""
L["ra Void"] = ""
L["ra Solarian"] = ""
L["ra Kael"] = ""

--button captions
L["tank position"] = true
L["Phase 1"] = true
L["Phase 2"] = true
L["Phase 4 & 5"] = true
L["Phase 1 & 3"] = true
L["phoenix tank"] = true