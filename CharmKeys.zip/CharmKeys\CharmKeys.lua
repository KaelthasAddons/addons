local charmkeys = {};
charmkeys.version = GetAddOnMetadata("simpleraidtargeticons","version");

CK_TITLE = "CharmKeys";
CK_HEADER = CK_TITLE .. " " .. charmkeys.version;

BINDING_HEADER_CK_TITLE = CK_TITLE;
BINDING_NAME_CK_STAR = "Star";
BINDING_NAME_CK_CIRCLE = "Circle";
BINDING_NAME_CK_DIAMOND = "Diamond";
BINDING_NAME_CK_TRIANGLE = "Triangle";
BINDING_NAME_CK_MOON = "Moon";
BINDING_NAME_CK_SQUARE = "Square";
BINDING_NAME_CK_CROSS = "Cross";
BINDING_NAME_CK_SKULL = "Skull";
BINDING_NAME_CK_NONE = "None";
