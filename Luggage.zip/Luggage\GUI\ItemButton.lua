local libBaggage = LibStub:GetLibrary("LibBaggage-1.0")
local L = LibStub("AceLocale-3.0"):GetLocale("Luggage")

local ItemButton = {}

function ItemButton:New()
   local frame = Luggage:GetItemButtonFrame()
   local newButton = {
      frame = frame,
      countText = _G[frame:GetName().."Count"],
      frameTexture = _G[frame:GetName().."IconTexture"],
      normalOnEnter = frame:GetScript("OnEnter"),
      
   }
   setmetatable(newButton, {__index = self})
   frame.obj = newButton
   return newButton
end

function ItemButton:SetFrame(frame)
   self.frame = frame
   self.countText = getglobal(frame:GetName().."Count")
   self.frameTexture = getglobal(frame:GetName().."IconTexture")
   self.normalOnEnter = frame:GetScript("OnEnter")
   frame.obj = self
end

function ItemButton:SetItem(item)
   local frame = self.frame
   if not item then
      frame:ClearAllPoints()
      frame:SetParent(UIParent)
      frame:Hide()
      return
   end
   self.itemID = item.itemID
   self.itemLink = item.link
   if item.bagID == "bank" then
      self.bagID = -1
   else
      self.bagID = item.bagID
   end
   self.slotID = item.slotID
   self:SetSlot(self.bagID, self.slotID)
   SetItemButtonTexture(frame, item.icon);
   SetItemButtonCount(frame, item.stackCount);
   self:SetLocked(item.locked)
   
   if ( item.icon ) then
      ContainerFrame_UpdateCooldown(self.bagID, frame);
      frame.hasItem = 1;
      frame.locked = locked;
      frame.readable = readable;
   else
      getglobal(frame:GetName().."Cooldown"):Hide();
      frame.hasItem = nil;
   end
   self.frame:Show()
end

function ItemButton:UseNormalSetSlot(bagID, slotID)
   if getglobal("BankFrame"):IsShown() then
      return true
   end
   if type(bagID) == "number" and bagID >= 0 and bagID <= NUM_BAG_SLOTS then
      return true
   end
end

local function newOnEnter(self)
   local x;
   x = self:GetRight();
   if ( x >= ( GetScreenWidth() / 2 ) ) then
      GameTooltip:SetOwner(self, "ANCHOR_LEFT");
   else
      GameTooltip:SetOwner(self, "ANCHOR_RIGHT");
   end
   GameTooltip:SetHyperlink(self.obj.itemLink)
   GameTooltip:AddLine(L["Item is in bank"])
   GameTooltip:Show()
end

function ItemButton:SetSlot(bagID, slotID)
   if self:UseNormalSetSlot(bagID, slotID) then
      self.frame:SetScript("OnEnter", self.normalOnEnter)
      self.frame:SetID(slotID)
      self.frame:SetParent(Luggage.dummyBagFrames[bagID])
      self.frame.UpdateTooltip = self.normalOnEnter
   else
      self.frame:SetID(slotID)
      self.frame:SetParent(Luggage.dummyBagFrames[bagID])
      self.frame:SetScript("OnEnter", newOnEnter)
      self.frame.UpdateTooltip = newOnEnter
   end
end

local texFactor = 64/37
function ItemButton:SetSize(size)
   local frame = self.frame
   local tex = _G[frame:GetName().."NormalTexture"]
   frame:SetHeight(size)
   frame:SetWidth(size)
   local texSize = size*texFactor
   tex:SetHeight(texSize)
   tex:SetWidth(texSize)
end

function ItemButton:UpdateCooldown()
   ContainerFrame_UpdateCooldown(self.bagID, self.frame);
end

function ItemButton:SetLocked(locked)
   SetItemButtonDesaturated(self.frame, locked, 0.5, 0.5, 0.5);
end

Luggage.ItemButton = ItemButton