Cheaptard = LibStub("AceAddon-3.0"):NewAddon("Cheaptard", "AceConsole-3.0", "AceEvent-3.0", "AceTimer-3.0")
local Cheaptard = Cheaptard
local L = LibStub("AceLocale-3.0"):GetLocale("Cheaptard", false)

BINDING_HEADER_CHEAPTARD = "Cheaptard"
BINDING_NAME_EQUIP_WORST_AMMO = L["EQUIP_WORST_AMMO"]
BINDING_NAME_EQUIP_BEST_AMMO = L["EQUIP_BEST_AMMO"]

local defaults = {
        char = {
                bestonboss = true,
                bestonduel = true,
                bestonraid = false,
                worstonpvp = true,
                bestonarena = true,
                worstonleavecombat = true,
                enabled = true,
        }
}

local db
local switch = { active = false, } -- set = nil, back = 0 }

-- options
Cheaptard.options = {
        type="group",
        args={
                options = {
                        type="group",
                        name=L["OPTIONS_NAME"],
                        desc=L["OPTIONS_DESC"],
                        args = {
                                bestonboss = {
                                        type="toggle",
                                        name=L["BESTONBOSS_NAME"],
                                        desc=L["BESTONBOSS_DESC"],
                                        get=function() return db.bestonboss end,
                                        set=function() db.bestonboss = not db.bestonboss end,
                                },
                                worstonpvp = {
                                        type="toggle",
                                        name=L["WORSTONPVP_NAME"],
                                        desc=L["WORSTONPVP_DESC"],
                                        get=function() return db.worstonpvp end,
                                        set=function() db.worstonpvp = not db.worstonpvp end,
                                },
                                bestonduel = {
                                        type="toggle",
                                        name=L["BESTONDUEL_NAME"],
                                        desc=L["BESTONDUEL_DESC"],
                                        get=function() return db.bestonduel end,
                                        set=function() db.bestonduel = not db.bestonduel end,
                                },
                                bestonarena = {
                                        type="toggle",
                                        name=L["BESTONARENA_NAME"],
                                        desc=L["BESTONARENA_DESC"],
                                        get=function() return db.bestonarena end,
                                        set=function() db.bestonarena = not db.bestonarena end,
                                },                        
                                bestonraid = {
                                        type="toggle",
                                        name=L["BESTONRAID_NAME"],
                                        desc=L["BESTONRAID_DESC"],
                                        get=function() return db.bestonraid end,
                                        set=function() db.bestonraid = not db.bestonraid end,
                                },
                                worstonleavecombat = {
                                        type="toggle",
                                        name=L["WORSTONLEAVECOMBAT_NAME"],
                                        desc=L["WORSTONLEAVECOMBAT_DESC"],
                                        get=function() return db.worstonleavecombat end,
                                        set=function() db.worstonleavecombat = not db.worstonleavecombat end,
                                },
						}
                },
        },
}

function Cheaptard:OnInitialize()
	LibStub("AceConfig-3.0"):RegisterOptionsTable("Cheaptard", self.options)

	self.optionsFrame = LibStub("AceConfigDialog-3.0"):AddToBlizOptions("Cheaptard", "Cheaptard")
	
	self:RegisterChatCommand("cheaptard", "Command")
	self:RegisterChatCommand("tard", "Command")
	self:RegisterChatCommand("tardtest", "ZONE_CHANGED")

	self.db = LibStub("AceDB-3.0"):New("CheaptardDB", defaults)
	db = self.db.char
end

function Cheaptard:Command(input)
	InterfaceOptionsFrame_OpenToFrame(self.optionsFrame)
end

function Cheaptard:EquipWorstAmmo()
	self:EquipAmmo(false)
end

function Cheaptard:EquipBestAmmo()
	self:EquipAmmo(true)
end

-- Equips best or worst ammo found in bags
function Cheaptard:EquipAmmo(use_best_ammo)
	local bestItemName, bestItemLevel, bestItemLink, bestItemRarity, found
	
	found = false
	
	-- For each bag
	for bag = 1, NUM_BAG_SLOTS do
		local slots = GetContainerNumSlots(bag)
		
--		self:Print("bag "..bag.." has "..slots.." slots")
		
		-- For each slot in bag
		for slot = 1, slots do
			local link = GetContainerItemLink(bag, slot)
			if link then
				
				local itemfamily = GetItemFamily(link)
				
				-- If this item can go into a quiver/ammo pouch, consider it
				-- I should get aquainted with bitlib some time
				if itemfamily == 1 or itemfamily == 2 then

--					self:Print("found "..link)

			
					local itemName, itemLink, itemRarity, itemLevel, itemMinLevel, itemType, itemSubType, itemStackCount, itemEquipLoc, itemTexture = GetItemInfo(link)

					-- If the level of this ammo is higher than current best,
					-- replace current best with it.
					if not found or (use_best_ammo and (itemLevel > bestItemLevel or (itemLevel == bestItemLevel and itemRarity > bestItemRarity))) or (not use_best_ammo and (itemLevel < bestItemLevel or (itemLevel == bestItemLevel and itemRarity < bestItemRarity))) then
					
--						self:Print(link.." will do fine!")

						bestItemLink = link
						bestItemName = itemName
						bestItemLevel = itemLevel
						bestItemRarity = itemRarity
						found = true
					end
					
				end
			end
		end
		
	end
	
	if found then
	
		-- Compare with our current equipped ammo
		local currentlink = GetInventoryItemLink("player",GetInventorySlotInfo("AmmoSlot"))
		if currentlink then
			local itemName, itemLink, itemRarity, itemLevel, itemMinLevel, itemType, itemSubType, itemStackCount, itemEquipLoc, itemTexture = GetItemInfo(currentlink)			
			if (use_best_ammo and (itemLevel < bestItemLevel or (itemLevel == bestItemLevel and itemRarity < bestItemRarity))) or (not use_best_ammo and (itemLevel > bestItemLevel or (itemLevel == bestItemLevel and itemRarity > bestItemRarity))) then
				self:Print("|cff22ff22"..L["EQUIPPING"].." "..bestItemLink)
				EquipItemByName(bestItemName)
			end
		end
	else
		self:Print("|cff22ff22"..L["NOAMMOFOUND"])
	end
	
end

function Cheaptard:ToggleBag()
		local link = GetInventoryItemLink("player", ContainerIDToInventoryID(i))
		if link then
			local subtype = select(7, GetItemInfo(link))
			if subtype == L["Soul Bag"] or subtype == L["Ammo Pouch"] or subtype == L["Quiver"] then
				ToggleBag(i)
			end
		end
	
end

function Cheaptard:OnEnable()
	self:RegisterEvent("PLAYER_REGEN_DISABLED")
	self:RegisterEvent("PLAYER_REGEN_ENABLED")
	self:RegisterEvent("DUEL_REQUESTED")
	self:RegisterEvent("DUEL_INBOUNDS");
	self:RegisterEvent("DUEL_FINISHED")
	self:RegisterEvent("PLAYER_TARGET_CHANGED")
	self:RegisterEvent("ZONE_CHANGED_NEW_AREA")
	switch.active = true
end

function Cheaptard:PLAYER_REGEN_ENABLED()
	if db.worstonleavecombat then
		self:EquipWorstAmmo()
	end
end

function Cheaptard:PLAYER_REGEN_DISABLED()
	if db.bestonduel and UnitExists("target") and UnitFactionGroup("target") == UnitFactionGroup("player") and not UnitIsFriend("player","target") then
		self:EquipBestAmmo()
	end
end

function Cheaptard:PLAYER_TARGET_CHANGED()
	if db.bestonboss then
		if UnitClassification("target") == "boss" or UnitClassification("target") == "worldboss" and not UnitIsDead("target") then
			self:EquipBestAmmo()
		end
	end
end

function Cheaptard:ZONE_CHANGED_NEW_AREA()
	local inInstance, instanceType = IsInInstance()
	
	if inInstance then
		
		if instanceType == "pvp" and db.worstonpvp then
			self:EquipWorstAmmo()
		elseif instanceType == "arena" and db.bestonarena then
			self:EquipBestAmmo()
		elseif instanceType == "raid" and db.bestonraid then
			self:EquipBestAmmo()
		end
		
	end
end

function Cheaptard:OnDisable()
        switch.active = false
end

function Cheaptard:BigWigs_RecvSync(sync,rest,nick)
--		self:Print("|cff22ff22BigWigs moo")
end

function Cheaptard:DUEL_FINISHED()
	if db.bestonduel then
		self:EquipWorstAmmo()
	end
end

function Cheaptard:DUEL_INBOUNDS()
	if db.bestonduel then
		self:EquipBestAmmo()
	end
end

function Cheaptard:DUEL_REQUESTED()
	if db.bestonduel then
		self:EquipBestAmmo()
	end
end

function Cheaptard:Toggle()
        db.enabled = not db.enabled

        if db.enabled then
                self:Print("|cff22ff22"..L["TOGGLE_ENABLED"])
        else
                self:Print("|cffff2222"..L["TOGGLE_DISABLED"])
        end
end
