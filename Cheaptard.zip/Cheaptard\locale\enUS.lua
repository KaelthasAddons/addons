local L = LibStub("AceLocale-3.0"):NewLocale("Cheaptard", "enUS", true)

L["EQUIP_WORST_AMMO"] = "Equip worst ammo"
L["EQUIP_BEST_AMMO"] = "Equip best ammo"

L["OPTIONS_NAME"] = "Autoswitch"
L["OPTIONS_DESC"] = "Options for automatic switching of ammo under certain circumstances."

L["TOGGLE_ENABLED"] = "Enabled"
L["TOGGLE_DISABLED"] = "Disabled"

L["BESTONBOSS_NAME"] = "Best for bosses"
L["BESTONBOSS_DESC"] = "Cheaptard will automatically equip your best ammo when starting a boss encounter. Currently this is done when you target a boss. And it is rather untested too."

L["BESTONDUEL_NAME"] = "Best for duels"
L["BESTONDUEL_DESC"] = "Cheaptard will automatically equip your best ammo when starting a duel. Currently this works best when you are challenged; otherwise the switch will take place when you enter combat."

L["BESTONARENA_NAME"] = "Best for arenas"
L["BESTONARENA_DESC"] = "Cheaptard will automatically equip your best ammo when entering an arena."

L["WORSTONPVP_NAME"] = "Worst for BGs"
L["WORSTONPVP_DESC"] = "Cheaptard will automatically equip your worst ammo when entering a battleground."

L["BESTONRAID_NAME"] = "Best for raids"
L["BESTONRAID_DESC"] = "Cheaptard will automatically equip your best ammo when entering a raid instance."

L["WORSTONLEAVECOMBAT_NAME"] = "Worst on end"
L["WORSTONLEAVECOMBAT_DESC"] = "Cheaptard will automatically equip your worst ammo when leaving combat."


L["NOAMMOFOUND"] = "Can not find any usable ammo in your bags."
L["EQUIPPING"] = "Equipping"
