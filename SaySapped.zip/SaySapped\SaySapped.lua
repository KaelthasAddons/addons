local SaySapped = CreateFrame("Frame")

SaySapped:SetScript("OnEvent",function()
	if (arg2 == "SPELL_AURA_APPLIED" and arg10 == "Sap" and arg7 == UnitName("player")) then
		SendChatMessage("Sapped", "SAY")
	end
end)

SaySapped:RegisterEvent("COMBAT_LOG_EVENT_UNFILTERED")
DEFAULT_CHAT_FRAME:AddMessage("SaySapped loaded")
