AtlasLootWBBossButtons = {

    FourDragons = {
        "";
        "";
        "";
        "";
        "";
        "";
        "";
        "";
        "";
        "";
        "";
        "";
        "DLethon";
        "DEmeriss";
        "DTaerar";
        "DYsondre";
        };

    Azuregos = {
        "AAzuregos";
        };

    DoomLordKazzak = {
        "DoomLordKazzak";
        };

    Doomwalker = {
        "DDoomwalker";
        };

    HighlordKruul = {
        "KKruul";
        };

    Skettis = {
        "";
        "";
        "";
        "";
        "";
        "";
        "";
        "";
        "Terokk";
        "";
        "";
        "SkettisTalonpriestIshaal";
        "";
        "";
        "SkettisHazziksPackage";
        "";
        "";
        "DarkscreecherAkkarai";
        "GezzaraktheHuntress";
        "Karrog";
        "VakkiztheWindrager";
        };

    };
