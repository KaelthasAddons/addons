pootpoot = LibStub("AceAddon-3.0"):NewAddon("pootpoot", "AceEvent-3.0", "AceConsole-3.0", "AceTimer-3.0")
local pootpoot = pootpoot

pootpoot.title = "pootpoot"
pootpoot.version = GetAddOnMetadata(pootpoot.title, "Version")
pootpoot.xbuild = GetAddOnMetadata(pootpoot.title, "X-Build")

local CombatLog_Object_IsA = CombatLog_Object_IsA

local COMBATLOG_OBJECT_NONE = COMBATLOG_OBJECT_NONE
local COMBATLOG_FILTER_MINE = COMBATLOG_FILTER_MINE
--local COMBATLOG_FILTER_POOT = bit.bor (
--					COMBATLOG_OBJECT_AFFILIATION_MINE,
--					COMBATLOG_OBJECT_TARGET)
--local COMBATLOG_FILTER_POOTPLAYER = bit.bor (
--					COMBATLOG_OBJECT_AFFILIATION_MINE,
--					COMBATLOG_OBJECT_TYPE_PLAYER)

local IsInInstance = IsInInstance

local zoneenable = true
local inpvpzone = false

local COMBAT_EVENTS = {
	["SWING_DAMAGE"] = "DAMAGE",
	["RANGE_DAMAGE"] = "DAMAGE",
	["SPELL_DAMAGE"] = "DAMAGE",
	["SPELL_PERIODIC_DAMAGE"] = "DAMAGE",
	["ENVIRONMENTAL_DAMAGE"] = "DAMAGE",
	["DAMAGE_SHIELD"] = "DAMAGE",
	["DAMAGE_SPLIT"] = "DAMAGE",
	["SPELL_HEAL"] = "HEAL",
	["SPELL_PERIODIC_HEAL"] = "HEAL",
	["SWING_MISSED"] = "MISS",
	["RANGE_MISSED"] = "MISS",
	["SPELL_MISSED"] = "MISS",
	["SPELL_PERIODIC_MISSED"] = "MISS",
	["DAMAGE_SHIELD_MISSED"] = "MISS",
	["SPELL_DRAIN"] = "DRAIN",
	["SPELL_LEECH"] = "DRAIN",
	["SPELL_PERIODIC_DRAIN"] = "DRAIN",
	["SPELL_PERIODIC_LEECH"] = "DRAIN",
	["SPELL_ENERGIZE"] = "POWER",
	["SPELL_PERIODIC_ENERGIZE"] = "POWER",
	["SPELL_INTERRUPT"] = "INTERRUPT",
	["PARTY_KILL"] = "DEATH",
	["UNIT_DIED"] = "DEATH",
	["UNIT_DESTROYED"] = "DEATH",
	["SPELL_AURA_APPLIED"] = "BUFF",
	["SPELL_PERIODIC_AURA_APPLIED"] = "BUFF",
	["SPELL_AURA_APPLIED_DOSE"] = "BUFF",
	["SPELL_PERIODIC_AURA_APPLIED_DOSE"] = "BUFF",
	["SPELL_AURA_REMOVED"] = "FADE",
	["SPELL_PERIODIC_AURA_REMOVED"] = "FADE",
	["SPELL_AURA_REMOVED_DOSE"] = "FADE",
	["SPELL_PERIODIC_AURA_REMOVED_DOSE"] = "FADE",
	["ENCHANT_APPLIED"] = "ENCHANT_APPLIED",
	["ENCHANT_REMOVED"] = "ENCHANT_REMOVED",
	["SPELL_SUMMON"] = "SUMMON",
	["SPELL_CREATE"] = "SUMMON",
	["SPELL_CAST_SUCCESS"] = "SUCCESS",
	["SPELL_CAST_START"] = "SPELLSTART",
}

local aboutopts = {
	type = "group",
	handler = pootpoot,
	args = {
		aboutdesc = {
			type = "description",
			name = "PootPoot " .. pootpoot.version .. " " .. pootpoot.xbuild .. "\n\nEmotes:\n\n/poot\n/foam\n/bong\n",
			cmdHidden = true,
		},
		aboutui = {
			type = "execute",
			name = "PootPoot GUI",
			desc = "Opens Configuration Dialog",
			func = "OpenPootConfig",
			cmdHidden = true,
		}
	}
}

local options = {
	type = "group",
	args = {
		ui = {
			order = 1,
			type = "execute",
			name = "PootPoot GUI",
			desc = "Opens Configuration Dialog",
			func = "OpenPootConfig",
			guiHidden = true,
		},
		profiles = {
			order = 2,
			type = "execute",
			name = "PootPoot Profiles GUI",
			desc = "Opens Profile Configuration Dialog",
			func = "OpenPootProfileConfig",
			guiHidden = true,
		},
		desc = {
			type = "description",
			name = "PootPoot " .. pootpoot.version .. " " .. pootpoot.xbuild .. "\n",
			cmdHidden = true,
		},
		hunterspells = {
			type = "group",
			handler = pootpoot,
			name = "Hunter",
			desc = "Hunter Spells",
			args = {
				hunterdesc = {
					order = 1,
					type = "description",
					name = "Hunter Options\n\nYou can use these options to set strings that can be output to /say.\nThe strings can be set to output on crit, and/or percentage chance.",
					cmdHidden = true,
				},
				disablehunt = {
					order = 2,
					type = "execute",
					name = "Disable Hunter Spells",
					desc = "Disables all Hunter spells",
					func = "DisableHunterSpells",
				},
				arcaneshotgrp = {
					type = "group",
					handler = pootpoot,
					name = "Arcane Shot",
					desc = "Arcane Shot Options",
					args = {
						arcaneshot = {
							order = 1,
							type = "input",
							name = "Arcane Shot",
							desc = "Arcane Shot string.",
							usage = "<string[;string...]>",
							get = "GetStringVar",
							set = "SetStringVar",
						},
						arcaneshottgl = {
							order = 2,
							type = "toggle",
							name = "Arcane Shot Toggle",
							desc = "Toggles the display of the Arcane Shot string.",
							get = "GetToggleVar",
							set = "SetToggleVar",
						},
						arcaneshotcrit = {
							order = 3,
							type = "toggle",
							name = "Arcane Shot Crit Toggle",
							desc = "Toggles the display of the Arcane Shot string only on crits.",
							get = "GetToggleVar",
							set = "SetToggleVar",
						},
						arcaneshotchance = {
							order = 4,
							type = "range",
							name = "Arcane Shot Chance",
							desc = "Chance of Arcane Shot string out of 100.",
							min = 0,
							max = 1,
							step = 0.01,
							get = "GetChance",
							set = "SetChance",
							isPercent = true,
						}
					}
				}
			}
		},
		shamanspells = {
			type = "group",
			handler = pootpoot,
			name = "Shaman",
			desc = "Shaman Spells",
			args = {
				shamandesc = {
					order = 1,
					type = "description",
					name = "Shaman Options\n\nYou can use these options to set strings that can be output to /say.\nThe strings can be set to output on crit, and/or percentage chance.",
					cmdHidden = true,
				},
				disablesham = {
					order = 2,
					type = "execute",
					name = "Disable Shaman Spells",
					desc = "Disables all Shaman spells",
					func = "DisableShamanSpells",
				},
				stormstrikegrp = {
					type = "group",
					handler = pootpoot,
					name = "Stormstrike",
					desc = "Stormstrike Options",
					args = {
						stormstrike = {
							order = 1,
							type = "input",
							name = "Stormstrike",
							desc = "Stormstrike string.",
							usage = "<string[;string...]>",
							get = "GetStringVar",
							set = "SetStringVar",
						},
						stormstriketgl = {
							order = 2,
							type = "toggle",
							name = "Stormstrike Toggle",
							desc = "Toggles the display of the Stormstrike string.",
							get = "GetToggleVar",
							set = "SetToggleVar",
						},
						stormstrikechance = {
							order = 3,
							type = "range",
							name = "Stormstrike Chance",
							desc = "Chance of Stormstrike string out of 100.",
							min = 0,
							max = 1,
							step = 0.01,
							get = "GetChance",
							set = "SetChance",
							isPercent = true,
						}
					}
				},
				lightningboltgrp = {
					type = "group",
					handler = pootpoot,
					name = "Lightning Bolt",
					desc = "Lightning Bolt Options",
					args = {
						lightningbolt = {
							order = 1,
							type = "input",
							name = "Lightning Bolt",
							desc = "Lightning Bolt string.",
							usage = "<string[;string...]>",
							get = "GetStringVar",
							set = "SetStringVar",
						},
						lightningbolttgl = {
							order = 2,
							type = "toggle",
							name = "Lightning Bolt Toggle",
							desc = "Toggles the display of the Lightning Bolt string.",
							get = "GetToggleVar",
							set = "SetToggleVar",
						},
						lightningboltcrit = {
							order = 3,
							type = "toggle",
							name = "Lightning Bolt Crit Toggle",
							desc = "Toggles the display of the Lightning Bolt string only on crits.",
							get = "GetToggleVar",
							set = "SetToggleVar",
						},
						lightningboltchance = {
							order = 4,
							type = "range",
							name = "Lightning Bolt Chance",
							desc = "Chance of Lightning Bolt string out of 100.",
							min = 0,
							max = 1,
							step = 0.01,
							get = "GetChance",
							set = "SetChance",
							isPercent = true,
						}
					}
				},
				earthshockgrp = {
					type = "group",
					handler = pootpoot,
					name = "Earthshock",
					desc = "Earthshock Options",
					args = {
						earthshock = {
							order = 1,
							type = "input",
							name = "Earthshock",
							desc = "Earthshock string.",
							usage = "<string[;string...]>",
							get = "GetStringVar",
							set = "SetStringVar",
						},
						earthshocktgl = {
							order = 2,
							type = "toggle",
							name = "Earthshock Toggle",
							desc = "Toggles the display of the Earthshock string.",
							get = "GetToggleVar",
							set = "SetToggleVar",
						},
						earthshockcrit = {
							order = 3,
							type = "toggle",
							name = "Earthshock Crit Toggle",
							desc = "Toggles the display of the Earthshock string only on crits.",
							get = "GetToggleVar",
							set = "SetToggleVar",
						},
						earthshockchance = {
							order = 4,
							type = "range",
							name = "Earthshock Chance",
							desc = "Chance of Earthshock string out of 100.",
							min = 0,
							max = 1,
							step = 0.01,
							get = "GetChance",
							set = "SetChance",
							isPercent = true,
						}
					}
				},
				flameshockgrp = {
					type = "group",
					handler = pootpoot,
					name = "Flameshock",
					desc = "Flameshock Options",
					args = {
						flameshock = {
							order = 1,
							type = "input",
							name = "Flameshock",
							desc = "Flameshock string.",
							usage = "<string[;string...]>",
							get = "GetStringVar",
							set = "SetStringVar",
						},
						flameshocktgl = {
							order = 2,
							type = "toggle",
							name = "Flameshock Toggle",
							desc = "Toggles the display of the Flameshock string.",
							get = "GetToggleVar",
							set = "SetToggleVar",
						},
						flameshockcrit = {
							order = 3,
							type = "toggle",
							name = "Flameshock Crit Toggle",
							desc = "Toggles the display of the Flameshock string only on crits.",
							get = "GetToggleVar",
							set = "SetToggleVar",
						},
						flameshockchance = {
							order = 4,
							type = "range",
							name = "Flameshock Chance",
							desc = "Chance of Flameshock string out of 100.",
							min = 0,
							max = 1,
							step = 0.01,
							get = "GetChance",
							set = "SetChance",
							isPercent = true,
						}
					}
				},
				purgegrp = {
					type = "group",
					handler = pootpoot,
					name = "Purge",
					desc = "Purge Options",
					args = {
						purge = {
							order = 1,
							type = "input",
							name = "Purge",
							desc = "Purge string.",
							usage = "<string[;string...]>",
							get = "GetStringVar",
							set = "SetStringVar",
						},
						purgetgl = {
							order = 2,
							type = "toggle",
							name = "Purge Toggle",
							desc = "Toggles the display of the Purge string.",
							get = "GetToggleVar",
							set = "SetToggleVar",
						},
						purgechance = {
							order = 3,
							type = "range",
							name = "Purge Chance",
							desc = "Chance of Purge string out of 100.",
							min = 0,
							max = 1,
							step = 0.01,
							get = "GetChance",
							set = "SetChance",
							isPercent = true,
						}
					}
				},
				frostshockgrp = {
					type = "group",
					handler = pootpoot,
					name = "Frostshock",
					desc = "Frostshock Options",
					args = {
						frostshock = {
							order = 1,
							type = "input",
							name = "Frostshock",
							desc = "Frostshock string.",
							usage = "<string[;string...]>",
							get = "GetStringVar",
							set = "SetStringVar",
						},
						frostshocktgl = {
							order = 2,
							type = "toggle",
							name = "Frostshock Toggle",
							desc = "Toggles the display of the Frostshock string.",
							get = "GetToggleVar",
							set = "SetToggleVar",
						},
						frostshockcrit = {
							order = 3,
							type = "toggle",
							name = "Frostshock Crit Toggle",
							desc = "Toggles the display of the Frostshock string only on crits.",
							get = "GetToggleVar",
							set = "SetToggleVar",
						},
						frostshockchance = {
							order = 4,
							type = "range",
							name = "Frostshock Chance",
							desc = "Chance of Frostshock string out of 100.",
							min = 0,
							max = 1,
							step = 0.01,
							get = "GetChance",
							set = "SetChance",
							isPercent = true,
						}
					}
				},
				chainlightninggrp = {
					type = "group",
					handler = pootpoot,
					name = "Chain Lightning",
					desc = "Chain Lightning Options",
					args = {
						chainlightning = {
							order = 1,
							type = "input",
							name = "Chain Lightning",
							desc = "Chain Lightning string.",
							usage = "<string[;string...]>",
							get = "GetStringVar",
							set = "SetStringVar",
						},
						chainlightningtgl = {
							order = 2,
							type = "toggle",
							name = "Chain Lightning Toggle",
							desc = "Toggles the display of the Chain Lightning string.",
							get = "GetToggleVar",
							set = "SetToggleVar",
						},
						chainlightningcrit = {
							order = 3,
							type = "toggle",
							name = "Chain Lightning Crit Toggle",
							desc = "Toggles the display of the Chain Lightning string only on crits.",
							get = "GetToggleVar",
							set = "SetToggleVar",
						},
						chainlightningchance = {
							order = 4,
							type = "range",
							name = "Chain Lightning Chance",
							desc = "Chance of Chain Lightning string out of 100.",
							min = 0,
							max = 1,
							step = 0.01,
							get = "GetChance",
							set = "SetChance",
							isPercent = true,
						}
					}
				},
				bloodlustgrp = {
					type = "group",
					handler = pootpoot,
					name = "Bloodlust/Heroism",
					desc = "Bloodlust Options",
					args = {
						bloodlust = {
							order = 1,
							type = "input",
							name = "Bloodlust",
							desc = "Bloodlust string.",
							usage = "<string[;string...]>",
							get = "GetStringVar",
							set = "SetStringVar",
						},
						bloodlusttgl = {
							order = 2,
							type = "toggle",
							name = "Bloodlust Toggle",
							desc = "Toggles the display of the Bloodlust string.",
							get = "GetToggleVar",
							set = "SetToggleVar",
						},
						bloodlustchance = {
							order = 3,
							type = "range",
							name = "Bloodlust Chance",
							desc = "Chance of Bloodlust string out of 100.",
							min = 0,
							max = 1,
							step = 0.01,
							get = "GetChance",
							set = "SetChance",
							isPercent = true,
						}
					}
				}
			}
		},
		warriorspells = {
			type = "group",
			handler = pootpoot,
			name = "Warrior",
			desc = "Warrior Spells",
			args = {
				warriordesc = {
					order = 1,
					type = "description",
					name = "Warrior Options\n\nYou can use these options to set strings that can be output to /say.\nThe strings can be set to output on crit, and/or percentage chance.",
					cmdHidden = true,
				},
				disablewarr = {
					order = 2,
					type = "execute",
					name = "Disable Warrior Spells",
					desc = "Disables all Warrior spells",
					func = "DisableWarriorSpells",
				},
				chargegrp = {
					type = "group",
					handler = pootpoot,
					name = "Charge",
					desc = "Charge Options",
					args = {
						charge = {
							order = 1,
							type = "input",
							name = "Charge",
							desc = "Charge, Intercept and Intervene string.",
							usage = "<string[;string...]>",
							get = "GetStringVar",
							set = "SetStringVar",
						},
						chargetgl = {
							order = 2,
							type = "toggle",
							name = "Charge Toggle",
							desc = "Toggles the display of the Charge string.",
							get = "GetToggleVar",
							set = "SetToggleVar",
						},
						chargechance = {
							order = 3,
							type = "range",
							name = "Charge Chance",
							desc = "Chance of Charge string out of 100.",
							min = 0,
							max = 1,
							step = 0.01,
							get = "GetChance",
							set = "SetChance",
							isPercent = true,
						}
					}
				},
				executegrp = {
					type = "group",
					handler = pootpoot,
					name = "Execute",
					desc = "Execute Options",
					args = {
						execute = {
							order = 4,
							type = "input",
							name = "Execute",
							desc = "Execute string.",
							usage = "<string[;string...]>",
							get = "GetStringVar",
							set = "SetStringVar",
						},
						executetgl = {
							order = 5,
							type = "toggle",
							name = "Execute Toggle",
							desc = "Toggles the display of the Execute string.",
							get = "GetToggleVar",
							set = "SetToggleVar",
						},
						executecrit = {
							order = 6,
							type = "toggle",
							name = "Execute Crit Toggle",
							desc = "Toggles the display of the Execute string only on crits.",
							get = "GetToggleVar",
							set = "SetToggleVar",
						},
						executechance = {
							order = 7,
							type = "range",
							name = "Execute Chance",
							desc = "Chance of Execute string out of 100.",
							min = 0,
							max = 1,
							step = 0.01,
							get = "GetChance",
							set = "SetChance",
							isPercent = true,
						}
					}
				},
				mortalstrikegrp = {
					type = "group",
					handler = pootpoot,
					name = "Mortal Strike",
					desc = "Mortal Strike Options",
					args = {
						mortalstrike = {
							order = 8,
							type = "input",
							name = "Mortal Strike",
							desc = "Mortal Strike string.",
							usage = "<string[;string...]>",
							get = "GetStringVar",
							set = "SetStringVar",
						},
						mortalstriketgl = {
							order = 9,
							type = "toggle",
							name = "Mortal Strike Toggle",
							desc = "Toggles the display of the Mortal Strike string.",
							get = "GetToggleVar",
							set = "SetToggleVar",
						},
						mortalstrikecrit = {
							order = 10,
							type = "toggle",
							name = "Mortal Strike Crit Toggle",
							desc = "Toggles the display of the Mortal Strike string only on crits.",
							get = "GetToggleVar",
							set = "SetToggleVar",
						},
						mortalstrikechance = {
							order = 11,
							type = "range",
							name = "Mortal Strike Chance",
							desc = "Chance of Mortal Strike string out of 100.",
							min = 0,
							max = 1,
							step = 0.01,
							get = "GetChance",
							set = "SetChance",
							isPercent = true,
						}
					}
				},
				bloodthirstgrp = {
					type = "group",
					handler = pootpoot,
					name = "Bloodthirst",
					desc = "Bloodthirst Options",
					args = {
						bloodthirst = {
							order = 12,
							type = "input",
							name = "Bloodthirst",
							desc = "Bloodthirst string.",
							usage = "<string[;string...]>",
							get = "GetStringVar",
							set = "SetStringVar",
						},
						bloodthirsttgl = {
							order = 13,
							type = "toggle",
							name = "Bloodthirst Toggle",
							desc = "Toggles the display of the Bloodthirst string.",
							get = "GetToggleVar",
							set = "SetToggleVar",
						},
						bloodthirstcrit = {
							order = 14,
							type = "toggle",
							name = "Bloodthirst Crit Toggle",
							desc = "Toggles the display of the Bloodthirst string only on crits.",
							get = "GetToggleVar",
							set = "SetToggleVar",
						},
						bloodthirstchance = {
							order = 15,
							type = "range",
							name = "Bloodthirst Chance",
							desc = "Chance of Bloodthirst string out of 100.",
							min = 0,
							max = 1,
							step = 0.01,
							get = "GetChance",
							set = "SetChance",
							isPercent = true,
						}
					}
				},
				rampagegrp = {
					type = "group",
					handler = pootpoot,
					name = "Rampage",
					desc = "Rampage Options",
					args = {
						rampage = {
							order = 16,
							type = "input",
							name = "Rampage",
							desc = "Rampage string.",
							usage = "<string[;string...]>",
							get = "GetStringVar",
							set = "SetStringVar",
						},
						rampagetgl = {
							order = 17,
							type = "toggle",
							name = "Rampage Toggle",
							desc = "Toggles the display of the Rampage string.",
							get = "GetToggleVar",
							set = "SetToggleVar",
						},
						rampagechance = {
							order = 18,
							type = "range",
							name = "Rampage Chance",
							desc = "Chance of Rampage string out of 100.",
							min = 0,
							max = 1,
							step = 0.01,
							get = "GetChance",
							set = "SetChance",
							isPercent = true,
						}
					}
				},
				shieldslamgrp = {
					type = "group",
					handler = pootpoot,
					name = "Shield Slam",
					desc = "Shield Slam Options",
					args = {
						shieldslam = {
							order = 19,
							type = "input",
							name = "Shield Slam",
							desc = "Shield Slam string.",
							usage = "<string[;string...]>",
							get = "GetStringVar",
							set = "SetStringVar",
						},
						shieldslamtgl = {
							order = 20,
							type = "toggle",
							name = "Shield Slam Toggle",
							desc = "Toggles the display of the Shield Slam string.",
							get = "GetToggleVar",
							set = "SetToggleVar",
						},
						shieldslamcrit = {
							order = 21,
							type = "toggle",
							name = "Shield Slam Crit Toggle",
							desc = "Toggles the display of the Shield Slam string only on crits.",
							get = "GetToggleVar",
							set = "SetToggleVar",
						},
						shieldslamchance = {
							order = 22,
							type = "range",
							name = "Shield Slam Chance",
							desc = "Chance of Shield Slam string out of 100.",
							min = 0,
							max = 1,
							step = 0.01,
							get = "GetChance",
							set = "SetChance",
							isPercent = true,
						}
					}
				},
				tauntgrp = {
					type = "group",
					handler = pootpoot,
					name = "Taunt",
					desc = "Taunt Options",
					args = {
						taunt = {
							order = 1,
							type = "input",
							name = "Taunt",
							desc = "Taunt string.",
							usage = "<string[;string...]>",
							get = "GetStringVar",
							set = "SetStringVar",
						},
						tauntresist = {
							order = 2,
							type = "input",
							name = "Taunt Resist",
							desc = "Taunt resist string.",
							usage = "<string[;string...]>",
							get = "GetStringVar",
							set = "SetStringVar",
						},
						taunttgl = {
							order = 3,
							type = "toggle",
							name = "Taunt Toggle",
							desc = "Toggles the display of the Taunt and Taunt Resist string.",
							get = "GetToggleVar",
							set = "SetToggleVar",
						},
						tauntresisttgl = {
							order = 4,
							type = "toggle",
							name = "Taunt Resist Toggle",
							desc = "Toggles the display of only the Taunt Resist string.(Turns off Taunt string)",
							get = "GetToggleVar",
							set = "SetToggleVar",
						},
						tauntchance = {
							order = 5,
							type = "range",
							name = "Taunt Chance",
							desc = "Chance of Taunt string out of 100.",
							min = 0,
							max = 1,
							step = 0.01,
							get = "GetChance",
							set = "SetChance",
							isPercent = true,
						}
					}
				},
				devastategrp = {
					type = "group",
					handler = pootpoot,
					name = "Devastate",
					desc = "Devastate Options",
					args = {
						devastate = {
							order = 1,
							type = "input",
							name = "Devastate",
							desc = "Devastate string.",
							usage = "<string[;string...]>",
							get = "GetStringVar",
							set = "SetStringVar",
						},
						devastatetgl = {
							order = 2,
							type = "toggle",
							name = "Devastate Toggle",
							desc = "Toggles the display of the Devastate string.",
							get = "GetToggleVar",
							set = "SetToggleVar",
						},
						devastatecrit = {
							order = 3,
							type = "toggle",
							name = "Taunt Resist Toggle",
							desc = "Toggles the display of Devastate string only on crits.",
							get = "GetToggleVar",
							set = "SetToggleVar",
						},
						devastatechance = {
							order = 4,
							type = "range",
							name = "Devastate Chance",
							desc = "Chance of Taunt string out of 100.",
							min = 0,
							max = 1,
							step = 0.01,
							get = "GetChance",
							set = "SetChance",
							isPercent = true,
						}
					}
				}
			}
		},
		magespells = {
			type = "group",
			handler = pootpoot,
			name = "Mage",
			desc = "Mage Spells",
			args = {
				magedesc = {
					order = 1,
					type = "description",
					name = "Mage Options\n\nYou can use these options to set strings that can be output to /say.\nThe strings can be set to output on crit, and/or percentage chance.",
					cmdHidden = true,
				},
				disablemage = {
					order = 2,
					type = "execute",
					name = "Disable Mage Spells",
					desc = "Disables all Mage spells",
					func = "DisableMageSpells",
				},
				firegrp = {
					type = "group",
					handler = pootpoot,
					name = "Fire",
					desc = "Fire Options",
					args = {
						fire = {
							order = 1,
							type = "input",
							name = "Fire",
							desc = "Fireball, Fire Blast, Pyroblast and Dragon's Breath string. Outputs on crit.",
							usage = "<string[;string...]>",
							get = "GetStringVar",
							set = "SetStringVar",
						},
						fireballtgl = {
							order = 2,
							type = "toggle",
							name = "Fireball Toggle",
							desc = "Toggles the display of the Fire string.",
							get = "GetToggleVar",
							set = "SetToggleVar",
						},
						fireballcasttgl = {
							order = 3,
							type = "toggle",
							name = "Fireball Casting Toggle",
							desc = "Toggles the display of the Fire string.",
							get = "GetToggleVar",
							set = "SetToggleVar",
						},
						fireblasttgl = {
							order = 4,
							type = "toggle",
							name = "Fireblast Toggle",
							desc = "Toggles the display of the Fire string.",
							get = "GetToggleVar",
							set = "SetToggleVar",
						},
						pyroblasttgl = {
							order = 5,
							type = "toggle",
							name = "Pyroblast Toggle",
							desc = "Toggles the display of the Fire string.",
							get = "GetToggleVar",
							set = "SetToggleVar",
						},
						pyroblastcasttgl = {
							order = 6,
							type = "toggle",
							name = "Pyroblast Casting Toggle",
							desc = "Toggles the display of the Fire string.",
							get = "GetToggleVar",
							set = "SetToggleVar",
						},
						dragonsbreathtgl = {
							order = 7,
							type = "toggle",
							name = "Dragon's Breath Toggle",
							desc = "Toggles the display of the Fire string.",
							get = "GetToggleVar",
							set = "SetToggleVar",
						},
						firecrit = {
							order = 8,
							type = "toggle",
							name = "Fire Crit Toggle",
							desc = "Toggles the display of the Fire string only on crits.",
							get = "GetToggleVar",
							set = "SetToggleVar",
						},
						firechance = {
							order = 9,
							type = "range",
							name = "Fire Chance",
							desc = "Chance of Fire string out of 100.",
							min = 0,
							max = 1,
							step = 0.01,
							get = "GetChance",
							set = "SetChance",
							isPercent = true,
						},
						firecastchance = {
							order = 10,
							type = "range",
							name = "Fire Casting Chance",
							desc = "Chance of Fire string out of 100.",
							min = 0,
							max = 1,
							step = 0.01,
							get = "GetChance",
							set = "SetChance",
							isPercent = true,
						}
					}
				},
				frostgrp = {
					type = "group",
					handler = pootpoot,
					name = "Frost",
					desc = "Frost Options",
					args = {
						frost = {
							order = 1,
							type = "input",
							name = "Frost",
							desc = "Frostbolt and Cone of Cold string. Outputs on crit.",
							usage = "<string[;string...]>",
							get = "GetStringVar",
							set = "SetStringVar",
						},
						frostbolttgl = {
							order = 2,
							type = "toggle",
							name = "Frostbolt Toggle",
							desc = "Toggles the display of the Frost string.",
							get = "GetToggleVar",
							set = "SetToggleVar",
						},
						frostboltcasttgl = {
							order = 3,
							type = "toggle",
							name = "Frostbolt Casting Toggle",
							desc = "Toggles the display of the Frost string.",
							get = "GetToggleVar",
							set = "SetToggleVar",
						},
						coneofcoldtgl = {
							order = 4,
							type = "toggle",
							name = "Cone of Cold Toggle",
							desc = "Toggles the display of the Frost string.",
							get = "GetToggleVar",
							set = "SetToggleVar",
						},
						frostcrit = {
							order = 5,
							type = "toggle",
							name = "Frost Crit Toggle",
							desc = "Toggles the display of the Frost string only on crits.",
							get = "GetToggleVar",
							set = "SetToggleVar",
						},
						frostchance = {
							order = 6,
							type = "range",
							name = "Frost Chance",
							desc = "Chance of Frost string out of 100.",
							min = 0,
							max = 1,
							step = 0.01,
							get = "GetChance",
							set = "SetChance",
							isPercent = true,
						},
						frostcastchance = {
							order = 7,
							type = "range",
							name = "Frost Casting Chance",
							desc = "Chance of Frost string out of 100.",
							min = 0,
							max = 1,
							step = 0.01,
							get = "GetChance",
							set = "SetChance",
							isPercent = true,
						}
					}
				},
				sheepgrp = {
					type = "group",
					handler = pootpoot,
					name = "Polymorph",
					desc = "Polymorph Options",
					args = {
						polymorph = {
							order = 1,
							type = "input",
							name = "Polymorph",
							desc = "Polymorph string.",
							usage = "<string[;string...]>",
							get = "GetStringVar",
							set = "SetStringVar",
						},
						polymorphtgl = {
							order = 2,
							type = "toggle",
							name = "Polymorph Toggle",
							desc = "Toggles the display of the Sheep string.",
							get = "GetToggleVar",
							set = "SetToggleVar",
						},
						polymorphchance = {
							order = 3,
							type = "range",
							name = "Polymorph Chance",
							desc = "Chance of Sheep string out of 100.",
							min = 0,
							max = 1,
							step = 0.01,
							get = "GetChance",
							set = "SetChance",
							isPercent = true,
						}
					}
				},
				blinkgrp = {
					type = "group",
					handler = pootpoot,
					name = "Blink",
					desc = "Blink Options",
					args = {
						blink = {
							order = 1,
							type = "input",
							name = "Blink",
							desc = "Blink string.",
							usage = "<string[;string...]>",
							get = "GetStringVar",
							set = "SetStringVar",
						},
						blinktgl = {
							order = 2,
							type = "toggle",
							name = "Blink Toggle",
							desc = "Toggles the display of the Blink string.",
							get = "GetToggleVar",
							set = "SetToggleVar",
						},
						blinkchance = {
							order = 3,
							type = "range",
							name = "Blink Chance",
							desc = "Chance of Blink string out of 100.",
							min = 0,
							max = 1,
							step = 0.01,
							get = "GetChance",
							set = "SetChance",
							isPercent = true,
						}
					}
				}
			}
		},
		warlockspells = {
			type = "group",
			handler = pootpoot,
			name = "Warlock",
			desc = "Warlock Spells",
			args = {
				warlockdesc = {
					order = 1,
					type = "description",
					name = "Warlock Options\n\nYou can use these options to set strings that can be output to /say.\nThe strings can be set to output on crit, and/or percentage chance.",
					cmdHidden = true,
				},
				disablewarlock = {
					order = 2,
					type = "execute",
					name = "Disable Warlock Spells",
					desc = "Disables all Warlock spells",
					func = "DisableWarlockSpells",
				},
				shadowboltgrp = {
					type = "group",
					handler = pootpoot,
					name = "Shadow Bolt",
					desc = "Shadow Bolt Options",
					args = {
						shadowbolt = {
							order = 1,
							type = "input",
							name = "Shadow Bolt",
							desc = "Shadow Bolt string.",
							usage = "<string[;string...]>",
							get = "GetStringVar",
							set = "SetStringVar",
						},
						shadowbolttgl = {
							order = 2,
							type = "toggle",
							name = "Shadow Bolt Toggle",
							desc = "Toggles the display of the Shadow Bolt string.",
							get = "GetToggleVar",
							set = "SetToggleVar",
						},
						shadowboltcrit = {
							order = 3,
							type = "toggle",
							name = "Shadow Bolt Crit Toggle",
							desc = "Toggles the display of the Shadow Bolt string on crit only.",
							get = "GetToggleVar",
							set = "SetToggleVar",
						},
						shadowboltchance = {
							order = 4,
							type = "range",
							name = "Shadow Bolt Chance",
							desc = "Chance of Shadow Bolt string out of 100.",
							min = 0,
							max = 1,
							step = 0.01,
							get = "GetChance",
							set = "SetChance",
							isPercent = true,
						},
						shadowboltcast = {
							order = 5,
							type = "input",
							name = "Shadow Bolt Cast",
							desc = "Shadow Bolt Casting string.",
							usage = "<string[;string...]>",
							get = "GetStringVar",
							set = "SetStringVar",
						},
						shadowboltcasttgl = {
							order = 6,
							type = "toggle",
							name = "Shadow Bolt Cast Toggle",
							desc = "Toggles the display of the Shadow Bolt Cast string.",
							get = "GetToggleVar",
							set = "SetToggleVar",
						},
						shadowboltcastchance = {
							order = 7,
							type = "range",
							name = "Shadow Bolt Cast Chance",
							desc = "Chance of Shadow Bolt Cast string out of 100.",
							min = 0,
							max = 1,
							step = 0.01,
							get = "GetChance",
							set = "SetChance",
							isPercent = true,
						}
					}
				},
				deathcoilgrp = {
					type = "group",
					handler = pootpoot,
					name = "Death Coil",
					desc = "Death Coil Options",
					args = {
						deathcoil = {
							order = 1,
							type = "input",
							name = "Death Coil",
							desc = "Death Coil string.",
							usage = "<string[;string...]>",
							get = "GetStringVar",
							set = "SetStringVar",
						},
						deathcoiltgl = {
							order = 2,
							type = "toggle",
							name = "Death Coil Toggle",
							desc = "Toggles the display of the Death Coil string.",
							get = "GetToggleVar",
							set = "SetToggleVar",
						},
						deathcoilcrit = {
							order = 3,
							type = "toggle",
							name = "Death Coil Crit Toggle",
							desc = "Toggles the display of the Death Coil string on crit only.",
							get = "GetToggleVar",
							set = "SetToggleVar",
						},
						deathcoilchance = {
							order = 4,
							type = "range",
							name = "Death Coil Chance",
							desc = "Chance of Death Coil string out of 100.",
							min = 0,
							max = 1,
							step = 0.01,
							get = "GetChance",
							set = "SetChance",
							isPercent = true,
						}
					}
				},
				lifetapgrp = {
					type = "group",
					handler = pootpoot,
					name = "Life Tap",
					desc = "Life Tap Options",
					args = {
						lifetap = {
							order = 1,
							type = "input",
							name = "Life Tap",
							desc = "Life Tap string.",
							usage = "<string[;string...]>",
							get = "GetStringVar",
							set = "SetStringVar",
						},
						lifetaptgl = {
							order = 2,
							type = "toggle",
							name = "Life Tap Toggle",
							desc = "Toggles the display of the Life Tap string.",
							get = "GetToggleVar",
							set = "SetToggleVar",
						},
						lifetapchance = {
							order = 3,
							type = "range",
							name = "Life Tap Chance",
							desc = "Chance of Life Tap string out of 100.",
							min = 0,
							max = 1,
							step = 0.01,
							get = "GetChance",
							set = "SetChance",
							isPercent = true,
						}
					}
				},
				curseofshadowgrp = {
					type = "group",
					handler = pootpoot,
					name = "Curse of Shadow",
					desc = "Curse of Shadow Options",
					args = {
						curseofshadow = {
							order = 1,
							type = "input",
							name = "Curse of Shadow",
							desc = "Curse of Shadow string.",
							usage = "<string[;string...]>",
							get = "GetStringVar",
							set = "SetStringVar",
						},
						curseofshadowtgl = {
							order = 2,
							type = "toggle",
							name = "Curse of Shadow Toggle",
							desc = "Toggles the display of the Curse of Shadow string.",
							get = "GetToggleVar",
							set = "SetToggleVar",
						},
						curseofshadowchance = {
							order = 3,
							type = "range",
							name = "Curse of Shadow Chance",
							desc = "Chance of Curse of Shadow string out of 100.",
							min = 0,
							max = 1,
							step = 0.01,
							get = "GetChance",
							set = "SetChance",
							isPercent = true,
						}
					}
				},
				corruptiongrp = {
					type = "group",
					handler = pootpoot,
					name = "Corruption",
					desc = "Corruption Options",
					args = {
						corruption = {
							order = 1,
							type = "input",
							name = "Corruption",
							desc = "Corruption string.",
							usage = "<string[;string...]>",
							get = "GetStringVar",
							set = "SetStringVar",
						},
						corruptiontgl = {
							order = 2,
							type = "toggle",
							name = "Corruption Toggle",
							desc = "Toggles the display of the Corruption string.",
							get = "GetToggleVar",
							set = "SetToggleVar",
						},
						corruptionchance = {
							order = 3,
							type = "range",
							name = "Corruption Chance",
							desc = "Chance of Corruption string out of 100.",
							min = 0,
							max = 1,
							step = 0.01,
							get = "GetChance",
							set = "SetChance",
							isPercent = true,
						}
					}
				},
				immolategrp = {
					type = "group",
					handler = pootpoot,
					name = "Immolate",
					desc = "Immolate Options",
					args = {
						immolate = {
							order = 1,
							type = "input",
							name = "Immolate",
							desc = "Immolate string.",
							usage = "<string[;string...]>",
							get = "GetStringVar",
							set = "SetStringVar",
						},
						immolatetgl = {
							order = 2,
							type = "toggle",
							name = "Immolate Toggle",
							desc = "Toggles the display of the Immolate string.",
							get = "GetToggleVar",
							set = "SetToggleVar",
						},
						immolatecrit = {
							order = 3,
							type = "toggle",
							name = "Immolate Crit Toggle",
							desc = "Toggles the display of the Immolate string on crit only.",
							get = "GetToggleVar",
							set = "SetToggleVar",
						},
						immolatechance = {
							order = 4,
							type = "range",
							name = "Immolate Chance",
							desc = "Chance of Immolate string out of 100.",
							min = 0,
							max = 1,
							step = 0.01,
							get = "GetChance",
							set = "SetChance",
							isPercent = true,
						},
						immolatecast = {
							order = 5,
							type = "input",
							name = "Immolate Cast",
							desc = "Immolate Casting string.",
							usage = "<string[;string...]>",
							get = "GetStringVar",
							set = "SetStringVar",
						},
						immolatecasttgl = {
							order = 6,
							type = "toggle",
							name = "Immolate Cast Toggle",
							desc = "Toggles the display of the Immolate Cast string.",
							get = "GetToggleVar",
							set = "SetToggleVar",
						},
						immolatecastchance = {
							order = 7,
							type = "range",
							name = "Immolate Cast Chance",
							desc = "Chance of Immolate Cast string out of 100.",
							min = 0,
							max = 1,
							step = 0.01,
							get = "GetChance",
							set = "SetChance",
							isPercent = true,
						}
					}
				},
				shadowburngrp = {
					type = "group",
					handler = pootpoot,
					name = "Shadowburn",
					desc = "Shadowburn Options",
					args = {
						shadowburn = {
							order = 1,
							type = "input",
							name = "Shadowburn",
							desc = "Shadowburn string.",
							usage = "<string[;string...]>",
							get = "GetStringVar",
							set = "SetStringVar",
						},
						shadowburntgl = {
							order = 2,
							type = "toggle",
							name = "Shadowburn Toggle",
							desc = "Toggles the display of the Shadowburn string.",
							get = "GetToggleVar",
							set = "SetToggleVar",
						},
						shadowburncrit = {
							order = 3,
							type = "toggle",
							name = "Shadowburn Crit Toggle",
							desc = "Toggles the display of the Shadowburn string on crit only.",
							get = "GetToggleVar",
							set = "SetToggleVar",
						},
						shadowburnchance = {
							order = 4,
							type = "range",
							name = "Shadowburn Chance",
							desc = "Chance of Shadowburn string out of 100.",
							min = 0,
							max = 1,
							step = 0.01,
							get = "GetChance",
							set = "SetChance",
							isPercent = true,
						}
					}
				},
				howlofterrorgrp = {
					type = "group",
					handler = pootpoot,
					name = "Howl of Terror",
					desc = "Howl of Terror Options",
					args = {
						howlofterror = {
							order = 1,
							type = "input",
							name = "Howl of Terror",
							desc = "Howl of Terror string.",
							usage = "<string[;string...]>",
							get = "GetStringVar",
							set = "SetStringVar",
						},
						howlofterrortgl = {
							order = 2,
							type = "toggle",
							name = "Howl of Terror Toggle",
							desc = "Toggles the display of the Howl of Terror string.",
							get = "GetToggleVar",
							set = "SetToggleVar",
						},
						howlofterrorchance = {
							order = 3,
							type = "range",
							name = "Howl of Terror Chance",
							desc = "Chance of Howl of Terror string out of 100.",
							min = 0,
							max = 1,
							step = 0.01,
							get = "GetChance",
							set = "SetChance",
							isPercent = true,
						}
					}
				},
				curseofagonygrp = {
					type = "group",
					handler = pootpoot,
					name = "Curse of Agony",
					desc = "Curse of Agony Options",
					args = {
						curseofagony = {
							order = 1,
							type = "input",
							name = "Curse of Agony",
							desc = "Curse of Agony string.",
							usage = "<string[;string...]>",
							get = "GetStringVar",
							set = "SetStringVar",
						},
						curseofagonytgl = {
							order = 2,
							type = "toggle",
							name = "Curse of Agony Toggle",
							desc = "Toggles the display of the Curse of Agony string.",
							get = "GetToggleVar",
							set = "SetToggleVar",
						},
						curseofagonychance = {
							order = 3,
							type = "range",
							name = "Curse of Agony Chance",
							desc = "Chance of Curse of Agony string out of 100.",
							min = 0,
							max = 1,
							step = 0.01,
							get = "GetChance",
							set = "SetChance",
							isPercent = true,
						}
					}
				},
				hellfiregrp = {
					type = "group",
					handler = pootpoot,
					name = "Hellfire",
					desc = "Hellfire Options",
					args = {
						hellfire = {
							order = 1,
							type = "input",
							name = "Hellfire",
							desc = "Hellfire string.",
							usage = "<string[;string...]>",
							get = "GetStringVar",
							set = "SetStringVar",
						},
						hellfiretgl = {
							order = 2,
							type = "toggle",
							name = "Hellfire Toggle",
							desc = "Toggles the display of the Hellfire string.",
							get = "GetToggleVar",
							set = "SetToggleVar",
						},
						hellfirechance = {
							order = 3,
							type = "range",
							name = "Hellfire Chance",
							desc = "Chance of Hellfire string out of 100.",
							min = 0,
							max = 1,
							step = 0.01,
							get = "GetChance",
							set = "SetChance",
							isPercent = true,
						}
					}
				},
				incinerategrp = {
					type = "group",
					handler = pootpoot,
					name = "Incinerate",
					desc = "Incinerate Options",
					args = {
						incinerate = {
							order = 1,
							type = "input",
							name = "Incinerate",
							desc = "Incinerate string.",
							usage = "<string[;string...]>",
							get = "GetStringVar",
							set = "SetStringVar",
						},
						incineratetgl = {
							order = 2,
							type = "toggle",
							name = "Incinerate Toggle",
							desc = "Toggles the display of the Incinerate string.",
							get = "GetToggleVar",
							set = "SetToggleVar",
						},
						incineratecrit = {
							order = 3,
							type = "toggle",
							name = "Incinerate Crit Toggle",
							desc = "Toggles the display of the Incinerate string on crit only.",
							get = "GetToggleVar",
							set = "SetToggleVar",
						},
						incineratechance = {
							order = 4,
							type = "range",
							name = "Incinerate Chance",
							desc = "Chance of Incinerate string out of 100.",
							min = 0,
							max = 1,
							step = 0.01,
							get = "GetChance",
							set = "SetChance",
							isPercent = true,
						},
						incineratecast = {
							order = 5,
							type = "input",
							name = "Incinerate Cast",
							desc = "Incinerate Casting string.",
							usage = "<string[;string...]>",
							get = "GetStringVar",
							set = "SetStringVar",
						},
						incineratecasttgl = {
							order = 6,
							type = "toggle",
							name = "Incinerate Cast Toggle",
							desc = "Toggles the display of the Incinerate Cast string.",
							get = "GetToggleVar",
							set = "SetToggleVar",
						},
						incineratecastchance = {
							order = 7,
							type = "range",
							name = "Incinerate Cast Chance",
							desc = "Chance of Incinerate Cast string out of 100.",
							min = 0,
							max = 1,
							step = 0.01,
							get = "GetChance",
							set = "SetChance",
							isPercent = true,
						}
					}
				},
				curseofweaknessgrp = {
					type = "group",
					handler = pootpoot,
					name = "Curse of Weakness",
					desc = "Curse of Weakness Options",
					args = {
						curseofweakness = {
							order = 1,
							type = "input",
							name = "Curse of Weakness",
							desc = "Curse of Weakness string.",
							usage = "<string[;string...]>",
							get = "GetStringVar",
							set = "SetStringVar",
						},
						curseofweaknesstgl = {
							order = 2,
							type = "toggle",
							name = "Curse of Weakness Toggle",
							desc = "Toggles the display of the Curse of Weakness string.",
							get = "GetToggleVar",
							set = "SetToggleVar",
						},
						curseofweaknesschance = {
							order = 3,
							type = "range",
							name = "Curse of Weakness Chance",
							desc = "Chance of Curse of Weakness string out of 100.",
							min = 0,
							max = 1,
							step = 0.01,
							get = "GetChance",
							set = "SetChance",
							isPercent = true,
						}
					}
				},
				curseofrecklessnessgrp = {
					type = "group",
					handler = pootpoot,
					name = "Curse of Recklessness",
					desc = "Curse of Recklessness Options",
					args = {
						curseofrecklessness = {
							order = 1,
							type = "input",
							name = "Curse of Recklessness",
							desc = "Curse of Recklessness string.",
							usage = "<string[;string...]>",
							get = "GetStringVar",
							set = "SetStringVar",
						},
						curseofrecklessnesstgl = {
							order = 2,
							type = "toggle",
							name = "Curse of Recklessness Toggle",
							desc = "Toggles the display of the Curse of Recklessness string.",
							get = "GetToggleVar",
							set = "SetToggleVar",
						},
						curseofrecklessnesschance = {
							order = 3,
							type = "range",
							name = "Curse of Recklessness Chance",
							desc = "Chance of Curse of Recklessness string out of 100.",
							min = 0,
							max = 1,
							step = 0.01,
							get = "GetChance",
							set = "SetChance",
							isPercent = true,
						}
					}
				},
				curseoftonguesgrp = {
					type = "group",
					handler = pootpoot,
					name = "Curse of Tongues",
					desc = "Curse of Tongues Options",
					args = {
						curseoftongues = {
							order = 1,
							type = "input",
							name = "Curse of Tongues",
							desc = "Curse of Tongues string.",
							usage = "<string[;string...]>",
							get = "GetStringVar",
							set = "SetStringVar",
						},
						curseoftonguestgl = {
							order = 2,
							type = "toggle",
							name = "Curse of Tongues Toggle",
							desc = "Toggles the display of the Curse of Tongues string.",
							get = "GetToggleVar",
							set = "SetToggleVar",
						},
						curseoftongueschance = {
							order = 3,
							type = "range",
							name = "Curse of Tongues Chance",
							desc = "Chance of Curse of Tongues string out of 100.",
							min = 0,
							max = 1,
							step = 0.01,
							get = "GetChance",
							set = "SetChance",
							isPercent = true,
						}
					}
				},
				curseofdoomgrp = {
					type = "group",
					handler = pootpoot,
					name = "Curse of Doom",
					desc = "Curse of Doom Options",
					args = {
						curseofdoom = {
							order = 1,
							type = "input",
							name = "Curse of Doom",
							desc = "Curse of Doom string.",
							usage = "<string[;string...]>",
							get = "GetStringVar",
							set = "SetStringVar",
						},
						curseofdoomtgl = {
							order = 2,
							type = "toggle",
							name = "Curse of Doom Toggle",
							desc = "Toggles the display of the Curse of Doom string.",
							get = "GetToggleVar",
							set = "SetToggleVar",
						},
						curseofdoomchance = {
							order = 4,
							type = "range",
							name = "Curse of Doom Chance",
							desc = "Chance of Curse of Doom string out of 100.",
							min = 0,
							max = 1,
							step = 0.01,
							get = "GetChance",
							set = "SetChance",
							isPercent = true,
						}
					}
				},
				seedofcorruptiongrp = {
					type = "group",
					handler = pootpoot,
					name = "Seed of Corruption",
					desc = "Seed of Corruption Options",
					args = {
						seedofcorruption = {
							order = 1,
							type = "input",
							name = "Seed of Corruption",
							desc = "Seed of Corruption string.",
							usage = "<string[;string...]>",
							get = "GetStringVar",
							set = "SetStringVar",
						},
						seedofcorruptiontgl = {
							order = 2,
							type = "toggle",
							name = "Seed of Corruption Toggle",
							desc = "Toggles the display of the Seed of Corruption string.",
							get = "GetToggleVar",
							set = "SetToggleVar",
						},
						seedofcorruptionchance = {
							order = 3,
							type = "range",
							name = "Seed of Corruption Chance",
							desc = "Chance of Seed of Corruption string out of 100.",
							min = 0,
							max = 1,
							step = 0.01,
							get = "GetChance",
							set = "SetChance",
							isPercent = true,
						}
					}
				},
				banishgrp = {
					type = "group",
					handler = pootpoot,
					name = "Banish",
					desc = "Banish Options",
					args = {
						banish = {
							order = 1,
							type = "input",
							name = "Banish",
							desc = "Banish string.",
							usage = "<string[;string...]>",
							get = "GetStringVar",
							set = "SetStringVar",
						},
						banishtgl = {
							order = 2,
							type = "toggle",
							name = "Banish Toggle",
							desc = "Toggles the display of the Banish string.",
							get = "GetToggleVar",
							set = "SetToggleVar",
						},
						banishchance = {
							order = 3,
							type = "range",
							name = "Banish Chance",
							desc = "Chance of Banish string out of 100.",
							min = 0,
							max = 1,
							step = 0.01,
							get = "GetChance",
							set = "SetChance",
							isPercent = true,
						}
					}
				},
				feargrp = {
					type = "group",
					handler = pootpoot,
					name = "Fear",
					desc = "Fear Options",
					args = {
						fear = {
							order = 1,
							type = "input",
							name = "Fear",
							desc = "Fear string.",
							usage = "<string[;string...]>",
							get = "GetStringVar",
							set = "SetStringVar",
						},
						feartgl = {
							order = 2,
							type = "toggle",
							name = "Fear Toggle",
							desc = "Toggles the display of the Fear string.",
							get = "GetToggleVar",
							set = "SetToggleVar",
						},
						fearchance = {
							order = 3,
							type = "range",
							name = "Fear Chance",
							desc = "Chance of Fear string out of 100.",
							min = 0,
							max = 1,
							step = 0.01,
							get = "GetChance",
							set = "SetChance",
							isPercent = true,
						}
					}
				}
			}
		},
		roguespells = {
			type = "group",
			handler = pootpoot,
			name = "Rogue",
			desc = "Rogue Spells and Abilities",
			args = {
				roguedesc = {
					order = 1,
					type = "description",
					name = "Rogue Options\n\nYou can use these options to set strings that can be output to /say.\nThe strings can be set to output on crit, and/or percentage chance.",
					cmdHidden = true,
				},
				disablerogue = {
					order = 2,
					type = "execute",
					name = "Disable Rogue Spells",
					desc = "Disables all Rogue spells",
					func = "DisableRogueSpells",
				},
				sinisterstrikegrp = {
					type = "group",
					handler = pootpoot,
					name = "Sinister Strike",
					desc = "Sinister Strike Options",
					args = {
						sinisterstrike = {
							order = 1,
							type = "input",
							name = "Sinister Strike",
							desc = "Sinister Strike string.",
							usage = "<string[;string...]>",
							get = "GetStringVar",
							set = "SetStringVar",
						},
						sinisterstriketgl = {
							order = 2,
							type = "toggle",
							name = "Sinister Strike Toggle",
							desc = "Toggles the display of the Sinister Strike string.",
							get = "GetToggleVar",
							set = "SetToggleVar",
						},
						sinisterstrikecrit = {
							order = 3,
							type = "toggle",
							name = "Sinister Strike Crit Toggle",
							desc = "Toggles the display of the Sinister Strike string only on crits.",
							get = "GetToggleVar",
							set = "SetToggleVar",
						},
						sinisterstrikechance = {
							order = 4,
							type = "range",
							name = "Sinister Strike Chance",
							desc = "Chance of Sinister Strike string out of 100.",
							min = 0,
							max = 1,
							step = 0.01,
							get = "GetChance",
							set = "SetChance",
							isPercent = true,
						}
					}
				},
				hemorrhagegrp = {
					type = "group",
					handler = pootpoot,
					name = "Hemorrhage",
					desc = "Hemorrhage Options",
					args = {
						hemorrhage = {
							order = 1,
							type = "input",
							name = "Hemorrhage",
							desc = "Hemorrhage string.",
							usage = "<string[;string...]>",
							get = "GetStringVar",
							set = "SetStringVar",
						},
						hemorrhagetgl = {
							order = 2,
							type = "toggle",
							name = "Hemorrhage Toggle",
							desc = "Toggles the display of the Hemorrhage string.",
							get = "GetToggleVar",
							set = "SetToggleVar",
						},
						hemorrhagecrit = {
							order = 3,
							type = "toggle",
							name = "Hemorrhage Crit Toggle",
							desc = "Toggles the display of the Hemorrhage string only on crits.",
							get = "GetToggleVar",
							set = "SetToggleVar",
						},
						hemorrhagechance = {
							order = 4,
							type = "range",
							name = "Hemorrhage Chance",
							desc = "Chance of Hemorrhage string out of 100.",
							min = 0,
							max = 1,
							step = 0.01,
							get = "GetChance",
							set = "SetChance",
							isPercent = true,
						}
					}
				},
				eviscerategrp = {
					type = "group",
					handler = pootpoot,
					name = "Eviscerate",
					desc = "Eviscerate Options",
					args = {
						eviscerate = {
							order = 1,
							type = "input",
							name = "Eviscerate",
							desc = "Eviscerate string.",
							usage = "<string[;string...]>",
							get = "GetStringVar",
							set = "SetStringVar",
						},
						evisceratetgl = {
							order = 2,
							type = "toggle",
							name = "Eviscerate Toggle",
							desc = "Toggles the display of the Eviscerate string.",
							get = "GetToggleVar",
							set = "SetToggleVar",
						},
						evisceratecrit = {
							order = 3,
							type = "toggle",
							name = "Eviscerate Crit Toggle",
							desc = "Toggles the display of the Eviscerate string only on crits.",
							get = "GetToggleVar",
							set = "SetToggleVar",
						},
						evisceratechance = {
							order = 4,
							type = "range",
							name = "Eviscerate Chance",
							desc = "Chance of Eviscerate string out of 100.",
							min = 0,
							max = 1,
							step = 0.01,
							get = "GetChance",
							set = "SetChance",
							isPercent = true,
						}
					}
				},
				rupturegrp = {
					type = "group",
					handler = pootpoot,
					name = "Rupture",
					desc = "Rupture Options",
					args = {
						rupture = {
							order = 1,
							type = "input",
							name = "Rupture",
							desc = "Rupture string.",
							usage = "<string[;string...]>",
							get = "GetStringVar",
							set = "SetStringVar",
						},
						rupturetgl = {
							order = 2,
							type = "toggle",
							name = "Rupture Toggle",
							desc = "Toggles the display of the Rupture string.",
							get = "GetToggleVar",
							set = "SetToggleVar",
						},
						rupturechance = {
							order = 3,
							type = "range",
							name = "Rupture Chance",
							desc = "Chance of Rupture string out of 100.",
							min = 0,
							max = 1,
							step = 0.01,
							get = "GetChance",
							set = "SetChance",
							isPercent = true,
						}
					}
				},
				sliceanddicegrp = {
					type = "group",
					handler = pootpoot,
					name = "Slice and Dice",
					desc = "Slice and Dice Options",
					args = {
						sliceanddice = {
							order = 1,
							type = "input",
							name = "Slice and Dice",
							desc = "Slice and Dice string.",
							usage = "<string[;string...]>",
							get = "GetStringVar",
							set = "SetStringVar",
						},
						sliceanddicetgl = {
							order = 2,
							type = "toggle",
							name = "Slice and Dice Toggle",
							desc = "Toggles the display of the Slice and Dice string.",
							get = "GetToggleVar",
							set = "SetToggleVar",
						},
						sliceanddicechance = {
							order = 3,
							type = "range",
							name = "Slice and Dice Chance",
							desc = "Chance of Slice and Dice string out of 100.",
							min = 0,
							max = 1,
							step = 0.01,
							get = "GetChance",
							set = "SetChance",
							isPercent = true,
						}
					}
				},
				deadlythrowgrp = {
					type = "group",
					handler = pootpoot,
					name = "Deadly Throw",
					desc = "Deadly Throw Options",
					args = {
						deadlythrow = {
							order = 1,
							type = "input",
							name = "Deadly Throw",
							desc = "Deadly Throw string.",
							usage = "<string[;string...]>",
							get = "GetStringVar",
							set = "SetStringVar",
						},
						deadlythrowtgl = {
							order = 2,
							type = "toggle",
							name = "Deadly Throw Toggle",
							desc = "Toggles the display of the Deadly Throw string.",
							get = "GetToggleVar",
							set = "SetToggleVar",
						},
						deadlythrowcrit = {
							order = 3,
							type = "toggle",
							name = "Deadly Throw Crit Toggle",
							desc = "Toggles the display of the Deadly Throw string only on crits.",
							get = "GetToggleVar",
							set = "SetToggleVar",
						},
						deadlythrowchance = {
							order = 4,
							type = "range",
							name = "Deadly Throw Chance",
							desc = "Chance of Deadly Throw string out of 100.",
							min = 0,
							max = 1,
							step = 0.01,
							get = "GetChance",
							set = "SetChance",
							isPercent = true,
						}
					}
				},
				kidneyshotgrp = {
					type = "group",
					handler = pootpoot,
					name = "Kidney Shot",
					desc = "Kidney Shot Options",
					args = {
						kidneyshot = {
							order = 1,
							type = "input",
							name = "Kidney Shot",
							desc = "Kidney Shot string.",
							usage = "<string[;string...]>",
							get = "GetStringVar",
							set = "SetStringVar",
						},
						kidneyshottgl = {
							order = 2,
							type = "toggle",
							name = "Kidney Shot Toggle",
							desc = "Toggles the display of the Kidney Shot string.",
							get = "GetToggleVar",
							set = "SetToggleVar",
						},
						kidneyshotchance = {
							order = 3,
							type = "range",
							name = "Kidney Shot Chance",
							desc = "Chance of Kidney Shot string out of 100.",
							min = 0,
							max = 1,
							step = 0.01,
							get = "GetChance",
							set = "SetChance",
							isPercent = true,
						}
					}
				},
				backstabgrp = {
					type = "group",
					handler = pootpoot,
					name = "Backstab",
					desc = "Backstab Options",
					args = {
						backstab = {
							order = 1,
							type = "input",
							name = "Backstab",
							desc = "Backstab string.",
							usage = "<string[;string...]>",
							get = "GetStringVar",
							set = "SetStringVar",
						},
						backstabtgl = {
							order = 2,
							type = "toggle",
							name = "Backstab Toggle",
							desc = "Toggles the display of the Backstab string.",
							get = "GetToggleVar",
							set = "SetToggleVar",
						},
						backstabcrit = {
							order = 3,
							type = "toggle",
							name = "Backstab Crit Toggle",
							desc = "Toggles the display of the Backstab string only on crits.",
							get = "GetToggleVar",
							set = "SetToggleVar",
						},
						backstabchance = {
							order = 4,
							type = "range",
							name = "Backstab Chance",
							desc = "Chance of Backstab string out of 100.",
							min = 0,
							max = 1,
							step = 0.01,
							get = "GetChance",
							set = "SetChance",
							isPercent = true,
						}
					}
				},
				gougegrp = {
					type = "group",
					handler = pootpoot,
					name = "Gouge",
					desc = "Gouge Options",
					args = {
						gouge = {
							order = 1,
							type = "input",
							name = "Gouge",
							desc = "Gouge string.",
							usage = "<string[;string...]>",
							get = "GetStringVar",
							set = "SetStringVar",
						},
						gougetgl = {
							order = 2,
							type = "toggle",
							name = "Gouge Toggle",
							desc = "Toggles the display of the Gouge string.",
							get = "GetToggleVar",
							set = "SetToggleVar",
						},
						gougechance = {
							order = 3,
							type = "range",
							name = "Gouge Chance",
							desc = "Chance of Gouge string out of 100.",
							min = 0,
							max = 1,
							step = 0.01,
							get = "GetChance",
							set = "SetChance",
							isPercent = true,
						}
					}
				},
				shivgrp = {
					type = "group",
					handler = pootpoot,
					name = "Shiv",
					desc = "Shiv Options",
					args = {
						shiv = {
							order = 1,
							type = "input",
							name = "Shiv",
							desc = "Shiv string.",
							usage = "<string[;string...]>",
							get = "GetStringVar",
							set = "SetStringVar",
						},
						shivtgl = {
							order = 2,
							type = "toggle",
							name = "Shiv Toggle",
							desc = "Toggles the display of the Shiv string.",
							get = "GetToggleVar",
							set = "SetToggleVar",
						},
						shivchance = {
							order = 3,
							type = "range",
							name = "Shiv Chance",
							desc = "Chance of Shiv string out of 100.",
							min = 0,
							max = 1,
							step = 0.01,
							get = "GetChance",
							set = "SetChance",
							isPercent = true,
						}
					}
				},
				blindgrp = {
					type = "group",
					handler = pootpoot,
					name = "Blind",
					desc = "Blind Options",
					args = {
						blind = {
							order = 1,
							type = "input",
							name = "Blind",
							desc = "Blind string.",
							usage = "<string[;string...]>",
							get = "GetStringVar",
							set = "SetStringVar",
						},
						blindtgl = {
							order = 2,
							type = "toggle",
							name = "Blind Toggle",
							desc = "Toggles the display of the Blind string.",
							get = "GetToggleVar",
							set = "SetToggleVar",
						},
						blindchance = {
							order = 3,
							type = "range",
							name = "Blind Chance",
							desc = "Chance of Blind string out of 100.",
							min = 0,
							max = 1,
							step = 0.01,
							get = "GetChance",
							set = "SetChance",
							isPercent = true,
						}
					}
				},
				feintgrp = {
					type = "group",
					handler = pootpoot,
					name = "Feint",
					desc = "Feint Options",
					args = {
						feint = {
							order = 1,
							type = "input",
							name = "Feint",
							desc = "Feint string.",
							usage = "<string[;string...]>",
							get = "GetStringVar",
							set = "SetStringVar",
						},
						feinttgl = {
							order = 2,
							type = "toggle",
							name = "Feint Toggle",
							desc = "Toggles the display of the Feint string.",
							get = "GetToggleVar",
							set = "SetToggleVar",
						},
						feintchance = {
							order = 3,
							type = "range",
							name = "Feint Chance",
							desc = "Chance of Feint string out of 100.",
							min = 0,
							max = 1,
							step = 0.01,
							get = "GetChance",
							set = "SetChance",
							isPercent = true,
						}
					}
				},
				shadowstepgrp = {
					type = "group",
					handler = pootpoot,
					name = "Shadowstep",
					desc = "Shadowstep Options",
					args = {
						shadowstep = {
							order = 1,
							type = "input",
							name = "Shadowstep",
							desc = "Shadowstep string.",
							usage = "<string[;string...]>",
							get = "GetStringVar",
							set = "SetStringVar",
						},
						shadowsteptgl = {
							order = 2,
							type = "toggle",
							name = "Shadowstep Toggle",
							desc = "Toggles the display of the Shadowstep string.",
							get = "GetToggleVar",
							set = "SetToggleVar",
						},
						shadowstepchance = {
							order = 3,
							type = "range",
							name = "Shadowstep Chance",
							desc = "Chance of Shadowstep string out of 100.",
							min = 0,
							max = 1,
							step = 0.01,
							get = "GetChance",
							set = "SetChance",
							isPercent = true,
						}
					}
				},
				garrotegrp = {
					type = "group",
					handler = pootpoot,
					name = "Garrote",
					desc = "Garrote Options",
					args = {
						garrote = {
							order = 1,
							type = "input",
							name = "Garrote",
							desc = "Garrote string.",
							usage = "<string[;string...]>",
							get = "GetStringVar",
							set = "SetStringVar",
						},
						garrotetgl = {
							order = 2,
							type = "toggle",
							name = "Garrote Toggle",
							desc = "Toggles the display of the Garrote string.",
							get = "GetToggleVar",
							set = "SetToggleVar",
						},
						garrotechance = {
							order = 3,
							type = "range",
							name = "Garrote Chance",
							desc = "Chance of Garrote string out of 100.",
							min = 0,
							max = 1,
							step = 0.01,
							get = "GetChance",
							set = "SetChance",
							isPercent = true,
						}
					}
				},
				cheapshotgrp = {
					type = "group",
					handler = pootpoot,
					name = "Cheap Shot",
					desc = "Cheap Shot Options",
					args = {
						cheapshot = {
							order = 1,
							type = "input",
							name = "Cheap Shot",
							desc = "Cheap Shot string.",
							usage = "<string[;string...]>",
							get = "GetStringVar",
							set = "SetStringVar",
						},
						cheapshottgl = {
							order = 2,
							type = "toggle",
							name = "Cheap Shot Toggle",
							desc = "Toggles the display of the Cheap Shot string.",
							get = "GetToggleVar",
							set = "SetToggleVar",
						},
						cheapshotchance = {
							order = 3,
							type = "range",
							name = "Cheap Shot Chance",
							desc = "Chance of Cheap Shot string out of 100.",
							min = 0,
							max = 1,
							step = 0.01,
							get = "GetChance",
							set = "SetChance",
							isPercent = true,
						}
					}
				},
				ambushgrp = {
					type = "group",
					handler = pootpoot,
					name = "Ambush",
					desc = "Ambush Options",
					args = {
						ambush = {
							order = 1,
							type = "input",
							name = "Ambush",
							desc = "Ambush string.",
							usage = "<string[;string...]>",
							get = "GetStringVar",
							set = "SetStringVar",
						},
						ambushtgl = {
							order = 2,
							type = "toggle",
							name = "Ambush Toggle",
							desc = "Toggles the display of the Ambush string.",
							get = "GetToggleVar",
							set = "SetToggleVar",
						},
						ambushcrit = {
							order = 3,
							type = "toggle",
							name = "Ambush Crit Toggle",
							desc = "Toggles the display of the Ambush string only on crits.",
							get = "GetToggleVar",
							set = "SetToggleVar",
						},
						ambushchance = {
							order = 4,
							type = "range",
							name = "Ambush Chance",
							desc = "Chance of Ambush string out of 100.",
							min = 0,
							max = 1,
							step = 0.01,
							get = "GetChance",
							set = "SetChance",
							isPercent = true,
						}
					}
				},
				mutilategrp = {
					type = "group",
					handler = pootpoot,
					name = "Mutilate",
					desc = "Mutilate Options",
					args = {
						mutilate = {
							order = 1,
							type = "input",
							name = "Mutilate",
							desc = "Mutilate string.",
							usage = "<string[;string...]>",
							get = "GetStringVar",
							set = "SetStringVar",
						},
						mutilatetgl = {
							order = 2,
							type = "toggle",
							name = "Mutilate Toggle",
							desc = "Toggles the display of the Mutilate string.",
							get = "GetToggleVar",
							set = "SetToggleVar",
						},
						mutilatecrit = {
							order = 3,
							type = "toggle",
							name = "Mutilate Crit Toggle",
							desc = "Toggles the display of the Mutilate string only on crits.",
							get = "GetToggleVar",
							set = "SetToggleVar",
						},
						mutilatechance = {
							order = 4,
							type = "range",
							name = "Mutilate Chance",
							desc = "Chance of Mutilate string out of 100.",
							min = 0,
							max = 1,
							step = 0.01,
							get = "GetChance",
							set = "SetChance",
							isPercent = true,
						}
					}
				},
				envenomgrp = {
					type = "group",
					handler = pootpoot,
					name = "Envenom",
					desc = "Envenom Options",
					args = {
						envenom = {
							order = 1,
							type = "input",
							name = "Envenom",
							desc = "Envenom string.",
							usage = "<string[;string...]>",
							get = "GetStringVar",
							set = "SetStringVar",
						},
						envenomtgl = {
							order = 2,
							type = "toggle",
							name = "Envenom Toggle",
							desc = "Toggles the display of the Envenom string.",
							get = "GetToggleVar",
							set = "SetToggleVar",
						},
						envenomcrit = {
							order = 3,
							type = "toggle",
							name = "Envenom Crit Toggle",
							desc = "Toggles the display of the Envenom string only on crits.",
							get = "GetToggleVar",
							set = "SetToggleVar",
						},
						envenomchance = {
							order = 4,
							type = "range",
							name = "Envenom Chance",
							desc = "Chance of Envenom string out of 100.",
							min = 0,
							max = 1,
							step = 0.01,
							get = "GetChance",
							set = "SetChance",
							isPercent = true,
						}
					}
				},
				bladeflurrygrp = {
					type = "group",
					handler = pootpoot,
					name = "Blade Flurry",
					desc = "Blade Flurry Options",
					args = {
						bladeflurry = {
							order = 1,
							type = "input",
							name = "Blade Flurry",
							desc = "Blade Flurry string.",
							usage = "<string[;string...]>",
							get = "GetStringVar",
							set = "SetStringVar",
						},
						bladeflurrytgl = {
							order = 2,
							type = "toggle",
							name = "Blade Flurry Toggle",
							desc = "Toggles the display of the Blade Flurry string.",
							get = "GetToggleVar",
							set = "SetToggleVar",
						},
						bladeflurrychance = {
							order = 3,
							type = "range",
							name = "Blade Flurry Chance",
							desc = "Chance of Blade Flurry string out of 100.",
							min = 0,
							max = 1,
							step = 0.01,
							get = "GetChance",
							set = "SetChance",
							isPercent = true,
						}
					}
				},
				envenomgrp = {
					type = "group",
					handler = pootpoot,
					name = "Cloak of Shadows",
					desc = "Cloak of Shadows Options",
					args = {
						cloakofshadows = {
							order = 1,
							type = "input",
							name = "Cloak of Shadows",
							desc = "Cloak of Shadows string.",
							usage = "<string[;string...]>",
							get = "GetStringVar",
							set = "SetStringVar",
						},
						cloakofshadowstgl = {
							order = 2,
							type = "toggle",
							name = "Cloak of Shadows Toggle",
							desc = "Toggles the display of the Cloak of Shadows string.",
							get = "GetToggleVar",
							set = "SetToggleVar",
						},
						cloakofshadowspvp = {
							order = 3,
							type = "toggle",
							name = "Enable Cloak of Shadows in Battlegrounds.",
							desc = "Enables the display of the Cloak of Shadows string in Battlegrounds.",
							get = "GetToggleVar",
							set = "SetToggleVar",
						},
						cloakofshadowschance = {
							order = 4,
							type = "range",
							name = "Cloak of Shadows Chance",
							desc = "Chance of Cloak of Shadows string out of 100.",
							min = 0,
							max = 1,
							step = 0.01,
							get = "GetChance",
							set = "SetChance",
							isPercent = true,
						}
					}
				},
				vanishgrp = {
					type = "group",
					handler = pootpoot,
					name = "Vanish",
					desc = "Vanish Options",
					args = {
						vanish = {
							order = 1,
							type = "input",
							name = "Vanish",
							desc = "Vanish string.",
							usage = "<string[;string...]>",
							get = "GetStringVar",
							set = "SetStringVar",
						},
						vanishtgl = {
							order = 2,
							type = "toggle",
							name = "Vanish Toggle",
							desc = "Toggles the display of the Vanish string.",
							get = "GetToggleVar",
							set = "SetToggleVar",
						},
						vanishpvp = {
							order = 3,
							type = "toggle",
							name = "Enable Vanish in Battlegrounds.",
							desc = "Enables the display of the Vanish string in Battlegrounds.",
							get = "GetToggleVar",
							set = "SetToggleVar",
						},
						vanishchance = {
							order = 4,
							type = "range",
							name = "Vanish Chance",
							desc = "Chance of Vanish string out of 100.",
							min = 0,
							max = 1,
							step = 0.01,
							get = "GetChance",
							set = "SetChance",
							isPercent = true,
						}
					}
				}
			}
		},
		general = {
			order = 3,
			type = "group",
			handler = pootpoot,
			name = "General",
			desc = "General Spells and Events",
			args = {
				bgtgl = {
					order = 1,
					type = "toggle",
					name = "Battleground Enable",
					desc = "Enables the mod in Battlegrounds.",
					get = "GetToggleVar",
					set = "SetZoneVar",
				},
				instancetgl = {
					order = 2,
					type = "toggle",
					name = "Instance Enable",
					desc = "Enables the mod in instances.",
					get = "GetToggleVar",
					set = "SetZoneVar",
				},
				showMinimap = {
					order = 3,
					type = "toggle",
					name = "Enable Minimap Icon",
					desc = "Enables the Minimap Icon.",
					get = "GetToggleVar",
					set = "SetShowMinimap",
				},
				ding = {
					order = 4,
					type = "input",
					name = "Ding",
					desc = "Level up string.",
					usage = "<string[;string...]>",
					get = "GetStringVar",
					set = "SetStringVar",
				},
				dingtgl = {
					order = 5,
					type = "toggle",
					name = "Ding Toggle",
					desc = "Toggles the display of the level up string.",
					get = "GetToggleVar",
					set = "SetToggleVar",
				},
				interrupt = {
					order = 6,
					type = "input",
					name = "Interrupt",
					desc = "Interrupt string. Works on healing spells.",
					usage = "<string[;string...]>",
					get = "GetStringVar",
					set = "SetStringVar",
				},
				interrupttgl = {
					order = 7,
					type = "toggle",
					name = "Interrupt Toggle",
					desc = "Toggles the display of the Interrupt string.",
					get = "GetToggleVar",
					set = "SetToggleVar",
				},
				interruptchance = {
					order = 8,
					type = "range",
					name = "Interrupt Chance",
					desc = "Chance of interrupt String display.",
					min = 0,
					max = 1,
					step = 0.01,
					get = "GetChance",
					set = "SetChance",
					isPercent = true,
				},
				cannibalize = {
					order = 9,
					type = "input",
					name = "Cannibalize",
					desc = "Cannibalize string.",
					usage = "<string[;string...]>",
					get = "GetStringVar",
					set = "SetStringVar",
				},
				cannibalizetgl = {
					order = 10,
					type = "toggle",
					name = "Cannibalize Toggle",
					desc = "Toggles the display of the Cannibalize string.",
					get = "GetToggleVar",
					set = "SetToggleVar",
				},
				cannibalizechance = {
					order = 11,
					type = "range",
					name = "Cannibalize Chance",
					desc = "Chance of Cannibalize String display.",
					min = 0,
					max = 1,
					step = 0.01,
					get = "GetChance",
					set = "SetChance",
					isPercent = true,
				},
				disablegeneral = {
					order = 12,
					type = "execute",
					name = "Disable General Spells",
					desc = "Disables all General spells",
					func = "DisableGeneralSpells",
				}
			}
		}
	}
}

local defaults = {
	profile = {
		showMinimap = true,
		charge = "Charge!",	-- Warrior Spells
		chargetgl = true,
		chargechance = 1,
		execute = "Execute!",
		executetgl = true,
		executecrit = true,
		executechance = 1,
		mortalstrike = "Mortal Strike!",
		mortalstriketgl = true,
		mortalstrikecrit = true,
		mortalstrikechance = 1,
		bloodthirst = "Bloodthirst!",
		bloodthirsttgl = true,
		bloodthirstcrit = true,
		bloodthirstchance = 1,
		rampage = "Rampage!",
		rampagetgl = true,
		rampagechance = 1,
		shieldslam = "Shield Slam!",
		shieldslamtgl = true,
		shieldslamcrit = true,
		shieldslamchance = 1,
		taunt = "Taunting %t!",
		tauntresist = "Taunt on %t failed!",
		taunttgl = true,
		tauntresisttgl = false,
		tauntchance = 1,
		devastate = "Devastate!",
		devastatetgl = true,
		devastatecrit = true,
		devastatechance = 1,
		fire = "Fire!",		-- Mage Spells
		fireballtgl = false,
		fireballcasttgl = false,
		fireblasttgl = false,
		pyroblasttgl = false,
		pyroblastcasttgl = false,
		dragonsbreathtgl = false,
		firecrit = true,
		firechance = 1,
		firecastchance = 0.25,
		frost = "Frost!",
		frostbolttgl = false,
		frostboltcasttgl = false,
		coneofcoldtgl = false,
		frostcrit = true,
		frostchance = 1,
		frostcastchance = 0.25,
		polymorph = "Polymorphing %t",
		polymorphtgl = false,
		polymorphchance = 1,
		blink = "Blink!",
		blinktgl = true,
		blinkchance = 1,
		ding = "Ding!",		-- General Spells
		dingtgl = false,
		interrupt = "Interrupt!",
		interrupttgl = true,
		interruptchance = 1,
		cannibalize = "BRAINS!",
		cannibalizetgl = true,
		cannibalizechance = 1,
		bgtgl = true,
		instancetgl = true,
		stormstrike = "Stormstrike!",	-- Shaman Spells
		stormstriketgl = true,
		stormstrikechance = 1,
		lightningbolt = "Lightning Bolt!",
		lightningbolttgl = true,
		lightningboltcrit = true,
		lightningboltchance = 1,
		earthshock = "Earth Shock!",
		earthshocktgl = true,
		earthshockcrit = true,
		earthshockchance = 1,
		flameshock = "Flame Shock!",
		flameshocktgl = true,
		flameshockcrit = true,
		flameshockchance = 1,
		purge = "Purge!",
		purgetgl = true,
		purgechance = 1,
		frostshock = "Frost Shock!",
		frostshocktgl = true,
		frostshockcrit = true,
		frostshockchance = 1,
		chainlightning = "Chain Lightning!",
		chainlightningtgl = true,
		chainlightningcrit = true,
		chainlightningchance = 1,
		bloodlust = "Bloodlust!",	-- Heroism for alliance
		bloodlusttgl = true,
		bloodlustchance = 1,
		arcaneshot = "Arcane Shot!",	-- Hunter Spells
		arcaneshottgl = true,
		arcaneshotcrit = true,
		arcaneshotchance = 1,
		curseofshadow = "Curse of Shadow!",	--Warlock Spells
		curseofshadowtgl = true,
		curseofshadowchance = 1,
		shadowbolt = "Shadow Bolt!",	-- Castable.
		shadowbolttgl = false,
		shadowboltcrit = true,
		shadowboltchance = 1,
		shadowboltcast = "Casting Shadow Bolt!",
		shadowboltcasttgl = true,
		shadowboltcastchance = 1,
		corruption = "Corruption!",	-- Castable if talented.
		corruptiontgl = true,
		corruptionchance = 1,
		immolate = "Immolate!",	-- Castable.
		immolatetgl = false,
		immolatecrit = true,
		immolatechance = 1,
		immolatecast = "Casting Immolate!",
		immolatecasttgl = true,
		immolatecastchance = 1,
		shadowburn = "Shadowburn!",
		shadowburntgl = true,
		shadowburncrit = true,
		shadowburnchance = 1,
		deathcoil = "Death Coil!",
		deathcoiltgl = true,
		deathcoilcrit = false,
		deathcoilchance = 1,
		howlofterror = "Howl of Terror!",	-- Castable.
		howlofterrortgl = true,
		howlofterrorchance = 1,
		curseofagony = "Curse of Agony!",
		curseofagonytgl = true,
		curseofagonychance = 1,
		lifetap = "Life Tap!",
		lifetaptgl = true,
		lifetapchance = 1,
		hellfire = "Hellfire!",	-- Channeled.
		hellfiretgl = true,
		hellfirechance = 1,
		incinerate = "Incinerate!",	-- Castable.
		incineratetgl = true,
		incineratecrit = true,
		incineratechance = 1,
		incineratecast = "Casting Incinerate!",
		incineratecasttgl = true,
		incineratecastchance = 1,
		curseofweakness = "Curse of Weakness!",
		curseofweaknesstgl = true,
		curseofweaknesschance = 1,
		curseofrecklessness = "Curse of Recklessness!",
		curseofrecklessnesstgl = true,
		curseofrecklessnesschance = 1,
		curseoftongues = "Curse of Tongues!",
		curseoftonguestgl = true,
		curseoftongueschance = 1,
		curseofdoom = "Curse of Doom!",
		curseofdoomtgl = true,
		curseofdoomchance = 1,
		seedofcorruption = "Seed of Corruption!",	-- Castable.
		seedofcorruptiontgl = true,
		seedofcorruptionchance = 1,
		banish = "Banishing %t!",	-- Castable.
		banishtgl = true,
		banishchance = 1,
		fear = "Fearing %t!",	-- Castable.
		feartgl = true,
		fearchance = 1,
		sinisterstrike = "Sinister Strike!",	-- Rogue Spells
		sinisterstriketgl = true,
		sinisterstrikecrit = true,
		sinisterstrikechance = 1,
		hemorrhage = "Hemorrhage!",
		hemorrhagetgl = true,
		hemorrhagecrit = true,
		hemorrhagechance = 1,
		eviscerate = "Eviscerate!",
		evisceratetgl = true,
		evisceratecrit = true,
		evisceratechance = 1,
		rupture = "Rupture!",
		rupturetgl = true,
		rupturechance = 1,
		sliceanddice = "Slice and Dice!",
		sliceanddicetgl = true,
		sliceanddicechance = 1,
		deadlythrow = "Deadly Throw!",
		deadlythrowtgl = true,
		deadlythrowcrit = true,
		deadlythrowchance = 1,
		kidneyshot = "Kidney Shot!",
		kidneyshottgl = true,
		kidneyshotchance = 1,
		backstab = "Backstab!",
		backstabtgl = true,
		backstabcrit = true,
		backstabchance = 1,
		gouge = "Gouge!",
		gougetgl = true,
		gougechance = 1,
		shiv = "Shiv!",
		shivtgl = true,
		shivchance = 1,
		blind = "Blind!",
		blindtgl = true,
		blindchance = 1,
		feint = "Feignt!",
		feinttgl = true,
		feintchance = 1,
		shadowstep = "Shadowstep!",
		shadowsteptgl = true,
		shadowstepchance = 1,
		cloakofshadows = "Cloak of Shadows!",	-- PvP
		cloakofshadowstgl = true,
		cloakofshadowspvp = false,
		cloakofshadowschance = 1,
		vanish = "Ninja Vanish!",		-- PvP
		vanishtgl = true,
		vanishpvp = false,
		vanishchance = 1,
		garrote = "Garrote!",
		garrotetgl = true,
		garrotechance = 1,
		cheapshot = "Cheap Shot!",
		cheapshottgl = true,
		cheapshotchance = 1,
		ambush = "Ambush!",
		ambushtgl = true,
		ambushcrit = true,
		ambushchance = 1,
		mutilate = "Mutilate!",
		mutilatetgl = true,
		mutilatecrit = true,
		mutilatechance = 1,
		envenom = "Envenom!",
		envenomtgl = true,
		envenomcrit = true,
		envenomchance = 1,
		bladeflurry = "Blade Flurry!",
		bladeflurrytgl = true,
		bladeflurrychance = 1,
	}
}

local optionsFrame
local profilesFrame

function pootpoot:DisableWarriorSpells()
	self.db.profile.chargetgl = false
	self.db.profile.executetgl = false
	self.db.profile.mortalstriketgl = false
	self.db.profile.rampagetgl = false
	self.db.profile.shieldslamtgl = false
	self.db.profile.taunttgl = false
	self.db.profile.devastatetgl = false
	self.db.profile.bloodthirsttgl = false
end

function pootpoot:DisableMageSpells()
	self.db.profile.fireballtgl = false		--fire
	self.db.profile.fireballcasttgl = false
	self.db.profile.fireblasttgl = false
	self.db.profile.pyroblasttgl = false
	self.db.profile.pyroblastcasttgl = false
	self.db.profile.dragonsbreathtgl = false
	self.db.profile.frostbolttgl = false	--frost
	self.db.profile.frostboltcasttgl = false
	self.db.profile.coneofcoldtgl = false
	self.db.profile.polymorphtgl = false	--arcane
	self.db.profile.blinktgl = false
end

function pootpoot:DisableShamanSpells()
	self.db.profile.stormstriketgl = false
	self.db.profile.lightningbolttgl = false
	self.db.profile.earthshocktgl = false
	self.db.profile.flameshocktgl = false
	self.db.profile.purgetgl = false
	self.db.profile.frostshocktgl = false
	self.db.profile.chainlightningtgl = false
	self.db.profile.bloodlusttgl = false
end

function pootpoot:DisableHunterSpells()
	self.db.profile.arcaneshottgl = false
end

function pootpoot:DisableWarlockSpells()
	self.db.profile.shadowbolttgl = false
	self.db.profile.shadowboltcasttgl = false
	self.db.profile.deathcoiltgl = false
	self.db.profile.lifetaptgl = false
	self.db.profile.curseofshadowtgl = false
	self.db.profile.corruptiontgl = false
	self.db.profile.immolatetgl = false
	self.db.profile.immolatecasttgl = false
	self.db.profile.shadowburntgl = false
	self.db.profile.howlofterrortgl = false
	self.db.profile.curseofagonytgl = false
	self.db.profile.hellfiretgl = false
	self.db.profile.incineratetgl = false
	self.db.profile.incineratecasttgl = false
	self.db.profile.curseofweaknesstgl = false
	self.db.profile.curseofrecklessnesstgl = false
	self.db.profile.curseoftonguestgl = false
	self.db.profile.curseofdoomtgl = false
	self.db.profile.seedofcorruptiontgl = false
	self.db.profile.banishtgl = false
	self.db.profile.feartgl = false
end

function pootpoot:DisableRogueSpells()
	self.db.profile.sinisterstriketgl = false
	self.db.profile.hemorrhagetgl = false
	self.db.profile.evisceratetgl = false
	self.db.profile.rupturetgl = false
	self.db.profile.sliceanddicetgl = false
	self.db.profile.deadlythrowtgl = false
	self.db.profile.kidneyshottgl = false
	self.db.profile.backstabtgl = false
	self.db.profile.gougetgl = false
	self.db.profile.shivtgl = false
	self.db.profile.blindtgl = false
	self.db.profile.feignttgl = false
	self.db.profile.shadowsteptgl = false
	self.db.profile.cloakofshadowstgl = false
	self.db.profile.vanishtgl = false
	self.db.profile.garrotetgl = false
	self.db.profile.cheapshottgl = false
	self.db.profile.ambushtgl = false
	self.db.profile.mutilatetgl = false
	self.db.profile.envenomtgl = false
	self.db.profile.bladeflurrytgl = false
	self.db.profile.combatpotencytgl = false
end

function pootpoot:DisableGeneralSpells()
	self.db.profile.dingtgl = false
	self.db.profile.interrupttgl = false
	self.db.profile.cannibalizetgl = false
end

function pootpoot:ChatCommand(input)
	LibStub("AceConfigCmd-3.0").HandleCommand(pootpoot, "ppc", "pootpoot", input)
end

function pootpoot:OpenPootConfig()
	LibStub("AceConfigDialog-3.0"):SetDefaultSize("pootpoot", 500, 350)
	LibStub("AceConfigDialog-3.0"):Open("pootpoot", configFrame)
end

function pootpoot:OpenPootProfileConfig()
	InterfaceOptionsFrame_OpenToFrame(self.profilesFrame)
end

function pootpoot:PootOnYou(input)
	local t=UnitName("target")
	if( t ) then
		if( t ~= self.player ) then
			SendChatMessage("poots on %t.", "EMOTE", nil, nil)
		else
			local genderTable = { "its", "his", "her" }
			SendChatMessage('poots ' .. genderTable[UnitSex(t)] .. ' pants.', "EMOTE", nil, nil)
		end
	else
		SendChatMessage("poots.", "EMOTE", nil, nil)
	end
end

function pootpoot:FoamOnMe(input)
	SendChatMessage("foams at the mouth.", "EMOTE", nil, nil)
end

function pootpoot:Bong(input)
	local t=UnitName("target")
	if( t ) then
		if( t ~= self.player ) then
			SendChatMessage("passes the bong to %t.", "EMOTE", nil, nil)
		else
			SendChatMessage("hits the bong.", "EMOTE", nil, nil)
		end
	else
		SendChatMessage("hits the bong.", "EMOTE", nil, nil)
	end
end

function pootpoot:OnInitialize()
	self.db = LibStub("AceDB-3.0"):New("pootpootDB", defaults, "Default")

	LibStub("AceConfig-3.0"):RegisterOptionsTable("pootpoot", options)
	LibStub("AceConfig-3.0"):RegisterOptionsTable("PootPoot About", aboutopts)
	LibStub("AceConfig-3.0"):RegisterOptionsTable("PootPoot Profiles", LibStub("AceDBOptions-3.0"):GetOptionsTable(self.db))
	self.optionsFrame = LibStub("AceConfigDialog-3.0"):AddToBlizOptions("PootPoot About", "PootPoot")
	self.profilesFrame = LibStub("AceConfigDialog-3.0"):AddToBlizOptions("PootPoot Profiles", "Profiles", "PootPoot")
	self:RegisterChatCommand("pootpoot", "ChatCommand")
	self:RegisterChatCommand("ppc", "ChatCommand")
	self:RegisterChatCommand("poot", "PootOnYou")
	self:RegisterChatCommand("foam", "FoamOnMe")
	self:RegisterChatCommand("bong", "Bong")

	self.player = UnitName("player")
	zoneenable = true
end

function pootpoot:OnEnable()
	self:RegisterEvent("PLAYER_LEVEL_UP")
	self:RegisterEvent("COMBAT_LOG_EVENT_UNFILTERED","ParseCombat")
	self:RegisterEvent("PLAYER_ENTERING_WORLD")
	--self:RegisterComm(self.title)
	self:UpdateMinimapButton()
end

function pootpoot:OnDisable()
end

local function DispPootMsg( dmessage, dmsgtype )
	local tbl = { strsplit(";", dmessage) }
	SendChatMessage( tbl[math.random(#tbl)], dmsgtype, nil, nil )
end

function pootpoot:GetStringVar(info)
	return self.db.profile[info[#info]]
end

function pootpoot:SetStringVar(info, newValue)
	self.db.profile[info[#info]] = newValue
end

function pootpoot:GetToggleVar(info)
	return self.db.profile[info[#info]]
end

function pootpoot:SetToggleVar(info, newValue)
	self.db.profile[info[#info]] = newValue
end

function pootpoot:SetZoneVar(info, newValue)
	self.db.profile[info[#info]] = newValue
	self:ZoneCheck()
end

function pootpoot:GetChance(info)
	return self.db.profile[info[#info]]
end

function pootpoot:SetChance(info, newValue)
	self.db.profile[info[#info]] = newValue
end

function pootpoot:ZoneCheck()
	if InCombatLockdown() then
		self:ScheduleTimer("ZoneCheck", 1, self)
		return
	end
	local inInstance, instanceType
	inInstance, instanceType = IsInInstance()

	if inInstance then
		if instanceType == "pvp" then
			if self.db.profile.bgtgl == false then
				zoneenable = false
			else
				zoneenable = true
			end
			inpvpzone = true
		else
			if self.db.profile.instancetgl == false then
				zoneenable = false
			else
				zoneenable = true
			end
			inpvpzone = false
		end
	else
		zoneenable = true
		inpvpzone = false
	end
end

function pootpoot:PLAYER_ENTERING_WORLD(event)
	self:ZoneCheck()
end

function pootpoot:PLAYER_LEVEL_UP(args)
	if (self.db.profile.dingtgl) then
		DispPootMsg( self.db.profile.ding, "SAY" )
	end
end

function pootpoot:ParseCombat(arg1, timestamp, event, sourceGUID, sourceName, sourceFlags, destGUID, destName, destFlags, ...)
	local etype = COMBAT_EVENTS[event]
	local healtot, healamt, parent
	local amount, school, resisted, blocked, absorbed, critical, glancing, crushing
	local spellId, spellName, spellSchool, missType, powerType, extraAmount, environmentalType, extraSpellId, extraSpellName, extraSpellSchool
  	local text, texture, message, inout, color

	if zoneenable == false then
		return
	end

  	if not etype then
  		return
  	end

	local fromPlayer, fromPet
	if (sourceName and not CombatLog_Object_IsA(sourceFlags, COMBATLOG_OBJECT_NONE) ) then
		fromPlayer = CombatLog_Object_IsA(sourceFlags, COMBATLOG_FILTER_MINE)
	end
	if (destName and not CombatLog_Object_IsA(destFlags, COMBATLOG_OBJECT_NONE) ) then
		toPlayer = CombatLog_Object_IsA(destFlags, COMBATLOG_FILTER_MINE)
		toTarget = CombatLog_Object_IsA(destFlags, COMBATLOG_OBJECT_TARGET)
	end
	--if not from player or pet, then end
	if fromPlayer then
		if etype == "DAMAGE" then
			if event == "SWING_DAMAGE" then
				amount, school, resisted, blocked, absorbed, critical, glancing, crushing = select(1, ...)
			else
				spellId, spellName, spellSchool, amount, school, resisted, blocked, absorbed, critical, glancing, crushing = select(1, ...)
				texture = select(3, GetSpellInfo(spellId))
			end
			text = tostring(amount)
			if event == "SPELL_DAMAGE" then
				if spellName == "Execute" then
					if (self.db.profile.executetgl) then
						if (self.db.profile.executecrit) then
							if (critical) then
								if (math.random(100) <= (self.db.profile.executechance*100)) then
									DispPootMsg( self.db.profile.execute, "SAY" )
								end
							end
						elseif (math.random(100) <= (self.db.profile.executechance*100)) then
							DispPootMsg( self.db.profile.execute, "SAY" )
						end
					end
				elseif spellName == "Mortal Strike" then
					if (self.db.profile.mortalstriketgl) then
						if (self.db.profile.mortalstrikecrit) then
							if (critical) then
								if (math.random(100) <= (self.db.profile.mortalstrikechance*100)) then
									DispPootMsg( self.db.profile.mortalstrike, "SAY" )
								end
							end
						elseif (math.random(100) <= (self.db.profile.mortalstrikechance*100)) then
							DispPootMsg( self.db.profile.mortalstrike, "SAY" )
						end
					end
				elseif spellName == "Bloodthirst" then
					if (self.db.profile.bloodthirsttgl) then
						if (self.db.profile.bloodthirstcrit) then
							if (critical) then
								if (math.random(100) <= (self.db.profile.bloodthirstchance*100)) then
									DispPootMsg( self.db.profile.bloodthirst, "SAY" )
								end
							end
						elseif (math.random(100) <= (self.db.profile.bloodthirstchance*100)) then
							DispPootMsg( self.db.profile.bloodthirst, "SAY" )
						end
					end
				elseif spellName == "Shield Slam" then
					if (self.db.profile.shieldslamtgl) then
						if (self.db.profile.shieldslamcrit) then
							if (critical) then
								if (math.random(100) <= (self.db.profile.shieldslamchance*100)) then
									DispPootMsg( self.db.profile.shieldslam, "SAY" )
								end
							end
						elseif (math.random(100) <= (self.db.profile.shieldslamchance*100)) then
							DispPootMsg( self.db.profile.shieldslam, "SAY" )
						end
					end
				elseif spellName == "Devastate" then
					if (self.db.profile.devastatetgl) then
						if (self.db.profile.devastatecrit) then
							if (critical) then
								if (math.random(100) <= (self.db.profile.devastatechance*100)) then
									DispPootMsg( self.db.profile.devastate, "SAY" )
								end
							end
						elseif (math.random(100) <= (self.db.profile.devastatechance*100)) then
							DispPootMsg( self.db.profile.devastate, "SAY" )
						end
					end	-- MAGE SPELLS
				elseif spellName == "Fireball" then
					if (self.db.profile.fireballtgl) then
						if (self.db.profile.firecrit) then
							if (critical) then
								if (math.random(100) <= (self.db.profile.firechance*100)) then
									DispPootMsg( self.db.profile.fire, "SAY" )
								end
							end
						elseif (math.random(100) <= (self.db.profile.firechance*100)) then
							DispPootMsg( self.db.profile.fire, "SAY" )
						end
					end
				elseif spellName == "Fire Blast" then
					if (self.db.profile.fireblasttgl) then
						if (self.db.profile.firecrit) then
							if (critical) then
								if (math.random(100) <= (self.db.profile.firechance*100)) then
									DispPootMsg( self.db.profile.fire, "SAY" )
								end
							end
						elseif (math.random(100) <= (self.db.profile.firechance*100)) then
							DispPootMsg( self.db.profile.fire, "SAY" )
						end
					end
				elseif spellName == "Pyroblast" then
					if (self.db.profile.pyroblasttgl) then
						if (self.db.profile.firecrit) then
							if (critical) then
								if (math.random(100) <= (self.db.profile.firechance*100)) then
									DispPootMsg( self.db.profile.fire, "SAY" )
								end
							end
						elseif (math.random(100) <= (self.db.profile.firechance*100)) then
							DispPootMsg( self.db.profile.fire, "SAY" )
						end
					end
				elseif spellName == "Dragon's Breath" then
					if (self.db.profile.dragonsbreathtgl) then
						if (self.db.profile.firecrit) then
							if (critical) then
								if (math.random(100) <= (self.db.profile.firechance*100)) then
									DispPootMsg( self.db.profile.fire, "SAY" )
								end
							end
						elseif (math.random(100) <= (self.db.profile.firechance*100)) then
							DispPootMsg( self.db.profile.fire, "SAY" )
						end
					end
				elseif spellName == "Frostbolt" or spellName == "Cone of Cold" then
					if (self.db.profile.frosttgl) then
						if (self.db.profile.frostcrit) then
							if (critical) then
								if (math.random(100) <= (self.db.profile.frostchance*100)) then
									DispPootMsg( self.db.profile.frost, "SAY" )
								end
							end
						elseif (math.random(100) <= (self.db.profile.frostchance*100)) then
							DispPootMsg( self.db.profile.frost, "SAY" )
						end
					end	-- SHAMAN SPELLS
				elseif spellName == "Lightning Bolt" then
					if (self.db.profile.lightningbolttgl) then
						if (self.db.profile.lightningboltcrit) then
							if (critical) then
								if (math.random(100) <= (self.db.profile.lightningboltchance*100)) then
									DispPootMsg( self.db.profile.lightningbolt, "SAY" )
								end
							end
						elseif (math.random(100) <= (self.db.profile.lightningboltchance*100)) then
							DispPootMsg( self.db.profile.lightningbolt, "SAY" )
						end
					end
				elseif spellName == "Earth Shock" then
					if (self.db.profile.earthshocktgl) then
						if (self.db.profile.earthshockcrit) then
							if (critical) then
								if (math.random(100) <= (self.db.profile.earthshockchance*100)) then
									DispPootMsg( self.db.profile.earthshock, "SAY" )
								end
							end
						elseif (math.random(100) <= (self.db.profile.earthshockchance*100)) then
							DispPootMsg( self.db.profile.earthshock, "SAY" )
						end
					end
				elseif spellName == "Flame Shock" then
					if (self.db.profile.flameshocktgl) then
						if (self.db.profile.flameshockcrit) then
							if (critical) then
								if (math.random(100) <= (self.db.profile.flameshockchance*100)) then
									DispPootMsg( self.db.profile.flameshock, "SAY" )
								end
							end
						elseif (math.random(100) <= (self.db.profile.flameshockchance*100)) then
							DispPootMsg( self.db.profile.flameshock, "SAY" )
						end
					end
				elseif spellName == "Frost Shock" then
					if (self.db.profile.frostshocktgl) then
						if (self.db.profile.frostshockcrit) then
							if (critical) then
								if (math.random(100) <= (self.db.profile.frostshockchance*100)) then
									DispPootMsg( self.db.profile.frostshock, "SAY" )
								end
							end
						elseif (math.random(100) <= (self.db.profile.frostshockchance*100)) then
							DispPootMsg( self.db.profile.frostshock, "SAY" )
						end
					end
				elseif spellName == "Chain Lightning" then
					if (self.db.profile.chainlightningtgl) then
						if (self.db.profile.chainlightningcrit) then
							if (critical) then
								if (math.random(100) <= (self.db.profile.chainlightningchance*100)) then
									DispPootMsg( self.db.profile.chainlightning, "SAY" )
								end
							end
						elseif (math.random(100) <= (self.db.profile.chainlightningchance*100)) then
							DispPootMsg( self.db.profile.chainlightning, "SAY" )
						end
					end	-- WARLOCK SPELLS
				elseif spellName == "Shadow Bolt" then
					if (self.db.profile.shadowbolttgl) then
						if (self.db.profile.shadowboltcrit) then
							if (critical) then
								if (math.random(100) <= (self.db.profile.shadowboltchance*100)) then
									DispPootMsg( self.db.profile.shadowbolt, "SAY" )
								end
							end
						elseif (math.random(100) <= (self.db.profile.shadowboltchance*100)) then
							DispPootMsg( self.db.profile.shadowbolt, "SAY" )
						end
					end
				elseif spellName == "Death Coil" then
					if (self.db.profile.deathcoiltgl) then
						if (self.db.profile.deathcoilcrit) then
							if (critical) then
								if (math.random(100) <= (self.db.profile.deathcoilchance*100)) then
									DispPootMsg( self.db.profile.deathcoil, "SAY" )
								end
							end
						elseif (math.random(100) <= (self.db.profile.deathcoilchance*100)) then
							DispPootMsg( self.db.profile.deathcoil, "SAY" )
						end
					end
				elseif spellName == "Shadowburn" then
					if (self.db.profile.shadowburntgl) then
						if (self.db.profile.shadowburncrit) then
							if (critical) then
								if (math.random(100) <= (self.db.profile.shadowburnchance*100)) then
									DispPootMsg( self.db.profile.shadowburn, "SAY" )
								end
							end
						elseif (math.random(100) <= (self.db.profile.shadowburnchance*100)) then
							DispPootMsg( self.db.profile.shadowburn, "SAY" )
						end
					end
				elseif spellName == "Immolate" then
					if (self.db.profile.immolatetgl) then
						if (self.db.profile.immolatecrit) then
							if (critical) then
								if (math.random(100) <= (self.db.profile.immolatechance*100)) then
									DispPootMsg( self.db.profile.immolate, "SAY" )
								end
							end
						elseif (math.random(100) <= (self.db.profile.immolatechance*100)) then
							DispPootMsg( self.db.profile.immolate, "SAY" )
						end
					end
				elseif spellName == "Incinerate" then
					if (self.db.profile.incineratetgl) then
						if (self.db.profile.incineratecrit) then
							if (critical) then
								if (math.random(100) <= (self.db.profile.incineratechance*100)) then
									DispPootMsg( self.db.profile.incinerate, "SAY" )
								end
							end
						elseif (math.random(100) <= (self.db.profile.incineratechance*100)) then
							DispPootMsg( self.db.profile.incinerate, "SAY" )
						end
					end	-- Rogue Spells
				elseif spellName == "Sinister Strike" then
					if (self.db.profile.sinisterstriketgl) then
						if (self.db.profile.sinisterstrikecrit) then
							if (critical) then
								if (math.random(100) <= (self.db.profile.sinisterstrikechance*100)) then
									DispPootMsg( self.db.profile.sinisterstrike, "SAY" )
								end
							end
						elseif (math.random(100) <= (self.db.profile.sinisterstrikechance*100)) then
							DispPootMsg( self.db.profile.sinisterstrike, "SAY" )
						end
					end
				elseif spellName == "Hemorrhage" then
					if (self.db.profile.hemorrhagetgl) then
						if (self.db.profile.hemorrhagecrit) then
							if (critical) then
								if (math.random(100) <= (self.db.profile.hemorrhagechance*100)) then
									DispPootMsg( self.db.profile.hemorrhage, "SAY" )
								end
							end
						elseif (math.random(100) <= (self.db.profile.hemorrhagechance*100)) then
							DispPootMsg( self.db.profile.hemorrhage, "SAY" )
						end
					end
				elseif spellName == "Eviscerate" then
					if (self.db.profile.evisceratetgl) then
						if (self.db.profile.evisceratecrit) then
							if (critical) then
								if (math.random(100) <= (self.db.profile.evisceratechance*100)) then
									DispPootMsg( self.db.profile.eviscerate, "SAY" )
								end
							end
						elseif (math.random(100) <= (self.db.profile.evisceratechance*100)) then
							DispPootMsg( self.db.profile.eviscerate, "SAY" )
						end
					end
				elseif spellName == "Deadly Throw" then
					if (self.db.profile.deadlythrowtgl) then
						if (self.db.profile.deadlythrowcrit) then
							if (critical) then
								if (math.random(100) <= (self.db.profile.deadlythrowchance*100)) then
									DispPootMsg( self.db.profile.deadlythrow, "SAY" )
								end
							end
						elseif (math.random(100) <= (self.db.profile.deadlythrowchance*100)) then
							DispPootMsg( self.db.profile.deadlythrow, "SAY" )
						end
					end
				elseif spellName == "Backstab" then
					if (self.db.profile.backstabtgl) then
						if (self.db.profile.backstabcrit) then
							if (critical) then
								if (math.random(100) <= (self.db.profile.backstabchance*100)) then
									DispPootMsg( self.db.profile.backstab, "SAY" )
								end
							end
						elseif (math.random(100) <= (self.db.profile.backstabchance*100)) then
							DispPootMsg( self.db.profile.backstab, "SAY" )
						end
					end
				elseif spellName == "Ambush" then
					if (self.db.profile.ambushtgl) then
						if (self.db.profile.ambushcrit) then
							if (critical) then
								if (math.random(100) <= (self.db.profile.ambushchance*100)) then
									DispPootMsg( self.db.profile.ambush, "SAY" )
								end
							end
						elseif (math.random(100) <= (self.db.profile.ambushchance*100)) then
							DispPootMsg( self.db.profile.ambush, "SAY" )
						end
					end
				elseif spellName == "Mutilate" then
					if (self.db.profile.mutilatetgl) then
						if (self.db.profile.mutilatecrit) then
							if (critical) then
								if (math.random(100) <= (self.db.profile.mutilatechance*100)) then
									DispPootMsg( self.db.profile.mutilate, "SAY" )
								end
							end
						elseif (math.random(100) <= (self.db.profile.mutilatechance*100)) then
							DispPootMsg( self.db.profile.mutilate, "SAY" )
						end
					end
				elseif spellName == "Envenom" then
					if (self.db.profile.envenomtgl) then
						if (self.db.profile.envenomcrit) then
							if (critical) then
								if (math.random(100) <= (self.db.profile.envenomchance*100)) then
									DispPootMsg( self.db.profile.envenom, "SAY" )
								end
							end
						elseif (math.random(100) <= (self.db.profile.envenomchance*100)) then
							DispPootMsg( self.db.profile.envenom, "SAY" )
						end
					end
				end
			end
		elseif etype == "SUCCESS" then
			if event == "SPELL_CAST_SUCCESS" then
				spellId, spellName, spellSchool = select(1, ...)
				if spellName == "Charge" or spellName == "Intercept" or spellName == "Intervene" then
					if (self.db.profile.chargetgl) then
						if (math.random(100) <= (self.db.profile.chargechance*100)) then
							DispPootMsg( self.db.profile.charge, "SAY" )
						end
					end
				elseif spellName == "Rampage" then
					if (self.db.profile.rampagetgl) then
						if (math.random(100) <= (self.db.profile.rampagechance*100)) then
							DispPootMsg( self.db.profile.rampage, "SAY" )
						end
					end
				elseif spellName == "Taunt" then
					if (self.db.profile.taunttgl) then
						if (math.random(100) <= (self.db.profile.tauntchance*100)) then
							DispPootMsg( self.db.profile.taunt, "SAY" )
						end
					end	-- SHAMAN SPELLS
				elseif spellName == "Purge" then
					if (self.db.profile.purgetgl) then
						if (math.random(100) <= (self.db.profile.purgechance*100)) then
							DispPootMsg( self.db.profile.purge, "SAY" )
						end
					end
				elseif spellName == "Bloodlust" or spellName == "Heroism" then
					if (self.db.profile.bloodlusttgl) then
						if (math.random(100) <= (self.db.profile.bloodlustchance*100)) then
							DispPootMsg( self.db.profile.bloodlust, "SAY" )
						end
					end
				elseif spellName == "Stormstrike" and spellId == 32175 then
					if (self.db.profile.stormstriketgl) then
						if (math.random(100) <= (self.db.profile.stormstrikechance*100)) then
							DispPootMsg( self.db.profile.stormstrike, "SAY" )
						end
					end	-- WARLOCK SPELLS
				elseif spellName == "Life Tap" then
					if (self.db.profile.lifetaptgl) then
						if (math.random(100) <= (self.db.profile.lifetapchance*100)) then
							DispPootMsg( self.db.profile.lifetap, "SAY" )
						end
					end
				elseif spellName == "Curse of Shadow" then
					if (self.db.profile.curseofshadowtgl) then
						if (math.random(100) <= (self.db.profile.curseofshadowchance*100)) then
							DispPootMsg( self.db.profile.curseofshadow, "SAY" )
						end
					end
				elseif spellName == "Corruption" then
					if (self.db.profile.corruptiontgl) then
						if (math.random(100) <= (self.db.profile.corruptionchance*100)) then
							DispPootMsg( self.db.profile.corruption, "SAY" )
						end
					end
				elseif spellName == "Curse of Agony" then
					if (self.db.profile.curseofagonytgl) then
						if (math.random(100) <= (self.db.profile.curseofagonychance*100)) then
							DispPootMsg( self.db.profile.curseofagony, "SAY" )
						end
					end
				elseif spellName == "Hellfire" then
					if (self.db.profile.hellfiretgl) then
						if (math.random(100) <= (self.db.profile.hellfirechance*100)) then
							DispPootMsg( self.db.profile.hellfire, "SAY" )
						end
					end
				elseif spellName == "Curse of Weakness" then
					if (self.db.profile.curseofweaknesstgl) then
						if (math.random(100) <= (self.db.profile.curseofweaknesschance*100)) then
							DispPootMsg( self.db.profile.curseofweakness, "SAY" )
						end
					end
				elseif spellName == "Curse of Recklessness" then
					if (self.db.profile.curseofrecklessnesstgl) then
						if (math.random(100) <= (self.db.profile.curseofrecklessnesschance*100)) then
							DispPootMsg( self.db.profile.curseofrecklessness, "SAY" )
						end
					end
				elseif spellName == "Curse of Tongues" then
					if (self.db.profile.curseoftonguestgl) then
						if (math.random(100) <= (self.db.profile.curseoftongueschance*100)) then
							DispPootMsg( self.db.profile.curseoftongues, "SAY" )
						end
					end
				elseif spellName == "Curse of Doom" then
					if (self.db.profile.curseofdoomtgl) then
						if (math.random(100) <= (self.db.profile.curseofdoomchance*100)) then
							DispPootMsg( self.db.profile.curseofdoom, "SAY" )
						end
					end	-- MAGE SPELLS
				elseif spellName == "Blink" then
					if (self.db.profile.blinktgl) then
						if (math.random(100) <= (self.db.profile.blinkchance*100)) then
							DispPootMsg( self.db.profile.blink, "SAY" )
						end
					end	-- ROGUE SPELLS
				elseif spellName == "Rupture" then
					if (self.db.profile.rupturetgl) then
						if (math.random(100) <= (self.db.profile.rupturechance*100)) then
							DispPootMsg( self.db.profile.rupture, "SAY" )
						end
					end
				elseif spellName == "Slice and Dice" then
					if (self.db.profile.sliceanddicetgl) then
						if (math.random(100) <= (self.db.profile.sliceanddicechance*100)) then
							DispPootMsg( self.db.profile.sliceanddice, "SAY" )
						end
					end
				elseif spellName == "Kidney Shot" then
					if (self.db.profile.kidneyshottgl) then
						if (math.random(100) <= (self.db.profile.kidneyshotchance*100)) then
							DispPootMsg( self.db.profile.kidneyshot, "SAY" )
						end
					end
				elseif spellName == "Gouge" then
					if (self.db.profile.gougetgl) then
						if (math.random(100) <= (self.db.profile.gougechance*100)) then
							DispPootMsg( self.db.profile.gouge, "SAY" )
						end
					end
				elseif spellName == "Shiv" then
					if (self.db.profile.shivtgl) then
						if (math.random(100) <= (self.db.profile.shivchance*100)) then
							DispPootMsg( self.db.profile.shiv, "SAY" )
						end
					end
				elseif spellName == "Blind" then
					if (self.db.profile.blindtgl) then
						if (math.random(100) <= (self.db.profile.blindchance*100)) then
							DispPootMsg( self.db.profile.blind, "SAY" )
						end
					end
				elseif spellName == "Feint" then
					if (self.db.profile.feinttgl) then
						if (math.random(100) <= (self.db.profile.feintchance*100)) then
							DispPootMsg( self.db.profile.feint, "SAY" )
						end
					end
				elseif spellName == "Shadowstep" then
					if (self.db.profile.shadowsteptgl) then
						if (math.random(100) <= (self.db.profile.shadowstepchance*100)) then
							DispPootMsg( self.db.profile.shadowstep, "SAY" )
						end
					end
				elseif spellName == "Garrote" then
					if (self.db.profile.garrotetgl) then
						if (math.random(100) <= (self.db.profile.garrotechance*100)) then
							DispPootMsg( self.db.profile.garrote, "SAY" )
						end
					end
				elseif spellName == "Cheap Shot" then
					if (self.db.profile.cheapshottgl) then
						if (math.random(100) <= (self.db.profile.cheapshotchance*100)) then
							DispPootMsg( self.db.profile.cheapshot, "SAY" )
						end
					end
				elseif spellName == "Blade Flurry" then
					if (self.db.profile.bladeflurrytgl) then
						if (math.random(100) <= (self.db.profile.bladeflurrychance*100)) then
							DispPootMsg( self.db.profile.bladeflurry, "SAY" )
						end
					end
				elseif spellName == "Cloak of Shadows" then
					if (self.db.profile.cloakofshadowstgl) then
						if not (self.db.profile.cloakofshadowspvp) then
							if (inpvpzone) then
								return
							end
						end
						if (math.random(100) <= (self.db.profile.cloakofshadowschance*100)) then
							DispPootMsg( self.db.profile.cloakofshadows, "SAY" )
						end
					end
				elseif spellName == "Vanish" then
					if (self.db.profile.vanishtgl) then
						if not (self.db.profile.vanishpvp) then
							if (inpvpzone) then
								return
							end
						end
						if (math.random(100) <= (self.db.profile.vanishchance*100)) then
							DispPootMsg( self.db.profile.vanish, "SAY" )
						end
					end	-- GENERAL SPELLS
				elseif spellName == "Cannibalize" then
					if (self.db.profile.cannibalizetgl) then
						if (math.random(100) <= (self.db.profile.cannibalizechance*100)) then
							DispPootMsg( self.db.profile.cannibalize, "SAY" )
						end
					end
				end
			end
		elseif etype == "INTERRUPT" then
			if event == "SPELL_INTERRUPT" then
				if (self.db.profile.interrupttgl) then
					spellId, spellName, spellSchool, extraSpellID, extraSpellName, extraSpellSchool = select(1, ...)
					if string.find(extraSpellName, "[hH]eal") or string.find(extraSpellName, "[rR]egrowth") or extraSpellName == "Flash of Light" or extraSpellName == "Holy Light" or extraSpellName == "Eternal Affection" then
						if (math.random(100) <= (self.db.profile.interruptchance*100)) then
							DispPootMsg( self.db.profile.interrupt, "SAY" )
						end
					end
				end
			end
		elseif etype == "MISS" then
			if event == "SPELL_MISSED" then
				spellId, spellName, spellSchool, missType = select(1, ...)
				texture = select(3, GetSpellInfo(spellId))
				if spellName == "Taunt" then
					if (self.db.profile.tauntresisttgl) and not (missType == "IMMUNE") and not (missType == "EVADE") then
						DispPootMsg( self.db.profile.tauntresist, "SAY" )
					end
				end
			end
		elseif etype == "SPELLSTART" then
			if event == "SPELL_CAST_START" then
				spellId, spellName, spellSchool = select(1, ...)
				texture = select(3, GetSpellInfo(spellId))
				if spellName == "Fireball" then
					if (self.db.profile.fireballcasttgl) then
						if (math.random(100) <= (self.db.profile.firecastchance*100)) then
							DispPootMsg( self.db.profile.fire, "SAY" )
						end
					end
				elseif spellName == "Pyroblast" then
					if (self.db.profile.pyroblastcasttgl) then
						if (math.random(100) <= (self.db.profile.firecastchance*100)) then
							DispPootMsg( self.db.profile.fire, "SAY" )
						end
					end
				elseif spellName == "Frostbolt" then
					if (self.db.profile.frostboltcasttgl) then
						if (math.random(100) <= (self.db.profile.frostcastchance*100)) then
							DispPootMsg( self.db.profile.frost, "SAY" )
						end
					end
				elseif string.find(spellName, "[pP]olymorph") then
					if (self.db.profile.polymorphtgl) then
						if (math.random(100) <= (self.db.profile.polymorphchance*100)) then
							DispPootMsg( self.db.profile.polymorph, "SAY" )
						end
					end	-- WARLOCK SPELLS
				elseif spellName == "Banish" then
					if (self.db.profile.banishtgl) then
						if (math.random(100) <= (self.db.profile.banishchance*100)) then
							DispPootMsg( self.db.profile.banish, "SAY" )
						end
					end
				elseif spellName == "Fear" then
					if (self.db.profile.feartgl) then
						if (math.random(100) <= (self.db.profile.fearchance*100)) then
							DispPootMsg( self.db.profile.fear, "SAY" )
						end
					end
				elseif spellName == "Howl of Terror" then
					if (self.db.profile.howlofterrortgl) then
						if (math.random(100) <= (self.db.profile.howlofterrorchance*100)) then
							DispPootMsg( self.db.profile.howlofterror, "SAY" )
						end
					end
				elseif spellName == "Seed of Corruption" then
					if (self.db.profile.seedofcorruptiontgl) then
						if (math.random(100) <= (self.db.profile.seedofcorruptionchance*100)) then
							DispPootMsg( self.db.profile.seedofcorruption, "SAY" )
						end
					end
				elseif spellName == "Shadow Bolt" then
					if (self.db.profile.shadowboltcasttgl) then
						if (math.random(100) <= (self.db.profile.shadowboltcastchance*100)) then
							DispPootMsg( self.db.profile.shadowboltcast, "SAY" )
						end
					end
				elseif spellName == "Immolate" then
					if (self.db.profile.immolatecasttgl) then
						if (math.random(100) <= (self.db.profile.immolatecastchance*100)) then
							DispPootMsg( self.db.profile.immolatecast, "SAY" )
						end
					end
				elseif spellName == "Incinerate" then
					if (self.db.profile.incineratecasttgl) then
						if (math.random(100) <= (self.db.profile.incineratecastchance*100)) then
							DispPootMsg( self.db.profile.incineratecast, "SAY" )
						end
					end
				end
			end
		end
		if etype == "POWER" then
			--if event == "SPELL_ENERGIZE" then
			--	spellId, spellName, spellSchool, amount, powerType = select(1, ...)
			--	texture = select(3, GetSpellInfo(spellId))
			--end
		end
	end
	if etype == "BUFF" then
--		if event == "SPELL_AURA_APPLIED" then
--			spellId, spellName, spellSchool, auraType, amount = select(1, ...)
--			texture = select(3, GetSpellInfo(spellId))
--			if spellName == "Mace Stun Effect" then
--				if CombatLog_Object_IsA(destFlags, COMBATLOG_FILTER_POOT) then
--					if (self.db.profile.macestuntgl) then
--						if (math.random(100) <= (self.db.profile.macestunchance*100)) then
--							DispPootMsg( self.db.profile.macestun, "SAY" )
--						end
--					end
--				end
--			elseif spellName == "Taunt" then
--				if CombatLog_Object_IsA(destFlags, COMBATLOG_FILTER_POOT) then
--					if (self.db.profile.taunttgl) then
--						if (math.random(100) <= (self.db.profile.tauntchance*100)) then
--							DispPootMsg( self.db.profile.taunt, "SAY" )
--						end
--					end
--				end
--			end
--		end
	end
end

--minimap functions
function pootpoot:SetShowMinimap(info, newValue)
	self.db.profile.showMinimap = newValue
	self:UpdateMinimapButton()
end

function pootpoot:ShowingMinimap()
	return self.db.profile.showMinimap
end

function pootpoot:UpdateMinimapButton()
	if self:ShowingMinimap() then
		self.Minimap:UpdatePosition()
		self.Minimap:Show()
	else
		self.Minimap:Hide()
	end
end

function pootpoot:SetMinimapButtonPosition(angle)
	self.db.profile.minimapPos = angle
end

function pootpoot:GetMinimapButtonPosition(angle)
	return self.db.profile.minimapPos
end

function pootpoot:ShowOptions()
	if LoadAddOn('pootpoot_Options') then
		InterfaceOptionsFrame_OpenToFrame('pootpoot')
		return true
	end
	return false
end
--DEFAULT_CHAT_FRAME:AddMessage("Message")