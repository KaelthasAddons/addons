local format, mod = string.format, mod
local date, time = date, time
local fmtSeconds = "%H:%M:%S" 
local fmtMinute  = "%H:%M"
local fullDate = "%A, %B %d, %Y"
local serverFormatSeconds, serverFormat = "%.2d:%.2d:%.2d", "%.2d:%.2d"
local FORCE_UPDATE = 100
local whiteFmt = "|cffffffff%s|r"

BrokerClockDB = {
	seconds = false,
}
local db = BrokerClockDB
local delay = 60
local counter = 0
local localTime, gameTime

local Clock = CreateFrame("Frame")
Clock.obj = LibStub("LibDataBroker-1.1"):NewDataObject("Broker_Clock", {
	type = "data source",
	icon = "Interface\\Icons\\INV_Misc_PocketWatch_02",
	label = "Time",
	text  = "00:00",
	
	OnClick = function(self, btn)
		db.seconds = not db.seconds
		delay = db.seconds and 1 or 60
		Clock:OnUpdate(FORCE_UPDATE)
	end,
	
	OnTooltipShow = function(tooltip)
		if not tooltip or not tooltip.AddLine then return end
		tooltip:AddLine( "Broker_Clock" )
		tooltip:AddDoubleLine( "Local Time", format(whiteFmt, localTime) )
		tooltip:AddDoubleLine( "Game Time", format(whiteFmt, gameTime) )
		tooltip:AddLine( date(fullDate) )
	end,
})

function Clock:OnUpdate(elapsed)
	counter = counter + elapsed
	if counter >= delay then
		localTime = date(db.seconds and fmtSeconds or fmtMinute)
		gameTime = self:GetServerTime()
		self.obj.text = localTime
		counter = 0
	end
end

local lastMinute, secondsDifference
function Clock:GetServerTime()
	local _
	local hour, minute = GetGameTime()

	if lastMinute ~= minute then
		lastMinute = minute
		secondsDifference = mod(time(), 60)
	end

	local second = mod(time() - secondsDifference, 60)
	return db.seconds and format(serverFormatSeconds, hour, minute, second) or format(serverFormat, hour, minute)
end

function Clock:ADDON_LOADED(event, addon)
	if addon == "Broker_Clock" then
		db = BrokerClockDB
		delay = db.seconds and 1 or 60
		self:OnUpdate(FORCE_UPDATE)
		
		self:UnregisterEvent("ADDON_LOADED")
		self:SetScript("OnEvent", nil)
		self.ADDON_LOADED = nil
	end
end

Clock:SetScript("OnUpdate", Clock.OnUpdate)
Clock:SetScript("OnEvent", Clock.ADDON_LOADED)
Clock:RegisterEvent("ADDON_LOADED")
