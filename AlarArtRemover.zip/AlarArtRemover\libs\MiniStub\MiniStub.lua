--[[
Stub to enable and load AlarShared on the fly 
--]]
function AlarCreateAddon(addon,force,...)
    if (force == nil) then force = true end
    if (not LibStub("AceAddon-3.0",true)) then
        EnableAddOn("Ace3")
        if (IsAddOnLoadOnDemand("Ace3")) then
            LoadAddOn("Ace3")
        else
        error("Ace 3 required. Trying to enable it for next reload")
    end
    end
    if (force) then
        EnableAddOn("AlarShared")
    end
    local AlarLib=LibStub("AlarAddon-3.0",true)
    if (not AlarLib) then
        local loaded,reason=LoadAddOn("AlarShared")
        if (not loaded) then
            error("AlarShared not loaded.\n Reason:" .. tostring(reason))
            return nil
        else
            AlarLib=LibStub("AlarAddon-3.0",true)
        end
    end
    if (not AlarLib) then
        error("AlarShared not found. Cant load " .. addon)
        return nil
    end
    local rc,lib=pcall(AlarLib.new,lib,addon,...)
    if (not rc) then
        lib=tostring(lib)
        if (select('#',...)>0) then
            error(lib .. " - Unable to load one or more dependencies for " .. addon .. '(' ..strjoin(",",...) .. ')')
        else
            error(lib .. ' - Unable to load ' .. addon)
        end
        return nil
    else
        return lib
    end
end
function AlarLoadLocale(lang,strings)
    local AceLocale=LibStub("AceLocale-3.0",true)
    if (not AceLocale) then
        -- implement some backup localizer or die?
        -- silently fail, will use key.See AlarGetLocale
    end
    local L=AceLocale:NewLocale("AlarMods",lang,lang=="enUS")
    if (not L) then return end
    for k,v in pairs(strings) do
        L[k]=v
    end
end
do
local L
function AlarGetLocale()
    local AceLocale=LibStub("AceLocale-3.0",true)
    if (type(L)=='table') then return L end
    if (AceLocale) then
        L=AceLocale:GetLocale("AlarMods",true) or {}
    end
    setmetatable(L,{
        __index=
        function(self,key)
            rawset(self,key,key)
            return key
        end
        }
    )
    return L
end
end        
AMO=AMO or {}
AMO.Locale=
    function(self,lang,strings) 
        return AlarLoadLocale(lang,strings)
    end