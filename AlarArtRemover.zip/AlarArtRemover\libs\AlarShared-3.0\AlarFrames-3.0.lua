--[[
Name: AlarFrames-3.0
Revision: $Rev: 325 $
Author: Alar of Daggerspine
Email: alar@aspide.it
Website: http://wow.aspide.it
Documentation: http://wiki.wowace.com/wiki/AlarFrames-3.0
SVN: $HeadUrl:$
Description: Generic library
Dependencies: Ace3
License: LGPL v2.1
Copmpatibility layer to ease transition from AlarLib-2.0 frame management to ace3 frame management
TO be gone as soon as I have time to 
--]]
local MAJOR_VERSION="AlarFrames-3.0"
local MINOR_VERSION = tonumber(string.sub("$Revision: 325 $", 12, -3))
local _G=_G
local pp=AlarLittlePrintUtility or function() return end
pp("Loading " .. MAJOR_VERSION .. " " .. MINOR_VERSION)
if (not LibStub) then
    pp("Couldn't find LibStub.Please reinstall " .. MAJOR_VERSION )
end
local lib,old=LibStub:NewLibrary(MAJOR_VERSION,MINOR_VERSION)
if (not lib) then
    pp("Already loaded a new version of " .. MAJOR_VERSION)
    return -- Already loaded
end
local new, del
do
	local list = setmetatable({}, {__mode="k"})
	function new()
		local t = next(list)
		if t then
			list[t] = nil
			return t
		else
			return {}
		end
	end
	function del(t)
		setmetatable(t, nil)
		for k in pairs(t) do
			t[k] = nil
		end
		list[t] = true
	end
end

local AMO=setmetatable({},
    {   
    __call=
        function(table,arg1) 
            pp('Called AMO:',arg1) 
        end,
    __index=
        function(table,key)
            return function(...) pp("AMO",key,...) end
        end
    }
)
local C=LibStub("AlarCore-3.0").mix.C -- color system
lib.CastPanels=lib.CastPanels or {}
local buttonmetatable={
    x=0,
    y=0,
    position=-90,
    clamped=true,
    custom=false,
}
local framemetatable={
}

function lib:RegisterDb(data)
    lib.data=data or {}
    lib.data.frames=lib.data.frames or {}
    setmetatable(lib.data.frames,{__index=function(table,key) rawset(table,key,framemetatable) end})
    lib.db=lib.data -- alias
end
lib.texture=lib.texture or UIParent:CreateTexture()
lib.fontstring=lib.fontstring or UIParent:CreateFontString()
-- Backdrops definition
lib.Backdrops=setmetatable({
dialog = {
    bgFile="Interface\\DialogFrame\\UI-DialogBox-Background",
    edgeFile="Interface\\DialogFrame\\UI-DialogBox-Border",
    tile=true,
    tileSize=32,
    edgeSize=32,
    insets={bottom=5,left=5,right=5,top=5}
},
bubble={
	bgFile = "Interface\\Tooltips\\ChatBubble-Background",
	edgeFile = "Interface\\Tooltips\\ChatBubble-BackDrop",
	tile = true, tileSize = 32, edgeSize = 32,
	insets = { left = 32, right = 32, top = 32, bottom = 32 }
},
party = {
    bgFile="Interface\\CharacterFrame\\UI-Party-Background",
    edgeFile="Interface\\CharacterFrame\\UI-Party-Border",
    tile=true,
    tileSize=32,
    edgeSize=32,
    insets={bottom=32,left=32,right=32,top=32}
},
tooltip = {
    bgFile="Interface\\Tooltips\\UI-Tooltip-Background",
    edgeFile="Interface\\Tooltips\\UI-Tooltip-Border",
    tile=true,
    tileSize=16,
    edgeSize=16,
    insets={bottom=5,left=5,right=5,top=5}
},
border = {
    bgFile="",
    edgeFile="Interface\\Tooltips\\UI-Tooltip-Border",
    tile=true,
    tileSize=16,
    edgeSize=16,
    insets={bottom=5,left=5,right=5,top=5}
},
tutorial = {
    bgFile="Interface\\TutorialFrame\\TutorialFrameBackground",
    edgeFile="Interface\\Tooltips\\UI-Tooltip-Border",
    tile=true,
    tileSize=16,
    edgeSize=16,
    insets={bottom=7,left=7,right=7,top=7}
},
background = {
    bgFile="Interface\\Tooltips\\UI-Tooltip-Background",
    edgeFile="",
    tile=false,
    tileSize=8,
    edgeSize=8,
    insets={bottom=3,left=3,right=3,top=3}
},
minimal = {
    bgFile="Interface\\TutorialFrame\\TutorialFrameBackground",
    edgeFile="Interface\\Tooltips\\UI-Tooltip-Border",
    tile=false,
    tileSize=8,
    edgeSize=8,
    insets={bottom=3,left=3,right=3,top=3}

}
},
{__index=function(table) return rawget(table,'tutorial') end}) -- default backdrop
local Backdrops=lib.Backdrops
local SetBackdrop
--[[
Calculates the offset in a squared multitexture 

--]]
function lib:GetTexCoord(typ,splitter)
    typ=typ or 1
    splitter=splitter or 8
    local row,col=self:Split(typ,splitter) -- 8 icons each row
    return 1/splitter*col,1/splitter*(col+1),1/splitter*row,1/splitter*(row+1)
end
function lib:SetTexCoord(f,typ,splitter)
    f:SetTexCoord(unpack({self:GetTexCoord(typ,splitter)}))
end
lib.SetPoiiOffset=lib.SetTexCoord
lib.ScrollPanelMethods={
SetText=function(frame,stringa) 
        frame.testo:SetText(tostring(stringa))
        frame.child:SetHeight(frame.testo:GetHeight())
        frame:SetVerticalScroll(0)
        frame.child:SetWidth(frame:GetWidth())
    end,
SetWidth=function(frame,width,...) 
    frame.org.SetWidth(frame,width)
    frame.child:SetWidth(frame:GetWidth())
end,
SetTextColor=function(frame,...) frame.testo:SetTextColor(...) end,
SetFormattedText=function(frame,...) frame.testo:SetFormattedText(...) end,
SetJustifyH=function(frame,...) frame.testo:SetJustifyH(...) end,
SetJustifyV=function(frame,...) frame.testo:SetJustifyV(...) end,
SetFontObject=function(frame,font,...) frame.testo:SetFontObject(font) end,
}
function lib:CreateScrollPanel(nome,title)
    local frame=CreateFrame("ScrollFrame",nome,UIParent,"UIPanelScrollFrameTemplate")
    local child=CreateFrame("EditBox",nil,frame)
    child:SetAutoFocus(false)
    child:SetMultiLine(true)
    child:EnableKeyboard(false)
    child:EnableMouse(false)
    child:SetFontObject("GameFontNormalSmall")
    child:SetTextInsets(5,5,0,0)
    frame:SetScrollChild(child)
    frame.child=child
    frame.testo=child
    frame.org={}
    for method,func in pairs(self.ScrollPanelMethods) do
        frame.org[method]=frame[method]
        frame[method]=func
    end
    frame:SetScript("OnShow",function(frame) frame.child:SetWidth(frame:GetWidth()) end )
    frame:SetScript("OnSizeChanged",function(frame) frame.child:SetWidth(frame:GetWidth()) end )
    frame:Show()
    return frame

end

function lib:SetBackdrop(f,tipo,alpha)
    if (not f) then
        return
    end
    if (not tipo and f.storage) then
        tipo=f.storage.Backdrop
    end
    if (type(tipo) == "table") then
        pcall(f.SetBackdrop,f,tipo)
    elseif (type("tipo") == "string") then
        pcall(f.SetBackdrop,f,Backdrops[tipo])
    else
        f:SetBackdrop(nil)
    end
    if (f.storage) then
        f.storage.Backdrop=tipo
    end
    if (alpha) then
        local r,g,b,a=f:GetBackdropColor()
        f:SetBackdropColor(r,g,b,alpha)
    end
    return f:GetBackdrop()
end
-------------------------------------------------------------------------------
-- Transitional compatibility with AlarLib-2.0
-------------------------------------------------------------------------------
local OnDragStart,OnDragStartNoAlt,OnDragStop,OnDragInfoOn,OnDragInfoOff,savepanel,restorepanel
local ClipChildren,FitToChildren,ScanChildren,AddScript
function AddScript(frame,hook,script)
    local oldscript=frame:GetScript(hook)
    frame:EnableMouse(true)
    if (oldscript) then
        frame:SetScript(hook,function(...) oldscript(...) script(...) end)
    else
        frame:SetScript(hook,function(...) script(...) end)
    end
end
function ClipChildren(frame)
    AMO:Debug("Clip",frame:GetName())
    ScanChildren(frame,
                    function(frame,v,insideform)
                        if (type(v.compact) == "nil") then
                            if (insideform) then
                                v:Show()
                            else
                                v:Hide()
                            end
                        end
                    end
                )
end
function FitChildren(frame)
    AMO:Debug("Fit",frame:GetName())
    ScanChildren(frame,
                    function(frame,v,insideform)
                        if (not insideform) then
                            frame:SetHeight(v:GetTop()-v:GetBottom() + 10)
                            frame:SetWidth(v:GetRight()-v:GetLeft() + 10)
                        end
                    end
                )
end
function ScanChildren(frame,op)
    frame.lastclip=tonumber(frame.lastclip) or 0
    if (GetTime() - frame.lastclip < 0.5) then
        return
    end
    frame.lastclip=GetTime()
    local t=frame:GetTop()
    local b=frame:GetBottom()
    if (tonumber(t) and tonumber(b)) then
        for i,v in ipairs({frame:GetChildren()}) do
            if (not v.ignore) then
                local vt=v:GetTop()
                local vb=v:GetBottom()
                if (vt and vb) then
                    if (vt <= t and vb >= b) then
                        op(frame,v,true)
                    else
                        op(frame,v,false)
                    end
                end
            end
        end
    end
    for i,v in ipairs({frame:GetRegions()}) do
        if (not v) then
            break
        end
        if (not v.ignore) then
            local vt=v:GetTop()
            local vb=v:GetBottom()
            if (vb and vt) then
                if (vt <= t and vb >= b) then
                    op(frame,v,true)
                else
                    op(frame,v,false)
                end
            end
        end
    end
end


function OnDragStart(this,...)
    if (IsAltKeyDown()) then
        OnDragStartNoAlt(this,...)
    else
        lib:TTOpen("Moving....")
        this:StartMoving()
    end
end
function OnDragStartNoAlt(this,...)
    lib:TTOpen("Sizing....")
    this.Sizing=true
    this:StartSizing("BOTTOMRIGHT")
end
function OnDragInfoOn(old,this,button)
    if (IsAltKeyDown()) then
        lib:TTOpen("Ready to resize")
    else
        lib:TTOpen(C("Right-click and drag:",'green') .. " move\n" .. C("Alt-Right-Click and drag:",'green') .. "resize")
    end
    if (type(old) == "function") then old(this,button) end
end
function OnDragInfoOff(old,this,button)
    lib:TTFade()
    if (type(old) == "function") then old(this,button) end
end
function OnDragStop(this,...)
    lib:TTFade()
    this:StopMovingOrSizing();
    AMO:Debug("DragStop")
    this.lastclip=0 -- forcing clip
    if (this.Sizing) then
        if (not this.IsCompact) then
            AMO:Debug("OnDragStop")
            this:ClipChildren()
        end
        this.Sizing=false
    end
    local f=this:GetParent()
    if (f) then
        if (f:GetName() ~= "UIParent" and not InCombatLockdown()) then
            this:ClearAllPoints()
            this:SetPoint("TOPLEFT",
                this:GetLeft()-f:GetLeft(),
                this:GetTop()-f:GetTop())
        end
    end
end
local OnDragStopParent
function OnDragStopParent(this,...)
    OnDragStop(this:GetParent(),'parent')
end
local OnDragStartParent
function OnDragStartParent(this)
    OnDragStart(this:GetParent(),'parent')
end
local OnDragStartParentNoAlt
function OnDragStartParentNoAlt(this)
    OnDragStartNoAlt(this:GetParent(),'parent')
end


function lib:CreateMiniPanel(nome,titolo)
    return self:CreatePanel(nome,{
        Cancel=true,
        Save=true,
        backdrop='minimal',
        Rescale=false,Resize=true,Config=false,
        Header=AlarGetLocale()[titolo],
        Width=300,
})
end
function lib:CreateTrackerPanel(nome,titolo)
    return self:CreatePanel(nome,{
        noCancel=1,
        noSave=1,
        backdrop='none',
        noRescale=true,
        noResize=true,
        noConfig=true,
        noMin=true,
        MiniHeader=AlarGetLocale()[titolo],
        Width=250,
})
end
function lib:CreatePanel(nome,p,show)
    p=p or {}
    p.name=nome or "Panel" .. math.ceil(time())
    local f=self:Create("Panel",p.name,UIParent)
    self:SetBackdrop(f,p.backdrop)
    f:SetParent(UIParent)
    --[[
    f:SetHeight(p.Height or 400)
    f:SetWidth(p.Width or 400)
    if (p.minsize) then
        --self:PanelMinSize(f,f:GetWidth(),f:GetHeight())
    end
    f:SetScale(0.8) -- My default scale
    --]]
    f.rightmost=0
    f.leftmost=0
    local bx
    if (p.X or not p.noX) then --default: yes
        local b,x,y=self:FrameAddXButton(f)
        f.rightmost=f.rightmost - 30
        bx=b
    end
    if (p.Min or not p.noMin) then --default: yes
        local b,x,y=self:FrameAddMinButton(f)
        f.rightmost=f.rightmost - b:GetWidth() -2
    end
    if (p.Config and not p.noConfig) then --default: no
        local b,x,y=self:FrameAddConfigButton(f)
        f.rightmost=f.rightmost - b:GetWidth() -2
    end
    if (p.Close and not p.noClose ) then --default: no
        local b,x,y=self:FrameAddCloseButton(f)
        if (type(p.closefunc) == "function") then
            b:SetScript("OnClick",p.closefunc)
        end
        b.compact=true
    end
    if (p.Save or not p.noSave) then --default yes
        local b,x,y=self:FrameAddSaveButton(f)
        if (type(p.savefunc) == "function") then
            b:SetScript("OnClick",p.savefunc)
        end
        b.compact=true
    end
    if (p.Cancel or not p.noCancel) then --default yes
        local b,x,y=self:FrameAddCancelButton(f)
        if (type(p.cancelfunc) == "function") then
            b:SetScript("OnClick",p.cancelfunc)
        end
        b.compact=true
    end
    if (p.Rescale or not p.noRescale) then --default: true
        local b,x,y=self:FrameAddRescaleButton(f)
        b.compact=true
        f.leftmost=f.leftmost+b:GetWidth()+2
    end
    if (p.Help and not p.noHelp) then --default: no
        if (p.Helptext) then
            self:AttachHelp(f,p.Helptext)
        end
    end
    if (p.Movable and not p.noMovable) then --default: no
        self:MakeMovable(p.name,p.noTip)
    end
    if (p.Resize or not p.noResize) then -- default: yes
        self:FrameAddResizer(f)
    end
    if ((p.Header or not p.noHeader) and not p.MiniHeader) then
        self:FrameAddHeader(f,p.Header)
    end
    if (p.MiniHeader and  not p.noMiniHeader) then
        self:FrameAddMiniHeader(f,p.MiniHeader)
        if (bx) then
            bx:SetPoint("TOPRIGHT",5,5)
        end
    end
    if (show) then
        f:Show()
    end
    f:SetScript("OnSizeChanged",ClipChildren)
    return f
end

function lib:CreateTargetPanel(nome,show,unit)
    local f=self:Create("Panel",nome,UIParent)
    self:SetBackdrop(f,"border")
    f:SetParent(UIParent)
    f:SetHeight(37)
    f:SetWidth(94)
    self:FrameAddXButton(f)
    f.button=self:FrameAddUnitButton(f,"target",unit,unit,0,-5)
    f.SetUnit=(function(this,unit)
        this.button:SetUnit(unit)
        end)
end
function lib:CreateButtonPanel(nome,show,message,func)
    local f=self:Create("Frame",nome,UIParent)
    local x=0
    local y=0
    AMOCOMMON.CastPanels=AMOCOMMON.CastPanels or {}
    AMOCOMMON.CastPanels[f]=1
    self:SetBackdrop(f,nil)
    f:SetParent(UIParent)
    f:SetPoint("CENTER",UIParent,"CENTER",x,y)
    f:SetHeight(64)
    f:SetWidth(64)
    local b=self:FrameAddXButton(f)
    if (type(func) ~= "function") then
        func=function(...) self:Print(...) end
    end
    if (type(message) ~= "string") then
        message="Click!"
    end
    b=self:FrameAddButton(f,"",message,-10,-18)
    self:TTAdd(b,message)
    f.Button=b
    f.SetText=function(this,...) f.b:SetText(...) end
    b:SetHeight(32)
    b:SetWidth(64)
    b:SetScript("OnClick",function(...)
            func(...)
            this:GetParent():Hide()
            end
    )
    f.Pop=function(this,delay)
        delay=delay or 30
        local x=0
        for p in pairs(AMOCOMMON.CastPanels) do
            if (p:IsShown() and p ~= this) then
                x=x+64
            end
        end
        this:SetPoint("CENTER",UIParent,"CENTER",x,0)
        this:Show()
        UIFrameFadeOut(this,delay,1.0,0.5)
        AMO:ScheduleEvent(function() this:Hide() this:SetAlpha(1.0) end,delay)
    end
    if (show) then
        f:Pop()
    end
    return f
end
function lib:CreateCastPanel(nome,show,spell)
    local f=self:Create("Frame",nome,UIParent)
    local x=0
    local y=0
    AMOCOMMON.CastPanels=AMOCOMMON.CastPanels or {}
    AMOCOMMON.CastPanels[f]=1
    self:SetBackdrop(f,nil)
    f:SetParent(UIParent)
    f:SetPoint("CENTER",UIParent,"CENTER",x,y)
    f:SetHeight(48)
    f:SetWidth(64)
    local b=self:FrameAddXButton(f)
    b=self:FrameAddCastButton(f,"",5,-5)
    f.SpellButton=b
    b:SetScript("PostClick",function(this)
          this:GetParent():Hide()

    end)
    if (spell) then
        b:SetSpell(spell)
    end
    f.SetSpell=function(this,t) this.SpellButton:SetSpell(t) end
    f.Pop=function(this,delay)
        delay=delay or 30
        local x=0
        for p in pairs(AMOCOMMON.CastPanels) do
            if (p:IsShown() and p ~= this) then
                x=x+64
            end
        end
        this:SetPoint("CENTER",UIParent,"CENTER",x,0)
        this:Show()
        UIFrameFadeOut(this,delay,1.0,0.5)
        AMO:ScheduleEvent(function() this:Hide() this:SetAlpha(1.0) end,delay)
    end
    if (show) then
        f:Pop()
    end
    return f
end
function lib:Create(tipo,nome,frameobject,template)
    local frameobject=frameobject or UIParent
    local isPanel
    if (tipo=="Panel") then
        isPanel=true
        tipo="Frame"
    end
    local f=getglobal(nome)
    if (not f) then
        r,f=pcall(CreateFrame,tipo,nome,frameobject,template)
        if (not r) then
            self:PrintLiteral(tipo,nome,frameobject,template)
            self:Error("Error AMO_Create: " .. f .. "-" ..tostring(nome))
            return nil
        end
    end
    if (isPanel) then
        --f.storage=self.db.profile.forms[nome]
        f.storage={}
    end
    f.Loaded=true
    f.objectname=nome
    f.ClipChildren=ClipChildren
    f.FitChildren=FitChildren
    f.AddScript=AddScript
    return f
end

function lib:FrameAddButton(f,tipo,testo,x,y,moretemplate)
    moretemplate = moretemplate or ''
    tipo=tipo or 'AMO'
    testo=testo or tipo
    tipo=string.capitalize(tipo)
    local fname=f:GetName() .. "Bt" .. tipo
    local b=self:Create("Button",fname,f,"UIPanelButtonTemplate" .. moretemplate)
    local width=0
    b:SetText(testo)
    width=b:GetTextWidth() + 5 -- Allow for button border
    if (width < 32) then
        width=32
    elseif (width >200) then
        width=200
    end
    b:SetHeight(32)
    b:SetFrameLevel(10)
    b:SetWidth(width)
    fs=nil
    local function closefunc()
        local a=this:GetParent()
        if (a) then
            a:Hide()
        end
    end
    if (tipo=="Close") then
        self:TTAdd(b,"Close this panel")
        b:SetPoint("BOTTOM",f,"BOTTOM",0,10)
        b:SetScript("PostClick",closefunc)
    elseif (tipo == "Cancel") then
        self:TTAdd(b,"Exit without saving your changes")
        b:SetPoint("BOTTOMLEFT",f,"BOTTOMLEFT",30,15)
        b:SetScript("PostClick",closefunc)
    elseif (tipo=="Save") then
        self:TTAdd(b,"Save your changes and exit")
        b:SetPoint("BOTTOMRIGHT",f,"BOTTOMRIGHT",-30,15)
        b:SetScript("PostClick",closefunc)
    else
        local x = x or 0
        local y = y or 0
        b:SetPoint("TOPLEFT",x,y)
    end
    b:Show()
    return b,self:GetXY(f,b)
end
local function enhance(this,c,v)
    this:SetBackdropColor(c.r,c.g,c.b,v)
end
function lib:SetClick(f,func,color,alpha)
    self:argCheck(f,1,"table","string")
    self:argCheck(func,2,"function","nil")
    self:argCheck(alpha,4,"number","nil")
    alpha=alpha or 0.5
    f=self:IsFrame(f)
	local highlight = f:CreateTexture(nil, "HIGHLIGHT")
	highlight:SetTexture("Interface\\QuestFrame\\UI-QuestTitleHighlight")
	highlight:SetBlendMode("ADD")
	highlight:SetAllPoints(f)
    f:EnableMouse(true)
    if (func) then
        f:SetScript("OnMouseUp",func)
    end
end
function lib:FrameBOTH(f,x)
    x=x or 5
    if (type(f)=="string") then
        f=getglobal(f)
    end
    if (f) then
        local a1,p,a2,x,y=f:GetPoint()
        f:SetPoint("LEFT",p,"LEFT" ,x,y)
        f:SetPoint("RIGHT",p,"RIGHT" ,-x,y)
    end
end
function lib:FrameRIGHT(f,themost)
    if (type(f)=="string") then
        f=getglobal(f)
    end
    if (f) then
        local a1,p,a2,x,y=f:GetPoint()
        if (themost) then
            x=-10
        else
            x=x-p:GetWidth()
        end
        a1=a1:gsub("LEFT","RIGHT")
        a2=a2:gsub("LEFT","RIGHT")
        f:ClearAllPoints()
        f:SetPoint(a1,p,a2 ,x,y)
    end
end
function lib:FrameBOTTOM(f)
    if (type(f)=="string") then
        f=getglobal(f)
    end
    if (f) then
        local a1,p,a2,x,y=f:GetPoint()
        if (themost) then
            y=y+10
        else
            y=y+p:GetHeight()
        end
        a1=a1:gsub("TOP","BOTTOM")
        a2=a2:gsub("TOP","BOTTOM")
        f:SetPoint(a1,p,a2 ,x,y)
    end
end
function lib:FrameMove(f,x,y,rightalign)
    if (type(f)=="string") then
        f=getglobal(f)
    end
    if (f) then
        local a1,p,a2,ox,oy=f:GetPoint()
        f:SetPoint(a1,p,a2 ,x or ox,y or oy)
    end
end
function lib:FrameAddCloseButton(f)
    return self:FrameAddButton(f,"Close")
end
function lib:FrameAddSaveButton(f)
    return self:FrameAddButton(f,"Save")
end
function lib:FrameAddCancelButton(f)
    return self:FrameAddButton(f,"Cancel")
end
function lib:TTAdd(frame,message,autohide)
    frame=self:IsFrame(frame,true)
    if (frame) then
        if (message) then
            frame:EnableMouse(true)
            frame:SetScript("OnEnter",
                            function()
                                frame:SetAlpha(1)
                                self:TTOpen()
                            end)
            frame:SetScript("OnLeave",
                            function()
                            self:TTClose()
                                if (autohide) then
                                    frame:SetAlpha(0)
                                end
                            end)
            frame.Tooltip=tostring(message)
        else
            frame:SetScript("OnEnter",nil)
            frame:SetScript("OnLeave",nil)
        end
    end
end

function lib:FrameAddLabel(f,nome,testo,x,y)
    local width
    local fname=(f:GetName() or '') .. nome
    local frame=self:Create("Frame",fname,f)
    if (type(testo) == "number") then
        width=testo
        testo=nil
    end
    frame:SetPoint("TOPLEFT",x or 0,y or 0)
    frame:SetHeight(16)
    if (not frame.Label) then
        frame.Label=frame:CreateFontString(fname .. "Label","OVERLAY","GameFontNormal")
    end
    if (testo) then
        frame.Label:SetText(testo)
        if (not width) then
            width=frame.Label:GetStringWidth()
        end
    end
    if (not width) then
        width=f:GetWidth()
    end
    frame:SetWidth(width)
    frame.Label:SetAllPoints(frame)
    frame.SetText=function(this,text) this.Label:SetText(text) end
    frame.SetFormattedText=function(this,fmt,...) this.Label:SetFormattedText(fmt,...) end
    frame.SetTextColor=function(this,r,g,b,a) this.Label:SetTextColor(r,g,b,a) end
    frame.GetText=function(this) return this.Label:GetText() end
    return frame
end

function lib:FrameAddTitle(f,nome,testo,x,y)
    x=0
    y=y or 0
    local frame=self:FrameAddLabel(f,nome,testo,x,y)
    frame:SetPoint("TOPRIGHT",x,y) -- So it's resized automaigcally
    frame.Label:SetJustifyH("CENTER")
    return frame
end

function lib:FrameAddCLabel(f,nome,testo,x,y)
    local frame=self:FrameAddLabel(f,nome,testo,x,y)
    frame.Label:SetJustifyH("CENTER")
    frame.Label:SetNonSpaceWrap(false)
    return frame
end

function lib:FrameAddLLabel(f,nome,testo,x,y)
    local frame=self:FrameAddLabel(f,nome,testo,x,y)
    frame.Label:SetJustifyH("LEFT")
    frame.Label:SetNonSpaceWrap(false)
    return frame
end


function lib:FrameAddRLabel(f,nome,testo,x,y)
    local frame=self:FrameAddLabel(f,nome,testo,x,y)
    frame.Label:SetNonSpaceWrap(false)
    frame.Label:SetJustifyH("RIGHT")
    return frame
end


function lib:FrameAddIcon(f,tipo,texture,x,y)
    local b=f:CreateTexture((f:GetName() or '')  .. tipo .. "Icon")
    x=x or 0
    y=y or 0
    b:SetPoint("TOPLEFT",x,y)
    b:SetWidth(16)
    b:SetHeight(16)
    b:SetTexture(texture)
    --b:SetHeight(32)
    --b:SetWidth(32)
    return b
end
function lib:FrameAddPanel(f,nome,attach,x,y)
    local width=f:GetWidth()
    x = x or 0
    y = y or 0
    attach=attach or 'none'
    attach=strupper(attach)
    local fname=f:GetName() .. nome
    local frame=self:Create("Frame",fname,f)
    self:SetBackdrop(frame,f.storage.Backdrop)
    if (attach=='LEFT') then
        frame:SetPoint("TOPRIGHT",f,"TOPLEFT",0,0)
        frame:SetPoint("BOTTOMRIGHT",f,"BOTTOMLEFT",0,0)
    elseif (attach=='TOP') then
        frame:SetPoint("BOTTOMLEFT",f,"TOPLEFT",0,0)
        frame:SetPoint("BOTTOMRIGHT",f,"TOPRIGHT",0,0)
    elseif (attach=='RIGHT') then
        frame:SetPoint("TOPLEFT",f,"TOPRIGHT",0,0)
        frame:SetPoint("BOTTOMLEFT",f,"BOTTOMRIGHT",0,0)
    elseif (attach=='BOTTOM') then
        frame:SetPoint("TOPLEFT",f,"BOTTOMLEFT",0,0)
        frame:SetPoint("TOPRIGHT",f,"BOTTOMRIGHT",0,0)
    else
        f:SetPoint("TOPLEFT",x,y)
    end
    frame:SetWidth(width)
    frame:SetHeight(100)
    return frame
end
function lib:TRACK(...)
   local event = AceLibrary("AceEvent-2.0").currentEvent
   self:Print(self:GetDebugPrefix(),event,...)
end
function lib:TTClose()
	GameTooltip:FadeOut()
end

function lib:TTFade()
	GameTooltip:FadeOut()
end
function lib:TTFormat(lmessage,rmessage)
    lmessage=lmessage or ''
    rmessage=rmessage or ''
    self:TTOpen(
        C(lmessage ..  rmessage,'green')
    )
end
function lib:TTOpen(message)
    if (this:GetAlpha() < 0.1) then
        return
    end
    local ex=0
    if (type(message)~="string") then
        if (type(this.tooltipFunction) == "function") then
            message=this:tooltipFunction(message)
            ex=1
        elseif (type(this.tooltipText)=="string") then
            message=this.tooltipText
            ex=2
        elseif (type(this.Tooltip)=="string") then
            message=this.Tooltip
            ex=3
        else
            message=nil
            ex=4
        end
    end
    if (not message) then
        return
    end
    if (tostring(message) == "nil") then
        return
    end
	local p=this:GetParent()
	if (p and p:GetFrameStrata() == "TOOLTIP") then
    	GameTooltip:SetOwner(this, "ANCHOR_RIGHT",0,-40)
        GameTooltip:SetFrameLevel(p:GetFrameLevel()-1)
    else
	   GameTooltip:SetOwner(this, "ANCHOR_CURSOR",50,0)
    end
	GameTooltip:SetText(message, C.Yellow.r,C.Yellow.g,C.Yellow.b,0.9, 1)
	if ( this.tooltipRequirement ) then
		GameTooltip:FrameAddLine(this.tooltipRequirement, "", 1.0, 1.0, 1.0);
	end
    GameTooltip:Show()

end
lib.PoiiOffsets={
MiNN=0, -- Neutral mine
MiHH=1,   -- Horde mine
MiAA=2,   -- Ally mine
GyAN=3,   -- Ally contested Graveyard
HoNN=4,   -- Neutral Home
ToNN=5,   -- Neutral Tower
ObNN=6,   -- Objective
GyNN=7,   -- Neutral Graveyard
ToAN=8,   -- Ally contested Tower
ToHH=9,   -- Horde Tower
ToAA=10,  -- Ally Tower
ToHN=11,  -- Horde Contested Tower
GyHH=12,  -- Horde Graveyard
GyHN=13,  -- Horde Contested Graveyard
GyAA=14,  -- Ally Graveyard
GmNN=16,  --Golden Mine
GmAN=17,
GmAA=18,
GmHN=19,
GmHH=20,
LmNN=21,  --Lumber Mill
LmAN=22,
LmAA=23,
LmHN=24,
LmHH=25,
BsNN=26,  --BlackSmith
BsAN=27,
BsAA=28,
BsHN=29,
BsHH=30,
FaAA=31,  --Farm
FaAN=32,
FaAA=33,
FaHN=34,
FaHH=35,
StAA=36,  --Stables
StAN=37,
StAA=38,
StHN=39,
StHH=40,
SkNN=41,  -- Skull
SkXX=42,  --Dunno...
FlAA=43,
FlHH=44,
FlNN=45,
BaAA=46,
BaAN=47,
BaHH=48,
BaHA=49,
INVI=55
}
function lib:Split(id,rowlen)
    local row=math.floor(id/rowlen);
    local col=id-(row*rowlen)
    return row,col
end
function lib:GetTexCoord(typ,splitter)
    self:argCheck(typ,1,"number","nil")
    self:argCheck(splitter,2,"number","nil")
    typ=typ or 1
    splitter=splitter or 8
    local row,col=self:Split(typ,splitter) -- 8 icons each row
    return 1/splitter*col,1/splitter*(col+1),1/splitter*row,1/splitter*(row+1)
end
function lib:SetPoiiOffset(f,typ,splitter)
    self:argCheck(f,1,"table")
    f:SetTexCoord(unpack({self:GetTexCoord(typ,splitter)}))
end
lib.SetTexCoord=lib.SetPoiiOffset

function lib:MakeParentMovable(tf)
    local f=self:IsFrame(tf,true)
    local p=f:GetParent()
    if (not p) then
        return
    end
    self:MakeMovable(p,true)
    f:SetScript("OnDragStart",OnDragStartParent)
    f:SetScript("OnDragStop",OnDragStopParent)
end
function lib:MakeMovable(tf,noinfo)
    local f=self:IsFrame(tf,true)
    if (f) then
        f.oldparent=f:GetParent()
        if (not f.FitChildren) then
            f.FitChildren=function() end
        end
        if (not f.ClipChildren) then
            f.ClipChildren=function() end
        end
        f:SetMovable(true)
        f:EnableMouse(true)
        if (f:GetFrameStrata() == "BACKGROUND") then
            f:SetFrameStrata("LOW")
        end
        f:SetMovable(true)
        f:SetResizable(true)
        f:SetClampedToScreen(true)
        f:RegisterForDrag("RightButton")
        local fname=f:GetName()

        if (not noinfo) then
            local omd=f:GetScript("OnMouseDown")
            local omu=f:GetScript("OnMouseUp")
            f:SetScript("OnMouseDown",function(...) OnDragInfoOn(...) end)
            f:SetScript("OnMouseUp",function(...) OnDragInfoOff(...) end)
        end
        f:SetScript("OnDragStart",OnDragStart)
        f:SetScript("OnDragStop",OnDragStop)
    else
        self:Print("Sorry, ",tf," is not a frame object")
    end
end
function lib:FrameAddXButton(f)
    local fname=f:GetName() .. "XButton"
    local b=self:Create("Button",fname,f,"UIPanelCloseButton")
    b:SetHeight(32)
    b:SetWidth(32)
    b:SetPoint("TOPRIGHT",f,"TOPRIGHT",f.rightmost,0)
    b:SetFrameLevel(10)
    b.ignore=true
    b:Show()
    return b
end
local Minimize
function Minimize(self,this)
    local base=16
    local height=32
    if (this.minimized) then
        base=3
        this.minimized=false
        height=this.oldwidth or 100
    else
        this.minimized=true
        this.oldwidth=this:GetParent():GetHeight()
    end
    self:SetTexCoord(this:GetNormalTexture(),base,8)
    self:SetTexCoord(this:GetPushedTexture(),base+1,8)
    this:GetParent():SetHeight(height)
end
function lib:FrameAddMinButton(f)
    local fname=f:GetName() .. "MinButton"
    local b=self:Create("Button",fname,f,"UIPanelCloseButton")
    b.ignore=true
    local t
    local ButtonsTexture=self:LoadTexture("Buttons")
    --------------- Normal
    t=b:CreateTexture()
    t:SetTexture(ButtonsTexture)
    self:SetTexCoord(t,3,8)
    t:SetAllPoints(b)
    b:SetNormalTexture(t)
    --------------- Pushed
    t=b:CreateTexture()
    t:SetTexture(ButtonsTexture)
    self:SetTexCoord(t,4,8)
    t:SetAllPoints(b)
    b:SetPushedTexture(t)
    --------------- HighLight
    t=b:CreateTexture()
    t:SetTexture(ButtonsTexture)
    self:SetTexCoord(t,2,8)
    t:SetBlendMode("ADD")
    t:SetAllPoints(b)
    b:SetHighlightTexture(t)
    b:SetScript("OnClick",function(this) Minimize(self,this) end)
    b:SetHeight(24)
    b:SetWidth(24)
    b:SetScale(1)
    b:SetPoint("TOPRIGHT",f,"TOPRIGHT",f.rightmost,-2)
    b:SetFrameLevel(10)
    b:Show()
    return b
end
function lib:FrameAddConfigButton(f)
    local fname=f:GetName() .. "ConfigButton"
    local b=self:Create("Button",fname,f,"UIPanelCloseButton")
    b.ignore=true
    local t
    local ButtonsTexture=self:LoadTexture("Buttons")
    --------------- Normal
    t=b:CreateTexture()
    t:SetTexture(ButtonsTexture)
    self:SetTexCoord(t,22,8)
    t:SetAllPoints(b)
    b:SetNormalTexture(t)
    --------------- Pushed
    t=b:CreateTexture()
    t:SetTexture(ButtonsTexture)
    self:SetTexCoord(t,23,8)
    t:SetAllPoints(b)
    b:SetPushedTexture(t)
    --------------- HighLight
    t=b:CreateTexture()
    t:SetTexture(ButtonsTexture)
    self:SetTexCoord(t,2,8)
    t:SetBlendMode("ADD")
    t:SetAllPoints(b)
    b:SetHighlightTexture(t)
    if (type(f.Configure) ~= "function") then
        f.Configure=function() end
    end
    b:SetScript("OnClick",function(...) f:Configure(...) end)
    b:SetHeight(24)
    b:SetWidth(24)
    b:SetScale(1)
    b:SetPoint("TOPRIGHT",f,"TOPRIGHT",f.rightmost,-2)
    b:SetFrameLevel(10)
    b:Show()
    return b
end
function lib:LoadTexture(v)
    local path="Interface\\Addons\\%s\\Media\\%s"
    self.texture:SetTexture(nil)
    for _,i in pairs{"!AlarLib","AlarLib",self.fullname} do
        self.texture:SetTexture(path:format(i,v))
        local t=self.texture:GetTexture()
        if (t) then
            return t
        end
    end
end
function lib:argCheck(...)
    return true
end
function lib:GetXY(...)
    return 0,0
end
local flipbutton
function lib:FrameAddRescaleButton(f)
    f=self:IsFrame(f)
    local fname=f:GetName() .. "BtResize"
    -- Adding Button
    local b=self:Create("Button",fname,f,"UIPanelCloseButton")
    b:SetFrameLevel(10)
    b.ignore=true
    b:SetHeight(16)
    b:SetWidth(16)
    b:SetPoint("TOPLEFT",f,"TOPLEFT",0,0)
    flipbutton(b,"plus")
    self:TTAdd(b,"Rescale\n(Panel could look 'funny' until you reloadUI)")
    b:SetScript("OnClick",function(...) self:DoResize(...) end)
    b:Show()
    -- Adding Slider
    local s =self:FrameAddSlider(f,"Resizer","Scale",50,200,f:GetScale()*100)
    s:SetParent(UIParent)
    s.percentage=true
    s.decimals=1
    s:Hide()
    s:SetScript("OnMouseUp",function(this)
                self:DoResize(b,"LeftButton")
                end)
    local func=f:GetScript("OnHide")
    f:SetScript("OnHide",function ()
        s:Hide()
        pcall(func)
        flipbutton(b,"plus")
    end)
    s.OnRescaled=function(...) self:FormRescale(...) end
    return b
end
lib.FrameAddResizeButton=lib.FrameAddRescaleButton -- Compatibility
function lib:IsFrame(tf,verbose)
    local f
    if (type(tf) == "table") then
        f=tf
    else
        f=getglobal(tf)
    end
    if (not f) then
        return verbose and self:Print(tf , " is not a global name")
    end
    if (type(f) ~= "table") then
        return verbose and self:Print(tf .. " is not a table")
    end
    local canoperate=f.IsObjectType and f:IsObjectType("Frame")
    if (canoperate) then
        return f
    else
        return verbose and self:Print(tf .. " is not a frame")
    end
end
function lib:FrameAddHelpButton(f,testo)
    self:argCheck(f,1,"table")
    self:argCheck(testo,2,"string","nil")
    local fname=f:GetName() .. "BtHelp"
    local b=self:Create("Button",fname,f,"UIPanelCloseButton")
    b.ignore=true
    b:SetFrameLevel(10)
    b:SetNormalTexture("interface\\buttons\\ui-microbutton-help-up")
    b:SetPushedTexture("interface\\buttons\\ui-microbutton-help-down")
    b:SetHighlightTexture("interface\\buttons\\ui-microbutton-hilight")
    b:SetHeight(48)
    b:SetWidth(32)
    b:SetPoint("TOPLEFT",f,"TOPRIGHT",-5,16)
    b:SetScript("OnClick",function() self:CmdHelp() end)
    b:RegisterForClicks("LeftButtonUp")
    local h=getglobal(f:GetName() .. 'Header')
    if (h) then
        h:AddScript("OnEnter",function() b:SetAlpha(1) end)
        h:AddScript("OnLeave",function() b:SetAlpha(0) end)
    else
        f:AddScript("OnEnter",function() b:SetAlpha(0.5) end)
        f:AddScript("OnLeave",function() b:SetAlpha(0) end)
    end
    if (testo) then
        self:TTAdd(b,testo,true)
    end
    b:SetAlpha(0)
    b:Show()
    return b
end
local bminus="interface\\buttons\\ui-minusbutton-"
local bplus="interface\\buttons\\ui-plusbutton-"
function flipbutton(this,status)
    status=status or ''
    if (this.texture == 'plus' or status == 'minus') then
        this:SetNormalTexture(bminus .. "up")
        this:SetPushedTexture(bminus.. "down")
        this:SetHighlightTexture(bminus .. "hilight")
        this.texture="minus"
    else
        this:SetNormalTexture(bplus .. "up")
        this:SetPushedTexture(bplus .. "down")
        this:SetHighlightTexture(bplus .. "hilight")
        this.texture="plus"
    end
end
function lib:DoResize(this,button)
    if (button == "LeftButton") then
        flipbutton(this)
        local form=this:GetParent()
        local current=math.floor(form:GetScale()*100)
        local min=50
        local max=200
        local fname=form:GetName() .. "SliderResizer"
        local s=getglobal(fname)

        if (s) then
            s:ClearAllPoints()
            s.percentage=true
            s.decimals=1
            if (s:IsShown()) then
                s:Hide()
                return
            end
            s:SetPoint("BOTTOMLEFT",form,"TOPLEFT", 0, 5)
            s:Show()
            s:ClearAllPoints()
        end
    elseif (button == "RightButton") then
        self:PrintLiteral("Frame data:",f.storage)
    end
end
function lib:FrameAddMiniHeader(f,titolo)
    local h=self:FrameAddHeader(f,titolo)
    h:SetHeight(16)
    h.ntexture:SetTexture(0,0,0,0)
    if (h.Label) then
        h:SetFontObject(GameFontNormal)
    end
end
function lib:FrameAddHeader(f,titolo,noTexture)
    self:argCheck(f,1,"table")
    self:argCheck(titolo,2,"string","nil")
    self:argCheck(noTexture,3,"nil","boolean")
    local fname=f:GetName() .. 'Header'
    local r=getglobal(fname)
    if (not r) then
        r=self:Create("Frame",fname,f)
        r.compact=true
        f:SetMovable(true)
        f:SetClampedToScreen(true)
        r.ignore=true
        r:SetMovable(true)
        r:EnableMouse(true)
        r:RegisterForDrag("LeftButton")
        r:SetHeight(24)
        r:SetPoint("TOPLEFT",3,-3)
        r:SetPoint("TOPRIGHT",-3,3)
        r:SetScript("OnDragStart",OnDragStartParent)
        r:SetScript("OnDragStop",OnDragStopParent)
        self:TTAdd(r,"Drag to move")
        if (not noTexture) then
            ---------------
            r.ntexture=r:CreateTexture(nil,"ARTWORK")
            r.ntexture:SetTexture(.5,.1,.1)
            r.ntexture:SetGradient("vertical",.4,.1,.1,.8,.2,.2)
            r.ntexture:SetAllPoints(r)
            ---------------
            r.htexture=r:CreateTexture(nil,"HIGHLIGHT")
            r.htexture:SetTexture(.5,.1,.1)
            r.htexture:SetGradient("vertical",.8,.2,.2,.4,.1,.1)
            r.htexture:SetBlendMode("ADD")
            r.htexture:SetAllPoints(r)
        end
    end
    if (titolo) then
        f.Label=f:CreateFontString(fname .. "Label","OVERLAY","GameFontNormal")
        local s=r:CreateFontString(nil,"OVERLAY","GameFontNormalLarge")
        s:SetPoint("TOPLEFT",f.leftmost,0)
        s:SetPoint("BOTTOMRIGHT",f.rightmost,0)
        s:SetJustifyH("LEFT")
        s:SetJustifyV("TOP")
        s:SetText(titolo)
    end
    return r
end
function lib:FrameAddResizer(f)
    local fname=f:GetName() .. 'Resizer'
    local r=self:Create("Frame",fname,f)
    f:SetResizable(true)
    f:SetClampedToScreen(true)
    r.ignore=true
    r:SetResizable(true)
    r:EnableMouse(true)
    r:RegisterForDrag("LeftButton")
    r:SetWidth(64)
    r:SetHeight(32)
    r:SetPoint("BOTTOMRIGHT",f,"BOTTOMRIGHT",18,-10)
    -----------------
    r.ntexture=r:CreateTexture()
    r.ntexture:SetTexture(self:LoadTexture("Buttons"))
    r.ntexture:SetTexCoord(.75,.875,0,.125)
    r.ntexture:SetAllPoints(r)
    -----------------
    r.htexture=r:CreateTexture(nil,"HIGHLIGHT")
    r.htexture:SetTexture(self:LoadTexture("Buttons"))
    r.htexture:SetTexCoord(.75,.875,0,.125)
    r.htexture:SetBlendMode("ADD")
    r.htexture:SetAllPoints(r)
    r:SetScript("OnDragStart",OnDragStartParentNoAlt)
    r:SetScript("OnDragStop",OnDragStopParent)
    return r
end
function lib:FrameAddSlider(f,tipo,testo,min,max,current,x,y)
    local fname=f:GetName() .. 'Slider' .. tipo
    min=min or 0
    max=max or 100
    current=current or 50
    s=self:Create("Slider",fname,f,"OptionsSliderTemplate")
    s.father=f
    s:SetScript("OnShow",function(this) self:SliderUpdate(this) end)
    s:SetScript("OnValueChanged",function(this) self:SliderUpdate(this) end)
    s:SetMinMaxValues(min,max)
    s:SetValue(current)
    s:SetPoint("TOPLEFT",x or 0,y or 0)
    s:Show()
    return s
end
function lib:SliderUpdate(Slider)
    local frame=Slider.father
    if (frame) then
        if (not Slider.percentage and not Slider.decimals) then
            Slider.decimals=1
        end
    	local vcurrent=Slider:GetValue()
        local formato="%"
        if (Slider.decimals) then
            formato=formato.. "." .. Slider.decimals .. "f"
            vcurrent=math.floor(vcurrent * 10 ^ Slider.decimals)/10 ^ Slider.decimals
        else
            formato=formato .. "d"
            vcurrent=math.floor(vcurrent)
        end
        if (Slider.percentage) then
            perc="%"
        else
            perc=""
        end
        local sn=Slider:GetName()
    	local vmin,vmax=Slider:GetMinMaxValues()
    	local x=getglobal(sn .. "Low")
    	if (x) then
    		x:SetText(format(formato,vmin) .. perc)
    	end
    	x=getglobal(sn .. "High")
    	if (x) then
    		x:SetText(format(formato,vmax) .. perc)
    	end
    	x =getglobal(sn .. "Text")
    	if (x) then
    		x:SetText(format(formato,vcurrent) .. perc)
    	end
    	if (type(Slider.OnRescaled) == "function") then
            Slider:OnRescaled(frame)
    	end
    end
end
function lib:FrameAddUnitButton(f,name,testo,unit,x,y)
    local b=self:FrameAddButton(f,name,testo,x,y,",SecureActionButtonTemplate")
    b:SetAttribute("type1","macro")
    b:SetAttribute("macrotext1","/target " .. unit)
    b.SetUnit=function(this,unit,extra)
        this:SetAttribute("macrotext1","/target " .. unit)
        this:SetText(unit .. (extra or  ''))
        this.Unit=unit
        end
    b.GetUnit=function(this) return this.Unit or 'none' end
    b:RegisterForClicks("AnyUp")
    return b
end
function lib:FrameAddText(...)
    local tt=new()
    for i=1,select('#',...),2 do
        local key,value=select(i,...)
        tt[key]=value
    end
    local f
    if (tt.clickable) then
        f=self:CreateFrame("Button")
    else
        f=self:CreateFrame("EditBox")
        f:SetMultiLine(true)
        f:SetAutoFocus(false)
    end
    del(tt)
end


