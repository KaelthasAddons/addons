--[[
Name: AlarLib-3.0
Revision: $Rev: 330 $
Author: Alar of Daggerspine
Email: alar@aspide.it
Website: http://wow.aspide.it
Documentation: http://wiki.wowace.com/wiki/AlarLib-3.0
SVN: $HeadUrl:$
Description: Generic library
Dependencies: Ace3
License: LGPL v2.1
--]]
local function xx(msg)
DEFAULT_CHAT_FRAME:AddMessage(msg)
end
local MAJOR_VERSION = "AlarCore-3.0"
local MINOR_VERSION = tonumber(string.sub("$Revision: 330 $", 12, -3))
local pp=AlarLittlePrintUtility or function() return end
pp("Loading " .. MAJOR_VERSION .. " " .. MINOR_VERSION)
if (not LibStub) then
    pp("Couldn't find LibStub. Please reinstall " .. MAJOR_VERSION )
end
local lib,old=LibStub:NewLibrary(MAJOR_VERSION,MINOR_VERSION)
if (not lib) then
    pp("Already loaded a new version of" .. MAJOR_VERSION)
    return -- Already loaded
end
if (old) then
    pp(format("Upgrading %s from %s to %s",MAJOR_VERSION,old,MINOR_VERSION))
end
local DESCRIPTION="Description"
local RELNOTES="Release Notes"
local LIBRARIES="Libraries"
local AceConfig = LibStub("AceConfig-3.0",true) or pp("Missing AceConfig-3.0")
local AceDBOptions=LibStub("AceDBOptions-3.0",true) or pp ("Missing AceDBOptions-3.0")
local AceConfigDialog=LibStub("AceConfigDialog-3.0",silent) or self:Print("Missing gui support")
local AceGUI=LibStub("AceGUI-3.0",silent)
local next = next
local pairs = pairs
local pcall = pcall
local type = type
local GetTime = GetTime
local gcinfo = gcinfo
local unpack = unpack
local geterrorhandler = geterrorhandler
local new, del
do
	local list = setmetatable({}, {__mode="k"})
	function new(...)
		local t = next(list)
		if t then
			list[t] = nil
			return t
		else
			return {}
		end
	end
	function del(t)
		setmetatable(t, nil)
		for k in pairs(t) do
			t[k] = nil
		end
		list[t] = true
	end
end

local _G=_G
lib.mix=lib.mix or {}
local mix=lib.mix
lib.hlp=lib.hlp or {}
local hlp=lib.hlp
lib.var=lib.var or {}
local var=lib.var
lib.virt=lib.virt or {}
local virt=lib.virt
lib.mixinTargets = lib.mixinTargets or {}
lib.frame=lib.frame or CreateFrame("Frame")
lib.combatSchedules = lib.combatSchedules or {}
local combatSchedules = lib.combatSchedules

local function nop(self,...) --[[self:Print(...) --]]  end
do
    local function f1(self,flag,value)
        return self:Apply(flag,value)
    end
    local function f2(self,flag,value)
        return self['Apply' .. flag](self,value)
    end
    
    var._Apply=setmetatable({},{
            __index = 
            function(table,cmd)
                self=rawget(table,'_handler')
                if (type(self["Apply" .. cmd]) =='function') then
                    rawset(table,cmd,f2)
                elseif (type(self.Apply)=='function') then
                    rawset(table,cmd,f1)
                else 
                    rawset(table,cmd,nop)
                end
                return rawget(table,cmd)
            end
        }
    )                    
end


-- Test Code
local ace2={Dump=nop}
if (ALARDEVELOPMENTPC) then
-- If it's around, I embed PrintLiteral from Ace2
    if (AceLibrary and AceLibrary:HasInstance("AceConsole-2.0")) then
        ace2=AceLibrary("AceConsole-2.0")
        ace2.Dump=ace2.PrintLiteral
    end
    --lib.frame:RegisterEvent("ADDON_LOADED")
    --lib.frame:RegisterEvent("VARIABLES_LOADED")
end
-- End Test Code
-- Color system related function
lib.colors={
azure                   ="0c92dc"
,black                   ="000000"
,blue                    ="0000ff"
,brightgrey              ="d0d0d0"
,connection_color        ="33ff66"
,copper                  ="cc9900"
,debug_color             ="00ff00"
,gold                    ="ffff66"
,gray                    ="808080"
,green                   ="20ff20"
,green2                  ="00c000"
,grey                    ="909090"
,guildchat               ="269926"
,highlight_color_code    ="ffffff"
,lightblue               ="515179"
,lightyellow             ="ffff9a"
,money_color             ="ffcc33"
,orange                  ="ff9900"
,partychat               ="515179"
,purple                  ="800080"
,raidchat                ="66331a"
,red                     ="ff2020"
,red2                    ="f41400"
,silver                  ="c0c0c0"
,status_color            ="0066ff"
,white                   ="ffffff"
,yellow                  ="ffd200"
,yellow2                 ="ffed1a"
,druid       ="ff7d0a"
,hunter      ="abd473"
,mage        ="69ccf0"
,paladin     ="f58cba"
,priest      ="ffffff"
,rogue       ="fff569"
,shaman      ="f58cba"
,warlock     ="9482ca"
,warrior     ="c79c6e"
}
setmetatable(lib.colors,
    {__index=
        function(table,key)
        return rawget(table,strlower(key)) or table.yellow end 
    }
)
-- Like it or not, I dont want to relay on Crayon
--[[
C.Azure.c returns a string "rrggbb"
tostring(C.Azure) returns a string "rrggbb"
so "aa" .. C.Azure can be done and returns "aarrggbb"

C.Azure() returns r,g,b as float list
C.Azure.r returns r as float
C("testo","azure") returns "|cff" .. >color code for azure> .. "test" .. "|r"
--]]
local C
do
    local function colorize(stringa,colore)
        return "|cff" .. C[colore] .. tostring(stringa) .. "|r" 
    end    
    local colors=lib.colors
    local map={r=1,g=2,b=3,c=4}
    local mt={
        __index=function(table,key)
            return rawget(table,map[key])
        end,
        __tostring=function(table)
            return rawget(table,4)
        end,
        __concat=function(t1,t2)
            return tostring(t1) .. tostring(t2)
        end,
        __call=function(table,...)
            return unpack(table)
        end
        
    }
    C=setmetatable({},{
            __index=function(table,key)
                local c=colors[key]
                local r,g,b=tonumber(c:sub(1,2),16)/255,tonumber(c:sub(3,4),16)/255,tonumber(c:sub(5,6),16)/255
                rawset(table,key,setmetatable({r,g,b,c},mt))
                return  rawget(table,key)
            end,
            __call = function(table,...)
                    return colorize(...)
            end
        }
    )
end
local L
mix.C=C
-- Stolen by AceConsole-2.0
local function tostring_args(a1, ...)
	if select('#', ...) < 1 then
		return tostring(a1)
	end
	return tostring(a1), tostring_args(...)
end
local function print(text, name, r, g, b, frame, delay)
	if not text or text:len() == 0 then
		text = " "
	end
	if not name then
	else
		text = "|cffffff78" .. tostring(name) .. ":|r " .. text
	end
	local last_color
	for t in text:gmatch("[^\n]+") do
		(frame or DEFAULT_CHAT_FRAME):AddMessage(last_color and "|cff" .. last_color .. t or t, r, g, b, nil, delay or 5)
		if not last_color or t:find("|r") or t:find("|c") then
			last_color = t:match(".*|c[fF][fF](%x%x%x%x%x%x)[^|]-$")
		end
	end
	return text
end

local function versiontonumber(version)
    if (type(version)=="number") then
        return version
    end
    local s,e,svn=version:find("$Rev%D*(%d+)%D*%$")
    version=version:gsub("$Rev%D*(%d+)%D*%$","")
    local res=0
    local fractpart=0
    local mult=1
    for i in version:gmatch("%d+") do
        local n=tonumber(i) or 0
        if (n < 1000) then
            res=res*1000
            res=res+n
        end
    end
    return tonumber(res .. '.' .. (svn or '0'))
end

lib.nops={
'HF_Cmd',
'HF_Color',
'HF_Command',
'HF_Commands',
'HF_Disabled',
'HF_Enabled',
'HF_Load',
'HF_Paragraph',
'HF_Pre',
'HF_Push',
'HF_Title',
'HF_Toggle',
'Debug',
'AddEdit',
'SetVar',
'AddCmdA',
}

function mix:VersionCompare(otherversion,strict)
    oterhversion=versiontonumber(otherversion)
    if (strict) then
        return self.numericversion-otherversion
    else
        return math.floor(self.numericversion - otherversion)
    end
end
local Myclass
function mix:Is(class,target)
    target=target or "player"
    if (target == "player") then
        if (not Myclass) then
            _,Myclass=UnitClass("player")
        end
        return Myclass==strupper(class)
    else
        local    rc,_,unitclass=pcall(UnitClass,target)
        if (rc) then
            return unitclass==strupper(class)
        else
            return false
        end
    end
end
function mix:Health(unit)
    local totale=UnitHealthMax(unit) or 1
    local corrente=UnitHealth(unit) or 1
    if (corrente == 0) then corrente =1 end
    if (totale==0) then totale = corrente end
    local life=corrente/totale*100
    return math.ceil(life)
end
function mix:Age(secs)
    return self:TimeToStr(GetTime() - secs)
end
function mix:Mana(unit)
    local totale=UnitManaMax(unit) or 1
    local corrente=UnitMana(unit) or 1
    if (corrente == 0) then corrente =1 end
    if (totale==0) then totale = corrente end
    local life=corrente/totale*100
    return math.ceil(life)
end
function mix:GetUnitDistance(x,y,unit)
    unit=unit or "player"
    local from={}
    local to={}
    from.x,from.y=GetPlayerMapPosition(unit)
    to.x=x
    to.y=y
    return self:GetDistance(from,to) * 10000
end
function mix:GetDistance(a,b)
--------------
-- Calculates distance betweeb 2 points given as
-- a.x,a.y and b.x,b.y
	 local x=b.x - a.x
	 local y=b.y -a.y
	 local d=x*x + y* y
	 local rc,distance=pcall(math.sqrt,d)
	 if (rc) then
        return distance
    else
        return 99999
    end
end
function mix:LoadEvents(events)
    for k,v in pairs(events) do
        self.registry.events[k]=v
    end
end
function mix:LoadHooks(hooks)
    for k,v in pairs(hooks) do
        if (not (type(self.org[v]) ~= 'function')) then
            self.org[v]=getglobal(v)
        end
        self.registry.hooks[k]=v
    end
end
--[[
 Optional compatibility function. Registers methods with magic names
 hook* go to hooks' registry
 evt* go to events' registry
 Not really needed
--]]
function mix:Register()
    pp("INVOKED REGISTER",self.name)
    local s,e,prefix,name    
    self.registry=self.registry or {}
    self.registry.hooks=self.registry.hooks or {}
    self.registry.events=self.registry.events or {}
    self.org=self.org or {}
    for k,v in pairs(self) do
        s,e,prefix,name=k:find("(Hook)(%a+)")
        if (s) then
            self.registry.hooks[name]=false
            self.org[name] = _G[name]
        end
        s,e,prefix,name=k:find("(Evt)(%a+)")
        if (s) then
            self.registry.events[name]=0
        end
    end
    pp("REGISTER DONE",self.name)
end

local LoadDefaults
function LoadDefaults(self)
    self.OptionsTable={
        handler=self,
        type="group",
        childGroups="tab",
        name=self.title,
        desc=self.notes,
        args={
           gui = {
                name="GUI",
                desc="Activates gui",
                type="execute",
                func="Gui",
                guiHidden=true,
            },
           hlp = {
                name="HELP",
                desc="Show help",
                type="execute",
                func="Help",
                guiHidden=true,
            },
            on = {
                name="On",
                desc="Activates " .. self.title,
                type="execute",
                func="Enable",
                guiHidden=true,
            },
            off = {
                name="Off",
                desc="Deactivates " .. self.title,
                type="execute",
                func="Disable",
                guiHidden=true,
                arg='Active'
            },
            standby = {
                name="Enabled",
                desc="Toggle " .. self.title .. " status",
                type="toggle",
                get="IsEnabled",
                set="Toggle",
                cmdHidden=true,
                arg='Active'
            },
            toggle={
                type="group",
                name="toggle",
                desc="configuration switches",
                guiHidden=true,
                args={}
            },
            commands={
                type="group",
                name="commands",
                desc="command line",
                guiHidden=true,
                args={}
            }
        }
    }
    self.DbDefaults={
        global={
            currentversion=self.version,
            firstrun=true,
            lastversion=0,
            lastinterface=20300,
            
        },
        profile={
            toggles={
                Active=true,
            },
            ["*"]={},
        }
    }
    self.MenuLevels={"root"}
    self.ItemOrder=setmetatable({},{__index=function(table,key) rawset(table,key,1)
    return 1
    end})
    local AceDB  = LibStub("AceDB-3.0",true) or pp("Missing AceDB-3.0")
    if (AceDB and not self.db) then
        self.db=AceDB:New(self.DATABASE)
        --self.localdb=self.db:RegisterNamespace(self.name)
    end
    self.db:RegisterDefaults(self.DbDefaults)
    self:SetEnabledState(self:GetBoolean("Active"))
    -- I have for sure some library that needs to be intialized Before the addon
    for _,library in self:IterateEmbeds(self) do
        local lib=LibStub(library)
        if (lib.OnEmbedPreInitialize) then
            lib:OnEmbedPreInitialize(self) 
         end
    end   
end
function mix:OnInitialize(...)
    L=AlarGetLocale()
    self:Print("Version %s %s loaded" ,self:Colorize(self.version,'green'),self:Colorize(format("(Revision: %s)",self.revision),"silver"))
    LoadDefaults(self) 
    self.help=setmetatable(
        {},
        {__index=function(table,key) 
            rawset(table,key,"") 
            return rawget(table,key) 
            end
        }
    )   
    self:OnInitialized(...)
    self.ProfileOpts=AceDBOptions:GetOptionsTable(self.db)
    local profile=self.name .. 'profile'
    local main=self.name
    local description=self.name .. DESCRIPTION
    local relnotes=self.name .. RELNOTES
    local libraries=self.name ..LIBRARIES
    self:HF_Title('Alar shared routines',LIBRARIES)
    for libname,k in LibStub:IterateLibraries() do
        if (libname:match("Alar%w*-3%.0")) then
            self:HF_Lib(libname,'green')
        end
    end    
    self:HF_Title('\nACE 3',LIBRARIES)
    for libname,k in LibStub:IterateLibraries() do
        if (libname:match("Ace%w*-3%.0")) then
            self:HF_Lib(libname,'yellow')
        end
    end    
    self:HF_Title('\nOther libraries',LIBRARIES)
    for libname,k in LibStub:IterateLibraries() do
        if (libname:match("Ace%w*-3%.0")) then
        elseif (libname:match("Alar%w*-3%.0")) then
        else
            self:HF_Lib(libname,'gray')
        end
    end    
    self:HF_Load(RELNOTES,relnotes)
    self:HF_Load(DESCRIPTION,description)
    self:HF_Load(LIBRARIES,libraries)
    AceConfig:RegisterOptionsTable(profile,self.ProfileOpts)
    AceConfig:RegisterOptionsTable(main,self.OptionsTable,{self.name,strlower(self.ID)})
    AceConfigDialog:AddToBlizOptions(description, main)
    AceConfigDialog:AddToBlizOptions(profile,L.Profile,self.name)
    self.CfgRel=AceConfigDialog:AddToBlizOptions(relnotes,L[RELNOTES],self.name)
    self.CfgDlg=AceConfigDialog:AddToBlizOptions(main,L.Configuration,self.name)
    AceConfigDialog:AddToBlizOptions(libraries,L.Libraries,self.name)
end

-- help related functions
function hlp:HF_Push(section,text)
    section=section or self.lastsection or DESCRIPTION
    self.lastsection=section
    self.help[section]=self.help[section]  .. '\n' .. text
end
function hlp:HF_Lib(libname)
        local o,minor=LibStub(libname,true)
        if (o) then
            self:HF_Pre(format("%s release: %s",self:Colorize(libname,'green'),self:Colorize(minor,'orange')),LIBRARIES)
        end        

end
function hlp:HF_Title(text,section)
    self:HF_Push(section,C(text or '','yellow') .. "\n")
end

function hlp:HF_Paragraph(text,section)
    self:HF_Push(section,"\n"..C(text,'green'))
end
function hlp:HF_Pre(testo,section)
    self:HF_Push(section,testo)
end

function hlp:RelNotes(major,minor,revision,t)
    local fmt=self:Colorize("Release note for %d.%d.%d:",'Yellow') .."\n%s"
    local lines={}
    local spacer=""
    local maxpanlen=70
    lines={strsplit("\n",t)}
    for i,tt in ipairs(lines) do
        local prefix,text=tt:match("^(Fixed):(.*)")
        if (prefix == "Fixed") then
            prefix=self:Colorize("Fixed: ",'Red')
            spacer=           "       "
        else
            prefix,text=tt:match("^(Feature):(.*)")
            if (prefix == "Feature") then
                prefix=self:Colorize("Feature: ",'Green')
                spacer=             "         "
            else
                text=tt
                prefix=spacer
            end
        end
        local tta=""
        tt=text
        while (tt:len() > maxpanlen)  do
            local p=tt:find("[%s%p]",maxpanlen -10) or maxpanlen
            tta=tta..prefix..tt:sub(1,p) .. "\n"
            prefix=spacer
            tt=tt:sub(p+1)
        end
        tta=tta..prefix..tt
        tta=tta:gsub("Upgrade:",self:Colorize("Upgrade:",'Azure'))
        lines[i]=tta:gsub("Example:",self:Colorize("Example:",'Orange'))
    end
    self:HF_Push(RELNOTES,fmt:format(major,minor,revision,strjoin("\n",unpack(lines))))
end

function hlp:HF_Load(section,optionname)
-- Creazione pannello di help
-- Livello due del tree
    local testo =self.help[section] or 'No text available'
	AceConfig:RegisterOptionsTable(optionname, {
		name = self.title,
		type = "group",
		args = {
			help = {
				type = "description",
				name = testo,
			},
		},
	})
	AceConfigDialog:SetDefaultSize(optionname, 600, 400)
end

function virt:Localize(...)
    return
end
function virt:OnInitialized(...)
    return
end
function virt:OnEnabled(...)
    return
end
function virt:OnDisabled(...)
    return
end
-- var area
local getgroup
function getgroup(self)
    local group=self.OptionsTable
    local m=self.MenuLevels
    for i=2,#m do
        group=group.args[self.MenuLevels[i]]
    end
    if (type(group) ~= "table") then
        group={}
    end
    return group
end
local getorder
function getorder(self,group)
    local i=self.ItemOrder[group.name]+1
    self.ItemOrder[group.name]=i
    return i
end
local toflag
function toflag(...)
    local appo=tostring_args(...)
    return appo:gsub("%W",'')
end
function var:EndLabel()
    local m=self.MenuLevels
    if (#m > 1) then
        table.remove(m)
    end
end    

--self:AddLabel("General",Green)
function var:AddLabel(title,description,stringcolor)
    self:EndLabel()
    description=description or title
    stringcolor=stringcolor or C.yellow
    local t=self:AddSubLabel(title,description,stringcolor)
    t.childGroups="tab"
    return t
        
end
--self:AddSubLabel("General Options",AMO_Green)
function var:AddSubLabel(title,description,stringcolor)
    local m=self.MenuLevels
    description=description or title
    stringcolor=stringcolor or C.orange
    local group=getgroup(self)
    local flag=toflag(group.name,title)
    group.args[flag]={
        name="|cff" .. stringcolor .. title .. "|r",
        desc=description,
        type="group",
        cmdHidden=true,
        args={},
        order=getorder(self,group),
    }
    table.insert(m,flag)
    return group.args[flag]
end

--self:AddText("Testo")
function var:AddText(text,image,imageHeight,imageWidth,imageCoords)
    local group=getgroup(self)
    local flag=toflag(group.name,text)
    local t={
        name=text,
        type="description",
        image=image,
        imageHeight=imageHeight,
        imageWidth=imageWidth,
        imageCoords=imageCoords,
        desc=text,
        order=getorder(self,group),
        
    }
    group.args[flag]=t
    return t
end

--self:AddToggle("AUTOLEAVE",true,"Alt-Click on hide button in battlefield alert leaves the queue")

function var:AddToggle(flag,defaultvalue,name,description)
    description=description or name
    local group=getgroup(self)
    local t={
        name=name,
        type="toggle",
        get="OptToggleGet",
        set="OptToggleSet",
        desc=description,
        arg=flag,
        order=getorder(self,group),
        
    }
    group.args[flag]=t
    if (self.db.profile.toggles[flag]== nil) then
        self.db.profile.toggles[flag]=defaultvalue
    end
    self.OptionsTable.args.toggle.args[flag]=t
    return t
end
-- self:AddEdit("REFLECTTO","","Whisper reflection receiver:","All your whispers will be forwarded to this guy")
function var:AddEdit(flag,defaultvalue,name,description,usage)
    description=description or name
    usage = usage or description
    local group=getgroup(self)
    local t={
        name=name,
        type="input",
        get="OptToggleGet",
        set="OptToggleSet",
        desc=description,
        arg=flag,
        usage=usage,
        order=getorder(self,group),
        
    }
    group.args[flag]=t
    if (self.db.profile.toggles[flag]== nil) then
        self.db.profile.toggles[flag]=defaultvalue
    end
    self.OptionsTable.args.toggle.args[flag]=t
    return t
end
--self:AddAction(flagname,method,label,tooltip)
function var:AddAction(flag,method,name,description,input)
    description=description or name
    local group=getgroup(self)
    local t={
        name=name,
        type="execute",
        func=method,
        input=input,
        desc=description,
        confirm=true,
        order=getorder(self,group),
    }
    group.args[flag]=t
    return t
end
--self:AddAction(flagname,method,label,tooltip)
function var:AddExec(flag,...)
    local t=self:AddAction(flag,...)
    t.confirm=false
    t.guiHidden=true
    self.OptionsTable.args[flag]=t    
    return t
end
--self:AddCmd(flagname,method,label,tooltip)
function var:AddCmd(flag,method,args,description)
    self:RegisterChatCommand(flag,method)
    description=description or flag
    args=args or ''
    local group=getgroup(self)
    local t={
        name=C('/' .. flag .. ' ' .. args,'orange'),
        type="description",
        order=getorder(self,group),
    }
    group.args[flag .. 'title']=t
    t={
        name=description,
        type="description",
        order=getorder(self,group),
    }
    group.args[flag]=t
    return t
end
--self:AddSeparator(flagname,method,label,tooltip)

function var:AddSeparator(text)
    pp('addsep',text)
    local group=getgroup(self)
    local i=getorder(self,group)
    local flag=group.name .. i
    flag=flag:gsub('%W','')
    local t={
        name=text,
        type="header",
        order=i,
    }
    group.args[flag]=t
    return t
end

function lib:OnEmbedEnable(first)
end

function lib:OnEmbedDisable()
end

function mix:OnEnable(...)
    self:Print(C("enabled",'green'))
    self:ApplySettings()
    self:OnEnabled(...)
end
function mix:OnDisable(...)
    self:Print(C("disabled",'red'))
    self:OnDisabled(...)
end
function mix:Dump(...)
    xx("dumpo")
    ace2.Dump(self,...)
end
local _GetMethod 
function _GetMethod(target,prefix,func)
    local method=prefix .. func
    if (type(target[method])== "function") then
        return method
    elseif (type(target["_" .. prefix])) then
        return "_" .. prefix
    end
end 
function mix:HookStart(hooks)
    hooks=hooks or self.registry.hooks
    for hook,security in pairs(hooks) do
        local hooked=_G[hook]
        if (hooked) then
            local method=_GetMethod(self,"Hook",hook)
            pp("Hooking " .. hook .. ' to ' .. tostring(method) .. ' Security:' .. tostring(security))
            if (not self:IsHooked(hook)) then
                if (not type(self.org[hook]) ~= 'function') then
                    self.org[hook]=hooked
                end
                if (security=='RAW') then
                    self:RawHook(hook,method,true)
                elseif (security=='SECURE') then
                    self:SecureHook(hook,method)
                else
                    self:Hook(hook,method)
                end
            end
        else
            hooks[hook]=nil
        end
    end
end
function mix:HookStop(hooks)
    hooks=hooks or self.registry.hooks
    for hook,level in pairs(hooks) do
        if (self:IsHooked(hook)) then
            pp("UnHooking " .. hook)
            self:Unhook(hook)
        end
    end
end
function mix:EvtStart(events)
    events=events or self.registry.events
    for evt,delay in pairs(events) do
        local method=_GetMethod(self,"Evt",evt)
        if (method) then
            --pp("Observing " .. evt .. ' with ' .. tostring(method))
            if (tonumber(delay)) then
                if (delay>0) then
                    self:RegisterBucketEvent(evt,delay,method)
                else
                    self:RegisterEvent(evt,method)
                end
            end
        end
    end
end
function mix:EvtStop(events)
    events=events or self.registry.events
    for evt,delay in pairs(events) do
        if (tonumber(delay)) then
            if (delay>0) then
                self:UnregisterBucketEvent(evt)
            else
                self:UnregisterEvent(evt)
            end
        end
    end
end
function mix:CustomPrint(r, g, b, frame, delay, connector, a1, ...)
    frame=frame or DEFAULT_CHAT_FRAME
	if connector == true then
		local s
		if select('#', ...) == 0 then
			s = tostring(a1)
		else
			s = (", "):join(tostring_args(a1, ...))
		end
		return print(s, self.ID, r, g, b, frame or self.printFrame, delay)
	elseif tostring(a1):find("%%") and select('#', ...) >= 1 then
	   
		local success, text = pcall(string.format, tostring_args(a1, ...))
		if success then
			return print(text, self.ID, r, g, b, frame or self.printFrame, delay)
		end
	end
	return print((connector or " "):join(tostring_args(a1, ...)), self.ID, r, g, b, frame or self.printFrame, delay)
end
function mix:Print(...)
	return self:CustomPrint(nil, nil, nil, nil, nil, ' ', ...)
end

function mix:PrintLiteral(...)
	return self:Dump(...)
end
function mix:Colorize(stringa,colore)
    return C(stringa,colore) .. "|r"
end
function mix:Toggle()
    if (self:IsEnabled()) then
        self:Disable()
    else
        self:Enable()
    end
end
function var:Vars()
    return pairs(self.db.profile.toggles)
end
function var:SetBoolean(flag,value)
    if (value) then
        value=true
    else
        value=false
    end
    self.db.profile.toggles[flag]=value  
    return not value
end
function var:GetBoolean(flag)
    if (self.db.profile.toggles[flag]) then
        return true
    else
        return false
    end  
end
function var:OptToggleSet(info,value)
    local flag=info.option.arg
    local tipo=info.option.type
    --self:SendMessage(self.ID .. "_UPDATECONFIG",flag,tipo)
    
    if (tipo=="toggle") then
        self:SetBoolean(flag,value)
    else
        self:GetSet(flag,value)
    end  
    if (self:IsEnabled()) then
        self._Apply[flag](self,flag,value)
    end
end
function var:OptToggleGet(info)
    local flag=info.option.arg
    local tipo=info.option.type
    if (tipo=="toggle") then
        return self:GetBoolean(flag)
    else
        return self:GetSet(flag)
    end  
end
function var:ApplySettings()
    if (type(self.ApplyAll)=="function") then
        self:ApplyAll()
    else
        for i,v in self:Vars() do
            self._Apply[i](self,i,v)
        end
    end
end
function mix:Gui(info)
    if (AceConfigDialog and AceGUI) then 
        InterfaceOptionsFrame_OpenToFrame(self.CfgDlg)
    else
        self:Print("No GUI available")
    end
        
end
function mix:Help(info)
    if (AceConfigDialog and AceGUI) then 
        InterfaceOptionsFrame_OpenToFrame(self.CfgRel)
    else
        self:Print("No GUI available")
    end
        
end
function mix:Trace(fmt,...)
    local stack={strsplit("\n",debugstack(1,6,0))}
    for i,info in ipairs(stack) do
        --self:Print("Stack: %s",self:Colorize(info,'green'))
        if (info:find(MAJOR_VERSION,1,true)) then
        else
            -- out of library
            stack=info
            break
        end
    end
    local _,_,file,func=stack:find("Interface.AddOns.(.*): in function (.*)")
    file=file or ''
    func=func or ''
    func=func:gsub("Interface.AddOns.",""):gsub("[<>'']","")
    msg=format("At %s from %s\nWhat:",self:Colorize(file,'azure'),self:Colorize(func,'orange'))
    local r,g,b=C.Yellow()
    self.CustomPrint("Where",r,g,b, nil, nil,' ',msg .. tostring(fmt), ...)
end
local uihold=UIERRORS_HOLD_TIME or 1
local onscreen=[[
function onscreen(self,msg,hold)
    if (type(self) ~= "table") then
        hold,msg,self=msg,self,nil
    end
        local r,g,b=XCOLORX
        hold=hold or 4
	   UIErrorsFrame:AddMessage(tostring(msg), r,g,b, 1.0, uihold * hold);
	   end
end
]]
mix.OnScreen=setmetatable({},
{
__index=function(table,key)
        local r,g,b=C[key]()
        local func=loadstring(onscreen:gsub("XCOLORX",format("%f.2,%f.2,%f.2",r,g,b))) or error("loadstring failed")
        rawset(table,key,func)
        return func
	end,
__call=table.Yellow,
}         
)
function mix:Long(msg) self.OnScreen.Yellow(msg,20) end
function mix:Onscreen_Orange(msg) self.OnScreen.Orange(msg,2) end
function mix:Onscreen_Purple(msg) self.OnScreen.Purple(msg,8) end
function mix:Onscreen_Yellow(msg) self.OnScreen.Yellow(msg,1) end
function mix:Onscreen_Azure(msg) self.OnScreen.Azure(msg,1) end
function mix:Onscreen_Red(msg) self.OnScreen.Red(msg,1) end
function mix:Onscreen_Green(msg) self.OnScreen.Green(msg,1) end

-- In case of upgrade, we need to redo embed for ALL Addons
-- This function get called on addon creation
-- Anything I define here is immediately available to addon code
function lib:Embed(target)
    pp("Embedding " .. MAJOR_VERSION .. " " .. MINOR_VERSION)
    -- Info from TOC
    local v=GetAddOnMetadata(tostring(target),"version")
    v=v or '0'
    target.tocversion=v
    local version,revision=v:match("([^$ ]*) *(.*)")
    target.version=version or "0"
    if (target.version == '@project-version@') then
        target.version=GetAddonMetadata('X-Version')
    end
    if (target.revision == '@project-revision@') then
        target.revision=GetAddonMetadata('X-Revision')
    end
    target.revision=revision:match("%d+") or "0"
    target.prettyversion=format("%s (Revision: %s)",target.version,target.revision)
    target.numericversion=versiontonumber(v)
    target.title=GetAddOnMetadata(tostring(target),"title") or 'No title'
    target.notes=GetAddOnMetadata(tostring(target),"notes") or 'No notes'
    -- Setting sensible default for mandatory fields
    target.ID= (target.name:gsub("[^%u%d]","") .. "XXXX"):sub(1,3)
    target.DATABASE=GetAddOnMetadata(target.name,"X-Database") or "db" .. target.ID
    -- Standard Mixins
    for name,method in pairs(mix) do
        target[name] = method
    end
    -- Help system mixins
    for name,method in pairs(hlp) do
        target[name] = method
    end
    -- var management mixins
    for name,method in pairs(var) do
        target[name] = method
    end
    target._Apply._handler=target
    -- virtual methods, they can be ovverriden
    -- versioning is not important, because virtual methods are always nop
    for name,_ in pairs(virt) do
        target[name]=target[name] or nop
    end
    -- nops, placeholders. To be removed when done with porting
    for _,name in pairs(lib.nops) do
        target[name]=target[name] or nop
    end
    
    target.registry=target.registry or {}
    local r=target.registry
    for _,subtable in pairs{'events','hooks','commands','options','icommands'} do
        r[subtable]=r[subtable] or {}
    end
    target.org=target.org or {}
    lib.mixinTargets[target] = true
end


----- New Global Function, I check if someone already defined then
if (not string.capitalize) then
    function string.capitalize(stringa)
        return string.gsub(strlower(stringa),
                "%w",function (s) return strupper(s) end,1)
    end
end
if (not capitalize) then
    capitalize=string.capitalize
end
if (not table.kpairs) then
    function table.kpairs(t,f)
      local a = {}
      for n in pairs(t) do table.insert(a, n) end
      table.sort(a, f)
      local i = 0      -- iterator variable
      local iter = function ()   -- iterator function
        i = i + 1
        if a[i] == nil then
            return nil
        else
            local k=a[i]
            a[i]=nil -- Should optimize memory usage
            return k, t[k]
        end
      end
      return iter
    end
end
if (not kpairs) then
    kpairs=table.kpairs
end
-------------------------------------------------------------------------------
-- ScheduleLeaveCombatAction Port
-- Shamelessly stolen from Ace2
-------------------------------------------------------------------------------
function mix:CancelAllCombatSchedules()
	local i = 0
	while true do
		i = i + 1
		if not combatSchedules[i] then
			break
		end
		local v = combatSchedules[i]
		if v.self == self then
			v = del(v)
			table.remove(combatSchedules, i)
			i = i - 1
		end
	end
end


do
	local tmp = {}
	local doaftercombataction
	function doaftercombataction()
	   pp("out of combat")
		for i, v in ipairs(combatSchedules) do
			tmp[i] = v
			combatSchedules[i] = nil
		end
		for i, v in ipairs(tmp) do
			local func = v.func
			if func then
				local success, err = pcall(func, unpack(v, 1, v.n))
				if not success then geterrorhandler()(err:find("%.lua:%d+:") and err or (debugstack():match("(.-: )in.-\n") or "") .. err) end
			else
				local obj = v.obj or v.self
				local method = v.method
				local obj_method = obj[method]
				if obj_method then
					local success, err = pcall(obj_method, obj, unpack(v, 1, v.n))
					if not success then geterrorhandler()(err:find("%.lua:%d+:") and err or (debugstack():match("(.-: )in.-\n") or "") .. err) end
				end
			end
			tmp[i] = del(v)
		end
	end
	lib.frame:SetScript("OnEvent",nil)
	lib.frame:RegisterEvent("PLAYER_REGEN_ENABLED")
    lib.frame:SetScript("OnEvent",doaftercombataction)
end

function mix:ScheduleLeaveCombatAction(method, ...)
	local style = type(method)
	if self == AceEvent then
		if style == "table" then
			local func = (...)
			--AceEvent:argCheck(func, 3, "string")
			if type(method[func]) ~= "function" then
				--AceEvent:error("Cannot schedule a combat action to method %q, it does not exist", func)
			end
		else
			--AceEvent:argCheck(method, 2, "function", --[[so message is right]] "table")
		end
		self = method
	else
		--AceEvent:argCheck(method, 2, "function", "string", "table")
		if style == "string" and type(self[method]) ~= "function" then
			--AceEvent:error("Cannot schedule a combat action to method %q, it does not exist", method)
		elseif style == "table" then
			local func = (...)
			--AceEvent:argCheck(func, 3, "string")
			if type(method[func]) ~= "function" then
				--AceEvent:error("Cannot schedule a combat action to method %q, it does not exist", func)
			end
		end
	end
	
	if not InCombatLockdown() then
		local success, err
		if type(method) == "function" then
			success, err = pcall(method, ...)
		elseif type(method) == "table" then
			local func = (...)
			success, err = pcall(method[func], method, select(2, ...))
		else
			success, err = pcall(self[method], self, ...)
		end
		if not success then geterrorhandler()(err:find("%.lua:%d+:") and err or (debugstack():match("(.-: )in.-\n") or "") .. err) end
		return
	end
	local t
	local n = select('#', ...)
	if style == "table" then
		t = new(select(2, ...))
		t.obj = method
		t.method = (...)
		t.n = n-1
	else
		t = new(...)
		t.n = n
		if style == "function" then
			t.func = method
		else
			t.method = method
		end
	end
	t.self = self
	table.insert(combatSchedules, t)
end

--- reembed routine
for target,_ in pairs(lib.mixinTargets) do
  lib:Embed(target)
end 
