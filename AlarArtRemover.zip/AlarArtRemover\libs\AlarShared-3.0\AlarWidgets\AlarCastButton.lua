local AWG=LibStub("AlarWidgets-3.0")
local AceGUI=AWG.AceGUI
local pp=AWG.pp
local InjectStandardMethods=AWG.InjectStandardMethods
do
    local Type="AlarCastButton"
    local Version=1
    local Serial =0
    local mx={}
	function mx.SetImage(self, path, ...)
		local image = self.image
		image:SetTexture(path)
		self.frame:SetPushedTexture(path)
		if image:GetTexture() then
			self.imageshown = true
			local n = select('#', ...)
			if n == 4 or n == 8 then
				image:SetTexCoord(...)
			end
		else
			self.imageshown = nil
		end
		return image:GetTexture()
	end	
    
   
    function mx.SetAttribute(self,attribute,valore)
    	   local attributes=self.userdata.attributes
    	   self.frame:SetAttribute(attribute,valore)
    end
    function mx.SetUnit(self,unit)
        self.unit=unit
        self:SetAttribute("unit",unit)
    end
	function mx.SetCast(self,type,spell,rank,button,checkselfcast)
	   self.type=type or "spell"
	   self.spell=spell
	   self.rank=rank or ""
	   this=self.frame
	   if (not spell) then
	       self:SetImage(nil)
	    else
	       local t
    	   if (self.type == "spell") then
    	       t=self:SetImage(GetSpellTexture(self.spell))
    	   elseif (self.type == "macro") then
    	       _,t=GetMacroInfo(self.spell)
    	       self:SetImage(t)
    	   end
    	   if (not t) then
    	       t="Interface\\Icons\\INV_Misc_QuestionMark"
        	    self:SetImage(t)
        	end
    	   if (button) then  -- minimal binding, only to be used in simple cases
    	       this:SetAttribute("type" .. button,type)
    	       this:SetAttribute(type .. button,spell)
    	    end
    	end
	end
    
	function mx.ApplyStatus(self)
		local status = self.status or self.localstatus
		local frame = self.frame
	end

	function mx.Acquire(self)
        proto.Acquire(self)
        self.userdata.attributes={}
	end
	local function Release(self)
	   self:SetImage(nil)
       local attributes=self.userdata.attributes
	   for k in pairs(attributes) do
	       self:SetAttribute(k,"")
	   end
	end
	function mx.UpdateCooldown(this)
        local c=this.obj.cooldown
        if (c) then
            pp(this.obj.spell)
            local start,duration,enable=GetSpellCooldown(this.obj.spell)
            if (start and duration) then
                CooldownFrame_SetTimer(c,start,duration,enable)
            end
        end
    end
    function mx.CheckRange(this)
        local spellname=this.obj.spell
        local unit=this.unit or "target"
        local icon=this.obj.image
        if (spellname) then
            if (SpellHasRange(spellname)) then
                if (IsSpellInRange(spellname,unit) == 0) then
    				icon:SetVertexColor(1.0, 0.1, 0.1);
    			elseif (IsUsableSpell(spellname)) then
        			icon:SetVertexColor(1.0, 1.0, 1.0);
                else
                    icon:SetVertexColor(0.1,0.1,1.0)
    			end
            end
        end
    end
    function mx._Constructor()
        Serial=Serial +1
        local name=Type .. "_" .. Version .. "_" .. Serial
        local frame=CreateFrame("CheckButton",name,UIParent,"SecureActionButtonTemplate,ActionButtonTemplate")
        local self={}
        InjectStandardMethods(self)
		self.SetCast=mx.SetCast
		self.SetImage=mx.SetImage
		self.SetUnit=mx.SetUnit
        self.frame=frame
        frame.obj=self
        frame:RegisterForClicks("AnyUp")
        frame:SetHeight(66)
        frame:SetWidth(66)
        frame:SetAttribute("useparent-unit", true);
        self.cooldown=getglobal(name .. "Cooldown")
        self.image=self.frame:GetNormalTexture()
        frame:SetScript("OnEnter",OnEnter)
        frame:SetScript("OnLeave",OnLeave)
        frame:SetScript("PostClick",UpdateCooldown)
        frame:SetScript("OnEvent",
            function(this,event)
                if (event == "ACTIONBAR_UPDATE_COOLDOWN") then
                    mx.UpdateCooldown(this)
                    this:SetChecked(false)
                end
            end
            )
        frame.rangetimer=0.5
        frame:SetScript("OnUpdate",
            function(this,elapsed)
        		this.rangetimer = this.rangetimer - elapsed;
        		if ( this.rangetimer <= 0 ) then
    			     mx.CheckRange(this)
    			     this.rangetimer=0.5
                end
    		end
    		)
        frame:RegisterEvent("ACTIONBAR_UPDATE_COOLDOWN")
        if (x and y) then
            b:SetPoint("TOPLEFT",x,y)
        end
		AceGUI:RegisterAsWidget(self)
        return self
    end
	AceGUI:RegisterWidgetType(Type,mx._Constructor,Version)
	AWG.widgets[Type]=Version    
end



