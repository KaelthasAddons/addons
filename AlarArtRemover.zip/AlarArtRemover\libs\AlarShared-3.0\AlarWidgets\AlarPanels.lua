local AWG=LibStub("AlarWidgets-3.0")
local AceGUI=AWG.AceGUI
local pp=AWG.pp
local InjectStandardMethods=AWG.InjectStandardMethods
do
-- Defining 2 kind of panels at the price of one :)
	local Version = 1
	local mx={}

	local FrameBackdrop = {
    	bgFile = "Interface\\Tooltips\\ChatBubble-Background",
    	edgeFile = "Interface\\Tooltips\\ChatBubble-BackDrop",
    	tile = true, tileSize = 32, edgeSize = 32,
    	insets = { left = 32, right = 32, top = 32, bottom = 32 }
    }
	local PaneBackdrop  = {
		bgFile = "Interface\\ChatFrame\\ChatFrameBackground",
		edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
		tile = true, tileSize = 16, edgeSize = 16,
		insets = { left = 3, right = 3, top = 5, bottom = 3 }
	}

	function mx.frameOnClose(this)
		this.obj:Fire("OnClose")
	end

	function mx.frameOnSizeChanged(this)
		local self = this.obj
		local status = self.status or self.localstatus
		status.width = this:GetWidth()
		status.height = this:GetHeight()
		status.top = this:GetTop()
		status.left = this:GetLeft()
	end
	
	function mx.closeOnClick(this)
	   this.obj:Fire("OnSave")
	   this.obj:Hide()
	end
	
	local function frameOnMouseDown(this)
		this:GetParent():StartMoving()
	end
	
	function mx.frameOnMouseUp(this)
		local frame = this:GetParent()
		frame:StopMovingOrSizing()
		local self = frame.obj
		local status = self.status or self.localstatus
		status.width = frame:GetWidth()
		status.height = frame:GetHeight()
		status.top = frame:GetTop()
		status.left = frame:GetLeft()
	end
	function mx.sizerseOnMouseDown(this)
	   this:GetParent():StartSizing("BOTTOMRIGHT")
	end
	
	function mx.sizersOnMouseDown(this)
	   this:GetParent():StartSizing("BOTTOM")
	end
	
	function mx.sizereOnMouseDown(this)
	   this:GetParent():StartSizing("RIGHT")
	end
	
	function mx.sizerOnMouseUp(this)
		this:GetParent():StopMovingOrSizing() 
	end
    -- Widget Methods

	function mx.SetBackdrop(self,backdrop)
	    if (type("backdrop" == "string")) then
	       self.frame:SetBackdrop(Backdrops[backdrop])
	    else
	       self.frame:SetBackdrop(backdrop)
	    end
	end
    function mx.SetTitle(self,title)
		self.titletext:SetText(title)
	end
	
	function mx.SetStatusText(self,text)
		self.statustext:SetText(text)
	end
	
	
	function mx.Show(self)
		self.frame:Show()
		self.xbutton:SetFrameLevel(99)
		self.xbutton:SetFrameStrata("HIGH")
	end
	
	function mx.Lock(self)
		local status = self.status or self.localstatus
		self.title:EnableMouse(not status.locked)
		self.sizer_e:EnableMouse(not status.locked)
		self.sizer_s:EnableMouse(not status.locked)
		self.sizer_se:EnableMouse(not status.locked)
	end
	
	function mx.ApplyStatus(self)
		local status = self.status or self.localstatus
		local frame = self.frame
		frame:SetWidth(status.width or 700)
		frame:SetHeight(status.height or 500)
		if status.top and status.left then
			frame:SetPoint("TOP",UIParent,"BOTTOM",0,status.top)
			frame:SetPoint("LEFT",UIParent,"LEFT",status.left,0)
		else
			frame:SetPoint("CENTER",UIParent,"CENTER")
		end
		self:Lock()
	end

	function mx.OnWidthSet(self, width)
		local content = self.content
		local contentwidth = width - 44
		if contentwidth < 0 then
			contentwidth = 0
		end
		content:SetWidth(contentwidth)
		content.width = contentwidth
	end
	
	
	function mx.OnHeightSet(self, height)
		local content = self.content
		local contentheight = height - 57
		if contentheight < 0 then
			contentheight = 0
		end
		content:SetHeight(contentheight)
		content.height = contentheight
	end
	

	function mx._Constructor(subtype)
		local frame = CreateFrame("Frame",nil,UIParent)
		local self = {}
		self.type = subtype
		InjectStandardMethods(self)
		self.Show = mxShow
		
		self.SetTitle =  mx.SetTitle
		--self.SetStatusText = SetStatusText
		self.ApplyStatus = mx.ApplyStatus
		self.OnWidthSet = mx.OnWidthSet
		self.OnHeightSet = mx.OnHeightSet
		
		self.localstatus = {}
		
		self.frame = frame
		frame.obj = self
		frame:SetWidth(700)
		frame:SetHeight(500)
		frame:SetPoint("CENTER",UIParent,"CENTER",0,0)
		frame:EnableMouse()
		frame:SetMovable(true)
		frame:SetResizable(true)
		frame:SetFrameStrata("FULLSCREEN_DIALOG")
		
		frame:SetBackdrop(FrameBackdrop)
		frame:SetBackdropColor(0,0,0,1)
		frame:SetScript("OnHide",mx.frameOnClose)
		frame:SetMinResize(400,200)
		frame:SetScript("OnSizeChanged", mx.frameOnSizeChanged)
		frame:SetToplevel(true)
		
		if (subtype=="AlarConfig") then
		
    		local closebutton = CreateFrame("Button",nil,frame,"UIPanelButtonTemplate")
    		closebutton:SetScript("OnClick", mx.closeOnClick)
    		closebutton:SetPoint("BOTTOMRIGHT",frame,"BOTTOMRIGHT",-27,17)
    		closebutton:SetHeight(20)
    		closebutton:SetWidth(100)
    		closebutton:SetText("Save")
    		
    		self.closebutton = closebutton
    		closebutton.obj = self
    		
    		local statusbg = CreateFrame("Frame",nil,frame)
    		statusbg:SetPoint("BOTTOMLEFT",frame,"BOTTOMLEFT",15,15)
    		statusbg:SetPoint("BOTTOMRIGHT",frame,"BOTTOMRIGHT",-132,15)
    		statusbg:SetHeight(24)
    		statusbg:SetBackdrop(PaneBackdrop)
    		statusbg:SetBackdropColor(0.1,0.1,0.1)
    		statusbg:SetBackdropBorderColor(0.4,0.4,0.4)
    		self.statusbg = statusbg
    		local statustext = statusbg:CreateFontString(nil,"OVERLAY","GameFontNormal")
    		self.statustext = statustext
    		statustext:SetPoint("TOPLEFT",statusbg,"TOPLEFT",7,-2)
    		statustext:SetPoint("BOTTOMRIGHT",statusbg,"BOTTOMRIGHT",-7,2)
    		statustext:SetHeight(20)
    		statustext:SetJustifyH("LEFT")
    		statustext:SetText("")
		end
		local title = CreateFrame("Frame",nil,frame)
		self.title = title
		title:EnableMouse()
		title:SetHeight(20)
		title:SetScript("OnMouseDown",mx.frameOnMouseDown)
		title:SetScript("OnMouseUp", mx.frameOnMouseUp)
        title:SetPoint("TOPLEFT",9,-6)
        title:SetPoint("TOPRIGHT",-9,-6)
        local ntexture=title:CreateTexture(nil,"ARTWORK")
        ntexture:SetTexture("Interface\\QuestFrame\\UI-QuestTitleHighlight")
        ntexture:SetVertexColor(1,0,0)
        ntexture:SetAllPoints(title)
        title.ntexture=ntexture
        local htexture=title:CreateTexture(nil,"HIGHLIGHT")
        htexture:SetTexture("Interface\\QuestFrame\\UI-QuestTitleHighlight")
        htexture:SetVertexColor(1,0,0)
        htexture:SetBlendMode("ADD")
        htexture:SetAllPoints(title)
        title.htexture=htexture

		local titletext = title:CreateFontString(nil,"OVERLAY","GameFontNormal")
		titletext:SetPoint("LEFT")
	
		self.titletext = titletext	
		

		local sizer_se = CreateFrame("Frame",nil,frame)
		sizer_se:SetPoint("BOTTOMRIGHT",frame,"BOTTOMRIGHT",0,0)
		sizer_se:SetWidth(25)
		sizer_se:SetHeight(25)
		sizer_se:EnableMouse()
		sizer_se:SetScript("OnMouseDown",mx.sizerseOnMouseDown)
		sizer_se:SetScript("OnMouseUp", mx.sizerOnMouseUp)
		self.sizer_se = sizer_se

		local line1 = sizer_se:CreateTexture(nil, "BACKGROUND")
		self.line1 = line1
		line1:SetWidth(14)
		line1:SetHeight(14)
		line1:SetPoint("BOTTOMRIGHT", -8, 8)
		line1:SetTexture("Interface\\Tooltips\\UI-Tooltip-Border")
		local x = 0.1 * 14/17
		line1:SetTexCoord(0.05 - x, 0.5, 0.05, 0.5 + x, 0.05, 0.5 - x, 0.5 + x, 0.5)
		local line1h = sizer_se:CreateTexture(nil, "HIGHLIGHT")
		self.line1h = line1h
		line1h:SetWidth(14)
		line1h:SetHeight(14)
		line1h:SetPoint("BOTTOMRIGHT", -8, 8)
		line1h:SetTexture("Interface\\Tooltips\\UI-Tooltip-Border")
		local x = 0.1 * 14/17
		line1h:SetTexCoord(0.05 - x, 0.5, 0.05, 0.5 + x, 0.05, 0.5 - x, 0.5 + x, 0.5)

		local line2 = sizer_se:CreateTexture(nil, "BACKGROUND")
		self.line2 = line2
		line2:SetWidth(8)
		line2:SetHeight(8)
		line2:SetPoint("BOTTOMRIGHT", -8, 8)
		line2:SetTexture("Interface\\Tooltips\\UI-Tooltip-Border")
		local x = 0.1 * 8/17
		line2:SetTexCoord(0.05 - x, 0.5, 0.05, 0.5 + x, 0.05, 0.5 - x, 0.5 + x, 0.5)
		local line2h = sizer_se:CreateTexture(nil, "HIGHLIGHT")
		self.line2h = line2h
		line2h:SetWidth(8)
		line2h:SetHeight(8)
		line2h:SetPoint("BOTTOMRIGHT", -8, 8)
		line2h:SetTexture("Interface\\Tooltips\\UI-Tooltip-Border")
		line2h:SetBlendMode("ADD")
		line2h:SetTexCoord(0.05 - x, 0.5, 0.05, 0.5 + x, 0.05, 0.5 - x, 0.5 + x, 0.5)

		local sizer_s = CreateFrame("Frame",nil,frame)
		sizer_s:SetPoint("BOTTOMRIGHT",frame,"BOTTOMRIGHT",-25,0)
		sizer_s:SetPoint("BOTTOMLEFT",frame,"BOTTOMLEFT",0,0)
		sizer_s:SetHeight(25)
		sizer_s:EnableMouse()
		sizer_s:SetScript("OnMouseDown",mx.sizersOnMouseDown)
		sizer_s:SetScript("OnMouseUp", mx.sizerOnMouseUp)
		local sizer_sh=sizer_s:CreateTexture(nil,"HIGHLIGHT")
        sizer_sh:SetTexture("Interface\\QuestFrame\\UI-QuestTitleHighlight")
        sizer_sh:SetPoint("BOTTOMLEFT",32,0)
        sizer_sh:SetPoint("BOTTOMRIGHT")
        sizer_sh:SetHeight(5)
		self.sizer_s = sizer_s
		
		local sizer_e = CreateFrame("Frame",nil,frame)
		sizer_e:SetPoint("BOTTOMRIGHT",frame,"BOTTOMRIGHT",0,25)
		sizer_e:SetPoint("TOPRIGHT",frame,"TOPRIGHT",0,0)
		sizer_e:SetWidth(25)
		sizer_e:EnableMouse()
		sizer_e:SetScript("OnMouseDown",mx.sizereOnMouseDown)
		sizer_e:SetScript("OnMouseUp", mx.sizerOnMouseUp)
		local sizer_eh=sizer_e:CreateTexture(nil,"HIGHLIGHT")
        sizer_eh:SetTexture("Interface\\QuestFrame\\UI-QuestTitleHighlight")
        local angle = math.rad(90)
        local cos, sin = math.cos(angle), math.sin(angle)
        sizer_eh:SetTexCoord((sin - cos), -(cos + sin), -cos, -sin, sin, -cos, 0, 0)
        sizer_eh:SetPoint("TOPRIGHT",0,-32)
        sizer_eh:SetPoint("BOTTOMRIGHT")
        sizer_eh:SetWidth(5)
        self.sizer_e = sizer_e

        local xbutton=CreateFrame("Button",nil,frame,"UIPanelCloseButton")
		xbutton:SetPoint("TOPRIGHT",0,0)
		xbutton:SetFrameLevel(99)
		self.xbutton=xbutton
		xbutton.obj=self
	
		--Container Support
		local content = CreateFrame("Frame",nil,frame)
		self.content = content
		content.obj = self
		content:SetPoint("TOPLEFT",frame,"TOPLEFT",17,-27)
		content:SetPoint("BOTTOMRIGHT",frame,"BOTTOMRIGHT",-17,40)
		
		AceGUI:RegisterAsContainer(self)
		return self	
	end

	AceGUI:RegisterWidgetType("AlarPanel",function(...) return mx._Constructor("AlarPanel") end,Version)
	AWG.widgets.AlarPanel=Version
	AceGUI:RegisterWidgetType("AlarConfig",function(...) return mx._Constructor("AlarConfig") end,Version)
	AWG.widgets.AlarConfig=Version
end

