﻿-- WoWEquip
-- frFR Localisation file
-- Note: The english localization file must be loaded before this file.

if ( GetLocale() ~= "frFR" ) then
	return;
end

WoWEquip_Localization = setmetatable({
	-- Text used in various frames and buttons
	WOW_EQUIP_SLASH_COMMAND		= "/wowequip";
	WOW_EQUIP_VERSION_TEXT		= "WoWEquip v0.92";


	-- Talent tree names
	-- Druid
	["Balance"] = "Equilibre",
	["Feral Combat"] = "Combat farouche",
	["Restoration"] = "Restauration",
	-- Hunter
	["Beast Mastery"] = "Maîtrise des bêtes",
	["Marksmanship"] = "Précision",
	["Survival"] = "Survie",
	-- Mage
	["Arcane"] = "Arcane",
	["Fire"] = "Feu",
	["Frost"] = "Givre",
	-- Paladin
	["Holy"] = "Sacré",
	["Protection"] = "Protection",
	["Retribution"] = "Vindicte",
	-- Priest
	["Discipline"] = "Discipline",
	-- ["Holy"] = "Sacré", -- same as Paladin
	["Shadow"] = "Ombre",
	-- Rogue
	["Assassination"] = "Assassinat",
	["Combat"] = "Combat",
	["Subtlety"] = "Finesse",
	-- Shaman
	["Elemental"] = "Elémentaire",
	["Enhancement"] = "Amélioration",
	-- ["Restoration"] = "Restauration", -- same as Druid
	-- Warrior
	["Arms"] = "Armes",
	["Fury"] = "Fureur",
	-- ["Protection"] = true, -- same as Paladin
	-- Warlock
	["Affliction"] = "Affliction",
	["Demonology"] = "Démonologie",
	["Destruction"] = "Destruction",

	-- The following strings are used for tooltip parsing
	WOW_EQUIP_ITEM_SOCKET_BONUS_R		= "Bonus de sertissage\194\160: .*",	-- Deformatting version of ITEM_SOCKET_BONUS = "Bonus de sertissage\194\160: %s"
	WOW_EQUIP_ITEM_SET_NAME_R		= "(.*) %(%d/(%d)%)",	-- Deformatting version of ITEM_SET_NAME = "%s (%d/%d)" to get the setname and setsize -- Set name (2/5)

	-- The following strings are the localized return values from GetItemInfo() for itemType and are used for parsing
	WOW_EQUIP_ITEMTYPE_ARMOR		= "Armure",
	WOW_EQUIP_ITEMTYPE_WEAPON		= "Arme",

	-- The following strings are the localized return values from GetItemInfo() for itemSubType and are used for parsing
	WOW_EQUIP_ITEMSUBTYPE_CLOTH		= "Tissu",
	WOW_EQUIP_ITEMSUBTYPE_LEATHER		= "Cuir",
	WOW_EQUIP_ITEMSUBTYPE_MAIL		= "Mailles",
	WOW_EQUIP_ITEMSUBTYPE_PLATE		= "Plaques",
	WOW_EQUIP_ITEMSUBTYPE_DAGGERS		= "Dagues",
	WOW_EQUIP_ITEMSUBTYPE_FISTWEAPONS	= "Armes de pugilat",
	WOW_EQUIP_ITEMSUBTYPE_1HAXES		= "Haches \195\160 une main",
	WOW_EQUIP_ITEMSUBTYPE_1HMACES		= "Maces \195\160 une main",
	WOW_EQUIP_ITEMSUBTYPE_1HSWORDS		= "Ep\195\169es \195\160 une main",
	WOW_EQUIP_ITEMSUBTYPE_FISHINGPOLE	= "Canne \195\160 p\195\170che",
	WOW_EQUIP_ITEMSUBTYPE_POLEARMS		= "Armes d'hast",
	WOW_EQUIP_ITEMSUBTYPE_STAVES		= "B\195\162tons",
	WOW_EQUIP_ITEMSUBTYPE_2HAXES		= "Haches \195\160 deux mains",
	WOW_EQUIP_ITEMSUBTYPE_2HMACES		= "Maces \195\160 deux mains",
	WOW_EQUIP_ITEMSUBTYPE_2HSWORDS		= "Ep\195\169es \195\160 deux mains",
	WOW_EQUIP_ITEMSUBTYPE_SHIELDS		= "Boucliers",
	WOW_EQUIP_ITEMSUBTYPE_MISC		= "Divers",
	WOW_EQUIP_ITEMSUBTYPE_BOWS		= "Arcs",
	WOW_EQUIP_ITEMSUBTYPE_CROSSBOWS		= "Arbal\195\168tes",
	WOW_EQUIP_ITEMSUBTYPE_GUNS		= "Fusils",
	WOW_EQUIP_ITEMSUBTYPE_THROWN		= "Armes de jet",
	WOW_EQUIP_ITEMSUBTYPE_WANDS		= "Baguettes",
	WOW_EQUIP_ITEMSUBTYPE_IDOLS		= "Idoles",
	WOW_EQUIP_ITEMSUBTYPE_LIBRAMS		= "Librams",
	WOW_EQUIP_ITEMSUBTYPE_TOTEMS		= "Totems",

}, {__index = WoWEquip_Localization})
