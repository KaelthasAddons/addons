--[[
    Data miner for all minipets and mounts
    $Revision: 88 $
]]--

--[[
Copyright (c) 2008, LordFarlander
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

    * Redistributions of source code must retain the above copyright notice,
      this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright notice,
      this list of conditions and the following disclaimer in the documentation
      and/or other materials provided with the distribution.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
]]--

local http = require( "socket.http" );
local lastRequest = nil;

persistence =
{
	store = function (path, ...)
		local f, e = io.open(path, "w");
		if f then
			f:write("-- Persistent Data\n");
			f:write("return ");
			persistence.write(f, select(1,...), 0);
			for i = 2, select("#", ...) do
				f:write(",\n");
				persistence.write(f, select(i,...), 0);
			end;
			f:write("\n");
		else
			error(e);
		end;
		f:close();
	end;
	
	load = function (path)
		local f, e = loadfile(path);
		if f then
			return f();
		else
			return nil, e;
			--error(e);
		end;
	end;
	
	write = function (f, item, level)
		local t = type(item);
		persistence.writers[t](f, item, level);
	end;
	
	writeIndent = function (f, level)
		for i = 1, level do
			f:write("\t");
		end;
	end;
	
	writers = {
		["nil"] = function (f, item, level)
				f:write("nil");
			end;
		["number"] = function (f, item, level)
				f:write(tostring(item));
			end;
		["string"] = function (f, item, level)
				f:write(string.format("%q", item));
			end;
		["boolean"] = function (f, item, level)
				if item then
					f:write("true");
				else
					f:write("false");
				end
			end;
		["table"] = function (f, item, level)
				f:write("{\n");
				for k, v in pairs(item) do
					persistence.writeIndent(f, level+1);
					f:write("[");
					persistence.write(f, k, level+1);
					f:write("] = ");
					persistence.write(f, v, level+1);
					f:write(";\n");
				end
				persistence.writeIndent(f, level);
				f:write("}");
			end;
		["function"] = function (f, item, level)
				-- Does only work for "normal" functions, not those
				-- with upvalues or c functions
				local dInfo = debug.getinfo(item, "uS");
				if dInfo.nups > 0 then
					f:write("nil -- functions with upvalue not supported\n");
				elseif dInfo.what ~= "Lua" then
					f:write("nil -- function is not a lua function\n");
				else
					local r, s = pcall(string.dump,item);
					if r then
						f:write(string.format("loadstring(%q)", s));
					else
						f:write("nil -- function could not be dumped\n");
					end
				end
			end;
		["thread"] = function (f, item, level)
				f:write("nil --thread\n");
			end;
		["userdata"] = function (f, item, level)
				f:write("nil --userdata\n");
			end;
	}
}

function sleep( milliseconds )
--     local start = os.time();
--     local currenttime = os.time();
-- 
--     while os.difftime( currenttime, start ) < milliseconds / 1000.0 do
--         currenttime = os.time();
--     end--while
end--sleep( milliseconds )

function GetPage( url )
    local currenttime = os.time();

    if( lastRequest ) then
        if( os.difftime( currenttime, lastRequest ) < 1.0 ) then
            sleep( 1000.0 - os.difftime( currenttime, lastRequest ) * 1000.0 );
        end--if
    end--if
    lastRequest = os.time();
    return http.request( url );
end--GetPage( url )

function ProcessMount( mount )
    if( not mount.Speed ) then
        mount.Speed = 0;
        mount.Riding = 0;
        mount.Type = "Ground";
        mount.Subtype = "Slow";
    end--if
    if( not mount.Riding ) then
        mount.Riding = 0;
    end--if
    if( mount.Passengers ) then
        if( mount.Type ~= "Passenger" ) then
            mount.Subtype2 = mount.Subtype;
            mount.Subtype = mount.Type;
            mount.Type = "Passenger";
        end--if
        mount.Value = ("%i|%i|%i"):format( mount.Speed, mount.Riding, mount.Passengers );
    else
        mount.Value = ("%i|%i"):format( mount.Speed, mount.Riding );
    end--if
end--ProcessMount( mount )

function ProcessCritter( critter )
    if( not critter.Type ) then
        critter.Type = "Normal";
    end--if
    if( critter.InventorySlot ) then
        critter.Type = "Equipment";
        if( critter.InventorySlot == "HEADSLOT" ) then
            critter.Subtype = "Head";
        end--if
        critter.Value = critter.InventorySlot;
    end--if
end--ProcessCritter( critter )

local HEADER = "--\[\[\n"..
    "    Database of all minipets and mounts\n"..
    "    $Revision: 88 $\n"..
    "\]\]--"..
    "\n"..
    "\n"..
    "--\[\[\nCopyright (c) 2008, LordFarlander\n"..
    "All rights reserved.\n"..
    "\n"..
    "Redistribution and use in source and binary forms, with or without\n"..
    "modification, are permitted provided that the following conditions are met:\n"..
    "\n"..
    "    * Redistributions of source code must retain the above copyright notice,\n"..
    "      this list of conditions and the following disclaimer.\n"..
    "    * Redistributions in binary form must reproduce the above copyright notice,\n"..
    "      this list of conditions and the following disclaimer in the documentation\n"..
    "      and/or other materials provided with the distribution.\n"..
    "\n"..
    "THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS \"AS IS\" AND\n"..
    "ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED\n"..
    "WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE\n"..
    "DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR\n"..
    "ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES\n"..
    "(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;\n"..
    "LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON\n"..
    "ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT\n"..
    "(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS\n"..
    "SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.\n"..
    "\]\]--\n"..
    "\n"..
    "if( not LibStub( \"LibPeriodicTable-3.1\", true ) ) then\n    error( \"PT3 must be loaded before data\" );\nend--if\n";

local data = persistence.load( "datacache.lua" ) or { database = {}, };
local reverseLookup = {};
local urlLists = {
    Critters = {
        Spells = { "http://wotlk.wowhead.com/?spells=-6", },
        Items = { "http://wotlk.wowhead.com/?items=15.2", },
        Process = ProcessCritter,
    }, --Critters
    Mounts = {
        Spells = { "http://wotlk.wowhead.com/?spells=-5", },
        Items = { "http://wotlk.wowhead.com/?items=15.5", "http://wotlk.wowhead.com/?items=15.-7", },
        Process = ProcessMount,
    }, --Mounts
};
local compatibleCollections = {};
local convert = {};
local collections = {};
--local compatiblityVersion = 20000;
local latestVersion = 30000;
local prebuilt =  {
    ["PetAndMountDatabase.Critters.Children"] = "31880,31881,18598,18597",
--    ["PetAndMountDatabase.Critters.Equipment.Head"] = "12185:HEADSLOT,38506:HEADSLOT",
    ["PetAndMountDatabase.Critters.Quest"] = "30803:10629,34253:11516",
    ["PetAndMountDatabase.Mounts.Ground.Fast.Paladin.Alliance"] = "-13819:60|75",
    ["PetAndMountDatabase.Mounts.Ground.Fast.Paladin.Horde"] = "-34769:60|75",
    ["PetAndMountDatabase.Mounts.Ground.Fast.Warlock"] = "-5784:60|75",
    ["PetAndMountDatabase.Mounts.Ground.VeryFast.Deathknight"] = "-48778:100|75",
    ["PetAndMountDatabase.Mounts.Ground.VeryFast.Paladin.Alliance"] = "-23214:100|150",
    ["PetAndMountDatabase.Mounts.Ground.VeryFast.Paladin.Horde"] = "-34767:100|150",
    ["PetAndMountDatabase.Mounts.Ground.VeryFast.Warlock"] = "-23161:100|150",
    ["PetAndMountDatabase.Items.MountEnchant"] = "21212,37750,37816,21213",
    ["PetAndMountDatabase.Items.CritterEnchant"] = "37460,35223,37431",
    ["PetAndMountDatabase.Spells.Teleport.Druid"] = "-18960",
    ["PetAndMountDatabase.Spells.Teleport.Items"] = "-54406:40585|40586,-8690:6948,-46149:35230,-39937:28585",
    ["PetAndMountDatabase.Spells.Teleport.Items.Engineering.Gnomish"] = "-23452:18986,-30544:30544",
    ["PetAndMountDatabase.Spells.Teleport.Items.Engineering.Goblin"] = "-36890:30542,-23442:18984",
    ["PetAndMountDatabase.Spells.Teleport.Mage"] = "-53140",
    ["PetAndMountDatabase.Spells.Teleport.Mage.Alliance"] = "-49359,-33690,-32271,-3561,-3565,-3562",
    ["PetAndMountDatabase.Spells.Teleport.Mage.Horde"] = "-3566,-3567,-35715,-32272,-3563,-49358",
    ["PetAndMountDatabase.Spells.Teleport.Shaman"] = "-556",
    ["PetAndMountDatabase.Spells.Teleport.Translocate"] = "-35727,-30141,-35730,-25649,-25650,-25666,-25140,-25652,-25143,-32568,-35376,-29128,-29129,-26572,-32571,-32572,-45371,-45368,-32569",
    ["PetAndMountDatabase.Spells.Travel.Aquatic.Druid"] = "-1066:50",
    ["PetAndMountDatabase.Spells.Travel.Flying.Druid"] = "-33943:60,-40120:280",
    ["PetAndMountDatabase.Spells.Travel.Ground.Druid"] = "-783:40",
    ["PetAndMountDatabase.Spells.Travel.Ground.Hunter"] = "-5118:30,-13159:30",
    ["PetAndMountDatabase.Spells.Travel.Ground.Shaman"] = "-2645:40",
    ["PetAndMountDatabase.MiniPets.Children"] = "m,PetAndMountDatabase.Critters.Children",
    ["PetAndMountDatabase.MiniPets.Equipment.Head"] = "m,PetAndMountDatabase.Critters.Equipment.Head",
    ["PetAndMountDatabase.MiniPets.Normal"] = "m,PetAndMountDatabase.Critters.Normal",
    ["PetAndMountDatabase.MiniPets.Quest"] = "m,PetAndMountDatabase.Critters.Quest",
    ["PetAndMountDatabase.MiniPets.Reagented.Snowball"] = "m,PetAndMountDatabase.Critters.Reagented.Snowball",
    ["PetAndMountDatabase.TempleOfAhnQiraj.Mounts"] = "-25863:100|150,-26655:100|150,-26656:100|150,21324:100|75,21321:100|75,21323:100|75,-31700:100|150,21218:100|75",
};

function GetMountSpeed( page, mount )
    local speed = page:match( "%[Apply Aura%]: Mod Speed Mounted Flight<small><br />Value: (%d+)</small>" );
    local flying = page:find( "[Cc]an only be [%w]+ed in [%w%s]+." );

    mount.Passengers = page:match( "can carry (%d+) passengers" ) or ( ( page:match( "complete with two buddies[%.!]" ) or page:match( "Allows two passengers to board." ) ) and 3 ) or ( page:match( "%[Summon%]&nbsp;%(<a href=\"/%?npc=%d+\">%d+</a>%)<small><br />Value: %d+</small>" ) and 2 );
    if( mount.Passengers ) then
        mount.Passengers = tonumber( mount.Passengers );
    end--if
    if( flying or speed ) then
        --Flying Mount
        if( not speed ) then
            speed = ( page:match( "This is an extremely fast [%w%s]+[%.!]" ) and 310 ) or ( page:match( "This is a very fast [%w%s]+[%.!]" ) and 280 ) or ( page:match( "This is a fast [%w%s]+[%.!]" ) and 60 );
        end--if
        if( speed ) then
            speed = tonumber( speed );
            mount.Type = "Flying";
            mount.Speed = speed;
            if( speed == 310 ) then
                mount.Subtype = "ExtremelyFast";
            elseif( speed == 280 ) then
                mount.Subtype = "VeryFast";
            else
                mount.Subtype = "Fast";
            end--if
        else
            if( page:find( "This [%w%s]- changes speed depending on your Riding skill." ) ) then
                if( page:find( "Increases flight speed" ) ) then
                    mount.Type = "Variable";
                    mount.Subtype = "Flying";
                    mount.Speed = -1;
                end--if
            end--if
        end--if
    else
        speed = page:match( "%[Apply Aura%]: Mod Speed Mounted<small><br />Value: (%d+)</small>" );

        if( not speed ) then
            speed = ( page:match( "This is a very fast [%w%s]+[%.!]" ) and 100 ) or ( page:match( "This is a fast [%w%s]+[%.!]" ) and 60 );
        end--if
        if( speed ) then
            --Ground Mount
            speed = tonumber( speed );
            mount.Type = "Ground";
            mount.Speed = speed;
            if( speed == 100 ) then
                mount.Subtype = "VeryFast";
            elseif( speed == 60 ) then
                mount.Subtype = "Fast";
            else
                mount.Subtype = "Slow";
            end--if
        else
            if( page:find( "This [%w%s]- changes speed depending on your Riding skill." ) ) then
                if( page:find( "Increases flight speed" ) ) then
                    mount.Type = "Variable";
                    mount.Subtype = "Flying";
                    mount.Speed = -1;
                else
                    mount.Type = "Variable";
                    mount.Subtype = "Ground";
                    mount.Speed = -1;
                end--if
                mount.Riding = 1;
            elseif( page:find( "This [%w%s]+ changes depending on your Riding skill and location." ) ) then
                mount.Type = "Variable";
                mount.Subtype = "All";
                mount.Speed = -1;
            end--if
        end--if
    end--if
    if( not mount.Speed ) then
        mount.Passengers = nil;
    end--if
end--GetMountSpeed( page, mount )

function ReagentedCheck( page, item )
    local reagent, name = page:match( "Reagents: .-<a href=\"/%?item=(%d+)\">(.-)</a>" );
    
    if( reagent ) then
        item.Type = "Reagented";
        item.Subtype = name;
        item.Value = reagent;
    end--if
end--ReagentedCheck( page, item )

function IgnoreSpell( page )
    return page:find( "Summons a .+ that will protect you for %d+ min." ) or page:find( "Summons a .+ to your aid for %d+ sec." );
end--IngnoreSpell( page )

function ProcessSpellList( url, dest )
    local page = GetPage( url );

    if( page ) then
        for spellID, name in page:gmatch( "<a href=\"/%?spell=(%d+)\">(.-)</a>" ) do
            spellID = tonumber( spellID );
            if( not dest[spellID] ) then
                page = GetPage( ("http://wotlk.wowhead.com/?spell=%i"):format( spellID ) );
                if( page ) then
                    if( not IgnoreSpell( page ) ) then
                        print( ("Found spell %s (%i)!"):format( name, spellID ) );
                        dest[spellID] = { Spell = spellID, SpellName = name, };                
                        GetMountSpeed( page, dest[spellID] );
                        ReagentedCheck( page, dest[spellID] );
                        for teaches, data in page:gmatch( "%({template: 'item', id: '(%l+)%-by%-item', name: LANG%.tab_%l+, tabs: tabsRelated, parent: 'lkljbjkb574', data: %[(.+)%]}%);" ) do
                            data = data .. ",";
                            for itemID, itemName, slot in data:gmatch( "{id:(%d+),name:'%d(.-)',.-,slot:(%d+),.-}," ) do
                                slot = tonumber( slot );
                                itemID = tonumber( itemID );
                                itemName = itemName:gsub( "\\", "" );
                                print( ("Found item %s [%s] for %s [%i]!"):format( itemName, itemID, name, spellID ) );
                                dest[spellID].ItemName = itemName;
                                dest[spellID].Item = itemID;
                                if( slot ~= 0 ) then
                                    if( slot == 1 ) then
                                        dest[spellID].InventorySlot = "HEADSLOT";
                                    end--if
                                end--if
                                if( teaches == "taught" ) then
                                    dest[spellID].Taught = true;
                                end--if
                                page = GetPage( ("http://wotlk.wowhead.com/?item=%i"):format( itemID ) );
                                if( page ) then
                                    dest[spellID].Riding = page:match( "Requires <a href=\"/%?spells=9%.762\" class=\"q1\">Riding</a> %((%d+)%)" );
                                    if( dest[spellID].Riding ) then
                                        dest[spellID].Riding = tonumber( dest[spellID].Riding );
                                    end--if
                                end--if
                            end--for
                        end--if
                        if( dest[spellID].Item ) then
                            reverseLookup[dest[spellID].Item] = spellID;
                        end--if
                        if( dest[spellID].Item1 ) then
                            reverseLookup[dest[spellID].Item1] = spellID;
                        end--if                        
                    end--if
                end--if
            end--if
        end--for
    else
        print( ("Could not open url %s"):format( url ) );
    end--if
end--ProcessSpellList( url, dest )

function ProcessItemsList( url, dest )
    local page = GetPage( url );

    if( page ) then
        for itemID, name in page:gmatch( "<a href=\"/%?item=(%d+)\">(.-)</a>" ) do
            itemID = tonumber( itemID );
            if( not reverseLookup[itemID] ) then
                local itemName = name;

                page = GetPage( ("http://wotlk.wowhead.com/?item=%i"):format( itemID ) );
                if( page ) then
                    local riding = page:match( "Requires <a href=\"/%?spells=9%.762\" class=\"q1\">Riding</a> %((%d+)%)" );
                    local spellID = page:match ( "{template: 'spell', id: 'teaches%-ability', name: LANG%.tab_teaches, tabs: tabsRelated, parent: '[%w]+', visibleCols: %['level', 'school'%], data: %[{id:(%d+)," );
                    local taught = nil;

                    if( not spellID ) then
                        spellID = page:match ( "<a href=\"/%?spell=(%d+)\" class=\"q2\">" );
                    else
                        taught = true;
                    end--if
                    if( not spellID ) then
                        --check the live server
                        page = GetPage( ("http://www.wowhead.com/?item=%i"):format( itemID ) );
                        if( page ) then
                            spellID = page:match ( "<a href=\"/%?spell=(%d+)\" class=\"q2\">" );
                        end--if
                    end--if
                    if( spellID ) then
                        spellID = tonumber( spellID );
                        page = GetPage( ("http://wotlk.wowhead.com/?spell=%i"):format( spellID ) );
                        if( page ) then
                            if( not IgnoreSpell( page ) ) then
                                name = page:match( "<title>(.+) %- Spell %- World of Warcraft</title>" ) or name;
                                if( not dest[spellID] ) then
                                    dest[spellID] = { Spell = spellID, SpellName = name, Taught = taught };
                                    GetMountSpeed( page, dest[spellID] );
                                    ReagentedCheck( page, dest[spellID] );
                                    for teaches, data in page:gmatch( "%({template: 'item', id: '(%l+)%-by%-item', name: LANG%.tab_%l+, tabs: tabsRelated, parent: 'lkljbjkb574', data: %[(.+)%]}%);" ) do
                                        data = data .. ",";
                                        for itemID, itemName, slot in data:gmatch( "{id:(%d+),name:'%d(.-)',.-,slot:(%d+),.-}," ) do
                                            itemID = tonumber( itemID );
                                            slot = tonumber( slot );
                                            itemName = itemName:gsub( "\\", "" );
                                            if( teaches == "taught" ) then
                                                dest[spellID].Taught = true;
                                            end--if
                                            if( slot ~= 0 ) then
                                                if( slot == 1 ) then
                                                    dest[spellID].InventorySlot = "HEADSLOT";
                                                end--if
                                            end--if
                                            print( ("Found item %s [%i] for %s [%i]!"):format( itemName, itemID, name, spellID ) );
                                            if( dest[spellID].Item ) then
                                                dest[spellID].Item1 = itemID;
                                            else
                                                dest[spellID].Item = itemID;
                                            end--if
                                        end--for
                                    end--if
                                end--if
                                dest[spellID].ItemName = itemName;
                                if( riding and ( not dest[spellID].Riding ) ) then
                                    dest[spellID].Riding = tonumber( riding );
                                end--if
                                reverseLookup[itemID] = spellID;                                
                            end--if
                        end--if
                    end--if
                end--if
            end--if
        end--for
    else
        print( ("Could not open url %s"):format( url ) );
    end--if
end--ProcessSpellList( url, dest )

for major, sets in pairs( data.database ) do
    for name, id in pairs( sets ) do
        if( id.Item ) then
            reverseLookup[id.Item] = id.Spell;
        end--if
    end--for
end--for
for major, subs in pairs( urlLists ) do
    if( not data.database[major] ) then
        data.database[major] = {};
    end--if
    for _, url in pairs( subs.Spells ) do
        print( ("\nLooking for %s spells..."):format( major ) );
        ProcessSpellList( url, data.database[major] );
    end--for
    for _, url in pairs( subs.Items ) do
        print( ("\nLooking for %s items..."):format( major ) );
        ProcessItemsList( url, data.database[major] );
    end--for
end--for

for major, sets in pairs( data.database ) do
    for name, id in pairs( sets ) do
        urlLists[major].Process( id );

        if( id.Item and not( id.Ignore ) ) then
            local collection = ("%s%s%s%s"):format( major, id.Type and (".%s"):format( id.Type ) or "", id.Subtype and (".%s"):format( id.Subtype ) or "", id.Subtype2 and (".%s"):format( id.Subtype2 ) or "" );
            local idUse = id.Taught and id.Spell * -1 or id.Item;

            if( not convert[major] ) then
                convert[major] = {};
            end--if
            convert[major][id.Spell] = id;
            if( collections[collection] ) then
                if( id.Value ) then
                    collections[collection] = ("%s,%i:%s"):format( collections[collection], idUse, id.Value );
                else
                    collections[collection] = ("%s,%i"):format( collections[collection], idUse );
                end--if
            else
                if( id.Value ) then
                    collections[collection] = ("%i:%s"):format( idUse, id.Value );
                else
                    collections[collection] = ("%i"):format( idUse );
                end--if
            end--if
            if( compatiblityVersion and id.Item ) then
                if( compatibleCollections[collection] ) then
                    if( id.Value ) then
                        compatibleCollections[collection] = ("%s,%i:%s"):format( compatibleCollections[collection], idUse, id.Value );
                    else
                        compatibleCollections[collection] = ("%s,%i"):format( compatibleCollections[collection], idUse1 );
                    end--if
                else
                    if( id.Value ) then
                        compatibleCollections[collection] = ("%i:%s"):format( idUse, id.Value );
                    else
                        compatibleCollections[collection] = ("%i"):format( idUse );
                    end--if
                end--if        
            end--if
        end--if
    end--for
end--for

print( "\nWriting database to file..." );

persistence.store( "datacache.lua", data );

local hFile = io.open( "LibPeriodicTable-3.1-PetAndMountDatabase.lua", "w+" );

if( hFile == nil ) then
    return;
end--if

hFile:write( HEADER );
if( compatiblityVersion ) then
    hFile:write( ("if( tonumber( select( 4, GetBuildInfo() ) ) < %i ) then\n"):format( latestVersion ) );
    hFile:write( "    LibStub( \"LibPeriodicTable-3.1\" ):AddData( \"PetAndMountDatabase\", tonumber( (\"$Rev: 88 $\"):match( \"%d+\" ) ) + 90000, {\n" );
    for setName, set in pairs( compatibleCollections ) do
        hFile:write( ("        [\"PetAndMountDatabase.%s\"] = %q,\n"):format( setName, set ) );
    end--for
    for setName, set in pairs( prebuilt ) do
        hFile:write( ("        [%q] = %q,\n"):format( setName, set ) );
    end--for
    hFile:write( "    } );\nelse\n" );
end--if
hFile:write( "    LibStub( \"LibPeriodicTable-3.1\" ):AddData( \"PetAndMountDatabase\", tostring( tonumber( (\"$Rev: 88 $\"):match( \"%d+\" ) ) + 90000 ), {\n" );
for setName, set in pairs( collections ) do
    hFile:write( ("        [\"PetAndMountDatabase.%s\"] = %q,\n"):format( setName, set ) );
end--for
for major, sets in pairs( convert ) do
    local writestring;

    for _, id in pairs( sets ) do
        if( id.Spell and ( not id.Ignore ) ) then
            if( writestring ) then
                writestring = ("%s,%i:%i"):format( writestring, id.Item, id.Spell * -1 );
            else
                writestring = ("%i:%i"):format( id.Item, id.Spell * -1 );
            end--if
            if( id.Item1 ) then
                if( writestring ) then
                    writestring = ("%s,%i:%i"):format( writestring, id.Item1, id.Spell * -1 );
                else
                    writestring = ("%i:%i"):format( id.Item1, id.Spell * -1 );
                end--if
            end--if
        end--if
    end--for
    hFile:write( ("        [\"PetAndMountDatabase.Conversion.%s\"] = %q,\n"):format( major, writestring ) );
end--for
for setName, set in pairs( prebuilt ) do
    hFile:write( ("        [%q] = %q,\n"):format( setName, set ) );
end--for
hFile:write( "    } );\n" );
if( compatiblityVersion ) then
    hFile:write( "end--if\n" );
end--if
hFile:close();

--tempdebug
-- local expanded = {}
-- for major, sets in pairs( data.database ) do
--     if( not expanded[major] ) then
--         expanded[major] = {};
--     end--if
--     for name, id in pairs( sets ) do
--         if( id.Spell and id.Item and ( not id.Ignore ) ) then
--             local putinto = nil;
--             local ids = id.Spell * -1;
--     
--             if( not id.Taught and id.Item ) then
--                 ids = id.Item;
--             end--if
--             if( not expanded[major][id.Type] ) then
--                 expanded[major][id.Type] = {};
--             end--if
--             putinto = expanded[major][id.Type];
--             if( id.Subtype ) then
--                 if( not expanded[major][id.Type][id.Subtype] ) then
--                     expanded[major][id.Type][id.Subtype] = {};
--                 end--if
--                 putinto = expanded[major][id.Type][id.Subtype];
--             end--if
--             if( id.Subtype1 ) then
--                 if( not expanded[major][id.Type][id.Subtype][id.Subtype1] ) then
--                     expanded[major][id.Type][id.Subtype][id.Subtype1] = {};
--                 end--if
--                 putinto = expanded[major][id.Type][id.Subtype][id.Subtype1];
--             end--if
--             putinto[ids] = { value = id.Value, name = id.SpellName };
--         end--if
--     end--for
-- end--for
-- 
-- persistence.store( "debug.lua", expanded );