-- Persistent Data
return {
	["database"] = {
		["Mounts"] = {
			[44744] = {
				["ItemName"] = "Merciless Nether Drake";
				["Subtype"] = "ExtremelyFast";
				["Spell"] = 44744;
				["Type"] = "Flying";
				["Item"] = 34092;
				["Value"] = "310|300";
				["Taught"] = true;
				["Speed"] = 310;
				["Riding"] = 300;
				["SpellName"] = "Merciless Nether Drake";
			};
			[59797] = {
				["Spell"] = 59797;
				["Subtype"] = "VeryFast";
				["ItemName"] = "Reins of the Ice Mammoth";
				["Type"] = "Ground";
				["Item"] = 44080;
				["Value"] = "100|150";
				["Speed"] = 100;
				["Taught"] = true;
				["Riding"] = 150;
				["SpellName"] = "Ice Mammoth";
			};
			[23221] = {
				["Spell"] = 23221;
				["Subtype"] = "VeryFast";
				["ItemName"] = "Reins of the Swift Frostsaber";
				["Type"] = "Ground";
				["Item"] = 18766;
				["Value"] = "100|150";
				["Speed"] = 100;
				["Taught"] = true;
				["Riding"] = 150;
				["SpellName"] = "Swift Frostsaber";
			};
			[23225] = {
				["Spell"] = 23225;
				["Subtype"] = "VeryFast";
				["ItemName"] = "Swift Green Mechanostrider";
				["Type"] = "Ground";
				["Item"] = 18772;
				["Value"] = "100|150";
				["Speed"] = 100;
				["Taught"] = true;
				["Riding"] = 150;
				["SpellName"] = "Swift Green Mechanostrider";
			};
			[22719] = {
				["Spell"] = 22719;
				["Subtype"] = "VeryFast";
				["ItemName"] = "Black Battlestrider";
				["Type"] = "Ground";
				["Item"] = 29465;
				["Value"] = "100|150";
				["Speed"] = 100;
				["Taught"] = true;
				["Riding"] = 150;
				["SpellName"] = "Black Battlestrider";
			};
			[22723] = {
				["Spell"] = 22723;
				["Subtype"] = "VeryFast";
				["ItemName"] = "Reins of the Black War Tiger";
				["Type"] = "Ground";
				["Item"] = 29471;
				["Value"] = "100|150";
				["Speed"] = 100;
				["Taught"] = true;
				["Riding"] = 150;
				["SpellName"] = "Black War Tiger";
			};
			[60116] = {
				["Spell"] = 60116;
				["Subtype"] = "VeryFast";
				["ItemName"] = "Reins of the Armored Brown Bear";
				["Type"] = "Ground";
				["Item"] = 44226;
				["Value"] = "100|150";
				["Speed"] = 100;
				["Taught"] = true;
				["Riding"] = 150;
				["SpellName"] = "Armored Brown Bear";
			};
			[23241] = {
				["Spell"] = 23241;
				["Subtype"] = "VeryFast";
				["ItemName"] = "Swift Blue Raptor";
				["Type"] = "Ground";
				["Item"] = 18788;
				["Value"] = "100|150";
				["Speed"] = 100;
				["Taught"] = true;
				["Riding"] = 150;
				["SpellName"] = "Swift Blue Raptor";
			};
			[41517] = {
				["Spell"] = 41517;
				["Subtype"] = "VeryFast";
				["ItemName"] = "Reins of the Veridian Netherwing Drake";
				["Type"] = "Flying";
				["Item"] = 32861;
				["Value"] = "280|300";
				["Speed"] = 280;
				["Taught"] = true;
				["Riding"] = 300;
				["SpellName"] = "Veridian Netherwing Drake";
			};
			[60140] = {
				["Type"] = "Passenger";
				["Subtype"] = "Ground";
				["Passengers"] = 3;
				["Subtype2"] = "VeryFast";
				["Value"] = "100|0|3";
				["Speed"] = 100;
				["Spell"] = 60140;
				["Riding"] = 0;
				["SpellName"] = "Grand Caravan Mammoth";
			};
			[61447] = {
				["Type"] = "Passenger";
				["Subtype"] = "Ground";
				["Passengers"] = 3;
				["Subtype2"] = "VeryFast";
				["Spell"] = 61447;
				["Taught"] = true;
				["Item"] = 44234;
				["Value"] = "100|150|3";
				["Speed"] = 100;
				["ItemName"] = "Reins of the Traveler's Tundra Mammoth";
				["Riding"] = 150;
				["SpellName"] = "Traveler's Tundra Mammoth";
			};
			[33660] = {
				["Spell"] = 33660;
				["Subtype"] = "VeryFast";
				["ItemName"] = "Swift Pink Hawkstrider";
				["Type"] = "Ground";
				["Item"] = 28936;
				["Value"] = "100|150";
				["Speed"] = 100;
				["Taught"] = true;
				["Riding"] = 150;
				["SpellName"] = "Swift Pink Hawkstrider";
			};
			[30174] = {
				["ItemName"] = "Riding Turtle";
				["Subtype"] = "Slow";
				["Type"] = "Ground";
				["Spell"] = 30174;
				["Item"] = 23720;
				["Value"] = "0|0";
				["Taught"] = true;
				["Speed"] = 0;
				["Riding"] = 0;
				["SpellName"] = "Riding Turtle";
			};
			[39318] = {
				["Spell"] = 39318;
				["Subtype"] = "VeryFast";
				["ItemName"] = "Reins of the Tan Riding Talbuk";
				["Type"] = "Ground";
				["Item"] = 31834;
				["Value"] = "100|150";
				["Speed"] = 100;
				["Taught"] = true;
				["Riding"] = 150;
				["SpellName"] = "Tan Riding Talbuk";
			};
			[32242] = {
				["Spell"] = 32242;
				["Subtype"] = "VeryFast";
				["ItemName"] = "Swift Blue Gryphon";
				["Type"] = "Flying";
				["Item"] = 25473;
				["Value"] = "280|300";
				["Speed"] = 280;
				["Taught"] = true;
				["Riding"] = 300;
				["SpellName"] = "Swift Blue Gryphon";
			};
			[10792] = {
				["ItemName"] = "Reins of the Spotted Nightsaber";
				["Subtype"] = "Fast";
				["Spell"] = 10792;
				["Type"] = "Ground";
				["Item"] = 8628;
				["Value"] = "60|0";
				["Taught"] = true;
				["Speed"] = 60;
				["Riding"] = 0;
				["SpellName"] = "Spotted Panther";
			};
			[470] = {
				["Spell"] = 470;
				["Subtype"] = "Fast";
				["ItemName"] = "Black Stallion Bridle";
				["Type"] = "Ground";
				["Item"] = 2411;
				["Value"] = "60|75";
				["Speed"] = 60;
				["Taught"] = true;
				["Riding"] = 75;
				["SpellName"] = "Black Stallion";
			};
			[10796] = {
				["Spell"] = 10796;
				["Subtype"] = "Fast";
				["ItemName"] = "Whistle of the Turquoise Raptor";
				["Type"] = "Ground";
				["Item"] = 8591;
				["Value"] = "60|75";
				["Speed"] = 60;
				["Taught"] = true;
				["Riding"] = 75;
				["SpellName"] = "Turquoise Raptor";
			};
			[10798] = {
				["Type"] = "Ground";
				["Value"] = "60|0";
				["Subtype"] = "Fast";
				["Speed"] = 60;
				["Spell"] = 10798;
				["Riding"] = 0;
				["SpellName"] = "Obsidian Raptor";
			};
			[32246] = {
				["Spell"] = 32246;
				["Subtype"] = "VeryFast";
				["ItemName"] = "Swift Red Wind Rider";
				["Type"] = "Flying";
				["Item"] = 25477;
				["Value"] = "280|300";
				["Speed"] = 280;
				["Taught"] = true;
				["Riding"] = 300;
				["SpellName"] = "Swift Red Wind Rider";
			};
			[17460] = {
				["ItemName"] = "Frost Ram";
				["Subtype"] = "VeryFast";
				["Spell"] = 17460;
				["Type"] = "Ground";
				["Item"] = 13329;
				["Taught"] = true;
				["Value"] = "100|150";
				["Speed"] = 100;
				["Riding"] = 150;
				["SpellName"] = "Frost Ram";
			};
			[17464] = {
				["Spell"] = 17464;
				["Subtype"] = "Fast";
				["ItemName"] = "Brown Skeletal Horse";
				["Type"] = "Ground";
				["Item"] = 13333;
				["Value"] = "60|75";
				["Speed"] = 60;
				["Taught"] = true;
				["Riding"] = 75;
				["SpellName"] = "Brown Skeletal Horse";
			};
			[26054] = {
				["Spell"] = 26054;
				["Subtype"] = "VeryFast";
				["ItemName"] = "Red Qiraji Resonating Crystal";
				["Type"] = "Ground";
				["Item"] = 21321;
				["Value"] = "100|75";
				["Speed"] = 100;
				["Taught"] = true;
				["Riding"] = 75;
				["SpellName"] = "Red Qiraji Battle Tank";
			};
			[23249] = {
				["Spell"] = 23249;
				["Subtype"] = "VeryFast";
				["ItemName"] = "Great Brown Kodo";
				["Type"] = "Ground";
				["Item"] = 18794;
				["Value"] = "100|150";
				["Speed"] = 100;
				["Taught"] = true;
				["Riding"] = 150;
				["SpellName"] = "Great Brown Kodo";
			};
			[26656] = {
				["Spell"] = 26656;
				["Subtype"] = "VeryFast";
				["ItemName"] = "Black Qiraji Resonating Crystal";
				["Type"] = "Ground";
				["Item"] = 21176;
				["Value"] = "100|150";
				["Speed"] = 100;
				["Taught"] = true;
				["Riding"] = 150;
				["SpellName"] = "Black Qiraji Battle Tank";
			};
			[59567] = {
				["Type"] = "Flying";
				["Value"] = "280|0";
				["Subtype"] = "VeryFast";
				["Speed"] = 280;
				["Spell"] = 59567;
				["Riding"] = 0;
				["SpellName"] = "Azure Drake";
			};
			[17229] = {
				["Spell"] = 17229;
				["Subtype"] = "VeryFast";
				["ItemName"] = "Reins of the Winterspring Frostsaber";
				["Type"] = "Ground";
				["Item"] = 13086;
				["Value"] = "100|75";
				["Speed"] = 100;
				["Taught"] = true;
				["Riding"] = 75;
				["SpellName"] = "Winterspring Frostsaber";
			};
			[35022] = {
				["Spell"] = 35022;
				["Subtype"] = "Fast";
				["ItemName"] = "Black Hawkstrider";
				["Type"] = "Ground";
				["Item"] = 29221;
				["Value"] = "60|75";
				["Speed"] = 60;
				["Taught"] = true;
				["Riding"] = 75;
				["SpellName"] = "Black Hawkstrider";
			};
			[32290] = {
				["Spell"] = 32290;
				["Subtype"] = "VeryFast";
				["ItemName"] = "Swift Green Gryphon";
				["Type"] = "Flying";
				["Item"] = 25528;
				["Value"] = "280|300";
				["Speed"] = 280;
				["Taught"] = true;
				["Riding"] = 300;
				["SpellName"] = "Swift Green Gryphon";
			};
			[16083] = {
				["Spell"] = 16083;
				["Subtype"] = "VeryFast";
				["ItemName"] = "White Stallion Bridle";
				["Type"] = "Ground";
				["Item"] = 12353;
				["Value"] = "100|150";
				["Speed"] = 100;
				["Taught"] = true;
				["Riding"] = 150;
				["SpellName"] = "White Stallion";
			};
			[42777] = {
				["Spell"] = 42777;
				["Subtype"] = "VeryFast";
				["ItemName"] = "Reins of the Swift Spectral Tiger";
				["Type"] = "Ground";
				["Item"] = 33225;
				["Value"] = "100|150";
				["Speed"] = 100;
				["Taught"] = true;
				["Riding"] = 150;
				["SpellName"] = "Swift Spectral Tiger";
			};
			[16081] = {
				["Spell"] = 16081;
				["Subtype"] = "VeryFast";
				["ItemName"] = "Horn of the Arctic Wolf";
				["Type"] = "Ground";
				["Item"] = 12351;
				["Value"] = "100|150";
				["Speed"] = 100;
				["Taught"] = true;
				["Riding"] = 150;
				["SpellName"] = "Winter Wolf";
			};
			[41518] = {
				["Spell"] = 41518;
				["Subtype"] = "VeryFast";
				["ItemName"] = "Reins of the Violet Netherwing Drake";
				["Type"] = "Flying";
				["Item"] = 32862;
				["Value"] = "280|300";
				["Speed"] = 280;
				["Taught"] = true;
				["Riding"] = 300;
				["SpellName"] = "Violet Netherwing Drake";
			};
			[34896] = {
				["Spell"] = 34896;
				["Subtype"] = "VeryFast";
				["ItemName"] = "Reins of the Cobalt War Talbuk";
				["Type"] = "Ground";
				["Item"] = 29227;
				["Value"] = "100|150";
				["Speed"] = 100;
				["Taught"] = true;
				["Riding"] = 150;
				["SpellName"] = "Cobalt War Talbuk";
			};
			[60021] = {
				["Type"] = "Flying";
				["Value"] = "310|0";
				["Subtype"] = "ExtremelyFast";
				["Speed"] = 310;
				["Spell"] = 60021;
				["Riding"] = 0;
				["SpellName"] = "Plagued Proto-Drake";
			};
			[471] = {
				["Type"] = "Ground";
				["Value"] = "60|0";
				["Subtype"] = "Fast";
				["Speed"] = 60;
				["Spell"] = 471;
				["Riding"] = 0;
				["SpellName"] = "Palamino";
			};
			[39317] = {
				["Spell"] = 39317;
				["Subtype"] = "VeryFast";
				["ItemName"] = "Reins of the Silver Riding Talbuk";
				["Type"] = "Ground";
				["Item"] = 31832;
				["Value"] = "100|150";
				["Speed"] = 100;
				["Taught"] = true;
				["Riding"] = 150;
				["SpellName"] = "Silver Riding Talbuk";
			};
			[23229] = {
				["Spell"] = 23229;
				["Subtype"] = "VeryFast";
				["ItemName"] = "Swift Brown Steed";
				["Type"] = "Ground";
				["Item"] = 18777;
				["Value"] = "100|150";
				["Speed"] = 100;
				["Taught"] = true;
				["Riding"] = 150;
				["SpellName"] = "Swift Brown Steed";
			};
			[3363] = {
				["Type"] = "Flying";
				["Value"] = "310|0";
				["Subtype"] = "ExtremelyFast";
				["Speed"] = 310;
				["Spell"] = 3363;
				["Riding"] = 0;
				["SpellName"] = "Nether Drake";
			};
			[23250] = {
				["Spell"] = 23250;
				["Subtype"] = "VeryFast";
				["ItemName"] = "Horn of the Swift Brown Wolf";
				["Type"] = "Ground";
				["Item"] = 18796;
				["Value"] = "100|150";
				["Speed"] = 100;
				["Taught"] = true;
				["Riding"] = 150;
				["SpellName"] = "Swift Brown Wolf";
			};
			[42776] = {
				["Spell"] = 42776;
				["Subtype"] = "Fast";
				["ItemName"] = "Reins of the Spectral Tiger";
				["Type"] = "Ground";
				["Item"] = 33224;
				["Value"] = "60|75";
				["Speed"] = 60;
				["Taught"] = true;
				["Riding"] = 75;
				["SpellName"] = "Spectral Tiger";
			};
			[6648] = {
				["Spell"] = 6648;
				["Subtype"] = "Fast";
				["ItemName"] = "Chestnut Mare Bridle";
				["Type"] = "Ground";
				["Item"] = 5655;
				["Value"] = "60|75";
				["Speed"] = 60;
				["Taught"] = true;
				["Riding"] = 75;
				["SpellName"] = "Chestnut Mare";
			};
			[23222] = {
				["Spell"] = 23222;
				["Subtype"] = "VeryFast";
				["ItemName"] = "Swift Yellow Mechanostrider";
				["Type"] = "Ground";
				["Item"] = 18774;
				["Value"] = "100|150";
				["Speed"] = 100;
				["Taught"] = true;
				["Riding"] = 150;
				["SpellName"] = "Swift Yellow Mechanostrider";
			};
			[26055] = {
				["Spell"] = 26055;
				["Subtype"] = "VeryFast";
				["ItemName"] = "Yellow Qiraji Resonating Crystal";
				["Type"] = "Ground";
				["Item"] = 21324;
				["Value"] = "100|75";
				["Speed"] = 100;
				["Taught"] = true;
				["Riding"] = 75;
				["SpellName"] = "Yellow Qiraji Battle Tank";
			};
			[39319] = {
				["Spell"] = 39319;
				["Subtype"] = "VeryFast";
				["ItemName"] = "Reins of the White Riding Talbuk";
				["Type"] = "Ground";
				["Item"] = 31836;
				["Value"] = "100|150";
				["Speed"] = 100;
				["Taught"] = true;
				["Riding"] = 150;
				["SpellName"] = "White Riding Talbuk";
			};
			[61470] = {
				["Type"] = "Passenger";
				["Subtype"] = "Ground";
				["Passengers"] = 3;
				["Subtype2"] = "VeryFast";
				["Spell"] = 61470;
				["Taught"] = true;
				["Item"] = 43961;
				["Value"] = "100|150|3";
				["Speed"] = 100;
				["ItemName"] = "Reins of the Grand Ice Mammoth";
				["Riding"] = 150;
				["SpellName"] = "Summon Grand Ice Mammoth";
			};
			[28828] = {
				["Type"] = "Ground";
				["Value"] = "300|0";
				["Subtype"] = "Slow";
				["Speed"] = 300;
				["Spell"] = 28828;
				["Riding"] = 0;
				["SpellName"] = "Nether Drake";
			};
			[6898] = {
				["Spell"] = 6898;
				["Subtype"] = "Fast";
				["ItemName"] = "White Ram";
				["Type"] = "Ground";
				["Item"] = 5873;
				["Value"] = "60|75";
				["Speed"] = 60;
				["Taught"] = true;
				["Riding"] = 75;
				["SpellName"] = "White Ram";
			};
			[17453] = {
				["Spell"] = 17453;
				["Subtype"] = "Fast";
				["ItemName"] = "Green Mechanostrider";
				["Type"] = "Ground";
				["Item"] = 13321;
				["Value"] = "60|75";
				["Speed"] = 60;
				["Taught"] = true;
				["Riding"] = 75;
				["SpellName"] = "Green Mechanostrider";
			};
			[16055] = {
				["ItemName"] = "Reins of the Nightsaber";
				["Subtype"] = "VeryFast";
				["Spell"] = 16055;
				["Type"] = "Ground";
				["Item"] = 12303;
				["Taught"] = true;
				["Value"] = "100|150";
				["Speed"] = 100;
				["Riding"] = 150;
				["SpellName"] = "Black Nightsaber";
			};
			[41516] = {
				["Spell"] = 41516;
				["Subtype"] = "VeryFast";
				["ItemName"] = "Reins of the Purple Netherwing Drake";
				["Type"] = "Flying";
				["Item"] = 32860;
				["Value"] = "280|300";
				["Speed"] = 280;
				["Taught"] = true;
				["Riding"] = 300;
				["SpellName"] = "Purple Netherwing Drake";
			};
			[29059] = {
				["Type"] = "Ground";
				["Value"] = "100|0";
				["Subtype"] = "VeryFast";
				["Speed"] = 100;
				["Spell"] = 29059;
				["Riding"] = 0;
				["SpellName"] = "Naxxramas Deathcharger";
			};
			[35710] = {
				["Spell"] = 35710;
				["Subtype"] = "Fast";
				["ItemName"] = "Gray Elekk";
				["Type"] = "Ground";
				["Item"] = 29744;
				["Value"] = "60|75";
				["Speed"] = 60;
				["Taught"] = true;
				["Riding"] = 75;
				["SpellName"] = "Gray Elekk";
			};
			[59791] = {
				["Spell"] = 59791;
				["Subtype"] = "VeryFast";
				["ItemName"] = "Reins of the Wooly Mammoth";
				["Type"] = "Ground";
				["Item"] = 44230;
				["Value"] = "100|150";
				["Speed"] = 100;
				["Taught"] = true;
				["Riding"] = 150;
				["SpellName"] = "Wooly Mammoth";
			};
			[59799] = {
				["Spell"] = 59799;
				["Subtype"] = "VeryFast";
				["ItemName"] = "Reins of the Ice Mammoth";
				["Type"] = "Ground";
				["Item"] = 43958;
				["Value"] = "100|150";
				["Speed"] = 100;
				["Taught"] = true;
				["Riding"] = 150;
				["SpellName"] = "Ice Mammoth";
			};
			[61425] = {
				["Type"] = "Passenger";
				["Subtype"] = "Ground";
				["Passengers"] = 3;
				["Subtype2"] = "VeryFast";
				["Spell"] = 61425;
				["Taught"] = true;
				["Item"] = 44235;
				["Value"] = "100|150|3";
				["Speed"] = 100;
				["ItemName"] = "Reins of the Traveler's Tundra Mammoth";
				["Riding"] = 150;
				["SpellName"] = "Traveler's Tundra Mammoth";
			};
			[42667] = {
				["ItemName"] = "Flying Broom";
				["Subtype"] = "Fast";
				["Spell"] = 42667;
				["Item"] = 33176;
				["Value"] = "60|225";
				["Speed"] = 60;
				["Type"] = "Flying";
				["Riding"] = 225;
				["SpellName"] = "Flying Broom";
			};
			[59568] = {
				["Spell"] = 59568;
				["Subtype"] = "VeryFast";
				["ItemName"] = "Reins of the Blue Drake";
				["Type"] = "Flying";
				["Item"] = 43953;
				["Value"] = "280|300";
				["Speed"] = 280;
				["Taught"] = true;
				["Riding"] = 300;
				["SpellName"] = "Blue Drake";
			};
			[24242] = {
				["Spell"] = 24242;
				["Subtype"] = "VeryFast";
				["ItemName"] = "Swift Razzashi Raptor";
				["Type"] = "Ground";
				["Item"] = 19872;
				["Value"] = "100|150";
				["Speed"] = 100;
				["Taught"] = true;
				["Riding"] = 150;
				["SpellName"] = "Swift Razzashi Raptor";
			};
			[18991] = {
				["ItemName"] = "Green Kodo";
				["Subtype"] = "VeryFast";
				["Spell"] = 18991;
				["Type"] = "Ground";
				["Item"] = 15292;
				["Taught"] = true;
				["Value"] = "100|150";
				["Speed"] = 100;
				["Riding"] = 150;
				["SpellName"] = "Green Kodo";
			};
			[22720] = {
				["Spell"] = 22720;
				["Subtype"] = "VeryFast";
				["ItemName"] = "Black War Ram";
				["Type"] = "Ground";
				["Item"] = 29467;
				["Value"] = "100|150";
				["Speed"] = 100;
				["Taught"] = true;
				["Riding"] = 150;
				["SpellName"] = "Black War Ram";
			};
			[22724] = {
				["Spell"] = 22724;
				["Subtype"] = "VeryFast";
				["ItemName"] = "Horn of the Black War Wolf";
				["Type"] = "Ground";
				["Item"] = 29469;
				["Value"] = "100|150";
				["Speed"] = 100;
				["Taught"] = true;
				["Riding"] = 150;
				["SpellName"] = "Black War Wolf";
			};
			[23238] = {
				["Spell"] = 23238;
				["Subtype"] = "VeryFast";
				["ItemName"] = "Swift Brown Ram";
				["Type"] = "Ground";
				["Item"] = 18786;
				["Value"] = "100|150";
				["Speed"] = 100;
				["Taught"] = true;
				["Riding"] = 150;
				["SpellName"] = "Swift Brown Ram";
			};
			[23242] = {
				["Spell"] = 23242;
				["Subtype"] = "VeryFast";
				["ItemName"] = "Swift Olive Raptor";
				["Type"] = "Ground";
				["Item"] = 18789;
				["Value"] = "100|150";
				["Speed"] = 100;
				["Taught"] = true;
				["Riding"] = 150;
				["SpellName"] = "Swift Olive Raptor";
			};
			[23246] = {
				["Spell"] = 23246;
				["Subtype"] = "VeryFast";
				["ItemName"] = "Purple Skeletal Warhorse";
				["Type"] = "Ground";
				["Item"] = 18791;
				["Value"] = "100|150";
				["Speed"] = 100;
				["Taught"] = true;
				["Riding"] = 150;
				["SpellName"] = "Purple Skeletal Warhorse";
			};
			[34897] = {
				["Spell"] = 34897;
				["Subtype"] = "VeryFast";
				["ItemName"] = "Reins of the White War Talbuk";
				["Type"] = "Ground";
				["Item"] = 29231;
				["Value"] = "100|150";
				["Speed"] = 100;
				["Taught"] = true;
				["Riding"] = 150;
				["SpellName"] = "White War Talbuk";
			};
			[23509] = {
				["Spell"] = 23509;
				["Subtype"] = "VeryFast";
				["ItemName"] = "Horn of the Frostwolf Howler";
				["Type"] = "Ground";
				["Item"] = 19029;
				["Value"] = "100|150";
				["Speed"] = 100;
				["Taught"] = true;
				["Riding"] = 150;
				["SpellName"] = "Frostwolf Howler";
			};
			[49193] = {
				["Spell"] = 49193;
				["Subtype"] = "ExtremelyFast";
				["ItemName"] = "Vengeful Nether Drake";
				["Type"] = "Flying";
				["Item"] = 37676;
				["Value"] = "310|300";
				["Speed"] = 310;
				["Taught"] = true;
				["Riding"] = 300;
				["SpellName"] = "Vengeful Nether Drake";
			};
			[15781] = {
				["Type"] = "Ground";
				["Value"] = "60|0";
				["Subtype"] = "Fast";
				["Speed"] = 60;
				["Spell"] = 15781;
				["Riding"] = 0;
				["SpellName"] = "Steel Mechanostrider";
			};
			[48954] = {
				["Type"] = "Ground";
				["Value"] = "100|0";
				["Subtype"] = "VeryFast";
				["Speed"] = 100;
				["Spell"] = 48954;
				["Riding"] = 0;
				["SpellName"] = "Swift Zhevra";
			};
			[32295] = {
				["Spell"] = 32295;
				["Subtype"] = "VeryFast";
				["ItemName"] = "Swift Green Wind Rider";
				["Type"] = "Flying";
				["Item"] = 25531;
				["Value"] = "280|300";
				["Speed"] = 280;
				["Taught"] = true;
				["Riding"] = 300;
				["SpellName"] = "Swift Green Wind Rider";
			};
			[61465] = {
				["Type"] = "Passenger";
				["Subtype"] = "Ground";
				["Passengers"] = 3;
				["Subtype2"] = "VeryFast";
				["Value"] = "100|0|3";
				["Speed"] = 100;
				["Spell"] = 61465;
				["Riding"] = 0;
				["SpellName"] = "Grand Black War Mammoth";
			};
			[39798] = {
				["Spell"] = 39798;
				["Subtype"] = "VeryFast";
				["ItemName"] = "Green Riding Nether Ray";
				["Type"] = "Flying";
				["Item"] = 32314;
				["Value"] = "280|300";
				["Speed"] = 280;
				["Taught"] = true;
				["Riding"] = 300;
				["SpellName"] = "Green Riding Nether Ray";
			};
			[46628] = {
				["Spell"] = 46628;
				["Subtype"] = "VeryFast";
				["ItemName"] = "Swift White Hawkstrider";
				["Type"] = "Ground";
				["Item"] = 35513;
				["Value"] = "100|150";
				["Speed"] = 100;
				["Taught"] = true;
				["Riding"] = 150;
				["SpellName"] = "Swift White Hawkstrider";
			};
			[34899] = {
				["Spell"] = 34899;
				["Subtype"] = "VeryFast";
				["ItemName"] = "Reins of the Tan War Talbuk";
				["Type"] = "Ground";
				["Item"] = 29230;
				["Value"] = "100|150";
				["Speed"] = 100;
				["Taught"] = true;
				["Riding"] = 150;
				["SpellName"] = "Tan War Talbuk";
			};
			[46197] = {
				["ItemName"] = "X-51 Nether-Rocket";
				["Subtype"] = "Fast";
				["Spell"] = 46197;
				["Type"] = "Flying";
				["Item"] = 35225;
				["Taught"] = true;
				["Value"] = "60|225";
				["Speed"] = 60;
				["Riding"] = 225;
				["SpellName"] = "X-51 Nether-Rocket";
			};
			[15780] = {
				["Type"] = "Ground";
				["Value"] = "60|0";
				["Subtype"] = "Fast";
				["Speed"] = 60;
				["Spell"] = 15780;
				["Riding"] = 0;
				["SpellName"] = "Green Mechanostrider";
			};
			[18989] = {
				["Spell"] = 18989;
				["Subtype"] = "Fast";
				["ItemName"] = "Gray Kodo";
				["Type"] = "Ground";
				["Item"] = 15277;
				["Value"] = "60|75";
				["Speed"] = 60;
				["Taught"] = true;
				["Riding"] = 75;
				["SpellName"] = "Gray Kodo";
			};
			[17463] = {
				["Spell"] = 17463;
				["Subtype"] = "Fast";
				["ItemName"] = "Blue Skeletal Horse";
				["Type"] = "Ground";
				["Item"] = 13332;
				["Value"] = "60|75";
				["Speed"] = 60;
				["Taught"] = true;
				["Riding"] = 75;
				["SpellName"] = "Blue Skeletal Horse";
			};
			[17459] = {
				["ItemName"] = "Icy Blue Mechanostrider Mod A";
				["Subtype"] = "VeryFast";
				["Spell"] = 17459;
				["Type"] = "Ground";
				["Item"] = 13327;
				["Taught"] = true;
				["Value"] = "100|150";
				["Speed"] = 100;
				["Riding"] = 150;
				["SpellName"] = "Icy Blue Mechanostrider Mod A";
			};
			[32235] = {
				["Spell"] = 32235;
				["Subtype"] = "Fast";
				["ItemName"] = "Golden Gryphon";
				["Type"] = "Flying";
				["Item"] = 25470;
				["Value"] = "60|225";
				["Speed"] = 60;
				["Taught"] = true;
				["Riding"] = 225;
				["SpellName"] = "Golden Gryphon";
			};
			[32239] = {
				["Spell"] = 32239;
				["Subtype"] = "Fast";
				["ItemName"] = "Ebon Gryphon";
				["Type"] = "Flying";
				["Item"] = 25471;
				["Value"] = "60|225";
				["Speed"] = 60;
				["Taught"] = true;
				["Riding"] = 225;
				["SpellName"] = "Ebon Gryphon";
			};
			[32243] = {
				["Spell"] = 32243;
				["Subtype"] = "Fast";
				["ItemName"] = "Tawny Wind Rider";
				["Type"] = "Flying";
				["Item"] = 25474;
				["Value"] = "60|225";
				["Speed"] = 60;
				["Taught"] = true;
				["Riding"] = 225;
				["SpellName"] = "Tawny Wind Rider";
			};
			[17455] = {
				["Type"] = "Ground";
				["Value"] = "60|0";
				["Subtype"] = "Fast";
				["Speed"] = 60;
				["Spell"] = 17455;
				["Riding"] = 0;
				["SpellName"] = "Purple Mechanostrider";
			};
			[17461] = {
				["ItemName"] = "Black Ram";
				["Subtype"] = "VeryFast";
				["Spell"] = 17461;
				["Type"] = "Ground";
				["Item"] = 13328;
				["Taught"] = true;
				["Value"] = "100|150";
				["Speed"] = 100;
				["Riding"] = 150;
				["SpellName"] = "Black Ram";
			};
			[17465] = {
				["Spell"] = 17465;
				["Subtype"] = "VeryFast";
				["ItemName"] = "Green Skeletal Warhorse";
				["Type"] = "Ground";
				["Item"] = 13334;
				["Value"] = "100|150";
				["Speed"] = 100;
				["Taught"] = true;
				["Riding"] = 150;
				["SpellName"] = "Green Skeletal Warhorse";
			};
			[15779] = {
				["ItemName"] = "White Mechanostrider Mod A";
				["Subtype"] = "VeryFast";
				["Spell"] = 15779;
				["Type"] = "Ground";
				["Item"] = 13326;
				["Taught"] = true;
				["Value"] = "100|150";
				["Speed"] = 100;
				["Riding"] = 150;
				["SpellName"] = "White Mechanostrider Mod B";
			};
			[23338] = {
				["Spell"] = 23338;
				["Subtype"] = "VeryFast";
				["ItemName"] = "Reins of the Swift Stormsaber";
				["Type"] = "Ground";
				["Item"] = 18902;
				["Value"] = "100|150";
				["Speed"] = 100;
				["Taught"] = true;
				["Riding"] = 150;
				["SpellName"] = "Swift Stormsaber";
			};
			[16082] = {
				["Spell"] = 16082;
				["Subtype"] = "VeryFast";
				["ItemName"] = "Commander's Steed";
				["Type"] = "Ground";
				["Item"] = 12354;
				["Value"] = "100|150";
				["Speed"] = 100;
				["Taught"] = true;
				["Riding"] = 150;
				["SpellName"] = "Palomino";
			};
			[59569] = {
				["Spell"] = 59569;
				["Subtype"] = "VeryFast";
				["ItemName"] = "Reins of the Bronze Drake";
				["Type"] = "Flying";
				["Item"] = 43951;
				["Value"] = "280|300";
				["Speed"] = 280;
				["Taught"] = true;
				["Riding"] = 300;
				["SpellName"] = "Bronze Drake";
			};
			[578] = {
				["Type"] = "Ground";
				["Value"] = "60|0";
				["Subtype"] = "Fast";
				["Speed"] = 60;
				["Spell"] = 578;
				["Riding"] = 0;
				["SpellName"] = "Black Wolf";
			};
			[8394] = {
				["Spell"] = 8394;
				["Subtype"] = "Fast";
				["ItemName"] = "Reins of the Striped Frostsaber";
				["Type"] = "Ground";
				["Item"] = 8631;
				["Value"] = "60|75";
				["Speed"] = 60;
				["Taught"] = true;
				["Riding"] = 75;
				["SpellName"] = "Striped Frostsaber";
			};
			[579] = {
				["Type"] = "Ground";
				["Value"] = "100|0";
				["Subtype"] = "VeryFast";
				["Speed"] = 100;
				["Spell"] = 579;
				["Riding"] = 0;
				["SpellName"] = "Red Wolf";
			};
			[34795] = {
				["Spell"] = 34795;
				["Subtype"] = "Fast";
				["ItemName"] = "Red Hawkstrider";
				["Type"] = "Ground";
				["Item"] = 28927;
				["Value"] = "60|75";
				["Speed"] = 60;
				["Taught"] = true;
				["Riding"] = 75;
				["SpellName"] = "Red Hawkstrider";
			};
			[60119] = {
				["Spell"] = 60119;
				["Subtype"] = "VeryFast";
				["ItemName"] = "Reins of the Black War Bear";
				["Type"] = "Ground";
				["Item"] = 44224;
				["Value"] = "100|150";
				["Speed"] = 100;
				["Taught"] = true;
				["Riding"] = 150;
				["SpellName"] = "Black War Bear";
			};
			[44317] = {
				["Type"] = "Flying";
				["Value"] = "310|0";
				["Subtype"] = "ExtremelyFast";
				["Speed"] = 310;
				["Spell"] = 44317;
				["Riding"] = 0;
				["SpellName"] = "Merciless Nether Drake";
			};
			[23223] = {
				["Spell"] = 23223;
				["Subtype"] = "VeryFast";
				["ItemName"] = "Swift White Mechanostrider";
				["Type"] = "Ground";
				["Item"] = 18773;
				["Value"] = "100|150";
				["Speed"] = 100;
				["Taught"] = true;
				["Riding"] = 150;
				["SpellName"] = "Swift White Mechanostrider";
			};
			[16056] = {
				["Spell"] = 16056;
				["Subtype"] = "VeryFast";
				["ItemName"] = "Reins of the Ancient Frostsaber";
				["Type"] = "Ground";
				["Item"] = 12302;
				["Value"] = "100|150";
				["Speed"] = 100;
				["Taught"] = true;
				["Riding"] = 150;
				["SpellName"] = "Ancient Frostsaber";
			};
			[16058] = {
				["Type"] = "Ground";
				["Value"] = "60|0";
				["Subtype"] = "Fast";
				["Speed"] = 60;
				["Spell"] = 16058;
				["Riding"] = 0;
				["SpellName"] = "Primal Leopard";
			};
			[16060] = {
				["Type"] = "Ground";
				["Value"] = "60|0";
				["Subtype"] = "Fast";
				["Speed"] = 60;
				["Spell"] = 16060;
				["Riding"] = 0;
				["SpellName"] = "Golden Sabercat";
			};
			[61442] = {
				["Type"] = "Passenger";
				["Subtype"] = "Flying";
				["Passengers"] = 2;
				["Subtype2"] = "VeryFast";
				["Value"] = "280|0|2";
				["Speed"] = 280;
				["Spell"] = 61442;
				["Riding"] = 0;
				["SpellName"] = "Swift Mooncloth Carpet";
			};
			[22717] = {
				["Spell"] = 22717;
				["Subtype"] = "VeryFast";
				["ItemName"] = "Black War Steed Bridle";
				["Type"] = "Ground";
				["Item"] = 29468;
				["Value"] = "100|150";
				["Speed"] = 100;
				["Taught"] = true;
				["Riding"] = 150;
				["SpellName"] = "Black War Steed";
			};
			[23243] = {
				["Spell"] = 23243;
				["Subtype"] = "VeryFast";
				["ItemName"] = "Swift Orange Raptor";
				["Type"] = "Ground";
				["Item"] = 18790;
				["Value"] = "100|150";
				["Speed"] = 100;
				["Taught"] = true;
				["Riding"] = 150;
				["SpellName"] = "Swift Orange Raptor";
			};
			[35711] = {
				["Spell"] = 35711;
				["Subtype"] = "Fast";
				["ItemName"] = "Purple Elekk";
				["Type"] = "Ground";
				["Item"] = 29743;
				["Value"] = "60|75";
				["Speed"] = 60;
				["Taught"] = true;
				["Riding"] = 75;
				["SpellName"] = "Purple Elekk";
			};
			[23247] = {
				["Spell"] = 23247;
				["Subtype"] = "VeryFast";
				["ItemName"] = "Great White Kodo";
				["Type"] = "Ground";
				["Item"] = 18793;
				["Value"] = "100|150";
				["Speed"] = 100;
				["Taught"] = true;
				["Riding"] = 150;
				["SpellName"] = "Great White Kodo";
			};
			[6777] = {
				["Spell"] = 6777;
				["Subtype"] = "Fast";
				["ItemName"] = "Gray Ram";
				["Type"] = "Ground";
				["Item"] = 5864;
				["Value"] = "60|75";
				["Speed"] = 60;
				["Taught"] = true;
				["Riding"] = 75;
				["SpellName"] = "Gray Ram";
			};
			[23251] = {
				["Spell"] = 23251;
				["Subtype"] = "VeryFast";
				["ItemName"] = "Horn of the Swift Timber Wolf";
				["Type"] = "Ground";
				["Item"] = 18797;
				["Value"] = "100|150";
				["Speed"] = 100;
				["Taught"] = true;
				["Riding"] = 150;
				["SpellName"] = "Swift Timber Wolf";
			};
			[17454] = {
				["Spell"] = 17454;
				["Subtype"] = "Fast";
				["ItemName"] = "Unpainted Mechanostrider";
				["Type"] = "Ground";
				["Item"] = 13322;
				["Value"] = "60|75";
				["Speed"] = 60;
				["Taught"] = true;
				["Riding"] = 75;
				["SpellName"] = "Unpainted Mechanostrider";
			};
			[59976] = {
				["Type"] = "Flying";
				["Value"] = "310|0";
				["Subtype"] = "ExtremelyFast";
				["Speed"] = 310;
				["Spell"] = 59976;
				["Riding"] = 0;
				["SpellName"] = "Black Proto-Drake";
			};
			[16080] = {
				["Spell"] = 16080;
				["Subtype"] = "VeryFast";
				["ItemName"] = "Horn of the Red Wolf";
				["Type"] = "Ground";
				["Item"] = 12330;
				["Value"] = "100|150";
				["Speed"] = 100;
				["Taught"] = true;
				["Riding"] = 150;
				["SpellName"] = "Red Wolf";
			};
			[43927] = {
				["Spell"] = 43927;
				["Subtype"] = "VeryFast";
				["ItemName"] = "Cenarion War Hippogryph";
				["Type"] = "Flying";
				["Item"] = 33999;
				["Value"] = "280|300";
				["Speed"] = 280;
				["Taught"] = true;
				["Riding"] = 300;
				["SpellName"] = "Cenarion War Hippogryph";
			};
			[16084] = {
				["Spell"] = 16084;
				["Subtype"] = "VeryFast";
				["ItemName"] = "Whistle of the Mottled Red Raptor";
				["Type"] = "Ground";
				["Item"] = 8586;
				["Value"] = "100|150";
				["Speed"] = 100;
				["Taught"] = true;
				["Riding"] = 150;
				["SpellName"] = "Mottled Red Raptor";
			};
			[43688] = {
				["Spell"] = 43688;
				["Subtype"] = "VeryFast";
				["ItemName"] = "Amani War Bear";
				["Type"] = "Ground";
				["Item"] = 33809;
				["Value"] = "100|150";
				["Speed"] = 100;
				["Taught"] = true;
				["Riding"] = 150;
				["SpellName"] = "Amani War Bear";
			};
			[35714] = {
				["Spell"] = 35714;
				["Subtype"] = "VeryFast";
				["ItemName"] = "Great Purple Elekk";
				["Type"] = "Ground";
				["Item"] = 29747;
				["Value"] = "100|150";
				["Speed"] = 100;
				["Taught"] = true;
				["Riding"] = 150;
				["SpellName"] = "Great Purple Elekk";
			};
			[60024] = {
				["Type"] = "Flying";
				["Value"] = "310|0";
				["Subtype"] = "ExtremelyFast";
				["Speed"] = 310;
				["Spell"] = 60024;
				["Riding"] = 0;
				["SpellName"] = "Violet Proto-Drake";
			};
			[49322] = {
				["Spell"] = 49322;
				["Subtype"] = "VeryFast";
				["ItemName"] = "Swift Zhevra";
				["Type"] = "Ground";
				["Item"] = 37719;
				["Value"] = "100|150";
				["Speed"] = 100;
				["Taught"] = true;
				["Riding"] = 150;
				["SpellName"] = "Swift Zhevra";
			};
			[59785] = {
				["Spell"] = 59785;
				["Subtype"] = "VeryFast";
				["ItemName"] = "Reins of the Black War Mammoth";
				["Type"] = "Ground";
				["Item"] = 43956;
				["Value"] = "100|150";
				["Speed"] = 100;
				["Taught"] = true;
				["Riding"] = 150;
				["SpellName"] = "Black War Mammoth";
			};
			[59793] = {
				["Spell"] = 59793;
				["Subtype"] = "VeryFast";
				["ItemName"] = "Reins of the Wooly Mammoth";
				["Type"] = "Ground";
				["Item"] = 44231;
				["Value"] = "100|150";
				["Speed"] = 100;
				["Taught"] = true;
				["Riding"] = 150;
				["SpellName"] = "Wooly Mammoth";
			};
			[55531] = {
				["Type"] = "Passenger";
				["Subtype"] = "Ground";
				["Passengers"] = 2;
				["Subtype2"] = "VeryFast";
				["Spell"] = 55531;
				["Taught"] = true;
				["Item"] = 41508;
				["Value"] = "100|150|2";
				["Speed"] = 100;
				["ItemName"] = "Mechano-hog";
				["Riding"] = 150;
				["SpellName"] = "Mechano-hog";
			};
			[35027] = {
				["Spell"] = 35027;
				["Subtype"] = "VeryFast";
				["ItemName"] = "Swift Purple Hawkstrider";
				["Type"] = "Ground";
				["Item"] = 29224;
				["Value"] = "100|150";
				["Speed"] = 100;
				["Taught"] = true;
				["Riding"] = 150;
				["SpellName"] = "Swift Purple Hawkstrider";
			};
			[60025] = {
				["Spell"] = 60025;
				["Subtype"] = "VeryFast";
				["ItemName"] = "Reins of the Albino Drake";
				["Type"] = "Flying";
				["Item"] = 44178;
				["Value"] = "280|300";
				["Speed"] = 280;
				["Taught"] = true;
				["Riding"] = 300;
				["SpellName"] = "Albino Drake";
			};
			[59570] = {
				["Spell"] = 59570;
				["Subtype"] = "VeryFast";
				["ItemName"] = "Reins of the Red Drake";
				["Type"] = "Flying";
				["Item"] = 43955;
				["Value"] = "280|300";
				["Speed"] = 280;
				["Taught"] = true;
				["Riding"] = 300;
				["SpellName"] = "Red Drake";
			};
			[49378] = {
				["Type"] = "Ground";
				["Value"] = "60|0";
				["Subtype"] = "Fast";
				["Speed"] = 60;
				["Spell"] = 49378;
				["Riding"] = 0;
				["SpellName"] = "Brewfest Riding Kodo";
			};
			[23227] = {
				["Spell"] = 23227;
				["Subtype"] = "VeryFast";
				["ItemName"] = "Swift Palomino";
				["Type"] = "Ground";
				["Item"] = 18776;
				["Value"] = "100|150";
				["Speed"] = 100;
				["Taught"] = true;
				["Riding"] = 150;
				["SpellName"] = "Swift Palomino";
			};
			[22721] = {
				["Spell"] = 22721;
				["Subtype"] = "VeryFast";
				["ItemName"] = "Whistle of the Black War Raptor";
				["Type"] = "Ground";
				["Item"] = 29472;
				["Value"] = "100|150";
				["Speed"] = 100;
				["Taught"] = true;
				["Riding"] = 150;
				["SpellName"] = "Black War Raptor";
			};
			[36702] = {
				["Spell"] = 36702;
				["Subtype"] = "VeryFast";
				["ItemName"] = "Fiery Warhorse's Reins";
				["Type"] = "Ground";
				["Item"] = 30480;
				["Value"] = "100|150";
				["Speed"] = 100;
				["Taught"] = true;
				["Riding"] = 150;
				["SpellName"] = "Fiery Warhorse";
			};
			[23239] = {
				["Spell"] = 23239;
				["Subtype"] = "VeryFast";
				["ItemName"] = "Swift Gray Ram";
				["Type"] = "Ground";
				["Item"] = 18787;
				["Value"] = "100|150";
				["Speed"] = 100;
				["Taught"] = true;
				["Riding"] = 150;
				["SpellName"] = "Swift Gray Ram";
			};
			[41513] = {
				["Spell"] = 41513;
				["Subtype"] = "VeryFast";
				["ItemName"] = "Reins of the Onyx Netherwing Drake";
				["Type"] = "Flying";
				["Item"] = 32857;
				["Value"] = "280|300";
				["Speed"] = 280;
				["Taught"] = true;
				["Riding"] = 300;
				["SpellName"] = "Onyx Netherwing Drake";
			};
			[60136] = {
				["Type"] = "Passenger";
				["Subtype"] = "Ground";
				["Passengers"] = 3;
				["Subtype2"] = "VeryFast";
				["Value"] = "100|0|3";
				["Speed"] = 100;
				["Spell"] = 60136;
				["Riding"] = 0;
				["SpellName"] = "Grand Caravan Mammoth";
			};
			[26056] = {
				["Spell"] = 26056;
				["Subtype"] = "VeryFast";
				["ItemName"] = "Green Qiraji Resonating Crystal";
				["Type"] = "Ground";
				["Item"] = 21323;
				["Value"] = "100|75";
				["Speed"] = 100;
				["Taught"] = true;
				["Riding"] = 75;
				["SpellName"] = "Green Qiraji Battle Tank";
			};
			[23510] = {
				["Spell"] = 23510;
				["Subtype"] = "VeryFast";
				["ItemName"] = "Stormpike Battle Charger";
				["Type"] = "Ground";
				["Item"] = 19030;
				["Value"] = "100|150";
				["Speed"] = 100;
				["Taught"] = true;
				["Riding"] = 150;
				["SpellName"] = "Stormpike Battle Charger";
			};
			[59650] = {
				["Spell"] = 59650;
				["Subtype"] = "VeryFast";
				["ItemName"] = "Reins of the Black Drake";
				["Type"] = "Flying";
				["Item"] = 43986;
				["Value"] = "280|300";
				["Speed"] = 280;
				["Taught"] = true;
				["Riding"] = 300;
				["SpellName"] = "Black Drake";
			};
			[17462] = {
				["Spell"] = 17462;
				["Subtype"] = "Fast";
				["ItemName"] = "Red Skeletal Horse";
				["Type"] = "Ground";
				["Item"] = 13331;
				["Value"] = "60|75";
				["Speed"] = 60;
				["Taught"] = true;
				["Riding"] = 75;
				["SpellName"] = "Red Skeletal Horse";
			};
			[61451] = {
				["ItemName"] = "Flying Carpet";
				["Subtype"] = "Slow";
				["Type"] = "Ground";
				["Spell"] = 61451;
				["Item"] = 44554;
				["Value"] = "0|0";
				["Taught"] = true;
				["Speed"] = 0;
				["Riding"] = 0;
				["SpellName"] = "Flying Carpet";
			};
			[32244] = {
				["Spell"] = 32244;
				["Subtype"] = "Fast";
				["ItemName"] = "Blue Wind Rider";
				["Type"] = "Flying";
				["Item"] = 25475;
				["Value"] = "60|225";
				["Speed"] = 60;
				["Taught"] = true;
				["Riding"] = 225;
				["SpellName"] = "Blue Wind Rider";
			};
			[35712] = {
				["Spell"] = 35712;
				["Subtype"] = "VeryFast";
				["ItemName"] = "Great Green Elekk";
				["Type"] = "Ground";
				["Item"] = 29746;
				["Value"] = "100|150";
				["Speed"] = 100;
				["Taught"] = true;
				["Riding"] = 150;
				["SpellName"] = "Great Green Elekk";
			};
			[39800] = {
				["Spell"] = 39800;
				["Subtype"] = "VeryFast";
				["ItemName"] = "Red Riding Nether Ray";
				["Type"] = "Flying";
				["Item"] = 32317;
				["Value"] = "280|300";
				["Speed"] = 280;
				["Taught"] = true;
				["Riding"] = 300;
				["SpellName"] = "Red Riding Nether Ray";
			};
			[32292] = {
				["Spell"] = 32292;
				["Subtype"] = "VeryFast";
				["ItemName"] = "Swift Purple Gryphon";
				["Type"] = "Flying";
				["Item"] = 25529;
				["Value"] = "280|300";
				["Speed"] = 280;
				["Taught"] = true;
				["Riding"] = 300;
				["SpellName"] = "Swift Purple Gryphon";
			};
			[59961] = {
				["Type"] = "Flying";
				["Value"] = "280|0";
				["Subtype"] = "VeryFast";
				["Speed"] = 280;
				["Spell"] = 59961;
				["Riding"] = 0;
				["SpellName"] = "Red Proto-Drake";
			};
			[46199] = {
				["Spell"] = 46199;
				["Subtype"] = "VeryFast";
				["ItemName"] = "X-51 Nether-Rocket X-TREME";
				["Type"] = "Flying";
				["Item"] = 35226;
				["Value"] = "280|300";
				["Speed"] = 280;
				["Taught"] = true;
				["Riding"] = 300;
				["SpellName"] = "X-51 Nether-Rocket X-TREME";
			};
			[43810] = {
				["Type"] = "Flying";
				["Value"] = "280|0";
				["Subtype"] = "VeryFast";
				["Speed"] = 280;
				["Spell"] = 43810;
				["Riding"] = 0;
				["SpellName"] = "Frost Wyrm";
			};
			[10789] = {
				["Spell"] = 10789;
				["Subtype"] = "Fast";
				["ItemName"] = "Reins of the Spotted Frostsaber";
				["Type"] = "Ground";
				["Item"] = 8632;
				["Value"] = "60|75";
				["Speed"] = 60;
				["Taught"] = true;
				["Riding"] = 75;
				["SpellName"] = "Spotted Frostsaber";
			};
			[23240] = {
				["Spell"] = 23240;
				["Subtype"] = "VeryFast";
				["ItemName"] = "Swift White Ram";
				["Type"] = "Ground";
				["Item"] = 18785;
				["Value"] = "100|150";
				["Speed"] = 100;
				["Taught"] = true;
				["Riding"] = 150;
				["SpellName"] = "Swift White Ram";
			};
			[10793] = {
				["Spell"] = 10793;
				["Subtype"] = "Fast";
				["ItemName"] = "Reins of the Striped Nightsaber";
				["Type"] = "Ground";
				["Item"] = 8629;
				["Value"] = "60|75";
				["Speed"] = 60;
				["Taught"] = true;
				["Riding"] = 75;
				["SpellName"] = "Striped Nightsaber";
			};
			[10795] = {
				["Type"] = "Ground";
				["Value"] = "60|0";
				["Subtype"] = "Fast";
				["Speed"] = 60;
				["Spell"] = 10795;
				["Riding"] = 0;
				["SpellName"] = "Ivory Raptor";
			};
			[32240] = {
				["Spell"] = 32240;
				["Subtype"] = "Fast";
				["ItemName"] = "Snowy Gryphon";
				["Type"] = "Flying";
				["Item"] = 25472;
				["Value"] = "60|225";
				["Speed"] = 60;
				["Taught"] = true;
				["Riding"] = 225;
				["SpellName"] = "Snowy Gryphon";
			};
			[10799] = {
				["Spell"] = 10799;
				["Subtype"] = "Fast";
				["ItemName"] = "Whistle of the Violet Raptor";
				["Type"] = "Ground";
				["Item"] = 8592;
				["Value"] = "60|75";
				["Speed"] = 60;
				["Taught"] = true;
				["Riding"] = 75;
				["SpellName"] = "Violet Raptor";
			};
			[17458] = {
				["Type"] = "Ground";
				["Value"] = "60|0";
				["Subtype"] = "Fast";
				["Speed"] = 60;
				["Spell"] = 17458;
				["Riding"] = 0;
				["SpellName"] = "Fluorescent Green Mechanostrider";
			};
			[18992] = {
				["Spell"] = 18992;
				["Subtype"] = "VeryFast";
				["ItemName"] = "Teal Kodo";
				["Type"] = "Ground";
				["Item"] = 15293;
				["Value"] = "100|150";
				["Speed"] = 100;
				["Taught"] = true;
				["Riding"] = 150;
				["SpellName"] = "Teal Kodo";
			};
			[50869] = {
				["Type"] = "Ground";
				["Value"] = "60|0";
				["Subtype"] = "Fast";
				["Speed"] = 60;
				["Spell"] = 50869;
				["Riding"] = 0;
				["SpellName"] = "Brewfest Kodo";
			};
			[59802] = {
				["Type"] = "Passenger";
				["Subtype"] = "Ground";
				["Passengers"] = 3;
				["Subtype2"] = "VeryFast";
				["Value"] = "100|0|3";
				["Speed"] = 100;
				["Spell"] = 59802;
				["Riding"] = 0;
				["SpellName"] = "Grand Ice Mammoth";
			};
			[59810] = {
				["Type"] = "Passenger";
				["Subtype"] = "Ground";
				["Passengers"] = 3;
				["Subtype2"] = "VeryFast";
				["Value"] = "100|0|3";
				["Speed"] = 100;
				["Spell"] = 59810;
				["Riding"] = 0;
				["SpellName"] = "Grand Black War Mammoth";
			};
			[32296] = {
				["Spell"] = 32296;
				["Subtype"] = "VeryFast";
				["ItemName"] = "Swift Yellow Wind Rider";
				["Type"] = "Flying";
				["Item"] = 25532;
				["Value"] = "280|300";
				["Speed"] = 280;
				["Taught"] = true;
				["Riding"] = 300;
				["SpellName"] = "Swift Yellow Wind Rider";
			};
			[59571] = {
				["Spell"] = 59571;
				["Subtype"] = "VeryFast";
				["ItemName"] = "Reins of the Twilight Drake";
				["Type"] = "Flying";
				["Item"] = 43954;
				["Value"] = "280|300";
				["Speed"] = 280;
				["Taught"] = true;
				["Riding"] = 300;
				["SpellName"] = "Twilight Drake";
			};
			[49379] = {
				["Spell"] = 49379;
				["Subtype"] = "VeryFast";
				["ItemName"] = "Great Brewfest Kodo";
				["Type"] = "Ground";
				["Item"] = 37828;
				["Value"] = "100|150";
				["Speed"] = 100;
				["Taught"] = true;
				["Riding"] = 150;
				["SpellName"] = "Great Brewfest Kodo";
			};
			[24252] = {
				["Spell"] = 24252;
				["Subtype"] = "VeryFast";
				["ItemName"] = "Swift Zulian Tiger";
				["Type"] = "Ground";
				["Item"] = 19902;
				["Value"] = "100|150";
				["Speed"] = 100;
				["Taught"] = true;
				["Riding"] = 150;
				["SpellName"] = "Swift Zulian Tiger";
			};
			[23228] = {
				["Spell"] = 23228;
				["Subtype"] = "VeryFast";
				["ItemName"] = "Swift White Steed";
				["Type"] = "Ground";
				["Item"] = 18778;
				["Value"] = "100|150";
				["Speed"] = 100;
				["Taught"] = true;
				["Riding"] = 150;
				["SpellName"] = "Swift White Steed";
			};
			[23220] = {
				["Type"] = "Ground";
				["Value"] = "100|0";
				["Subtype"] = "VeryFast";
				["Speed"] = 100;
				["Spell"] = 23220;
				["Riding"] = 0;
				["SpellName"] = "Swift Dawnsaber";
			};
			[42781] = {
				["Spell"] = 42781;
				["Value"] = "0|0";
				["Subtype"] = "Slow";
				["Speed"] = 0;
				["Type"] = "Ground";
				["Riding"] = 0;
				["SpellName"] = "Upper Deck - Spectral Tiger Mount";
			};
			[41514] = {
				["Spell"] = 41514;
				["Subtype"] = "VeryFast";
				["ItemName"] = "Reins of the Azure Netherwing Drake";
				["Type"] = "Flying";
				["Item"] = 32858;
				["Value"] = "280|300";
				["Speed"] = 280;
				["Taught"] = true;
				["Riding"] = 300;
				["SpellName"] = "Azure Netherwing Drake";
			};
			[59572] = {
				["Type"] = "Ground";
				["Value"] = "100|0";
				["Subtype"] = "VeryFast";
				["Speed"] = 100;
				["Spell"] = 59572;
				["Riding"] = 0;
				["SpellName"] = "Black Polar Bear";
			};
			[58615] = {
				["Type"] = "Flying";
				["Value"] = "310|0";
				["Subtype"] = "ExtremelyFast";
				["Speed"] = 310;
				["Spell"] = 58615;
				["Riding"] = 0;
				["SpellName"] = "Brutal Nether Drake";
			};
			[60424] = {
				["Type"] = "Passenger";
				["Subtype"] = "Ground";
				["Passengers"] = 2;
				["Subtype2"] = "VeryFast";
				["Spell"] = 60424;
				["Taught"] = true;
				["Item"] = 44413;
				["Value"] = "100|150|2";
				["Speed"] = 100;
				["ItemName"] = "Mekgineer's Chopper";
				["Riding"] = 150;
				["SpellName"] = "Mekgineer's Chopper";
			};
			[34406] = {
				["Spell"] = 34406;
				["Subtype"] = "Fast";
				["ItemName"] = "Brown Elekk";
				["Type"] = "Ground";
				["Item"] = 28481;
				["Value"] = "60|75";
				["Speed"] = 60;
				["Taught"] = true;
				["Riding"] = 75;
				["SpellName"] = "Brown Elekk";
			};
			[61444] = {
				["Type"] = "Passenger";
				["Subtype"] = "Flying";
				["Passengers"] = 2;
				["Subtype2"] = "VeryFast";
				["Value"] = "280|0|2";
				["Speed"] = 280;
				["Spell"] = 61444;
				["Riding"] = 0;
				["SpellName"] = "Swift Shadoweave Carpet";
			};
			[10873] = {
				["Spell"] = 10873;
				["Subtype"] = "Fast";
				["ItemName"] = "Red Mechanostrider";
				["Type"] = "Ground";
				["Item"] = 8563;
				["Value"] = "60|75";
				["Speed"] = 60;
				["Taught"] = true;
				["Riding"] = 75;
				["SpellName"] = "Red Mechanostrider";
			};
			[25953] = {
				["Spell"] = 25953;
				["Subtype"] = "VeryFast";
				["ItemName"] = "Blue Qiraji Resonating Crystal";
				["Type"] = "Ground";
				["Item"] = 21218;
				["Value"] = "100|75";
				["Speed"] = 100;
				["Taught"] = true;
				["Riding"] = 75;
				["SpellName"] = "Blue Qiraji Battle Tank";
			};
			[35713] = {
				["Spell"] = 35713;
				["Subtype"] = "VeryFast";
				["ItemName"] = "Great Blue Elekk";
				["Type"] = "Ground";
				["Item"] = 29745;
				["Value"] = "100|150";
				["Speed"] = 100;
				["Taught"] = true;
				["Riding"] = 150;
				["SpellName"] = "Great Blue Elekk";
			};
			[39801] = {
				["Spell"] = 39801;
				["Subtype"] = "VeryFast";
				["ItemName"] = "Purple Riding Nether Ray";
				["Type"] = "Flying";
				["Item"] = 32316;
				["Value"] = "280|300";
				["Speed"] = 280;
				["Taught"] = true;
				["Riding"] = 300;
				["SpellName"] = "Purple Riding Nether Ray";
			};
			[61229] = {
				["Spell"] = 61229;
				["Subtype"] = "VeryFast";
				["ItemName"] = "Armored Snowy Gryphon";
				["Type"] = "Flying";
				["Item"] = 44689;
				["Value"] = "280|300";
				["Speed"] = 280;
				["Taught"] = true;
				["Riding"] = 300;
				["SpellName"] = "Armored Snowy Gryphon";
			};
			[17481] = {
				["Spell"] = 17481;
				["Subtype"] = "VeryFast";
				["ItemName"] = "Deathcharger's Reins";
				["Type"] = "Ground";
				["Item"] = 13335;
				["Value"] = "100|150";
				["Speed"] = 100;
				["Taught"] = true;
				["Riding"] = 150;
				["SpellName"] = "Rivendare's Deathcharger";
			};
			[39315] = {
				["Spell"] = 39315;
				["Subtype"] = "VeryFast";
				["ItemName"] = "Reins of the Cobalt Riding Talbuk";
				["Type"] = "Ground";
				["Item"] = 31830;
				["Value"] = "100|150";
				["Speed"] = 100;
				["Taught"] = true;
				["Riding"] = 150;
				["SpellName"] = "Cobalt Riding Talbuk";
			};
			[17456] = {
				["Type"] = "Ground";
				["Value"] = "60|0";
				["Subtype"] = "Fast";
				["Speed"] = 60;
				["Spell"] = 17456;
				["Riding"] = 0;
				["SpellName"] = "Red and Blue Mechanostrider";
			};
			[35025] = {
				["Spell"] = 35025;
				["Subtype"] = "VeryFast";
				["ItemName"] = "Swift Green Hawkstrider";
				["Type"] = "Ground";
				["Item"] = 29223;
				["Value"] = "100|150";
				["Speed"] = 100;
				["Taught"] = true;
				["Riding"] = 150;
				["SpellName"] = "Swift Green Hawkstrider";
			};
			[48025] = {
				["Type"] = "Variable";
				["Value"] = "-1|0";
				["Subtype"] = "All";
				["Speed"] = -1;
				["Spell"] = 48025;
				["Riding"] = 0;
				["SpellName"] = "Headless Horseman's Mount";
			};
			[60002] = {
				["Type"] = "Flying";
				["Value"] = "280|0";
				["Subtype"] = "VeryFast";
				["Speed"] = 280;
				["Spell"] = 60002;
				["Riding"] = 0;
				["SpellName"] = "Time-Lost Proto-Drake";
			};
			[35020] = {
				["Spell"] = 35020;
				["Subtype"] = "Fast";
				["ItemName"] = "Blue Hawkstrider";
				["Type"] = "Ground";
				["Item"] = 29220;
				["Value"] = "60|75";
				["Speed"] = 60;
				["Taught"] = true;
				["Riding"] = 75;
				["SpellName"] = "Blue Hawkstrider";
			};
			[35028] = {
				["Spell"] = 35028;
				["Subtype"] = "VeryFast";
				["ItemName"] = "Swift Warstrider";
				["Type"] = "Ground";
				["Item"] = 34129;
				["Value"] = "100|150";
				["Speed"] = 100;
				["Taught"] = true;
				["Riding"] = 150;
				["SpellName"] = "Swift Warstrider";
			};
			[33630] = {
				["Type"] = "Ground";
				["Value"] = "60|0";
				["Subtype"] = "Fast";
				["Speed"] = 60;
				["Spell"] = 33630;
				["Riding"] = 0;
				["SpellName"] = "Blue Mechanostrider";
			};
			[61309] = {
				["Type"] = "Passenger";
				["Subtype"] = "Flying";
				["Passengers"] = 2;
				["Subtype2"] = "VeryFast";
				["Spell"] = 61309;
				["Taught"] = true;
				["Item"] = 44558;
				["Value"] = "280|0|2";
				["Speed"] = 280;
				["ItemName"] = "Magnificent Flying Carpet";
				["Riding"] = 0;
				["SpellName"] = "Magnificent Flying Carpet";
			};
			[47037] = {
				["Type"] = "Ground";
				["Value"] = "100|0";
				["Subtype"] = "VeryFast";
				["Speed"] = 100;
				["Spell"] = 47037;
				["Riding"] = 0;
				["SpellName"] = "Swift War  Elekk";
			};
			[50870] = {
				["Type"] = "Ground";
				["Value"] = "60|0";
				["Subtype"] = "Fast";
				["Speed"] = 60;
				["Spell"] = 50870;
				["Riding"] = 0;
				["SpellName"] = "Brewfest Ram";
			};
			[18363] = {
				["Type"] = "Ground";
				["Value"] = "60|0";
				["Subtype"] = "Fast";
				["Speed"] = 60;
				["Spell"] = 18363;
				["Riding"] = 0;
				["SpellName"] = "Riding Kodo";
			};
			[59811] = {
				["Type"] = "Passenger";
				["Subtype"] = "Ground";
				["Passengers"] = 3;
				["Subtype2"] = "VeryFast";
				["Value"] = "100|0|3";
				["Speed"] = 100;
				["Spell"] = 59811;
				["Riding"] = 0;
				["SpellName"] = "Grand Black War Mammoth";
			};
			[472] = {
				["Spell"] = 472;
				["Subtype"] = "Fast";
				["ItemName"] = "Pinto Bridle";
				["Type"] = "Ground";
				["Item"] = 2414;
				["Value"] = "60|75";
				["Speed"] = 60;
				["Taught"] = true;
				["Riding"] = 75;
				["SpellName"] = "Pinto";
			};
			[51412] = {
				["Spell"] = 51412;
				["Subtype"] = "VeryFast";
				["ItemName"] = "Big Battle Bear";
				["Type"] = "Ground";
				["Item"] = 38576;
				["Value"] = "100|150";
				["Speed"] = 100;
				["Taught"] = true;
				["Riding"] = 150;
				["SpellName"] = "Big Battle Bear";
			};
			[40192] = {
				["ItemName"] = "Ashes of Al'ar";
				["Subtype"] = "ExtremelyFast";
				["Spell"] = 40192;
				["Type"] = "Flying";
				["Item"] = 32458;
				["Taught"] = true;
				["Value"] = "310|300";
				["Speed"] = 310;
				["Riding"] = 300;
				["SpellName"] = "Ashes of Al'ar";
			};
			[22718] = {
				["Spell"] = 22718;
				["Subtype"] = "VeryFast";
				["ItemName"] = "Black War Kodo";
				["Type"] = "Ground";
				["Item"] = 29466;
				["Value"] = "100|150";
				["Speed"] = 100;
				["Taught"] = true;
				["Riding"] = 150;
				["SpellName"] = "Black War Kodo";
			};
			[22722] = {
				["Spell"] = 22722;
				["Subtype"] = "VeryFast";
				["ItemName"] = "Red Skeletal Warhorse";
				["Type"] = "Ground";
				["Item"] = 29470;
				["Value"] = "100|150";
				["Speed"] = 100;
				["Taught"] = true;
				["Riding"] = 150;
				["SpellName"] = "Red Skeletal Warhorse";
			};
			[60114] = {
				["Spell"] = 60114;
				["Subtype"] = "VeryFast";
				["ItemName"] = "Reins of the Armored Brown Bear";
				["Type"] = "Ground";
				["Item"] = 44225;
				["Value"] = "100|150";
				["Speed"] = 100;
				["Taught"] = true;
				["Riding"] = 150;
				["SpellName"] = "Armored Brown Bear";
			};
			[41252] = {
				["Spell"] = 41252;
				["Subtype"] = "VeryFast";
				["ItemName"] = "Reins of the Raven Lord";
				["Type"] = "Ground";
				["Item"] = 32768;
				["Value"] = "100|150";
				["Speed"] = 100;
				["Taught"] = true;
				["Riding"] = 150;
				["SpellName"] = "Raven Lord";
			};
			[41515] = {
				["Spell"] = 41515;
				["Subtype"] = "VeryFast";
				["ItemName"] = "Reins of the Cobalt Netherwing Drake";
				["Type"] = "Flying";
				["Item"] = 32859;
				["Value"] = "280|300";
				["Speed"] = 280;
				["Taught"] = true;
				["Riding"] = 300;
				["SpellName"] = "Cobalt Netherwing Drake";
			};
			[23248] = {
				["Spell"] = 23248;
				["Subtype"] = "VeryFast";
				["ItemName"] = "Great Gray Kodo";
				["Type"] = "Ground";
				["Item"] = 18795;
				["Value"] = "100|150";
				["Speed"] = 100;
				["Taught"] = true;
				["Riding"] = 150;
				["SpellName"] = "Great Gray Kodo";
			};
			[23252] = {
				["Spell"] = 23252;
				["Subtype"] = "VeryFast";
				["ItemName"] = "Horn of the Swift Gray Wolf";
				["Type"] = "Ground";
				["Item"] = 18798;
				["Value"] = "100|150";
				["Speed"] = 100;
				["Taught"] = true;
				["Riding"] = 150;
				["SpellName"] = "Swift Gray Wolf";
			};
			[17450] = {
				["Spell"] = 17450;
				["Subtype"] = "VeryFast";
				["ItemName"] = "Whistle of the Ivory Raptor";
				["Type"] = "Ground";
				["Item"] = 13317;
				["Value"] = "100|150";
				["Speed"] = 100;
				["Taught"] = true;
				["Riding"] = 150;
				["SpellName"] = "Ivory Raptor";
			};
			[34407] = {
				["Type"] = "Ground";
				["Value"] = "100|0";
				["Subtype"] = "VeryFast";
				["Speed"] = 100;
				["Spell"] = 34407;
				["Riding"] = 0;
				["SpellName"] = "Great Elite Elekk";
			};
			[44151] = {
				["Spell"] = 44151;
				["Subtype"] = "VeryFast";
				["ItemName"] = "Turbo-Charged Flying Machine Control";
				["Type"] = "Flying";
				["Item"] = 34061;
				["Value"] = "280|0";
				["Speed"] = 280;
				["Taught"] = true;
				["Riding"] = 0;
				["SpellName"] = "Turbo-Charged Flying Machine";
			};
			[61467] = {
				["Type"] = "Passenger";
				["Subtype"] = "Ground";
				["Passengers"] = 3;
				["Subtype2"] = "VeryFast";
				["Value"] = "100|0|3";
				["Speed"] = 100;
				["Spell"] = 61467;
				["Riding"] = 0;
				["SpellName"] = "Grand Black War Mammoth";
			};
			[34898] = {
				["Spell"] = 34898;
				["Subtype"] = "VeryFast";
				["ItemName"] = "Reins of the Silver War Talbuk";
				["Type"] = "Ground";
				["Item"] = 29229;
				["Value"] = "100|150";
				["Speed"] = 100;
				["Taught"] = true;
				["Riding"] = 150;
				["SpellName"] = "Silver War Talbuk";
			};
			[61469] = {
				["Type"] = "Passenger";
				["Subtype"] = "Ground";
				["Passengers"] = 3;
				["Subtype2"] = "VeryFast";
				["Spell"] = 61469;
				["Taught"] = true;
				["Item"] = 44086;
				["Value"] = "100|150|3";
				["Speed"] = 100;
				["ItemName"] = "Reins of the Grand Ice Mammoth";
				["Riding"] = 150;
				["SpellName"] = "Summon Grand Ice Mammoth";
			};
			[39802] = {
				["Spell"] = 39802;
				["Subtype"] = "VeryFast";
				["ItemName"] = "Silver Riding Nether Ray";
				["Type"] = "Flying";
				["Item"] = 32318;
				["Value"] = "280|300";
				["Speed"] = 280;
				["Taught"] = true;
				["Riding"] = 300;
				["SpellName"] = "Silver Riding Nether Ray";
			};
			[61230] = {
				["Spell"] = 61230;
				["Subtype"] = "VeryFast";
				["ItemName"] = "Armored Blue Wind Rider";
				["Type"] = "Flying";
				["Item"] = 44690;
				["Value"] = "280|300";
				["Speed"] = 280;
				["Taught"] = true;
				["Riding"] = 300;
				["SpellName"] = "Armored Blue Wind Rider";
			};
			[44153] = {
				["Spell"] = 44153;
				["Subtype"] = "Fast";
				["ItemName"] = "Flying Machine Control";
				["Type"] = "Flying";
				["Item"] = 34060;
				["Value"] = "60|0";
				["Speed"] = 60;
				["Taught"] = true;
				["Riding"] = 0;
				["SpellName"] = "Flying Machine";
			};
			[39316] = {
				["Spell"] = 39316;
				["Subtype"] = "VeryFast";
				["ItemName"] = "Reins of the Dark Riding Talbuk";
				["Type"] = "Ground";
				["Item"] = 28915;
				["Value"] = "100|150";
				["Speed"] = 100;
				["Taught"] = true;
				["Riding"] = 150;
				["SpellName"] = "Dark Riding Talbuk";
			};
			[51960] = {
				["Type"] = "Flying";
				["Value"] = "280|0";
				["Subtype"] = "VeryFast";
				["Speed"] = 280;
				["Spell"] = 51960;
				["Riding"] = 0;
				["SpellName"] = "Frostwyrm Mount";
			};
			[23219] = {
				["Spell"] = 23219;
				["Subtype"] = "VeryFast";
				["ItemName"] = "Reins of the Swift Mistsaber";
				["Type"] = "Ground";
				["Item"] = 18767;
				["Value"] = "100|150";
				["Speed"] = 100;
				["Taught"] = true;
				["Riding"] = 150;
				["SpellName"] = "Swift Mistsaber";
			};
			[42692] = {
				["ItemName"] = "Rickety Magic Broom";
				["Subtype"] = "Slow";
				["Type"] = "Ground";
				["Item"] = 33189;
				["Value"] = "0|0";
				["Speed"] = 0;
				["Spell"] = 42692;
				["Riding"] = 0;
				["SpellName"] = "Rickety Magic Broom";
			};
			[58983] = {
				["Spell"] = 58983;
				["Value"] = "0|0";
				["Subtype"] = "Slow";
				["Speed"] = 0;
				["Type"] = "Ground";
				["Riding"] = 0;
				["SpellName"] = "Big Blizzard Bear";
			};
			[42668] = {
				["Spell"] = 42668;
				["Subtype"] = "VeryFast";
				["Item1"] = 33184;
				["ItemName"] = "Swift Magic Broom";
				["Item"] = 33182;
				["Speed"] = 280;
				["Value"] = "280|150";
				["Type"] = "Flying";
				["Riding"] = 150;
				["SpellName"] = "Swift Flying Broom";
			};
			[61294] = {
				["Type"] = "Flying";
				["Value"] = "280|0";
				["Subtype"] = "VeryFast";
				["Speed"] = 280;
				["Spell"] = 61294;
				["Riding"] = 0;
				["SpellName"] = "Green Proto-Drake";
			};
			[32245] = {
				["Spell"] = 32245;
				["Subtype"] = "Fast";
				["ItemName"] = "Green Wind Rider";
				["Type"] = "Flying";
				["Item"] = 25476;
				["Value"] = "60|225";
				["Speed"] = 60;
				["Taught"] = true;
				["Riding"] = 225;
				["SpellName"] = "Green Wind Rider";
			};
			[34790] = {
				["Spell"] = 34790;
				["Subtype"] = "VeryFast";
				["ItemName"] = "Reins of the Dark War Talbuk";
				["Type"] = "Ground";
				["Item"] = 29228;
				["Value"] = "100|150";
				["Speed"] = 100;
				["Taught"] = true;
				["Riding"] = 150;
				["SpellName"] = "Dark War Talbuk";
			};
			[59788] = {
				["Spell"] = 59788;
				["Subtype"] = "VeryFast";
				["ItemName"] = "Reins of the Black War Mammoth";
				["Type"] = "Ground";
				["Item"] = 44077;
				["Value"] = "100|150";
				["Speed"] = 100;
				["Taught"] = true;
				["Riding"] = 150;
				["SpellName"] = "Black War Mammoth";
			};
			[35018] = {
				["Spell"] = 35018;
				["Subtype"] = "Fast";
				["ItemName"] = "Purple Hawkstrider";
				["Type"] = "Ground";
				["Item"] = 29222;
				["Value"] = "60|75";
				["Speed"] = 60;
				["Taught"] = true;
				["Riding"] = 75;
				["SpellName"] = "Purple Hawkstrider";
			};
			[59804] = {
				["Type"] = "Passenger";
				["Subtype"] = "Ground";
				["Passengers"] = 3;
				["Subtype2"] = "VeryFast";
				["Value"] = "100|0|3";
				["Speed"] = 100;
				["Spell"] = 59804;
				["Riding"] = 0;
				["SpellName"] = "Grand Ice Mammoth";
			};
			[580] = {
				["Spell"] = 580;
				["Subtype"] = "Fast";
				["ItemName"] = "Horn of the Timber Wolf";
				["Type"] = "Ground";
				["Item"] = 1132;
				["Value"] = "60|75";
				["Speed"] = 60;
				["Taught"] = true;
				["Riding"] = 75;
				["SpellName"] = "Timber Wolf";
			};
			[459] = {
				["Type"] = "Ground";
				["Value"] = "60|0";
				["Subtype"] = "Fast";
				["Speed"] = 60;
				["Spell"] = 459;
				["Riding"] = 0;
				["SpellName"] = "Gray Wolf";
			};
			[59573] = {
				["Type"] = "Ground";
				["Value"] = "100|0";
				["Subtype"] = "VeryFast";
				["Speed"] = 100;
				["Spell"] = 59573;
				["Riding"] = 0;
				["SpellName"] = "Brown Polar Bear";
			};
			[8980] = {
				["Type"] = "Ground";
				["Value"] = "60|0";
				["Subtype"] = "Fast";
				["Speed"] = 60;
				["Spell"] = 8980;
				["Riding"] = 0;
				["SpellName"] = "Skeletal Horse";
			};
			[8395] = {
				["Spell"] = 8395;
				["Subtype"] = "Fast";
				["ItemName"] = "Whistle of the Emerald Raptor";
				["Type"] = "Ground";
				["Item"] = 8588;
				["Value"] = "60|75";
				["Speed"] = 60;
				["Taught"] = true;
				["Riding"] = 75;
				["SpellName"] = "Emerald Raptor";
			};
			[458] = {
				["Spell"] = 458;
				["Subtype"] = "Fast";
				["ItemName"] = "Brown Horse Bridle";
				["Type"] = "Ground";
				["Item"] = 5656;
				["Value"] = "60|75";
				["Speed"] = 60;
				["Taught"] = true;
				["Riding"] = 75;
				["SpellName"] = "Brown Horse";
			};
			[32289] = {
				["Spell"] = 32289;
				["Subtype"] = "VeryFast";
				["ItemName"] = "Swift Red Gryphon";
				["Type"] = "Flying";
				["Item"] = 25527;
				["Value"] = "280|300";
				["Speed"] = 280;
				["Taught"] = true;
				["Riding"] = 300;
				["SpellName"] = "Swift Red Gryphon";
			};
			[60118] = {
				["Type"] = "Ground";
				["Value"] = "100|0";
				["Subtype"] = "VeryFast";
				["Speed"] = 100;
				["Spell"] = 60118;
				["Riding"] = 0;
				["SpellName"] = "Black War Bear";
			};
			[581] = {
				["Type"] = "Ground";
				["Value"] = "60|0";
				["Subtype"] = "Fast";
				["Speed"] = 60;
				["Spell"] = 581;
				["Riding"] = 0;
				["SpellName"] = "Winter Wolf";
			};
			[6896] = {
				["Type"] = "Ground";
				["Value"] = "60|0";
				["Subtype"] = "Fast";
				["Speed"] = 60;
				["Spell"] = 6896;
				["Riding"] = 0;
				["SpellName"] = "Black Ram";
			};
			[6897] = {
				["Type"] = "Ground";
				["Value"] = "60|0";
				["Subtype"] = "Fast";
				["Speed"] = 60;
				["Spell"] = 6897;
				["Riding"] = 0;
				["SpellName"] = "Blue Ram";
			};
			[16059] = {
				["Type"] = "Ground";
				["Value"] = "60|0";
				["Subtype"] = "Fast";
				["Speed"] = 60;
				["Spell"] = 16059;
				["Riding"] = 0;
				["SpellName"] = "Tawny Sabercat";
			};
			[6899] = {
				["Spell"] = 6899;
				["Subtype"] = "Fast";
				["ItemName"] = "Brown Ram";
				["Type"] = "Ground";
				["Item"] = 5872;
				["Value"] = "60|75";
				["Speed"] = 60;
				["Taught"] = true;
				["Riding"] = 75;
				["SpellName"] = "Brown Ram";
			};
			[61446] = {
				["Type"] = "Passenger";
				["Subtype"] = "Flying";
				["Passengers"] = 2;
				["Subtype2"] = "VeryFast";
				["Value"] = "280|0|2";
				["Speed"] = 280;
				["Spell"] = 61446;
				["Riding"] = 0;
				["SpellName"] = "Swift Spellfire Carpet";
			};
			[43900] = {
				["Spell"] = 43900;
				["Subtype"] = "VeryFast";
				["ItemName"] = "Swift Brewfest Ram";
				["Type"] = "Ground";
				["Item"] = 33977;
				["Value"] = "100|150";
				["Speed"] = 100;
				["Taught"] = true;
				["Riding"] = 150;
				["SpellName"] = "Swift Brewfest Ram";
			};
			[32297] = {
				["Spell"] = 32297;
				["Subtype"] = "VeryFast";
				["ItemName"] = "Swift Purple Wind Rider";
				["Type"] = "Flying";
				["Item"] = 25533;
				["Value"] = "280|300";
				["Speed"] = 280;
				["Taught"] = true;
				["Riding"] = 300;
				["SpellName"] = "Swift Purple Wind Rider";
			};
			[10969] = {
				["Spell"] = 10969;
				["Subtype"] = "Fast";
				["ItemName"] = "Blue Mechanostrider";
				["Type"] = "Ground";
				["Item"] = 8595;
				["Value"] = "60|75";
				["Speed"] = 60;
				["Taught"] = true;
				["Riding"] = 75;
				["SpellName"] = "Blue Mechanostrider";
			};
			[39803] = {
				["Spell"] = 39803;
				["Subtype"] = "VeryFast";
				["ItemName"] = "Blue Riding Nether Ray";
				["Type"] = "Flying";
				["Item"] = 32319;
				["Value"] = "280|300";
				["Speed"] = 280;
				["Taught"] = true;
				["Riding"] = 300;
				["SpellName"] = "Blue Riding Nether Ray";
			};
			[54753] = {
				["Type"] = "Ground";
				["Value"] = "100|0";
				["Subtype"] = "VeryFast";
				["Speed"] = 100;
				["Spell"] = 54753;
				["Riding"] = 0;
				["SpellName"] = "White Polar Bear Mount";
			};
			[43899] = {
				["Spell"] = 43899;
				["Subtype"] = "Fast";
				["ItemName"] = "Brewfest Ram";
				["Type"] = "Ground";
				["Item"] = 33976;
				["Value"] = "60|75";
				["Speed"] = 60;
				["Taught"] = true;
				["Riding"] = 75;
				["SpellName"] = "Brewfest Ram";
			};
			[32345] = {
				["ItemName"] = "Peep's Whistle";
				["Subtype"] = "ExtremelyFast";
				["Spell"] = 32345;
				["Type"] = "Flying";
				["Item"] = 25596;
				["Taught"] = true;
				["Value"] = "310|0";
				["Speed"] = 310;
				["Riding"] = 0;
				["SpellName"] = "Peep the Phoenix Mount";
			};
			[6653] = {
				["Spell"] = 6653;
				["Subtype"] = "Fast";
				["ItemName"] = "Horn of the Dire Wolf";
				["Type"] = "Ground";
				["Item"] = 5665;
				["Value"] = "60|75";
				["Speed"] = 60;
				["Taught"] = true;
				["Riding"] = 75;
				["SpellName"] = "Dire Wolf";
			};
			[6654] = {
				["Spell"] = 6654;
				["Subtype"] = "Fast";
				["ItemName"] = "Horn of the Brown Wolf";
				["Type"] = "Ground";
				["Item"] = 5668;
				["Value"] = "60|75";
				["Speed"] = 60;
				["Taught"] = true;
				["Riding"] = 75;
				["SpellName"] = "Brown Wolf";
			};
			[59996] = {
				["Type"] = "Flying";
				["Value"] = "280|0";
				["Subtype"] = "VeryFast";
				["Speed"] = 280;
				["Spell"] = 59996;
				["Riding"] = 0;
				["SpellName"] = "Blue Proto-Drake";
			};
			[37015] = {
				["ItemName"] = "Swift Nether Drake";
				["Subtype"] = "ExtremelyFast";
				["Spell"] = 37015;
				["Type"] = "Flying";
				["Item"] = 30609;
				["Taught"] = true;
				["Value"] = "310|300";
				["Speed"] = 310;
				["Riding"] = 300;
				["SpellName"] = "Swift Nether Drake";
			};
			[48027] = {
				["Spell"] = 48027;
				["Subtype"] = "VeryFast";
				["ItemName"] = "Reins of the Black War Elekk";
				["Type"] = "Ground";
				["Item"] = 35906;
				["Value"] = "100|150";
				["Speed"] = 100;
				["Taught"] = true;
				["Riding"] = 150;
				["SpellName"] = "Black War Elekk";
			};
			[42680] = {
				["ItemName"] = "Old Magic Broom";
				["Subtype"] = "Fast";
				["Spell"] = 42680;
				["Item"] = 33183;
				["Value"] = "60|75";
				["Speed"] = 60;
				["Type"] = "Ground";
				["Riding"] = 75;
				["SpellName"] = "Magic Broom";
			};
			[468] = {
				["Type"] = "Ground";
				["Value"] = "60|0";
				["Subtype"] = "Fast";
				["Speed"] = 60;
				["Spell"] = 468;
				["Riding"] = 0;
				["SpellName"] = "White Stallion";
			};
			[18990] = {
				["Spell"] = 18990;
				["Subtype"] = "Fast";
				["ItemName"] = "Brown Kodo";
				["Type"] = "Ground";
				["Item"] = 15290;
				["Value"] = "60|75";
				["Speed"] = 60;
				["Taught"] = true;
				["Riding"] = 75;
				["SpellName"] = "Brown Kodo";
			};
			[54729] = {
				["Spell"] = 54729;
				["Subtype"] = "Flying";
				["ItemName"] = "Winged Steed of the Ebon Blade";
				["Type"] = "Variable";
				["Item"] = 40775;
				["Value"] = "-1|225";
				["Speed"] = -1;
				["Taught"] = true;
				["Riding"] = 225;
				["SpellName"] = "Winged Steed of the Ebon Blade";
			};
		};
		["Critters"] = {
			[24986] = {
				["Type"] = "Normal";
				["Spell"] = 24986;
				["SpellName"] = "Summon Baby Murloc (Green)";
			};
			[24990] = {
				["Type"] = "Normal";
				["Spell"] = 24990;
				["SpellName"] = "Summon Baby Murloc (Purple)";
			};
			[61351] = {
				["Type"] = "Normal";
				["Spell"] = 61351;
				["SpellName"] = "Cobra Hatchling";
			};
			[25018] = {
				["Type"] = "Normal";
				["Spell"] = 25018;
				["SpellName"] = "Murki";
			};
			[35907] = {
				["Spell"] = 35907;
				["Item"] = 29901;
				["Taught"] = true;
				["Type"] = "Normal";
				["ItemName"] = "Blue Moth Egg";
				["SpellName"] = "Blue Moth";
			};
			[28871] = {
				["Spell"] = 28871;
				["Item"] = 23083;
				["Taught"] = true;
				["Type"] = "Normal";
				["ItemName"] = "Captured Flame";
				["SpellName"] = "Spirit of Summer";
			};
			[45127] = {
				["Spell"] = 45127;
				["Item"] = 34493;
				["Taught"] = true;
				["Type"] = "Normal";
				["ItemName"] = "Dragon Kite";
				["SpellName"] = "Dragon Kite";
			};
			[46426] = {
				["Spell"] = 46426;
				["Item"] = 35350;
				["Taught"] = true;
				["Type"] = "Normal";
				["ItemName"] = "Chuck's Bucket";
				["SpellName"] = "Chuck";
			};
			[42609] = {
				["Spell"] = 42609;
				["Item"] = 33154;
				["Taught"] = true;
				["Type"] = "Normal";
				["ItemName"] = "Sinister Squashling";
				["SpellName"] = "Sinister Squashling";
			};
			[45175] = {
				["Type"] = "Normal";
				["Spell"] = 45175;
				["SpellName"] = "Silver Pig";
			};
			[46203] = {
				["Spell"] = 46203;
				["Item"] = 35227;
				["Ignore"] = true;
				["Type"] = "Normal";
				["ItemName"] = "Goblin Weather Machine - Prototype 01-B";
				["SpellName"] = "Goblin Weather Machine";
			};
			[23811] = {
				["Spell"] = 23811;
				["Item"] = 19450;
				["Taught"] = true;
				["Type"] = "Normal";
				["ItemName"] = "A Jubling's Tiny Home";
				["SpellName"] = "Jubling";
			};
			[36027] = {
				["Spell"] = 36027;
				["Item"] = 29953;
				["Taught"] = true;
				["Type"] = "Normal";
				["ItemName"] = "Golden Dragonhawk Hatchling";
				["SpellName"] = "Golden Dragonhawk Hatchling";
			};
			[17707] = {
				["Spell"] = 17707;
				["Item"] = 13583;
				["Taught"] = true;
				["Type"] = "Normal";
				["ItemName"] = "Panda Collar";
				["SpellName"] = "Panda Cub";
			};
			[17468] = {
				["Type"] = "Normal";
				["Spell"] = 17468;
				["SpellName"] = "Pet Fish";
			};
			[45048] = {
				["Type"] = "Normal";
				["Spell"] = 45048;
				["SpellName"] = "Clockwork Rocket Bot";
			};
			[39709] = {
				["Spell"] = 39709;
				["Item"] = 32233;
				["Taught"] = true;
				["Type"] = "Normal";
				["ItemName"] = "Wolpertinger's Tankard";
				["SpellName"] = "Wolpertinger";
			};
			[32298] = {
				["Spell"] = 32298;
				["Item"] = 25535;
				["Taught"] = true;
				["Type"] = "Normal";
				["ItemName"] = "Netherwhelp's Collar";
				["SpellName"] = "Netherwhelp";
			};
			[25162] = {
				["Spell"] = 25162;
				["Item"] = 20769;
				["Taught"] = true;
				["Type"] = "Normal";
				["ItemName"] = "Disgusting Oozeling";
				["SpellName"] = "Disgusting Oozeling";
			};
			[28740] = {
				["Spell"] = 28740;
				["Item"] = 23015;
				["Taught"] = true;
				["Type"] = "Normal";
				["ItemName"] = "Rat Cage";
				["SpellName"] = "Whiskers the Rat";
			};
			[28505] = {
				["Type"] = "Normal";
				["Spell"] = 28505;
				["SpellName"] = "Poley";
			};
			[35239] = {
				["Spell"] = 35239;
				["Item"] = 29364;
				["Taught"] = true;
				["Type"] = "Normal";
				["ItemName"] = "Brown Rabbit Crate";
				["SpellName"] = "Brown Rabbit";
			};
			[23429] = {
				["Spell"] = 23429;
				["Item"] = 18964;
				["Taught"] = true;
				["Type"] = "Normal";
				["ItemName"] = "Turtle Egg (Loggerhead)";
				["SpellName"] = "Loggerhead Snapjaw";
			};
			[36028] = {
				["Spell"] = 36028;
				["Item"] = 29956;
				["Taught"] = true;
				["Type"] = "Normal";
				["ItemName"] = "Red Dragonhawk Hatchling";
				["SpellName"] = "Red Dragonhawk Hatchling";
			};
			[40634] = {
				["Spell"] = 40634;
				["Item"] = 32622;
				["Taught"] = true;
				["Type"] = "Normal";
				["ItemName"] = "Elekk Training Collar";
				["SpellName"] = "Peanut";
			};
			[24987] = {
				["Type"] = "Normal";
				["Spell"] = 24987;
				["SpellName"] = "Summon Baby Murloc (Orange)";
			};
			[26529] = {
				["ItemName"] = "Jingling Bell";
				["Spell"] = 26529;
				["Item"] = 21308;
				["Subtype"] = "Snowball";
				["Taught"] = true;
				["Type"] = "Reagented";
				["Value"] = "17202";
				["SpellName"] = "Winter Reindeer";
			};
			[26533] = {
				["ItemName"] = "Green Helper Box";
				["Spell"] = 26533;
				["Item"] = 21301;
				["Subtype"] = "Snowball";
				["Taught"] = true;
				["Type"] = "Reagented";
				["Value"] = "17202";
				["SpellName"] = "Father Winter's Helper";
			};
			[26541] = {
				["ItemName"] = "Red Helper Box";
				["Spell"] = 26541;
				["Item"] = 21305;
				["Subtype"] = "Snowball";
				["Taught"] = true;
				["Type"] = "Reagented";
				["Value"] = "17202";
				["SpellName"] = "Winter's Little Helper";
			};
			[35909] = {
				["Spell"] = 35909;
				["Item"] = 29902;
				["Taught"] = true;
				["Type"] = "Normal";
				["ItemName"] = "Red Moth Egg";
				["SpellName"] = "Red Moth";
			};
			[58636] = {
				["Spell"] = 58636;
				["Item"] = 43517;
				["Taught"] = true;
				["Type"] = "Normal";
				["ItemName"] = "Penguin Egg";
				["SpellName"] = "Chilly the Penguin";
			};
			[53082] = {
				["Spell"] = 53082;
				["Item"] = 39656;
				["Taught"] = true;
				["Type"] = "Normal";
				["ItemName"] = "Tyrael's Hilt";
				["SpellName"] = "Mini Tyrael";
			};
			[43918] = {
				["Spell"] = 43918;
				["Item"] = 33993;
				["Taught"] = true;
				["Type"] = "Normal";
				["ItemName"] = "Mojo";
				["SpellName"] = "Mojo";
			};
			[36029] = {
				["Spell"] = 36029;
				["Item"] = 29957;
				["Taught"] = true;
				["Type"] = "Normal";
				["ItemName"] = "Silver Dragonhawk Hatchling";
				["SpellName"] = "Silver Dragonhawk Hatchling";
			};
			[59250] = {
				["Spell"] = 59250;
				["Item"] = 43698;
				["Taught"] = true;
				["Type"] = "Normal";
				["ItemName"] = "Giant Sewer Rat";
				["SpellName"] = "Giant Sewer Rat";
			};
			[17708] = {
				["Spell"] = 17708;
				["Item"] = 13584;
				["Taught"] = true;
				["Type"] = "Normal";
				["ItemName"] = "Diablo Stone";
				["SpellName"] = "Mini Diablo";
			};
			[10673] = {
				["Spell"] = 10673;
				["Item"] = 8485;
				["Taught"] = true;
				["Type"] = "Normal";
				["ItemName"] = "Cat Carrier (Bombay)";
				["SpellName"] = "Bombay Cat";
			};
			[10675] = {
				["Spell"] = 10675;
				["Item"] = 8491;
				["Taught"] = true;
				["Type"] = "Normal";
				["ItemName"] = "Cat Carrier (Black Tabby)";
				["SpellName"] = "Black Tabby Cat";
			};
			[10677] = {
				["Spell"] = 10677;
				["Item"] = 8490;
				["Taught"] = true;
				["Type"] = "Normal";
				["ItemName"] = "Cat Carrier (Siamese)";
				["SpellName"] = "Siamese Cat";
			};
			[17469] = {
				["Type"] = "Normal";
				["Spell"] = 17469;
				["SpellName"] = "Pet Stone";
			};
			[10681] = {
				["Type"] = "Normal";
				["Spell"] = 10681;
				["SpellName"] = "Summon Cockatoo";
			};
			[19772] = {
				["Spell"] = 19772;
				["Item"] = 15996;
				["Taught"] = true;
				["Type"] = "Normal";
				["ItemName"] = "Lifelike Mechanical Toad";
				["SpellName"] = "Lifelike Toad";
			};
			[10685] = {
				["Spell"] = 10685;
				["Item"] = 11023;
				["Taught"] = true;
				["Type"] = "Normal";
				["ItemName"] = "Ancona Chicken";
				["SpellName"] = "Ancona Chicken";
			};
			[33057] = {
				["Type"] = "Normal";
				["Spell"] = 33057;
				["SpellName"] = "Summon Mighty Mr. Pinchy";
			};
			[10695] = {
				["Spell"] = 10695;
				["Item"] = 10822;
				["Taught"] = true;
				["Type"] = "Normal";
				["ItemName"] = "Dark Whelpling";
				["SpellName"] = "Dark Whelpling";
			};
			[10697] = {
				["Spell"] = 10697;
				["Item"] = 8499;
				["Taught"] = true;
				["Type"] = "Normal";
				["ItemName"] = "Tiny Crimson Whelpling";
				["SpellName"] = "Crimson Whelpling";
			};
			[10699] = {
				["Type"] = "Normal";
				["Spell"] = 10699;
				["SpellName"] = "Summon Bronze Whelpling";
			};
			[10701] = {
				["Type"] = "Normal";
				["Spell"] = 10701;
				["SpellName"] = "Summon Dart Frog";
			};
			[10703] = {
				["Spell"] = 10703;
				["Item"] = 11027;
				["Taught"] = true;
				["Type"] = "Normal";
				["ItemName"] = "Wood Frog Box";
				["SpellName"] = "Wood Frog";
			};
			[10705] = {
				["Type"] = "Normal";
				["Spell"] = 10705;
				["SpellName"] = "Summon Eagle Owl";
			};
			[10707] = {
				["Spell"] = 10707;
				["Item"] = 8500;
				["Taught"] = true;
				["Type"] = "Normal";
				["ItemName"] = "Great Horned Owl";
				["SpellName"] = "Great Horned Owl";
			};
			[10709] = {
				["Spell"] = 10709;
				["Item"] = 10394;
				["Taught"] = true;
				["Type"] = "Normal";
				["ItemName"] = "Prairie Dog Whistle";
				["SpellName"] = "Brown Prairie Dog";
			};
			[10711] = {
				["Spell"] = 10711;
				["Item"] = 8497;
				["Taught"] = true;
				["Type"] = "Normal";
				["ItemName"] = "Rabbit Crate (Snowshoe)";
				["SpellName"] = "Snowshoe Rabbit";
			};
			[12243] = {
				["Spell"] = 12243;
				["Item"] = 10398;
				["Taught"] = true;
				["Type"] = "Normal";
				["ItemName"] = "Mechanical Chicken";
				["SpellName"] = "Mechanical Chicken";
			};
			[10715] = {
				["Type"] = "Normal";
				["Spell"] = 10715;
				["SpellName"] = "Summon Blue Racer";
			};
			[10717] = {
				["Spell"] = 10717;
				["Item"] = 10392;
				["Taught"] = true;
				["Type"] = "Normal";
				["ItemName"] = "Crimson Snake";
				["SpellName"] = "Crimson Snake";
			};
			[10719] = {
				["Type"] = "Normal";
				["Spell"] = 10719;
				["SpellName"] = "Summon Ribbon Snake";
			};
			[10721] = {
				["Type"] = "Normal";
				["Spell"] = 10721;
				["SpellName"] = "Summon Elven Wisp";
			};
			[23430] = {
				["Type"] = "Normal";
				["Spell"] = 23430;
				["SpellName"] = "Olive Snapjaw";
			};
			[40405] = {
				["Spell"] = 40405;
				["Item"] = 32498;
				["Taught"] = true;
				["Type"] = "Normal";
				["ItemName"] = "Fortune Coin";
				["SpellName"] = "Lucky";
			};
			[24988] = {
				["Spell"] = 24988;
				["Item"] = 30360;
				["Taught"] = true;
				["Type"] = "Normal";
				["ItemName"] = "Lurky's Egg";
				["SpellName"] = "Lurky";
			};
			[13548] = {
				["Spell"] = 13548;
				["Item"] = 11110;
				["Taught"] = true;
				["Type"] = "Normal";
				["ItemName"] = "Chicken Egg";
				["SpellName"] = "Westfall Chicken";
			};
			[33050] = {
				["Spell"] = 33050;
				["Item"] = 27445;
				["Taught"] = true;
				["Type"] = "Normal";
				["ItemName"] = "Magical Crawdad Box";
				["SpellName"] = "Magical Crawdad";
			};
			[27570] = {
				["Spell"] = 27570;
				["Item"] = 22235;
				["Taught"] = true;
				["Type"] = "Normal";
				["ItemName"] = "Truesilver Shafted Arrow";
				["SpellName"] = "Peddlefeet";
			};
			[48406] = {
				["Spell"] = 48406;
				["Item"] = 37297;
				["Taught"] = true;
				["Type"] = "Normal";
				["ItemName"] = "Gold Medallion";
				["SpellName"] = "Spirit of Competition";
			};
			[55068] = {
				["Type"] = "Normal";
				["Spell"] = 55068;
				["SpellName"] = "Mr. Chilly";
			};
			[30152] = {
				["Type"] = "Normal";
				["Spell"] = 30152;
				["SpellName"] = "White Tiger Cub";
			};
			[40549] = {
				["Spell"] = 40549;
				["Item"] = 32588;
				["Taught"] = true;
				["Type"] = "Normal";
				["ItemName"] = "Banana Charm";
				["SpellName"] = "Bananas";
			};
			[23530] = {
				["Type"] = "Normal";
				["Spell"] = 23530;
				["SpellName"] = "Tiny Red Dragon";
			};
			[25849] = {
				["Spell"] = 25849;
				["Item"] = 21168;
				["Taught"] = true;
				["Type"] = "Normal";
				["ItemName"] = "Baby Shark";
				["SpellName"] = "Baby Shark";
			};
			[40613] = {
				["Spell"] = 40613;
				["Item"] = 32617;
				["Taught"] = true;
				["Type"] = "Normal";
				["ItemName"] = "Sleepy Willy";
				["SpellName"] = "Willy";
			};
			[36031] = {
				["Spell"] = 36031;
				["Item"] = 29958;
				["Taught"] = true;
				["Type"] = "Normal";
				["ItemName"] = "Blue Dragonhawk Hatchling";
				["SpellName"] = "Blue Dragonhawk Hatchling";
			};
			[43697] = {
				["Spell"] = 43697;
				["Item"] = 33816;
				["Taught"] = true;
				["Type"] = "Normal";
				["ItemName"] = "Toothy's Bucket";
				["SpellName"] = "Toothy";
			};
			[17709] = {
				["Spell"] = 17709;
				["Item"] = 13582;
				["Taught"] = true;
				["Type"] = "Normal";
				["ItemName"] = "Zergling Leash";
				["SpellName"] = "Zergling";
			};
			[4055] = {
				["Spell"] = 4055;
				["Item"] = 4401;
				["Taught"] = true;
				["Type"] = "Normal";
				["ItemName"] = "Mechanical Squirrel Box";
				["SpellName"] = "Mechanical Squirrel";
			};
			[15648] = {
				["Type"] = "Normal";
				["Spell"] = 15648;
				["SpellName"] = "Corrupted Kitten";
			};
			[16450] = {
				["Spell"] = 16450;
				["Item"] = 12529;
				["Taught"] = true;
				["Type"] = "Normal";
				["ItemName"] = "Smolderweb Carrier";
				["SpellName"] = "Smolderweb Hatchling";
			};
			[61348] = {
				["Type"] = "Normal";
				["Spell"] = 61348;
				["SpellName"] = "Tickbird Hatchling";
			};
			[28738] = {
				["Spell"] = 28738;
				["Item"] = 23002;
				["Taught"] = true;
				["Type"] = "Normal";
				["ItemName"] = "Turtle Box";
				["SpellName"] = "Speedy";
			};
			[28487] = {
				["Type"] = "Normal";
				["Spell"] = 28487;
				["SpellName"] = "Terky";
			};
			[53316] = {
				["Spell"] = 53316;
				["Item"] = 39973;
				["Taught"] = true;
				["Type"] = "Normal";
				["ItemName"] = "Ghostly Skull";
				["SpellName"] = "Ghostly Skull";
			};
			[40319] = {
				["Type"] = "Normal";
				["Spell"] = 40319;
				["SpellName"] = "Lucky";
			};
			[23431] = {
				["Type"] = "Normal";
				["Spell"] = 23431;
				["SpellName"] = "Leatherback Snapjaw";
			};
			[52615] = {
				["Type"] = "Normal";
				["Spell"] = 52615;
				["SpellName"] = "Frosty";
			};
			[43698] = {
				["Spell"] = 43698;
				["Item"] = 33818;
				["Taught"] = true;
				["Type"] = "Normal";
				["ItemName"] = "Muckbreath's Bucket";
				["SpellName"] = "Muckbreath";
			};
			[35910] = {
				["Spell"] = 35910;
				["Item"] = 29903;
				["Taught"] = true;
				["Type"] = "Normal";
				["ItemName"] = "Yellow Moth Egg";
				["SpellName"] = "Yellow Moth";
			};
			[35911] = {
				["Spell"] = 35911;
				["Item"] = 29904;
				["Taught"] = true;
				["Type"] = "Normal";
				["ItemName"] = "White Moth Egg";
				["SpellName"] = "White Moth";
			};
			[24985] = {
				["Type"] = "Normal";
				["Spell"] = 24985;
				["SpellName"] = "Summon Baby Murloc (Blue)";
			};
			[24989] = {
				["Type"] = "Normal";
				["Spell"] = 24989;
				["SpellName"] = "Summon Baby Murloc (Pink)";
			};
			[10679] = {
				["Spell"] = 10679;
				["Item"] = 8489;
				["Taught"] = true;
				["Type"] = "Normal";
				["ItemName"] = "Cat Carrier (White Kitten)";
				["SpellName"] = "White Kitten";
			};
			[26010] = {
				["Spell"] = 26010;
				["Item"] = 21277;
				["Taught"] = true;
				["Type"] = "Normal";
				["ItemName"] = "Tranquil Mechanical Yeti";
				["SpellName"] = "Tranquil Mechanical Yeti";
			};
			[61349] = {
				["Type"] = "Normal";
				["Item"] = 39899;
				["Taught"] = true;
				["ItemName"] = "White Tickbird Hatchling";
				["Spell"] = 61349;
				["SpellName"] = "White Tickbird Hatchling";
			};
			[61357] = {
				["Spell"] = 61357;
				["Item"] = 44723;
				["Taught"] = true;
				["Type"] = "Normal";
				["ItemName"] = "Nurtured Penguin Egg";
				["SpellName"] = "Pengu";
			};
			[54187] = {
				["Spell"] = 54187;
				["Item"] = 34425;
				["Taught"] = true;
				["Type"] = "Normal";
				["ItemName"] = "Clockwork Rocket Bot";
				["SpellName"] = "Clockwork Rocket Bot";
			};
			[51149] = {
				["Value"] = "HEADSLOT";
				["ItemName"] = "Don Carlos' Famous Hat";
				["Item"] = 38506;
				["Subtype"] = "Head";
				["InventorySlot"] = "HEADSLOT";
				["Type"] = "Equipment";
				["Spell"] = 51149;
				["SpellName"] = "Summon Coyote Spirit";
			};
			[23432] = {
				["Type"] = "Normal";
				["Spell"] = 23432;
				["SpellName"] = "Hawksbill Snapjaw";
			};
			[46599] = {
				["Spell"] = 46599;
				["Item"] = 35504;
				["Taught"] = true;
				["Type"] = "Normal";
				["ItemName"] = "Phoenix Hatchling";
				["SpellName"] = "Phoenix Hatchling";
			};
			[26045] = {
				["ItemName"] = "Snowman Kit";
				["Spell"] = 26045;
				["Item"] = 21309;
				["Subtype"] = "Snowball";
				["Taught"] = true;
				["Type"] = "Reagented";
				["Value"] = "17202";
				["SpellName"] = "Tiny Snowman";
			};
			[40614] = {
				["Spell"] = 40614;
				["Item"] = 32616;
				["Taught"] = true;
				["Type"] = "Normal";
				["ItemName"] = "Egbert's Egg";
				["SpellName"] = "Egbert";
			};
			[48408] = {
				["Type"] = "Normal";
				["Item"] = 37298;
				["Taught"] = true;
				["ItemName"] = "Competitor's Souvenir";
				["Spell"] = 48408;
				["SpellName"] = "Essence of Competition";
			};
			[35156] = {
				["Spell"] = 35156;
				["Item"] = 29363;
				["Taught"] = true;
				["Type"] = "Normal";
				["ItemName"] = "Mana Wyrmling";
				["SpellName"] = "Mana Wyrmling";
			};
			[10687] = {
				["Type"] = "Normal";
				["Spell"] = 10687;
				["SpellName"] = "Summon White Plymouth Rock";
			};
			[15999] = {
				["Spell"] = 15999;
				["Item"] = 12264;
				["Taught"] = true;
				["Type"] = "Normal";
				["ItemName"] = "Worg Carrier";
				["SpellName"] = "Worg Pup";
			};
			[45125] = {
				["Spell"] = 45125;
				["Item"] = 34492;
				["Taught"] = true;
				["Type"] = "Normal";
				["ItemName"] = "Rocket Chicken";
				["SpellName"] = "Rocket Chicken";
			};
			[45174] = {
				["Type"] = "Normal";
				["Spell"] = 45174;
				["SpellName"] = "Golden Pig";
			};
			[24696] = {
				["Spell"] = 24696;
				["Item"] = 20371;
				["Taught"] = true;
				["Type"] = "Normal";
				["ItemName"] = "Blue Murloc Egg";
				["SpellName"] = "Murky";
			};
			[23531] = {
				["Type"] = "Normal";
				["Spell"] = 23531;
				["SpellName"] = "Tiny Green Dragon";
			};
			[30156] = {
				["Spell"] = 30156;
				["Item"] = 23713;
				["Taught"] = true;
				["Type"] = "Normal";
				["ItemName"] = "Hippogryph Hatchling";
				["SpellName"] = "Hippogryph Hatchling";
			};
			[46425] = {
				["Spell"] = 46425;
				["Item"] = 35349;
				["Taught"] = true;
				["Type"] = "Normal";
				["ItemName"] = "Snarly's Bucket";
				["SpellName"] = "Snarly";
			};
			[15049] = {
				["Spell"] = 15049;
				["Item"] = 11826;
				["Taught"] = true;
				["Type"] = "Normal";
				["ItemName"] = "Lil' Smoky";
				["SpellName"] = "Lil' Smoky";
			};
			[44369] = {
				["Type"] = "Normal";
				["Spell"] = 44369;
				["SpellName"] = "Summon Baby Pink Elekk";
			};
			[10720] = {
				["Type"] = "Normal";
				["Spell"] = 10720;
				["SpellName"] = "Summon Scarlet Snake";
			};
			[53768] = {
				["Type"] = "Normal";
				["Spell"] = 53768;
				["SpellName"] = "Haunted";
			};
			[10704] = {
				["Spell"] = 10704;
				["Item"] = 11026;
				["Taught"] = true;
				["Type"] = "Normal";
				["ItemName"] = "Tree Frog Box";
				["SpellName"] = "Tree Frog";
			};
			[35157] = {
				["Type"] = "Normal";
				["Spell"] = 35157;
				["SpellName"] = "Summon Spotted Rabbit";
			};
			[51851] = {
				["Type"] = "Normal";
				["Spell"] = 51851;
				["SpellName"] = "Vampiric Batling";
			};
			[49964] = {
				["Spell"] = 49964;
				["Item"] = 38050;
				["Taught"] = true;
				["Type"] = "Normal";
				["ItemName"] = "Soul-Trader Beacon";
				["SpellName"] = "Ethereal Soul-Trader";
			};
			[10698] = {
				["Spell"] = 10698;
				["Item"] = 8498;
				["Taught"] = true;
				["Type"] = "Normal";
				["ItemName"] = "Tiny Emerald Whelpling";
				["SpellName"] = "Emerald Whelpling";
			};
			[10674] = {
				["Spell"] = 10674;
				["Item"] = 8486;
				["Taught"] = true;
				["Type"] = "Normal";
				["ItemName"] = "Cat Carrier (Cornish Rex)";
				["SpellName"] = "Cornish Rex Cat";
			};
			[10676] = {
				["Spell"] = 10676;
				["Item"] = 8487;
				["Taught"] = true;
				["Type"] = "Normal";
				["ItemName"] = "Cat Carrier (Orange Tabby)";
				["SpellName"] = "Orange Tabby Cat";
			};
			[10678] = {
				["Spell"] = 10678;
				["Item"] = 8488;
				["Taught"] = true;
				["Type"] = "Normal";
				["ItemName"] = "Cat Carrier (Silver Tabby)";
				["SpellName"] = "Silver Tabby Cat";
			};
			[10680] = {
				["Spell"] = 10680;
				["Item"] = 8496;
				["Taught"] = true;
				["Type"] = "Normal";
				["ItemName"] = "Parrot Cage (Cockatiel)";
				["SpellName"] = "Cockatiel";
			};
			[10682] = {
				["Spell"] = 10682;
				["Item"] = 8494;
				["Taught"] = true;
				["Type"] = "Normal";
				["ItemName"] = "Parrot Cage (Hyacinth Macaw)";
				["SpellName"] = "Hyacinth Macaw";
			};
			[10684] = {
				["Spell"] = 10684;
				["Item"] = 8495;
				["Taught"] = true;
				["Type"] = "Normal";
				["ItemName"] = "Parrot Cage (Senegal)";
				["SpellName"] = "Senegal";
			};
			[10686] = {
				["Type"] = "Normal";
				["Spell"] = 10686;
				["SpellName"] = "Summon Prairie Chicken";
			};
			[10688] = {
				["Spell"] = 10688;
				["Item"] = 10393;
				["Taught"] = true;
				["Type"] = "Normal";
				["ItemName"] = "Cockroach";
				["SpellName"] = "Cockroach";
			};
			[61350] = {
				["Spell"] = 61350;
				["Item"] = 44721;
				["Taught"] = true;
				["Type"] = "Normal";
				["ItemName"] = "Proto-Drake Whelp";
				["SpellName"] = "Proto-Drake Whelp";
			};
			[39181] = {
				["Spell"] = 39181;
				["Item"] = 31760;
				["Taught"] = true;
				["Type"] = "Normal";
				["ItemName"] = "Miniwing";
				["SpellName"] = "Miniwing";
			};
			[40990] = {
				["Spell"] = 40990;
				["Item"] = 40653;
				["Taught"] = true;
				["Type"] = "Normal";
				["ItemName"] = "Reeking Pet Carrier";
				["SpellName"] = "Stinker";
			};
			[10696] = {
				["Spell"] = 10696;
				["Item"] = 34535;
				["Taught"] = true;
				["Type"] = "Normal";
				["ItemName"] = "Azure Whelpling";
				["SpellName"] = "Azure Whelpling";
			};
			[51716] = {
				["Spell"] = 51716;
				["Item"] = 38628;
				["Taught"] = true;
				["Type"] = "Normal";
				["ItemName"] = "Nether Ray Fry";
				["SpellName"] = "Nether Ray Fry";
			};
			[10700] = {
				["Type"] = "Normal";
				["Spell"] = 10700;
				["SpellName"] = "Summon Faeling";
			};
			[10702] = {
				["Type"] = "Normal";
				["Spell"] = 10702;
				["SpellName"] = "Summon Island Frog";
			};
			[28739] = {
				["Spell"] = 28739;
				["Item"] = 23007;
				["Taught"] = true;
				["Type"] = "Normal";
				["ItemName"] = "Piglet's Collar";
				["SpellName"] = "Mr. Wiggles";
			};
			[10706] = {
				["Spell"] = 10706;
				["Item"] = 8501;
				["Taught"] = true;
				["Type"] = "Normal";
				["ItemName"] = "Hawk Owl";
				["SpellName"] = "Hawk Owl";
			};
			[10708] = {
				["Type"] = "Normal";
				["Spell"] = 10708;
				["SpellName"] = "Summon Snowy Owl";
			};
			[10710] = {
				["Type"] = "Normal";
				["Spell"] = 10710;
				["SpellName"] = "Summon Cottontail Rabbit";
			};
			[10712] = {
				["Type"] = "Normal";
				["Spell"] = 10712;
				["SpellName"] = "Summon Spotted Rabbit";
			};
			[10714] = {
				["Spell"] = 10714;
				["Item"] = 10360;
				["Taught"] = true;
				["Type"] = "Normal";
				["ItemName"] = "Black Kingsnake";
				["SpellName"] = "Black Kingsnake";
			};
			[10716] = {
				["Spell"] = 10716;
				["Item"] = 10361;
				["Taught"] = true;
				["Type"] = "Normal";
				["ItemName"] = "Brown Snake";
				["SpellName"] = "Brown Snake";
			};
			[10718] = {
				["Type"] = "Normal";
				["Spell"] = 10718;
				["SpellName"] = "Summon Green Water Snake";
			};
			[27241] = {
				["Spell"] = 27241;
				["Item"] = 22114;
				["Taught"] = true;
				["Type"] = "Normal";
				["ItemName"] = "Pink Murloc Egg";
				["SpellName"] = "Gurky";
			};
			[45890] = {
				["Spell"] = 45890;
				["Item"] = 34955;
				["Taught"] = true;
				["Type"] = "Normal";
				["ItemName"] = "Scorched Stone";
				["SpellName"] = "Scorchling";
			};
			[15048] = {
				["Spell"] = 15048;
				["Item"] = 11825;
				["Taught"] = true;
				["Type"] = "Normal";
				["ItemName"] = "Pet Bombling";
				["SpellName"] = "Pet Bombling";
			};
			[23428] = {
				["Type"] = "Normal";
				["Spell"] = 23428;
				["SpellName"] = "Albino Snapjaw";
			};
			[17567] = {
				["Value"] = "HEADSLOT";
				["ItemName"] = "Bloodsail Admiral's Hat";
				["Item"] = 12185;
				["Subtype"] = "Head";
				["InventorySlot"] = "HEADSLOT";
				["Type"] = "Equipment";
				["Spell"] = 17567;
				["SpellName"] = "Summon Blood Parrot";
			};
			[36034] = {
				["Spell"] = 36034;
				["Item"] = 29960;
				["Taught"] = true;
				["Type"] = "Normal";
				["ItemName"] = "Captured Firefly";
				["SpellName"] = "Firefly";
			};
			[15067] = {
				["Spell"] = 15067;
				["Item"] = 11474;
				["Taught"] = true;
				["Type"] = "Normal";
				["ItemName"] = "Sprite Darter Egg";
				["SpellName"] = "Sprite Darter Hatchling";
			};
			[45082] = {
				["Spell"] = 45082;
				["Item"] = 34478;
				["Taught"] = true;
				["Type"] = "Normal";
				["ItemName"] = "Tiny Sporebat";
				["SpellName"] = "Tiny Sporebat";
			};
			[61472] = {
				["Type"] = "Normal";
				["Spell"] = 61472;
				["SpellName"] = "Kirin Tor Familiar";
			};
			[10683] = {
				["Spell"] = 10683;
				["Item"] = 8492;
				["Taught"] = true;
				["Type"] = "Normal";
				["ItemName"] = "Parrot Cage (Green Wing Macaw)";
				["SpellName"] = "Green Wing Macaw";
			};
			[10713] = {
				["Type"] = "Normal";
				["Spell"] = 10713;
				["SpellName"] = "Summon Albino Snake";
			};
		};
	};
}
