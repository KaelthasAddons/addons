--[[
    Database of all minipets and mounts
    $Revision: 88 $
]]--

--[[
Copyright (c) 2008, LordFarlander
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

    * Redistributions of source code must retain the above copyright notice,
      this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright notice,
      this list of conditions and the following disclaimer in the documentation
      and/or other materials provided with the distribution.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
]]--

HEADER = "--\[\[\n"..
    "    Database of all minipets and mounts\n"..
    "    $Revision: 88 $\n"..
    "\]\]--"..
    "\n"..
    "\n"..
    "--\[\[\nCopyright (c) 2008, LordFarlander\n"..
    "All rights reserved.\n"..
    "\n"..
    "Redistribution and use in source and binary forms, with or without\n"..
    "modification, are permitted provided that the following conditions are met:\n"..
    "\n"..
    "    * Redistributions of source code must retain the above copyright notice,\n"..
    "      this list of conditions and the following disclaimer.\n"..
    "    * Redistributions in binary form must reproduce the above copyright notice,\n"..
    "      this list of conditions and the following disclaimer in the documentation\n"..
    "      and/or other materials provided with the distribution.\n"..
    "\n"..
    "THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS \"AS IS\" AND\n"..
    "ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED\n"..
    "WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE\n"..
    "DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR\n"..
    "ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES\n"..
    "(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;\n"..
    "LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON\n"..
    "ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT\n"..
    "(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS\n"..
    "SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.\n"..
    "\]\]--\n"..
    "\n"..
    "if( not LibStub( \"LibPeriodicTable-3.1\", true ) ) then\n    error( \"PT3 must be loaded before data\" );\nend--if\n";

function buildPetAndMountDatabase()
    PetAndMountDatabase = {
        Databases = {
            oldest = {
                WoWVersion = 20403,
                Collections = {
                    Critters = {
                        Normal = {
                            [19450] = true, -- A Jubling's Tiny Home
                            [11023] = true, -- Ancona Chicken
                            [34535] = true, -- Azure Whelpling
                            [32588] = true, -- Banana Charm
                            [10360] = true, -- Black Kingsnake
                            [29958] = true, -- Blue Dragonhawk Hatchling
                            [29901] = true, -- Blue Moth Egg
                            [20371] = true, -- Blue Murloc Egg
                            [29364] = true, -- Brown Rabbit Crate
                            [10361] = true, -- Brown Snake
                            [37298] = true, -- Competitor's Souvenir
                            [29960] = true, -- Captured Firefly
                            [23083] = true, -- Captured Flame
                            [8491]  = true, -- Cat Carrier (Black Tabby)
                            [8485]  = true, -- Cat Carrier (Bombay)
                            [8486]  = true, -- Cat Carrier (Cornish Rex)
                            [8487]  = true, -- Cat Carrier (Orange Tabby)
                            [8490]  = true, -- Cat Carrier (Siamese)
                            [8488]  = true, -- Cat Carrier (Silver Tabby)
                            [8489]  = true, -- Cat Carrier (White Kitten)
                            [11110] = true, -- Chicken Egg
                            [35350] = true, -- Chuck's Bucket
                            [34425] = true, -- Clockwork Rocket Bot
                            [10393] = true, -- Cockroach
                            [10392] = true, -- Crimson Snake
                            [10822] = true, -- Dark Whelpling
                            [34493] = true, -- Dragon Kite
                            [13584] = true, -- Diablo Stone
                            [20769] = true, -- Disgusting Oozeling
                            [32616] = true, -- Egbert's Egg
                            [32622] = true, -- Elekk Training Collar
                            [32498] = true, -- Fortune Coin
                            [37297] = true, -- Gold Medallion
                            [29953] = true, -- Golden Dragonhawk Hatchling
                            [8500]  = true, -- Great Horned Owl
                            [8501]  = true, -- Hawk Owl
                            [23713] = true, -- Hippogryph Hatchling
                            [15996] = true, -- Lifelike Mechanical Toad
                            [11826] = true, -- Lil' Smoky
                            [30360] = true, -- Lurky's Egg
                            [27445] = true, -- Magical Crawdad Box
                            [29363] = true, -- Mana Wyrmling
                            [10398] = true, -- Mechanical Chicken
                            [4401]  = true, -- Mechanical Squirrel Box
                            [31760] = true, -- Miniwing
                            [33993] = true, -- Mojo
                            [33818] = true, -- Muckbreath's Bucket
                            [38628] = true, -- Nether Ray Fry
                            [25535] = true, -- Netherwhelp's Collar
                            [13583] = true, -- Panda Collar
                            [8496]  = true, -- Parrot Cage (Cockatiel)
                            [8492]  = true, -- Parrot Cage (Green Wing Macaw)
                            [8494]  = true, -- Parrot Cage (Hyacinth Macaw)
                            [8495]  = true, -- Parrot Cage (Senegal)
                            [11825] = true, -- Pet Bombling
                            [35504] = true, -- Phoenix Hatchling
                            [23007] = true, -- Piglet's Collar
                            [22114] = true, -- Pink Murloc Egg
                            [10394] = true, -- Prairie Dog Whistle
                            [8497]  = true, -- Rabbit Crate (Snowshoe)
                            [23015] = true, -- Rat Cage
                            [29956] = true, -- Red Dragonhawk Hatchling
                            [29902] = true, -- Red Moth Egg
                            [34492] = true, -- Rocket Chicken
                            [34955] = true, -- Scorched Stone
                            [29957] = true, -- Silver Dragonhawk Hatchling
                            [33154] = true, -- Sinister Squashling
                            [32617] = true, -- Sleepy Willy
                            [12529] = true, -- Smolderweb Carrier
                            [35349] = true, -- Snarly's Bucket
                            [38050] = true, -- Soul-Trader Beacon
                            [11474] = true, -- Sprite Darter Egg
                            [8499]  = true, -- Tiny Crimson Whelpling
                            [8498]  = true, -- Tiny Emerald Whelpling
                            [34478] = true, -- Tiny Spore Bat
                            [33816] = true, -- Toothy's Bucket
                            [31665] = true, -- Toy RC Mortar Tank [[NYA]]
                            [21277] = true, -- Tranquil Mechanical Yeti
                            [11026] = true, -- Tree Frog Box
                            [22235] = true, -- Truesilver Shafted Arrow
                            [23002] = true, -- Turtle Box
                            [39656] = true, -- Tyrael's Hilt
                            [29904] = true, -- White Moth Egg
                            [11027] = true, -- Wood Frog Box
                            [12264] = true, -- Worg Carrier
                            [32233] = true, -- Wolpertinger's Tankard
                            [29903] = true, -- Yellow Moth Egg
                            [13582] = true, -- Zergling Leash
                            }, -- Normal
                        
                        Reagented = { -- Needs an item to summon
                            Snowball = {
                                [21301] = 17202, -- Green Helper Box
                                [21308] = 17202, -- Jingling Bell
                                [21305] = 17202, -- Red Helper Box
                                [21309] = 17202, -- Snowman Kit
                                }, -- Snowball
                            }, -- Reagented

                        Equipment = { -- Needs to be equipped
                            Head = {
                                [12185] = "HEADSLOT", -- Bloodsail Admiral's Hat
                                [38506] = "HEADSLOT", -- Don Carlos' Famous Hat
                                },
                            }, -- Equipment
                
                        Children = { -- Children's week
                            [31880] = true, -- Blood Elf Orphan Whistle
                            [31881] = true, -- Draenei Orphan Whistle
                            [18598] = true, -- Human Orphan Whistle
                            [18597] = true, -- Orcish Orphan Whistle
                            }, -- Children
                            
                        Quest = { -- Used in a quest
                            [30803] = 10629, -- Felhound Whistle for Shizz Work
                            [34253] = 11516, -- Sizzling Embers for Blast the Gateway
                            [12565] = 4506,  -- Winna's Kitten Carrier
                            }, -- Quest
                    }, -- MiniPets
                    
                    Mounts = {
                        Ground = {
                            Slow = { -- +0% speed
                                 Items = {
                                    [33189] = "0|0", -- Rickety Magic Broom
                                    [23720] = "0|0", -- Riding Turtle
                                    },
                                }, -- Slow
        
                            Fast = { -- +60% speed
                                 Items = {
                                    [29221] = "60|75", -- Black Hawkstrider
                                    [29220] = "60|75", -- Blue Hawkstrider
                                    [8595]  = "60|75", -- Blue Mechanostrider
                                    [13332] = "60|75", -- Blue Skeletal Horse
                                    [2411]  = "60|75", -- Black Stallion Bridle
                                    [33976] = "60|75", -- Brewfest Ram
                                    [5656]  = "60|75", -- Brown Horse Bridle
                                    [13333] = "60|75", -- Brown Skeletal Horse
                                    [28481] = "60|75", -- Brown Elekk
                                    [15290] = "60|75", -- Brown Kodo
                                    [5872]  = "60|75", -- Brown Ram
                                    [5655]  = "60|75", -- Chestnut Mare Bridle
                                    [29744] = "60|75", -- Gray Elekk
                                    [15277] = "60|75", -- Gray Kodo
                                    [5864]  = "60|75", -- Gray Ram
                                    [13321] = "60|75", -- Green Mechanostrider
                                    [1041]  = "60|75", -- Horn of the Black Wolf
                                    [5668]  = "60|75", -- Horn of the Brown Wolf
                                    [5665]  = "60|75", -- Horn of the Dire Wolf
                                    [1134]  = "60|75", -- Horn of the Gray Wolf
                                    [1132]  = "60|75", -- Horn of the Timber Wolf
                                    [14062] = "60|75", -- Kodo Mount
                                    [37011] = "60|75", -- Magic Broom
                                    [33183] = "60|75", -- Old Magic Broom
                                    [2414]  = "60|75", -- Pinto Bridle
                                    [29743] = "60|75", -- Purple Elekk
                                    [29222] = "60|75", -- Purple Hawkstrider
                                    [28927] = "60|75", -- Red Hawkstrider
                                    [8563]  = "60|75", -- Red Mechanostrider
                                    [13331] = "60|75", -- Red Skeletal Horse
                                    [21044] = "60|75", -- Reindeer Reins (TEST)
                                    [8627]  = "60|75", -- Reins of the Night saber
                                    [33224] = "60|75", -- Reins of the Spectral Tiger
                                    [8632]  = "60|75", -- Reins of the Spotted Frostsaber
                                    [8631]  = "60|75", -- Reins of the Striped Frostsaber
                                    [8628]  = "60|75", -- Reins of the Spotted Nightsaber
                                    [8629]  = "60|75", -- Reins of the Striped Nightsaber
                                    [13322] = "60|75", -- Unpainted Mechanostrider
                                    [8588]  = "60|75", -- Whistle of the Emerald Raptor
                                    [8591]  = "60|75", -- Whistle of the Turquoise Raptor
                                    [8592]  = "60|75", -- Whistle of the Violet Raptor
                                    [5873]  = "60|75", -- White Ram
                                    },
                                Spells = {
                                    Paladin = {
                                        Alliance = {
                                            [-13819]= "60|75", --Summon Warhorse (Alliance)
                                            },
                                        Horde = {
                                            [-34769]= "60|75", --Summon Warhorse (Horde)
                                            },
                                        },
                                    Warlock = {
                                        [-5784]= "60|75", --Summon Felsteed
                                        },
                                    },
                                }, -- Fast
        
                            VeryFast = { -- +100% speed
                                Items = {
                                    [33809] = "100|150", -- Amani War Bear
                                    [38576] = "100|150", -- Big Battle Bear
                                    [18243] = "100|150", -- Black Battlestrider
                                    [29465] = "100|150", -- Black Battlestrider
                                    [13328] = "100|150", -- Black Ram
                                    [18247] = "100|150", -- Black War Kodo
                                    [29466] = "100|150", -- Black War Kodo
                                    [18244] = "100|150", -- Black War Ram
                                    [29467] = "100|150", -- Black War Ram
                                    [18241] = "100|150", -- Black War Steed Bridle
                                    [29468] = "100|150", -- Black War Steed Bridle
                                    [13335] = "100|150", -- Deathcharger's Reins
                                    [30480] = "100|150", -- Fiery Warhorse's Reins
                                    [13329] = "100|150", -- Frost Ram
                                    [29745] = "100|150", -- Great Blue Elekk
                                    [37828] = "100|150", -- Great Brewfest Kodo
                                    [18794] = "100|150", -- Great Brown Kodo
                                    [18795] = "100|150", -- Great Gray Kodo
                                    [29746] = "100|150", -- Great Green Elekk
                                    [29747] = "100|150", -- Great Purple Elekk
                                    [18793] = "100|150", -- Great White Kodo
                                    [15292] = "100|150", -- Green Kodo
                                    [13334] = "100|150", -- Green Skeletal Warhorse
                                    [12351] = "100|150", -- Horn of the Arctic Wolf
                                    [18245] = "100|150", -- Horn of the Black War Wolf
                                    [29469] = "100|150", -- Horn of the Black War Wolf
                                    [19029] = "100|150", -- Horn of the Frostwolf Howler
                                    [12330] = "100|150", -- Horn of the Red Wolf
                                    [18796] = "100|150", -- Horn of the Swift Brown Wolf
                                    [18798] = "100|150", -- Horn of the Swift Gray Wolf
                                    [18797] = "100|150", -- Horn of the Swift Timber Wolf
                                    [13327] = "100|150", -- Icy Blue Mechanostrider Mod A
                                    [12354] = "100|150", -- Palomino Bridle
                                    [18791] = "100|150", -- Purple Skeletal Warhorse
                                    [29470] = "100|150", -- Red Skeletal Warhorse
                                    [35906] = "100|150", -- Reins of the Black War Elekk
                                    [18242] = "100|150", -- Reins of the Black War Tiger
                                    [29471] = "100|150", -- Reins of the Black War Tiger
                                    [31829] = "100|150", -- Reins of the Cobalt Riding Talbuk
                                    [31830] = "100|150", -- Reins of the Cobalt Riding Talbuk
                                    [29102] = "100|150", -- Reins of the Cobalt War Talbuk
                                    [29227] = "100|150", -- Reins of the Cobalt War Talbuk
                                    [28915] = "100|150", -- Reins of the Dark Riding Talbuk
                                    [29228] = "100|150", -- Reins of the Dark War Talbuk
                                    [12302] = "100|150", -- Reins of the Frostsaber
                                    [12303] = "100|150", -- Reins of the Nightsaber
                                    [32768] = "100|150", -- Reins of the Raven Lord
                                    [31831] = "100|150", -- Reins of the Silver Riding Talbuk
                                    [31832] = "100|150", -- Reins of the Silver Riding Talbuk
                                    [29104] = "100|150", -- Reins of the Silver War Talbuk
                                    [29229] = "100|150", -- Reins of the Silver War Talbuk
                                    [18766] = "100|150", -- Reins of the Swift Frostsaber
                                    [18767] = "100|150", -- Reins of the Swift Mistsaber
                                    [33225] = "100|150", -- Reins of the Swift Spectral Tiger
                                    [18902] = "100|150", -- Reins of the Swift Stormsaber
                                    [31833] = "100|150", -- Reins of the Tan Riding Talbuk
                                    [31834] = "100|150", -- Reins of the Tan Riding Talbuk
                                    [29105] = "100|150", -- Reins of the Tan War Talbuk
                                    [29230] = "100|150", -- Reins of the Tan War Talbuk
                                    [13086] = "100|75",  -- Reins of the Winterspring Frostsaber
                                    [31835] = "100|150", -- Reins of the White Riding Talbuk
                                    [31836] = "100|150", -- Reins of the White Riding Talbuk
                                    [29103] = "100|150", -- Reins of the White War Talbuk
                                    [29231] = "100|150", -- Reins of the White War Talbuk
                                    [19030] = "100|150", -- Stormpike Battle Charger
                                    [18788] = "100|150", -- Swift Blue Raptor
                                    [33977] = "100|150", -- Swift Brewfest Ram
                                    [18786] = "100|150", -- Swift Brown Ram
                                    [18777] = "100|150", -- Swift Brown Steed
                                    [18787] = "100|150", -- Swift Gray Ram
                                    [29223] = "100|150", -- Swift Green Hawkstrider
                                    [18772] = "100|150", -- Swift Green Mechanostrider
                                    [33184] = "100|150", -- Swift Magic Broom
                                    [18789] = "100|150", -- Swift Olive Raptor
                                    [18790] = "100|150", -- Swift Orange Raptor
                                    [18776] = "100|150", -- Swift Palomino
                                    [28936] = "100|150", -- Swift Pink Hawkstrider
                                    [29224] = "100|150", -- Swift Purple Hawkstrider
                                    [19872] = "100|150", -- Swift Razzashi Raptor
                                    [34129] = "100|150", -- Swift Warstrider
                                    [35513] = "100|150", -- Swift White Hawkstrider
                                    [18773] = "100|150", -- Swift White Mechanostrider
                                    [18785] = "100|150", -- Swift White Ram
                                    [18778] = "100|150", -- Swift White Steed
                                    [18774] = "100|150", -- Swift Yellow Mechanostrider
                                    [37719] = "100|150", -- Swift Zhevra
                                    [19902] = "100|150", -- Swift Zulian Tiger
                                    [15293] = "100|150", -- Teal Kodo
                                    [37012] = "100|75",  -- The Horseman's Reins
                                    [18246] = "100|150", -- Whistle of the Black War Raptor
                                    [29472] = "100|150", -- Whistle of the Black War Raptor
                                    [13317] = "100|150", -- Whistle of the Ivory Raptor
                                    [8586]  = "100|150", -- Whistle of the Mottled Red Raptor
                                    [13326] = "100|150", -- White Mechanostrider Mod A
                                    [12353] = "100|150", -- White Stallion Bridle
        
                                    TempleOfAhnQiraj = {
                                        --The only mounts allowed to be used in Temple of Ahn'Qiraj
                                        [21176] = "100|150", -- Black Qiraji Resonating Crystal
                                        [21218] = "100|75",  -- Blue Qiraji Resonating Crystal
                                        [21323] = "100|75",  -- Green Qiraji Resonating Crystal
                                        [21321] = "100|75",  -- Red Qiraji Resonating Crystal
                                        [21324] = "100|75",  -- Yellow Qiraji Resonating Crystal
                                        },
                                    },
                                Spells = {
                                    Paladin = {
                                        Alliance = {
                                            [-23214]= "100|150", --Summon Charger (Alliance)
                                            },
                                        Horde = {
                                            [-34767]= "100|150", --Summon Charger (Horde)
                                            },
                                        },
                                    Warlock = {
                                        [-23161]= "100|150", --Summon Dreadsteed
                                        },
                                    },
                                }, -- VeryFast
                            }, -- Ground
                        Flying = {
                            Fast = { -- +60% speed
                                Items = {
                                    [25475] = "60|225", -- Blue Windrider
                                    [25471] = "60|225", -- Ebon Gryphon
                                    [33176] = "60|225", -- Flying Broom
                                    [34060] = "60|225", -- Flying Machine Control
                                    [25470] = "60|225", -- Golden Gryphon
                                    [25476] = "60|225", -- Green Windrider
                                    [25472] = "60|225", -- Snowy Gryphon
                                    [25474] = "60|225", -- Tawny Windrider
                                    [37012] = "60|225", -- The Horseman's Reins
                                    [35225] = "60|225", -- X-51 Nether-Rocket
                                    },
                                }, -- Fast
                            
                            VeryFast = { -- +280% speed
                                Items = {
                                    [32319] = "280|300", -- Blue Riding Nether Ray
                                    [33999] = "280|300", -- Cenarion War Hippogryph
                                    [32314] = "280|300", -- Green Riding Nether Ray
                                    [32316] = "280|300", -- Purple Riding Nether Ray
                                    [32317] = "280|300", -- Red Riding Nether Ray
                                    [32858] = "280|300", -- Reins of the Azure Netherwing Drake
                                    [32859] = "280|300", -- Reins of the Cobalt Netherwing Drake
                                    [32857] = "280|300", -- Reins of the Onyx Netherwing Drake
                                    [32860] = "280|300", -- Reins of the Purple Netherwing Drake
                                    [32861] = "280|300", -- Reins of the Veridian Netherwing Drake
                                    [32862] = "280|300", -- Reins of the Violet Netherwing Drake
                                    [32318] = "280|300", -- Silver Riding Nether Ray
                                    [25473] = "280|300", -- Swift Blue Gryphon
                                    [33182] = "280|300", -- Swift Flying Broom
                                    [25528] = "280|300", -- Swift Green Gryphon
                                    [25531] = "280|300", -- Swift Green Windrider
                                    [25529] = "280|300", -- Swift Purple Gryphon
                                    [25533] = "280|300", -- Swift Purple Windrider
                                    [25527] = "280|300", -- Swift Red Gryphon
                                    [25477] = "280|300", -- Swift Red Windrider
                                    [25532] = "280|300", -- Swift Yellow Windrider
                                    [37012] = "280|300", -- The Horseman's Reins
                                    [34061] = "280|300", -- Turbo-Charged Flying Machine Control
                                    [35226] = "280|300", -- X-51 Nether-Rocket XTREME
                                    },
                                }, -- VeryFast
        
                            ExtremelyFast = { -- +310% speed
                                Items = {
                                    [32458] = "310|300", -- Ashes of Al'ar
                                    [34092] = "310|300", -- Merciless Nether Drake
                                    [35600] = "310|300", -- Nether Drake Flying Mount (TEST)
                                    [35800] = "310|300", -- Peep the Phoenix
                                    [30609] = "310|300", -- Swift Nether Drake
                                    [37676] = "310|300", -- Vengeful Nether Drake
                                    },
                                }, -- ExtremelyFast
                        }, -- Flying
                    }, -- Mounts
        
                    Spells = {
                        Travel = {
                            Aquatic = {
                                Druid = {
                                    [-1066] = "50", -- Aquatic Form
                                },
                            },
                            Ground = {
                                Druid = {
                                    [-783] = "40", -- Travel Form
                                },
                                Hunter = {
                                    [-5118]  = "30", -- Aspect of the Cheetah
                                    [-13159] = "30", -- Aspect of the Pack
                                },
                                Shaman = {
                                    [-2645] = "40", -- Ghost Wolf
                                },
                            },
                            Flying = {
                                Druid = {
                                    [-33943] = "60",  -- Flight Form
                                    [-40120] = "280", -- Swift Flight Form
                                },
                            },
                        },
                        Teleport = {
                            Items = {
                                [-8690]  = 6948,  -- Hearthstone
                                [-46149] = 35230, -- Teleport: Shattrath (Darnarian's Scroll of Teleportation)
                                [-39937] = 28585, -- There's No Place Like Home (Ruby Slippers)
                                Engineering = {
                                    Goblin = {
                                        [-36890] = 30542, -- Area52 Transporter (Dimensional Ripper - Area 52)
                                        [-23442] = 18984, -- Everlook Transporter (Dimensional Ripper - Everlook)
                                        },
                                    Gnomish = {
                                        [-23452] = 18986, -- Gnomish Transporter (Ultrasafe Transporter: Gadgetzan)
                                        [-30544] = 30544, -- Toshley's Station Transporter (Ultrasafe Transporter: Toshley's Station)
                                        },
                                    },
                                },
                            Mage = {
                                Alliance = {
                                    [-3565]  = true, -- Teleport: Darnassus
                                    [-32271] = true, -- Teleport: Exodar
                                    [-3562]  = true, -- Teleport: Ironforge
                                    [-33690] = true, -- Teleport: Shattrath
                                    [-3561]  = true, -- Teleport: Stormwind
                                    [-49359] = true, -- Teleport: Theramore
                                    },
                                Horde = {
                                    [-3567]  = true, -- Teleport: Orgrimmar
                                    [-35715] = true, -- Teleport: Shattrath
                                    [-32272] = true, -- Teleport: Silvermoon
                                    [-49358] = true, -- Teleport: Stonard
                                    [-3566]  = true, -- Teleport: Thunder Bluff
                                    [-3563]  = true, -- Teleport: Undercity
                                    },
                                },
                            Druid = {
                                [-18960] = true, -- Teleport: Moonglade
                                },
                            Shaman = {
                                [-556]   = true, -- Astral Recall
                                },
                            Translocate = {
                                [-25140] = true,
                                [-25143] = true,
                                [-25649] = true,
                                [-25650] = true,
                                [-25652] = true,
                                [-25666] = true,
                                [-26572] = true,
                                [-29128] = true,
                                [-29129] = true,
                                [-30141] = true,
                                [-32568] = true,
                                [-32569] = true,
                                [-32571] = true,
                                [-32572] = true,
                                [-35376] = true,
                                [-35727] = true,
                                [-35730] = true,
                                [-45368] = true,
                                [-45371] = true,
                                },
                            },
                        },
                    Items = {
                        CritterEnchant = {
                            [35223] = 1, -- Papa Hummel's Old-Fashioned Pet Biscuit
                        },
                        MountEnchant = {
                            [21212] = 1, --Fresh Holly
                            [39477] = 2, --Fresh Dwarven Hops
                            [39476] = 3, --Fresh Goblin Hops
                            [37750] = 4, --Fresh Brewfest Hops
                            [21213] = 5, --Preserved Holly
                            [37816] = 6, --Preserved Brewfest Hops
                            },
                        },
                }, -- Collections
        
                Sets = {},
                
                Shortcuts = {
                    ["PetAndMountDatabase.Spells.Mounts.Ground.VeryFast"] = "m,PetAndMountDatabase.Mounts.Ground.VeryFast.Spells",
                    ["PetAndMountDatabase.Spells.Mounts.Ground.Fast"] = "m,PetAndMountDatabase.Mounts.Ground.Fast.Spells",
                    ["PetAndMountDatabase.Items.Mounts.Ground.Slow"] = "m,PetAndMountDatabase.Mounts.Ground.Slow.Items",
                    ["PetAndMountDatabase.Items.Mounts.Ground.Fast"] = "m,PetAndMountDatabase.Mounts.Ground.Fast.Items",
                    ["PetAndMountDatabase.Items.Mounts.Ground.VeryFast"] = "m,PetAndMountDatabase.Mounts.Ground.VeryFast.Items",
                    ["PetAndMountDatabase.Items.Mounts.Flying.Fast"] = "m,PetAndMountDatabase.Mounts.Flying.Fast.Items",
                    ["PetAndMountDatabase.Items.Mounts.Flying.VeryFast"] = "m,PetAndMountDatabase.Mounts.Flying.VeryFast.Items",
                    ["PetAndMountDatabase.Items.Mounts.Flying.ExtremelyFast"] = "m,PetAndMountDatabase.Mounts.Flying.ExtremelyFast.Items",
                    ["PetAndMountDatabase.Items.MiniPets"] = "m,PetAndMountDatabase.Critters",
                    ["PetAndMountDatabase.MiniPets.Normal"] = "m,PetAndMountDatabase.Critters.Normal",
                    ["PetAndMountDatabase.MiniPets.Quest"] = "m,PetAndMountDatabase.Critters.Quest",
                    ["PetAndMountDatabase.MiniPets.Children"] = "m,PetAndMountDatabase.Critters.Children",
                    ["PetAndMountDatabase.MiniPets.Reagented.Snowball"] = "m,PetAndMountDatabase.Critters.Reagented.Snowball",
                    ["PetAndMountDatabase.MiniPets.Equipment.Head"] = "m,PetAndMountDatabase.Critters.Equipment.Head",
                    ["PetAndMountDatabase.TempleOfAhnQiraj.Mounts"] = "m,PetAndMountDatabase.Mounts.Ground.VeryFast.Items.TempleOfAhnQiraj",
                },
            }, --oldest
            newest = {
                WoWVersion = 30000,
                Collections = {
                    Critters = {
                        Normal = {
                            [-10713] = true, -- Albino Snake
                            [-23428] = true, -- Albino Snapjaw
                            [-10685] = true, -- Ancona Chicken
                            [-10696] = true, -- Azure Whelpling
                            [-24985] = true, -- Baby Murloc (Blue)
                            [-24986] = true, -- Baby Murloc (Green)
                            [-24987] = true, -- Baby Murloc (Orange)
                            [-24989] = true, -- Baby Murloc (Pink)
                            [-24990] = true, -- Baby Murloc (Purple)
                            [-24988] = true, -- Baby Murloc (White) [Lurky]
                            [-44369] = true, -- Baby Pink Elekk
                            [-25849] = true, -- Baby Shark
                            [-40549] = true, -- Bananas
                            [-10714] = true, -- Black Kingsnake
                            [-36031] = true, -- Blue Dragonhawk Hatchling
                            [-35907] = true, -- Blue Moth
                            [-10715] = true, -- Blue Racer
                            [-10673] = true, -- Bombay
                            [-35239] = true, -- Brown Rabbit
                            [-10716] = true, -- Brown Snake
                            [-10699] = true, -- Bronze Whelpling
                            [-58636] = true, -- Chilly the Penguin
                            [-46426] = true, -- Chuck
                            [-45048] = true, -- Clockwork Rocket Bot
                            [-54187] = true, -- Clockwork Rocket Bot
                            [-61351] = true, -- Cobra Hatchling
                            [-10681] = true, -- Cockatoo
                            [-10680] = true, -- Cockatiel
                            [-10688] = true, -- Cockroach
                            [-10674] = true, -- Cornish Rex
                            [-15648] = true, -- Corrupted Kitten
                            [-10710] = true, -- Cottontail Rabbit
                            [-10717] = true, -- Crimson Snake
                            [-10697] = true, -- Crimson Whelpling
                            [-45127] = true, -- Dragon Kite
                            [-10695] = true, -- Dark Whelpling
                            [-10701] = true, -- Dart Frog
                            [-17708] = true, -- Diablo
                            [-25162] = true, -- Disgusting Oozeling
                            [-10705] = true, -- Eagle Owl
                            [-40614] = true, -- Egbert
                            [-10721] = true, -- Elven Wisp
                            [-10698] = true, -- Emerald Whelpling
                            [-49964] = true, -- Ethereal Soul-Trader
                            [-48408] = true, -- Essence of Competition
                            [-10700] = true, -- Faeling
                            [-13548] = true, -- Farm Chicken
                            [-36034] = true, -- Firefly
                            [-52615] = true, -- Frosty
                            [-53316] = true, -- Ghostly Skull
                            [-59250] = true, -- Giant Sewer Rat
                            [-36027] = true, -- Golden Dragonhawk Hatchling
                            [-45174] = true, -- Golden Pig
                            [-10707] = true, -- Great Horned Owl
                            [-10718] = true, -- Green Water Snake
                            [-10683] = true, -- Green Wing Macaw
                            [-27241] = true, -- Gurky
                            [-10706] = true, -- Hawk Owl
                            [-23432] = true, -- Hawksbill Snapjaw
                            [-30156] = true, -- Hippogryph Hatchling
                            [-10682] = true, -- Hyacinth Macaw
                            [-10702] = true, -- Island Frog
                            [-23811] = true, -- Jubling
                            [-61472] = true, -- Kirin Tor Familiar
                            [-23431] = true, -- Leatherback Snapjaw
                            [-19772] = true, -- Lifelike Toad
                            [-15049] = true, -- Lil' Smoky
                            [-40319] = true, -- Lucky
                            [-40405] = true, -- Lucky
                            [-33050] = true, -- Magical Crawdad
                            [-10675] = true, -- Maine Coon
                            [-35156] = true, -- Mana Wyrmling
                            [-12243] = true, -- Mechanical Chicken
                            [-4055]  = true, -- Mechanical Squirrel
                            [-43918] = true, -- Mojo
                            [-39181] = true, -- Miniwing
                            [-55068] = true, -- Mr. Chilly
                            [-28739] = true, -- Mr. Wiggles
                            [-43698] = true, -- Muckbreath
                            [-25018] = true, -- Murki
                            [-24696] = true, -- Murky
                            [-23430] = true, -- Olive Snapjaw
                            [-10676] = true, -- Orange Tabby
                            [-51716] = true, -- Nether Ray Fry
                            [-42431] = true, -- Netherwhelp
                            [-17707] = true, -- Panda
                            [-40634] = true, -- Peanut
                            [-27570] = true, -- Peddlefeet
                            [-61357] = true, -- Pengu
                            [-15048] = true, -- Pet Bombling
                            [-46599] = true, -- Phoenix Hatchling
                            [-28505] = true, -- Poley
                            [-10709] = true, -- Prairie Dog
                            [-61350] = true, -- Proto-Drake Whelp
                            [-38842] = true, -- RC Tank Pet[[NYA]]
                            [-36028] = true, -- Red Dragonhawk Hatchling
                            [-35909] = true, -- Red Moth
                            [-10719] = true, -- Ribbon Snake
                            [-45125] = true, -- Rocket Chicken
                            [-10684] = true, -- Senegal
                            [-10720] = true, -- Scarlet Snake
                            [-45890] = true, -- Scorchling
                            [-53768] = true, -- Scourge Haunt
                            [-10677] = true, -- Siamese
                            [-36029] = true, -- Silver Dragonhawk Hatchling
                            [-45175] = true, -- Silver Pig
                            [-10678] = true, -- Silver Tabby
                            [-16450] = true, -- Smolderweb
                            [-46425] = true, -- Snarly
                            [-26468] = true, -- Snowman
                            [-10711] = true, -- Snowshoe Rabbit
                            [-28738] = true, -- Speedy
                            [-48406] = true, -- Spirit of Competition
                            [-28871] = true, -- Spirit of Summer
                            [-10712] = true, -- Spotted Rabbit
                            [-35157] = true, -- Spotted Rabbit
                            [-15067] = true, -- Sprite Darter Hatchling
                            [-42609] = true, -- Squashling
                            [-40990] = true, -- Stinker
                            [-28487] = true, -- Terky
                            [-61348] = true, -- Tickbird Hatchling                            
                            [-23531] = true, -- Tiny Green Dragon
                            [-23530] = true, -- Tiny Red Dragon
                            [-45082] = true, -- Tiny Sporebat
                            [-43697] = true, -- Toothy
                            [-26010] = true, -- Tranquil Mechanical Yeti
                            [-10704] = true, -- Tree Frog
                            [-53082] = true, -- Tyrael
                            [-51851] = true, -- Vampiric Batling
                            [-28740] = true, -- Whiskers
                            [-10679] = true, -- White Kitten
                            [-35911] = true, -- White Moth
                            [-10687] = true, -- White Plymouth Rock
                            [-61349] = true, -- White Tickbird Hatchling
                            [-30152] = true, -- White Tiger Cub
                            [-40613] = true, -- Willy
                            [-39709] = true, -- Wolpertinger
                            [-10703] = true, -- Wood Frog
                            [-15999] = true, -- Worg Pup
                            [-35910] = true, -- Yellow Moth
                            [-17709] = true, -- Zergling
                        }, -- Normal
        
                        Reagented = { -- Needs an item to summon
                            Snowball = {
                                [-26533] = 17202, -- Father Winter's Helper
                                [-26045] = 17202, -- Tiny Snowman
                                [-26529] = 17202, -- Winter Reindeer
                                [-26541] = 17202, -- Winter's Little Helper
                            }, -- Snowball
                        }, -- Reagented
        
                        Equipment = { -- Needs to be equipped
                            Head = {
                                [12185] = "HEADSLOT", -- Bloodsail Admiral's Hat
                                [38506] = "HEADSLOT", -- Don Carlos' Famous Hat
                            },
                         }, -- Equipment
                
                        Children = { -- Children's week
                            [31880] = true, -- Blood Elf Orphan Whistle
                            [31881] = true, -- Draenei Orphan Whistle
                            [18598] = true, -- Human Orphan Whistle
                            [18597] = true, -- Orcish Orphan Whistle
                        }, -- Children

                        Quest = { -- Used in a quest
                            [30803] = 10629, -- Felhound Whistle for Shizz Work
                            [34253] = 11516, -- Sizzling Embers for Blast the Gateway
                            [12565] = 4506,  -- Winna's Kitten Carrier
                        }, -- Quest
                    }, -- MiniPets
        
                    Mounts = {
                        Variable = {
                            All = { -- Ground AND Flying
                                [-48025] = "-1|75", -- Headless Horseman's Mount
                            }, -- All
                            Flying = {
                                [-54729] = "-1|225", -- Winged Steed of the Ebon Blade
                            }, -- Flying
                            Ground = {
                                [-58983] = "-1|75", -- Big Blizzard Bear
                            }, -- Ground
                        }, -- Variable
                        Ground = {
                            Slow = { -- +0% speed
                                [33189]  = "0|0", -- Rickety Magic Broom
                                [-30174] = "0|0", -- Riding Turtle
                            }, -- Slow
        
                            Fast = { -- +60% speed
                                [-35022] = "60|75", -- Black Hawkstrider
                                [-35020] = "60|75", -- Blue Hawkstrider
                                [-10969] = "60|75", -- Blue Mechanostrider
                                [-33630] = "60|75", -- Blue Mechanostrider
                                [-17463] = "60|75", -- Blue Skeletal Horse
                                [-470]   = "60|75", -- Black Stallion
                                [-578]   = "60|75", -- Black Wolf
                                [-49378] = "60|75", -- Brewfest Kodo
                                [-50869] = "60|75", -- Brewfest Kodo
                                [-43899] = "60|75", -- Brewfest Ram
                                [-50870] = "60|75", -- Brewfest Ram
                                [-458]   = "60|75", -- Brown Horse
                                [-17464] = "60|75", -- Brown Skeletal Horse
                                [-34406] = "60|75", -- Brown Elekk
                                [-18990] = "60|75", -- Brown Kodo
                                [-6899]  = "60|75", -- Brown Ram
                                [-6654]  = "60|75", -- Brown Wolf
                                [-6648]  = "60|75", -- Chestnut Mare Bridle
                                [-6653]  = "60|75", -- Dire Wolf
                                [-8395]  = "60|75", -- Emerald Raptor
                                [-17458] = "60|75", -- Fluorescent Green Mechanostrider
                                [-35710] = "60|75", -- Gray Elekk
                                [-18989] = "60|75", -- Gray Kodo
                                [-6777]  = "60|75", -- Gray Ram
                                [-459]   = "60|75", -- Gray Wolf
                                [-15780] = "60|75", -- Green Mechanostrider
                                [-17453] = "60|75", -- Green Mechanostrider
                                [-580]   = "60|75", -- Large Timber Wolf
                                [37011]  = "60|75", -- Magic Broom
                                [33183]  = "60|75", -- Old Magic Broom
                                [-16055] = "60|75", -- Nightsaber
                                [-472]   = "60|75", -- Pinto
                                [-35711] = "60|75", -- Purple Elekk
                                [-35018] = "60|75", -- Purple Hawkstrider
                                [-34795] = "60|75", -- Red Hawkstrider
                                [-10873] = "60|75", -- Red Mechanostrider
                                [-17456] = "60|75", -- Red & Blue Mechanostrider
                                [-17462] = "60|75", -- Red Skeletal Horse
                                [-25675] = "60|75", -- Reindeer
                                [-18363] = "60|75", -- Riding Kodo
                                [-42776] = "60|75", -- Spectral Tiger
                                [-10789] = "60|75", -- Spotted Frostsaber
                                [-10792] = "60|75", -- Spotted Panther
                                [-8394]  = "60|75", -- Striped Frostsaber
                                [-10793] = "60|75", -- Striped Nightsaber
                                [-17454] = "60|75", -- Unpainted Mechanostrider
                                [-10796] = "60|75", -- Turquoise Raptor
                                [-10799] = "60|75", -- Violet Raptor
                                [-6898]  = "60|75", -- White Ram
                                [-581]   = "60|75", -- Winter Wolf
                                [-13819] = "60|75", --Summon Warhorse (Alliance)
                                [-34769] = "60|75", --Summon Warhorse (Horde)
                                [-5784] = "60|75", --Summon Felsteed
                            }, -- Fast

                            VeryFast = { -- +100% speed
                                [-43688] = "100|150", -- Amani War Bear
                                [-60114] = "100|150", -- Armored Brown Bear
                                [-60116] = "100|150", -- Armored Brown Bear
                                [-51412] = "100|150", -- Big Battle Bear
                                [-22719] = "100|150", -- Black Battlestrider
                                [-59572] = "100|150", -- Black Polar Bear
                                [-6896]  = "100|150", -- Black Ram
                                [-17461] = "100|150", -- Black Ram
                                [-60118] = "100|150", -- Black War Bear
                                [-60119] = "100|150", -- Black War Bear
                                [-48027] = "100|150", -- Black War Elekk
                                [-22718] = "100|150", -- Black War Kodo
                                [-59785] = "100|150", -- Black War Mammoth
                                [-59788] = "100|150", -- Black War Mammoth
                                [-22720] = "100|150", -- Black War Ram
                                [-22721] = "100|150", -- Black War Raptor
                                [-22717] = "100|150", -- Black War Steed
                                [-22723] = "100|150", -- Black War Tiger
                                [-22724] = "100|150", -- Black War Wolf
                                [-50281] = "100|150", -- Black Warp Stalker
                                [-59573] = "100|150", -- Brown Polar Bear
                                [-39315] = "100|150", -- Cobalt Riding Talbuk
                                [-34896] = "100|150", -- Cobalt War Talbuk
                                [-39316] = "100|150", -- Dark Riding Talbuk
                                [-34790] = "100|150", -- Dark War Talbuk
                                [-17481] = "100|150", -- Deathcharger
                                [-36702] = "100|150", -- Fiery Warhorse's Reins
                                [-17460] = "100|150", -- Frost Ram
                                [-16056] = "100|150", -- Frostsaber
                                [-35713] = "100|150", -- Great Blue Elekk
                                [-49379] = "100|150", -- Great Brewfest Kodo
                                [-23249] = "100|150", -- Great Brown Kodo
                                [-23248] = "100|150", -- Great Gray Kodo
                                [-35712] = "100|150", -- Great Green Elekk
                                [-35714] = "100|150", -- Great Purple Elekk
                                [-23247] = "100|150", -- Great White Kodo
                                [-18991] = "100|150", -- Green Kodo
                                [-17465] = "100|150", -- Green Skeletal Warhorse
                                [-23509] = "100|150", -- Frostwolf Howler
                                [-59797] = "100|150", -- Ice Mammoth
                                [-59799] = "100|150", -- Ice Mammoth
                                [-17459] = "100|150", -- Icy Blue Mechanostrider Mod A
                                [-10795] = "100|150", -- Ivory Raptor
                                [-17450] = "100|150", -- Ivory Raptor
                                [-16084] = "100|150", -- Mottled Red Raptor
                                [-16055] = "100|150", -- Nightsaber
                                [-16082] = "100|150", -- Palomino Stallion
                                [-54753] = "100|150", -- Polar Bear
                                [-23246] = "100|150", -- Purple Skeletal Warhorse
                                [-41252] = "100|150", -- Raven Lord
                                [-22722] = "100|150", -- Red Skeletal Warhorse
                                [-579]   = "100|150", -- Red Wolf
                                [-16080] = "100|150", -- Red Wolf
                                [-39910] = "100|150", -- Riding Clefthoof
                                [-39317] = "100|150", -- Silver Riding Talbuk
                                [-34898] = "100|150", -- Silver War Talbuk
                                [-23510] = "100|150", -- Stormpike Battle Charger
                                [-23241] = "100|150", -- Swift Blue Raptor
                                [-43900] = "100|150", -- Swift Brewfest Ram
                                [-23238] = "100|150", -- Swift Brown Ram
                                [-23229] = "100|150", -- Swift Brown Steed
                                [-23250] = "100|150", -- Swift Brown Wolf
                                [-23220] = "100|150", -- Swift Dawnsaber
                                [-23221] = "100|150", -- Swift Frostsaber
                                [-23239] = "100|150", -- Swift Gray Ram
                                [-23252] = "100|150", -- Swift Gray Wolf
                                [-35025] = "100|150", -- Swift Green Hawkstrider
                                [-23225] = "100|150", -- Swift Green Mechanostrider
                                [33184]  = "100|150", -- Swift Magic Broom
                                [-23219] = "100|150", -- Swift Mistsaber
                                [-23242] = "100|150", -- Swift Olive Raptor
                                [-23243] = "100|150", -- Swift Orange Raptor
                                [-23227] = "100|150", -- Swift Palomino
                                [-33660] = "100|150", -- Swift Pink Hawkstrider
                                [-35027] = "100|150", -- Swift Purple Hawkstrider
                                [-24242] = "100|150", -- Swift Razzashi Raptor
                                [-42777] = "100|150", -- Swift Spectral Tiger
                                [-23338] = "100|150", -- Swift Stormsaber
                                [-23251] = "100|150", -- Swift Timber Wolf
                                [-35028] = "100|150", -- Swift Warstrider
                                [-46628] = "100|150", -- Swift White Hawkstrider
                                [-23223] = "100|150", -- Swift White Mechanostrider
                                [-23240] = "100|150", -- Swift White Ram
                                [-23228] = "100|150", -- Swift White Steed
                                [-23222] = "100|150", -- Swift Yellow Mechanostrider
                                [-48954] = "100|150", -- Swift Zhevra
                                [-49322] = "100|150", -- Swift Zhevra
                                [-24252] = "100|150", -- Swift Zulian Tiger
                                [-39318] = "100|150", -- Tan Riding Talbuk
                                [-34899] = "100|150", -- Tan War Talbuk
                                [-18992] = "100|150", -- Teal Kodo
                                [-15779] = "100|150", -- White Mechanostrider Mod A
                                [-54753] = "100|150", -- White Polar Bear
                                [-39319] = "100|150", -- White Riding Talbuk
                                [-16083] = "100|150", -- White Stallion
                                [-34897] = "100|150", -- White War Talbuk
                                [-5818]  = "100|150", -- Winter Wolf
                                [-16081] = "100|150", -- Winter Wolf                                
                                [-17229] = "100|75",  -- Winterspring Frostsaber
                                [-59791] = "100|150", -- Wooly Mammoth
                                [-59793] = "100|150", -- Wooly Mammoth
        
                                TempleOfAhnQiraj = {
                                    --The only mounts allowed to be used in Temple of Ahn'Qiraj
                                    [-25863] = "100|150", -- Black Qiraji Battle Tank
                                    [-26655] = "100|150", -- Black Qiraji Battle Tank
                                    [-26656] = "100|150", -- Black Qiraji Battle Tank
                                    [-31700] = "100|150", -- Black Qiraji Battle Tank
                                    [21218]  = "100|75",  -- Blue Qiraji Resonating Crystal
                                    [21323]  = "100|75",  -- Green Qiraji Resonating Crystal
                                    [21321]  = "100|75",  -- Red Qiraji Resonating Crystal
                                    [21324]  = "100|75",  -- Yellow Qiraji Resonating Crystal
                                },
                                [-48778]= "100|75", --Summon Acherus Deathcharger
                                [-23214]= "100|150", --Summon Charger (Alliance)
                                [-34767]= "100|150", --Summon Charger (Horde)
                                [-23161]= "100|150", --Summon Dreadsteed
                            }, -- VeryFast
                        }, -- Ground
                        Flying = {
                            Slow = { -- +0% speed
                                [44221]  = "0|0", -- Loaned Gryphon Reins
                            },-- Slow
                            Fast = { -- +60% speed
                                [-32244] = "60|225", -- Blue Windrider
                                [-32239] = "60|225", -- Ebon Gryphon Mount
                                [33176]  = "60|225", -- Flying Broom
                                [-44153] = "60|225", -- Flying Machine Control
                                [-32235] = "60|225", -- Golden Gryphon
                                [-32245] = "60|225", -- Green Windrider
                                [-54726] = "60|225", -- Skeletal Gryphon
                                [-32240] = "60|225", -- Snowy Gryphon Mount
                                [-32243] = "60|225", -- Tawny Windrider
                                [-48025] = "60|225", -- Headless Horseman's Mount
                                [-46197] = "60|225", -- X-51 Nether-Rocket
                            }, -- Fast

                            VeryFast = { -- +280% speed
                                [-60025] = "280|300", -- Albino Drake
                                [-61230] = "280|300", -- Armored Blue Wind Rider
                                [-61229] = "280|300", -- Armored Snowy Gryphon
                                [-41514] = "280|300", -- Azure Netherwing Drake
                                [-59568] = "280|300", -- Blue Drake
                                [-59976] = "280|300", -- Black Proto-Drake
                                [-59996] = "280|300", -- Blue Proto-Drake
                                [-39803] = "280|300", -- Blue Riding Nether Ray
                                [-59569] = "280|300", -- Bronze Drake
                                [-43927] = "280|300", -- Cenarion War Hippogryph
                                [-41515] = "280|300", -- Cobalt Netherwing Drake
                                [-43810] = "280|300", -- Frost Wyrm
                                [-51960] = "280|300", -- Frostwyrm Mount
                                [-39798] = "280|300", -- Green Riding Nether Ray
                                [-52649] = "280|300", -- Magnificent Flying Carpet
                                [-61309] = "280|300", -- Magnificent Flying Carpet
                                [-41513] = "280|300", -- Onyx Netherwing Drake
                                [-60021] = "280|300", -- Plagued Proto-Drake
                                [-41516] = "280|300", -- Purple Netherwing Drake
                                [-39801] = "280|300", -- Purple Riding Nether Ray
                                [-59570] = "280|300", -- Red Drake                                                                
                                [-59961] = "280|300", -- Red Proto-Drake
                                [-39800] = "280|300", -- Red Riding Nether Ray
                                [-39802] = "280|300", -- Silver Riding Nether Ray
                                [-32242] = "280|300", -- Swift Blue Gryphon
                                [33182]  = "280|300", -- Swift Flying Broom
                                [-32290] = "280|300", -- Swift Green Gryphon
                                [-32295] = "280|300", -- Swift Green Windrider
                                [-61442] = "280|300", -- Swift Mooncloth Carpet
                                [-32292] = "280|300", -- Swift Purple Gryphon
                                [-32297] = "280|300", -- Swift Purple Windrider
                                [-32289] = "280|300", -- Swift Red Gryphon
                                [-32246] = "280|300", -- Swift Red Windrider
                                [-54727] = "280|300", -- Swift Skeletal Gryphon
                                [-61446] = "280|300", -- Swift Spellfire Carpet
                                [-61444] = "280|300", -- Swift Spellweave Carpet
                                [-32296] = "280|300", -- Swift Yellow Windrider
                                [-60002] = "280|300", -- Time-Lost Proto-drake
                                [-44151] = "280|300", -- Turbo-Charged Flying Machine
                                [-59571] = "280|300", -- Twilight Drake
                                [-41517] = "280|300", -- Veridian Netherwing Drake
                                [-41518] = "280|300", -- Violet Netherwing Drake
                                [-60024] = "280|300", -- Violet Proto-Drake
                                [-60002] = "280|300", -- White Proto-Drake
                                [-46199] = "280|300", -- X-51 Nether-Rocket XTREME
                            }, -- VeryFast
        
                            ExtremelyFast = { -- +310% speed
                                [-58615] = "310|300", -- Brutal Nether Drake
                                [-40192] = "310|300", -- Call of the Phoenix
                                [-44317] = "310|300", -- Merciless Nether Drake
                                [-44744] = "310|300", -- Merciless Nether Drake
                                [-3363]  = "310|300", -- Nether Drake
                                [-32345] = "310|300", -- Peep the Phoenix Mount
                                [-37015] = "310|300", -- Swift Nether Drake
                                [-49193] = "310|300", -- Vengeful Nether Drake
                            }, -- ExtremelyFast
                        }, -- Flying
        
                        Passenger = {
                            Ground = {
                                VeryFast = {
                                    [-59810] = "100|150|3", -- Grand Black War Mammoth
                                    [-59811] = "100|150|3", -- Grand Black War Mammoth
                                    [-60136] = "100|150|3", -- Grand Caravan Mammoth
                                    [-60140] = "100|150|3", -- Grand Caravan Mammoth
                                    [-59802] = "100|150|3", -- Grand Ice Mammoth
                                    [-59804] = "100|150|3", -- Grand Ice Mammoth
                                    [-55531] = "100|150|2", -- Mechano-Hog
                                    [-60424] = "100|150|2", -- Mekgineer's Chopper
                                    [-61425] = "100|150|3", -- Traveler's Tundra Mammoth
                                    [-61447] = "100|150|3", -- Traveler's Tundra Mammoth
                                }, -- VeryFast
                            }, -- Ground
                            Flying = {
                                ExtremelyFast = {
                                }, -- ExtremelyFast
                            }, -- Flying
                        }, -- Passenger
                    }, -- Mounts
        
                    Spells = {
                        Travel = {
                            Aquatic = {
                                Druid = {
                                    [-1066] = "50", -- Aquatic Form
                                },
                            },
                            Ground = {
                                Druid = {
                                    [-783] = "40", -- Travel Form
                                },
                                Hunter = {
                                    [-5118]  = "30", -- Aspect of the Cheetah
                                    [-13159] = "30", -- Aspect of the Pack
                                },
                                Shaman = {
                                    [-2645] = "40", -- Ghost Wolf
                                },
                            },
                            Flying = {
                                Druid = {
                                    [-33943] = "60",  -- Flight Form
                                    [-40120] = "280", -- Swift Flight Form
                                },
                            },
                        },
                        Teleport = {
                            Items = {
                                [-54406] = "40585|40586", -- Signet of the Kirin Tor, Band of the Kirin Tor
                                [-8690]  = 6948,  -- Hearthstone
                                [-46149] = 35230, -- Teleport: Shattrath (Darnarian's Scroll of Teleportation)
                                [-39937] = 28585, -- There's No Place Like Home (Ruby Slippers)
                                Engineering = {
                                    Goblin = {
                                        [-36890] = 30542, -- Area52 Transporter (Dimensional Ripper - Area 52)
                                        [-23442] = 18984, -- Everlook Transporter (Dimensional Ripper - Everlook)
                                    },
                                    Gnomish = {
                                        [-23452] = 18986, -- Gnomish Transporter (Ultrasafe Transporter: Gadgetzan)
                                        [-30544] = 30544, -- Toshley's Station Transporter (Ultrasafe Transporter: Toshley's Station)
                                    },
                                },
                            },
                            Mage = {
                                [-53140] = true, -- Teleport: Dalaran
                                Alliance = {
                                    [-3565]  = true, -- Teleport: Darnassus
                                    [-32271] = true, -- Teleport: Exodar
                                    [-3562]  = true, -- Teleport: Ironforge
                                    [-33690] = true, -- Teleport: Shattrath
                                    [-3561]  = true, -- Teleport: Stormwind
                                    [-49359] = true, -- Teleport: Theramore
                                },
                                Horde = {
                                    [-3567]  = true, -- Teleport: Orgrimmar
                                    [-35715] = true, -- Teleport: Shattrath
                                    [-32272] = true, -- Teleport: Silvermoon
                                    [-49358] = true, -- Teleport: Stonard
                                    [-3566]  = true, -- Teleport: Thunder Bluff
                                    [-3563]  = true, -- Teleport: Undercity
                                },
                            },
                            Druid = {
                                [-18960] = true, -- Teleport: Moonglade
                            },
                            Shaman = {
                                [-556]   = true, -- Astral Recall
                            },
                            Translocate = {
                                [-25140] = true,
                                [-25143] = true,
                                [-25649] = true,
                                [-25650] = true,
                                [-25652] = true,
                                [-25666] = true,
                                [-26572] = true,
                                [-29128] = true,
                                [-29129] = true,
                                [-30141] = true,
                                [-32568] = true,
                                [-32569] = true,
                                [-32571] = true,
                                [-32572] = true,
                                [-35376] = true,
                                [-35727] = true,
                                [-35730] = true,
                                [-45368] = true,
                                [-45371] = true,
                            },
                        },
                    },
                    Items = {
                        CritterEnchant = {
                            [35223] = 1, -- Papa Hummel's Old-Fashioned Pet Biscuit
                            [37460] = 2, -- Rope Pet Leash
                            [37431] = 3, -- Fetch Ball
                            [43352] = 4, -- Pet Grooming Kit
                            [43626] = 5, -- Happy Pet Snack
                        },
                        MountEnchant = {
                            [21212] = 1, --Fresh Holly
                            [39477] = 2, --Fresh Dwarven Hops
                            [39476] = 3, --Fresh Goblin Hops
                            [37750] = 4, --Fresh Brewfest Hops
                            [21213] = 5, --Preserved Holly
                            [37816] = 6, --Preserved Brewfest Hops
                        },
                    },
                    Conversion = {
                        Mounts = {
                            [23720] = -30174, -- Riding Turtle
                            [29221] = -35022, -- Black Hawkstrider
                            [29220] = -35020, -- Blue Hawkstrider
                            [8595]  = -10969, -- Blue Mechanostrider
                            [13332] = -17463, -- Blue Skeletal Horse
                            [2411]  = -470,   -- Black Stallion Bridle
                            [33976] = -43899, -- Brewfest Ram
                            [5656]  = -458,   -- Brown Horse Bridle
                            [13333] = -17464, -- Brown Skeletal Horse
                            [28481] = -28481, -- Brown Elekk
                            [15290] = -18990, -- Brown Kodo
                            [5872]  = -6899,  -- Brown Ram
                            [5655]  = -6648,  -- Chestnut Mare Bridle
                            [29744] = -35710, -- Gray Elekk
                            [15277] = -18989, -- Gray Kodo
                            [5864]  = -6777,  -- Gray Ram
                            [13321] = -17453, -- Green Mechanostrider
                            [1041]  = -578,   -- Horn of the Black Wolf
                            [5668]  = -6654,  -- Horn of the Brown Wolf
                            [5665]  = -6653,  -- Horn of the Dire Wolf
                            [1134]  = -459,   -- Horn of the Gray Wolf
                            [1132]  = -580,   -- Horn of the Timber Wolf
                            [14062] = -18363, -- Kodo Mount
                            [2414]  = -472,   -- Pinto Bridle
                            [29743] = -35711, -- Purple Elekk
                            [29222] = -35018, -- Purple Hawkstrider
                            [28927] = -34795, -- Red Hawkstrider
                            [8563]  = -10873, -- Red Mechanostrider
                            [13331] = -17462, -- Red Skeletal Horse
                            [21044] = -25675, -- Reindeer Reins (TEST)
                            [8627]  = -10787, -- Reins of the Night saber
                            [33224] = -42776, -- Reins of the Spectral Tiger
                            [8632]  = -10789, -- Reins of the Spotted Frostsaber
                            [8631]  = -8394,  -- Reins of the Striped Frostsaber
                            [8628]  = -10792, -- Reins of the Spotted Nightsaber
                            [8629]  = -10793, -- Reins of the Striped Nightsaber
                            [13322] = -17454, -- Unpainted Mechanostrider
                            [8588]  = -8395,  -- Whistle of the Emerald Raptor
                            [8591]  = -10796, -- Whistle of the Turquoise Raptor
                            [8592]  = -10799, -- Whistle of the Violet Raptor
                            [5873]  = -6898,  -- White Ram
                            [33809] = -43688, -- Amani War Bear
                            [38576] = -51412, -- Big Battle Bear
                            [18243] = -22719, -- Black Battlestrider
                            [29465] = -22719, -- Black Battlestrider
                            [13328] = -17461, -- Black Ram
                            [18247] = -22718, -- Black War Kodo
                            [29466] = -22718, -- Black War Kodo
                            [18244] = -22720, -- Black War Ram
                            [29467] = -22720, -- Black War Ram
                            [18241] = -22717, -- Black War Steed Bridle
                            [29468] = -22717, -- Black War Steed Bridle
                            [13335] = -17418, -- Deathcharger's Reins
                            [30480] = -36702, -- Fiery Warhorse's Reins
                            [13329] = -17460, -- Frost Ram
                            [29745] = -35713, -- Great Blue Elekk
                            [37828] = -49379, -- Great Brewfest Kodo
                            [18794] = -23249, -- Great Brown Kodo
                            [18795] = -23248, -- Great Gray Kodo
                            [29746] = -35712, -- Great Green Elekk
                            [29747] = -35714, -- Great Purple Elekk
                            [18793] = -23247, -- Great White Kodo
                            [15292] = -18991, -- Green Kodo
                            [13334] = -17465, -- Green Skeletal Warhorse
                            [12351] = -16081, -- Horn of the Arctic Wolf
                            [18245] = -22724, -- Horn of the Black War Wolf
                            [29469] = -22724, -- Horn of the Black War Wolf
                            [19029] = -23509, -- Horn of the Frostwolf Howler
                            [12330] = -16080, -- Horn of the Red Wolf
                            [18796] = -23250, -- Horn of the Swift Brown Wolf
                            [18798] = -23252, -- Horn of the Swift Gray Wolf
                            [18797] = -23251, -- Horn of the Swift Timber Wolf
                            [13327] = -17459, -- Icy Blue Mechanostrider Mod A
                            [12354] = -12354, -- Palomino Bridle
                            [18791] = -23246, -- Purple Skeletal Warhorse
                            [29470] = -22722, -- Red Skeletal Warhorse
                            [35906] = -48027, -- Reins of the Black War Elekk
                            [18242] = -22723, -- Reins of the Black War Tiger
                            [29471] = -22723, -- Reins of the Black War Tiger
                            [31829] = -39315, -- Reins of the Cobalt Riding Talbuk
                            [31830] = -39315, -- Reins of the Cobalt Riding Talbuk
                            [29102] = -34896, -- Reins of the Cobalt War Talbuk
                            [29227] = -34896, -- Reins of the Cobalt War Talbuk
                            [28915] = -39316, -- Reins of the Dark Riding Talbuk
                            [29228] = -34790, -- Reins of the Dark War Talbuk
                            [12302] = -16056, -- Reins of the Frostsaber
                            [12303] = -16055, -- Reins of the Nightsaber
                            [32768] = -41252, -- Reins of the Raven Lord
                            [31831] = -39317, -- Reins of the Silver Riding Talbuk
                            [31832] = -39317, -- Reins of the Silver Riding Talbuk
                            [29104] = -34898, -- Reins of the Silver War Talbuk
                            [29229] = -34898, -- Reins of the Silver War Talbuk
                            [18766] = -23221, -- Reins of the Swift Frostsaber
                            [18767] = -23219, -- Reins of the Swift Mistsaber
                            [33225] = -42777, -- Reins of the Swift Spectral Tiger
                            [18902] = -23338, -- Reins of the Swift Stormsaber
                            [31833] = -39318, -- Reins of the Tan Riding Talbuk
                            [31834] = -39318, -- Reins of the Tan Riding Talbuk
                            [29105] = -34899, -- Reins of the Tan War Talbuk
                            [29230] = -34899, -- Reins of the Tan War Talbuk
                            [13086] = -17229, -- Reins of the Winterspring Frostsaber
                            [31835] = -39319, -- Reins of the White Riding Talbuk
                            [31836] = -39319, -- Reins of the White Riding Talbuk
                            [29103] = -34897, -- Reins of the White War Talbuk
                            [29231] = -34897, -- Reins of the White War Talbuk
                            [19030] = -23510, -- Stormpike Battle Charger
                            [18788] = -23241, -- Swift Blue Raptor
                            [33977] = -43900, -- Swift Brewfest Ram
                            [18786] = -23238, -- Swift Brown Ram
                            [18777] = -23229, -- Swift Brown Steed
                            [18787] = -23239, -- Swift Gray Ram
                            [29223] = -35025, -- Swift Green Hawkstrider
                            [18772] = -23225, -- Swift Green Mechanostrider
                            [18789] = -23242, -- Swift Olive Raptor
                            [18790] = -23243, -- Swift Orange Raptor
                            [18776] = -23227, -- Swift Palomino
                            [28936] = -33660, -- Swift Pink Hawkstrider
                            [29224] = -35027, -- Swift Purple Hawkstrider
                            [19872] = -24242, -- Swift Razzashi Raptor
                            [34129] = -35028, -- Swift Warstrider
                            [35513] = -46628, -- Swift White Hawkstrider
                            [18773] = -23223, -- Swift White Mechanostrider
                            [18785] = -23240, -- Swift White Ram
                            [18778] = -23228, -- Swift White Steed
                            [18774] = -23222, -- Swift Yellow Mechanostrider
                            [37719] = -49322, -- Swift Zhevra
                            [19902] = -24252, -- Swift Zulian Tiger
                            [15293] = -18992, -- Teal Kodo
                            [37012] = -48025, -- The Horseman's Reins
                            [18246] = -22721, -- Whistle of the Black War Raptor
                            [29472] = -22721, -- Whistle of the Black War Raptor
                            [13317] = -17450, -- Whistle of the Ivory Raptor
                            [8586]  = -16084, -- Whistle of the Mottled Red Raptor
                            [13326] = -15779, -- White Mechanostrider Mod A
                            [12353] = -16083, -- White Stallion Bridle
                            [21176] = -26656, -- Black Qiraji Resonating Crystal
                            [25475] = -32244, -- Blue Windrider
                            [25471] = -32239, -- Ebon Gryphon
                            [34060] = -44153, -- Flying Machine Control
                            [25470] = -32235, -- Golden Gryphon
                            [25476] = -32245, -- Green Windrider
                            [25472] = -32240, -- Snowy Gryphon
                            [25474] = -32243, -- Tawny Windrider
                            [37012] = -48025, -- The Horseman's Reins
                            [35225] = -46197, -- X-51 Nether-Rocket
                            [32319] = -39803, -- Blue Riding Nether Ray
                            [33999] = -43927, -- Cenarion War Hippogryph
                            [32314] = -39798, -- Green Riding Nether Ray
                            [32316] = -39801, -- Purple Riding Nether Ray
                            [32317] = -39800, -- Red Riding Nether Ray
                            [32858] = -41514, -- Reins of the Azure Netherwing Drake
                            [32859] = -41515, -- Reins of the Cobalt Netherwing Drake
                            [32857] = -41513, -- Reins of the Onyx Netherwing Drake
                            [32860] = -41516, -- Reins of the Purple Netherwing Drake
                            [32861] = -41517, -- Reins of the Veridian Netherwing Drake
                            [32862] = -41518, -- Reins of the Violet Netherwing Drake
                            [32318] = -39802, -- Silver Riding Nether Ray
                            [25473] = -32242, -- Swift Blue Gryphon
                            [25528] = -32290, -- Swift Green Gryphon
                            [25531] = -32295, -- Swift Green Windrider
                            [25529] = -32292, -- Swift Purple Gryphon
                            [25533] = -32297, -- Swift Purple Windrider
                            [25527] = -32289, -- Swift Red Gryphon
                            [25477] = -32246, -- Swift Red Windrider
                            [25532] = -32296, -- Swift Yellow Windrider
                            [37012] = -48025, -- The Horseman's Reins
                            [34061] = -44151, -- Turbo-Charged Flying Machine Control
                            [35226] = -46199, -- X-51 Nether-Rocket XTREME
                            [32458] = -40192, -- Ashes of Al'ar
                            [34092] = -44744, -- Merciless Nether Drake
                            [35600] = -3363,  -- Nether Drake Flying Mount (TEST)
                            [35800] = -32345, -- Peep the Phoenix
                            [30609] = -37015, -- Swift Nether Drake
                            [37676] = -49193, -- Vengeful Nether Drake
                        }, --Mounts
                        Critters = {
                            [19450] = -23811, -- A Jubling's Tiny Home
                            [11023] = -10685, -- Ancona Chicken
                            [34535] = -10696, -- Azure Whelpling
                            [32588] = -40549, -- Banana Charm
                            [10360] = -10714, -- Black Kingsnake
                            [29958] = -36031, -- Blue Dragonhawk Hatchling
                            [29901] = -35907, -- Blue Moth Egg
                            [20371] = -24696, -- Blue Murloc Egg
                            [29364] = -35239, -- Brown Rabbit Crate
                            [10361] = -10716, -- Brown Snake
                            [29960] = -36034, -- Captured Firefly
                            [23083] = -28871, -- Captured Flame
                            [8491]  = -10675, -- Cat Carrier (Black Tabby)
                            [8485]  = -10673, -- Cat Carrier (Bombay)
                            [8486]  = -10674, -- Cat Carrier (Cornish Rex)
                            [8487]  = -10676, -- Cat Carrier (Orange Tabby)
                            [8490]  = -10677, -- Cat Carrier (Siamese)
                            [8488]  = -10678, -- Cat Carrier (Silver Tabby)
                            [8489]  = -10679, -- Cat Carrier (White Kitten)
                            [11110] = -13548, -- Chicken Egg
                            [35350] = -46426, -- Chuck's Bucket
                            [34425] = -54187, -- Clockwork Rocket Bot
                            [10393] = -10688, -- Cockroach
                            [37298] = -48408, -- Competitor's Souvenir
                            [10392] = -10717, -- Crimson Snake
                            [10822] = -10695, -- Dark Whelpling
                            [34493] = -45127, -- Dragon Kite
                            [13584] = -17708, -- Diablo Stone
                            [20769] = -25162, -- Disgusting Oozeling
                            [32616] = -40614, -- Egbert's Egg
                            [32622] = -40634, -- Elekk Training Collar
                            [32498] = -40405, -- Fortune Coin
                            [37297] = -48406, -- Gold Medallion
                            [29953] = -36027, -- Golden Dragonhawk Hatchling
                            [8500]  = -10707, -- Great Horned Owl
                            [8501]  = -10706, -- Hawk Owl
                            [23713] = -30156, -- Hippogryph Hatchling
                            [15996] = -19772, -- Lifelike Mechanical Toad
                            [11826] = -15049, -- Lil' Smoky
                            [30360] = -24988, -- Lurky's Egg
                            [27445] = -33050, -- Magical Crawdad Box
                            [29363] = -35156, -- Mana Wyrmling
                            [10398] = -12243, -- Mechanical Chicken
                            [4401]  = -4055 , -- Mechanical Squirrel Box
                            [31760] = -39181, -- Miniwing
                            [33993] = -43918, -- Mojo
                            [33818] = -43698, -- Muckbreath's Bucket
                            [38628] = -51716, -- Nether Ray Fry
                            [25535] = -42431, -- Netherwhelp's Collar
                            [13583] = -17707, -- Panda Collar
                            [8496]  = -10680, -- Parrot Cage (Cockatiel)
                            [8492]  = -10683, -- Parrot Cage (Green Wing Macaw)
                            [8494]  = -10682, -- Parrot Cage (Hyacinth Macaw)
                            [8495]  = -10684, -- Parrot Cage (Senegal)
                            [11825] = -15048, -- Pet Bombling
                            [35504] = -46599, -- Phoenix Hatchling
                            [23007] = -28739, -- Piglet's Collar
                            [22114] = -27241, -- Pink Murloc Egg
                            [10394] = -10709, -- Prairie Dog Whistle
                            [8497]  = -10711, -- Rabbit Crate (Snowshoe)
                            [23015] = -28740, -- Rat Cage
                            [29956] = -36028, -- Red Dragonhawk Hatchling
                            [29902] = -35909, -- Red Moth Egg
                            [34492] = -45125, -- Rocket Chicken
                            [34955] = -45890, -- Scorched Stone
                            [29957] = -36029, -- Silver Dragonhawk Hatchling
                            [33154] = -42609, -- Sinister Squashling
                            [32617] = -40613, -- Sleepy Willy
                            [12529] = -16450, -- Smolderweb Carrier
                            [35349] = -46425, -- Snarly's Bucket
                            [38050] = -49964, -- Soul-Trader Beacon
                            [11474] = -15067, -- Sprite Darter Egg
                            [8499]  = -10697, -- Tiny Crimson Whelpling
                            [8498]  = -10698, -- Tiny Emerald Whelpling
                            [34478] = -45082, -- Tiny Spore Bat
                            [33816] = -43697, -- Toothy's Bucket
                            [31665] = -38842, -- Toy RC Mortar Tank [[NYA]]
                            [21277] = -26010, -- Tranquil Mechanical Yeti
                            [11026] = -10704, -- Tree Frog Box
                            [22235] = -27570, -- Truesilver Shafted Arrow
                            [23002] = -28738, -- Turtle Box
                            [39656] = -53082, -- Tyrael's Hilt
                            [29904] = -35911, -- White Moth Egg
                            [11027] = -10703, -- Wood Frog Box
                            [12264] = -15999, -- Worg Carrier
                            [32233] = -39709, -- Wolpertinger's Tankard
                            [29903] = -35910, -- Yellow Moth Egg
                            [13582] = -17709, -- Zergling Leash
                            [21301] = -26533, -- Green Helper Box
                            [21308] = -26529, -- Jingling Bell
                            [21305] = -26541, -- Red Helper Box
                            [21309] = -26045, -- Snowman Kit
                        }, --Critters
                    }, --Conversion
                }, --Collections
                Sets = {},

                Shortcuts = {
                    ["PetAndMountDatabase.TempleOfAhnQiraj.Mounts"] = "m,PetAndMountDatabase.Mounts.Ground.VeryFast.TempleOfAhnQiraj",
                },
            },
        },
    };

    function buildString( set )
        local returnString = "";

        for item, value in pairs( set ) do

        end--for
        return returnString;
    end--function buildString( set )
    
    function LoopSet( set, setName, dest )
        local returnString = "";
        local count = 0;

        for itemName, item in pairs( set ) do
            count = count + 1;
            if( type( item ) == "table" ) then
                LoopSet( item, setName .. "." .. itemName, dest );
            else
                if( returnString:len() > 0 ) then
                    returnString = returnString .. ",";
                end--if
                returnString = returnString .. itemName;
                if( type( item ) ~= "boolean" ) then
                    returnString = returnString .. ":" .. item;
                end--if            
            end--if
        end--for
        if( ( returnString:len() > 0 ) or ( count == 0 ) ) then
            print( ("Adding set %s..."):format( setName ) );
            dest[setName] = returnString;
        end--if
    end--LoopSet( set, setName )
    
    function OutputSets( hFile, sets )
        for setName, set in pairs( sets ) do
            hFile:write( ("            [%q] = %q,\n"):format( setName, set ) );
        end--for
    end--OutputSets( hFile, sets )

    for name, set in pairs( PetAndMountDatabase.Databases ) do
        LoopSet( PetAndMountDatabase.Databases[name].Collections, "PetAndMountDatabase", PetAndMountDatabase.Databases[name].Sets );
    end--for

    local hFile = io.open( "LibPeriodicTable-3.1-PetAndMountDatabase.lua", "w+" );

    if( hFile == nil ) then
        return;
    end--if

    hFile:write( HEADER );
    hFile:write( ("\nif( tonumber( select( 4, GetBuildInfo() ) ) >= %i ) then\n"):format( PetAndMountDatabase.Databases.newest.WoWVersion ) );
    hFile:write( "    LibStub( \"LibPeriodicTable-3.1\" ):AddData( \"PetAndMountDatabase\", tostring( tonumber( (\"$Rev: 88 $\"):match( \"%d+\" ) ) + 90000 ), {\n" );
    OutputSets( hFile, PetAndMountDatabase.Databases.newest.Sets );
    hFile:write( "\n        -- Shortcuts\n" );
    OutputSets( hFile, PetAndMountDatabase.Databases.newest.Shortcuts );
    hFile:write( "    } );\n" );
    hFile:write( "else\n" );
    hFile:write( "    LibStub( \"LibPeriodicTable-3.1\" ):AddData( \"PetAndMountDatabase\", tostring( tonumber( (\"$Rev: 88 $\"):match( \"%d+\" ) ) + 90000 ), {\n" );
    OutputSets( hFile, PetAndMountDatabase.Databases.oldest.Sets );
    hFile:write( "\n        -- Shortcuts\n" );
    OutputSets( hFile, PetAndMountDatabase.Databases.oldest.Shortcuts );
    hFile:write( "    } );\n" );
    hFile:write( "end--if\n" );
    hFile:close();
end--buildList

buildPetAndMountDatabase();
