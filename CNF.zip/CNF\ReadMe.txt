Chuck Norris Fact Generator
By: Edgar De Loa A.K.A Mexiding on Dethecus

This small addon will post the random Chuck Norris facts found on ChuckNorrisFacts.com
Over 230 fun facts to use!

Usage:

Type /Chuck and then the channel that you wish to post in.
You may use "guild", "raid", "party", "say", "yell", "officer".
Additionally, you can also whisper somebody a fact with /Chuck whisper <PlayerName>
You may also use channel numbers, such as /Chuck 1 to post in /1, /Chuck 2 to post in /2,
and so on.

/Chuck guild
/Chuck raid
/Chuck say
/Chuck yell
/Chuck party
/Chuck officer
/Chuck whisper <PlayerName>
/Chuck <Channel Number> - such as 1, 2, 3, etc.


Any questions, comments, and concerns, please email edeloa@gmail.com