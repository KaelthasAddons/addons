local L = AceLibrary("AceLocale-2.2"):new("JumpCounter")

L:RegisterTranslations("enUS", function() return {
	["Slash-Commands"] = { "/jumpcounter", "/jc" },
     
	["Display each jump"] = true,
	["Show counter in chat each time you jump."] = true,
	 
	["Show counter"] = true,
	["Show how many times you have jumped."] = true,
     
	["This was your jump #"] = true,
     
	["You have jumped "] = true,
	[" times."] = true,
} end)