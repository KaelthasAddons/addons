local L = AceLibrary("AceLocale-2.2"):new("JumpCounter")

L:RegisterTranslations("frFR", function() return {
	["Display each jump"] = "Afficher chaque saut",
	["Show counter in chat each time you jump."] = "Affiche le compteur \195\160 chaque saut.",
	 
	["Show counter"] = "Afficher le compteur",
	["Show how many times you have jumped."] = "Affiche le nombre de sauts que vous avez fait.",
     
	["This was your jump #"] = "C'\195\169tait votre saut num\195\169ro ",
     
	["You have jumped "] = "Vous avez saut\195\169 ",
	[" times."] = " fois.",
} end)