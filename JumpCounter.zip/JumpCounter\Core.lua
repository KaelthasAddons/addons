local L = AceLibrary("AceLocale-2.2"):new("JumpCounter")

local options = { 
    type='group',
    args = {
        displayEachJump = {
            type = 'toggle',
            name = L['Display each jump'],
            desc = L['Show counter in chat each time you jump.'],
            get = "IsShowEachJump",
            set = "ToggleShowEachJump",
        },
		show = {
            type = 'execute',
            name = L['Show counter'],
            desc = L['Show how many times you have jumped.'],
			func = 'DisplayCounter',
        },
    },
}

JumpCounter = AceLibrary("AceAddon-2.0"):new("AceEvent-2.0", "AceConsole-2.0", "AceDB-2.0", "AceHook-2.1", "FuBarPlugin-2.0")
JumpCounter:RegisterChatCommand(L['Slash-Commands'], options)

JumpCounter:RegisterDB("JumpCounterDB", "JumpCounterDBPC")

JumpCounter:RegisterDefaults("profile", {
    showEachJump = false,
} )

JumpCounter:RegisterDefaults("char", {
    counter = 0,
} )

JumpCounter.revision = tonumber(string.sub("$Revision: 31 $", 12, -3))

JumpCounter.cannotDetachTooltip = true
JumpCounter.hasNoColor = true
JumpCounter.clickableTooltip = false
JumpCounter.cannotAttachToMinimap = true
JumpCounter.hasIcon = "Interface\\Icons\\INV_RoseBouquet01"
JumpCounter.OnMenuRequest = options
JumpCounter.hideWithoutStandby = true

function JumpCounter:OnInitialize()
	if not self.version then self.version = GetAddOnMetadata("JumpCounter", "Version") end
	self.version = (self.version or "1.0") .. " |cffff8888r" .. self.revision .. "|r"
	
	self:SecureHook("JumpOrAscendStart")
	self:SetText(self.db.char.counter)
	self.lastJumpTime = GetTime()
end

function JumpCounter:JumpOrAscendStart()
	if UnitOnTaxi("player") or IsFlying() or IsSwimming() or HasFullControl() == false or UnitIsDead("player") then return end
	if lastJumpTime == nil or GetTime() - 0.8 > lastJumpTime then
		lastJumpTime = GetTime()
		self.db.char.counter = self.db.char.counter + 1
		self:SetText(self.db.char.counter)
		if self.db.profile.showEachJump then
			self:Print(L["This was your jump #"] .. self.db.char.counter .. ".")
		end
	end
end

function JumpCounter:IsShowEachJump()
	return self.db.profile.showEachJump
end

function JumpCounter:ToggleShowEachJump()
	self.db.profile.showEachJump = not self.db.profile.showEachJump
end

function JumpCounter:DisplayCounter()
	self:Print(L["You have jumped "] .. self.db.char.counter .. L[" times."])
end

function JumpCounter:OnTextUpdate()
	self:SetText(self.db.char.counter)
end
