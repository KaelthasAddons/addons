local L = AceLibrary("AceLocale-2.2"):new("JumpCounter")

L:RegisterTranslations("koKR", function() return {     
	["Display each jump"] = "점프 할 때마다 보여주기",
	["Show counter in chat each time you jump."] = "당신이 점프 할 때마다 채팅 창에 카운터를 보여줍니다.",
	 
	["Show counter"] = "카운터 보이기",
	["Show how many times you have jumped."] = "당신이 얼마나 많이 점프했는지 보여줍니다.",
     
	["This was your jump #"] = "이번까지 당신의 점프 횟수입니다 #",
     
	["You have jumped "] = "당신은 ",
	[" times."] = "번 점프 했습니다.",
} end)