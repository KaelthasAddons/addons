﻿local _G = _G
local GetUnitSpeed = GetUnitSpeed
local Speed = _G.LibStub("LibDataBroker-1.1"):NewDataObject("Broker_Speed", {
	icon = "Interface\\Icons\\Ability_Rogue_Sprint.blp",
	label = "Speed",
	suffix = "%",
})
local fSpeed = 0
local color = 'ffffff'
local math = math
local string = string
local function UpdateSpeed(frame,elapsed)
	fSpeed = math.floor(GetUnitSpeed("player") / 7 * 100 + 0.1)
	if fSpeed > 100 then
		color = "ff00ff"
	elseif fSpeed < 100 then
		color = "ffff00"
	else
		color = color
	end
	Speed.value = fSpeed
	Speed.text = string.format("|c%s00%s%s|r", color, fSpeed, Speed.suffix)
end

local frame = CreateFrame("Frame")
frame:SetScript("OnUpdate", UpdateSpeed)