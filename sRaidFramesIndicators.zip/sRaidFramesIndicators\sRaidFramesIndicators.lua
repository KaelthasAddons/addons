-- $Id: sRaidFramesIndicators.lua 21 2008-05-02 08:07:46Z nevcairiel $

--[[
	Grid Style Corner Indicators for sRaidFrames
		Adds one 8x8 indicator frame to the topleft corner of the sRF unit frames that can be used for aggro indication or whatnot
		
		TODO:
			- maybe offer more indicators? Personally i dont feel the need right now, but maybe someone does
		
		Usage:
			Simply select the Indicator option in the Advanced -> Status elements -> [element of your choice] -> GUI Elements config
]]
local sRaidFrames = sRaidFrames

-- Utility function to create the Indicator frame on the unit frames

local backdrop = {
	bgFile = "Interface\\Addons\\sRaidFramesIndicators\\indicator", tile = true, tileSize = 16,
	edgeFile = "Interface\\Addons\\sRaidFramesIndicators\\indicator", edgeSize = 1,
	insets = {left = 1, right = 1, top = 1, bottom = 1},
}

local indicators = { "tl", "tr", "bl", "br" }
local function createIndicatorFrames(frame)
	frame.indicator_init = true
	for i=1,#indicators do
		local indicator = CreateFrame("Frame", nil, frame)
		indicator:SetWidth(8)
		indicator:SetHeight(8)
		indicator:SetBackdrop(backdrop)
		indicator:SetBackdropBorderColor(0,0,0,0)
		indicator:SetBackdropColor(0,0,0,0)
		indicator:Show()
	
		frame["indicator_"..indicators[i]] = indicator
	end
end

-- Hook the StyleUnitFrame function of the different layouts and add our indicator there 
local function layoutIndicators(frame)
	if not frame.indicator_init then
		createIndicatorFrames(frame)
	end
	sRaidFrames:SetWHP(frame.indicator_tl, 8, 8, "TOPLEFT", frame, "TOPLEFT", -1, 1)
	sRaidFrames:SetWHP(frame.indicator_tr, 8, 8, "TOPRIGHT", frame, "TOPRIGHT", 1, 1)
	sRaidFrames:SetWHP(frame.indicator_bl, 8, 8, "BOTTOMLEFT", frame, "BOTTOMLEFT", -1, -1)
	sRaidFrames:SetWHP(frame.indicator_br, 8, 8, "BOTTOMRIGHT", frame, "BOTTOMRIGHT", 1, -1)
end

local function hookStyleFunc(data, newStyleFunc)
	local oldStyleFunc = data.StyleUnitFrame
	data.StyleUnitFrame = function(...)
		oldStyleFunc(...)
		newStyleFunc(...)
	end
end

for name, data in pairs(sRaidFrames.Layouts) do
	hookStyleFunc(data, layoutIndicators)
end

-- Actually register the indicator as a status element with sRF
sRaidFrames:RegisterStatusElement("indicator-tl", "Indicator (Top Left)",
	function(self, frame, status)
		if not frame.indicator_init then return end
		if status == nil then
			frame.indicator_tl:SetBackdropColor(0,0,0,0)
		else
			frame.indicator_tl:SetBackdropColor(status.color.r, status.color.g, status.color.b, status.color.a or 1)
		end
	end)

sRaidFrames:RegisterStatusElement("indicator-tr", "Indicator (Top Right)",
	function(self, frame, status)
		if not frame.indicator_init then return end
		if status == nil then
			frame.indicator_tr:SetBackdropColor(0,0,0,0)
		else
			frame.indicator_tr:SetBackdropColor(status.color.r, status.color.g, status.color.b, status.color.a or 1)
		end
	end)

sRaidFrames:RegisterStatusElement("indicator-bl", "Indicator (Bottom Left)",
	function(self, frame, status)
		if not frame.indicator_init then return end
		if status == nil then
			frame.indicator_bl:SetBackdropColor(0,0,0,0)
		else
			frame.indicator_bl:SetBackdropColor(status.color.r, status.color.g, status.color.b, status.color.a or 1)
		end
	end)

sRaidFrames:RegisterStatusElement("indicator-br", "Indicator (Bottom Right)",
	function(self, frame, status)
		if not frame.indicator_init then return end
		if status == nil then
			frame.indicator_br:SetBackdropColor(0,0,0,0)
		else
			frame.indicator_br:SetBackdropColor(status.color.r, status.color.g, status.color.b, status.color.a or 1)
		end
	end)
