local addonName = "Cooling2"

cyCircled_Cooling2 = cyCircled:NewModule(addonName)

function cyCircled_Cooling2:AddonLoaded()
	self.db = cyCircled:AcquireDBNamespace(addonName)
	cyCircled:RegisterDefaults(addonName, "profile", {
		["Main"] = true,
	})
	
	self:SetupElements()
end

function cyCircled_Cooling2:GetElements()
	return {
		["Main"] = true,
	}
end

function cyCircled_Cooling2:SetupElements()
	self.elements = {
		["Main"] = { 
			args = {
				button = { width = 35, height = 35, },
				nt = false,
				ht = false,
				pt = false, 
				ct = false,
				eborder = false,
			},
			elements = {}, 
		},
	}
	
	for i=1, 15, 1 do
		table.insert(self.elements["Main"].elements, format("Cooling2_Button%d", i))
	end
end
