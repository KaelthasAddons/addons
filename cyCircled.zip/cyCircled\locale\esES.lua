local L = AceLibrary("AceLocale-2.2"):new("cyCircled")

L:RegisterTranslations("esES", function() return {
	["Skin"] = "Skin",
	["skinDesc"] = "Cambia el skin.",
	["Elements"] = "Elementos",
	["elementsDesc"] = "Activa y desactiva este skin.",
	["Toggle plugin"] = "Activar m\195\179dulo",
	["toggleallDesc"] = "Activa el skin en todos los elementos.",
	["toggleskinDesc"] = "Activar skin en %s.",
	["Colors"] = "Colores",
	["ringcolorDesc"] = "Cambia el color del aro",
	["Normal"] = "Normal",
	["normalcolorDesc"] = "Color del aro normal.",
	["Hover"] = "Encima",
	["hovercolorDesc"] = "Color al pasar el rat\195\179n por encima.",
	["Equipped"] = "Equipado",
	["equipcolorDesc"] = "Color del aro cuando est\195\161 enlazado a un objeto equipado.",
	["Config"] = "Configurar",
} end)
