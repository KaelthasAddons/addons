local addonName = "InfiniBar"

cyCircled_InfiniBar = cyCircled:NewModule(addonName)

function cyCircled_InfiniBar:AddonLoaded(addon)
	self.db = cyCircled:AcquireDBNamespace(addonName)
	local barList = InfiniBar:BuildBarList()
	cyCircled:RegisterDefaults(addonName, "profile", barList)
	
	self:SetupElements(barList)
end

function cyCircled_InfiniBar:GetElements()
	return InfiniBar:BuildBarList()
end

function cyCircled_InfiniBar:SetupElements(barList)
	self.elements = {}
	for k in pairs(barList) do
		self.elements[k] = {
			args = {
				button = { width = 35, height = 35, },
				eborder = false,
			},
			elements = InfiniBar:BuildButtonList(k),
		}
	end
end
