local addonName = "Klappa"

cyCircled_Klappa = cyCircled:NewModule(addonName)

function cyCircled_Klappa:AddonLoaded(addon)
	self.db = cyCircled:AcquireDBNamespace(addonName);
	cyCircled:RegisterDefaults(addonName, "profile", {
		["Main"] = true,
		["Popup"] = true,
	})
	self:SetupElements();
end

function cyCircled_Klappa:GetElements()
	return {
		["Main"] = true,
		["Popup"] = true,
	}
end

function cyCircled_Klappa:SetupElements()
	local size = KlappaBar1Row1Button1:GetWidth();
	self.elements = {
		["Main"] =  {
			args = {
				button = { width = size, height = size, },
			},
			elements = {},
		},
		["Popup"] = { 
			args = {
				button = { width = size, height = size, },
			},
			elements = {},
		},
	}

	--for k,v in pairs(Klappa.root.buttons) do
	--	table.insert(self.elements["Main"].elements, "Klappabar"..k.."Button")
	--	for k2,v2 in pairs(Klappa.root.buttons[k].popupButtons) do
	--		table.insert(self.elements["Popup"].elements, "Klappabar"..k.."PopUpButton"..k2)
	--	end
	--end
	
	for k, bar in pairs(Klappa.bars) do
		for i, main in pairs(bar.root.buttons) do
			table.insert(self.elements["Main"].elements, "KlappaBar"..k.."Row"..i.."Button1")
			for k2,v2 in pairs(bar.root.buttons[i].popupButtons) do
				table.insert(self.elements["Popup"].elements, "KlappaBar"..k.."Row"..i.."Button"..k2+1)
			end
		end
	end
	
end
