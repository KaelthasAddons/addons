local addonName = "AutoRack"

cyCircled_AutoRack = cyCircled:NewModule(addonName)

function cyCircled_AutoRack:AddonLoaded()
	self.db = cyCircled:AcquireDBNamespace(addonName)
	cyCircled:RegisterDefaults(addonName, "profile", {
		["Slots"] = true,
	})
	
	self:SetupElements()
	self:OnEnable()
end

function cyCircled_AutoRack:GetElements()
	return {
		["Slots"] = "Slots", -- Add localization?
	}
end

function cyCircled_AutoRack:SetupElements()
	self.elements = {
		["Slots"] = { 
			args = {
				button = { width = 35, height = 35, },
				ft = false,
				hotkey = false,
			},
			elements = {}, 
		},
	}
	
	for i=0, 8, 1 do
		table.insert(self.elements["Slots"].elements, format("AutoRackSlotsItem%d", i))
	end
end