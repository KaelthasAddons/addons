﻿local L = AceLibrary("AceLocale-2.2"):new("cyCircled")

L:RegisterTranslations("zhTW", function() return {
	["Skin"] = "外觀",
	["skinDesc"] = "更換外觀。",
	["Elements"] = "元件",
	["elementsDesc"] = "切換外觀。",
	["Toggle plugin"] = "切換外掛。",
	["toggleallDesc"] = "切換全部元件使用外觀。",
	["toggleskinDesc"] = "切換%s元件外觀。",
	["Colors"] = "顏色",
	["ringcolorDesc"] = "改變外環顏色。",
	["Normal"] = "一般",
	["normalcolorDesc"] = "一般外環顏色。",
	["Hover"] = "停留",
	["hovercolorDesc"] = "滑鼠停留時的外環顏色。",
	["Equipped"] = "裝備",
	["equipcolorDesc"] = "當連結為裝備時的外環顏色。",
	["Config"] = "設定",
} end)
