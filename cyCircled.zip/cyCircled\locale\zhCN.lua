﻿--[[
	Chinese  Local : CWDG Translation Team 冰之魅影
	CWDG site: http://Cwowaddon.com
	$Rev: 1034 $
	$Date: 2007-06-28 00:33:10 +0800 (四, 28 六月 2007) $
]]

local L = AceLibrary("AceLocale-2.2"):new("cyCircled")

L:RegisterTranslations("zhCN", function() return {
	["Skin"] = "皮肤",
	["skinDesc"] = "更换皮肤.",
	["Elements"] = "基础",
	["elementsDesc"] = "皮肤加载/关闭.",
	["Toggle plugin"] = "锁定介面选择.",
	["toggleallDesc"] = "在选定的介面使用皮肤.",
	["toggleskinDesc"] = "在%s栏上切换皮肤.",
	["Colors"] = "颜色",
	["ringcolorDesc"] = "改变皮肤边缘颜色.",
	["Normal"] = "常规",
	["normalcolorDesc"] = "普通状态下的颜色.",
	["Hover"] = "环绕",
	["hovercolorDesc"] = "鼠标指向时的颜色.",
	["Equipped"] = "装备",
	["equipcolorDesc"] = "装备时的外观颜色.",
	["Config"] = "设置",
} end)