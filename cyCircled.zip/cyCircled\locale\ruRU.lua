﻿local L = AceLibrary("AceLocale-2.2"):new("cyCircled")

--ruRU by Swix.  Report bugs to http://forums.playhard.ru/index.php?showforum=89
L:RegisterTranslations("ruRU", function() return {
	["Skin"] = "Скин",
	["skinDesc"] = "Изменить скин",
	["Elements"] = "Плагины",
	["elementsDesc"] = "Включить/выключить скин",
	["Toggle plugin"] = "Активировать плагин",
	["toggleallDesc"] = "Включить/выключить скин для всех элементов плагина",
	["toggleskinDesc"] = "Включить/выключить скин для %s.",
	["Colors"] = "Цвета",
	["ringcolorDesc"] = "Изменить цвет колец",
	["Normal"] = "Основной цвет",
	["normalcolorDesc"] = "Установить основной цвет колец",
	["Hover"] = "Цвет подсветки",
	["hovercolorDesc"] = "Установить цвет колец при наведении на них мышкой",
	["Equipped"] = "Цвет снаряжения",
	["equipcolorDesc"] = "Цвет колец, связанных с надетыми предметами",
	["Config"] = "Настройка",
} end)