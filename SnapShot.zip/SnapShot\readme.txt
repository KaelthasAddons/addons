Install this like any other addon by moving the SnapShot folder
into your WorldOfWarcraft\Interface\AddOns directory.

You can access the addon over its minimap-button, by using the
command /snapshot or by assigning a key to it through the "Key
Bindings" menu of WoW.
