loc = GetLocale();

if (loc == "frFR") then

	SNAP_LEVELUP = "Snapshot: Character leveled up";
	SNAP_NEWCHARACTER = "Snapshot: New character";
	SNAP_LEVEL = "Snapshot: Haven't made one yet this level";
	SNAP_MONTH = "Snapshot: More than a month since last one";
	SNAP_TWOWEEKS = "Snapshot: More than two weeks since last one";
	SNAP_NEWITEMS = "Snapshot: Several new items";

	SNAP_NOSHOTS = "You have not yet made any snapshots";
	SNAP_WITHTHISCHAR = "with this character";

	SNAPSHOT_DELETEQUESTION = "Do you really want to delete this snapshot?";
	SNAPSHOT_YES = "Oui";
	SNAPSHOT_NO = "Non";
	SNAPSHOT_CANNOTDELETELAST = "You cannot delete this shot as it's the last one left";

	SNAP_HUNTER = "Chasseur";
	SNAP_HAT = "Chapeau";
	SNAP_CLOAK = "Cape";

elseif (loc == "deDE") then

	SNAP_LEVELUP = "Snapshot: Character leveled up";
	SNAP_NEWCHARACTER = "Snapshot: New character";
	SNAP_LEVEL = "Snapshot: Haven't made one yet this level";
	SNAP_MONTH = "Snapshot: More than a month since last one";
	SNAP_TWOWEEKS = "Snapshot: More than two weeks since last one";
	SNAP_NEWITEMS = "Snapshot: Several new items";

	SNAP_NOSHOTS = "You have not yet made any snapshots";
	SNAP_WITHTHISCHAR = "with this character";

	SNAPSHOT_DELETEQUESTION = "Wollen sie diese Aufnahme wirklich l\195\182schen?";
	SNAPSHOT_YES = "Ja";
	SNAPSHOT_NO = "Nein";
	SNAPSHOT_CANNOTDELETELAST = "You cannot delete this shot as it's the last one left";

	SNAP_HUNTER = "J\195\164ger";
	SNAP_HAT = "Hut";
	SNAP_CLOAK = "Umhang";

elseif (loc == "koKR") then

	SNAP_LEVELUP = "Snapshot: Character leveled up";
	SNAP_NEWCHARACTER = "Snapshot: New character";
	SNAP_LEVEL = "Snapshot: Haven't made one yet this level";
	SNAP_MONTH = "Snapshot: More than a month since last one";
	SNAP_TWOWEEKS = "Snapshot: More than two weeks since last one";
	SNAP_NEWITEMS = "Snapshot: Several new items";

	SNAP_NOSHOTS = "You have not yet made any snapshots";
	SNAP_WITHTHISCHAR = "with this	 character";

	SNAPSHOT_DELETEQUESTION = "Do you really want to delete this snapshot?";
	SNAPSHOT_YES = "Yes";
	SNAPSHOT_NO = "No";
	SNAPSHOT_CANNOTDELETELAST = "You cannot delete this shot as it's the last one left";

	SNAP_HUNTER = "사냥꾼";
	SNAP_HAT = "Hat";
	SNAP_CLOAK = "Cloak";

else

	SNAP_LEVELUP = "Snapshot: Character leveled up";
	SNAP_NEWCHARACTER = "Snapshot: New character";
	SNAP_LEVEL = "Snapshot: Haven't made one yet this level";
	SNAP_MONTH = "Snapshot: More than a month since last one";
	SNAP_TWOWEEKS = "Snapshot: More than two weeks since last one";
	SNAP_NEWITEMS = "Snapshot: Several new items";

	SNAP_NOSHOTS = "You have not yet made any snapshots";
	SNAP_WITHTHISCHAR = "with this character";

	SNAPSHOT_DELETEQUESTION = "Do you really want to delete this snapshot?";
	SNAPSHOT_YES = "Yes";
	SNAPSHOT_NO = "No";
	SNAPSHOT_CANNOTDELETELAST = "You cannot delete this shot as it's the last one left";

	SNAP_HUNTER = "Hunter";
	SNAP_HAT = "Hat";
	SNAP_CLOAK = "Cloak";

end;
