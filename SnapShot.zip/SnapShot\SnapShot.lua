BINDING_HEADER_SNAPSHOT = "SnapShot";
BINDING_NAME_SNAP = "Open SnapShot window";

SnapShot_shots = {};
SnapShot_mini = {}
local SnapShot_current = -1;

local SlotInfo = {
	[1] = "HeadSlot",
	[2] = "NeckSlot",
	[3] = "ShoulderSlot",
	[4] = "ShirtSlot",
	[5] = "ChestSlot",
	[6] = "WaistSlot",
	[7] = "LegsSlot",
	[8] = "FeetSlot",
	[9] = "WristSlot",
	[10] = "HandsSlot",
	[11] = "Finger0Slot",
	[12] = "Finger1Slot",
	[13] = "Trinket0Slot",
	[14] = "Trinket1Slot",
	[15] = "BackSlot",
	[16] = "MainHandSlot",
	[17] = "SecondaryHandSlot",
	[18] = "RangedSlot",
	[19] = "TabardSlot",
}

local Months = {
	["Jan"] = 1,
	["Feb"] = 2,
	["Mar"] = 3,
	["Apr"] = 4,
	["May"] = 5,
	["Jun"] = 6,
	["Jul"] = 7,
	["Aug"] = 8,
	["Sep"] = 9,
	["Oct"] = 10,
	["Nov"] = 11,
	["Dec"] = 12,
}

--
-- Debug output
--

local function debugprint(x)
	DEFAULT_CHAT_FRAME:AddMessage(x, 0.5, 0, 1);
end

--
-- Check if the zone we are currently in is a PvE raid zone. If yes, the character is probably in his battle gear
--
local RaidZones = {
	"Karazhan",
	"Gruul",
	"Serpentshrine",
	"Tempest Keep",
	"Hyjal",
	"Black Temple",
	"Sunwell",
}
local function IsRaidZone(z)
	for _, v in ipairs(RaidZones) do
		if strmatch(z, v) then
			return true;
		end
	end

	return false;
end


--
-- Receives the id of a button as its argument, then returns an item link in the format of "item:14727:0:0:0" to be used in a tooltip
--
local function GetLink(id)
	item = SnapShot_shots[SnapShot_current][id];
	if (item == nil) then
		return nil;
	end

	--_, _, itemCode = strfind(item, "|H(item:%d+:%d+:%d+:%d+:%d+:%d+:%d+:%d+)|");
	_, _, itemCode = strfind(item, "|H(item:[%d\-]+:[%d\-]+:[%d\-]+:[%d\-]+:[%d\-]+:[%d\-]+:[%d\-]+:[%d\-]+)|");
	return itemCode;
end


--
-- Displays or hites the checkboxes to show the hat and cloak on the dressup model
--
local function SetHatCloakButton(check)
	if (check == 1) then
		HatCheckButton:Show();
		CloakCheckButton:Show();
	else
		HatCheckButton:Hide();
		CloakCheckButton:Hide();
	end
end


--
-- Receives the id of a button as its argument, then returns an item link in the full format to be displayed in chat etc
--
local function GetHyperlink(id)
	return SnapShot_shots[SnapShot_current][id];
end


--
-- Receives the id of a button as its argument, then returns an item link in the full format to be displayed in chat etc
--
local function GetOldHyperlink(ver, id)
	return SnapShot_shots[ver][id];
end


--
-- Check if this item has already been worn in one of the last 6 snapshots
--
local function ItemIsNew(i)
	link = GetInventoryItemLink("player", i);
	if (link == nil) then
		return false;
	end;
	current = gsub(link, ".*item:(%d+).*", "%1", 1);

	lastNum = SnapShot_shots["n"];
	compared = 0;
	repeat
		link = GetOldHyperlink(lastNum, i);
		if (link) then
			old = gsub(link, ".*item:(%d+).*", "%1", 1);
			if (old == current) then
				return false;
			end;
		end;

		lastNum = lastNum - 1;
		compared = compared + 1;
	until (lastNum == 1 or compared >= 6);

	return true;
end

--
-- Check if all the items currently being worn by this character have already been worn in the last 3 snapshots
--
local function AnyItemIsNew()
	for i = 1, 19 do
		if (ItemIsNew(i)) then
			return true;
		end;
	end;

	return false;
end

--
-- Check how many items on this character are newly acquired
--
local function NumNewItems()
	r = 0
	for i = 1, 19 do
		if (ItemIsNew(i)) then
			r = r + 1;
		end;
	end;

	return r;
end


--
-- Converts the date format used in older versions into a newer time format
--
local function FixDates()
	if (SnapShot_shots == nil) then
		return;
	end
	if (SnapShot_shots[1] == nil) then
		return;
	end
	if (SnapShot_shots[1]["time"] == nil) then
		if (strfind(SnapShot_shots[1]["date"], "%a+")) then
			for i = 1, SnapShot_shots["n"] do
				SnapShot_shots[i]["time"] = SnapShot_MacDate(SnapShot_shots[i]["date"]);
			end
		else
			for i = 1, SnapShot_shots["n"] do
				SnapShot_shots[i]["time"] = SnapShot_PcDate(SnapShot_shots[i]["date"]);
			end
		end
	end
end

--
-- Converts an itemlink into the new TBC format
--
local function ConvertLink(oldlink)
	_, _, part1, part2 = strfind(oldlink, "(|.*|Hitem:%d+:%d+:)(%d+:%d+|h.*|h|r)");
	if (part2 == nil) then
		return nil;
	end
	if (part1 == nil) then
		return nil;
	end
	newlink = part1 .. "0:0:0:0:" .. part2;

	return newlink;
end

--
-- Converts version 1.0 into the new 2.0 snapshots
--
local function ConvertPreTBCSnapshots()
	SnapShot_shots["v1_n"] = SnapShot_shots["n"];
	for i = 1, SnapShot_shots["n"] do
		SnapShot_shots["v1_" .. i] = {};
		for j = 1, 19 do
			if (SnapShot_shots[i][j] ~= nil) then
				SnapShot_shots["v1_" .. i][j] = SnapShot_shots[i][j];
				SnapShot_shots[i][j] = ConvertLink(SnapShot_shots[i][j]);
			end
		end
	end
end

-- "|cffffffff|Hitem:6120:0:0:0|h[Recruit's Shirt]|h|r"

--
-- Converts version 1.0 into the new 2.0 snapshots
--
local function FixPreTBCSnapshots()
	if (SnapShot_shots == nil) then
		return;
	end
	if (SnapShot_shots["n"] == nil) then
		return;
	end

	local found = false;
	for i = 1, SnapShot_shots["n"] do
		for j = 1, 19 do
			if (SnapShot_shots[i][j] ~= nil) then
				ifound = i;
				jfound = j;
				found = true;
				break;
			end
		end
		if (found) then
			break;
		end
	end

	_, _, itemCode = strfind(SnapShot_shots[ifound][jfound], "|H(item:%d+:%d+:%d+:%d+)|");
	if (itemCode ~= nil) then
		-- Ok this item link is in the old version 1.0 format so we have to convert all links
		DEFAULT_CHAT_FRAME:AddMessage("Converting Snapshots into WoW 2.0 Format", 0, 1, 1);
		ConvertPreTBCSnapshots();
	end
end


function SnapShot_initialize()
	SlashCmdList["SNAPSHOTPLAY"] = 	ToggleSnapShot;
	SLASH_SNAPSHOTPLAY1 = "/snapshot";
	
	this:RegisterEvent("PLAYER_LEVEL_UP");
	this:RegisterEvent("PLAYER_ENTERING_WORLD");

	FixDates();
	FixPreTBCSnapshots();
	if (SnapShot_shots["show_minimap_button"] == nil) then
		SnapShot_shots["show_minimap_button"] = 1;
	end;
	if (SnapShot_shots["show_hatcloak_button"] == nil) then
		SnapShot_shots["show_hatcloak_button"] = 0;
	end;

	SetHatCloakButton(SnapShot_shots["show_hatcloak_button"]);
end;

function SnapShot_store(msg)
	SnapShot_captureShot(UnitLevel("player"));
end;

function SnapShot_captureShot(level)
	current_shot = {}
	for i = 0, 19 do
		current_shot[i] = GetInventoryItemLink("player", i);
	end

	current_shot["cloak"] = (ShowingCloak() == 1);
	current_shot["hat"] = (ShowingHelm() == 1);

	current_shot["level"] = level;
	--current_shot["date"] = date("%m/%d/%y %H:%M:%S");
	current_shot["time"] = time();

	guild, guildRank, _ = GetGuildInfo("player");
	current_shot["guildRank"] = guildRank;
	current_shot["guild"] = guild;

	--[[ current_shot["HeadSlot"] = GetInventoryItemLink("player", GetInventorySlotInfo("HeadSlot"))
	current_shot["ShoulderSlot"] = GetInventoryItemLink("player", GetInventorySlotInfo("ShoulderSlot"))
	current_shot["NeckSlot"] = GetInventoryItemLink("player", GetInventorySlotInfo("Slot"))
	current_shot["BackSlot"] = GetInventoryItemLink("player", GetInventorySlotInfo("Slot"))
	current_shot["ChestSlot"] = GetInventoryItemLink("player", GetInventorySlotInfo("Slot"))
	current_shot["ShirtSlot"] = GetInventoryItemLink("player", GetInventorySlotInfo("Slot"))
	current_shot["TabardSlot"] = GetInventoryItemLink("player", GetInventorySlotInfo("Slot"))
	current_shot["WristSlot"] = GetInventoryItemLink("player", GetInventorySlotInfo("Slot"))
	current_shot["HandsSlot"] = GetInventoryItemLink("player", GetInventorySlotInfo("Slot"))
	current_shot["WaistSlot"] = GetInventoryItemLink("player", GetInventorySlotInfo("Slot"))
	current_shot["LegsSlot"] = GetInventoryItemLink("player", GetInventorySlotInfo("Slot"))
	current_shot["FeetSlot"] = GetInventoryItemLink("player", GetInventorySlotInfo("Slot"))
	current_shot["Finger0Slot"] = GetInventoryItemLink("player", GetInventorySlotInfo("Slot"))
	current_shot["Finger1Slot"] = GetInventoryItemLink("player", GetInventorySlotInfo("Slot"))
	current_shot["Trinket0Slot"] = GetInventoryItemLink("player", GetInventorySlotInfo("Slot"))
	current_shot["Trinket1Slot"] = GetInventoryItemLink("player", GetInventorySlotInfo("Slot"))
	current_shot["MainHandSlot"] = GetInventoryItemLink("player", GetInventorySlotInfo("MainHandSlot"))
	current_shot["SecondaryHandSlot"] = GetInventoryItemLink("player", GetInventorySlotInfo("SecondaryHandSlot"))
	current_shot["RangedSlot"] = GetInventoryItemLink("player", GetInventorySlotInfo("RangedSlot")) ]]--

	if (SnapShot_shots["n"] == nil) then
		SnapShot_shots["n"] = 1;
	else
		SnapShot_shots["n"] = SnapShot_shots["n"] + 1;
	end

	SnapShot_shots[SnapShot_shots["n"]] = current_shot;

	-- Check if this is the first save, if yes, store some info about this character
	if (SnapShot_shots["name"] == nil) then
		SnapShot_shots["name"] = UnitName("player");
		SnapShot_shots["class"], _ = UnitClass("player");
	end
end;

function SnapShot_OnEvent()
	if (event == "VARIABLES_LOADED") then		
		SnapShot_initialize();
		MyMinimapButton:Create("SnapShot", SnapShot_mini)
		MyMinimapButton:SetIcon("SnapShot", "Interface\\Icons\\INV_Misc_Spyglass_03")
		MyMinimapButton:SetLeftClick("SnapShot", ToggleSnapShot)
		MyMinimapButton:SetEnable("SnapShot", SnapShot_shots["show_minimap_button"]);
		
		HatCheckButtonText:SetText(SNAP_HAT);
		CloakCheckButtonText:SetText(SNAP_CLOAK);
	end

	if (event == "PLAYER_LEVEL_UP") then
		SnapShot_captureShot(arg1);
		DEFAULT_CHAT_FRAME:AddMessage(SNAP_LEVELUP, 0, 1, 1);
	end

	if (event == "PLAYER_ENTERING_WORLD") then
		-- If we haven't made a snapshot yet, someone probably just started this character, so make one
		if (SnapShot_shots["n"] == nil) then
			SnapShot_captureShot(UnitLevel("player"));
			DEFAULT_CHAT_FRAME:AddMessage(SNAP_NEWCHARACTER, 0, 0.6, 1);
		elseif (SnapShot_shots[SnapShot_shots["n"]]["level"] < UnitLevel("player")) then
			-- If we haven't made a snapshot yet this level, make one
			SnapShot_captureShot(UnitLevel("player"));
			DEFAULT_CHAT_FRAME:AddMessage(SNAP_LEVEL, 0, 1, 1);
		elseif (time() - SnapShot_shots[SnapShot_shots["n"]]["time"] > 2629743) then
			-- If the last snapshot was more than a month ago, make one
			SnapShot_captureShot(UnitLevel("player"));
			DEFAULT_CHAT_FRAME:AddMessage(SNAP_MONTH, 0, 1, 1);
		elseif (time() - SnapShot_shots[SnapShot_shots["n"]]["time"] > 1209600 and IsRaidZone(GetRealZoneText())) then
			-- If the last snapshot was more than two weeks ago, take a snapshot once this character enters a raid zone
			SnapShot_captureShot(UnitLevel("player"));
			DEFAULT_CHAT_FRAME:AddMessage(SNAP_TWOWEEKS, 0, 1, 1);
		elseif (time() - SnapShot_shots[SnapShot_shots["n"]]["time"] > 304800 and IsRaidZone(GetRealZoneText()) and NumNewItems() > 3) then
			-- If the last snapshot was more than a week ago and more than 3 items are new, take a snapshot
			SnapShot_captureShot(UnitLevel("player"));
			DEFAULT_CHAT_FRAME:AddMessage(SNAP_NEWITEMS, 0, 1, 1);
		end
	end;
end;


--
-- Take the difference between two dates in "mm/dd/yy hh:mm:ss" format in seconds
--
function SnapShot_DateDistance(date1, date2)
	_, _, mo1, d1, y1, h1, mi1, s1 = strfind(date1, "(%d+)/(%d+)/(%d+) (%d+)%:(%d+)%:(%d+)");
	_, _, mo2, d2, y2, h2, mi2, s2 = strfind(date2, "(%d+)/(%d+)/(%d+) (%d+)%:(%d+)%:(%d+)");

	t1 = y1 * 31556926 + mo1 * 2629743 + d1 * 86400 + h1 * 3600 + mi1 * 60 + s1;
	t2 = y2 * 31556926 + mo2 * 2629743 + d2 * 86400 + h2 * 3600 + mi2 * 60 + s2;

	return(t2-t1);	
end


--
-- Turns a pc format date into seconds
--
function SnapShot_PcDate(d)
-- Fri Nov 17 17:27:57 2006
	_, _, mo1, d1, y1, h1, mi1, s1 = strfind(d, "(%d+)/(%d+)/(%d+) (%d+)%:(%d+)%:(%d+)");

	local datetable = {};
	datetable["year"] = 2000 + y1;
	datetable["month"] = mo1;
	datetable["day"] = d1;
	datetable["hour"] = h1;
	datetable["min"] = mi1;
	datetable["sec"] = s1;

	t1 = time(datetable);
	return(t1);
end


--
-- Turns a macintosh format date into seconds
--
function SnapShot_MacDate(d)
-- Fri Nov 17 17:27:57 2006
	_, _, mo1, d1, h1, mi1, s1, y1 = strfind(d, "%a+ (%a+) (%d+) (%d+)%:(%d+)%:(%d+) (%d+)");

	local datetable = {};
	datetable["year"] = y1;
	datetable["month"] = Months[mo1];
	datetable["day"] = d1;
	datetable["hour"] = h1;
	datetable["min"] = mi1;
	datetable["sec"] = s1;

	t1 = time(datetable);
	return(t1);
end
-- /script SnapShot_MacDate("Fri Nov 17 17:27:57 2006");
-- /script message(date("%m/%d/%y %H:%M:%S"));

--
-- Take the difference between two dates in "mm/dd/yy hh:mm:ss" format in seconds
--
function SnapShot_PrintDuration(dur)
	y = math.floor(dur / 31556926);
	dur = dur - y * 31556926;

	mo = math.floor(dur / 2629743);
	dur = dur - mo * 2629743;

	d = math.floor(dur / 86400);
	dur = dur - d * 86400;

	h = math.floor(dur / 3600);
	dur = dur - h * 3600;

	mi = math.floor(dur / 60);
	dur = dur - mi * 60;

	s = dur;

	DEFAULT_CHAT_FRAME:AddMessage(y .. " years " .. mo .. " months " .. d .. " days " .. h .. " hours " .. mi .. " minutes " .. s .. " seconds", 1, 0, 1);
end


function SS_ListItems()
	for i = 1, 19 do
		if (ItemIsNew(i)) then
			DEFAULT_CHAT_FRAME:AddMessage(SlotInfo[i] .. " is new", 0, 1, 1);
		else
			DEFAULT_CHAT_FRAME:AddMessage(SlotInfo[i] .. " is old", 0, 1, 1);
		end;
	end;
end;


function ToggleSnapShot()
	if( SnapShotFrame:IsVisible() ) then
		HideUIPanel(SnapShotFrame);
	else
		ShowUIPanel(SnapShotFrame);
	end
end

--
-- Remembers the name of the background texture so we can later display that if a slot remains unused
--
function SnapShotItemButton_OnShow()
	id = this:GetID();
	id, textureName, checkRelic = GetInventorySlotInfo(SlotInfo[id]);
	if (textureName == nil) then
		DEFAULT_CHAT_FRAME:AddMessage(SlotInfo[id], 0, 1, 1);
	end
	local texture = getglobal("CharacterMainHandSlotIconTexture");
	texture:SetTexture(textureName);
	this.backgroundTextureName = textureName;
	--DEFAULT_CHAT_FRAME:AddMessage(textureName, 0, 1, 1);
	this.checkRelic = checkRelic;
end


--
-- Handles the clicking used to display an item in chat or on a dressup model
--
function SnapShotItemButton_OnClick(button)
	if( IsShiftKeyDown() and ChatFrameEditBox:IsVisible() ) then
		ChatFrameEditBox:Insert(GetHyperlink(this:GetID()));
	elseif ( IsControlKeyDown() ) then
		DressUpItemLink(GetHyperlink(this:GetID()));
	end
end

--
-- Displays a tooltip when the user mouseovers over an item button
--
function SnapShotItemButton_OnEnter()
	if (SnapShot_shots["n"] == nil) then
		return;
	end;
	local buttonID = this:GetID();
	local link = GetLink(buttonID);
	if ( link ) then
		SnapShotFrame.TooltipButton = this:GetID();
		SnapShotTooltip:SetOwner(this, "ANCHOR_BOTTOMRIGHT");
		SnapShotTooltip:SetHyperlink(link);
	end
end

--
-- Closes the tooltip when the mouse pointer leaves an item button
--
function SnapShotItemButton_OnLeave()
	if (SnapShot_shots["n"] == nil) then
		return;
	end;
	if( SnapShotFrame.TooltipButton ) then
		SnapShotFrame.SnapShotButton = nil;
		HideUIPanel(SnapShotTooltip);
	end
end


--
-- Rearranges the main display frame to show the stored snapshot indexed by the SnapShot_current variable
--
function SnapShot_Update()
	local snapShotItem = nil;

	SnapShot_Model:Undress();

	if (SnapShot_shots["n"] == nil or SnapShot_shots["n"] == 0) then
		SnapShotLevelText:SetText(SNAP_NOSHOTS);
		SnapShotDateText:SetText(SNAP_WITHTHISCHAR);
		getglobal("SnapShotLastButton"):Disable();
		getglobal("SnapShotNextButton"):Disable();
		return;
	end

	-- Set the hat and cloak buttons
	if (SnapShot_shots[SnapShot_current]["hat"] == nil) then SnapShot_shots[SnapShot_current]["hat"] = false; end;
	if (SnapShot_shots[SnapShot_current]["cloak"] == nil) then SnapShot_shots[SnapShot_current]["cloak"] = false; end;
	if (SnapShot_shots[SnapShot_current]["hat"] == 0) then SnapShot_shots[SnapShot_current]["hat"] = false; end;
	if (SnapShot_shots[SnapShot_current]["cloak"] == 0) then SnapShot_shots[SnapShot_current]["cloak"] = false; end;
	HatCheckButton:SetChecked(SnapShot_shots[SnapShot_current]["hat"]);
	CloakCheckButton:SetChecked(SnapShot_shots[SnapShot_current]["cloak"]);

	-- If this character is not a hunter, equip the ranged slot first so their melee weapons are visible
	if (SnapShot_shots["class"] ~= SNAP_HUNTER) then
		SnapShot_DisplayItem(18, true);
	end
	for i = 1, 19 do
		if (i == 1) then
			if (SnapShot_shots[SnapShot_current]["hat"]) then
				SnapShot_DisplayItem(i, true);
			else
				SnapShot_DisplayItem(i, false);
			end
		elseif (i == 15) then
			if (SnapShot_shots[SnapShot_current]["cloak"]) then
				SnapShot_DisplayItem(i, true);
			else
				SnapShot_DisplayItem(i, false);
			end
		elseif (i == 18) then
			if (SnapShot_shots["class"] == SNAP_HUNTER) then
				SnapShot_DisplayItem(i, true);
			else
				SnapShot_DisplayItem(i, false);
			end;
		else
			SnapShot_DisplayItem(i, true);
		end;
	end

	-- Set the title text
	SnapShotNameText:SetText(SnapShot_shots["name"]);
	SnapShotLevelText:SetText("Level " .. SnapShot_shots[SnapShot_current]["level"] .. " " .. SnapShot_shots["class"]);
	SnapShotDateText:SetText(date("%c", SnapShot_shots[SnapShot_current]["time"]));
	if (SnapShot_shots[SnapShot_current]["guild"] ~= nil) then
		SnapShotGuildText:SetText(SnapShot_shots[SnapShot_current]["guildRank"] .. " of " .. SnapShot_shots[SnapShot_current]["guild"]);
	else
		SnapShotGuildText:SetText("");
	end

	SnapShot_EnableNavigation();
end

--
-- Puts one item onto the dressup doll and into the inventory slot
--
function SnapShot_DisplayItem(i, showItem)
	snapShotItem = getglobal("SnapShotItem" .. i);
	-- Get the item hyperlink out of the current snapshot
	itemLink = GetLink(i);
	if (itemLink ~= nil) then
		if (showItem) then
			SnapShot_Model:TryOn(gsub(itemLink, ".*item:(%d+).*", "%1", 1));
		end;
		local _, _, _, _, _, _, _, _, _, iconTexture = GetItemInfo(itemLink);
		snapShotItem:SetNormalTexture(iconTexture);
	else
		snapShotItem:SetNormalTexture(snapShotItem.backgroundTextureName);
	end;
end

--
-- If the frame is opened, display the last taken snapshot
--
function SnapShot_OnShow()
	SnapShot_current = SnapShot_shots["n"];
	SnapShot_Update();
end

--
-- Move back one snapshot to the past
--
function SnapShot_Last()
	if (SnapShot_current > 1) then
		SnapShot_current = SnapShot_current - 1;
	end
	SnapShot_Update();
end

--
-- Move forward one snapshot to the future
--
function SnapShot_Next()
	if (SnapShot_current < SnapShot_shots["n"]) then
		SnapShot_current = SnapShot_current + 1;
	end
	SnapShot_Update();
end

--
-- Move back 10 snapshots to the past
--
function SnapShot_Last10()
	if (SnapShot_current > 11) then
		SnapShot_current = SnapShot_current - 10;
	else
		SnapShot_current = 1;
	end
	SnapShot_Update();
end

--
-- Move forward 10 snapshots to the future
--
function SnapShot_Next10()
	if (SnapShot_current < SnapShot_shots["n"] - 10) then
		SnapShot_current = SnapShot_current + 10;
	else
		SnapShot_current = SnapShot_shots["n"];
	end
	SnapShot_Update();
end

--
-- Move forward to the newest snapshot
--
function SnapShot_Newest()
	SnapShot_current = SnapShot_shots["n"];
	SnapShot_Update();
end

--
-- Disables the navigation buttons so people don't get confused while deleting
--
function SnapShot_DisableNavigation()
	SnapShotLastButton:Disable();
	SnapShotLast10Button:Disable();
	SnapShotNextButton:Disable();
	SnapShotNext10Button:Disable();
end


--
-- Enables the navigation buttons
--
function SnapShot_EnableNavigation()
	-- If we're on the first or last snapshot, disable one of the navigation buttons
	if (SnapShot_current == 1) then
		SnapShotLastButton:Disable();
		SnapShotLast10Button:Disable();
	else
		SnapShotLastButton:Enable();
		SnapShotLast10Button:Enable();
	end
	if (SnapShot_current == SnapShot_shots["n"]) then
		SnapShotNextButton:Disable();
		SnapShotNext10Button:Disable();
	else
		SnapShotNextButton:Enable();
		SnapShotNext10Button:Enable();
	end
end


--
-- Deletes the currently displayed snapshot
--
function SnapShot_DeleteCurrent()
	local s = SnapShot_current;
	local e = SnapShot_shots["n"] - 1;

	if (e == 0) then
		DEFAULT_CHAT_FRAME:AddMessage(SNAPSHOT_CANNOTDELETELAST, 1, 0, 0);
		return;
	end;
	
	for i = s, e do
		SnapShot_shots[i] = SnapShot_shots[i+1];
	end;

	SnapShot_shots[SnapShot_shots["n"]] = nil;

	SnapShot_shots["n"] = SnapShot_shots["n"] - 1;

	SnapShot_current = SnapShot_current - 1;
	if (SnapShot_current == 0) then
		SnapShot_current = 1;
	end;
	SnapShot_Update();
end

function SnapShotModel_OnLoad()
	this.rotation = 0.61;
	this:SetRotation(this.rotation);
end

function SnapShot_About()
	SnapShotAboutFrame:Show();
end

function OptionsDropDown_OnLoad()
	UIDropDownMenu_SetAnchor(3, 80, this, "TOPLEFT", this:GetName(), "TOPRIGHT");

	-- Wierd thing that is certainly because I'm implementing this wrong is that the following command keeps resizing my button so I
	-- have to re-resize it :o
	UIDropDownMenu_Initialize(this, OptionsDropDown_Initialize);

	--UIDropDownMenu_Refresh(this);

	ToggleDropDownMenu(1, nil, this);

	-- Re-resize here
	this:SetHeight(26);
end

function OptionsDropDown_Initialize()
	local vFrame = getglobal(UIDROPDOWNMENU_INIT_MENU);
	local pColor = NORMAL_FONT_COLOR;
	
	UIDropDownMenu_AddButton({text = "Take", notCheckable = true, notClickable = true});
	UIDropDownMenu_AddButton({text = "Take Snapshot", value = 1, owner = vFrame, checked = nil, func = OptionsDropDown_OnClick, textR = pColor.r, textG = pColor.g, textB = pColor.b, disabled = nil}, nil);

	UIDropDownMenu_AddButton({text = "Delete", notCheckable = true, notClickable = true});
	UIDropDownMenu_AddButton({text = "Delete Snapshot...", value = 2, owner = vFrame, checked = nil, func = OptionsDropDown_OnClick, textR = pColor.r, textG = pColor.g, textB = pColor.b, disabled = nil}, nil);

	UIDropDownMenu_AddButton({text = "Options", notCheckable = true, notClickable = true});

	if (SnapShot_shots["show_minimap_button"] == 0) then
		pChecked = nil;
	else
		pChecked = 1;
	end;
	UIDropDownMenu_AddButton({text = "Show Minimap Button", value = 3, owner = vFrame, checked = pChecked, func = OptionsDropDown_OnClick, textR = pColor.r, textG = pColor.g, textB = pColor.b, disabled = nil, keepShownOnClick = 1}, nil);

	if (SnapShot_shots["show_hatcloak_button"] == 0) then
		pChecked = nil;
	else
		pChecked = 1;
	end;
	UIDropDownMenu_AddButton({text = "Show Hat/Cloak Buttons", value = 4, owner = vFrame, checked = pChecked, func = OptionsDropDown_OnClick, textR = pColor.r, textG = pColor.g, textB = pColor.b, disabled = nil, keepShownOnClick = 1}, nil);
end

StaticPopupDialogs["SNAPSHOT_DELETE"] = {
  text = SNAPSHOT_DELETEQUESTION,
  button1 = SNAPSHOT_YES,
  button2 = SNAPSHOT_NO,
  OnAccept = function() SnapShot_DeleteCurrent() end,
  OnCancel = function() SnapShot_EnableNavigation() end,
  timeout = 0,
  whileDead = 1,
  hideOnEscape = 1
};


--
-- Handles clicks on the Options drop down menu
--
function OptionsDropDown_OnClick()
	if (this.value == 1) then --Take
		SnapShot_captureShot(UnitLevel("player"));
		SnapShot_Newest();
	elseif (this.value == 2) then --Delete
		SnapShot_DisableNavigation();
		StaticPopup_Show("SNAPSHOT_DELETE");
	elseif (this.value == 3) then --Minimap Butan
		local check;
		if (this.checked) then
			check = 0;
		else
			check = 1;
		end;
		MyMinimapButton:SetEnable("SnapShot", check);
		SnapShot_shots["show_minimap_button"] = check;
	elseif (this.value == 4) then --Hat/Cloak Butan
		local check;
		if (this.checked) then
			check = 0;
		else
			check = 1;
		end;
		SetHatCloakButton(check);
		SnapShot_shots["show_hatcloak_button"] = check;
	end;
end

--
-- Handles clicks on the Hat display button
--
function SnapShot_Hat_OnClick()
	local check = HatCheckButton:GetChecked();
	if (check == nil) then
		check = false;
	end;

	SnapShot_shots[SnapShot_current]["hat"] = check;

	SnapShot_Update();
end

--
-- Handles clicks on the Cloak display button
--
function SnapShot_Cloak_OnClick()
	local check = CloakCheckButton:GetChecked();
	if (check == nil) then
		check = false;
	end;

	SnapShot_shots[SnapShot_current]["cloak"] = check;

	SnapShot_Update();
end

