-- only allow french clients to use this localization
if (GetLocale() == "frFR") then
	
	-- short strings
	rewatch_loc["prefix"] = "Rw: ";

	-- report messages
	rewatch_loc["welcome"] = "Thank you for trying Rewatch! Pour l'aide, utiliser \"/rewatch help\"";
	rewatch_loc["cleared"] = "Donn\195\169es correctement remises \195\160 z\195\169ro";
	rewatch_loc["credits"] = "Rewatch AddOn par Dezyne, AD (EU), 2008. Pour l'aide, utiliser \"/rewatch help\"";
	rewatch_loc["invalid_command"] = "Commande invalide. Pour de l'aide, taper \"/rewatch help\"";
	rewatch_loc["noplayer"] = "No such player!";
	rewatch_loc["combatfailed"] = "Cannot perform requested action; you're in combat";
	rewatch_loc["sorted"] = "Re-sorted the players";
	rewatch_loc["nosort"] = "Could not re-sort the players, because the auto-group feature is disabled (not saved). To enable this, type \"/rewatch autogroup 1\", or to just clear the list, type \"/rewatch clear\"";
	rewatch_loc["nonumber"] = "This is not a valid number!";
	rewatch_loc["setalpha"] = "Set the global cooldown overlay alpha to ";
	rewatch_loc["sethidesolo"] = "Set the hide on solo feature to ";
	rewatch_loc["sethide"] = "Set the hide feature to ";
	rewatch_loc["setautogroup"] = "Set the auto-group feature to ";
	rewatch_loc["buffresults"] = "Buff check results:";
	rewatch_loc["nothorns"] = "Pas de Epines found.";
	rewatch_loc["missingmotw"] = "Joueurs missing Marque/Don du fauve:";
	
	-- ui texts
	rewatch_loc["visible"] = "Visible";
	rewatch_loc["invisible"] = "Invisible";
	rewatch_loc["gcdText"] = "Global cooldown overlay transparency:";
	rewatch_loc["hide"] = "Hide always";
	rewatch_loc["hideSolo"] = "Hide when soloing";
	rewatch_loc["autoAdjust"] = "Automatically adjust to group";
	rewatch_loc["buffCheck"] = "Buff check";
	rewatch_loc["sortList"] = "Sort list";
	rewatch_loc["clearList"] = "Clear list";

	-- help messages
	rewatch_loc["help"] = {};
	rewatch_loc["help"][1] = "Rewatch - commandes disponibles:";
	rewatch_loc["help"][2] = " /rewatch: affichage des cr\195\169dits";
	rewatch_loc["help"][3] = " /rewatch add [_target||<name>]: adds either your target, or the player with the specified name to the list";
	rewatch_loc["help"][4] = " /rewatch clear: r\195\169initialise la liste de rewatch";
	rewatch_loc["help"][5] = " /rewatch sort: resort la liste de rewatch";
	rewatch_loc["help"][6] = " /rewatch gcdAlpha [0 through 1]: sets the global cooldown overlay alpha, default=1=fully visible";
	rewatch_loc["help"][7] = " /rewatch hideSolo [0 or 1]: set the hide on solo feature, default=0=disabled";
	rewatch_loc["help"][8] = " /rewatch autoGroup [0 or 1]: set the hide on solo feature, default=1=enabled";
	rewatch_loc["help"][9] = " /rewatch check: checks the druid buffs on your party/raid";

	-- spell names
	rewatch_loc["rejuvenation"] = "R\195\169cup\195\169ration";
	rewatch_loc["regrowth"] = "R\195\169tablissement";
	rewatch_loc["lifebloom"] = "Fleur de vie";
	rewatch_loc["innervate"] = "Innervation";
	rewatch_loc["barkskin"] = "Ecorce";
	rewatch_loc["markofthewild"] = "Marque du fauve";
	rewatch_loc["giftofthewild"] = "Don du fauve";
	rewatch_loc["naturesswiftness"] = "Rapidit\195\169 de la nature";
	rewatch_loc["tranquility"] = "Tranquilit\195\169";
	rewatch_loc["swiftmend"] = "Prompte gu\195\169rison";
	rewatch_loc["abolishpoison"] = "Abolir le poison";
	rewatch_loc["removecurse"] = "D\195\169livrance de la mal\195\169diction";
	rewatch_loc["thorns"] = "Epines";
	
end;