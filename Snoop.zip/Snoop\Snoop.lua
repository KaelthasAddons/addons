-- FloatingChatFrame.xml predefines seven chat windows.  Use those for now.
local Snoop_MaxFrames = 7;

local Snoop_Help = {
    "Snoop usage:",
    "/snoop N  -- Sets output to go to chat window N, where N is from 1 to "..Snoop_MaxFrames,
    "/snoop print -- Prints each chat window's number in that window for reference.",
    "/snoop on|off -- Begins|ends copying addon channel text to the selected chat window."
};
--[[
Farmbuyer, Kilrogg realm
farmbuyer@gmail.com
]]

Snoop_ChatFrame = 2;

Snoop_PrintHelp = function ()
    for _,v in pairs(Snoop_Help) do
        DEFAULT_CHAT_FRAME:AddMessage (v,1,1,1);
    end;
end;


local green = "|cFF00FF00";
local open = green.."<";
local close = green..">";
local prefix = "|cFFFF0088";
local ppl = "|cFFFEC500";

Snoop_OnEvent = function (event)
    if event == "CHAT_MSG_ADDON" then
        -- arg1:  prefix
        -- arg2:  message
        -- arg3:  distribution
        -- arg4:  sender
        local f = getglobal ("ChatFrame"..Snoop_ChatFrame);
        f:AddMessage (open..prefix..arg1..close..
                      ppl.."("..arg4.."->"..arg3.."):  |r" .. arg2,
                      0.41, 0.8, 0.94);
    end;
end;


Snoop_OnLoad = function ()
    SlashCmdList["SNOOPCOMMAND"] = function (txt)
        if txt == "print" then
            for i = 1, 7 do
                local f = getglobal ("ChatFrame"..i);
                if f then
                    f:AddMessage ("This is chat window "..i..".",1,1,1);
                end;
            end;
        elseif txt == "on" then
            DEFAULT_CHAT_FRAME:AddMessage ("Snoop activated.");
            SnoopFrame:RegisterEvent("CHAT_MSG_ADDON");
        elseif txt == "off" then
            DEFAULT_CHAT_FRAME:AddMessage ("Snoop deactivated.");
            SnoopFrame:UnregisterEvent("CHAT_MSG_ADDON");
        else
            -- "/snoop N"
            local n = tonumber (txt or "");
            if (not n) or (n < 1) or (n > Snoop_MaxFrames) then
                -- if they type something like "/snoop 5.5" then screw 'em
                Snoop_PrintHelp();
            else
                Snoop_ChatFrame = n;
                DEFAULT_CHAT_FRAME:AddMessage ("Snoop will now print to chat window "..n..".");
            end;
        end;
    end;
    SLASH_SNOOPCOMMAND1 = "/snoop";
    DEFAULT_CHAT_FRAME:AddMessage ("Snoop is set to print to chat window "..Snoop_ChatFrame..".");
end;



