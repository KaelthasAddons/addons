#/bin/bash

cd ..
rm -rf LittleWigs_Auchindoun
rm -rf LittleWigs_Coilfang
rm -rf LittleWigs_HellfireCitadel
rm -rf LittleWigs_TempestKeep
rm -rf LittleWigs_CoT
rm -rf LittleWigs_MagistersTerrace

cd LittleWigs

mv Auchindoun ../LittleWigs_Auchindoun
mv Coilfang ../LittleWigs_Coilfang
mv HellfireCitadel ../LittleWigs_HellfireCitadel
mv TempestKeep ../LittleWigs_TempestKeep
mv CoT ../LittleWigs_CoT
mv MagistersTerrace ../LittleWigs_MagistersTerrace