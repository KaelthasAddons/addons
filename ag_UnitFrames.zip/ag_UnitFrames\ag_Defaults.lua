aUF_DEFAULT_OPTIONS = {
	RaidHideParty = true,

	Locked = false,

	RaidColorName = false,

	HighlightSelected = true,

	ShowPvPIcon = false,
	ShowGroupIcons = true,

	SmoothHealthBars = true,

	RaidGrouping = "subgroup",
	PartyGrouping = "withplayer",
	PetGrouping = "withplayer",

	BorderStyle = "Hidden",
	BarStyle = "Otravi",

	BlizzCastbar = false,

	CurrentRaidSet = "1",

	CastbarColor = {
		r = 1.0,
		g = 0.7,
		b = 0.0,
	},

	HealthColor = {
		r = 0.41,
		g = 0.95,
		b = 0.2,
	},

	ManaColor = {
		[0] = { b = 0.84, g = 0.52, r = 0.28}, -- Mana
		[1] = { r = 226/255, g = 45/255, b = 75/255}, -- Rage
		[2] = { r = 255/255, g = 210/255, b = 0}, -- Focus
		[3] = { r = 255/255, g = 220/255, b = 25/255}, -- Energy
		[4] = { r = 0.00, g = 1.00, b = 1.00} -- Happiness
	},

	PartyFrameColors = {
		r = 0,
		g = 0,
		b = 0,
		a = 0.5
	},
	TargetFrameColors = {
		r = 0,
		g = 0,
		b = 0,
		a = 0.5
	},
	FrameBorderColors = {
		r = TOOLTIP_DEFAULT_COLOR.r,
		g = TOOLTIP_DEFAULT_COLOR.g,
		b = TOOLTIP_DEFAULT_COLOR.b,
		c = 0.7
	},
	BlizFramesVisibility = {
		HidePlayerFrame = true,
		HidePartyFrame = true,
		HideTargetFrame = true
	},
	
	units = {
		["**"] = {
			HealthTextFormat = "[curhp]/[maxhp]",
			HealthTextWidth = 0,
			ManaTextFormat = "[curmana]/[maxmana]",
			ManaTextWidth = 0,
			HealthTextStyle = "Absolute",
			ManaTextStyle = "Absolute",
			NameLabelStyle = "Default",
			ClassTextStyle = "Default",
			NameLabelFormat = "",
			ClassTextFormat = "",

			FrameStyle = "ABF",
			AuraStyle = "TwoLines",
			AuraPos = "Below",
			AuraFilter = 1,
			AuraDebuffC = true,
			ShowCombat = false,
			ShowXP = true,
			LongStatusbars = false,
			ClassColorBars = false,
			Scale = 1,
			RaidColorName = false,
			ShowRaidTargetIcon = true,
			ShowInCombatIcon = true,
			Width = 165,
			Portrait = false,

			AuraRows = 2,
			AuraColumns = 10,
			AuraPreferBuff = true,
			AuraCooldown = true,
		},

		player = {
			CastBar = true,
			ClassColorBars = true,
		},

		party = {
			AlwaysShow = false,
			AuraRows = 1,
			AuraColumns = 12,
			ClassColorBars = true,
		},

		partypet = {
			AuraStyle = "OneLine",
			HideMana = true,
		},

		pet = {
			AuraStyle = "OneLine",
		},

		raid = {
			AuraStyle = "OneLine",
			AuraPos = "Inside",
			HideMana = true,
			HideFrame = true,
			Scale = 0.85,
			Width = 125,
			ClassColorBars = true,
		},

		raidpet = {
			AuraStyle = "OneLine",
			AuraPos = "Inside",
			HideMana = true,
			HideFrame = true,
			Scale = 0.85,
			Width = 125,
		},

		target = {
			AuraFilter = 0,
			AuraDebuffC = false,
			AuraRows = 3,
			CastBar = true,
			TargetShowHostile = true,
		},

		focustarget = {
			AuraFilter = 0,
			AuraDebuffC = false,
			HideFrame = true,
			AuraRows = 3,
		},

		focus = {
			AuraFilter = 0,
			AuraDebuffC = false,
			AuraRows = 3,
		},

		targettarget = {
			AuraFilter = 0,
			HideMana = true,
			Scale = 0.80,
			RaidColorName = true,
			Width = 145,
			AuraRows = 3,
		},

		targettargettarget = {
			AuraFilter = 0,
			HideMana = true,
			Scale = 0.80,
			RaidColorName = true,
			Width = 145,
			HideFrame = true,
			AuraRows = 1,
		},
	},

	partygroup = {
			Grow = "TOP",
			ShowAnchor = false,
			Exists = true,
			groupFilter = "",
			Padding = 21,
			AnchorOffset = 2,
	},
	partypetgroup = {
			Grow = "TOP",
			ShowAnchor = false,
			Exists = true,
			groupFilter = "",
			Padding = 48,
			AnchorOffset = 2,
			suffix = "pet",
	},

	subgroups = {
		["**"] = {
			Grow = "TOP",
			ShowAnchor = true,
			Padding = 2,
			AnchorOffset = 2,
			RaidSets = {"1","2","3","4","5","6","7","8","9","10"},
			groupFilter = "",
		},
		group1 = {
			groupFilter = "1",
			Exists = true,
		},
		group2 = {
			groupFilter = "2",
			Exists = true,
		},
		group3 = {
			groupFilter = "3",
			Exists = true,
		},
		group4 = {
			groupFilter = "4",
			Exists = true,
		},
		group5 = {
			groupFilter = "5",
			Exists = true,
		},
		group6 = {
			groupFilter = "6",
			Exists = true,
		},
		group7 = {
			groupFilter = "7",
			Exists = true,
		},
		group8 = {
			groupFilter = "8",
			Exists = true,
		},
	},

	Positions = {
		aUFplayer = "10 -13",
		aUFpet = "10 -61",
		aUFtarget = "250 -13",
		aUFtargettarget = "400 -13",
		aUFtargettargettarget = "400 -30",
		party = "10 -109",
		partypet = "185 -109",
	}
}

