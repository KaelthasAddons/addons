﻿-- Author      : Bandayd of Uther
-- Create Date : 5/22/2008 6:24:22 PM

	--To Do:
	-----------------------------------------
	--Add new sounds like "bring out yer dead"
	
					--Fix party buff nag so it doesn't bug you with warlocks pets
					--also if someone DC's make it not nag you for the DC'd person
	
					--Make options for turning on/off...
						--Rez whispers (T/F)
						--Funny Emotes for
							--Mounts   -Say
							--Rezzing  -Say -Party -Whisper
							--M/C      -Say
							--Shackle  -Say
						--Raid/Party Rez Annoucements
	
	--check to make sure that fear ward doesn't make a noise when it fades
	--from non-group members
	


	--Current strategy
	------------------
					--Nag:Inner Fire, Fort, Shadow Protection
	
					--Inner Fire:
					--just monitor when it fades
					--play sound when it fades

					--Fortitude, Shadow Protection
					--just monitor when it fades from someone and check to see if they're in
					--your group.
					--if they are in your group then play the noise
					
	--Disease, Magic
	--just monitor when people get debuffs
	--if they are then see if it's magic or disease and if so then play the noise
	
					--ShackleBreak
					--monitor when you cast it, get a GUID of that mob
					--then if any shackle breaks, check to see if it matches your mob's GUID
					--if it matches your GUID then play your ShackleBreak sound
					--otherwise play the OtherShackleBreak sound because it wasn't yours that broke

	--Next I want to:
	-----------------
					--Make it whisper the person you are rezzing
	
					--Make it say the things that serenity says when you shackle, rez, mc
						--just make it pick up on the beginning of the spell cast
						--the only other thing is I need to make it pick a random saying
						--and I need to figure out how to use arrays
	
	--Make a slider and a variable to save and remember how many candles you want
					--Make it restock candles when you open a vendor that sells them
						--iterate through all the stuff he sells when the window opens
						--look at how many we have and buy however many we need
						--confirm before doing it

-- for version 3.0 I should make it
-- ================================
-- show a timer for other people's shackles
--   just start counting from when they cast it

	FearWardCooldown = 181;
	CurrentCountdown = 1.0;
	UpdateInterval = 1.0; -- How often the OnUpdate code will run (in seconds)
	
	
	--NagIntervalText = 5.0; -- How often to nag them about their buffs
				--60
				
				
	FWTimeSinceLastUpdate = 0.0;
	NagTimeSinceLastUpdate = 0.0;
	FWTimerEnabled = false;

	--FWReadyText = true;
	--FWFadedText = true;
	--FWCastText = true;
	--InnerFireText = true;
	--FortitudeText = true;
	--ShadowProtectionText = true;
	--DiseaseText = true;
	--MagicText = true;
	--ShackleBreakText = true;
	--OtherShackleBreakText = true;
	--InnerFireNag = true;
	--FortitudeNag = true;
	--ShadowProtectionNag = true;
	--
	--MountSayText = true;
	--RezSayText = true;
	--RezWhisperText = true;
	--RezPartyText = true;
	--MCSayText = true;
	--ShackleSayText = true;

	elapsed = 0.0;
	SoundPath = "Interface\\AddOns\\PriestFriend\\Sounds\\";
	SettingWhat = "FWReady";
	myShackleID = 0;
	LastShackleID = 0;

    ShackleMessage = {  --1 to 14
    "THE POWER OF "..string.upper(UnitName("player")).." COMPELS YOU!!",
	"Shackling <target>!  Stay away from it!",
	"I hope you brought the gag, <target>; I brought the handcuffs!",
	"Believe it or not, <target>, I'm into bondage.",
	"Shackling <target>! Drop what you're doing and leave it alone! ",
	"Shackling <target>. Everytime you break it, I'll kill a kitten.",
	"Shackling <target>!  You break it, you tank it.",
	"<target> is my undead. There are many others like it but this one is mine.",
	"Shackling <target> because the dead can't say no.",
	"Go to your cage, <target>!",
	"All I ever hear from you is 'mind this' and 'mind that', <target>.  No more!",
	"You fought the law and the law won, <target>.",
	"<target>, go to jail.  Go directly to jail.  Do not pass go.  Do not collect 200g",
	"You were never meant to move, <target>. Be still once more!",
    };
    MindControlMessage = {  --1 to 3
        "I'm feeling alone ! <target>, be mine !!",
        "Come here <target>. Now!",
        "The problem with doing this <target>, is your friends no longer like you!",
    };
    --ResurectionWhisper = {  --1 to 8
		--"Hey, you're legs look \"dead tired\" why don't you just sit there and I'll rez ya :-P",
		--"Hey seeing as I failed to heal you I might as well throw you a rez :-P",
		--"So, I know you're probably havin' fun lying there dead, wanna join the living??? :-P",
		--"So, how much gold will ya pay for a rez right now :-P",
		--"Ok here's the deal, I'm gonna rez ya but try and not die this time ok? :-P",
		--"So, how's you're durability doin these days? Goin down is it? hmmmmm, that's wierd :-P",
		--"<Insert smart-alec resurection message here>",
		--"I'm rezzing you now since you're my favorite... just don't tell tell anyone... :-P",
    --};
    ResurectionNoTarget = {  --1 to 27
	"Okay, nap time is over! Back to work!",
	"Cool, I received 42 silver, 32 copper from this corpse",
	"Okay, Stop being dead.",
	"Don't rush me. You rush a miracle worker, you get rotten miracles.",
	"Administering Resurrecting. Side effects may include: nausea, explosive bowels, a craving for brains, and erectile dysfunction. Resurrection is not for everyone. Please consult healer before dying.",
	"Dammit I'm a doctor! Not a priest! .... Wait a second.... Nevermind. Rezzing",
	"Dying makes me sad.",
	"Stop worshipping the ground I walk on and get up." ,
	"Walk it off.",
	"By accepting this resurrection you hereby accept that you must forfeit your immortal soul to <player>. Please click 'Accept' to continue.",
	"This better not be another attempt to get me to give you mouth-to-mouth.",
	"Arise, and fear death no more...or at least until the next pull.",
	"Stop slacking, You can sleep when you're dea... Oh... Um, rezzing",
	"Quit hitting on the Spirit Healer and come kill something!",
	"I *warned* you, but did you listen to me? Oh, no, you *knew*, didn't you? Oh, it's just a harmless little *bunny*, isn't it?",
	"Please! This is supposed to be a happy occasion. Let's not bicker and argue over who killed who.",
	"There are worse things then death. Have you ever grouped with... oh, wait. We aren't supposed to mention that in front of you.",
	"Did you run into some snakes on a plane or something? 'cause you're dead.",
	"Wee-ooo! Wee-ooo! Wee-ooo! Wee-ooo! Wee-ooo! Wee-ooo... that's the best ambulance impression I can do.",
	"Tsk tsk, See, I told you to sacrifice that virgin to the Volcano God.",
	"Hey, do you know what you call a physician that was last in his class?  Doctor.",
	"You don't deserve a cute rez macro, You deserve to die. But you already did, so, um... yeah.",
	"You have been weighed, you have been measured, and you have been found wanting.",
	"Gah, dead again? You probably want a rez, don't you? What do you think I am, a prie... oh. Fair enough.",
	"Sorry, I know I'm a priest ... but come ON! Did you see how many guys there were!?",
	"Hey! Don't go towards the light! Well, unless it says 'Accept' ... but even then, it might be a trick!",
	"Sorry, I couldn't heal you. I was too busy being the tank.",
    };
    Resurection = {  --1 to 55
    "Granddaddy always said laughter was the best medicine. I guess it wasn't strong enough to keep <target> alive.",
	"Okay, <target>, nap time is over! Back to work!",
	"Rezzing <target>. Can I get an 'amen', please!",
	"<target>, your subscription to Life(tm) has expired. Do you wish to renew?",
	"YAY! I always wanted my very own <target>-zombie!",
	"It just so happens that <target> is only MOSTLY dead. There's a big difference between mostly dead and all dead. Mostly dead is slightly alive.",
	"<target> has failed at life, I'm giving him a second chance. That's right, not the Spirit Healer, ME!!",
	"Cool, I received 42 silver, 32 copper from <target>'s corpse",
	"GAME OVER, <target>. To continue press up, up, down, down, left, right, left, right, B, A, B, A, Select + Start",
	"<target>, it's more mana efficient just to resurrect you.  Haha, I'm just kidding!",
	"Well, <target>, if you had higher reputation with the faction <player>, you might have gotten a heal.  How do you raise it?  10g donation = 15 rep.",
	"Okay, <target>.  Stop being dead.",
	"If you are reading this message, <target> is already dead.",
	"Don't rush me <target>. You rush a miracle worker, you get rotten miracles.",
	"Death comes for you <target>! with large, pointy teeth!",
	"Resurrecting <target>. Side effects may include: nausea, explosive bowels, a craving for brains, and erectile dysfunction. Resurrection is not for everyone. Please consult healer before dying.",
	"Dammit <target>, I'm a doctor! Not a priest! .... Wait a second.... Nevermind. Rezzing <target>",
	"Dying makes me sad, <target>.",
	"<target> stop worshipping the ground I walk on and get up." ,
	"Hey <target>, will you check to see if Elvis is really dead?...and will he fill your spot in the party?",
	"Giving <target> another chance to mess it up. ",
	"Dammit, <target>, did you get my PERMISSION before dying?!",
	"Death defying feats are clearly not your strong point, <target>",
	"Walk it off, <target>.",
	"<target>, by accepting this resurrection you hereby accept that you must forfeit your immortal soul to <player>. Please click 'Accept' to continue.",
	"<target>, this better not be another attempt to get me to give you mouth-to-mouth.",
	"Arise <target>, and fear death no more...or at least until the next pull.",
	"Stop slacking, <target>. You can sleep when you're dea... Oh... Um, rezzing <target>",
	"We can rebuild <target>. We can make <himher> stronger, faster, but we can't make <himher> any smarter.",
	"<target> has fallen and can't get up!",
	"Bring out your dead! *throws <target> on the cart*",
	"Hey <target>, say hello to Feathers for me, will ya?",
	"<target>, quit hitting on the Spirit Healer and come kill something!",
	"<target> I *warned* you, but did you listen to me? Oh, no, you *knew*, didn't you? Oh, it's just a harmless little *bunny*, isn't it?",
	"<target>, please! This is supposed to be a happy occasion. Let's not bicker and argue over who killed who.",
	"Today's category on Final Jeopardy: Spells that end in 'esurrection'. <target>, ready?",
	"There are worse things then death, <target>. Have you ever grouped with... oh, wait. We aren't supposed to mention that in front of you.",
	"Did you run into some snakes on a plane or something, <target>? 'cause you're dead.",
	"Wee-ooo! Wee-ooo! Wee-ooo! Wee-ooo! Wee-ooo! Wee-ooo... that's the best ambulance impression I can do, <target>.",
	"Tsk tsk, <target>. See, I told you to sacrifice that virgin to the Volcano God.",
	"<target> gets a Mulligan.",
	"Hey <target>, do you know what you call a physician that was last in his class?  Doctor.",
	"Eww!  What's that smell!  It smells like something died in here!  Hey, where is <target>?... Oh.",
	"Sorry to hear that you're dead, <target>, but hey, the good news is that I just saved a bunch of money on my car insurance by switching to Geico.",  
	"You don't deserve a cute rez macro, <target>. You deserve to die. But you already did, so, um... yeah.",
	"<target>, you have been weighed, you have been measured, and you have been found wanting.",
	"Well <target>, you tried your best...and apparently failed miserably. Good job.", 
	"Did it hurt, <target>, when you fell from Heaven? Oh, wait...You're dead...hmmm...I don't know where I was going with that. Nevermind.", 
	"Gah, <target>, dead again? You probably want a rez, don't you? What do you think I am, a prie... oh. Fair enough.",
	"<target> have you heard of Nethaera?  Yeah, she's really cool.  Why do I bring it up?  No reason.",
	"Can somebody get <target> a Phoenix Down over here? *stumbles* Wow, out of body experience...",
	"Funny how everyone else can die and come back, but a Phoenix Down won't take care of <target>.",
	"Sorry <target>, I know I'm a priest ... but come ON! Did you see how many guys there were!?",
	"Hey <target>! Don't go towards the light! Well, unless it says 'Accept' ... but even then, it might be a trick!",
	"Sorry <target>, I couldn't heal you. I was too busy being the tank.",
    };
    MountMessage = {  --1 to 16
    "If it wasn't for my <mount>, I wouldn't have spent that year in college.",
	"The directions said to just add water and... WHOA a <mount>!",
	"If it wasn't for my <mount>, I'd be walking.",
	"I'd love to hang around, but my <mount> needs exercise.",
	"Alright <mount>, I'm ready to ride!",
	"Fasten your seat belts, it's going to be a bouncy ride.",
	"Hi-ho <mount>...Away!!!",
	"You should see my other mount... but it's in the shop getting fixed.",
	"Shotgun!",
	"Hm, something's growing under my butt!",
	"Ah, now for some good old fashioned <mount> riding.",
	"Does this look like a <mount> to you? Oh, I guess it really is. Nevermind.",
	"Ok, mounting my <mount> now. Wait... that didn't come out right.",
	"*cough cough* Man, I wish my <mount> didn't smoke.",
	"Pardon the smoke, folks! My <mount> adores flashy appearances...",
	"On the road again ... *whistles* ... let's go, <mount>!",
	};
	MountList = {   --1 to 32
	"saber",--1
	"Tiger",--2
	"Elekk",--3
	"Steed",--4
	"Mechanostrider",--5
	"Ram",--6
	"Raptor",--7
	"orse",--8
	"Wolf",--9
	"Hawkstrider",--10
	"Kodo",--11
	"Swift",--12
	"Pinto",--13
	"Brown Horse",--14
	"Black Stallion",--15
	"Chestnut Mare",--16
	"harger",--17
	"Talbuk",--18
	"Windrider",--19
	"Gryphon",--20
	"Nether Ray",--21
	"Drake",--22
	"Hippogryph",--23
	"Flying Machine",--24
	"Phoenix",--25
	"Nether-Rocket",--26
	"Howler",--27
	"Battlestrider",--28
	"Raven Lord",--29
	"Battle Tank",--30
	"Riding Turtle",--31
	"War Bear",--32
	};

	
function Timer_OnLoad()
	--this:RegisterEvent("CHAT_MSG_SAY");
	--this:RegisterEvent("CHAT_MSG_WHISPER");
	--HideConfig();
	this:RegisterEvent("COMBAT_LOG_EVENT_UNFILTERED");
	this:RegisterEvent("VARIABLES_LOADED");
	this:RegisterEvent("UNIT_SPELLCAST_SENT");
	this:RegisterEvent("MERCHANT_SHOW");
	this:RegisterEvent("MERCHANT_CLOSED");
	this:RegisterEvent("PLAYER_LEAVE_COMBAT");
	--this:RegisterEvent("PLAYER_TARGET_CHANGED");
	--this:RegisterEvent('UNIT_SPELLCAST_SUCCEEDED');

	--this:RegisterEvent('PLAYER_ENTERING_WORLD');
	---- new zone
	--this:RegisterEvent('ZONE_CHANGED_NEW_AREA');
	--
	---- monitor some status infos
	--this:RegisterEvent('UNIT_HEALTH');
	--this:RegisterEvent('UNIT_MANA');
	--this:RegisterEvent('UNIT_FOCUS');
	--r
	---- some basic info has changed
	----this:RegisterEvent('PLAYER_PET_CHANGED');
	--this:RegisterEvent('SPELLS_CHANGED');
	--this:RegisterEvent('BAG_UPDATE');
	--this:RegisterEvent('UNIT_INVENTORY_CHANGED');
	--
	---- capture spellcasts (messages, recasts)
	--this:RegisterEvent('UNIT_SPELLCAST_FAILED'); 
	--this:RegisterEvent('UNIT_SPELLCAST_INTERRUPTED'); 
	--this:RegisterEvent('UNIT_SPELLCAST_STOP');
	--this:RegisterEvent('UNIT_SPELLCAST_SUCCEEDED');     
	--
	SLASH_CMD1 = "/pf";
	SLASH_CMD2 = "/priestfriend";
	SLASH_CMD3 = "/fw";
	SLASH_CMD4 = "/fearwatch";
	SlashCmdList["CMD"] = CMD_Command;
end

function CMD_Command(cmd)
	if (cmd == "hide") then
	    HideConfig();
	elseif (cmd == "show") then
		ShowConfig();
	else
		DEFAULT_CHAT_FRAME:AddMessage("|cfff0ef76Usage:|r /pf {show | hide}", 1.0, 1.0, 1.0, nil, false);
		DEFAULT_CHAT_FRAME:AddMessage(" - |cfff0ef76show:|r Shows the configuration page", 1.0, 1.0, 1.0, nil, false);
		DEFAULT_CHAT_FRAME:AddMessage(" - |cfff0ef76hide:|r Hides the configuration page", 1.0, 1.0, 1.0, nil, false);
	end
end

--function MyUnhandledEvent(timestamp, event, srcGUID, srcName, srcFlags, destGUID, destName, destFlags, spellId, spellName, spellSchool, auraType)
	----DEFAULT_CHAT_FRAME:AddMessage(.." : "..srcName.." just cast "..spellName.." on "..destName, 0.0, 1.0, 1.0, nil, false);
	--if (timestamp ~= nil) then
		--DEFAULT_CHAT_FRAME:AddMessage("timestamp"..timestamp, 1.0, 1.0, 0.0, nil, false);
	--end
	--if (event ~= nil) then
		--DEFAULT_CHAT_FRAME:AddMessage("event"..event, 0.0, 1.0, 1.0, nil, false);
	--end
	--if (srcGUID ~= nil) then
		--DEFAULT_CHAT_FRAME:AddMessage("srcGUID"..srcGUID, 0.0, 1.0, 1.0, nil, false);
	--end
	--if (srcName ~= nil) then
		--DEFAULT_CHAT_FRAME:AddMessage("srcName"..srcName, 0.0, 1.0, 1.0, nil, false);
	--end
	--if (srcFlags ~= nil) then
		--DEFAULT_CHAT_FRAME:AddMessage("srcFlags"..srcFlags, 0.0, 1.0, 1.0, nil, false);
	--end
	--if (destGUID ~= nil) then
		--DEFAULT_CHAT_FRAME:AddMessage("destGUID"..destGUID, 0.0, 1.0, 1.0, nil, false);
	--end
	--if (destName ~= nil) then
		--DEFAULT_CHAT_FRAME:AddMessage("destName"..destName, 0.0, 1.0, 1.0, nil, false);
	--end
	--if (destFlags ~= nil) then
		--DEFAULT_CHAT_FRAME:AddMessage("destFlags"..destFlags, 0.0, 1.0, 1.0, nil, false);
	--end
	--if (spellId ~= nil) then
		--DEFAULT_CHAT_FRAME:AddMessage("spellId"..spellId, 0.0, 1.0, 1.0, nil, false);
	--end
	--if (spellName ~= nil) then
		--DEFAULT_CHAT_FRAME:AddMessage("spellName"..spellName, 0.0, 1.0, 1.0, nil, false);
	--end
	--if (spellSchool ~= nil) then
		--DEFAULT_CHAT_FRAME:AddMessage("spellSchool"..spellSchool, 0.0, 1.0, 1.0, nil, false);
	--end
	--if (auraType ~= nil) then
		--DEFAULT_CHAT_FRAME:AddMessage("auraType"..auraType, 0.0, 1.0, 1.0, nil, false);
	--end
--end

function Timer_OnEvent()
	if (event == "VARIABLES_LOADED") then
		MyVariablesLoadedEvent()
	elseif (event == "COMBAT_LOG_EVENT_UNFILTERED") then
		if (arg2 == "SPELL_AURA_APPLIED") then
			MyAuraAppliedEvent(arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12);
		elseif (arg2 == "SPELL_AURA_REMOVED") then
			MyAuraRemovedEvent(arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12);
		elseif (arg2 == "SPELL_CAST_SUCCESS") then
			MySpellCastSuccessEvent(arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11);
		elseif (arg2 == "SPELL_CAST_START") then
			MySpellCastStartEvent(arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11);
		elseif (arg2 == "SPELL_CAST_FAILED") then
			MySpellCastFailedEvent(arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11);
		else
			----THIS IS FOR TROUBLESHOOTING PURPOSES
			--MyUnhandledEvent(arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12);
			----THIS IS FOR TROUBLESHOOTING PURPOSES
		end
	elseif (event == "UNIT_SPELLCAST_SENT") then
		MyMountEvent(arg1, arg2, arg3, arg4);
	elseif (event == "MERCHANT_SHOW") then
		MyVendorOpenEvent();
	elseif (event == "MERCHANT_CLOSED") then
		MyVendorCloseEvent();
	elseif (event == "PLAYER_LEAVE_COMBAT") then
		MyLeftCombatEvent();
	--else
		--THIS IS FOR TROUBLESHOOTING PURPOSES
		--MyUnhandledEvent(arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12);
		--THIS IS FOR TROUBLESHOOTING PURPOSES
	end
end

function MyLeftCombatEvent()
	--check to see if we have dead people
	if (GetNumRaidMembers() > 0) then
		--go through and check for dead people to rez
		for i=1,40 do
			if (UnitIsDeadOrGhost("raid"..i)) then
				DEFAULT_CHAT_FRAME:AddMessage("Just FYI "..UnitName("raid"..i).." is dead", 1.0, 1.0, 1.0, nil, false);
				i=40;
			end
		end
	elseif (GetNumPartyMembers() > 0) then
		--go through and check for dead people to rez
		for i=1,4 do
			if (UnitIsDeadOrGhost("party"..i)) then
				DEFAULT_CHAT_FRAME:AddMessage("Just FYI "..UnitName("party"..i).." is dead", 1.0, 1.0, 1.0, nil, false);
				i=40;
			end
		end
	end
end

function MyVendorOpenEvent()
	local MerchItems = GetMerchantNumItems()
	local Purchase = false;
	local color;
 	local display = false;
	for item= 1, MerchItems do
		local itemString = GetMerchantItemInfo(item)
		if (itemString == "Sacred Candle") then
			if (SacredCandleText > 0) then
				--check bags to see if we have enough
				local numCandles = 0;
				--now see if we have something in our bag which contains this spell's name
				--if so then that's our mount :-)
				--For each bag
				local tempItemLink
				for container=0,4 do
					-- For each slot
					for slot=1,GetContainerNumSlots(container) do
						tempItemLink = GetContainerItemLink(container, slot);
						if (tempItemLink) then
							local itemName, itemLink, itemRarity, itemLevel, itemMinLevel, itemType, itemSubType, itemStackCount, itemEquipLoc, itemTexture = GetItemInfo(tempItemLink);
							local texture, itemCount, locked, quality, readable = GetContainerItemInfo(container, slot);
							if (itemName) then
								if (itemName == "Sacred Candle") then
									numCandles = numCandles + itemCount;
								end
							end
						end
					end
				end
				DEFAULT_CHAT_FRAME:AddMessage("|cfff0ef76"..numCandles.." Sacred Candles in inventory|r", 1.0, 1.0, 1.0, nil, false);
				if (numCandles < SacredCandleText) then
					StaticPopupDialogs["RESTOCK_SACRED_CONFIRMATION"] = {
						text = "Restock Sacred Candles?",
						button1 = "Yes",
						button2 = "No",
						OnAccept = function()
							local TempNumNeeded
							TempNumNeeded = SacredCandleText-numCandles;
							while (numCandles < SacredCandleText) do
								if ((SacredCandleText-numCandles) > 20) then
									BuyMerchantItem(item, 20);
									numCandles = numCandles + 20;
								else
									BuyMerchantItem(item, SacredCandleText-numCandles);
									numCandles = numCandles + (SacredCandleText-numCandles);
								end
							end
							DEFAULT_CHAT_FRAME:AddMessage("|cfff0ef76"..(TempNumNeeded).." Sacred Candles purchased|r", 1.0, 1.0, 1.0, nil, false);
						end,
						OnShow = function()
							DEFAULT_CHAT_FRAME:AddMessage("|cfff0ef76"..(SacredCandleText-numCandles).." Sacred Candles needed|r", 1.0, 1.0, 1.0, nil, false);
						end,
						timeout = 0,
						whileDead = 1,
						hideOnEscape = 1
					};
					StaticPopup_Show("RESTOCK_SACRED_CONFIRMATION");
				end
			end
		elseif (itemString == "Holy Candle") then
			if (HolyCandleText > 0) then
				--check bags to see if we have enough
				local numCandles = 0;
				--now see if we have something in our bag which contains this spell's name
				--if so then that's our mount :-)
				--For each bag
				local tempItemLink
				for container=0,4 do
					-- For each slot
					for slot=1,GetContainerNumSlots(container) do
						tempItemLink = GetContainerItemLink(container, slot);
						if (tempItemLink) then
							local itemName, itemLink, itemRarity, itemLevel, itemMinLevel, itemType, itemSubType, itemStackCount, itemEquipLoc, itemTexture = GetItemInfo(tempItemLink);
							local texture, itemCount, locked, quality, readable = GetContainerItemInfo(container, slot);
							if (itemName) then
								if (itemName == "Holy Candle") then
									numCandles = numCandles + itemCount;
								end
							end
						end
					end
				end
				DEFAULT_CHAT_FRAME:AddMessage("|cfff0ef76"..numCandles.." Holy Candles in inventory|r", 1.0, 1.0, 1.0, nil, false);
				if (numCandles < HolyCandleText) then
					StaticPopupDialogs["RESTOCK_HOLY_CONFIRMATION"] = {
						text = "Restock Holy Candles?",
						button1 = "Yes",
						button2 = "No",
						OnAccept = function()
							local TempNumNeeded
							TempNumNeeded = HolyCandleText-numCandles;
							while (numCandles < HolyCandleText) do
								if ((HolyCandleText-numCandles) > 20) then
									BuyMerchantItem(item, 20);
									numCandles = numCandles + 20;
								else
									BuyMerchantItem(item, HolyCandleText-numCandles);
									numCandles = numCandles + (HolyCandleText-numCandles);
								end
							end
							DEFAULT_CHAT_FRAME:AddMessage("|cfff0ef76"..(TempNumNeeded).." Holy Candles purchased|r", 1.0, 1.0, 1.0, nil, false);
						end,
						OnShow = function()
							DEFAULT_CHAT_FRAME:AddMessage("|cfff0ef76"..(HolyCandleText-numCandles).." Holy Candles needed|r", 1.0, 1.0, 1.0, nil, false);
						end,
						timeout = 0,
						whileDead = 1,
						hideOnEscape = 1
					};
					StaticPopup_Show("RESTOCK_HOLY_CONFIRMATION");				
				end
			end
		end
	end
end

function MyVendorCloseEvent()
	StaticPopup_Hide("RESTOCK_SACRED_CONFIRMATION");
	StaticPopup_Hide("RESTOCK_HOLY_CONFIRMATION");
end

function InsertTagValues(myMessage,myTarget,isFemale,myMount)
	--<target>
	--<mount>
	--string.find(spellName, itemName)
	while (string.find(myMessage,"<player>")) do
		myMessage = string.gsub(myMessage,"<player>",UnitName("player"));
	end
	while (string.find(myMessage,"<mount>")) do
		myMessage = string.gsub(myMessage,"<mount>",myMount);
	end
	while (string.find(myMessage,"<target>")) do
		myMessage = string.gsub(myMessage,"<target>",myTarget);
	end
	while (string.find(myMessage,"<himher>")) do
		if (isFemale) then
			myMessage = string.gsub(myMessage,"<himher>","her");
		else
			myMessage = string.gsub(myMessage,"<himher>","him");
		end
	end
	return myMessage;
end

function MyMountEvent(unitName, spellName, spellRank, spellTarget)
	if (unitName == "player") then
		--elseif ((spellName == "Resurrection") and (srcName == UnitName("player"))) then
		if (spellName == "Resurrection") then
			--display resurrection message
			math.randomseed(math.random(0,2147483647)+(GetTime()*1000));
			if (spellTarget == "Unknown") then --use the target if we can
				if (UnitName("target")) then
					if (UnitIsDeadOrGhost("target")) then
						--whipser the person you are rezzing
						if (RezSayText) then
							SendChatMessage(InsertTagValues(Resurection[math.random(1,55)], UnitName("target"), (UnitSex(UnitName("target")) == 3),""), "SAY");
						end
						if (RezWhisperText) then
							--SendChatMessage(InsertTagValues(ResurectionWhisper[math.random(1,8)], UnitName("target"), (UnitSex(UnitName("target")) == 3),""), "WHISPER", "Common", UnitName("target"));
							SendChatMessage("Just FYI I'm rezzing you now", "WHISPER", "Common", UnitName("target"));
						end
						if (RezPartyText) then
							if (GetNumRaidMembers() > 0) then  --iterate through your raid members
								SendChatMessage("Now casting Resurection on "..UnitName("target"), "RAID", "Common");
							elseif (GetNumPartyMembers() > 0) then  --iterate through your party members
								SendChatMessage("Now casting Resurection on "..UnitName("target"), "PARTY", "Common");
							end
						end
					end
				else
					SendChatMessage(InsertTagValues(ResurectionNoTarget[math.random(1,27)],"<unknown>","",""), "SAY");
				end
			else
				--whipser the person you are rezzing
				if (RezSayText) then
					SendChatMessage(InsertTagValues(Resurection[math.random(1,55)], spellTarget, (UnitSex(spellTarget) == 3),""), "SAY");
				end
				if (RezWhisperText) then
					--SendChatMessage(InsertTagValues(ResurectionWhisper[math.random(1,8)], spellTarget, (UnitSex(spellTarget) == 3),""), "WHISPER", "Common", spellTarget);
					SendChatMessage("Just FYI I'm rezzing you now", "WHISPER", "Common", spellTarget);
				end
				if (RezPartyText) then
					if (GetNumRaidMembers() > 0) then  --iterate through your raid members
						SendChatMessage("Now casting Resurection on "..spellTarget, "RAID", "Common");
					elseif (GetNumPartyMembers() > 0) then  --iterate through your raid members
						SendChatMessage("Now casting Resurection on "..spellTarget, "PARTY", "Common");
					end
				end
			end
		else
			--check to see if the spell has specific keywords for the mounts
			local isMount = false;
			for i=1,32 do
				if (string.find(spellName,MountList[i])) then
					isMount = true;
					i=14;
				end
			end
			if (isMount) then
				--now see if we have something in our bag which contains this spell's name
				--if so then that's our mount :-)
				--For each bag
				local tempItemLink
				for container=0, 4 do
					-- For each slot
					for slot=1, GetContainerNumSlots(container) do
						tempItemLink = GetContainerItemLink(container, slot);
						if (tempItemLink) then
							local itemName, itemLink, itemRarity, itemLevel, itemMinLevel, itemType, itemSubType, itemStackCount, itemEquipLoc, itemTexture = GetItemInfo(tempItemLink);
							if (itemName) then
								if ((string.find(spellName, itemName)) or (string.find(itemName, spellName))) then
									if (MountSayText) then
										math.randomseed(math.random(0,2147483647)+(GetTime()*1000));
										SendChatMessage(InsertTagValues(MountMessage[math.random(1,16)],"","",spellName), "SAY");
										slot=GetContainerNumSlots(container);
										container=5;
									end
								end
							end
						end
					end
				end
			end
		end
	end
end

function MySpellCastStartEvent(timestamp, event, srcGUID, srcName, srcFlags, destGUID, destName, destFlags, spellId, spellName, spellSchool)
	--this part makes it remember which shackle belongs to you
	--we store the previous target id just in case this cast fails
	if ((spellName == "Shackle Undead") and (srcName == UnitName("player"))) then
		LastShackleID = myShackleID;
		myShackleID = spellId; --destGUID;
		--display shackle message
		if 	(ShackleSayText) then
			math.randomseed(math.random(0,2147483647)+(GetTime()*1000));
			if (UnitName("target")) then
				SendChatMessage(InsertTagValues(ShackleMessage[math.random(1,14)],UnitName("target"),"",""), "SAY");
			else
				SendChatMessage(InsertTagValues(ShackleMessage[math.random(1,14)],"<unknown>","",""), "SAY");
			end
		end
	elseif ((spellName == "Mind Control") and (srcName == UnitName("player"))) then
		--display Mind Control message
		if (MCSayText) then
			math.randomseed(math.random(0,2147483647)+(GetTime()*1000));
			if (UnitName("target")) then
				SendChatMessage(InsertTagValues(MindControlMessage[math.random(1,3)],UnitName("target"),"",""), "SAY");
			else
				SendChatMessage(InsertTagValues(MindControlMessage[math.random(1,3)],"<unknown>","",""), "SAY");
			end
		end
	--elseif (srcName == UnitName("player")) then
		----display info for finding spell name
		--SendChatMessage(spellName.." on "..UnitName("target"), "SAY");
	end
end

function MySpellCastFailedEvent(timestamp, event, srcGUID, srcName, srcFlags, destGUID, destName, destFlags, spellId, spellName, failedType)
	--this part is for making it remember which shackle belongs to you 
	--but this part is for if our shackle fails which means the previous shackle
	--is what is ours
	if ((spellName == "Shackle Undead") and (srcName == UnitName("player"))) then
		--sets it to the previous one since this one failed
		myShackleID = LastShackleID;
	end
end

function isGroupMember(destName)
	local theirGroupID = "";
	for i=1,40 do
		if (destName == UnitName("raid"..i)) then
			theirGroupID = "raid"..i;
			i=40;
		elseif (destName == UnitName("raidpet"..i)) then
			theirGroupID = "raidpet"..i;
			i=40;
		end
	end
	if (theirGroupID == "") then --keep looking
		for i=1,4 do
			if (destName == UnitName("party"..i)) then
				theirGroupID = "party"..i;
				i=4;
			elseif (destName == UnitName("partypet"..i)) then
				theirGroupID = "partypet"..i;
				i=4;
			end
		end
	end
	return theirGroupID;
end

function MyAuraAppliedEvent(timestamp, event, srcGUID, srcName, srcFlags, destGUID, destName, destFlags, spellId, spellName, spellSchool, auraType)
	if (auraType == "DEBUFF") then
		if (destName == UnitName("player")) then
			--iterate through their debuffs
			for i=1,40 do
				local myDebuffName, rank, iconTexture, count, debuffType, duration, timeLeft = UnitDebuff("player",i,1);
				if (myDebuffName == spellName) then
					--now check to see if it's magic or disease
					if (debuffType == "Magic") then
						DEFAULT_CHAT_FRAME:AddMessage("you need to dispell the Magic "..spellName.." from yourself", 1.0, 0.0, 0.0, nil, false);
					elseif (debuffType == "Disease") then
						DEFAULT_CHAT_FRAME:AddMessage("you need to cure the Disease "..spellName.." from yourself", 0.0, 1.0, 0.0, nil, false);
					end
					i=40;
				end
			end
		else
			local myGroupID = isGroupMember(destName);
			if (myGroupID ~= "") then
				--we need to iterate through all their debuffs to find the one we want
				for i=1,40 do --iterate through their debuffs
					local myDebuffName, rank, iconTexture, count, debuffType, duration, timeLeft = UnitDebuff(myGroupID,i,1);
					if (myDebuffName == spellName) then
						--now check to see if it's magic or disease
						if (debuffType == "Magic") then
							DEFAULT_CHAT_FRAME:AddMessage("you need to dispell the Magic "..spellName.." from "..UnitName(myGroupID), 1.0, 0.0, 0.0, nil, false);
						elseif (debuffType == "Disease") then
							DEFAULT_CHAT_FRAME:AddMessage("you need to cure the Disease "..spellName.." from "..UnitName(myGroupID), 0.0, 1.0, 0.0, nil, false);
						end
						i=40;
					end
				end
			end
		end
	end
end

function MyAuraRemovedEvent(timestamp, event, srcGUID, srcName, srcFlags, destGUID, destName, destFlags, spellId, spellName, spellSchool, auraType)
	if (spellName == "Fear Ward") then
		if (srcName == UnitName("player")) then
			DEFAULT_CHAT_FRAME:AddMessage("Fear Ward faded from from yourself", 1.0, 0.0, 0.0, nil, false);
			if (FearWardFadedSound ~= "") then
				if (CurrentCountdown < FearWardCooldown-2) then
					PlaySoundFile(SoundPath..FearWardFadedSound);
				end
			end
		elseif (isGroupMember(destName) ~= "") then
			DEFAULT_CHAT_FRAME:AddMessage("Fear Ward faded from from "..destName, 1.0, 0.0, 0.0, nil, false);
			if (FearWardFadedSound ~= "") then
				if (CurrentCountdown < FearWardCooldown-2) then
					PlaySoundFile(SoundPath..FearWardFadedSound);
				end
			end
		end
	elseif ((spellName == "Inner Fire") and (destName == UnitName("player"))) then
		--DEFAULT_CHAT_FRAME:AddMessage("You lost Inner Fire", 1.0, 0.0, 1.0, nil, false);
		if (InnerFireSound ~= "") then
			PlaySoundFile(SoundPath..InnerFireSound);
		end
	elseif ((spellName == "Power Word: Fortitude") or (spellName == "Prayer of Fortitude")) then
		if (destName == UnitName("player")) then
			--DEFAULT_CHAT_FRAME:AddMessage("You lost "..spellName, 1.0, 0.0, 1.0, nil, false);
			if (FortitudeSound ~= "") then
				PlaySoundFile(SoundPath..FortitudeSound);
			end
		else
			if (isGroupMember(destName) ~= "") then
				--DEFAULT_CHAT_FRAME:AddMessage(destName.." just lost "..spellName, 1.0, 0.0, 1.0, nil, false);
				if (FortitudeSound ~= "") then
					PlaySoundFile(SoundPath..FortitudeSound);
				end
			end
		end
	elseif ((spellName == "Shadow Protection") or (spellName == "Prayer of Shadow Protection")) then
		if (destName == UnitName("player")) then
			--DEFAULT_CHAT_FRAME:AddMessage("You lost "..spellName, 1.0, 0.0, 1.0, nil, false);
			if (ShadowProtectionSound ~= "") then
				PlaySoundFile(SoundPath..ShadowProtectionSound);
			end
		else
			if (isGroupMember(destName) ~= "") then
				--DEFAULT_CHAT_FRAME:AddMessage(destName.." just lost "..spellName, 1.0, 0.0, 1.0, nil, false);
				if (ShadowProtectionSound ~= "") then
					PlaySoundFile(SoundPath..ShadowProtectionSound);
				end
			end
		end
	elseif (spellName == "Shackle Undead") then
		if (spellId == myShackleID) then
			--that means it was my shackle that broke
			DEFAULT_CHAT_FRAME:AddMessage("Your shackle just broke", 1.0, 0.0, 1.0, nil, false);
			if (ShackleBreakSound ~= "") then
				PlaySoundFile(SoundPath..ShackleBreakSound);
			end
		else
			--that means it was someone elses shackle that broke
			DEFAULT_CHAT_FRAME:AddMessage("Someone else's shackle just broke", 1.0, 0.0, 1.0, nil, false);
			if (OtherShackleBreakSound ~= "") then
				PlaySoundFile(SoundPath..OtherShackleBreakSound);
			end
		end
	end
end

function MySpellCastSuccessEvent(timestamp, event, srcGUID, srcName, srcFlags, destGUID, destName, destFlags, spellID, spellName, spellSchool)
	if (spellName == "Fear Ward") then
		if (srcName == UnitName("player")) then
			DEFAULT_CHAT_FRAME:AddMessage("You just cast Fear Ward on "..destName, 1.0, 0.0, 1.0, nil, false);
			FWTimerEnabled = true;
		elseif (isGroupMember(destName) ~= "") then
			DEFAULT_CHAT_FRAME:AddMessage(srcName.." just cast Fear Ward on "..destName, 1.0, 1.0, 1.0, nil, false);
			if (FearWardCastSound ~= "") then
				PlaySoundFile(SoundPath..FearWardCastSound);
			end
		end
	end
end

function MyVariablesLoadedEvent()
	--this just sets up the variables as well as
	--it sets up what is displayed on the form
	--now we need to check and see if the previous settings are empty, if so, then
	--we'll set them to the default value
	if (FearWardReadySoundDisplay == nil) then
		FearWardReadySoundDisplay = "Coocoo";
	end
	if (FearWardFadedSoundDisplay == nil) then
		FearWardFadedSoundDisplay = "Yell";
	end
	if (FearWardCastSoundDisplay == nil) then
		FearWardCastSoundDisplay = "Woohoo!!!";
	end
	if (InnerFireSoundDisplay == nil) then
		InnerFireSoundDisplay = "Coocoo";
	end
	if (FortitudeSoundDisplay == nil) then
		FortitudeSoundDisplay = "Coocoo";
	end
	if (ShadowProtectionSoundDisplay == nil) then
		ShadowProtectionSoundDisplay = "Coocoo";
	end
	if (DiseaseSoundDisplay == nil) then
		DiseaseSoundDisplay = "Coocoo";
	end
	if (MagicSoundDisplay == nil) then
		MagicSoundDisplay = "Coocoo";
	end
	if (ShackleBreakSoundDisplay == nil) then
		ShackleBreakSoundDisplay = "Bring Dead";
	end
	if (OtherShackleBreakSoundDisplay == nil) then
		OtherShackleBreakSoundDisplay = "Problem";
	end

	--now load them all into the text boxes :-)
	SettingWhat = "FWReady";
	SetSound(FearWardReadySoundDisplay);
	SettingWhat = "FWFaded";
	SetSound(FearWardFadedSoundDisplay);
	SettingWhat = "FWCast";
	SetSound(FearWardCastSoundDisplay);
	SettingWhat = "InnerFire";
	SetSound(InnerFireSoundDisplay);
	SettingWhat = "Fortitude";
	SetSound(FortitudeSoundDisplay);
	SettingWhat = "ShadowProtection";
	SetSound(ShadowProtectionSoundDisplay);
	SettingWhat = "Disease";
	SetSound(DiseaseSoundDisplay);
	SettingWhat = "Magic";
	SetSound(MagicSoundDisplay);
	SettingWhat = "ShackleBreak";
	SetSound(ShackleBreakSoundDisplay);
	SettingWhat = "OtherShackleBreak";
	SetSound(OtherShackleBreakSoundDisplay);

	--now set up all the checkboxes
	if (AlreadyStoredVars) then
		chkFWReady:SetChecked(FWReadyText);
		chkFWFaded:SetChecked(FWFadedText);
		chkFWCast:SetChecked(FWCastText);
		chkInnerFire:SetChecked(InnerFireText);
		chkFortitude:SetChecked(FortitudeText);
		chkShadowProtection:SetChecked(ShadowProtectionText);
		chkDisease:SetChecked(DiseaseText);
		chkMagic:SetChecked(MagicText);
		chkShackleBreak:SetChecked(ShackleBreakText);
		chkOtherShackleBreak:SetChecked(OtherShackleBreakText);
		chkInnerFireNag:SetChecked(InnerFireNag);
		chkFortitudeNag:SetChecked(FortitudeNag);
		chkShadowProtectionNag:SetChecked(ShadowProtectionNag);
		chkMountSay:SetChecked(MountSayText);
		chkRezSay:SetChecked(RezSayText);
		chkRezWhisper:SetChecked(RezWhisperText);
		chkRezParty:SetChecked(RezPartyText);
		chkMCSay:SetChecked(MCSayText);
		chkShackleSay:SetChecked(ShackleSayText);
	else
		chkFWReady:SetChecked(true);
		chkFWFaded:SetChecked(true);
		chkFWCast:SetChecked(true);
		chkInnerFire:SetChecked(true);
		chkFortitude:SetChecked(true);
		chkShadowProtection:SetChecked(true);
		chkDisease:SetChecked(true);
		chkMagic:SetChecked(true);
		chkShackleBreak:SetChecked(true);
		chkOtherShackleBreak:SetChecked(true);
		chkInnerFireNag:SetChecked(true);
		chkFortitudeNag:SetChecked(true);
		chkShadowProtectionNag:SetChecked(true);
		chkMountSay:SetChecked(true);
		chkRezSay:SetChecked(true);
		chkRezWhisper:SetChecked(true);
		chkRezParty:SetChecked(true);
		chkMCSay:SetChecked(true);
		chkShackleSay:SetChecked(true);
	end
	
	--now set up the sliders
	if (SacredCandleText) then
		sldSacredCandles:SetValue(SacredCandleText);
	else
		sldSacredCandles:SetValue("60");
	end
	if (HolyCandleText) then
		sldHolyCandles:SetValue(HolyCandleText);
	else
		sldHolyCandles:SetValue("0");
	end
	if (NagIntervalText) then
		sldNagInterval:SetValue(NagIntervalText);
	else
		sldNagInterval:SetValue("60");
	end
	AlreadyStoredVars = true;
end

function Timer_OnUpdate(self, elapsed)
	--DEFAULT_CHAT_FRAME:AddMessage("it's running", 1.0, 1.0, 1.0, nil, false);
	if (FWTimerEnabled == true) then
		--DEFAULT_CHAT_FRAME:AddMessage("here:"..elapsed, 1.0, 1.0, 1.0, nil, false);
		FWTimeSinceLastUpdate = FWTimeSinceLastUpdate + elapsed;
		while (FWTimeSinceLastUpdate > UpdateInterval) do
			--DEFAULT_CHAT_FRAME:AddMessage("Counting "..CurrentCountdown, 1.0, 0.0, 0.0, nil, false);
			CurrentCountdown = CurrentCountdown + 1.0; --count 1 second
			if (CurrentCountdown > FearWardCooldown-6) then
				if (CurrentCountdown > FearWardCooldown-1) then
					CurrentCountdown = 1;
					FWTimerEnabled = false;
					FWTimeSinceLastUpdate = 0;
					DEFAULT_CHAT_FRAME:AddMessage("Fear Ward is ready!!!", 1.0, 0.0, 0.0, nil, false);
					if (FearWardReadySound ~= "") then
						PlaySoundFile(SoundPath..FearWardReadySound);
					end
				else
					--print the last 5 seconds of the countdown
					DEFAULT_CHAT_FRAME:AddMessage("Fear Ward will be ready in "..(FearWardCooldown-CurrentCountdown).." seconds", 1.0, 1.0, 1.0, nil, false);
				end
			end
			FWTimeSinceLastUpdate = FWTimeSinceLastUpdate - UpdateInterval;
		end
	end
	local TempNagMessageSelf = "";
	TempNagMessageRaidFort = "";
	TempNagMessageRaidShadowProt = "";
	HasInnerFire = false;
	HasFort = false;
	HasShadowProt = false;
	if (InnerFireNag or FortitudeNag or ShadowProtectionNag) then
		--DEFAULT_CHAT_FRAME:AddMessage("here:"..elapsed, 1.0, 1.0, 1.0, nil, false);
		NagTimeSinceLastUpdate = NagTimeSinceLastUpdate + elapsed;
		if (NagTimeSinceLastUpdate > NagIntervalText) then
			--now check the buffs that we need to check
			--check yo'self before you reck yo'self :-P
			--iterate through your buffs
			--DEFAULT_CHAT_FRAME:AddMessage("Checking Buffs", 1.0, 0.0, 0.0, 53, 5);
			TempNagMessageSelf = "";
			HasInnerFire = not InnerFireNag; --this will give us a false positive if it's disabled
			HasFort = not FortitudeNag; --this will give us a false positive if it's disabled
			HasShadowProt = not ShadowProtectionNag; --this will give us a false positive if it's disabled
			NumBuffs = 0;
			TempNumBuffs = 0;
			for i=1,40 do
				local myBuffName, rank, iconTexture, count, duration, timeLeft =  UnitBuff("player", i);
				if (myBuffName == "Inner Fire") then
					HasInnerFire = true;
				elseif ((myBuffName == "Power Word: Fortitude") or (myBuffName == "Prayer of Fortitude")) then
					HasFort = true;
				elseif ((myBuffName == "Shadow Protection") or (myBuffName == "Prayer of Shadow Protection")) then
					HasShadowProt = true;						
				end
				if ((HasInnerFire) and (HasFort) and (HasShadowProt)) then
					i=40;
				end
			end
			TempNagMessageSelf = MakeMyMessage(HasInnerFire, HasFort, HasShadowProt);
			if (TempNagMessageSelf ~= "") then
				if (not HasInnerFire) then
					if (InnerFireSound ~= "") then
						PlaySoundFile(SoundPath..InnerFireSound);
					end
				end
				if (not HasFort) then
					if (FortitudeSound ~= "") then
						PlaySoundFile(SoundPath..FortitudeSound);
					end
				end
				if (not HasShadowProt) then
					if (ShadowProtectionSound ~= "") then
						PlaySoundFile(SoundPath..ShadowProtectionSound);
					end
				end
				UIErrorsFrame:AddMessage("You need "..TempNagMessageSelf, 1.0, 0.0, 0.0, 53, 5);
			end
			--now check party/raid members for the buffs
			TempNagMessageRaidFort = "";
			TempNagMessageRaidShadowProt = "";
			if (GetNumRaidMembers() > 0) then  --iterate through your raid members
				--go through and check for dead people to rez
				for i=1,40 do
					if (UnitName("raid"..i)) then
						if (UnitName("raid"..i) ~= UnitName("player")) then
							if (not UnitIsDeadOrGhost("raid"..i)) then
								if (UnitIsConnected("raid"..i)) then
									--check buffs
									CheckFortAndShadowBuffs("raid"..i);
								end
							end
						end
					end
					if (UnitName("raidpet"..i)) then
						if (not UnitIsDeadOrGhost("raid"..i)) then
							if (UnitIsConnected("raid"..i)) then
								--check buffs
								CheckFortAndShadowBuffs("raidpet"..i);
							end
						end
					end
				end
			elseif (GetNumPartyMembers() > 0) then  --iterate through your raid members
				for i=1,4 do
					if (UnitName("party"..i)) then
						if (not UnitIsDeadOrGhost("party"..i)) then
							if (UnitIsConnected("party"..i)) then
								--check buffs
								CheckFortAndShadowBuffs("party"..i);
							end
						end
					end
					if (UnitName("partypet"..i)) then
						if (not UnitIsDeadOrGhost("party"..i)) then
							if (UnitIsConnected("party"..i)) then
								--check buffs
								CheckFortAndShadowBuffs("partypet"..i);
							end
						end
					end
				end
			end
			if (TempNagMessageRaidFort ~= "") then
				UIErrorsFrame:AddMessage("Needs Fortitude:"..TempNagMessageRaidFort, 1.0, 0.0, 0.0, 53, 5);
				if (FortitudeSound ~= "") then
					PlaySoundFile(SoundPath..FortitudeSound);
				end
			end
			if (TempNagMessageRaidShadowProt ~= "") then
				UIErrorsFrame:AddMessage("Needs Shadow Protection:"..TempNagMessageRaidShadowProt, 1.0, 0.0, 0.0, 53, 5);
				if (ShadowProtectionSound ~= "") then
					PlaySoundFile(SoundPath..ShadowProtectionSound);
				end
			end
			while (NagTimeSinceLastUpdate > NagIntervalText) do
				NagTimeSinceLastUpdate = NagTimeSinceLastUpdate - NagIntervalText;
			end
		end
	end
end

function CheckFortAndShadowBuffs(WhoToCheck)
	HasFort = not FortitudeNag; --this will give us a false positive if it's disabled
	HasShadowProt = not ShadowProtectionNag; --this will give us a false positive if it's disabled
	local j
	for j=1,40 do
		local myBuffName, rank, iconTexture, count, duration, timeLeft =  UnitBuff(WhoToCheck, j);
		if (myBuffName) then
			if ((myBuffName == "Power Word: Fortitude") or (myBuffName == "Prayer of Fortitude")) then
				HasFort = true;
			elseif ((myBuffName == "Shadow Protection") or (myBuffName == "Prayer of Shadow Protection")) then
				HasShadowProt = true;						
			end
			if ((HasFort) and (HasShadowProt)) then
				j=40; --stop looking, we have what we want
			end
		else
			j=40; --because we reached the end
		end
	end
	if (not ((HasFort) and (HasShadowProt))) then
		if (not HasFort) then
			if (TempNagMessageRaidFort == "") then
				TempNagMessageRaidFort = TempNagMessageRaidFort..UnitName(WhoToCheck);
			else
				TempNagMessageRaidFort = TempNagMessageRaidFort..","..UnitName(WhoToCheck);
			end
		end
		if (not HasShadowProt) then
			if (TempNagMessageRaidShadowProt == "") then
				TempNagMessageRaidShadowProt = TempNagMessageRaidShadowProt..UnitName(WhoToCheck);
			else
				TempNagMessageRaidShadowProt = TempNagMessageRaidShadowProt..","..UnitName(WhoToCheck);
			end
		end
	end
end

function MakeMyMessage(HasInnerFire, HasFort, HasShadowProt)
	local TempMyMessage = "";
	local NumBuffs = 0;
	local TempNumBuffs = 0;
	if (not ((HasInnerFire) and (HasFort) and (HasShadowProt))) then
		NumBuffs = 0;
		TempNumBuffs = 0;
		if (not (HasInnerFire)) then
			NumBuffs = NumBuffs + 1;
		end
		if (not (HasFort)) then
			NumBuffs = NumBuffs + 1;
		end
		if (not (HasShadowProt)) then
			NumBuffs = NumBuffs + 1;
		end
		-- now that we know how many put the message together
		if (not (HasInnerFire)) then
			TempMyMessage = "Inner Fire";
			TempNumBuffs = TempNumBuffs + 1;
		end
		if (not (HasFort)) then
			if (NumBuffs == 3) then
				TempMyMessage = TempMyMessage..", Fortitude"
			elseif (NumBuffs ==2) then
				if (TempNumBuffs == 1) then
					TempMyMessage = TempMyMessage.." and Fortitude"
				else
					TempMyMessage = "Fortitude"
				end
			else  --(NumBuffs ==1) then
				TempMyMessage = "Fortitude"
			end
			TempNumBuffs = TempNumBuffs + 1;
		end
		if (not (HasShadowProt)) then
			if (NumBuffs > 1) then
				TempMyMessage = TempMyMessage.." and Shadow Protection"
			else
				TempMyMessage = "Shadow Protection"
			end
			TempNumBuffs = TempNumBuffs + 1;
		end
	end
	return TempMyMessage;
end

function HideConfig()
	Config:Hide();
end

function ShowConfig()
	Config:Show();
end

--function MyAddOn_OnComms(chattype, text, author)
	--if (chattype == "CHAT_MSG_SAY") then
	--	DEFAULT_CHAT_FRAME:AddMessage(text, 1.0, 1.0, 1.0, nil, false);
	--elseif (chattype == "CHAT_MSG_WHISPER") then
	--	DEFAULT_CHAT_FRAME:AddMessage(text, 1.0, 0.0, 0.0, nil, false);
	--end
--end
