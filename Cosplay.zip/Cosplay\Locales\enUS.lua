local L = LibStub("AceLocale-3.0"):NewLocale("Cosplay", "enUS", true)
if not L then return end
--
L["Undress"] = true
L["Target"] = true
L["Open the DressUpFrame"] = true
L["Undress Button"] = true
