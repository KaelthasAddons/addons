﻿local L = LibStub("AceLocale-3.0"):NewLocale("Cosplay", "esES")
if not L then return end
--
L["Undress"] = "Desvestir"
L["Target"] = "Objetivo"
L["Open the DressUpFrame"] = "Abrir marco Vestidor"
L["Undress Button"] = "Botón Desvestir"
