You are allowed to copy/learn from this addon
and use the code in other addons without credit
for PRIVATE use only.

You are not allowed to publish code from this
addon without giving credit.

Any form of public release of this code in another
addon must have the following:

>Full credit to BadBoy on the page description
with a URL to an OFFICIAL BadBoy download location.
>Full credit to BadBoy in the Lua file stating
what code was copied and a URL to an OFFICIAL
BadBoy download location.

Any copying of the blacklist database must have
the following:

>Full credit to BadBoy on the page description
with a URL to an OFFICIAL BadBoy download location.
>Full credit to BadBoy in the Lua file stating
what code was copied and a URL to an OFFICIAL
BadBoy download location.
>Partial credit to Anea(Author of SpamSentry) of
which this database was originally built in
a location of your choosing.

You are in no way allowed to continue leeching the
database of this addon, a database copy should be a
one time thing to get started.
