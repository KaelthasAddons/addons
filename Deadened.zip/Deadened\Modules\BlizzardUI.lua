local Deadened = LibStub("AceAddon-3.0"):GetAddon("Deadened")
local mod = Deadened:NewModule("BlizzardUI", "AceHook-3.0")

function mod:OnEnable(module)
	if not TargetFrameSpellBar then return end
	self:RawHook("CastingBarFrame_OnEvent", true)
end

function mod:MenuHide()
	return TargetFrameSpellBar == nil
end

function mod:CastingBarFrame_OnEvent(obj, newevent, newarg1)
	if this == TargetFrameSpellBar and newevent == PLAYER_ENTERING_WORLD or newevent == UNIT_SPELLCAST_START then
		local spell, rank, displayName, icon, startTime, endTime = UnitCastingInfo("target")
		if Deadened:IsDeaden(displayName) then
			return
		end
	end
	self.hooks.CastingBarFrame_OnEvent(newevent, newarg1)
end
