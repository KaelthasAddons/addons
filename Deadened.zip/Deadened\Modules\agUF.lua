local Deadened = LibStub("AceAddon-3.0"):GetAddon("Deadened")
local aguf = Deadened:NewModule("agUF", "AceHook-3.0", "AceEvent-3.0")

local first = true
function aguf:OnEnable(module)
	if first then
		self:RegisterEvent("PLAYER_ENTERING_WORLD")
		first = nil
	else
		self:PLAYER_ENTERING_WORLD()
	end
end

function aguf:PLAYER_ENTERING_WORLD()
	self:UnregisterEvent("PLAYER_ENTERING_WORLD")
	if not aUF or not aUF.units or not aUF.units.aUFtarget then return end
	if not self:IsHooked(aUF.units.aUFtarget, "SpellcastStart") then
		self:RawHook(aUF.units.aUFtarget, "SpellcastStart", "UNIT_SPELLCAST_START")
	end
end

function aguf:MenuHide()
	return aUF == nil
end

function aguf:UNIT_SPELLCAST_START(orig_object, event, unit, ...)
	if unit == "target" then
		local spell, rank, displayName, icon, startTime, endTime = UnitCastingInfo(unit)
		if not Deadened:IsDeaden(displayName) then
			self.hooks[orig_object].UNIT_SPELLCAST_START(orig_object, event, unit, ...)
		end
	end
end
