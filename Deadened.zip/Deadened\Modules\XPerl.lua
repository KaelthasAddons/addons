local Deadened = LibStub("AceAddon-3.0"):GetAddon("Deadened")
local xperl = Deadened:NewModule("XPerl", "AceHook-3.0")

function xperl:OnEnable()
	if not XPerl_ArcaneBar_OnEvent then return end
	if not self:IsHooked("XPerl_ArcaneBar_OnEvent") then
		self:RawHook("XPerl_ArcaneBar_OnEvent")
	end
end

function xperl:MenuHide()
	return XPerl_ArcaneBar_OnEvent == nil
end

local events = {
	["PLAYER_ENTERING_WORLD"] = true,
	["PLAYER_TARGET_CHANGED"] = true,
	["PLAYER_FOCUS_CHANGED"] = true,
	["PARTY_MEMBER_ENABLE"] = true,
	["PARTY_MEMBER_DISABLE"] = true
}

local count = 0
function xperl.XPerl_ArcaneBar_OnEvent(orig_object, self, origevent, newarg1)
	count = count + 1
	local event
	if not self.unit then
		return xperl.hooks.XPerl_ArcaneBar_OnEvent(self, origevent, newarg1)
	end
	local spell, rank, displayName, icon, startTime, endTime = UnitCastingInfo(self.unit)
	local event = events[origevent] and "UNIT_SPELLCAST_START" or origevent
	if displayName and event == "UNIT_SPELLCAST_START" and Deadened:Suppress(displayName) then
		return
	end
	xperl.hooks.XPerl_ArcaneBar_OnEvent(self, origevent, newarg1)
end
