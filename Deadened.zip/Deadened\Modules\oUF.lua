local mod = Deadened:NewModule("oUF", "AceHook-3.0")

function mod:OnEnable(module)
	if not IsAddOnLoaded("oUF") then return end
	for _, obj in pairs(oUF.objects) do
		if obj.unit == "target" and obj.Castbar then
			self:RawHook(obj, "UNIT_SPELLCAST_START")
			break
		end
	end
end

function mod:UNIT_SPELLCAST_START(obj, event, unit, ...)
	if unit ~= obj.unit then return end
	local _, _, displayName = UnitCastingInfo(unit)
	if not Deadened:IsDeaden(displayName) then
		self.hooks[obj].UNIT_SPELLCAST_START(obj, event, unit, ...)
	end
end
