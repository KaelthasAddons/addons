local Deadened = LibStub("AceAddon-3.0"):GetAddon("Deadened")
local antagonist = Deadened:NewModule("Antagonist", "AceHook-3.0")

function antagonist:OnEnable()
	if not Antagonist then return end
	if not self:IsHooked(Antagonist, "ParseChannelUpdate") then
		self:RawHook(Antagonist, "StartBar")
		-- self:Hook(Antagonist, "ParseSpellStart", "UNIT_SPELLCAST_START", true)
	end
end

function antagonist:MenuHide()
	return Antagonist == nil
end

function antagonist:StartBar(frame, unitName, unitGUID, spellID, group, left)
	if UnitGUID("target") == unitGUID and Deadened:IsDeaden(spellID) then
		return
	end
	self.hooks[frame]["StartBar"](frame, unitName, unitGUID, spellID, group, left)
end
