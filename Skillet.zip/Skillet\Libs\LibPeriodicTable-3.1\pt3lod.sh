#/bin/bash
cd ..
rm -rf LibPeriodicTable-3.1-ClassSpell
rm -rf LibPeriodicTable-3.1-Consumable
rm -rf LibPeriodicTable-3.1-Gear
rm -rf LibPeriodicTable-3.1-GearSet
rm -rf LibPeriodicTable-3.1-InstanceLoot
rm -rf LibPeriodicTable-3.1-InstanceLootHeroic
rm -rf LibPeriodicTable-3.1-Misc
rm -rf LibPeriodicTable-3.1-Reputation
rm -rf LibPeriodicTable-3.1-Tradeskill
rm -rf LibPeriodicTable-3.1-TradeskillResultMats

cd LibPeriodicTable-3.1

mv LibPeriodicTable-3.1-ClassSpell ../LibPeriodicTable-3.1-ClassSpell
mv LibPeriodicTable-3.1-Consumable ../LibPeriodicTable-3.1-Consumable
mv LibPeriodicTable-3.1-Gear ../LibPeriodicTable-3.1-Gear
mv LibPeriodicTable-3.1-GearSet ../LibPeriodicTable-3.1-GearSet
mv LibPeriodicTable-3.1-InstanceLoot ../LibPeriodicTable-3.1-InstanceLoot
mv LibPeriodicTable-3.1-InstanceLootHeroic ../LibPeriodicTable-3.1-InstanceLootHeroic
mv LibPeriodicTable-3.1-Misc ../LibPeriodicTable-3.1-Misc
mv LibPeriodicTable-3.1-Reputation ../LibPeriodicTable-3.1-Reputation
mv LibPeriodicTable-3.1-Tradeskill ../LibPeriodicTable-3.1-Tradeskill
mv LibPeriodicTable-3.1-TradeskillResultMats ../LibPeriodicTable-3.1-TradeskillResultMats
