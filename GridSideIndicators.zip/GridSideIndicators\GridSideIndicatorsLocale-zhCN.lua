﻿local L = AceLibrary("AceLocale-2.2"):new("GridSideIndicators")

L:RegisterTranslations("zhCN", function()
        return {
			["Top Side"] = "顶部",
			["Right Side"] = "右侧",
			["Bottom Side"] = "底部",
			["Left Side"] = "左侧",
        } 
end)
