local L = AceLibrary("AceLocale-2.2"):new("GridSideIndicators")

L:RegisterTranslations("frFR", function()
        return {
			["Top Side"] = "Coin sup\195\169rieur",
			["Right Side"] = "Coin droit",
			["Bottom Side"] = "Coin inf\195\169rieur",
			["Left Side"] = "Coin gauche",
        } 
end)
