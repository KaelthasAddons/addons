﻿local L = AceLibrary("AceLocale-2.2"):new("GridSideIndicators")

L:RegisterTranslations("deDE", function()
        return {
			["Top Side"] = "Seite oben",
			["Right Side"] = "Seite rechts",
			["Bottom Side"] = "Seite unten",
			["Left Side"] = "Seite links",
        } 
end)
