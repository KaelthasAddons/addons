local L = AceLibrary("AceLocale-2.2"):new("GridSideIndicators")

L:RegisterTranslations("koKR", function()
        return {
			["Top Side"] = "상단 모서리",
			["Right Side"] = "우측 모서리",
			["Bottom Side"] = "하단 모서리",
			["Left Side"] = "좌측 모서리",
        } 
end)
