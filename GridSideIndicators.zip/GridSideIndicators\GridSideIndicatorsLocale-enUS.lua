local L = AceLibrary("AceLocale-2.2"):new("GridSideIndicators")

L:RegisterTranslations("enUS", function()
        return {
			["Top Side"] = true,
			["Right Side"] = true,
			["Bottom Side"] = true,
			["Left Side"] = true,
        } 
end)
