PlayerHitIndicator:SetText(nil)
PlayerHitIndicator.SetText = function() end
PetHitIndicator:SetText(nil)
PetHitIndicator.SetText = function() end

local UnitIsPlayer, UnitIsConnected, UnitClass, RAID_CLASS_COLORS = UnitIsPlayer, UnitIsConnected, UnitClass, RAID_CLASS_COLORS
local _, class, c
local function colour(statusbar, unit) if UnitIsPlayer(unit) and UnitIsConnected(unit) and unit == statusbar.unit and UnitClass(unit) then _, class = UnitClass(unit) c = CUSTOM_CLASS_COLORS and CUSTOM_CLASS_COLORS[class] or RAID_CLASS_COLORS[class] statusbar:SetStatusBarColor(c.r, c.g, c.b) end end
hooksecurefunc("UnitFrameHealthBar_Update", colour) hooksecurefunc("HealthBar_OnValueChanged", function(self) colour(self, self.unit) end)
local sb = _G.GameTooltipStatusBar local addon = CreateFrame("Frame", "StatusColour") addon:RegisterEvent("UPDATE_MOUSEOVER_UNIT") addon:SetScript("OnEvent", function() colour(sb, "mouseover") end) 

--MainMenuBar:SetScale(0.9)
ExtraActionBarFrame:ClearAllPoints();
ExtraActionBarFrame:SetPoint("CENTER", UIParent, 0, -200)
ExtraActionBarFrame.SetPoint = function() end;
ExtraActionBarFrame:SetScale(0.8);
MultiBarRight:ClearAllPoints();
MultiBarRight:SetPoint("Center",MultiBarBottomRight, -233, -186)
MultiBarRight.SetPoint = function() end;
MultiBarLeft:ClearAllPoints();
MultiBarLeft:SetPoint("Center",MultiBarBottomLeft, -233, -186)
MultiBarLeft.SetPoint = function() end;
StanceBarFrame:ClearAllPoints();
StanceBarFrame:SetPoint("TOPRIGHT",MultiBarBottomRight, -125, 85)
StanceBarFrame.SetPoint = function() end; for i,v in ipairs{"Left","Right"} do for i = 2, 12 do local n = "MultiBar"..v.."Button" local btn = _G[n..i] btn:ClearAllPoints() btn:SetPoint("LEFT", n..i - 1, "RIGHT", 6, 0) end end;
PetActionBarFrame:ClearAllPoints();
PetActionBarFrame:SetPoint("TOPLEFT", MultiBarBottomLeft, -37, 97);
PetActionBarFrame.SetPoint = function() end;

hooksecurefunc("GameTooltip_SetDefaultAnchor",function(tooltip, parent)tooltip:SetOwner(parent, "ANCHOR_NONE"); tooltip:ClearAllPoints();tooltip:SetPoint("TOP", UIParent, 0, -100)end) GameTooltip:SetScale(0.9) local function ToTTooltip(totT, ...) local sName, iUnit = totT:GetUnit() if iUnit then sName = UnitName(iUnit.."target") if sName then totT:AddLine("Target " .. sName) totT:Show() end end end GameTooltip:HookScript("OnTooltipSetUnit", ToTTooltip)

-- Class Icon instead of Portrait
-- hooksecurefunc("UnitFramePortrait_Update",function(self) if self.portrait then if UnitIsPlayer(self.unit) then local t = CLASS_ICON_TCOORDS[select(2, UnitClass(self.unit))] if t then self.portrait:SetTexture("Interface\\TargetingFrame\\UI-Classes-Circles") self.portrait:SetTexCoord(unpack(t)) end else self.portrait:SetTexCoord(0,1,0,1) end end end)