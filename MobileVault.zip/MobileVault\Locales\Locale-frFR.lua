local L = AceLibrary("AceLocale-2.2"):new("MobileVault")

L:RegisterTranslations("frFR", function() return {

	-- Menu translations
	["Toggle Frame"] = "Affiche/Cache la fenêtre",
	["Show or Hide the Guild Vault Image Frame"] = "Affiche ou cache l'image de la fenêtre de la banque de guilde",
	["Gather Data"] = "Récupère les données",
	["Toggle whether or not MGV will take an image of your guild bank."] = "Indique si MGV prendra une image de votre banque de guilde",
	["Delete"] = "Effacer",
	["Delete the specified guild's data table"] = "Efface les données de l'onglet de guilde spécifié",
	["<name of guild>"] = "<nom de guilde>",
	["has been cleared from the Database."] = "a été effacé de la base de données",
	["does not have any data stored with MGV."] = "n'a pas de données stockées avec MGV",
	["Print DB Names"] = "Afficher le nom des BDD",
	["Print out a list of all populated guild databases."] = "Affiche la liste des bases de données des guildes collectées",
	["Scan"] = "Scan",
	["Runs a scan of the Guild Bank if it is already open."] = "Lance un scan de la banque de guilde si elle est déjà ouverte",
	["Visuals"] = "Visuels",
	["Options for the visual aspects of the addon."] = "Options pour les aspects visuels de l'addon",
	["Text Color"] = "Couleur texte",
	["Set the text color."] = "Définit la couleur du texte",
	["Frame Color"] = "Couleur fenêtre",
	["Set the color of the image frame"] = "Définit la couleur de la fenêtre",
	["Border Color"] = "Couleur bordure",
	["Set the Slot Border Color"] = "Définit la couleur de la bordure des emplacements",
	["Clicked Color"] = "Couleur onglet actif",
	["Sets the color for the active tab button"] = "Définit la couleur du bouton de l'onglet actif",
	["Highlight Color"] = "Couleur surbrillance",
	["Set the Slot Hightlight Color"] = "Définit la couleur de surbrillance des emplacements",
	["Configuration"] = "Configuration",
	["Show the GUI configuration menu."] = "Affiche l'interface du menu de configuration",
	["Tooltips"] = "Infobulles",
	["Options for the Mobile Guild Vault toolips."] = "Options pour les infobulles de MGV",
	["Guilds"] = "Guildes",
	["Choose which guild bank counts you want in the tooltips."] = "Choisit quels comptes de banque de guilde à afficher dans les infobulles",
	["Text Color"] = "Couleur texte",
	["Set the text color for the tooltips."] = "Définit la couleur du texte dans les infobulles",
	
	--Other translations
	["Last Scan:"] = "Dernier scan :",
	["Left-click to drag the window"] = "Clic-gauche pour déplacer la fenêtre",
	["Right-click to open the DewDrop menu"] = "Clic-droit pour ouvrir le menu DewDrop",
	["Mobile Guild Vault"] = "Mobile Guild Vault",
	["Page"] = "Page",
	["at"] = "à",
	["There are no tabs in this guild bank!"] = "Il n'y a aucun onglet dans cette banque de guilde",
	["Vault:"] = "Banque :",
	
	--In the following strings leave the |r after the translations for Click and Shift-Click for the coloring to work properly
	["Click|r to toggle the MobileVault Frame"] = "Clic|r pour ouvrir/fermer la fenêtre de MobileVault",
	
	--for locales with different syntax from English, the %s is replaced with the name of a guild
	--ex. "View the Dark Tranquility Vault"
	["View the %s vault."] = "Voir la banque de la guilde %s",
	
	--new translations for the updated FuBar stuff
	["FuBar Options"] = "Options FuBar",
	["Display options for the FuBar plugin."] = "Affiche les options pour le module FuBar",
} end)
