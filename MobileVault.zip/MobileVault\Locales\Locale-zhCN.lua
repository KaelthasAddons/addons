local L = AceLibrary("AceLocale-2.2"):new("MobileVault")

L:RegisterTranslations("zhCN", function() return {
	["Slash-Commands"] = { "/mobilevault", "/mgv" },
	-- Menu translations
	["Toggle Frame"] = "开关窗口",
	["Show or Hide the Guild Vault Image Frame"] = "显示或隐藏公会银行影像窗口",
	["Gather Data"] = "收集数据",
	["Toggle whether or not MGV will take an image of your guild bank."] = "开启或关闭让MGV收集公会银行数据",
	["Delete"] = "删除",
	["Delete the specified guild's data table"] = "删除特定的公会数据",
	["<name of guild>"] = "<公会名称>",
	["has been cleared from the Database."] = "已经从数据库里删除",
	["does not have any data stored with MGV."] = "没有任何被MGV保存的数据",
	["Print DB Names"] = "列出数据库名字",
	["Print out a list of all populated guild databases."] = "列出数据库内所有公会",
	["Scan"] = "扫描",
	["Runs a scan of the Guild Bank if it is already open."] = "扫描公会银行(如果已经打开)",
	["Visuals"] = "外观",
	["Options for the visual aspects of the addon."] = "设置插件窗口外观",
	["Text Color"] = "文字颜色",
	["Set the text color."] = "设置文字颜色",
	["Frame Color"] = "窗口颜色",
	["Set the color of the image frame"] = "设置窗口颜色",
	["Border Color"] = "边框颜色",
	["Set the Slot Border Color"] = "设置格子边框颜色",
	["Clicked Color"] = "当前标签颜色",
	["Sets the color for the active tab button"] = "设置已激活的当前标签颜色",
	["Highlight Color"] = "高亮颜色",
	["Set the Slot Hightlight Color"] = "设置格子高亮颜色",
	["Configuration"] = "设置",
	["Show the GUI configuration menu."] = "显示图形设置菜单",
	["Tooltips"] = "工具提示",
	["Options for the Mobile Guild Vault toolips."] = "设置Mobile Guild Vault工具提示",
	["Guilds"] = "公会",
	["Choose which guild bank counts you want in the tooltips."] = "选择哪个公会银行的数据显示在工具提示上",
	--["Text Color"] = true,
	["Set the text color for the tooltips."] = "设置工具提示上的文字颜色",
	
	--Other translations
	["Last Scan:"] = "上次扫描:",
	["Last Scan: "] = "上次扫描: ",
	["Left-click to drag the window"] = "左键点击拖动窗口",
	["Right-click to open the DewDrop menu"] = "右键点击显示菜单",
	["Mobile Guild Vault"] = "Mobile Guild Vault",
	["Page"] = "页",
	["date_format"] = "%Y-%m-%d",
	["at"] = "在",
	["There are no tabs in this guild bank!"] = "该公会银行没有任何标签",
	["Vault:"] = "公会银行:",
	
	--in the following strings leave the |r after the traslations for Click and Shift-Click for the coloring to work properly
	["Click|r to toggle the MobileVault Frame"] = "点击|r 开关MobileVault窗口",
	
	--for locales with different syntax from English, the %s is replaced with the name of a guild
	--ex. "View the Dark Tranquility Vault"
	["View the %s vault."] = "查看 %s 的公会银行",
	
	--new translations for the updated FuBar stuff
	["FuBar Options"] = "FuBar设置",
	["Display options for the FuBar plugin."] = "显示FuBar插件设置",
	
	--new translations for customizing the image frame
	["Column Spacing"] = "列间隔",
	["Set the column spacing"] = "设置列间隔",
	["Slot Padding"] = "格子间隔",
	["Set the amount of space between the slots in a column"] = "设置格子之间的间隔",
	["Tab Button Spacing"] = "标签按钮间隔",
	["Set the amount of space between the tab buttons"] = "设置标签按钮的间隔",

	["g |r"] = "g |r",
	["s |r"] = "s |r",
	["c"] = "c",
	[" AM"] = " 上午",
	[" PM"] = " 下午",
	
	["Welcome to Mobile Vault! \nPlease select a tab."] = "欢迎使用Mobile Vault! \n请选择标签.",
	
	["Frame Alpha"] = "窗口透明度",
	["Set the frame alpha"] = "设置窗口透明度",
} end)
