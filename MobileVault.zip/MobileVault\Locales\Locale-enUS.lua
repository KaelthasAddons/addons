﻿local L = AceLibrary("AceLocale-2.2"):new("MobileVault")

L:RegisterTranslations("enUS", function() return {
	["Slash-Commands"] = { "/mobilevault", "/mgv" },
	-- Menu translations
	["Toggle Frame"] = true,
	["Show or Hide the Guild Vault Image Frame"] = true,
	["Gather Data"] = true,
	["Toggle whether or not MGV will take an image of your guild bank."] = true,
	["Delete"] = true,
	["Delete the specified guild's data table"] = true,
	["<name of guild>"] = true,
	["has been cleared from the Database."] = true,
	["does not have any data stored with MGV."] = true,
	["Print DB Names"] = true,
	["Print out a list of all populated guild databases."] = true,
	["Scan"] = true,
	["Runs a scan of the Guild Bank if it is already open."] = true,
	["Visuals"] = true,
	["Options for the visual aspects of the addon."] = true,
	["Text Color"] = true,
	["Set the text color."] = true,
	["Frame Color"] = true,
	["Set the color of the image frame"] = true,
	["Border Color"] = true,
	["Set the Slot Border Color"] = true,
	["Clicked Color"] = true,
	["Sets the color for the active tab button"] = true,
	["Highlight Color"] = true,
	["Set the Slot Hightlight Color"] = true,
	["Configuration"] = true,
	["Show the GUI configuration menu."] = true,
	["Tooltips"] = true,
	["Options for the Mobile Guild Vault toolips."] = true,
	["Guilds"] = true,
	["Choose which guild bank counts you want in the tooltips."] = true,
	["Text Color"] = true,
	["Set the text color for the tooltips."] = true,
	
	--Other translations
	["Last Scan:"] = true,
	["Last Scan: "] = true,
	["Left-click to drag the window"] = true,
	["Right-click to open the DewDrop menu"] = true,
	["Mobile Guild Vault"] = true,
	["Page"] = true,
	["date_format"] = "%B %d, %Y",
	["at"] = true,
	["There are no tabs in this guild bank!"] = true,
	["Vault:"] = true,
	
	--in the following strings leave the |r after the traslations for Click and Shift-Click for the coloring to work properly
	["Click|r to toggle the MobileVault Frame"] = true,
	
	--for locales with different syntax from English, the %s is replaced with the name of a guild
	--ex. "View the Dark Tranquility Vault"
	["View the %s vault."] = true,
	
	--new translations for the updated FuBar stuff
	["FuBar Options"] = true,
	["Display options for the FuBar plugin."] = true,
	
	--new translations for customizing the image frame
	["Column Spacing"] = true,
	["Set the column spacing"] = true,
	["Slot Padding"] = true,
	["Set the amount of space between the slots in a column"] = true,
	["Tab Button Spacing"] = true,
	["Set the amount of space between the tab buttons"] = true,

	["g |r"] = true,
	["s |r"] = true,
	["c"] = true,
	[" AM"] = true,
	[" PM"] = true,
	
	["Welcome to Mobile Vault! \nPlease select a tab."] = true,
	
	["Frame Alpha"] = true,
	["Set the frame alpha"] = true,
} end)
