﻿local L = AceLibrary("AceLocale-2.2"):new("MobileVault")

L:RegisterTranslations("koKR", function() return {
--	["Slash-Commands"] = { "/mobilevault", "/mgv" },
	-- Menu translations
	["Toggle Frame"] = "길드은행 보기",
	["Show or Hide the Guild Vault Image Frame"] = "길드은행를 표시하거나 숨깁니다.",
	["Gather Data"] = "길드은행 아이템 기록",
	["Toggle whether or not MGV will take an image of your guild bank."] = "길드은행에 보관되어있는 아이템의 정보를 저장합니다.",
	["Delete"] = "삭제",
	["Delete the specified guild's data table"] = "길드은행 정보를 삭제합니다.",
	["<name of guild>"] = "<길드이름>",
	["has been cleared from the Database."] = "데이터베이스가 초기화 되었습니다.",
	["does not have any data stored with MGV."] = "저장된 데이터가 없습니다.",
	["Print DB Names"] = "DB이름(저장된 길드) 표시",
	["Print out a list of all populated guild databases."] = "저장된 길드목록을 대화창에 표시합니다.",
	["Scan"] = "조사",
	["Runs a scan of the Guild Bank if it is already open."] = "길드은행을 열었을 경우 아이템을 조사하여 기록합니다.",
	["Visuals"] = "화면표시",
	["Options for the visual aspects of the addon."] = "화면표시에 관한 설정입니다.",
	["Text Color"] = "글자색상",
	["Set the text color."] = "글자 색상을 변경합니다.",
	["Frame Color"] = "프레임 색상",
	["Set the color of the image frame"] = "길드은행 프레임 색상을 변경합니다.",
	["Border Color"] = "테두리 색상",
	["Set the Slot Border Color"] = "각 슬롯의 테두리 색상을 변경합니다.",
	["Clicked Color"] = "선택 색상",
	["Sets the color for the active tab button"] = "아이템 선택시 색상을 변경합니다.",
	["Highlight Color"] = "강조 색상",
	["Set the Slot Hightlight Color"] = "강조된 슬롯의 색상을 변경합니다.",
	["Configuration"] = "설정",
	["Show the GUI configuration menu."] = "GUI 설정 메뉴를 표시합니다.",
	["Tooltips"] = "툴팁",
	["Options for the Mobile Guild Vault toolips."] = "애드온 툴팁에 관한 설정입니다.",
	["Guilds"] = "길드",
	["Choose which guild bank counts you want in the tooltips."] = "아이템의 툴팁에 어느 길드은행에 보관되어 있는지 길드이름을 표시합니다.",
	["Text Color"] = "글자 색상",
	["Set the text color for the tooltips."] = "툴팁의 글자 색상을 변경합니다.",
	
	--Other translations
	["Last Scan:"] = "최근 조사:",
	["Left-click to drag the window"] = "왼쪽 클릭으로 창을 옮길 수 있습니다.",
	["Right-click to open the DewDrop menu"] = "오른쪽 클릭으로 메뉴를 엽니다.",
--	["Mobile Guild Vault"] = true,
	["Page"] = "페이지",
--	["at"] = true,
	["There are no tabs in this guild bank!"] = "길드은행 탭이 아닙니다.",
	["Vault:"] = "갯수:",
	
	--in the following strings leave the |r after the traslations for Click and Shift-Click for the coloring to work properly
	["Click|r to toggle the MobileVault Frame"] = "클릭|r하면 길드은행을 엽니다.",
	
	--for locales with different syntax from English, the %s is replaced with the name of a guild
	--ex. "View the Dark Tranquility Vault"
	["View the %s vault."] = "%s 길드은행 보기",
	
	--new translations for the updated FuBar stuff
	["FuBar Options"] = "FuBar 설정",
	["Display options for the FuBar plugin."] = "FuBar를 위한 설정입니다.",
	
	--new translations for customizing the image frame
	["Column Spacing"] = "컬럼 간격",
	["Set the column spacing"] = "컬럼의 세로 간격을 조정합니다.",
	["Slot Padding"] = "슬롯 간격",
	["Set the amount of space between the slots in a column"] = "각 컬럼의 슬롯(칸)의 간격을 조절합니다.",
	["Tab Button Spacing"] = "탭 버튼 간격",
	["Set the amount of space between the tab buttons"] = "은행 탭 버튼의 세로 간격을 조절합니다.",

	["g |r"] = "골드 |r",
	["s |r"] = "실버 |r",
	["c"] = "코퍼",
	[" AM"] = " 오전",
	[" PM"] = " 오후",

	["Welcome to Mobile Vault! \nPlease select a tab."] = "Mobile Vault 사용 \n 탭을 선택하세요.",
	
	["Frame Alpha"] = "투명도",
	["Set the frame alpha"] = "투명도를 변경합니다.",
} end)
