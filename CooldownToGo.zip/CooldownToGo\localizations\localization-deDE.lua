local L = LibStub("AceLocale-3.0"):NewLocale("CooldownToGo", "deDE", false)
if not L then return end
		
-- deDE localizations by Carylon. Thanks

L["Locked"] = "Gesperrt"
L["Lock/Unlock display frame"] = "Anzeige sperren/entsperren"
-- L["Hold time"] = true
-- L["Time to hold the message in seconds"] = true
-- L["Fade time"] = true
-- L["Fade time of the message in seconds"] = true
-- L["Ready time"] = true
-- L["Show the cooldown again this many seconds before the cooldown expires"] = true
L["Font"] = "Schriftart"
L["Default"] = "Default"
L["Font size"] = "Schriftgröße"
L["Font outline"] = "Schriftstil"
L["None"] = "Keine"
L["Normal"] = "Normal"
L["Thick"] = "Fett"
L["Color"] = "Farbe"
L["%s loaded. Type /cdtg for help"] = "%s geladen. /cdtg für Hilfe"
-- ["Strata"] = "Strata"
-- ["Frame strata"] = "Frame strata"
L["High"] = "Hoch"
L["Medium"] = "Mittel"
L["Low"] = "Niedrig"
-- L["Configure"] = true
-- L["Bring up GUI configure dialog"] = true


