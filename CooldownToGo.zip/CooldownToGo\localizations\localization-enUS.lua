local L = LibStub("AceLocale-3.0"):NewLocale("CooldownToGo", "enUS", true)
if not L then return end
		
L["Locked"] = true
L["Lock/Unlock display frame"] = true
L["Hold time"] = true
L["Time to hold the message in seconds"] = true
L["Fade time"] = true
L["Fade time of the message in seconds"] = true
L["Ready time"] = true
L["Show the cooldown again this many seconds before the cooldown expires"] = true
L["Font"] = true
L["Default"] = true
L["Font size"] = true
L["Font outline"] = true
L["None"] = true
L["Normal"] = true
L["Thick"] = true
L["Color"] = true
L["%s loaded. Type /cdtg for help"] = true
L["Strata"] = true
L["Frame strata"] = true
L["High"] = true
L["Medium"] = true
L["Low"] = true
L["Configure"] = true
L["Bring up GUI configure dialog"] = true
L["Ready"] = true
