local L = LibStub("AceLocale-3.0"):NewLocale("CooldownToGo", "zhCN", false)
if not L then return end
		
--zhCN by lcncg

L["Locked"] = "锁定"
L["Lock/Unlock display frame"] = "锁定或解锁显示框"
-- L["Hold time"] = true
-- L["Time to hold the message in seconds"] = true
-- L["Fade time"] = true
-- L["Fade time of the message in seconds"] = true
-- L["Ready time"] = true
-- L["Show the cooldown again this many seconds before the cooldown expires"] = true
L["Font"] = "字体"
L["Default"] = "默认"
L["Font size"] = "字号"
L["Font outline"] = "字型"
L["None"] = "无"
L["Normal"] = "正常"
L["Thick"] = "加粗"
L["Color"] = "颜色"
L["%s loaded. Type /cdtg for help"] = "%s已加载。输入 /cdtg 进行设置"
L["Strata"] = "层面"
L["Frame strata"] = "框架显示层面"
L["High"] = "最高层"
L["Medium"] = "中间层"
L["Low"] = "最低层"
-- L["Configure"] = true
-- L["Bring up GUI configure dialog"] = true

