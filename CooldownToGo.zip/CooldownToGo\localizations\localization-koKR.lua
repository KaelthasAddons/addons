local L = LibStub("AceLocale-3.0"):NewLocale("CooldownToGo", "koKR", false)
if not L then return end
		
L["Locked"] = "잠금"
L["Lock/Unlock display frame"] = "표시 창을 고정시키거나 이동시킵니다."
-- L["Hold time"] = true
-- L["Time to hold the message in seconds"] = true
-- L["Fade time"] = true
-- L["Fade time of the message in seconds"] = true
-- L["Ready time"] = true
-- L["Show the cooldown again this many seconds before the cooldown expires"] = true
L["Font"] = "글꼴"
L["Default"] = "기본값"
L["Font size"] = "글꼴 크기"
L["Font outline"] = "글꼴 윤각"
L["None"] = "없음"
L["Normal"] = "보통"
L["Thick"] = "굵게"
L["Color"] = "색상"
L["%s loaded. Type /cdtg for help"] = "%s 불려옵니다. 도움말을 보실려면 /cdtg 를 입력하세요."
L["Strata"] = "우선순위"
L["Frame strata"] = "창 우선순위"
L["High"] = "높음"
L["Medium"] = "중간"
L["Low"] = "낮음"
-- L["Configure"] = true
-- L["Bring up GUI configure dialog"] = true

