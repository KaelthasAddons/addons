local L = LibStub("AceLocale-3.0"):NewLocale("CooldownToGo", "frFR", false)
if not L then return end
		
-- frFR by |Pixel|
L["Locked"] = "Vérouillé"
L["Lock/Unlock display frame"] = "(Dé)Vérouille la fenêtre"
-- L["Hold time"] = true
-- L["Time to hold the message in seconds"] = true
-- L["Fade time"] = true
-- L["Fade time of the message in seconds"] = true
-- L["Ready time"] = true
-- L["Show the cooldown again this many seconds before the cooldown expires"] = true
L["Font"] = "Police"
L["Default"] = "Défaut"
L["Font size"] = "Taille de police"
L["Font outline"] = "Epaisseur de police"
L["None"] = "Aucun"
L["Normal"] = "Normal"
L["Thick"] = "Epais"
L["Color"] = "Couleur"
L["%s loaded. Type /cdtg for help"] = "%s chargé. Tapez /cdtg pour obtenir de l'aide"
L["Strata"] = "Profondeur"
L["Frame strata"] = "Profondeur de la fenêtre"
L["High"] = "Au dessus"
L["Medium"] = "Normal"
L["Low"] = "En dessous"
-- L["Configure"] = true
-- L["Bring up GUI configure dialog"] = true

