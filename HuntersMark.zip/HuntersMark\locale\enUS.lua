local L = LibStub("AceLocale-3.0"):NewLocale("HuntersMark", "enUS", true)

L["FULLSTRENGTH_MESSAGE"] = "Hunter's Mark on %s is now full strength!"