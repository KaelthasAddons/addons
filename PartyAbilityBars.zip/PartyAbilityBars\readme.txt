PartyAbilityBars backport for patch 2.4.3 by Schaka
Thanks to Kollektiv for doing the initial work

Added:
- race functionality
- spells from CombatLog