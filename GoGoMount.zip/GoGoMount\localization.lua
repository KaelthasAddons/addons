﻿BINDING_HEADER_GOGOHEADER = "GoGoMount"
BINDING_NAME_GOGOBINDING = "Mount/Dismount"
BINDING_NAME_GOGOBINDING2 = "Mount/Dismount (no flying)"

if GetLocale() == "frFR" then

	GOGO_TWISTING_NETHER = "Le N\195\169ant distordu"

	GOGO_PALADIN_FAST = "Invocation de destrier"
	GOGO_PALADIN_SLOW = "Invocation d'un cheval de guerre"

	GOGO_WARLOCK_FAST = "Invocation d'un destrier de l'effroi"
	GOGO_WARLOCK_SLOW = "Invocation d'un palefroi corrompu"

	GOGO_DRUID_AQUAFORM = "Forme aquatique"
	GOGO_DRUID_TRAVELFORM = "Forme du voyage"
	GOGO_DRUID_FLIGHTFORM = "Forme de vol"
	GOGO_DRUID_FAST_FLIGHTFORM = "Forme de vol rapide"

	GOGO_SHAMAN_GHOSTWOLF = "Loup fant\195\180me"
	
elseif GetLocale() == "deDE" then

	GOGO_TWISTING_NETHER = "Wirbelnder Nether"

	GOGO_PALADIN_FAST = "Streitross beschw\195\182ren"
	GOGO_PALADIN_SLOW = "Schlachtross beschw\195\182ren"

	GOGO_WARLOCK_FAST = "Schreckensross herbeirufen"
	GOGO_WARLOCK_SLOW = "Teufelsross beschw\195\182ren"

	GOGO_DRUID_AQUAFORM = "Wassergestalt"
	GOGO_DRUID_TRAVELFORM = "Reisegestalt"
	GOGO_DRUID_FLIGHTFORM = "Fluggestalt"
	GOGO_DRUID_FAST_FLIGHTFORM = "Schnelle Fluggestalt"

	GOGO_SHAMAN_GHOSTWOLF = "Geisterwolf"

elseif GetLocale() == "esES" then

	GOGO_TWISTING_NETHER = "El Vac\195\173o Abisal"

	GOGO_PALADIN_FAST = "Invocar a gara\195\177\195\179n"
	GOGO_PALADIN_SLOW = "Invocar a caballo de guerra"

	GOGO_WARLOCK_FAST = "Invocar a corcel nefasto"
	GOGO_WARLOCK_SLOW = "Invocar a corcel vil"

	GOGO_DRUID_AQUAFORM = "Forma acu\195\161tica"
	GOGO_DRUID_TRAVELFORM = "Forma de viaje"
	GOGO_DRUID_FLIGHTFORM = "Forma voladora"
	GOGO_DRUID_FAST_FLIGHTFORM = "Forma de Vuelo presto"

	GOGO_SHAMAN_GHOSTWOLF = "Lobo fantasmal"

elseif GetLocale() == "koKR" then

	GOGO_TWISTING_NETHER = "뒤틀린 황천"

	GOGO_PALADIN_FAST = "군마 소환"
	GOGO_PALADIN_SLOW = "군마 소환"

	GOGO_WARLOCK_FAST = "공포마 소환"
	GOGO_WARLOCK_SLOW = "지옥마 소환"

	GOGO_DRUID_AQUAFORM = "바다표범 변신"
	GOGO_DRUID_TRAVELFORM = "치타 변신"
	GOGO_DRUID_FLIGHTFORM = "폭풍까마귀 변신"
	GOGO_DRUID_FAST_FLIGHTFORM = "빠른 폭풍까마귀 변신"

	GOGO_SHAMAN_GHOSTWOLF = "늑대 정령"

	BINDING_NAME_GOGOBINDING = "타기/내리기"
	BINDING_NAME_GOGOBINDING2 = "타기/내리기 (비행중이 아닐때)"

elseif GetLocale() == "zhCN" then

	GOGO_TWISTING_NETHER = "Twisting Nether"  -- to be translated still

	GOGO_PALADIN_FAST = "召唤战马"
	GOGO_PALADIN_SLOW = "召唤军马"

	GOGO_WARLOCK_FAST = "召唤恐惧战马"
	GOGO_WARLOCK_SLOW = "召唤地狱战马"

	GOGO_DRUID_AQUAFORM = "水栖形态"
	GOGO_DRUID_TRAVELFORM = "旅行形态"
	GOGO_DRUID_FLIGHTFORM = "飞行形态"
	GOGO_DRUID_FAST_FLIGHTFORM = "迅捷飞行形态"

	GOGO_SHAMAN_GHOSTWOLF = "幽魂之狼"

elseif GetLocale() == "esMX" then

	GOGO_TWISTING_NETHER = "El Vac\195\173o Abisal"

	GOGO_PALADIN_FAST = "Invocar a gara\195\177\195\179n"
	GOGO_PALADIN_SLOW = "Invocar a caballo de guerra"

	GOGO_WARLOCK_FAST = "Invocar a corcel nefasto"
	GOGO_WARLOCK_SLOW = "Invocar a corcel vil"

	GOGO_DRUID_AQUAFORM = "Forma acu\195\161tica"
	GOGO_DRUID_TRAVELFORM = "Forma de viaje"
	GOGO_DRUID_FLIGHTFORM = "Forma voladora"
	GOGO_DRUID_FAST_FLIGHTFORM = "Forma de Vuelo presto"

	GOGO_SHAMAN_GHOSTWOLF = "Lobo fantasmal"

elseif GetLocale() == "zhTW" then

	GOGO_TWISTING_NETHER = "扭曲虛空"

	GOGO_PALADIN_FAST = "召喚戰馬"
	GOGO_PALADIN_SLOW = "召喚戰馬"

	GOGO_WARLOCK_FAST = "召喚恐懼戰馬"
	GOGO_WARLOCK_SLOW = "召喚地獄戰馬"

	GOGO_DRUID_AQUAFORM = "水棲形態"
	GOGO_DRUID_TRAVELFORM = "旅行形態"
	GOGO_DRUID_FLIGHTFORM = "飛行形態"
	GOGO_DRUID_FAST_FLIGHTFORM = "迅捷飛行形態"

	GOGO_SHAMAN_GHOSTWOLF = "幽魂之狼"

elseif GetLocale() == "enGB" then

	GOGO_TWISTING_NETHER = "Twisting Nether"

	GOGO_PALADIN_FAST = "Summon Charger"
	GOGO_PALADIN_SLOW = "Summon Warhorse"

	GOGO_WARLOCK_FAST = "Summon Dreadsteed"
	GOGO_WARLOCK_SLOW = "Summon Felsteed"

	GOGO_DRUID_AQUAFORM = "Aquatic Form"
	GOGO_DRUID_TRAVELFORM = "Travel Form"
	GOGO_DRUID_FLIGHTFORM = "Flight Form"
	GOGO_DRUID_FAST_FLIGHTFORM = "Swift Flight Form"

	GOGO_SHAMAN_GHOSTWOLF = "Ghost Wolf"

elseif GetLocale() == "ruRU" then

	GOGO_TWISTING_NETHER = "Круговерть Пустоты"

	GOGO_PALADIN_FAST = "Призыв скакуна"
	GOGO_PALADIN_SLOW = "Призыв боевого коня"

	GOGO_WARLOCK_FAST = "Призыв коня погибели"
	GOGO_WARLOCK_SLOW = "Призывание коня Скверны"

	GOGO_DRUID_AQUAFORM = "Водный облик"
	GOGO_DRUID_TRAVELFORM = "Походный облик"
	GOGO_DRUID_FLIGHTFORM = "Воздушный облик"
	GOGO_DRUID_FAST_FLIGHTFORM = "Быстрый воздушный облик"

	GOGO_SHAMAN_GHOSTWOLF = "Призрачный волк"

else  -- default to enUS

	GOGO_TWISTING_NETHER = "Twisting Nether"

	GOGO_PALADIN_FAST = "Summon Charger"
	GOGO_PALADIN_SLOW = "Summon Warhorse"

	GOGO_WARLOCK_FAST = "Summon Dreadsteed"
	GOGO_WARLOCK_SLOW = "Summon Felsteed"

	GOGO_DRUID_AQUAFORM = "Aquatic Form"
	GOGO_DRUID_TRAVELFORM = "Travel Form"
	GOGO_DRUID_FLIGHTFORM = "Flight Form"
	GOGO_DRUID_FAST_FLIGHTFORM = "Swift Flight Form"

	GOGO_SHAMAN_GHOSTWOLF = "Ghost Wolf"

end --if