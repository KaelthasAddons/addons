
function Skinner:TitanExitGame()

	self:applySkin(LogoutFrame, true)

end
