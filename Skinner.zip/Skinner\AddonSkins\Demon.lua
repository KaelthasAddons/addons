
function Skinner:Demon()

	self:applySkin(DemonFrame)

end
