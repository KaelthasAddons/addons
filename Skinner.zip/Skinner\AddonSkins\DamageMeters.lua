
function Skinner:DamageMeters()

	self:applySkin(DamageMetersFrame_TitleButton)
	self:applySkin(DamageMetersFrame)

end
