
function Skinner:SellJunk()

	self:moveObject(SellJunk_SellJunkButton, "+", 12, "+", 35)

end
