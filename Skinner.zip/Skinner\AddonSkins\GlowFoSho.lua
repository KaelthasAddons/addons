
function Skinner:GlowFoSho()

	self:moveObject(GlowFoSho_Button, "+", 31, "+", 15)

end
