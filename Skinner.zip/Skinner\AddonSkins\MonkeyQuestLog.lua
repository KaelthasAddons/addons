
function Skinner:MonkeyQuestLog()

	self:applySkin(MkQL_Main_Frame)

end
