
function Skinner:ConcessionStand()

	self:moveObject(ConcessionStandFrame, "+", 20, "+", 10)
	self:applySkin(ConcessionStandFrame)

end
