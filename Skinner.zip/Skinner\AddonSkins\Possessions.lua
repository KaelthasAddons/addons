
function Skinner:Possessions()

	self:removeRegions(Possessions_IC_ScrollFrame)
	self:skinScrollBar(Possessions_IC_ScrollFrame)
	self:applySkin(Possessions_Frame)

end
