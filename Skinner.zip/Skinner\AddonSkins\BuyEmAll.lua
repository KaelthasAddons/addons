
function Skinner:BuyEmAll()

	self:keepRegions(BuyEmAllFrame, {5})
	self:applySkin(BuyEmAllFrame, nil)

end
