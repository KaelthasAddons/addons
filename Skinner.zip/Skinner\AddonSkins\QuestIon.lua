
function Skinner:QuestIon()

	self:keepFontStrings(QuestIon_Frame)
	self:applySkin(QuestIon_Frame)

end
