Cartographer3_L("Main", "esES", function() return {
	-- ["English"] = "Localized",
} end)
