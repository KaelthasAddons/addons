Cartographer3_L("Main", "ruRU", function() return {
	-- ["English"] = "Localized",
} end)
