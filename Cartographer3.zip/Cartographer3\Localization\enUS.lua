Cartographer3_L("Main", "enUS", function() return {
	["Player:"] = "Player:",
	["Party:"] = "Party:",
	["Raid:"] = "Raid:",
	["Class:"] = "Class:",
	["Level:"] = "Level:",
	["Race:"] = "Race:",
	["Guild:"] = "Guild:",
	["Rank:"] = "Rank:",
	
	["Cities"] = "Cities",
	["Zones"] = "Zones",
	
	["Group_acronym"] = "G",
} end)
