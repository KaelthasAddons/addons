Cartographer3_L("Main", "deDE", function() return {
	-- ["English"] = "Localized",
} end)
