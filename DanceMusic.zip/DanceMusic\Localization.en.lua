-------------------------------------------------------------------------------
-- English localization (Default)
-------------------------------------------------------------------------------

DANCEMUSIC_ENABLED = "DanceMusic is enabled"
DANCEMUSIC_DISABLED = "DanceMusic is disabled"

DANCEMUSIC_DEBUG_ENABLED = "DanceMusic debug messages are enabled"
DANCEMUSIC_DEBUG_DISABLED = "DanceMusic debug messages are disabled"

DANCEMUSIC_HELP =  --\n = enter
  "DanceMusic commands:\n"..
  " on - Enables DanceMusic\n"..
  " off - Disables DanceMusic\n"..
  " debug - Toggles debug messages on/off"
