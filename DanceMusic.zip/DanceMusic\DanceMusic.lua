--[[
This addon for WoW will play a music file when you start to dance. The music files have to 
be placed in the "Music" folder of the addon. The file that is played has to be 
named "<race><gender>.mp3". So for the song to play for human males the filename 
would be "HumanMale.mp3"
]]--

-- Save variables, these will get overwritten during load time with the stored value
DanceMusicEnabled = true;

local DanceMusicDebug = false;     -- Display debug messages when true
local DanceMusicPlaying = false;   -- When true a song is playing that was started by DanceMusic
local DanceMusicDefaultSongname = '';

-- Constants
local genders = { "Unknown", "Male", "Female" };

-- Prints messages in debug mode
function DanceMusic_Debug(msg)
  if DanceMusicDebug then
    DEFAULT_CHAT_FRAME:AddMessage(msg);
  end;
end

-- Slash command handler
function DanceMusic_SlashCommandHandler(command)
	if (command == "on") then
		DanceMusicEnabled = true;
		DEFAULT_CHAT_FRAME:AddMessage(DANCEMUSIC_ENABLED);
	elseif (command == "off") then
		DanceMusicEnabled = false;
		DEFAULT_CHAT_FRAME:AddMessage(DANCEMUSIC_DISABLED);
	elseif (command == "debug") then
		if (DanceMusicDebug == false) then
			DanceMusicDebug = true;
			DEFAULT_CHAT_FRAME:AddMessage(DANCEMUSIC_DEBUG_ENABLED);
		else
			DEFAULT_CHAT_FRAME:AddMessage(DANCEMUSIC_DEBUG_DISABLED);
			DanceMusicDebug = false;
		end;
	else
		-- Print current status and help message
		if (DanceMusicEnabled) then
			DEFAULT_CHAT_FRAME:AddMessage(DANCEMUSIC_ENABLED);
		else
			DEFAULT_CHAT_FRAME:AddMessage(DANCEMUSIC_DISABLED);
		end;

		DEFAULT_CHAT_FRAME:AddMessage(DANCEMUSIC_HELP);
end;
	end;

function DanceMusic_OnLoad()
	-- Register the slash command
	SlashCmdList["DanceMusic"] = DanceMusic_SlashCommandHandler;
	SLASH_DanceMusic1 = "/dancemusic";

	-- Hook into the DoEmote function to see if we start dancing
	hooksecurefunc("DoEmote", DanceMusic_DoEmote);

	-- Dance stops when moving, so hook relevant movement functions to stop the music. 
	hooksecurefunc("MoveForwardStart" , DanceMusic_StopMusic);
	hooksecurefunc("MoveBackwardStart", DanceMusic_StopMusic);
	hooksecurefunc("StrafeLeftStart"  , DanceMusic_StopMusic);
	hooksecurefunc("StrafeRightStart" , DanceMusic_StopMusic);
	hooksecurefunc("JumpOrAscendStart", DanceMusic_StopMusic);
	hooksecurefunc("ToggleAutoRun"    , DanceMusic_StopMusic);

	-- Determine the default songname based on player gender and race
	local _, race = UnitRace("player");

	-- Undead are called Scourge, fix it to Undead (I like it better that way)
	if (race=='Scourge') then
		race = 'Undead';
	end;

	-- Combine it all
	DanceMusicDefaultSongname = race..genders[UnitSex("player")]..'.mp3';


	DanceMusic_Debug('DanceMusic_OnLoad');
end

function DanceMusic_DoEmote(emote, msg)
	DanceMusic_Debug('DanceMusic_DoEmote '..emote);

	--emote is DANCE when "/dance" is used.
	if (DanceMusicEnabled and emote=="DANCE") then
		-- Play the song if it is not already playing
		if (DanceMusicPlaying==false) then
			DanceMusic_Debug('Start song: '..DanceMusicDefaultSongname);
			PlayMusic('Interface\\AddOns\\DanceMusic\\Music\\'..DanceMusicDefaultSongname);


			DanceMusicPlaying = true;
		else
			DanceMusic_Debug('Song is already playing');
		end
	end;
end

-- Stop the music
function DanceMusic_StopMusic()
	--DanceMusic_Debug('Stop song when playing');

	-- Only stop the music when DanceMusic was playing
	if (DanceMusicPlaying) then
		StopMusic();
		DanceMusicPlaying = false;
		
		DanceMusic_Debug('Song is stopped');
	end;
end;
