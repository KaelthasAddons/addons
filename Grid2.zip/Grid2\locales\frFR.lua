local L =  LibStub:GetLibrary("AceLocale-3.0"):NewLocale("Grid2", "frFR")
if not L then return end

L["(%d+) yd range"] = "portée de (%d+) m."

L["Beast"] = "Bête"
L["Demon"] = "Démon"
L["Humanoid"] = "Humanoïde"
L["Elemental"] = "Elementaire"
