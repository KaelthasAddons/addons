local MAJOR_VERSION = "LibDogTag-Items-3.0"
local MINOR_VERSION = 90000 + tonumber(("$Revision: 10 $"):match("%d+")) or 0

_G.DogTag_Items_MINOR_VERSION = MINOR_VERSION

_G.DogTag_Items_funcs = {}

DogTag_Items_funcs[#DogTag_Items_funcs+1] = function(DogTag_Items, DogTag)

DogTag_Items.L =
{
	["Items"] = "Items",
	["Return count of specified item in your bags"] = "Return count of specified item in your bags",
}

for k,v in pairs(DogTag_Items.L) do
	if type(v) ~= "string" then -- some evil addon messed it up
		DogTag_Items.L[k] = k
	end
end

setmetatable(DogTag_Items.L, {__index = function(self, key)
	self[key] = key
	return key
end})

end