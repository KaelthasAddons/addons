﻿local MAJOR_VERSION = "LibDogTag-Items-3.0"
local MINOR_VERSION = 90000 + tonumber(("$Revision: 10 $"):match("%d+")) or 0

if MINOR_VERSION > _G.DogTag_Items_MINOR_VERSION then
	_G.DogTag_Items_MINOR_VERSION = MINOR_VERSION
end

if GetLocale() == "ruRU" then

DogTag_Items_funcs[#DogTag_Items_funcs+1] = function(DogTag_Items, DogTag)
	local L = DogTag_Items.L

	L["Items"] = "Предметы"
	L["Return count of specified item in your bags"] = "Возвращает количество указанных предметов в ваших сумках"
end

end