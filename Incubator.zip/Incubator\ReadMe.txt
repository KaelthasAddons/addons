Incubator ReadMe!

I'm putting this together because I've been getting a number of 'bug' reports that have actually been people not understanding the way that Incubator is supposed to work ;)

Not that there aren't bugs or things that need to be fixed, of course.

Currently dewdrop still needs to be implemented, so you'll need to either type out all the slash commands by hand, or run DeuceCommander or Niagra.

The first time you load Incubator, you should get an anchor in the middle of your screen to position somewhere for bars showing up. You can drag the anchor wherever, and alt or shift click on it to hide and lock the anchor, or show a test bar.

If you want to unlock or lock the anchor manually, use /inc baroptions locked to toggle it.


While Incubator tracks a lot of trash, it doesn't (by default) show you bars for everything that it's tracking! There are three options to control how and when bars are displayed:

- maxshowtime (Defaults to 60)
Bars will not show on screen until a particular respawn timer is LESS then this time in minutes. The idea here is that you may not want to see a bar on screen for two hours or more at a time. I run with mine set to 30 minutes. Setting this to 0 disables checking maxshowtime and will try to show all bars (so long as timbetween and barcount allow the bar to display).

- timebetween (Defaults to 1)
Bars will not show on screen if they are closer together then this value in minutes. This is useful for throttling a lot of bars on screen at once. If you have it set to 15 minutes, and you have trash times of 30, 32, 36, 40, 48, 55 with maxshowtime set to 60, then you'll see a bar for the 30 minute and 48 minute respawns. The 32/36/40/55 minute respawns will show up as the other timers expire. Setting this to 0 disables checking how close together respawns might be.

- barcount (Defaults to 5)
Incubator will not display more then this number of bars at one time. Setting this to 0 will allow an unlimited number of bars to be displayed at once.

Currently Incubator checks to start a bar when you go out of combat -- the one catch to this is that if you die during a particular pull and are not raised until afterwards, a bar won't get started for that particular pull. I'm working on a better method of handling this, but that's a limitation until I get that finished.

If you're not sure if incubator is tracking a particular pull and just not kicking up a bar for it, or missed it entirely - use /inc list to list all running timers in chat.

When bars are running, you can ctrl + left click on a bar to broadcast the time to your party/raid, or shift click on a bar to kill that timer.