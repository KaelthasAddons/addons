local L =  LibStub("AceLocale-3.0"):NewLocale("BagSlots", "enUS", true)
if not L then return end

-- Mod title and description
L["BagSlots"] = true
L["Display bag usage on each of your bag slots."] = true
-- Depletion
L["Show Depletion"] = true
L["Show depletion of bag slots."] = true
-- Total
L["Show Total"] = true
L["Show total slots per bag."] = true
-- Text Positioning
L["Text Position"] = true
L["Change the position of the usage text on the bags."] = true
L["Bottom"] = true
L["Top"] = true
