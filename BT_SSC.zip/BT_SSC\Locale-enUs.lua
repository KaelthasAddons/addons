local L = LibStub("AceLocale-3.0"):NewLocale("BT_SSC", "enUS", true)
if not L then return end

--infos
L["Module resetted"] = "Module resetted" --dont change this line!

L["info"] = "|cff91069ETactics by|r rpguides\n|cff91069EImages by|r Vonswan, rpguides\n|cff91069EModule by|r Sorontur\n\n|cffC0C0C0[http://www.kdh-wow.de]\n[http://www.rpguides.de]|r"

--add here localized tactic texts

L["tactic Hydross"] = [[

not yet available

]]

L["tactic Lurker"] =  [[

not yet available

]]

L["tactic Leotheras"] =  [[

not yet available

]]

L["tactic Karathress"] =  [[

not yet available

]]

L["tactic Morogrim"] =  [[

not yet available

]]

L["tactic Vashj"] =  [[

not yet available

]]

--texts for trash

L["trash Hydross"] = [[

not yet available

]]

L["trash Lurker"] =  [[

not yet available

]]
L["trash Leotheras"] =  [[

not yet available

]]
L["trash Karathress"] =  [[

not yet available

]]
L["trash Morogrim"] =  [[

not yet available

]]



--ra text messages every line separated by \n
L["ra Hydross"] = ""
L["ra Lurker"] = ""
L["ra Leotheras"] =  ""
L["ra Karathress"] =  ""
L["ra Morogrim"] =  ""

--button captions
L["Natureresi Tank"] = true
L["Frostresi Tank"] = true
L["Hydross frost form"] = true
L["Hydross nature form"] = true
L["Add Tank"] = true
L["warlock tank"] = true
L["Pet"] = true
L["Fathom-Guard Tidalvess"] = true
L["Fathom-Guard Sharkkis"] = true
L["Fathom-Guard Tidalvess"] = true

L["Phase 1"] = true
L["Phase 2"] = true
L["Phase 3"] = true
L["Phase 1 & 3"] = true

L["Murloc-Tank"] = true
L["Raid"] = true