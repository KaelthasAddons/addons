local L = LibStub("AceLocale-3.0"):NewLocale("GatherMate_Sharing","zhTW")
if not L then return end
