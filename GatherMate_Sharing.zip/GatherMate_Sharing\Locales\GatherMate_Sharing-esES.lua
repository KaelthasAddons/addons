local L = LibStub("AceLocale-3.0"):NewLocale("GatherMate_Sharing","esES")
if not L then return end
