﻿AceLibrary("AceLocale-2.2"):new("SacredBuff"):RegisterTranslations("frFR", function()
	return {
		
		-- BINDINGS
		["SacredBuff"] = "SacredBuff",
	--	["Mount"] = "Monture",
		
		-- MENU
		["Lock"] = "Verrouillage",
		["(Un)Lock the SacredBuff frame."] = "(D\195\169)verrouiller SacredBuff.",
		["On"] = "On",
		["Off"] = "Off",
		
		["Scale"] = "Echelle",
		["Set the frame's scale."] = "Dimensionner l'\195\169chelle de la fen\195\170tre.",
		
		["Tooltip"] = "Info-bulle",
		["Tooltip Options"] = "Options des info-bulles",
		["Select what information the tooltip provides."] = "S\195\169lectionne le type d'information affich\195\169 sur l'info-bulle.",
		
		["None"] = "Aucune",
		["No Tooltip"] = "Pas d'info-bulle",
		["No tooltip will be displayed over the spell icons."] = "Aucune info-bulle ne sera affich\195\169e sur les ic\195\180nes des sorts.",
		["Tooltips turned off."] = "Info-bulles arr\195\170t\195\169es.",
		
		["Mana Only"] = "Mana uniquement",
		["Only the mana cost of the spell will be displayed in its tooltip."] = "Seul le co\195\187t en mana du sort sera affich\195\169 dans l'info-bulle.",
		["Tooltips will now display the spell's mana cost."] = "Les info-bulles afficheront d\195\169sormais le co\195\187t en mana du sort.",
		
		["Full"] = "Compl\195\168te",
		["Full Tooltip"] = "Info-bulle compl\195\168te",
		["The spell's full tooltip will be displayed on mouseover."] = "L'info-bulle sera affich\195\169e avec un descriptif complet des sorts au passage de la souris.",
		["Full spell tooltips will now be displayed."] = "Les info-bulles seront d\195\169sormais affich\195\169es avec un descriptif complet des sorts.",
		
	--	["Riding"] = "Monte",
		
		["Increases speed by"] = "Augmente la vitesse par",
		
		["You are not a Priest."] = "Vous n'\195\170tes pas un Pr\195\170tre.",
		["This addon has been disabled."] = "Cet addon a \195\169t\195\169 arr\195\170t\195\169.",
		
		["Ahn'Qiraj"] = "Ahn'Qiraj",
		
		["There is no mount in your inventory."] = "Il n'y a pas de monture dans votre inventaire.",
		["Select your preferred mount."] = "S\195\169lectionnez votre monture pr\195\169f\195\169r\195\169e.",
		
		["There is no Hearthstone in your inventory."] = "Il n'y a pas de pierre de foyer dans votre inventaire.",
		
		-- SACREDBUFF MOUNTS
		['Twisting Nether'] = 'Le N\195\169ant distordu',
		
	}
end)