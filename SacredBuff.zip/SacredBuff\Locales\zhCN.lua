﻿AceLibrary("AceLocale-2.2"):new("SacredBuff"):RegisterTranslations("zhCN", function()
	return {
		
		-- BINDINGS
		["SacredBuff"] = "SacredBuff",
	--	["Mount"] = "坐骑",
		
		-- MENU
		["Lock"] = "锁定",
		["(Un)Lock the SacredBuff frame."] = "锁定/解锁 SacredBuff 框体.",
		["On"] = "打开",
		["Off"] = "关闭",
		
		["Scale"] = "缩放",
		["Set the frame's scale."] = "设置框体缩放比例.",
		
		["Tooltip"] = "提示",
		["Tooltip Options"] = "提示设置",
		["Select what information the tooltip provides."] = "选择提示所提供的信息.",
		
		["None"] = "无",
		["No Tooltip"] = "无提示",
		["No tooltip will be displayed over the spell icons."] = "法术图标上将不会显示提示.",
		["Tooltips turned off."] = "提示关闭.",
		
		["Mana Only"] = "仅法力",
		["Only the mana cost of the spell will be displayed in its tooltip."] = "法术图标上仅显示法力消耗.",
		["Tooltips will now display the spell's mana cost."] = "提示现在将会显示法术的法力消耗.",
		
		["Full"] = "全部",
		["Full Tooltip"] = "全部提示",
		["The spell's full tooltip will be displayed on mouseover."] = "法术图标上将显示全部提示.",
		["Full spell tooltips will now be displayed."] = "全部法术提示将会显示.",
		
	--	["Riding"] = "Riding",
		
		["Increases speed by"] = "提升速度的坐骑:",
		
		["You are not a Priest."] = "你不是牧师.",
		["This addon has been disabled."] = "此插件已经禁止.",
		
		["Ahn'Qiraj"] = "安其拉",
		
		["There is no mount in your inventory."] = "你的包裹中没有坐骑.",
		["Select your preferred mount."] = "选择你想使用的坐骑.",
		
		["There is no Hearthstone in your inventory."] = "你的包裹中没有炉石.",
		
		-- SACREDBUFF MOUNTS
		['Twisting Nether'] = 'Twisting Nether',
		
	}
end)