﻿AceLibrary("AceLocale-2.2"):new("SacredBuff"):RegisterTranslations("zhTW", function()
	return {
		
		-- BINDINGS
		["SacredBuff"] = "SacredBuff",
	--	["Mount"] = "坐騎",
		
		-- MENU
		["Lock"] = "鎖定",
		["(Un)Lock the SacredBuff frame."] = "鎖定/解鎖 SacredBuff 框體.",
		["On"] = "打開",
		["Off"] = "關閉",
		
		["Scale"] = "縮放",
		["Set the frame's scale."] = "設置框體縮放比例.",
		
		["Tooltip"] = "提示",
		["Tooltip Options"] = "提示設置",
		["Select what information the tooltip provides."] = "選擇提示所提供的信息.",
		
		["None"] = "無",
		["No Tooltip"] = "無提示",
		["No tooltip will be displayed over the spell icons."] = "法術圖標上將不會顯示提示.",
		["Tooltips turned off."] = "提示關閉.",
		
		["Mana Only"] = "僅法力",
		["Only the mana cost of the spell will be displayed in its tooltip."] = "法術圖標上僅顯示法力消耗.",
		["Tooltips will now display the spell's mana cost."] = "提示現在將會顯示法術的法力消耗.",
		
		["Full"] = "全部",
		["Full Tooltip"] = "全部提示",
		["The spell's full tooltip will be displayed on mouseover."] = "法術圖標上將顯示全部提示.",
		["Full spell tooltips will now be displayed."] = "全部法術提示將會顯示.",
		
	--	["Riding"] = "Riding",
		
		["Increases speed by"] = "提升速度的坐騎:",
		
		["You are not a Priest."] = "你不是牧師.",
		["This addon has been disabled."] = "此插件已經禁止.",
		
		["Ahn'Qiraj"] = "安其拉",
		
		["There is no mount in your inventory."] = "你的包裹中沒有坐騎.",
		["Select your preferred mount."] = "選擇你想使用的坐騎.",
		
		["There is no Hearthstone in your inventory."] = "你的包裹中沒有爐石.",
		
		-- SACREDBUFF MOUNTS
		['Twisting Nether'] = 'Twisting Nether',
		
	}
end)