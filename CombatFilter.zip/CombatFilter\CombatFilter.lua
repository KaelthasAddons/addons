local CF = LibStub("AceAddon-3.0"):NewAddon("CombatFilter", "AceConsole-3.0", "AceEvent-3.0")
CombatFilter = CF

local string_lower = string.lower

local defaults = {
	profile = {
		filters = {
			['**'] = {
				enabled = true,
				output = "ChatFrame3",
				events = {
					['*'] = false
				},
				settings = CopyTable(COMBATLOG_DEFAULT_SETTINGS),
				colors = CopyTable(COMBATLOG_DEFAULT_COLORS),
				flags = {
					src = {
						['*'] = false,
					},
					dst = {
						['*'] = false,
					},
					mode = "OR",
				},
			},
		}
	}
}

local CheckFilter

function CF:OnInitialize()
	self.db = LibStub("AceDB-3.0"):New("CombatFilterDB", defaults)
	self:CreateOptionsGUI()
end

function CF:OnEnable()
	if not self.updateFrame then
		self.updateFrame = CreateFrame("Frame", nil, UIParent)
		self.updateFrame:Show()
	end
	self:GenerateFilters()
	self:ApplyFilter()
	self:RegisterEvent("COMBAT_LOG_EVENT_UNFILTERED", "ParseEvent")
end

function CF:DeleteFilter(filter_id)
	tremove(self.db.profile.filters, filter_id)
	self:GenerateFilters()
	self:GenerateFilterOptions()
end

function CF:ParseEvent(event, ...)
	if not self.filters then return end
	for k, v in pairs(self.filters) do
		-- query the filter if the event is valid for this one
		if not v.refiltering and CheckFilter(v, ...) then
			v.output:AddMessage(CombatLog_OnEvent(v.settings, ...))
		end
	end
end

-- defined later
local CombatFilter_OnUpdateFilter

local updateFilters = {}
function CF:ApplyFilter(index, framesToUpdate)
	if self.updateFrame.filtering then
		self:Print("There is currently a re-filtering active on another filter/frame, please wait before running a new one.")
		return
	end
	
	framesToUpdate = framesToUpdate or {}
	local count = CombatLogGetNumEntries(true)
	-- refresh a specific filter
	if type(index) == "number" then
		-- refresh all filters on the frame our filter is on
		
		local filter = self.filters[index]
		if not filter then 
			-- probably disabled filter
			local data = self.db.profile.filters[index]
			if not data then return end
			framesToUpdate[(_G[data.output] or ChatFrame3)] = true
		else
			framesToUpdate[filter.output] = true
		end
		
		-- add all filters on our frame to the update batch
		for k,v in pairs(self.filters) do
			if framesToUpdate[v.output] then
				tinsert(updateFilters, v)
				v.refiltering = true
			end
		end
	else
		-- no specific filter supplied, update all filters
		for k,v in pairs(self.filters) do
			tinsert(updateFilters, v)
			v.refiltering = true
			framesToUpdate[v.output] = true
		end
	end
	
	for frame in pairs(framesToUpdate) do
		if count > frame:GetMaxLines() then
			frame:SetMaxLines(count)
		end
		-- and clear it
		frame:Clear()
		framesToUpdate[frame] = nil
	end
	
	-- reset log to first entry
	CombatLogSetCurrentEntry(1, true)
	
	-- start the OnUpdate handler
	self.updateFrame.filtering = true
	self.updateFrame:SetScript("OnUpdate", CombatFilter_OnUpdateFilter)
	
	-- and run it once this frame
	CombatFilter_OnUpdateFilter()
end

function CombatFilter_OnUpdateFilter()
	-- do we actually have a valid log?
	local valid = CombatLogGetCurrentEntry(true)
	local total = 0
	
	-- walk through our current log
	while (valid and total < COMBATLOG_LIMIT_PER_FRAME) do 
		-- process all filters that are in the process of being updated
		for k,v in pairs(updateFilters) do
			-- is the message valid?
			if CheckFilter(v, CombatLogGetCurrentEntry(true)) then
				-- add it and increment our counter
				v.output:AddMessage(CombatLog_OnEvent(v.settings, CombatLogGetCurrentEntry(true)) )
				total = total + 1
			end
		end
		-- count can be 
		--  positive to advance from oldest to newest
		--  negative to advance from newest to oldest
		valid = CombatLogAdvanceEntry(1, true)
	end
	
	-- if no longer valid then we reached the end of our schedule, reset the updateFilters thingy and stop the OnUpdate
	if not valid then
		for k,v in pairs(updateFilters) do
			v.refiltering = nil
			updateFilters[k] = nil
		end
		CF.updateFrame.filtering = false
		CF.updateFrame:SetScript("OnUpdate", nil)
	end
end

function CheckFilter(filter, timestamp, event, sGUID, sName, sFlags, dGUID, dName, dFlags)
	-- check if the event is included in the current filter
	if not filter.events[event] then return false end
	
		
	if filter.srcSpecific or filter.dstSpecific then
		local result = false
		
		local lsName = type(sName) == "string" and string_lower(sName)
		local ldName = type(dName) == "string" and string_lower(dName)
		
		if filter.srcSpecific and filter.dstSpecific then
			result = ((lsName == filter.srcSpecific) and (ldName == filter.dstSpecific))
		elseif filter.srcSpecific then
			result = (lsName == filter.srcSpecific)
		else
			result = (ldName == filter.dstSpecific)
		end
		
		return result
	end
	
	-- check the source flags
	local srcMatch = filter.srcflags and CombatLog_Object_IsA(sFlags, unpack(filter.srcflags))
	-- check the dest flags
	local dstMatch = filter.dstflags and CombatLog_Object_IsA(dFlags, unpack(filter.dstflags))
	
	if filter.srcflags and filter.dstflags then
		if ( filter.flagMode == "AND" and not (srcMatch and dstMatch) ) or
		   ( filter.flagMode == "OR" and not (srcMatch or dstMatch) ) then
			return false
		end
	elseif (filter.srcflags and not srcMatch) or (filter.dstflags and not dstMatch) then 
		return false 
	end
	
	return true
end
