local CF = LibStub("AceAddon-3.0"):GetAddon("CombatFilter")

local _G = _G
local string_gmatch = string.gmatch
local string_split = string.split
local bit_bor = bit.bor

-- map of our config keys to the actual game events
local EventMap = {
	melee_hit = "SWING_DAMAGE",
	melee_miss = "SWING_MISSED",
	range_hit = "RANGE_DAMAGE",
	range_miss = "RANGE_MISSED",
	spell_hit = { "SPELL_DAMAGE", "SPELL_DRAIN", "SPELL_LEECH" },
	spell_miss = "SPELL_MISSED",
	spell_heal = "SPELL_HEAL",
	spell_energize = { "SPELL_ENERGIZE", "SPELL_PERIODIC_ENERGIZE" },
	spell_extra = "SPELL_EXTRA_ATTACKS",
	spell_special = { "DAMAGE_SPLIT", "SPELL_DURABILITY_DAMAGE", "SPELL_DURABILITY_DAMAGE_ALL", "SPELL_SUMMON", "SPELL_CREATE" },
	periodic_hit = "SPELL_PERIODIC_DAMAGE",
	periodic_miss = "SPELL_PERIODIC_MISSED",
	periodic_heal = "SPELL_PERIODIC_HEAL",
	periodic_other = { "SPELL_PERIODIC_ENERGIZE",  "SPELL_PERIODIC_DRAIN", "SPELL_PERIODIC_LEECH" },
	casting_start = "SPELL_CAST_START",
	casting_success = "SPELL_CAST_SUCCESS",
	casting_failed = "SPELL_CAST_FAILED",
	casting_interrupt = "SPELL_INTERRUPT",
	aura_beneficial = { "SPELL_AURA_APPLIED", "SPELL_AURA_APPLIED_DOSE", "SPELL_AURA_REMOVED", "SPELL_AURA_REMOVED_DOSE" },
	aura_hostile = { "SPELL_AURA_APPLIED", "SPELL_AURA_APPLIED_DOSE", "SPELL_AURA_REMOVED", "SPELL_AURA_REMOVED_DOSE" },
	aura_dispel = { "SPELL_AURA_DISPELLED", "SPELL_AURA_STOLEN", "SPELL_DISPEL_FAILED" },
	aura_enchant = { },
	misc_shields = { "DAMAGE_SHIELD", "DAMAGE_SHIELD_MISSED" },
	misc_environment = "ENVIRONMENTAL_DAMAGE",
	misc_kills = { "PARTY_KILL", "UNIT_DESTROYED", "SPELL_INSTAKILL" },
	misc_death = { "UNIT_DIED" },
}
CF.EventMap = EventMap

-- map of the unit config keys to bit masks
local FlagMap = setmetatable({
	me = COMBATLOG_FILTER_MINE,
	pet = COMBATLOG_FILTER_MY_PET,
	friends = COMBATLOG_FILTER_FRIENDLY_UNITS,
	hostile = COMBATLOG_FILTER_HOSTILE_PLAYERS,
	npc = COMBATLOG_FILTER_HOSTILE_UNITS,
	neutral = COMBATLOG_FILTER_NEUTRAL_UNITS,
	unknown = COMBATLOG_FILTER_UNKNOWN_UNITS,
}, {__index = function(t, k) geterrorhandler()(("CombatFilter: Unknown unit filter key '%s'."):format(k)); return 0 end})
CF.FlagMap = FlagMap

-- helper function to enable the events in the dst table
local function setEvents(dst, data)
	if type(data) == "table" then
		for k,v in pairs(data) do
			dst[v] = true
		end
	elseif type(data) == "string" then
		dst[data] = true
	end
end

-- generate the filters table
function CF:GenerateFilters(index)
	-- if index was set then we only update one specific filter
	if index then
		-- grab filter data
		local data = self.db.profile.filters[index]
		if data then
			-- and replace the actual data
			self.filters[index] = data.enabled and self:GenerateSingleFilter(data) or nil
		else
			geterrorhandler()(("CombatFilter: Invalid filter id '%s'."):format(index))
		end
	else
		-- clear existing filters
		self.filters = {}
		
		-- generate new filters from DB
		for k, v in pairs(self.db.profile.filters) do
			if v.enabled then
				self.filters[k] = self:GenerateSingleFilter(v)
			end
		end
	end
end

function CF:GenerateSingleFilter(data)
	-- create new filter table
	local newFilter = { events = {} }
	newFilter.output = _G[data.output] or ChatFrame3
	
	-- parse the events
	local events = data.events
	for event, active in pairs(events) do
		-- take our event map and if activated call setEvents to set the flags on the table
		local data = EventMap[event]
		if data then
			if active then
				setEvents(newFilter.events, data)
			end
		else
			geterrorhandler()(("CombatFilter: Unknown event key '%s'."):format(event))
		end
	end
	
	-- hack for buff/debuff seperation
	data.settings.hideBuffs = not data.events.aura_beneficial
	data.settings.hideDebuffs = not data.events.aura_hostile
	
	-- process source unit filters
	local srcflags = {}
	for filter, state in pairs(data.flags.src) do
		-- if our filter is active then add it to our flags table
		if state and filter ~= "specific" then
			tinsert(srcflags, FlagMap[filter])
		end
	end
	newFilter.srcflags =  #srcflags > 0 and srcflags or nil
	
	if data.flags.src.specific and data.flags.src.specific ~= "" then
		newFilter.srcSpecific = string.lower(data.flags.src.specific)
	end
	
	-- process destination filters
	local dstflags = {}
	for filter, state in pairs(data.flags.dst) do
		-- if our filter is active then add it to our flags table
		if state and filter ~= "specific" then
			tinsert(dstflags, FlagMap[filter])
		end
	end
	newFilter.dstflags =  #dstflags > 0 and dstflags or nil
	
	newFilter.flagMode = data.flags.mode
	
	if data.flags.dst.specific and data.flags.dst.specific ~= "" then
		newFilter.dstSpecific = string.lower(data.flags.dst.specific)
	end
	
	-- add the format and color settings to the filter
	newFilter.settings = { settings = data.settings, colors = data.colors }
	
	return newFilter
end
