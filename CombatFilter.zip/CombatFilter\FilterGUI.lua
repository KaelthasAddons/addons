local CF = LibStub("AceAddon-3.0"):GetAddon("CombatFilter")

local string_split = string.split

local function colorize(text, r, g, b, a)
	if not a then a = 1 end
	local colorTag = ("|c%02x%02x%02x%02x"):format(a*255, r*255, g*255, b*255)
	text = text:gsub("|r", colorTag):gsub("|c", "|r|c")
	return (colorTag .. text .. "|r")
end

local function TblCpy(source, dest)
	if type(source) ~= "table" then return end
	if type(dest) ~= "table" then dest = {} end
	for k,v in pairs(source) do
		if type(v) == "table" then
			dest[k] = TblCpy(v)
		else
			dest[k] = v
		end
	end
	return dest
end


local filterHandler

local options, filterOptions
local newFilterName, newFilterCopyMode = false, 0
local function getOptions()
	if not options then
		options = {
			type = "group",
			name = "CombatFilter",
			args = {
				--general = {
				--	type = "group",
				--	name = "General Config",
				--	order = 10,
				--	args = {},
				--},
				add = {
					type = "group",
					name = "Add Filter",
					order = 20,
					args = {
						intro = {
							order = 1,
							type = "description",
							name = "Create a new filter by entering a name and navigating to the filter in the options tree.\n",
						},
						name = {
							order = 10,
							type = "input",
							name = "Filter Name",
							desc = "Enter the name of the new filter.",
							get = function() return newFilterName end,
							set = function(info, value)
								newFilterName = (value:trim() ~= "") and value or false
							end,
						},
						mode = {
							order = 11,
							type = "select",
							name = "Copy Filter",
							desc = "Select a filter (if any) to copy the settings from.",
							values = function() 
								local t = { [0] = "-- Empty Filter --" }
								for k,v in pairs(CF.db.profile.filters) do
									t[k] = v.name
								end
								return t
							end,
							get =  function() return newFilterCopyMode end,
							set = function(info, value)
								newFilterCopyMode = value
							end,
						},
						nl = {
							order = 15,
							type = "description",
							name = "",
						},
						create = {
							order = 20,
							type = "execute",
							name = "Create Filter",
							desc = "Create the new filter using the values specified above.",
							func = function()
								local filters = CF.db.profile.filters
								local newID = #filters+1
								local newFilter = filters[newID]
								
								if newFilterCopyMode ~= 0 then
									TblCpy(filters[newFilterCopyMode], newFilter)
								end
								newFilter.name = newFilterName
								
								newFilterName, newFilterCopyMode = false, 0
								
								CF:GenerateFilterOptions()
								CF:GenerateFilters(newID)
							end,
							disabled = function()
								return (type(newFilterName) ~= "string" or newFilterName:trim() == "")
							end,
						},
						desc = {
							order = 50,
							type = "description",
							name = "\nAfter creating the filter you should navigate to the filter configuration and start setting up the rules.",
						}
					},
				},
				filters = {
					type = "group",
					name = "Filters",
					order = 30,
					args = {},
				},
			},
		}
		
		filterOptions = {
			type = "group",
			name = function(info) return filterHandler:GetName(info) end,
			handler = filterHandler,
			order = function(info) return tonumber(info[#info]) end,
			get = "Get",
			set = "Set",
			childGroups = "tab",
			args = {
				name = {
					type = "input",
					order = 1,
					name = "Filter Name",
					desc = "The display name of the filter in the GUI.",
				},
				output = {
					type = "select",
					order = 2,
					name = "Filter Output",
					desc = "The target ChatFrame to send the events of this filter to.",
					values = {ChatFrame1 = "ChatFrame1", ChatFrame2 = "ChatFrame2", ChatFrame3 = "ChatFrame3", ChatFrame4 = "ChatFrame4", ChatFrame5 = "ChatFrame5", ChatFrame6 = "ChatFrame6", ChatFrame7 = "ChatFrame7"},
				},
				markout = {
					type = "execute",
					order = 3,
					name = "Show",
					desc = "Mark all ChatFrames so you can identify them and choose the right one.",
					width = "half",
					func = "MarkOutput",
				},
				enabled = {
					type = "toggle",
					order = 4,
					name = "Enabled",
					desc = "Enable/Disable this filter.",
					width = "half",
				},
				update = {
					type = "execute",
					order = 5,
					name = "Apply Filter",
					desc = "Apply the new filter settings to the selected chat frame, clearing all previous output.",
					--usage = "The filter settings will only be activated once you applied them here, or reloading your UI.",
					func = "Update",
				},
				delete = {
					type = "execute",
					order = 6,
					name = "Delete Filter",
					desc = "Delete this filter.",
					func = "Delete",
					confirm = true,
					confirmText = "Do you really want to delete this filter?",
				},
				source = {
					order = 10,
					type = "group",
					name = "Source/Destination",
					desc = "Configure the source and/or destination of the filtered events.",
					get = "GetUnitFilter",
					set = "SetUnitFilter",
					args = {
						-- Row 1
						header_source = {
							order = 11,
							type = "description",
							name = "Done by:",
							width = "normal",
						},
						row1spacer = {
							order = 12,
							type = "description",
							name = "",
							width = "half",
						},
						header_destination = {
							order = 13,
							type = "description",
							name = "Done to:",
							width = "normal",
						},
						-- Row 2
						src_me = {
							order = 21,
							type = "toggle",
							name = COMBATLOG_FILTER_STRING_ME,
							desc = FILTER_BY_ME_COMBATLOG_TOOLTIP,
						},
						row2spacer = {
							order = 22,
							type = "description",
							name = "",
							width = "half",
						},
						dst_me = {
							order = 23,
							type = "toggle",
							name = COMBATLOG_FILTER_STRING_ME,
							desc = FILTER_TO_ME_COMBATLOG_TOOLTIP,
						},
						-- Row 3
						src_pet = {
							order = 31,
							type = "toggle",
							name = COMBATLOG_FILTER_STRING_MY_PET,
							desc = FILTER_BY_PET_COMBATLOG_TOOLTIP,
						},
						row3spacer = {
							order = 32,
							type = "description",
							name = "",
							width = "half",
						},
						dst_pet = {
							order = 33,
							type = "toggle",
							name = COMBATLOG_FILTER_STRING_MY_PET,
							desc = FILTER_TO_PET_COMBATLOG_TOOLTIP,
						},
						-- Row 4
						src_friends = {
							order = 41,
							type = "toggle",
							name = FRIENDS,
							desc = FILTER_BY_FRIENDS_COMBATLOG_TOOLTIP,
						},
						row4spacer = {
							order = 42,
							type = "description",
							name = "",
							width = "half",
						},
						dst_friends = {
							order = 43,
							type = "toggle",
							name = FRIENDS,
							desc = FILTER_TO_FRIENDS_COMBATLOG_TOOLTIP,
						},
						-- Row 5
						src_hostile = {
							order = 51,
							type = "toggle",
							name = COMBATLOG_FILTER_STRING_HOSTILE_PLAYERS,
							desc = FILTER_BY_HOSTILE_PLAYERS_COMBATLOG_TOOLTIP,
						},
						row5spacer = {
							order = 52,
							type = "description",
							name = "",
							width = "half",
						},
						dst_hostile = {
							order = 53,
							type = "toggle",
							name = COMBATLOG_FILTER_STRING_HOSTILE_PLAYERS,
							desc = FILTER_TO_HOSTILE_PLAYERS_COMBATLOG_TOOLTIP,
						},
						-- Row 6
						src_npc = {
							order = 61,
							type = "toggle",
							name = COMBATLOG_FILTER_STRING_HOSTILE_UNITS,
							desc = FILTER_BY_ENEMIES_COMBATLOG_TOOLTIP,
						},
						row6spacer = {
							order = 62,
							type = "description",
							name = "",
							width = "half",
						},
						dst_npc = {
							order = 63,
							type = "toggle",
							name = COMBATLOG_FILTER_STRING_HOSTILE_UNITS,
							desc = FILTER_TO_HOSTILE_COMBATLOG_TOOLTIP,
						},
						-- Row 7
						src_neutral = {
							order = 71,
							type = "toggle",
							name = COMBATLOG_FILTER_STRING_NEUTRAL_UNITS,
							desc = FILTER_BY_NEUTRAL_COMBATLOG_TOOLTIP,
						},
						row7spacer = {
							order = 72,
							type = "description",
							name = "",
							width = "half",
						},
						dst_neutral = {
							order = 73,
							type = "toggle",
							name = COMBATLOG_FILTER_STRING_NEUTRAL_UNITS,
							desc = FILTER_TO_NEUTRAL_COMBATLOG_TOOLTIP,
						},
						-- Row 8
						src_unknown = {
							order = 81,
							type = "toggle",
							name = COMBATLOG_FILTER_STRING_UNKNOWN_UNITS,
							desc = FILTER_BY_UNKNOWN_COMBATLOG_TOOLTIP,
						},
						row8spacer = {
							order = 82,
							type = "description",
							name = "",
							width = "half",
						},
						dst_unknown = {
							order = 83,
							type = "toggle",
							name = COMBATLOG_FILTER_STRING_UNKNOWN_UNITS,
							desc = FILTER_TO_UNKNOWN_COMBATLOG_TOOLTIP,
						},
						-- Row 9
						src_specific = {
							order = 91,
							type = "input",
							name = "Specific Source",
							desc = "Show only the actions performed by the player specified.\nThis filter works exclusively, thus disabling all of the source filters above, if used.",
						},
						row9spacer = {
							order = 92,
							type = "description",
							name = "",
							width = "half",
						},
						dst_specific = {
							order = 93,
							type = "input",
							name = "Specific Target",
							desc = "Show only the actions performed on the player specified.\nThis filter works exclusively, thus disabling all of the target filters above, if used.",
						},
						-- Row 10
						footer = {
							order = 100,
							type = "description",
							name = "Note: Selecting no filter for either source or target means 'all messages'.",
						},
					},
				},
				events = {
					order = 11,
					type = "group",
					name = "Event Types",
					desc = "Configure the type of events this filter is supposed to show.",
					get = "GetEvent",
					set = "SetEvent",
					args = {
						-- Row Based Layout
						-- Row 1 -- Description Headers
						header_melee = {
							order = 11,
							type = "description",
							name = MELEE,
							width = "normal",
						},
						row1spacer = {
							order = 12,
							type = "description",
							name = "",
							width = "half",
						},
						header_spells = {
							order = 13,
							type = "description",
							name = SPELLS,
							width = "normal",
						},
						row1nl = {
							order = 19,
							type = "description",
							name = "",
						},
						-- Row 2
						melee_hit = {
							order = 21,
							type = "toggle",
							name = DAMAGE,
							desc = SWING_DAMAGE_COMBATLOG_TOOLTIP,
							width = "half",
						},
						melee_miss = {
							order = 22,
							type = "toggle",
							name = MISSES,
							desc = SWING_MISSED_COMBATLOG_TOOLTIP,
							width = "half",
						},
						row2spacer = {
							order = 23,
							type = "description",
							name = "",
							width = "half",
						},
						spell_hit = {
							order = 24,
							type = "toggle",
							name = DAMAGE,
							desc = SPELL_DAMAGE_COMBATLOG_TOOLTIP,
							width = "half",
						},
						spell_miss = {
							order = 25,
							type = "toggle",
							name = MISSES,
							desc = SPELL_MISSED_COMBATLOG_TOOLTIP,
							width = "half",
						},
						-- Row 3
						header_ranged = {
							order = 31,
							type = "description",
							name = RANGED,
							width = "normal",
						},
						row3spacer = {
							order = 32,
							type = "description",
							name = "",
							width = "half",
						},
						spell_heal = {
							order = 33,
							type = "toggle",
							name = HEALS,
							desc = SPELL_HEAL_COMBATLOG_TOOLTIP,
							width = "half",
						},
						spell_energize = {
							order = 34,
							type = "toggle",
							name = "Energize",
							desc = POWER_GAINS_COMBATLOG_TOOLTIP,
							width = "half",
						},
						-- Row 4
						range_hit = {
							order = 41,
							type = "toggle",
							name = DAMAGE,
							desc = RANGE_DAMAGE_COMBATLOG_TOOLTIP,
							width = "half",
						},
						range_miss = {
							order = 42,
							type = "toggle",
							name = MISSES,
							desc = RANGE_MISSED_COMBATLOG_TOOLTIP,
							width = "half",
						},
						row4spacer = {
							order = 43,
							type = "description",
							name = "",
							width = "half",
						},
						spell_extra = {
							order = 44,
							type = "toggle",
							name = "Extra",
							desc = SPELL_EXTRA_ATTACKS_COMBATLOG_TOOLTIP,
							width = "half",
						},
						spell_special = {
							order = 45,
							type = "toggle",
							name = SPECIAL,
							desc = SPELL_INSTAKILL_COMBATLOG_TOOLTIP,
							width = "half",
						},
						-- Row 5
						header_auras = {
							order = 51,
							type = "description",
							name = AURAS,
							width = "normal",
						},
						row5spacer = {
							order = 53,
							type = "description",
							name = "",
							width = "half",
							image = "Interface\\AddOns\\CombatFilter\\spacer",
							imageWidth = 24,
							imageHeight = 24,
						},
						header_casting = {
							order = 54,
							type = "description",
							name = SPELL_CASTING,
							width = "normal",
						},
						-- Row 6
						aura_beneficial = {
							order = 61,
							type = "toggle",
							name = BENEFICIAL,
							desc = BENEFICIAL_AURA_COMBATLOG_TOOLTIP,
							width = "half",
						},
						aura_hostile = {
							order = 62,
							type = "toggle",
							name = HOSTILE,
							desc = HARMFUL_AURA_COMBATLOG_TOOLTIP,
							width = "half",
						},
						row6spacer = {
							order = 63,
							type = "description",
							name = "",
							width = "half",
						},
						casting_start = {
							order = 64,
							type = "toggle",
							name = START,
							desc = SPELL_CAST_START_COMBATLOG_TOOLTIP,
							width = "half",
						},
						casting_success = {
							order = 65,
							type = "toggle",
							name = SUCCESS,
							desc = SPELL_CAST_SUCCESS_COMBATLOG_TOOLTIP,
							width = "half",
						},
						-- Row 7
						aura_dispel = {
							order = 71,
							type = "toggle",
							name = DISPELS,
							desc = DISPEL_AURA_COMBATLOG_TOOLTIP,
							width = "half",
						},
						aura_enchant = {
							order = 72,
							type = "toggle",
							name = ENCHANTS,
							desc = ENCHANT_AURA_COMBATLOG_TOOLTIP,
							width = "half",
						},
						row7spacer = {
							order = 73,
							type = "description",
							name = "",
							width = "half",
						},
						casting_failed = {
							order = 74,
							type = "toggle",
							name = FAILED,
							desc = SPELL_CAST_FAILED_COMBATLOG_TOOLTIP,
							width = "half",
						},
						casting_interrupt = {
							order = 75,
							type = "toggle",
							name = INTERRUPT,
							desc = SPELL_INTERRUPT_COMBATLOG_TOOLTIP,
							width = "half",
						},
						-- Row 8
						header_periodic = {
							order = 81,
							type = "description",
							name = PERIODIC,
							width = "normal",
						},
						row8spacer = {
							order = 83,
							type = "description",
							name = "",
							width = "half",
							image = "Interface\\AddOns\\CombatFilter\\spacer",
							imageWidth = 24,
							imageHeight = 24,
						},
						header_misc = {
							order = 84,
							type = "description",
							name = MISCELLANEOUS,
							width = "normal",
						},
						-- Row 9
						periodic_hit = {
							order = 91,
							type = "toggle",
							name = DAMAGE,
							desc = SPELL_PERIODIC_DAMAGE_COMBATLOG_TOOLTIP,
							width = "half",
						},
						periodic_miss = {
							order = 92,
							type = "toggle",
							name = MISSES,
							desc = SPELL_PERIODIC_MISSED_COMBATLOG_TOOLTIP,
							width = "half",
						},
						row9spacer = {
							order = 93,
							type = "description",
							name = "",
							width = "half",
						},
						misc_kills = {
							order = 94,
							type = "toggle",
							name = KILLS,
							desc = KILLS_COMBATLOG_TOOLTIP,
							width = "half",
						},
						misc_death = {
							order = 95,
							type = "toggle",
							name = DEATHS,
							desc = DEATHS_COMBATLOG_TOOLTIP,
							width = "half",
						},
						-- Row 10
						periodic_heal = {
							order = 101,
							type = "toggle",
							name = HEALS,
							desc = SPELL_PERIODIC_HEAL_COMBATLOG_TOOLTIP,
							width = "half",
						},
						periodic_other = {
							order = 102,
							type = "toggle",
							name = OTHER,
							desc = SPELL_PERIODIC_OTHER_COMBATLOG_TOOLTIP,
							width = "half",
						},
						row10spacer = {
							order = 103,
							type = "description",
							name = "",
							width = "half",
						},
						misc_environment = {
							order = 104,
							type = "toggle",
							name = ENVIRONMENTAL_DAMAGE,
							desc = ENVIRONMENTAL_DAMAGE_COMBATLOG_TOOLTIP,
							width = "normal",
						},
						-- Row 11
						all = {
							order = 111,
							type = "execute",
							name = "All",
							desc = "Active the messages for all supported event types.",
							func = "SelectAllEvents",
							width = "half",
						},
						none = {
							order = 112,
							type = "execute",
							name = "None",
							desc = "Disable the messages for all supported event types.",
							func = "UnselectAllEvents",
							width = "half",
						},
						row11space2 = {
							order = 113,
							type = "description",
							name = "",
							width = "half",
						},
						misc_shields = {
							order = 114,
							type = "toggle",
							name = DAMAGE_SHIELD,
							desc = DAMAGE_SHIELD_COMBATLOG_TOOLTIP,
							width = "normal",
						},
					},
				},
				colors = {
					order = 12,
					type = "group",
					name = "Colors",
					desc = "Configure the colors of the log output for this filter.",
					get = "GetSettings",
					set = "SetSettings",
					args = {
						-- Row1
						row1spacer1 = {
							order = 11,
							type = "description",
							name = "",
							width = "normal",
						},
						header_example = {
							order = 12,
							type = "description",
							name = "|cffffd100Example Text:|r",
							width = "half",
						},
						row1spacer2 = {
							order = 13,
							type = "description",
							name = "",
							width = "normal",
						},
						-- Row2
						example1 = {
							order = 21,
							type = "description",
							name = function(info)
								local filter = CF.db.profile.filters[tonumber(info[2])]
								return colorize(CombatLog_OnEvent(filter, 0, "SPELL_DAMAGE", 0x0000000000000001, UNIT_YOU_DEST_POSSESSIVE, 0x511, 0xF13000012B000820, EXAMPLE_TARGET_MONSTER, 0x10a28 ,116, EXAMPLE_SPELL_FROSTBOLT, SCHOOL_MASK_FROST, 27, SCHOOL_MASK_FROST, nil, nil, nil, 1, nil, nil))
							end,
						},
						-- Row 3
						example2 = {
							order = 31,
							type = "description",
							name = function(info)
								local filter = CF.db.profile.filters[tonumber(info[2])]
								return colorize(CombatLog_OnEvent(filter, 0, "SPELL_DAMAGE", 0xF13000024D002914, EXAMPLE_TARGET_MONSTER, 0x10a48, 0x0000000000000001, UNIT_YOU_DEST, 0x511, 20793,EXAMPLE_SPELL_FIREBALL, SCHOOL_MASK_FIRE, 68, SCHOOL_MASK_FIRE, nil, nil, nil, nil, nil, nil))
							end,
						},
						row3newline = {
							order = 39,
							type = "description",
							name = "",
						},
						-- Row 4
						header_unit = {
							order = 41,
							type = "description",
							name = "|cffffd100Unit Colors:|r",
							width = "normal",
						},
						row4spacer = {
							order = 42,
							type = "description",
							name = "",
							width = "half",
						},
						header_colorize = {
							order = 43,
							type = "description",
							name = "|cffffd100Colorize:|r",
							width = "normal",
						},
						-- Row 5
						unitColoring_me = {
							order = 51,
							type = "color",
							name = COMBATLOG_FILTER_STRING_ME,
							desc = "Configure the color, events involving you are displayed in.",
							get = "GetColor",
							set = "SetColor",
						},
						row5spacer = {
							order = 52,
							type = "description",
							name = "",
							width = "half",
						},
						unitColoring = {
							order = 53,
							type = "toggle",
							name = "Unit Names",
							desc = "Color unit names.",
						},
						-- Row 6
						unitColoring_pet = {
							order = 61,
							type = "color",
							name = COMBATLOG_FILTER_STRING_MY_PET,
							desc = "Configure the color, events involving your pet are displayed in.",
							get = "GetColor",
							set = "SetColor",
						},
						row6spacer = {
							order = 62,
							type = "description",
							name = "",
							width = "half",
						},
						abilityColoring = {
							order = 63,
							type = "toggle",
							name = "Spells",
							desc = "Color spell names.",
							width = "half",
						},
						defaults_spell = {
							order = 64,
							type = "color",
							name = "",
							desc = "Select a color for the spell events.",
							get = "GetColor",
							set = "SetColor",
							width = "half",
							disabled = function(info) return not filterHandler:GetRawSetting(info, "abilityColoring") end,
						},
						-- Row 7
						unitColoring_friends = {
							order = 71,
							type = "color",
							name = FRIENDS,
							desc = "Configure the color, events involving friendly players/pets/npcs are displayed in.",
							get = "GetColor",
							set = "SetColor",
						},
						row7spacer = {
							order = 72,
							type = "description",
							name = "",
							width = "half",
						},
						abilitySchoolColoring = {
							order = 73,
							type = "toggle",
							name = "Spells: By-School",
							desc = "Color spell names by school.",
							disabled = function(info) return not filterHandler:GetRawSetting(info, "abilityColoring") end,
						},
						-- Row 8
						unitColoring_hostile = {
							order = 81,
							type = "color",
							name = COMBATLOG_FILTER_STRING_HOSTILE_PLAYERS,
							desc = "Configure the color, events involving hostile players are displayed in.",
							get = "GetColor",
							set = "SetColor",
						},
						row8spacer = {
							order = 82,
							type = "description",
							name = "",
							width = "half",
						},
						amountColoring = {
							order = 83,
							type = "toggle",
							name = "Damage",
							desc = "Colorize the damage number on non-melee swings.",
							width = "half",
						},
						defaults_damage = {
							order = 84,
							type = "color",
							name = "",
							desc = "Select a color for the damage number.",
							get = "GetColor",
							set = "SetColor",
							width = "half",
							disabled = function(info) return not filterHandler:GetRawSetting(info, "amountColoring") end,
						},
						-- Row 9
						unitColoring_npc = {
							order = 91,
							type = "color",
							name = COMBATLOG_FILTER_STRING_HOSTILE_UNITS,
							desc = "Configure the color, events involving hostile npcs are displayed in.",
							get = "GetColor",
							set = "SetColor",
						},
						row9spacer = {
							order = 92,
							type = "description",
							name = "",
							width = "half",
						},
						amountSchoolColoring = {
							order = 93,
							type = "toggle",
							name = "Damage: By-School",
							desc = "Color damage numbers by school.",
							disabled = function(info) return not filterHandler:GetRawSetting(info, "amountColoring") end,
						},
						-- Row 10
						unitColoring_neutral = {
							order = 101,
							type = "color",
							name = COMBATLOG_FILTER_STRING_NEUTRAL_UNITS,
							desc = "Configure the color, events involving neutral npcs are displayed in.",
							get = "GetColor",
							set = "SetColor",
						},
						row10spacer = {
							order = 102,
							type = "description",
							name = "",
							width = "half",
						},
						schoolNameColoring = {
							order = 103,
							type = "toggle",
							name = "Damage School",
							desc = "Color the damage school name. (e.g. shadow)",
						},
						-- Row 11
						unitColoring_unknown = {
							order = 111,
							type = "color",
							name = COMBATLOG_FILTER_STRING_UNKNOWN_UNITS,
							desc = "Configure the color, events involving unkown sources are displayed in.",
							get = "GetColor",
							set = "SetColor",
						},
						row11spacer = {
							order = 112,
							type = "description",
							name = "",
							width = "half",
						},
						lineColoring = {
							order = 113,
							type = "toggle",
							name = "Entire Line",
							desc = "Color the entire line based on the selection below.",
						},
						-- row 12
						row12spacer1 = {
							order = 121,
							type = "description",
							name = "",
							width = "normal",
						},
						row12spacer2 = {
							order = 122,
							type = "description",
							name = "",
							width = "half",
						},
						lineColorPriority = {
							order = 123,
							type = "select",
							name = "",
							desc = "Select which coloring to use for the line.",
							values = { "By Source", "By Target", --[[ "By Event" ]] },
							disabled = function(info) return not filterHandler:GetRawSetting(info, "lineColoring") end,
						},
					},
				},
				format = {
					order = 13,
					type = "group",
					name = "Formatting",
					desc = "Configure the text format of the log output for this filter.",
					get = "GetSettings",
					set = "SetSettings",
					args = {
						-- Row1
						row1spacer1 = {
							order = 11,
							type = "description",
							name = "",
							width = "normal",
						},
						header_example = {
							order = 12,
							type = "description",
							name = "|cffffd100Example Text:|r",
							width = "half",
						},
						row1spacer2 = {
							order = 13,
							type = "description",
							name = "",
							width = "normal",
						},
						-- Row2
						example1 = {
							order = 21,
							type = "description",
							name = function(info)
								local filter = CF.db.profile.filters[tonumber(info[2])]
								return colorize(CombatLog_OnEvent(filter, 0, "SPELL_DAMAGE", 0x0000000000000001, UNIT_YOU_DEST_POSSESSIVE, 0x511, 0xF13000012B000820, EXAMPLE_TARGET_MONSTER, 0x10a28 ,116, EXAMPLE_SPELL_FROSTBOLT, SCHOOL_MASK_FROST, 27, SCHOOL_MASK_FROST, nil, nil, nil, 1, nil, nil))
							end,
						},
						-- Row 3
						example2 = {
							order = 31,
							type = "description",
							name = function(info)
								local filter = CF.db.profile.filters[tonumber(info[2])]
								return colorize(CombatLog_OnEvent(filter, 0, "SPELL_DAMAGE", 0xF13000024D002914, EXAMPLE_TARGET_MONSTER, 0x10a48, 0x0000000000000001, UNIT_YOU_DEST, 0x511, 20793,EXAMPLE_SPELL_FIREBALL, SCHOOL_MASK_FIRE, 68, SCHOOL_MASK_FIRE, nil, nil, nil, nil, nil, nil))
							end,
						},
						row3newline = {
							order = 39,
							type = "description",
							name = " ",
						},
						-- Row 4
						timestamp = {
							order = 41,
							type = "toggle",
							name = "Show Timestamp",
							desc = "Display the timestamp for combat log messages.",
						},
						row4newline = {
							order = 49,
							type = "description",
							name = "",
						},
						-- Row 5
						braces = {
							order = 51,
							type = "toggle",
							name = "Show Braces",
							desc = "Display braces around hyperlinks in combat log messages.",
						},
						row5newline = {
							order = 59,
							type = "description",
							name = "",
						},
						-- Row 6
						row6spacing = {
							order = 60,
							type = "description",
							name = "",
							width = "half",
						},
						unitBraces = {
							order = 61,
							type = "toggle",
							name = "Units",
							desc = "Show braces around unit names.",
							disabled = function(info) return not filterHandler:GetRawSetting(info, "braces") end,
							width = "half",
						},
						spellBraces = {
							order = 62,
							type = "toggle",
							name = "Spells",
							desc = "Display braces around spell names.",
							disabled = function(info) return not filterHandler:GetRawSetting(info, "braces") end,
							width = "half",
						},
						itemBraces = {
							order = 63,
							type = "toggle",
							name = "Items",
							desc = "Display braces around item names.",
							disabled = function(info) return not filterHandler:GetRawSetting(info, "braces") end,
							width = "half",
						},
						row6newline = {
							order = 69,
							type = "description",
							name = " ",
						},
						-- Row 7
						fullText = {
							order = 71,
							type = "toggle",
							name = "Use Verbose Mode",
							desc = "Show combat log entries as full sentences.",
						},
					},
				},
			},
		}
		
		CF:GenerateFilterOptions()
	end
	
	return options
end


function CF:CreateOptionsGUI()
	LibStub("AceConfigRegistry-3.0"):RegisterOptionsTable("CombatFilter", getOptions)
	LibStub("AceConfigDialog-3.0"):SetDefaultSize("CombatFilter", 705, 525)
	LibStub("AceConsole-3.0"):RegisterChatCommand("cfilter", function() LibStub("AceConfigDialog-3.0"):Open("CombatFilter") end)
end

function CF:GenerateFilterOptions()
	local filters = options.args.filters.args
	for k,v in pairs(filters) do
		filters[k] = nil
	end
	for k,v in pairs(self.db.profile.filters) do
		filters[tostring(k)] = filterOptions
	end
end

filterHandler = {}
function filterHandler:GetName(info)
	local key = tonumber(info[2])
	return CF.db.profile.filters[key].name
end

function filterHandler:MarkOutput()
	for i=1,7 do
		local frame = format("ChatFrame%d", i)
		CF:Print(_G[frame], "This is " .. frame)
	end
end

local outputChanged = {}
function filterHandler:Update(info)
	local filter = tonumber(info[2])
	CF:GenerateFilters(filter)
	CF:ApplyFilter(filter, outputChanged)
end

function filterHandler:Delete(info)
	local filter = tonumber(info[2])
	CF:DeleteFilter(filter)
end

function filterHandler:Get(info)
	local filter = tonumber(info[2])
	local key = info.arg or info[#info]
	return CF.db.profile.filters[filter][key]
end

function filterHandler:Set(info, value)
	local filter = tonumber(info[2])
	local key = info.arg or info[#info]
	if key == "output" then
		outputChanged[(_G[CF.db.profile.filters[filter][key]] or ChatFrame3)] = true
	end
	CF.db.profile.filters[filter][key] = value
end

function filterHandler:GetEvent(info)
	local filter = tonumber(info[2])
	local key = info[#info]
	return CF.db.profile.filters[filter].events[key]
end

function filterHandler:SetEvent(info, value)
	local filter = tonumber(info[2])
	local key = info[#info]
	CF.db.profile.filters[filter].events[key] = value
end

function filterHandler:SelectAllEvents(info)
	local filter = tonumber(info[2])
	local events = CF.db.profile.filters[filter].events
	
	for k in pairs(CF.EventMap) do
		events[k] = true
	end
end

function filterHandler:UnselectAllEvents(info)
	local filter = tonumber(info[2])
	local events = CF.db.profile.filters[filter].events
	
	for k in pairs(events) do
		events[k] = nil
	end
end

function filterHandler:GetUnitFilter(info)
	local filter = tonumber(info[2])
	local type, key = string_split("_", info[#info], 2)
	return CF.db.profile.filters[filter].flags[type][key]
end

function filterHandler:SetUnitFilter(info, value)
	local filter = tonumber(info[2])
	local type, key = string_split("_", info[#info], 2)
	CF.db.profile.filters[filter].flags[type][key] = value
end

function filterHandler:GetSettings(info)
	local filter = tonumber(info[2])
	local key = info.arg or info[#info]
	return CF.db.profile.filters[filter].settings[key]
end

function filterHandler:SetSettings(info, value)
	local filter = tonumber(info[2])
	local key = info.arg or info[#info]
	CF.db.profile.filters[filter].settings[key] = value
end

function filterHandler:GetRawSetting(info, setting)
	local filter = tonumber(info[2])
	return CF.db.profile.filters[filter].settings[setting]
end

function filterHandler:GetColor(info)
	local filter = tonumber(info[2])
	local type, key = string_split("_", info[#info], 2)
	if type == "unitColoring" then
		key = CF.FlagMap[key]
	end
	local c = CF.db.profile.filters[filter].colors[type][key]
	return c.r, c.g, c.b, c.a
end

function filterHandler:SetColor(info, r, g, b, a)
	local filter = tonumber(info[2])
	local type, key = string_split("_", info[#info], 2)
	if type == "unitColoring" then
		key = CF.FlagMap[key]
	end
	local c = CF.db.profile.filters[filter].colors[type][key]
	c.r, c.g, c.b, c.a = r, g, b, a
end
