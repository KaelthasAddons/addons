local L = LibStub("AceLocale-3.0"):NewLocale("Acheron", "enUS", true)

-- config strings

L["config"] = true
L["Toggle the Configuration Dialog"] = true

L["show"] = true
L["Show Acheron Death Reports"] = true

L["General"] = true
L["Enable"] = true
L["Enable or disable data collection"] = true
L["History"] = true
L["The amount of history, in seconds, of combat log to keep per player"] = true
L["Number of Reports"] = true
L["The numer of death reports to keep per player, 0 for no limit"] = true
L["Log Level"] = true
L["Determines the amount of output from the addon"] = true

L["Enable White List"] = true
L["When the white list is enabled, only auras on the white list will be tracked."] = true
L["Enable Black List"] = true
L["When the black list is enabled, any auras on the black list will not be tracked."] = true
L["Auras"] = true
L["Aura"] = true
L["List"] = true
L["Select the desired list from the dropdown menu and enter the name of a buff or debuff to track."] = true
L["You must select the list from the dropdown menu for which to add this aura"] = true
L["You must enter a value for the aura name"] = true
L["White List"] = true
L["Black List"] = true
L["Delete"] = true
L["Are you sure you want to delete this aura from the white list?"] = true
L["Are you sure you want to delete this aura from the black list?"] = true

L["Display"] = true
L["Font Size"] = true
L["The font size of the death report entries"] = true

L["Profile: %s"] = true

-- combat log strings

L["Melee"] = true
L["Environment"] = true
L["Unknown"] = true
L["Death"] = true
L["Dodge"] = true
L["Parry"] = true
L["Miss"] = true
L["Resist"] = true

-- report strings

L["Filter"] = true
L["Show"] = true
L["Time to Show"] = true
L["Amount to Show >"] = true
L["Damage"] = true
L["Healing"] = true
L["Buffs"] = true
L["Debuffs"] = true

L["Report"] = true
L["Report To"] = true
L["Whisper To"] = true
L["Absolute Health"] = true

L["Clear All"] = true

L["say"] = true
L["party"] = true
L["raid"] = true
L["guild"] = true
L["officer"] = true
L["whisper"] = true


L["Acheron: Death report for %s:"] = true
L["Acheron: No whisper target"] = true
L["Acheron: Whisper target is not a player"] = true
L["Acheron: You are not in a party"] = true
L["Acheron: You are not in a raid"] = true
L["Acheron: You are not in a guild"] = true
L["Acheron: No such channel: %s"] = true

L["Click to report from this point"] = true
L["Critical"] = true
L["Crushing"] = true

-- log levels

L["NONE"] = "Disabled"
L["ERROR"] = "Errors only"
L["WARN"] = "Errors and warnings"
L["INFO"] = "Informational messages"
L["DEBUG"] = "Debug messaging"
L["TRACE"] = "Debug trace messages"
L["SPAM"] = "Everything"