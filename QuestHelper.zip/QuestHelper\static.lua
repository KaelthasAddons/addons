QuestHelper_File["static.lua"] = "0.95"
QuestHelper_Loadtime["static.lua"] = GetTime()
QuestHelper_StaticData={  ruRU=QuestHelper_StaticData_ruRU,  deDE=QuestHelper_StaticData_deDE,  koKR=QuestHelper_StaticData_koKR,  esMX=QuestHelper_StaticData_esMX,  enUS=QuestHelper_StaticData_enUS,  zhCN=QuestHelper_StaticData_zhCN,  esES=QuestHelper_StaticData_esES,  zhTW=QuestHelper_StaticData_zhTW,  frFR=QuestHelper_StaticData_frFR,}
