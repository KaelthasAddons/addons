QuestHelper_File = {}
QuestHelper_Loadtime = {}
QuestHelper_File["bst_pre.lua"] = "0.95"
QuestHelper_Loadtime["bst_pre.lua"] = GetTime()
