QuestHelper_File["bst_libaboutpanel.lua"] = "0.95"
QuestHelper_Loadtime["bst_libaboutpanel.lua"] = GetTime()
