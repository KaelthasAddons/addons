QuestHelper_File["bst_astrolabe.lua"] = "0.95"
QuestHelper_Loadtime["bst_astrolabe.lua"] = GetTime()
