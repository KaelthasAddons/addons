QuestHelper_ChangeLog="|cffffff00       Version 0.95 3/20/2009|r\
\
• Disable donation request.\
Bad news, everyone. Questhelper's dead.\
Blizzard just posted their new UI Add-On Development Policy at http://www.worldofwarcraft.com/policy/ui.html. The important part is that I'm no longer allowed to ask for donations in-client. I know how much I got before I added the in-client reminder - it doesn't pay a significant fraction of the bills. And, as much as I like you guys, good intentions don't pay for my apartment.\
So that's it. I do plan to keep QH functional, at least through the end of Wrath, and probably further. I've got one or two features in mind that I want to do for my own sake - a few achievements, mostly - but besides that, that's pretty much all there's going to be.\
I would like to say: thanks to everyone who donated in the past. I enjoyed working on this quite a bit, and I always enjoyed seeing another donation come in - not just because of the money, but because it meant that people wanted to use QH and wanted to keep it going.\
Let Blizzard know if you don't like it, and if I can get an exception, I'll start everything right back up again :)\
\
|cffffff00       Version 0.94 3/17/2009|r\
\
• Update database.\
\
|cffffff00       Version 0.93 3/3/2009|r\
\
• Fix the minimap issue for real. Argh.\
\
|cffffff00       Version 0.92 3/2/2009|r\
\
• There was never a bug with rotating-minimaps causing the routing arrow to point at the wrong place. This release is merely being done for fun. Hey look! Wasn't that fun!\
\
|cffffff00       Version 0.91 3/1/2009|r\
\
• Full compatability with WoW 3.1 on the PTR. Let me know if it breaks again, I may not notice.\
• Fix a small bug that caused hardreset to stop working\
• Remove some error spam that was occuring with tooltips when QH didn't actually load properly\
"
