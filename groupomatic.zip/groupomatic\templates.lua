--[[

	===================================

	ROLES:

	"TANK"
	"TANK_BUFFER"
	"HEALER"
	"MANA_BATTERY"
	"HEAL_BUFFER"
	"MELEE_BUFFER"
	"RANGE_BUFFER"
	"SPELL_BUFFER"
	"DECURSER"
	"MELEE_DPS"
	"RANGE_DPS"
	"SPELL_DPS"

	----------------------------------
	Note:
	-The "BUFFER" roles imply that that player has an aura or something that buffs people in their own group only.
	-TANK_BUFFER gets applied to warlocks with imp. imp, pallies with imp. devo aura, etc. It means a *better* tank buffer, but that doesn't mean that other members of that class shouldn't get added to tanking groups if no "tank buffers" are available. use "class" for that
	-DECURSER has several special attributes, see below

	===================================

	If you would like to add your own templates, you can put them in this file
	If you would like to distribute templates, you can do so by sending people a copy of this file or by making a small addon which adds one or more entries into GrOM.userTemplates
	Of course, if you do that, you need to make sure that it adds them after GOM has loaded, for example by watching for VARIABLES_LOADED

	The basic layout of a template is a 3-index table. The first index is the name of the template. The second and third are both tables that specify a set of actions to follow:

	Entries in both tables can be either a string, which gives a special command, or a table specifying the type of raid member you want to add to the current subgroup.

	The auto-arranger first assumes that each subgroup is empty and passes over them (up to the highest subgroup that is going to be used) and executes the actions in the first table for each group.
	It then passes over each subgroup again, executing the actions in the second table.

	This happens in one video frame, before the confirmation dialog. The code that actually moves people around starts after that.

	Valid strings:
		-go #
			-go to index # (must be higher than the current index)
		-fail #
			-if the most recent attempt to find a player to add (in the current subgroup, in the current pass) did not find anyone, go to index # (must be higher than the current index)
		-spec ROLE #
			-if the current group already contains a member that has the role ROLE, go to index # (must be higher than the current index)
		-group #,#,#,#,...
			-all subsequent commands will only be applied for the given subgroups, until the arranger moves to a different subgroup or reaches "allgroups"
		-allgroups
			-see "group"
		-limit limit1,limit2,limit3,...
			-sets limits on future class and/or spec additions to the group which will be enforced until the arranger moves to another subgroup, reaches a different "limit" command, or reaches "nolimit"
			-each limit is a number, followed by a class string(or * for not specified), followed by either & or @, followed by a ROLES string (or * for not specified)
				-you cannot use * for both class and spec
			-place a + in front of a limit to require that it not be exceeded, otherwise the arranger will just match others first
			-sample limits:
				-  limit +1SHAMAN@*   (require that the group has at most 1 shaman of any spec)
				-  limit +2WARRIOR&TANK  (require that the group has at most 2 tank warriors)
				-  limit +2WARRIOR@TANK  (require that the group has at most 2 warriors or tanks)
				-  limit +1SHAMAN@*,2WARRIOR&TANK (require that the group has at most one shaman, and try not to let the group exceed 2 tank warriors)
				-  limit +1SHAMAN@*,+1PRIEST&MANA_BATTERY,+1PALADIN@* (require that the group has at most one shaman, shadow priest, and pally)
				-  limit +0DRUID&SPELL_DPS (don't add any boomkins to this group)
		-nolimit
			-see "limit"
		-decursewhich any | TYPE(,TYPE(,TYPE(,TYPE))))
			-until the arranger reaches another decursewhich line (NOTE: this is not reset by moving to another subgroup, only but finding another decursewhich line or starting an entirely new arrange), the DECURSER role will refer to either "any" class that's capable of dispelling debuffs, or any class that is capable of dispelling at least one of the list of "TYPE"s
			examples:
				-  decursewhich any
				-  decursewhich POISON
				-  decursewhich CURSE,DISEASE
				-  decursewhich MAGIC,DISEASE,CURSE
			-if there is no decursewhich line, the default is "any"
		-pass #
			-until the arranger moves on to a different subgroup or reaches "anypass", any subsequent commands will only be followed if the arranger has passed over all the groups twice already, has not found a group for everyone yet, and is now on pass #...note that if your rules cause the arranger to pass over 100 or more groups and still not find a group for everyone, it will give up and error out
		-anypass
			-see "pass"
		-pushextras
			-stop the entire arrangement and push anyone left into the lowest group(s) available
		-end
			-stop and go on to the next subgroup

	Valid Table Structure:
		{class, prefSpec, requirePref, ignoreSpec, loop}

		-if prefSpec is "DECURSER", requirePref is ignored, and always acts as if it were true (i.e. if there is no decurser available, the line will not add anyone, even if requirePref is false)
		-class is a literal string. all caps, in english; or nil for any class
		-prefSpec is a ROLE string. you must specify something here, and it must be a valid role.
		-requirePref is a boolean. if it is true then only players matching prefSpec will be considered, otherwise they will just be preferred
		-ignoreSpec is a ROLE string. members with this spec will not be considered. Nil for none.
		-loop is a boolean. if it is true, the auto-arranger will repeat this step until it does not yield another match, or the group is full, or there are no more unassigned members to add

	General guidelines:
		-If your rules do not find a group for everyone in the raid, GOM will output an error and stop.
		-It's usually a good idea to put a general "add anyone else" at the very end
		-Obviously the "spec" command will always be false if you're using it in the first pass.
		-Don't put quotes around whatever ROLE you use with the "spec" command, they go around the whole thing like the other strings (i.e. "spec TANK_BUFFER 45")
		-nil and false are treated the same and can be interchanged
		-If all of the remaining entries in a table are nil/false, you can omit them: {nil, "TANK", true} is the same as {nil, "TANK", true, nil, false}

]]


--[[

This example (almost) exactly duplicates the original ruleset used for the "default" template up until version 1.6

GrOM.userTemplates["EXAMPLE_AKRYN"] = {
	"Example",
	{
	--we're creating a new group
	--if there is a tank available, add it and
		--if there is another tank available, add it too
		--if there is a tree druid that isn't a tank (not possible to be both atm but it can't hurt to be thorough), add it
		--if there is a pally that is not a tank and is a "tank buffer" available, add it; otherwise if there is a pally that isn't a tank available, add it
		--if there is a warlock that is a "tank buffer" available, add it; otherwise, if there is any other warlock available, add it
		--stop
	--else if there is a healer available, add it and
		--if there is a mana battery, add it
		--if there is any free "heal buffer" add it
		--add as many other healers as there are free
		--stop
	--else if there is a melee dps available, add it and
		--if there is any melee buffer available, add it
		--find as many melee dps as are available, and add them
		--stop
	--else do the same as above for ranged and then spell dps

		[1] = {nil, "TANK", true},
		[2] = "fail 8",
		[3] = {nil, "TANK", true},
		[4] = {"DRUID", "TANK_BUFFER"},
		[5] = {"PALADIN", "TANK_BUFFER"},
		[6] = {"WARLOCK", "TANK_BUFFER"},
		[7] = "end",
		[8] = {nil, "HEALER", true},
		[9] = "fail 14",
		[10] = {nil, "MANA_BATTERY", true},
		[11] = {nil, "HEAL_BUFFER", true},
		[12] = {nil, "HEALER", true, nil, true},
		[13] = "end",
		[14] = {nil, "MELEE_DPS", true},
		[15] = "fail 19",
		[16] = {nil, "MELEE_BUFFER", true},
		[17] = {nil, "MELEE_DPS", true, nil, true},
		[18] = "end",
		[19] = {nil, "RANGE_DPS", true},
		[20] = "fail 24",
		[21] = {nil, "RANGE_BUFFER", true},
		[22] = {nil, "RANGE_DPS", true, nil, true},
		[23] = "end",
		[24] = {nil, "SPELL_DPS", true}, --no need for a "fail" here because if this fails there are no tanks, healers or dps left to add, but there are still unassigned members, which would mean there's something really wrong :P
		[25] = {nil, "SPELL_BUFFER", true},
		[26] = {nil, "SPELL_DPS", true, nil, true}

	},
	{
	--we're filling in empty space
	--if there is a healer anywhere in the group
		--find any available heal buffers or mana batteries and add them
	--if there is a tank anywhere in the group
		--find any available tanks or tank buffers and add them
	--if there are any melee buffers in the group, add any available melee dps
	--if there are any ranged buffers in the group, add any available ranged dps and then melee dps
	--fill in the rest, starting with spell dps

		[1] = "spec HEALER 6",
		[2] = "spec TANK 9",
		[3] = "spec MELEE_BUFFER 12",
		[4] = "spec RANGE_BUFFER 14",
		[5] = "go 16",
		[6] = {nil, "HEAL_BUFFER", true, nil, true},
		[7] = {nil, "MANA_BATTERY", true, nil, true},
		[8] = "go 16",
		[9] = {nil, "TANK_BUFFER", true, nil, true},
		[10] = {nil, "TANK", true, nil, true},
		[11] = "go 16",
		[12] = {nil, "MELEE_DPS", true, nil, true},
		[13] = "go 16",
		[14] = {nil, "RANGE_DPS", true, nil, true},
		[15] = {nil, "MELEE_DPS", true, nil, true},
		[16] = {nil, "SPELL_DPS", false, nil, true} --will add anything left (starting with casters) until the group is full or there's nothing else to add

	}}

]]


GrOM.userTemplates["Alterac_Valley_AKRYN"] = {
	"Alterac Valley (1.0)",

	{
		--set up each group with one healer and one of each class (ignoring other healers) until it's full

		[1] = {nil, "HEALER", true}, --add one healer to each group on the first pass
		[2] = {"ROGUE", "HEALER", false}, --healer because i don't want any pref spec, and none of these classes are likely to be healers
		[3] = {"WARRIOR", "HEALER", false},
		[4] = {"WARLOCK", "HEALER", false},
		[5] = {"DRUID", "TANK", false, "HEALER"}, --feral druids, or oomkin if none
		[6] = {"MAGE", "HEALER", false},
		[7] = {"HUNTER", "HEALER", false},
		[8] = {"PRIEST", "SPELL_DPS", true}, --spriests
		[9] = {"SHAMAN", "HEALER", false, "HEALER"}, --pref = ignore will give you anything that is not ignore without bias if requirepref is false
		[10] = {"PALADIN", "HEALER", false, "HEALER"}
	},
	{
		[1] = "spec HEALER 6",
		[2] = "spec TANK 9",
		[3] = "spec MELEE_BUFFER 12",
		[4] = "spec RANGE_BUFFER 14",
		[5] = "go 16",
		[6] = {nil, "HEAL_BUFFER", true, nil, true},
		[7] = {nil, "MANA_BATTERY", true, nil, true},
		[8] = "go 16",
		[9] = {nil, "TANK_BUFFER", true, nil, true},
		[10] = {nil, "TANK", true, nil, true},
		[11] = "go 16",
		[12] = {nil, "MELEE_DPS", true, nil, true},
		[13] = "go 16",
		[14] = {nil, "RANGE_DPS", true, nil, true},
		[15] = {nil, "MELEE_DPS", true, nil, true},
		[16] = {nil, "SPELL_DPS", false, nil, true}
	}
}

if GetLocale() == "zhCN" then
     GrOM.userTemplates["Alterac_Valley_AKRYN"][1] = "奥特兰克山谷 (1.0)"
end

GrOM.userTemplates["PVE_RAID_2_AKRYN"] = {
	"Alt. Generic PvE (Beta 2)",

	{
		[1] = "group 1,2",
		[2] = "go 8",
		[3] = "allgroups",
		[4] = "group 3,4",
		[5] = "go 15",
		[6] = "allgroups",
		[7] = "go 30",
		[8] = {nil, "TANK", true},
		[9] = "fail 15",
		[10] = {nil, "TANK", true},
		[11] = {nil, "TANK", true},
		[12] = {"DRUID", "TANK_BUFFER", true},
		[13] = {"PALADIN", "TANK_BUFFER"},
		[14] = "end",
		[15] = {"PRIEST", "MANA_BATTERY", true},
		[16] = "fail 23",
		[17] = {"WARLOCK", "HEALER", false, nil, true},
		[18] = {"MAGE", "HEALER", false, nil, true},
		[19] = {"HUNTER", "RANGE_BUFFER", false, nil, true},
		[20] = "group 1,2",
		[21] = "end",
		[22] = "allgroups",
		[23] = {nil, "HEALER", true},
		[24] = "fail 30",
		[25] = "limit +1SHAMAN@*,1PALADIN@*",
		[26] = {nil, "HEAL_BUFFER", true},
		[27] = {nil, "HEALER", true, nil, true},
		[28] = {nil, "MANA_BATTERY", true},
		[29] = "end",
		[30] = {nil, "MELEE_DPS", true},
		[31] = "fail 36",
		[32] = "limit +1SHAMAN@*,+1PALADIN@*",
		[33] = {nil, "MELEE_BUFFER", true},
		[34] = {nil, "MELEE_DPS", true, nil, true},
		[35] = "end",
		[36] = {nil, "RANGE_DPS", true},
		[37] = "fail 42",
		[38] = "limit +1SHAMAN@*,+1PALADIN@*,1*@RANGE_BUFFER",
		[39] = {nil, "RANGE_BUFFER", true},
		[40] = {nil, "RANGE_DPS", true, nil, true},
		[41] = "end",
		[42] = "limit +1SHAMAN@*,+1PALADIN@*",
		[43] = {nil, "SPELL_DPS", true},
		[44] = {nil, "SPELL_BUFFER", true},
		[45] = {nil, "SPELL_DPS", true, nil, true}
	},
	{
		[1] = "spec TANK 6",
		[2] = "spec HEALER 12",
		[3] = "spec MELEE_BUFFER 19",
		[4] = "spec RANGE_BUFFER 21",
		[5] = "go 27",
		[6] = "limit +1SHAMAN@*,+1PALADIN@*,+1PRIEST&MANA_BATTERY,+1WARLOCK@*",
		[7] = {"WARLOCK", "TANK_BUFFER", true},
		[8] = {nil, "TANK_BUFFER", true, nil, true},
		[9] = {nil, "TANK", true, nil, true},
		[10] = "spec HEALER 12",
		[11] = "go 27",
		[12] = "limit +1SHAMAN@*,+1PALADIN@*,+1PRIEST&MANA_BATTERY",
		[13] = "pass 3",
		[14] = "nolimit",
		[15] = "anypass",
		[16] = {nil, "HEAL_BUFFER", true, nil, true},
		[17] = {nil, "MANA_BATTERY", true, nil, true},
		[18] = "go 27",
		[19] = {nil, "MELEE_DPS", true, nil, true},
		[20] = "go 27",
		[21] = "limit +1SHAMAN@*,+1PALADIN@*,+1PRIEST&MANA_BATTERY,+1WARLOCK@*",
		[22] = "pass 3",
		[23] = "nolimit",
		[24] = "anypass",
		[25] = {nil, "RANGE_DPS", true, nil, true},
		[26] = {nil, "MELEE_DPS", true, nil, true},
		[27] = "limit +1SHAMAN@*,+1PALADIN@*,+1PRIEST&MANA_BATTERY,+1WARLOCK@*",
		[28] = "pass 3",
		[29] = "nolimit",
		[30] = "anypass",
		[31] = {"WARLOCK", "SPELL_DPS", false, nil, true},
		[32] = {nil, "SPELL_DPS", false, nil, true}
	}
}
if GetLocale() == "zhCN" then
     GrOM.userTemplates["PVE_RAID_2_AKRYN"][1] = "奥特兰克山谷 普通 PvE (测试版)"
end

GrOM.userTemplates["AB_EOTS_AUTO_AKRYN"] = {
	"AB/EotS (group by current node)",

	{
		"dynbg",
		"end"
	},
	{
		"end"
	}
}
if GetLocale() == "zhCN" then
     GrOM.userTemplates["AB_EOTS_AUTO_AKRYN"][1] = "阿拉希盆地/风暴之眼 (按当前节点分配)"
end












--[[

GrOM.userTemplates["PVE_RAID_2_AKRYN_TEST"] = {
	"Testing PvE 2",

	{
		[1] = "group 1,2",
		[2] = "go 8",
		[3] = "allgroups",
		[4] = "group 3,4",
		[5] = "go 15",
		[6] = "allgroups",
		[7] = "go 30",
		[8] = {nil, "TANK", true},
		[9] = "fail 15",
		[10] = {nil, "TANK", true},
		[11] = {nil, "TANK", true},
		[12] = {"DRUID", "TANK_BUFFER", true},
		[13] = {"PALADIN", "TANK_BUFFER"},
		[14] = "end",
		[15] = {"PRIEST", "MANA_BATTERY", true},
		[16] = "fail 23",
		[17] = {"WARLOCK", "HEALER", false, nil, true},
		[18] = {"MAGE", "HEALER", false, nil, true},
		[19] = {"HUNTER", "RANGE_BUFFER", false, nil, true},
		[20] = "group 1,2",
		[21] = "end",
		[22] = "allgroups",
		[23] = {nil, "HEALER", true},
		[24] = "fail 30",
		[25] = "limit +1SHAMAN@*,1PALADIN@*",
		[26] = {nil, "HEAL_BUFFER", true},
		[27] = {nil, "HEALER", true, nil, true},
		[28] = {nil, "MANA_BATTERY", true},
		[29] = "end",
		[30] = {nil, "MELEE_DPS", true},
		[31] = "fail 36",
		[32] = "limit +1SHAMAN@*,+1PALADIN@*",
		[33] = {nil, "MELEE_BUFFER", true},
		[34] = {nil, "MELEE_DPS", true, nil, true},
		[35] = "end",
		[36] = {nil, "RANGE_DPS", true},
		[37] = "fail 42",
		[38] = "limit +1SHAMAN@*,+1PALADIN@*,1*@RANGE_BUFFER",
		[39] = {nil, "RANGE_BUFFER", true},
		[40] = {nil, "RANGE_DPS", true, nil, true},
		[41] = "end",
		[42] = "limit +1SHAMAN@*,+1PALADIN@*",
		[43] = {nil, "SPELL_DPS", true},
		[44] = {nil, "SPELL_BUFFER", true},
		[45] = {nil, "SPELL_DPS", true, nil, true}
	},
	{
		"pushextras"
	}
}]]