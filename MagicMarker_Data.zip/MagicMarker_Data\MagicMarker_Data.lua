MagicMarker:ImportData(MagicMarker_Data, MagicMarker_DataVersion)
MagicMarker_Data = nil
MagicMarker_DataVersion = nil
