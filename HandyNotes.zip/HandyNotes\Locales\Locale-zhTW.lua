﻿-- HandyNotes
-- zhTW Localization file

local L = LibStub("AceLocale-3.0"):NewLocale("HandyNotes", "zhTW")
if not L then return end


-- vim: ts=4 noexpandtab
