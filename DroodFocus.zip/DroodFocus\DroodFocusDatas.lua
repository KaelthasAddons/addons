--------------------------
-- TRACKER DATA 2.6.5 --
--------------------------------------------------------------------

local _, class = UnitClass("player")
if (class ~= "DRUID" and class ~= "ROGUE")  then
	-- don't load for non-druids
	return
end

abilities = {};

abilities[1] = {
	abiId = 33983, -- id mangle cat
	abiName = GetSpellInfo(33983),
	abiIdAlt = 33987, -- id mangle bear
	abiNameAlt = GetSpellInfo(33987),
	abiPersonnal = false, 
	abiTimer= 12,
	abiTimeLeft=-1,
	abiDot= false,
	abiCombo= false,
	abiX = 0 * 22,
	abiY = -10,
	abiW = 20,
	abiH = 20,
	abiObj = "DruidFocusMangleCat", 
	abiImg = "Interface\\AddOns\\DroodFocus\\arts\\img_mangle",
	abiMode = "BLEND",
	abiScale = 0.10,
	abiScaleAdd = 0,
	abiState = 0,
	abiAlpha = 1,
	abiAmount = 0,
};

abilities[2] = {
	abiId = 16857, -- fearyfire f�ral
	abiName = GetSpellInfo(16857),
	abiIdAlt = -1, 
	abiNameAlt = "",
	abiPersonnal = false, 
	abiTimer= 12,
	abiTimeLeft=-1,
	abiDot= false,
	abiCombo= false,
	abiX = -3*22,
	abiY = -10,
	abiW = 20,
	abiH = 20,
	abiObj = "DruidFocusFeary", 
	abiImg = "Interface\\AddOns\\DroodFocus\\arts\\img_fearie",
	abiMode = "BLEND",
	abiScale = 0.10,
	abiScaleAdd = 0,
	abiState = 0,
	abiAlpha = 1,
	abiAmount = 0,
};

abilities[3] = {
	abiId = 1822, -- rake
	abiName = GetSpellInfo(1822),
	abiIdAlt = -1, 
	abiNameAlt = "",
	abiPersonnal = true, 
	abiTimer= 4,
	abiTimeLeft=-1,
	abiDot= true,
	abiCombo= false,
	abiX = 2*22,
	abiY = -10,
	abiW = 20,
	abiH = 20,
	abiObj = "DruidFocusRake", 
	abiImg = "Interface\\AddOns\\DroodFocus\\arts\\img_rake",
	abiMode = "BLEND",
	abiScale = 0.10,
	abiScaleAdd = 0,
	abiState = 0,
	abiAlpha = 1,
	abiAmount = 0,
};

abilities[4] = {
	abiId = 1079, -- rip
	abiName = GetSpellInfo(1079),
	abiIdAlt = -1, 
	abiNameAlt = "",
	abiPersonnal = true,
	abiDot= true,
	abiTimer= 3,
	abiTimeLeft=-1,
	abiCombo= false,
	abiX = 1*22,
	abiY = -10,
	abiW = 20,
	abiH = 20,
	abiObj = "DruidFocusRip", 
	abiImg = "Interface\\AddOns\\DroodFocus\\arts\\img_rip",
	abiMode = "BLEND",
	abiScale = 0.10,
	abiScaleAdd = 0,
	abiState = 0,
	abiAlpha = 1,
	abiAmount = 0,
};

abilities[5] = {
	abiId = 99, -- Demoralizing Roar
	abiName = GetSpellInfo(99),
	abiIdAlt = -1, 
	abiNameAlt = "",
	abiPersonnal = false, 
	abiDot= false,
	abiTimer= -1,
	abiTimeLeft=-1,
	abiCombo= false,
	abiX = -2*22,
	abiY = -10,
	abiW = 20,
	abiH = 20,
	abiObj = "DruidFocusRoar", 
	abiImg = "Interface\\AddOns\\DroodFocus\\arts\\img_roar",
	abiMode = "BLEND",
	abiScale = 0.10,
	abiScaleAdd = 0,
	abiState = 0,
	abiAlpha = 1,
	abiAmount = 0,
};

abilities[6] = {
	abiId = 33745, -- Lacerate
	abiName = GetSpellInfo(33745),
	abiIdAlt = -1, 
	abiNameAlt = "",
	abiPersonnal = true, 
	abiTimer= 15,
	abiTimeLeft=-1,
	abiDot= true,
	abiCombo= true,
	abiX = -1*22,
	abiY = -10,
	abiW = 20,
	abiH = 20,
	abiObj = "DruidFocusLacerate", 
	abiImg = "Interface\\AddOns\\DroodFocus\\arts\\img_lacerate",
	abiMode = "BLEND",
	abiScale = 0.10,
	abiScaleAdd = 0,
	abiState = 0,
	abiAlpha = 1,
	abiAmount = 0,
};

abilities[7] = {
	abiId = 9007, -- Pounce Bleed
	abiName = GetSpellInfo(22570),
	abiIdAlt = -1, 
	abiNameAlt = "",
	abiPersonnal = true,
	abiDot= true,
	abiTimer= 18,
	abiTimeLeft=-1,
	abiCombo= false,
	abiX = 3*22,
	abiY = -10,
	abiW = 20,
	abiH = 20,
	abiObj = "DruidFocusPounce", 
	abiImg = "Interface\\AddOns\\DroodFocus\\arts\\img_pounce",
	abiMode = "BLEND",
	abiScale = 0.10,
	abiScaleAdd = 0,
	abiState = 0,
	abiAlpha = 1,
	abiAmount = 0,
};

abilities[8] = {
	abiId = 22570, -- maim
	abiName = GetSpellInfo(22570),
	abiIdAlt = -1, 
	abiNameAlt = "",
	abiPersonnal = true,
	abiDot= true,
	abiTimer= 7,
	abiTimeLeft=-1,
	abiCombo= false,
	abiX = 4*22,
	abiY = -10,
	abiW = 20,
	abiH = 20,
	abiObj = "DruidFocusMaim", 
	abiImg = "Interface\\AddOns\\DroodFocus\\arts\\img_maim",
	abiMode = "BLEND",
	abiScale = 0.10,
	abiScaleAdd = 0,
	abiState = 0,
	abiAlpha = 1,
	abiAmount = 0,
};

abilities[9] = {
	abiId = 5211, -- bash
	abiName = GetSpellInfo(5211),
	abiIdAlt = -1, 
	abiNameAlt = "",
	abiPersonnal = true,
	abiDot= false,
	abiTimer= 4,
	abiTimeLeft=-1,
	abiCombo= false,
	abiX = -4*22,
	abiY = -10,
	abiW = 20,
	abiH = 20,
	abiObj = "DruidFocusBash", 
	abiImg = "Interface\\AddOns\\DroodFocus\\arts\\img_bash",
	abiMode = "BLEND",
	abiScale = 0.10,
	abiScaleAdd = 0,
	abiState = 0,
	abiAlpha = 1,
	abiAmount = 0,
};

nbAbilities = getn(abilities);

