DROODFOCUS_VERSION	= "2.6.5";
DROODFOCUS		= "Drood Focus "..DROODFOCUS_VERSION;
DROODFOCUS_WELCOME	= "Drood Focus "..DROODFOCUS_VERSION.." - Type /droodfocus or /df for options.";
DROODFOCUS_SCALE	= "Scale";
DROODFOCUS_LOW		= "Low";
DROODFOCUS_HIGH		= "High";
DROODFOCUS_LOCK		= "Locked.";
DROODFOCUS_CLAWS	= "Claws/blood on critical strike."
DROODFOCUS_TRACKER	= "Show debuffs bar."
DROODFOCUS_CONTX	= "X"
DROODFOCUS_CONTY	= "Y"
DROODFOCUS_MINI		= "Min."
DROODFOCUS_MAXI		= "Max."
DROODFOCUS_ENABLE	= "Enabled."
DROODFOCUS_ALPHA	= "Alpha."
DROODFOCUS_CMD		= DROODFOCUS..": use '/df config' to open configuration panel or '/df reset' to reset configuration";

if (GetLocale() == "frFR") then
	DROODFOCUS		= "Drood Focus "..DROODFOCUS_VERSION;
	DROODFOCUS_WELCOME	= "Drood Focus "..DROODFOCUS_VERSION.." - Taper /droodfocus ou /df pour les options.";
	DROODFOCUS_SCALE	= "Echelle";
	DROODFOCUS_LOW		= "Bas";
	DROODFOCUS_HIGH		= "Haut";
	DROODFOCUS_LOCK		= "Verrouiller.";
	DROODFOCUS_CLAWS	= "Griffes/sang sur critiques."
	DROODFOCUS_TRACKER	= "Voir barre des debuffs."
	DROODFOCUS_CONTX	= "X"
	DROODFOCUS_CONTY	= "Y"
	DROODFOCUS_MINI		= "Min."
	DROODFOCUS_MAXI		= "Max."	
	DROODFOCUS_ENABLE	= "Activé."
	DROODFOCUS_ALPHA	= "Alpha."
	DROODFOCUS_CMD		= DROODFOCUS..": utiliser '/df config' pour ouvrir le panneau de configuration ou '/df reset' pour reinitialiser la configuration";
		
elseif (GetLocale() == "zhCN") then
	-- locale by 急云@CWDG
	-- 2008-7-22 DROOD FOCUS v2.4.1b
	--DROODFOCUS_VERSION	= "2.4.1b";
	--DROODFOCUS		= "Drood Focus "..DROODFOCUS_VERSION;
	DROODFOCUS_WELCOME	= "Drood Focus "..DROODFOCUS_VERSION.." - 键入 /droodfocus 或 /df 打开设置。";
	DROODFOCUS_SCALE	= "缩放";
	DROODFOCUS_LOW		= "低";
	DROODFOCUS_HIGH		= "高";
	DROODFOCUS_LOCK		= "锁定.";
	DROODFOCUS_CLAWS	= "爆击时显示爪痕/血腥效果。";
	DROODFOCUS_TRACKER	= "显示减益栏。";
	--DROODFOCUS_CONTX	= "X";
	--DROODFOCUS_CONTY	= "Y";
	DROODFOCUS_MINI		= "最小.";
	DROODFOCUS_MAXI		= "最大.";
	DROODFOCUS_ENABLE	= "开启.";
	DROODFOCUS_ALPHA	= "血腥效果."
	DROODFOCUS_CMD		= DROODFOCUS..": 键入 '/df config' 打开设置面板 或 '/df reset' 重置设置";

elseif (GetLocale() == "zhTW") then
	-- locale by 急云@CWDG
	-- 2008-7-22 DROOD FOCUS v2.4.1b
	--DROODFOCUS_VERSION = "2.4.1b";
	--DROODFOCUS = "Drood Focus "..DROODFOCUS_VERSION;
	DROODFOCUS_WELCOME = "Drood Focus "..DROODFOCUS_VERSION.." - 鍵入 /droodfocus 或 /df 打開設置。";
	DROODFOCUS_SCALE = "縮放";
	DROODFOCUS_LOW = "低";
	DROODFOCUS_HIGH = "高";
	DROODFOCUS_LOCK = "鎖定.";
	DROODFOCUS_CLAWS = "致命一击時顯示爪痕/血腥效果。";
	DROODFOCUS_TRACKER = "顯示減益欄.";
	--DROODFOCUS_CONTX = "X";
	--DROODFOCUS_CONTY = "Y";
	DROODFOCUS_MINI = "最小.";
	DROODFOCUS_MAXI = "最大.";
	DROODFOCUS_ENABLE = "開啟.";
	DROODFOCUS_ALPHA = "血腥效果."
	DROODFOCUS_CMD		= DROODFOCUS..": 輸入 '/df config' 打開設定板 或 '/df reset' 重置設定";
end